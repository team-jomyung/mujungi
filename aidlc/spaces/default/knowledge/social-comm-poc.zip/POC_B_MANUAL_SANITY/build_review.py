# -*- coding: utf-8 -*-
"""리뷰용 두 파일을 만든다. 손으로 적지 않고 장면 파일에서 뽑는다.

    python build_review.py

  MANUAL_REVIEW.html      가린 채 보는 화면. 기술 이름도 등급도 안 보인다
  MANUAL_REVIEW_KEY.csv   답 맞춰 볼 때만 여는 열쇠

왜 만들어서 확인까지 하나
  가렸다고 말만 하는 것은 가린 것이 아니다. 만든 뒤 HTML 안을 뒤져서
  기술 이름 · 등급 · Core 필드 · 씨앗 id 가 한 글자라도 남아 있으면 **실패한다.**
  일부러 흘려 놓고 안 잡히는지도 확인한다.

항목 순서
  M01 M02 M03 은 같은 앵커의 같은 · 가까운 · 먼 순서다. 그대로 보여 주면
  세 번째마다 먼 것이라는 규칙이 보인다. 씨를 고정해 섞고 R01~R18 로 다시 매긴다.
  되돌리는 표는 열쇠 파일에만 있다.
"""
from __future__ import annotations

import csv
import io
import json
import os
import random
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
SCENES = os.path.join(HERE, 'generated_scenes.jsonl')
HTML = os.path.join(HERE, 'MANUAL_REVIEW.html')
KEY = os.path.join(HERE, 'MANUAL_REVIEW_KEY.csv')
SHUFFLE_SEED = 20260914

# 응답 CSV 의 칸 이름. **여기서만 정한다.**
# 화면의 JS 가 이것을 쓰고, summarize_manual_review.py 가 이것을 import 해서 대조한다.
# 두 자리에 따로 적으면 한쪽만 고쳐도 아무 말 없이 어긋난다.
RESPONSE_COLS = ('display_id', 'q1_naturalness', 'q2_context_sufficient',
                 'q3_same_ability', 'q4_distance', 'q5_answer_leak', 'memo')

Q4_CHOICES = [
    ('SAME_CONTEXT', '거의 같은 상황', '사람과 관계는 그대로고 소재나 장소만 바뀌었다'),
    ('NEAR', '조금 먼 상황', '상대와의 관계나 자리 성격이 달라졌다. 걸린 것의 무게는 비슷하다'),
    ('FAR', '많이 먼 상황', '관계나 자리도 달라졌고 잘못됐을 때 치를 것도 달라졌다'),
    ('UNSURE', '모르겠다', ''),
]


def esc(t):
    return (t.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
            .replace('"', '&quot;'))


def scene_html(text):
    """장면을 줄 단위로 문단으로 만든다. 괄호로 시작하는 줄은 지문으로 흐리게."""
    out = []
    for ln in text.split(chr(10)):
        t = ln.strip()
        if not t:
            continue
        cls = 'stage' if t.startswith('(') else 'line'
        out.append('<p class="%s">%s</p>' % (cls, esc(t)))
    return chr(10).join(out)


def build_key(rows):
    cols = ['display_id', 'item_id', 'anchor_id', 'scope_skill', 'skill_family',
            'seed_origin', 'intended_distance', 'invariant_sentence',
            'core_target_skill', 'core_required_inference', 'core_perspective_structure',
            'core_decidable_by_evidence', 'core_direct_check_allowed',
            'planned_changed_axes', 'surface_axes',
            'anchor_relationship_type', 'anchor_situation_type',
            'anchor_misread_cost', 'anchor_recoverable',
            'variant_relationship_type', 'variant_situation_type',
            'variant_misread_cost', 'variant_recoverable',
            'attempt_number', 'regenerated', 'generation_warning']
    with io.open(KEY, 'w', encoding='utf-8-sig', newline='') as fh:
        w = csv.writer(fh)
        w.writerow(cols)
        for r in rows:
            c, a, v = r['core'], r['anchor_context'], r['variant_context']
            w.writerow([
                r['display_id'], r['item_id'], r['anchor_id'], r['scope_skill'],
                r['skill_family'], r['seed_origin'] or '', r['intended_distance'],
                r['invariant_sentence'],
                c['target_skill'], c['required_inference'], c['perspective_structure'],
                c['decidable_by_evidence'], c['direct_check_allowed'],
                ' · '.join(r['planned_changed_axes']), ' · '.join(r['surface_axes']),
                a['relationship_type'], a['situation_type'], a['misread_cost'],
                a['recoverable'],
                v['relationship_type'], v['situation_type'], v['misread_cost'],
                v['recoverable'],
                r['attempt_number'], 'YES' if r['regenerated'] else 'NO',
                r['generation_warning']])
    return cols


def q4_html(did):
    out = []
    for val, label, hint in Q4_CHOICES:
        h = ('<span class="hint">%s</span>' % esc(hint)) if hint else ''
        out.append(
            '<label class="opt"><input type="radio" name="%s_q4" value="%s">'
            '<span class="ol"><b>%s</b>%s</span></label>' % (did, val, esc(label), h))
    return chr(10).join(out)


def card(r, i, n):
    d = r['display_id']
    return TPL_CARD.format(
        did=d, i=i, n=n,
        anchor=scene_html(r['anchor_scene']),
        variant=scene_html(r['generated_scene']),
        q4=q4_html(d))


def main():
    if not os.path.exists(SCENES):
        print('없다 · generated_scenes.jsonl · build_scenes.py 를 먼저 돌린다')
        return 2
    rows = [json.loads(x) for x in io.open(SCENES, encoding='utf-8') if x.strip()]
    if not rows:
        print('장면이 없다')
        return 2

    random.Random(SHUFFLE_SEED).shuffle(rows)
    for i, r in enumerate(rows, 1):
        r['display_id'] = 'R%02d' % i

    build_key(rows)
    cards = chr(10).join(card(r, i, len(rows)) for i, r in enumerate(rows, 1))
    html = TPL_PAGE.format(n=len(rows), cards=cards, seed=SHUFFLE_SEED,
                           cols=','.join(RESPONSE_COLS))
    io.open(HTML, 'w', encoding='utf-8', newline='\n').write(html)

    print('열쇠 · %s (%d행)' % (os.path.basename(KEY), len(rows)))
    print('화면 · %s (%d항목 · %s bytes)'
          % (os.path.basename(HTML), len(rows), format(len(html.encode('utf-8')), ',')))

    bad = leak_scan(html, rows)
    print('가림 확인 · %s' % ('샌 것 없다' if not bad else '**샜다**'))
    for b in bad:
        print('    %s' % b)

    planted = leak_selftest(rows)
    print('  일부러 흘린 %d개 중 %d개가 잡혔다' % (planted[1], planted[0]))
    if planted[0] != planted[1]:
        return 1
    return 1 if bad else 0


# ── 가림 확인 ──────────────────────────────────────────────
MIN_LEN = 2   # `S2` 가 두 글자다. 셋으로 잘랐더니 기술 id 가 통째로 안 보였다


def secrets_of(rows):
    """화면에 있으면 안 되는 낱말들.

    값은 **항목마다 다를 때만** 비밀이다. 열여덟 항목이 전부 같은 값을 가지면
    그 값을 봐도 어느 항목인지 알 수 없다. `target_skill=PRODUCT` 가 그렇다.
    반대로 id 와 필드 이름은 값이 같든 다르든 늘 가린다. 기술 낱말 자체가 안 보여야 한다."""
    always, varying = set(), {}

    def note(bucket, v):
        if isinstance(v, str) and v:
            varying.setdefault(bucket, set()).add(v)

    for r in rows:
        for x in (r['scope_skill'], r['skill_family'], r['intended_distance'],
                  r['anchor_id'], r['item_id'], r['seed_origin'],
                  r['invariant_sentence'], r['generation_warning']):
            if x:
                always.add(x)
        for k, v in r['core'].items():
            always.add(k)
            note('core.' + k, v)
        for side, ctx in (('a', r['anchor_context']), ('v', r['variant_context'])):
            for k, v in ctx.items():
                always.add(k)
                note('ctx.' + k, v)
        always.update(r['planned_changed_axes'])

    for bucket, vals in varying.items():
        if len(vals) > 1:          # 항목을 갈라 주는 값만 비밀이다
            always |= vals
    return {x for x in always if x}


def leak_scan(html, rows):
    """등급 이름은 라디오 value 로 꼭 들어간다. 그 자리만 빼고 본다.

    CSS 는 뺀다. `place-items: center` 가 표면 축 `place` 로 잡혔다.
    앞서 `<t[hd]>` 가 `<thead>` 를 잡았던 것과 같은 부류다. CSS 에는 자료가 안 들어간다.
    `<script>` 는 **빼지 않는다.** 거기로 새면 진짜 새는 것이다."""
    stripped = re.sub(r'<style[^>]*>.*?</style>', '', html, flags=re.S)
    stripped = re.sub(r'<input[^>]*>', '', stripped)
    bad = []
    for s in sorted(secrets_of(rows), key=len, reverse=True):
        if len(s) < MIN_LEN:
            continue
        if s.isascii():
            # 통낱말로만 본다. `place` 가 `placeholder` · `.replace(` 에 걸렸다
            if not re.search(r'(?<![A-Za-z0-9_])%s(?![A-Za-z0-9_])' % re.escape(s), stripped):
                continue
        elif s not in stripped:
            continue
        bad.append('"%s"' % s[:44])
    # 등급이 value 밖에서도 나오는지 따로 본다
    for g in ('SAME_CONTEXT', 'NEAR', 'FAR'):
        n_all = html.count(g)
        n_val = len(re.findall(r'value="%s"' % g, html))
        if n_all != n_val:
            bad.append('등급 "%s" 가 라디오 밖에 %d번' % (g, n_all - n_val))
    return bad


def leak_selftest(rows):
    """일부러 흘려 놓고 잡히는지 본다. 안 잡히면 이 검사는 없는 것이다."""
    base = TPL_PAGE.format(n=1, cards='<p>x</p>', seed=0,
                           cols=','.join(RESPONSE_COLS))
    planted = [
        base + '<p>표면 축은 place 였다</p>',
        base + '<p>topic 과 participants 를 바꿨다</p>',
        base + '<p>이 항목의 기술은 S2 관계 조정이다</p>',
        base + '<p>indirect_meaning</p>',
        base + '<p>이 변형은 FAR 이다</p>',
        base + '<p>앵커 A2a 에서 왔다</p>',
        base + '<p>상대가 껄끄러운 말을 돌려서 했다</p>',
        base + '<p>misread_cost 가 HIGH 다</p>',
    ]
    hit = sum(1 for h in planted if leak_scan(h, rows))
    return hit, len(planted)


# ── 틀 ────────────────────────────────────────────────────
TPL_CARD = '''
<article class="card" id="{did}">
  <header class="chead">
    <span class="cid">{did}</span>
    <span class="cnum">{i} / {n}</span>
  </header>

  <div class="scenes">
    <section class="sc sc-a">
      <h3>원본 상황</h3>
      {anchor}
    </section>
    <section class="sc sc-b">
      <h3>생성된 상황</h3>
      {variant}
    </section>
  </div>

  <div class="qs">
    <fieldset class="q">
      <legend>1 &middot; 생성된 상황이 실제로 있을 법한가</legend>
      <div class="scale">
        <span class="send">전혀</span>
        <label class="num"><input type="radio" name="{did}_q1" value="1"><span>1</span></label>
        <label class="num"><input type="radio" name="{did}_q1" value="2"><span>2</span></label>
        <label class="num"><input type="radio" name="{did}_q1" value="3"><span>3</span></label>
        <label class="num"><input type="radio" name="{did}_q1" value="4"><span>4</span></label>
        <label class="num"><input type="radio" name="{did}_q1" value="5"><span>5</span></label>
        <span class="send">매우</span>
      </div>
    </fieldset>

    <fieldset class="q">
      <legend>2 &middot; 무슨 일이 벌어지는지 알 만큼 설명이 있는가</legend>
      <div class="opts two">
        <label class="opt"><input type="radio" name="{did}_q2" value="YES"><span class="ol"><b>충분하다</b></span></label>
        <label class="opt"><input type="radio" name="{did}_q2" value="NO"><span class="ol"><b>모자라다</b></span></label>
      </div>
    </fieldset>

    <fieldset class="q">
      <legend>3 &middot; 두 상황이 같은 능력을 요구하는가</legend>
      <div class="opts">
        <label class="opt"><input type="radio" name="{did}_q3" value="SAME"><span class="ol"><b>같다</b><span class="hint">잘 해내려면 같은 것을 알아채야 한다</span></span></label>
        <label class="opt"><input type="radio" name="{did}_q3" value="DIFFERENT"><span class="ol"><b>다르다</b><span class="hint">다른 것을 알아채야 한다</span></span></label>
        <label class="opt"><input type="radio" name="{did}_q3" value="UNSURE"><span class="ol"><b>모르겠다</b></span></label>
      </div>
    </fieldset>

    <fieldset class="q">
      <legend>4 &middot; 원본에서 얼마나 멀어졌는가</legend>
      <div class="opts">
        {q4}
      </div>
    </fieldset>

    <fieldset class="q">
      <legend>5 &middot; 어떻게 해야 하는지 글이 알려 주고 있는가</legend>
      <div class="opts two">
        <label class="opt"><input type="radio" name="{did}_q5" value="YES"><span class="ol"><b>알려 준다</b><span class="hint">속마음을 풀어 주거나 답을 짚어 준다</span></span></label>
        <label class="opt"><input type="radio" name="{did}_q5" value="NO"><span class="ol"><b>안 알려 준다</b></span></label>
      </div>
    </fieldset>

    <fieldset class="q memo">
      <legend>메모</legend>
      <textarea name="{did}_memo" rows="2" placeholder="걸리는 것이 있으면 적는다"></textarea>
    </fieldset>
  </div>
</article>'''

TPL_PAGE = '''<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>수동 점검 · 생성 장면 {n}건</title>
<style>
:root {{
  --paper: #faf8f4; --paper-2: #f2eee6; --paper-3: #e8e2d6;
  --ink: #23201b; --ink-soft: #5b544a; --ink-faint: #8d857a;
  --rule: #ddd5c6; --accent: #7a3b1f; --accent-soft: #f0e4da;
  --ok: #3d6b4a; --warn: #8a5a1a;
  --stack: system-ui, "Segoe UI", "Malgun Gothic", "Apple SD Gothic Neo", sans-serif;
  --serif: "Iowan Old Style", "Palatino Linotype", "Batang", "Nanum Myeongjo", serif;
  --w: 62rem;
}}
@media (prefers-color-scheme: dark) {{
  :root:not([data-theme="light"]) {{
    --paper: #181613; --paper-2: #201d19; --paper-3: #2a2621;
    --ink: #ece6dc; --ink-soft: #b3aa9c; --ink-faint: #857d71;
    --rule: #35302a; --accent: #d98f62; --accent-soft: #2e241d;
    --ok: #7fb894; --warn: #d5a45f;
  }}
}}
:root[data-theme="dark"] {{
  --paper: #181613; --paper-2: #201d19; --paper-3: #2a2621;
  --ink: #ece6dc; --ink-soft: #b3aa9c; --ink-faint: #857d71;
  --rule: #35302a; --accent: #d98f62; --accent-soft: #2e241d;
  --ok: #7fb894; --warn: #d5a45f;
}}
* {{ box-sizing: border-box; }}
html, body {{ overflow-x: clip; }}
body {{
  margin: 0; background: var(--paper); color: var(--ink);
  font-family: var(--stack); font-size: 15px; line-height: 1.65;
  -webkit-font-smoothing: antialiased;
}}
.wrap {{ max-width: var(--w); margin: 0 auto; padding: 0 1.25rem 6rem; }}

/* ── 머리 ── */
.top {{ border-bottom: 1px solid var(--rule); padding: 3.5rem 0 2rem; margin-bottom: 2rem; }}
.kicker {{
  font-size: .7rem; letter-spacing: .16em; text-transform: uppercase;
  color: var(--accent); font-weight: 600; margin: 0 0 .9rem;
}}
h1 {{
  font-family: var(--serif); font-style: normal; font-weight: 600;
  font-size: clamp(1.7rem, 4.4vw, 2.5rem); line-height: 1.2; margin: 0 0 1rem;
  letter-spacing: -.01em; overflow-wrap: anywhere; min-width: 0;
}}
.lede {{ color: var(--ink-soft); max-width: 44rem; margin: 0 0 1.5rem; }}
.banner {{
  border: 1px solid var(--rule); border-left: 3px solid var(--warn);
  background: var(--paper-2); padding: .85rem 1.1rem; margin: 0 0 1.75rem;
  font-size: .84rem; color: var(--ink-soft);
}}
.banner b {{ color: var(--ink); }}
.how {{ display: grid; gap: .45rem; margin: 0; padding: 0; list-style: none;
        font-size: .87rem; color: var(--ink-soft); }}
.how li {{ padding-left: 1.15rem; position: relative; }}
.how li::before {{ content: "·"; position: absolute; left: .3rem; color: var(--accent); }}

/* ── 진행 ── */
.bar {{
  position: sticky; top: 0; z-index: 5; background: var(--paper);
  border-bottom: 1px solid var(--rule); padding: .7rem 0; margin-bottom: 2rem;
  display: flex; align-items: center; gap: 1rem; flex-wrap: wrap;
}}
.bar .track {{ flex: 1 1 10rem; height: 3px; background: var(--paper-3); min-width: 0; }}
.bar .fill {{ height: 100%; width: 0; background: var(--accent); transition: width .2s; }}
.bar .cnt {{ font-variant-numeric: tabular-nums; font-size: .82rem; color: var(--ink-soft); }}
.bar button {{
  font: inherit; font-size: .8rem; padding: .35rem .8rem; cursor: pointer;
  background: var(--ink); color: var(--paper); border: 1px solid var(--ink);
}}
.bar button.ghost {{ background: transparent; color: var(--ink); }}
.bar button:hover {{ background: var(--accent); border-color: var(--accent); color: #fff; }}

/* ── 항목 ── */
.card {{ border-top: 1px solid var(--rule); padding: 2.25rem 0 2.5rem; scroll-margin-top: 4rem; }}
.card.done {{ opacity: .55; }}
.card.done:hover, .card.done:focus-within {{ opacity: 1; }}
.chead {{ display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 1.1rem; }}
.cid {{ font-family: var(--serif); font-size: 1.05rem; letter-spacing: .04em; }}
.cnum {{ font-size: .75rem; color: var(--ink-faint); font-variant-numeric: tabular-nums; }}

.scenes {{ display: grid; grid-template-columns: minmax(0,1fr) minmax(0,1fr); gap: 1px;
           background: var(--rule); border: 1px solid var(--rule); }}
.sc {{ background: var(--paper); padding: 1.1rem 1.2rem 1.3rem; }}
.sc-b {{ background: var(--paper-2); }}
.sc h3 {{
  font-size: .68rem; letter-spacing: .14em; text-transform: uppercase;
  color: var(--ink-faint); font-weight: 600; margin: 0 0 .8rem;
}}
.sc-b h3 {{ color: var(--accent); }}
.sc p {{ margin: 0 0 .42rem; }}
.sc .line {{ font-size: .93rem; }}
.sc .stage {{ font-size: .85rem; color: var(--ink-faint); }}

/* ── 질문 ── */
.qs {{ margin-top: 1.4rem; display: grid; gap: 1.1rem; }}
.q {{ border: 0; padding: 0; margin: 0; }}
.q legend {{ font-size: .85rem; font-weight: 600; padding: 0 0 .5rem; color: var(--ink); }}
.opts {{ display: flex; flex-wrap: wrap; gap: .5rem; }}
.opt {{ flex: 1 1 13rem; min-width: 0; }}
.opts.two .opt {{ flex: 0 1 13rem; }}
.opt input {{ position: absolute; opacity: 0; width: 0; height: 0; }}
.ol {{
  display: block; border: 1px solid var(--rule); background: var(--paper);
  padding: .5rem .75rem; cursor: pointer; font-size: .85rem;
  transition: border-color .12s, background .12s;
}}
.ol b {{ font-weight: 600; display: block; white-space: nowrap; }}
.ol .hint {{ display: block; font-size: .74rem; color: var(--ink-faint);
             line-height: 1.4; margin-top: .15rem; white-space: normal; }}
.opt:hover .ol {{ border-color: var(--ink-faint); }}
.opt input:focus-visible + .ol {{ outline: 2px solid var(--accent); outline-offset: 1px; }}
.opt input:checked + .ol {{ border-color: var(--accent); background: var(--accent-soft); }}

.scale {{ display: flex; align-items: center; gap: .4rem; flex-wrap: wrap; }}
.send {{ font-size: .74rem; color: var(--ink-faint); }}
.num input {{ position: absolute; opacity: 0; width: 0; height: 0; }}
.num span {{
  display: grid; place-items: center; width: 2.35rem; height: 2.1rem;
  border: 1px solid var(--rule); background: var(--paper); cursor: pointer;
  font-variant-numeric: tabular-nums; font-size: .9rem;
}}
.num:hover span {{ border-color: var(--ink-faint); }}
.num input:focus-visible + span {{ outline: 2px solid var(--accent); outline-offset: 1px; }}
.num input:checked + span {{ border-color: var(--accent); background: var(--accent-soft); font-weight: 600; }}

.memo textarea {{
  width: 100%; font: inherit; font-size: .85rem; padding: .55rem .7rem;
  border: 1px solid var(--rule); background: var(--paper); color: var(--ink);
  resize: vertical;
}}
.memo textarea:focus-visible {{ outline: 2px solid var(--accent); outline-offset: 1px; }}

/* ── 내보내기 ── */
.out {{ border-top: 1px solid var(--rule); margin-top: 2rem; padding-top: 2rem; }}
.out h2 {{ font-family: var(--serif); font-weight: 600; font-size: 1.3rem; margin: 0 0 .6rem; }}
.out p {{ color: var(--ink-soft); font-size: .88rem; margin: 0 0 1rem; }}
.out textarea {{
  width: 100%; font-family: ui-monospace, Consolas, monospace; font-size: .74rem;
  line-height: 1.5; padding: .8rem; border: 1px solid var(--rule);
  background: var(--paper-2); color: var(--ink); resize: vertical;
}}
.row {{ display: flex; gap: .5rem; flex-wrap: wrap; margin-bottom: 1rem; }}
.row button, .row a {{
  font: inherit; font-size: .82rem; padding: .45rem .95rem; cursor: pointer;
  border: 1px solid var(--ink); background: var(--ink); color: var(--paper);
  text-decoration: none; display: inline-block;
}}
.row .ghost {{ background: transparent; color: var(--ink); }}
.row button:hover, .row a:hover {{ background: var(--accent); border-color: var(--accent); color: #fff; }}
.saved {{ font-size: .78rem; color: var(--ok); }}

@media (max-width: 720px) {{
  .scenes {{ grid-template-columns: minmax(0,1fr); }}
  .opt, .opts.two .opt {{ flex: 1 1 100%; }}
  .top {{ padding-top: 2.25rem; }}
}}
</style>
</head>
<body>
<div class="wrap">

<header class="top">
  <p class="kicker">Developer manual sanity check</p>
  <h1>생성된 상황이 쓸 만한가</h1>
  <p class="lede">
    같은 상황을 바꿔 만든 글 {n}건이다. 원본과 나란히 놓고 다섯 가지를 본다.
    맞고 틀리고를 가리는 자리가 아니라, 생성기가 이상한 것을 뱉는지 보는 자리다.
  </p>

  <div class="banner">
    <b>이것은 연구 결과가 아니다.</b>
    만든 사람이 자기 생성기를 눈으로 확인하는 절차다.
    사람 대상 검증이 아니고, 여기서 나온 수치를 성능이라고 부르지 않는다.
  </div>

  <ul class="how">
    <li>어떤 기술을 겨냥했는지, 얼마나 멀게 만들려 했는지는 일부러 가렸다. 보고 판단한다.</li>
    <li>순서는 섞여 있다. 앞뒤 항목이 이어지지 않는다.</li>
    <li>모르겠으면 모르겠다를 고른다. 억지로 고르면 숫자만 나빠진다.</li>
    <li>답은 이 브라우저에 저장된다. 다 하고 아래에서 CSV 로 내린다.</li>
  </ul>
</header>

<div class="bar">
  <div class="track"><div class="fill" id="fill"></div></div>
  <span class="cnt" id="cnt">0 / {n}</span>
  <button type="button" class="ghost" id="jump">덜 한 곳으로</button>
  <button type="button" class="ghost" id="wipe">비우기</button>
</div>

<main id="items">
{cards}
</main>

<section class="out">
  <h2>내보내기</h2>
  <p>
    아래 CSV 를 <code>manual_review_responses.csv</code> 로 저장한 뒤
    <code>python summarize_manual_review.py</code> 를 돌린다.
    브라우저가 내려받기를 막으면 상자 안의 글을 그대로 복사해도 된다.
  </p>
  <div class="row">
    <a id="dl" download="manual_review_responses.csv">CSV 내려받기</a>
    <button type="button" class="ghost" id="copy">복사</button>
    <span class="saved" id="saved"></span>
  </div>
  <textarea id="csv" rows="10" readonly></textarea>
</section>

</div>

<script>
(function () {{
  var KEY = 'poc_b_manual_review_v1';
  var N = {n};
  var items = Array.prototype.slice.call(document.querySelectorAll('.card'));
  var store = {{}};

  try {{ store = JSON.parse(localStorage.getItem(KEY) || '{{}}'); }} catch (e) {{ store = {{}}; }}

  function fields(card) {{
    return Array.prototype.slice.call(card.querySelectorAll('input[type=radio], textarea'));
  }}
  function answered(card) {{
    var need = ['q1', 'q2', 'q3', 'q4', 'q5'];
    return need.every(function (q) {{
      return card.querySelector('input[name$="_' + q + '"]:checked') !== null;
    }});
  }}
  function restore() {{
    Object.keys(store).forEach(function (k) {{
      var v = store[k];
      var ta = document.querySelector('textarea[name="' + k + '"]');
      if (ta) {{ ta.value = v; return; }}
      var r = document.querySelector('input[name="' + k + '"][value="' + v + '"]');
      if (r) {{ r.checked = true; }}
    }});
  }}
  function save() {{
    try {{ localStorage.setItem(KEY, JSON.stringify(store)); }} catch (e) {{}}
  }}
  function csv() {{
    var out = ['{cols}'];
    items.forEach(function (c) {{
      var id = c.id;
      var row = [id];
      ['q1', 'q2', 'q3', 'q4', 'q5'].forEach(function (q) {{
        var r = c.querySelector('input[name="' + id + '_' + q + '"]:checked');
        row.push(r ? r.value : '');
      }});
      var ta = c.querySelector('textarea');
      var m = (ta ? ta.value : '').replace(/"/g, '""').replace(/[\\r\\n]+/g, ' ');
      row.push(m ? '"' + m + '"' : '');
      out.push(row.join(','));
    }});
    return out.join('\\n') + '\\n';
  }}
  function refresh() {{
    var done = 0;
    items.forEach(function (c) {{
      var ok = answered(c);
      c.classList.toggle('done', ok);
      if (ok) {{ done += 1; }}
    }});
    document.getElementById('cnt').textContent = done + ' / ' + N;
    document.getElementById('fill').style.width = (done / N * 100) + '%';
    var text = csv();
    document.getElementById('csv').value = text;
    var a = document.getElementById('dl');
    a.href = 'data:text/csv;charset=utf-8,' + encodeURIComponent('\\ufeff' + text);
  }}

  document.getElementById('items').addEventListener('change', function (e) {{
    var t = e.target;
    if (!t.name) {{ return; }}
    store[t.name] = t.value;
    save();
    refresh();
  }});
  document.getElementById('items').addEventListener('input', function (e) {{
    var t = e.target;
    if (t.tagName !== 'TEXTAREA') {{ return; }}
    store[t.name] = t.value;
    save();
    refresh();
  }});
  document.getElementById('jump').addEventListener('click', function () {{
    var next = items.filter(function (c) {{ return !answered(c); }})[0];
    if (next) {{ next.scrollIntoView({{ behavior: 'smooth', block: 'start' }}); }}
  }});
  document.getElementById('wipe').addEventListener('click', function () {{
    store = {{}};
    save();
    items.forEach(function (c) {{
      fields(c).forEach(function (f) {{
        if (f.type === 'radio') {{ f.checked = false; }} else {{ f.value = ''; }}
      }});
    }});
    refresh();
  }});
  document.getElementById('copy').addEventListener('click', function () {{
    var ta = document.getElementById('csv');
    ta.select();
    var ok = false;
    try {{ ok = document.execCommand('copy'); }} catch (e) {{ ok = false; }}
    document.getElementById('saved').textContent = ok ? '복사했다' : '직접 복사한다';
    setTimeout(function () {{ document.getElementById('saved').textContent = ''; }}, 2500);
  }});

  restore();
  refresh();
}})();
</script>
</body>
</html>
'''

if __name__ == '__main__':
    sys.exit(main())
