# -*- coding: utf-8 -*-
"""장면이 생성 원칙을 지켰는가. 내 눈이 아니라 규칙이 본다.

    python check_scenes.py

무엇을 보나
  1 자리표시자      "상대가 먼저 말을 꺼냈다" 같은 Echo 문구
  2 기술용어 노출    required_inference · NEAR · SAME_CONTEXT · Core 필드 이름
  3 태그 노출       [관계:] 같은 메타데이터 표기
  4 정답 · 속마음    "사실은 거절이었다" · "~라는 뜻이다" 같은 해설
  5 턴 수          3~7턴
  6 실명            특정 학교 · 회사 이름
  7 옛 씨앗 혼입     이번 범위 밖 skill (S4~S8 · 운율 · 비언어)
  8 등급 규칙       바꾼 축이 등급 정의와 맞는가

**심어 보고 터지는지도 확인한다.** 조용히 통과하는 검사는 없는 것만 못하다.
"""
from __future__ import annotations

import io
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
SCENES = os.path.join(HERE, 'generated_scenes.jsonl')

PLACEHOLDER = ('상대가 먼저 말을 꺼냈다', '나는 대답했다', '상대가 말했다.', '나는 말했다.',
               'placeholder', 'TODO', 'lorem')
TECH = ('required_inference', 'perspective_structure', 'decidable_by_evidence',
        'direct_check_allowed', 'target_skill', 'SAME_CONTEXT', 'NEAR', 'FAR',
        'skill_identity', 'transfer_distance', 'misread_cost', 'recoverable',
        'relationship_type', 'situation_type')
TAG_RX = re.compile(r'\[(관계|대가|회복|상황|스킬|skill|relationship)\s*[:：]')
# 상대의 속마음을 단정하거나 답을 알려 주는 해설
ANSWER_RX = re.compile(
    r'(사실은?\s*거절|사실\s*싫|속으로는|진심은|라는 뜻이[다었]|의미였다|'
    r'거절의 의미|이때는 .{0,12}해야|정답은|올바른 (반응|대답))')
SCHOOL_RX = re.compile(r'(서울대|연세대|고려대|카이스트|포항공대|한양대|성균관|중앙대|경희대)')
CORP_RX = re.compile(r'(삼성|엘지|LG|현대자동차|SK\b|네이버|카카오|쿠팡|배달의민족|토스)')
# 이번 범위 밖
OUT_OF_SCOPE = ('repair_clarification', 'topic_management', 'reciprocity_responsiveness',
                'prosody', 'nonverbal', '운율', '비언어')
ALLOWED_SKILL = {'S1', 'S2', 'S3'}
ALLOWED_FAMILY = {'listener_knowledge', 'information_quantity',
                  'listener_relationship_adaptation', 'indirect_meaning'}

# 화자 이름에 쓰는 역할 낱말
ROLE = ('선배', '후배', '형', '누나', '언니', '오빠', '팀장', '점장', '교수', '조교',
        '동기', '룸메', '사장', '대리', '과장', '선생', '조원', '동료', '친구', '엄마', '아빠')

SURFACE = {'topic', 'place', 'participants'}
CTX_AXES = {'relationship_type', 'situation_type'}
RISK_AXES = {'misread_cost', 'recoverable'}


def turns(scene):
    """대사 줄 수. 화자 이름으로 시작하거나 (메일) 이 붙은 줄을 센다."""
    n = 0
    for ln in scene.split(chr(10)):
        t = ln.strip()
        if not t or t.startswith('('):
            continue
        if '"' in t or '"' in t:
            n += 1
    return n


def speakers(scene):
    """화자 표시. 따옴표나 여는 괄호 앞에 오는 짧은 이름."""
    out = []
    for ln in scene.split(chr(10))[1:]:
        m = re.match(r'^([^"“(]{1,8}?)\s*["“(]', ln.strip())
        if m and m.group(1).strip():
            out.append(m.group(1).strip())
    return out


def check_speaker(scene):
    """지문이 소개한 사람과 화자 표시가 어긋나는가.

    A2b 의 가까운 변형이 이랬다. 지문은 "동아리 선배인 형" 이라고만 하는데
    화자는 "룸메" 로 적혀 있어, 앵커를 같이 보지 않으면 같은 사람인지 안 읽혔다.

    좁게 본다. 지문이 역할 낱말을 쓰고 · 화자도 역할 낱말인데 · 둘이 겹치지 않고 ·
    그 화자 이름이 장면 어디에서도 안 불릴 때만 잡는다.
    `조원` `동료` `A` 처럼 지문에 역할 낱말이 없는 경우는 건드리지 않는다."""
    lines = scene.split(chr(10))
    narr = lines[0]
    nn = [x for x in ROLE if x in narr]
    if not nn:
        return []
    body = []
    for ln in lines:
        t = ln.strip()
        m = re.match(r'^([^"“(]{1,8}?)\s*(["“(].*)$', t)
        body.append(m.group(2) if m else t)
    body = chr(10).join(body)
    bad = []
    for sp in sorted(set(speakers(scene)) - {'나'}):
        if not any(x in sp for x in ROLE):
            continue
        if any(x in sp for x in nn):
            continue
        if sp in body:
            continue
        bad.append('지문은 %s 라 하는데 화자는 "%s" 다 · 장면 안에서 한 번도 안 불린다'
                   % (nn, sp))
    return bad


def check_grade(r):
    """바꾼 축이 등급 정의와 맞는가. variation_plan.py 의 정의를 그대로 쓴다."""
    g = r['intended_distance']
    ax = set(r['planned_changed_axes'])
    a, v = r['anchor_context'], r['variant_context']
    real = {k for k in ('relationship_type', 'situation_type', 'misread_cost', 'recoverable')
            if a.get(k) != v.get(k)}
    bad = []
    if g == 'SAME_CONTEXT':
        if real:
            bad.append('SAME_CONTEXT 인데 맥락 축이 바뀌었다 · %s' % sorted(real))
        if not (ax & SURFACE):
            bad.append('SAME_CONTEXT 인데 표면 축을 안 바꿨다')
    elif g == 'NEAR':
        if not (real & CTX_AXES):
            bad.append('NEAR 인데 관계도 상황도 안 바뀌었다')
        if real & RISK_AXES:
            bad.append('NEAR 인데 대가/회복이 바뀌었다 · %s' % sorted(real & RISK_AXES))
    elif g == 'FAR':
        if not (real & CTX_AXES):
            bad.append('FAR 인데 관계도 상황도 안 바뀌었다')
        if not (real & RISK_AXES):
            bad.append('FAR 인데 대가도 회복도 안 바뀌었다')
    # 적어 둔 축과 실제로 바뀐 축이 맞는가
    declared = ax & (CTX_AXES | RISK_AXES)
    if declared != real:
        bad.append('적어 둔 축 %s · 실제 바뀐 축 %s' % (sorted(declared), sorted(real)))
    return bad


def check_row(r):
    bad = []
    for key in ('anchor_scene', 'generated_scene'):
        sc = r[key]
        for p in PLACEHOLDER:
            if p in sc:
                bad.append('%s · 자리표시자 "%s"' % (key, p))
        for t in TECH:
            if t in sc:
                bad.append('%s · 기술용어 "%s"' % (key, t))
        m = TAG_RX.search(sc)
        if m:
            bad.append('%s · 태그 노출 "%s"' % (key, m.group(0)))
        m = ANSWER_RX.search(sc)
        if m:
            bad.append('%s · 정답/속마음 해설 "%s"' % (key, m.group(0)))
        m = SCHOOL_RX.search(sc) or CORP_RX.search(sc)
        if m:
            bad.append('%s · 실명 "%s"' % (key, m.group(0)))
        n = turns(sc)
        if not (3 <= n <= 7):
            bad.append('%s · 턴 %d (3~7 밖)' % (key, n))
        for b in check_speaker(sc):
            bad.append('%s · %s' % (key, b))
    if r['scope_skill'] not in ALLOWED_SKILL:
        bad.append('이번 범위 밖 skill · %s' % r['scope_skill'])
    if r['skill_family'] not in ALLOWED_FAMILY:
        bad.append('이번 범위 밖 family · %s' % r['skill_family'])
    blob = json.dumps(r, ensure_ascii=False)
    for o in OUT_OF_SCOPE:
        if o in blob:
            bad.append('옛 씨앗 흔적 · %s' % o)
    bad += check_grade(r)
    return bad


SEED_JSON = os.path.normpath(os.path.join(
    HERE, '..', 'FINAL_CLOSURE', '04_GENERATION', 'generator', 'skill_family_seeds.json'))
# STALE_SEED_AUDIT.md 가 적어 둔 전제. 씨앗 파일이 바뀌면 그 문서가 낡은 것이다
AUDIT_IDS = ('S1','S2','S3','S4','S5','S6','S7','S8','S9','S10','X1','X2','X3','X4')
# 씨앗 파일에는 family 필드가 **둘** 있다. 이름이 비슷해 헷갈린다
AUDIT_SKILL_FAMILIES = ('indirect_meaning', 'listener_knowledge', 'information_quantity',
                        'listener_relationship_adaptation', 'repair_clarification',
                        'topic_management', 'reciprocity_responsiveness')
AUDIT_SCOPE_FAMILIES = ('implicit_meaning_comprehension', 'listener_adapted_informativeness',
                        'repair_clarification', 'topic_management', 'relationship_adaptation',
                        'reciprocity_responsiveness')
AUDIT_S2_SEEDS = ('S10',)


def check_audit():
    """STALE_SEED_AUDIT.md 의 전제가 아직 사실인가.

    문서는 손으로 썼다. 씨앗 파일이 바뀌면 문서가 조용히 틀려진다. 그 전에 잡는다."""
    bad = []
    if not os.path.exists(SEED_JSON):
        return ['씨앗 파일이 없다 · %s' % SEED_JSON]
    seeds = json.load(io.open(SEED_JSON, encoding='utf-8'))['seeds']
    ids = tuple(s['id'] for s in seeds)
    if ids != AUDIT_IDS:
        bad.append('씨앗 id 가 달라졌다 · 문서 %s · 실제 %s' % (list(AUDIT_IDS), list(ids)))
    for field, want in (('skill_family', AUDIT_SKILL_FAMILIES),
                        ('scope_family', AUDIT_SCOPE_FAMILIES)):
        fam = {s[field] for s in seeds}
        if fam != set(want):
            bad.append('%s 어휘가 달라졌다 · 문서에 없는 %s · 문서에만 있는 %s'
                       % (field, sorted(fam - set(want)), sorted(set(want) - fam)))
    s2 = tuple(s['id'] for s in seeds
               if s['skill_family'] == 'listener_relationship_adaptation')
    if s2 != AUDIT_S2_SEEDS:
        bad.append('새 S2 의 씨앗이 달라졌다 · 문서 %s · 실제 %s'
                   % (list(AUDIT_S2_SEEDS), list(s2)))
    if set(AUDIT_SKILL_FAMILIES) == set(AUDIT_SCOPE_FAMILIES):
        bad.append('두 어휘가 같아졌다 · 문서의 논점이 사라졌다')
    # 번호가 아니라 이름으로 골랐다는 주장을 확인한다
    for s in seeds:
        if s['skill_family'] in ('repair_clarification', 'topic_management',
                                 'reciprocity_responsiveness') and s['id'] in ALLOWED_SKILL:
            bad.append('겹침이 실재한다는 전제가 깨졌다 · 씨앗 %s' % s['id'])
    return bad


def load():
    return [json.loads(x) for x in io.open(SCENES, encoding='utf-8') if x.strip()]


def main():
    if not os.path.exists(SCENES):
        print('없다 · generated_scenes.jsonl · build_scenes.py 를 먼저 돌린다')
        return 2
    rows = load()
    total = 0
    print('장면 %d' % len(rows))
    for r in rows:
        bad = check_row(r)
        total += len(bad)
        if bad:
            print('  %s · %s · %s' % (r['item_id'], r['scope_skill'], r['intended_distance']))
            for b in bad:
                print('      %s' % b)
    print('  규칙 위반 %d' % total)

    ab = check_audit()
    total += len(ab)
    print('  STALE_SEED_AUDIT.md 전제 · %s' % ('아직 사실' if not ab else '깨졌다'))
    for b in ab:
        print('      %s' % b)

    # 심어 보고 터지는가
    import copy
    fired = 0
    cases = [
        ('자리표시자', lambda d: d.__setitem__('generated_scene', '상대가 먼저 말을 꺼냈다')),
        ('기술용어', lambda d: d.__setitem__('generated_scene',
                                         d['generated_scene'] + chr(10) + '이 장면은 NEAR 다')),
        ('정답 해설', lambda d: d.__setitem__('generated_scene',
                                          d['generated_scene'] + chr(10) + '사실은 거절이었다')),
        ('태그 노출', lambda d: d.__setitem__('generated_scene',
                                          '[관계: 선배]' + chr(10) + d['generated_scene'])),
        ('화자 어긋남', lambda d: d.__setitem__(
            'generated_scene', '같은 동아리 선배인 그 형과 준비를 한다.' + chr(10)
            + '나 "어떻게 돼가요?"' + chr(10) + '룸메 "아직."' + chr(10)
            + '나 "제가 도울까요?"' + chr(10) + '룸메 "아니야."')),
        ('등급 어긋남', lambda d: d['variant_context'].__setitem__(
            'misread_cost', 'HIGH' if d['intended_distance'] == 'NEAR' else
            d['variant_context']['misread_cost'])),
    ]
    base = [r for r in rows if r['intended_distance'] == 'NEAR'][0]
    for label, mut in cases:
        d = copy.deepcopy(base)
        mut(d)
        if check_row(d):
            fired += 1
        else:
            print('    >>> "%s" 를 해도 안 터진다' % label)
    print('  심은 결함 %d개 중 %d개가 터졌다' % (len(cases), fired))
    if fired != len(cases):
        return 1
    return 1 if total else 0


if __name__ == '__main__':
    sys.exit(main())
