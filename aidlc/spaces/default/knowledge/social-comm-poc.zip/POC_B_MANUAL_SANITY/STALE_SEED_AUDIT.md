# 씨앗과 범위가 어긋난 자리

확인일 2026-09-14 · 확인 대상
`FINAL_CLOSURE/04_GENERATION/generator/skill_family_seeds.json` (씨앗 14개)
`FINAL_TARGET_AND_POC/00_DECISION/SKILL_SCOPE_V0_1_FINAL.csv` (범위 S1~S10)

---

## 한 줄

**내용이 낡은 것이 아니라 번호가 겹친다.** 씨앗 파일의 `S1`~`S10` 과 새 범위의 `S1`~`S10` 은
같은 글자를 쓰면서 다른 것을 가리킨다. 씨앗 안에 범위 밖 소재는 하나도 없다.

## 왜 어긋났나

씨앗 파일이 먼저 있었다. 그때 `S`는 seed 의 S 였고 순번일 뿐이었다.
Skill Scope 를 나중에 닫으면서 기술에 `S1`~`S10` 을 다시 매겼다.
두 번호 체계가 서로를 모르는 채로 같은 접두어를 골랐다.

## 겹침 둘 · family 필드가 두 개다

씨앗 한 건에 family 가 **둘** 붙어 있다. 이름이 비슷해서 같은 것으로 읽기 쉽다.

| 필드 | 어휘 | 쓰임 |
|---|---|---|
| `skill_family` | 7종 · 상대 지식과 정보량을 **나눈다** | 생성 프롬프트에서 기술별 지시를 고른다 |
| `scope_family` | 6종 · 둘을 `listener_adapted_informativeness` 로 **묶는다** | `02_SCOPE/ONTOLOGY_SCOPE_FINAL.md` §4·§6 판정 |

씨앗 S4 와 S5 는 `scope_family` 가 같고 `skill_family` 가 다르다.
`scope_family` 로 고르면 둘을 구분할 수 없다.

이번 묶음은 `skill_family` 로 골랐다. 새 범위의 S1 이 상대 지식과 정보량을 한 서명으로
합쳐 놓았기 때문에, 두 씨앗이 같은 기술로 들어오는 것이 맞다. 다만 **어느 필드로 골랐는지**
적어 두지 않으면 다음 사람이 다른 필드를 보고 다른 집합을 얻는다.

## 겹침 하나 · 번호표

| 씨앗 id | `skill_family` | 씨앗 문장 | 새 범위에서 실제로 해당하는 기술 |
|---|---|---|---|
| S1 | indirect_meaning | 상대가 껄끄러운 말을 돌려서 했다 | **S3** 함축 이해 |
| S2 | indirect_meaning | 불편을 말했지만 원한 건 행동이었다 | **S3** |
| S3 | indirect_meaning | 대답이 없는 것 자체가 대답이었다 | **S3** |
| S4 | listener_knowledge | 상대가 모르는 걸 안다고 치고 말했다 | **S1** 청자 맞춤 정보 조절 |
| S5 | information_quantity | 상대가 이미 아는 걸 길게 설명했다 | **S1** |
| S6 | repair_clarification | 상대가 내 말을 다르게 알아들었다 | **S5** 수리 · 명료화 |
| S7 | indirect_meaning | 도와주겠다는 건지 불만인지 몰랐다 | **S3** |
| S8 | topic_management | 상대가 화제를 옮기고 싶어 했다 | **S7** 화제 운용 |
| S9 | indirect_meaning | 말은 괜찮다는데 다른 게 아니라고 했다 | **S3** |
| S10 | listener_relationship_adaptation | 부담 주지 않으면서 부탁해야 했다 | **S2** 관계 · 상황 맞춤 조정 |
| X1 | topic_management | 상대 이야기가 끝나기 전에 내 이야기로 넘어갔다 | **S7** |
| X2 | repair_clarification | 무슨 뜻인지 몰랐는데 묻지 못하고 넘어갔다 | **S6** 모를 때 묻기 |
| X3 | listener_knowledge | 상대가 내 말을 못 따라오는 걸 알아채지 못했다 | **S1** |
| X4 | reciprocity_responsiveness | 상대가 부탁을 했는데 대답 없이 내 이야기만 했다 | **S4** 응답성 · 상호성 |

## 이것이 실제로 일으키는 사고

번호만 보고 거르면 **정확히 거꾸로 걸러진다.**

- 새 범위에서 `S9`(운율)·`S10`(비언어)은 EXCLUDE 다.
  번호로 "S9, S10 을 뺀다" 고 하면 **씨앗 S9(함축 이해)과 씨앗 S10(관계 조정)이 빠진다.**
  씨앗 S10 은 새 S2 의 **하나뿐인 씨앗**이라 S2 가 통째로 사라진다.
- 반대로 "CORE 는 S1, S2, S3 이니 그 씨앗을 쓴다" 고 하면
  **셋 다 함축 이해 씨앗**이 와서 S1·S2 는 한 건도 안 들어온다.

두 경우 다 오류 메시지가 없다. 조용히 틀린 집합이 만들어진다.

## 낡은 씨앗은 없다

`scope_tier` 는 `MVP` 10개와 `MVP_CONDITIONAL` 4개뿐이다.
운율·비언어 씨앗은 **애초에 없다.** 텍스트 매체라 만들어진 적이 없다.
따라서 이번 묶음에서 "범위 밖 씨앗을 걷어냈다" 고 말할 것이 없다. 걷어낼 것이 없었다.

## 새 S2 의 씨앗이 하나뿐이다

| 새 기술 | 대응하는 씨앗 | 개수 |
|---|---|---|
| S1 청자 맞춤 정보 조절 | 씨앗 S4 · S5 · X3 | 3 |
| **S2 관계 · 상황 맞춤 조정** | **씨앗 S10** | **1** |
| S3 함축 이해 | 씨앗 S1 · S2 · S3 · S7 · S9 | 5 |

S2 는 범위표에서 비임상 성인 근거가 가장 두껍다고 적은 기술인데 씨앗은 가장 얇다.
이번 묶음은 앵커를 기술당 둘씩 써야 해서, A2b 는 **씨앗 없이 새로 썼다.**
씨앗 S10 의 Core 서명을 그대로 지켰다.

| | A2a | A2b |
|---|---|---|
| 출처 | 씨앗 S10 | 없음 · 이번에 씀 |
| target_skill | PRODUCT | PRODUCT |
| required_inference | 부담의 크기를 가늠해 표현 수위 정하기 | 같음 |
| perspective_structure | 상대가 나를 어떻게 봤을지 2층 | 같음 |
| decidable_by_evidence | YES | YES |
| direct_check_allowed | NO | NO |

이 사실은 `generated_scenes.jsonl` 의 `seed_origin` 에 그대로 적혀 있다.
A2b 만 씨앗 id 가 비어 있다. 리뷰 결과를 볼 때 A2b 가 유독 나쁘면 씨앗이 없어서일 수 있다.

## 이번 묶음에서 한 일

이번 묶음은 **번호로 고르지 않았다.** `skill_family` 로 골랐다.

    skill_family = listener_knowledge · information_quantity  → 새 S1
    skill_family = listener_relationship_adaptation           → 새 S2
    skill_family = indirect_meaning                           → 새 S3

`check_scenes.py` 가 `skill_family` 를 허용 집합으로 잠가 두었고,
`repair_clarification` · `topic_management` · `reciprocity_responsiveness` 가 한 글자라도
섞이면 실패한다. 번호가 아니라 이름을 본다.

## 고칠 방법 (이번 묶음 밖의 일)

셋 중 하나를 골라야 한다. **이번 묶음에서는 하지 않았다.** 규격을 함부로 안 고치기로 했다.

1. 씨앗 id 를 `SEED-01`~`SEED-14` 로 바꾼다. 접두어가 갈라져 겹칠 일이 없어진다. 가장 깨끗하다.
2. 씨앗에 `scope_skill` 필드를 넣어 새 번호를 명시한다. 파일 하나만 손대면 된다.
3. 그대로 두고 번호로 거르는 코드를 금지한다. 규칙에 기대는 방법이라 가장 약하다.

지금 값으로는 1번이 맞다고 본다. 씨앗 id 를 참조하는 코드가 생성기 안에만 있다.

family 두 개는 **합치지 않는 것이 맞다.** 생성은 상대 지식과 정보량을 나눠야 프롬프트가
달라지고, 판정은 합쳐야 새 S1 과 맞는다. 쓰임이 정말 다르다.
다만 이름을 `prompt_family` · `scope_family` 로 갈라 두면 헷갈릴 일이 줄어든다.

## 다시 확인하는 법

    python -c "import io,json; d=json.load(io.open('../FINAL_CLOSURE/04_GENERATION/generator/skill_family_seeds.json',encoding='utf-8')); print([(s['id'],s['skill_family']) for s in d['seeds']])"

`check_scenes.py` 가 이 표의 전제를 매번 대조한다. 대조하는 것 넷.

- 씨앗 id 14개가 그대로인가
- `skill_family` 7종 · `scope_family` 6종 어휘가 그대로인가
- 새 S2 의 씨앗이 여전히 `S10` 하나뿐인가
- 번호 겹침이 여전히 실재하는가 (없어졌으면 이 문서가 불필요해진 것이다)

씨앗 파일이 바뀌면 이 문서가 낡았다고 말한다.
**이 대조는 처음 돌렸을 때 실제로 걸렸다.** 위의 family 두 개짜리 항목이 그때 나왔다.
