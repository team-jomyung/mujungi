# -*- coding: utf-8 -*-
"""수동 점검용 장면 18개를 JSONL 로 낸다.

    python build_scenes.py

이것이 무엇인가
  **DEVELOPER MANUAL SANITY CHECK 다.** 사람 검증 연구 결과가 아니다.
  Echo dry-run 은 배선만 봤다. 여기서는 **실제 한국어 대화 장면**을 놓고
  사람이 눈으로 자연스러움과 맥락 충분성을 본다.

무엇을 그대로 쓰나
  Core Equivalence Fields · invariant_sentence · base_context 는
  `FINAL_CLOSURE/04_GENERATION/generator/skill_family_seeds.json` 의 것을 그대로 쓴다.
  등급 정의도 `variation_plan.py` 의 것을 그대로 쓴다.

    SAME_CONTEXT  표면 축(화제 · 장소 · 등장인물)만 바꾼다.
                  관계 · 상황 유형 · 오판 대가 · 회복 가능성 유지
    NEAR          관계 또는 상황 유형 하나를 바꾼다. 오판 대가 · 회복 가능성 유지
    FAR           관계 또는 상황 유형을 바꾸고, 오판 대가 또는 회복 가능성도 바꾼다

무엇이 다른가
  장면 글을 Echo 자리표시자가 아니라 **사람이 쓴 한국어 대화**로 채웠다.
  누가 썼나 · 이 세션. 즉 **규격을 아는 쪽이 썼다.** 그것이 이 점검의 한계다.
  README 에 적었다.

기록
  초안을 감추지 않는다. attempt_number · regenerated · generation_warning 을 그대로 남긴다.
"""
from __future__ import annotations

import io
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, 'generated_scenes.jsonl')

# ─────────────────────────────────────────────────────────────
# 앵커 여섯. core 와 invariant 는 씨앗 파일에서 그대로 가져왔다.
# 새 Skill Scope 의 CORE 3 개에만 매핑한다. S4~S8 · S9 · S10 은 이번에 안 쓴다.
# ─────────────────────────────────────────────────────────────

ANCHORS = [
    # ── 새 S1 · 청자 맞춤 정보 조절 ──
    dict(
        anchor_id='A1a', scope_skill='S1', seed_origin='skill_family_seeds.json#S4',
        skill_family='listener_knowledge',
        invariant='상대가 모르는 걸 안다고 치고 말했다',
        core=dict(target_skill='PRODUCE',
                  required_inference='상대가 무엇을 아는지 짐작하기',
                  perspective_structure='상대의 지식 상태 1층',
                  decidable_by_evidence='YES', direct_check_allowed='YES'),
        base=dict(relationship_type='FRIEND_CASUAL', situation_type='FRIEND_PRIVATE',
                  misread_cost='LOW', recoverable=True),
        scene=(
            '동아리 방에서 오랜만에 만난 친구가 요즘 뭐 하냐고 물었다.\n\n'
            '친구 "요즘 뭐 하고 지내? 얼굴을 통 못 봤네."\n'
            '나 "아 나 요즘 그 프로젝트 때문에 정신없어. 지난번에 갈아엎고 다시 시작했거든."\n'
            '친구 "어... 그 프로젝트?"\n'
            '나 "응 원래 팀에서 하던 거. 근데 중간에 방향이 바뀌어서."\n'
            '친구 "아 그렇구나." (잠깐 있다가) "재밌겠다."\n'
            '나 "재밌긴 한데 힘들어. 너는?"'),
    ),
    dict(
        anchor_id='A1b', scope_skill='S1', seed_origin='skill_family_seeds.json#S5',
        skill_family='information_quantity',
        invariant='상대가 이미 아는 걸 길게 설명했다',
        core=dict(target_skill='PRODUCE',
                  required_inference='상대가 무엇을 아는지 짐작하기',
                  perspective_structure='상대의 지식 상태 1층',
                  decidable_by_evidence='YES', direct_check_allowed='YES'),
        base=dict(relationship_type='TEAMMATE', situation_type='SCHOOL_GROUP',
                  misread_cost='LOW', recoverable=True),
        scene=(
            '조별과제 첫 회의. 같은 조 사람이 자료를 정리해 왔다.\n\n'
            '나 "그럼 제가 설문 부분 설명드릴게요. 설문은 크게 세 단계로 나뉘는데요, '
            '먼저 문항을 설계하고, 그다음에 배포를 하고, 마지막에 응답을 정리합니다."\n'
            '조원 "네."\n'
            '나 "문항 설계할 때는 답이 한쪽으로 쏠리지 않게 해야 하고요, 배포는 요즘 보통 온라인으로 하죠. '
            '응답 정리는 엑셀로 하면 되는데 코딩을 미리 정해 두면 편합니다."\n'
            '조원 "아 네." (노트북 화면을 잠깐 보다가) "저 지난 학기에 설문 조사 수업 들었어요."\n'
            '나 "아 그러셨구나. 그럼 배포는 어떻게 할지 정할까요?"'),
    ),
    # ── 새 S2 · 관계 · 상황 맞춤 조정 ──
    dict(
        anchor_id='A2a', scope_skill='S2', seed_origin='skill_family_seeds.json#S10',
        skill_family='listener_relationship_adaptation',
        invariant='부담 주지 않으면서 부탁해야 했다',
        core=dict(target_skill='PRODUCE',
                  required_inference='부담의 크기를 가늠해 표현 수위 정하기',
                  perspective_structure='상대가 나를 어떻게 봤을지 2층',
                  decidable_by_evidence='YES', direct_check_allowed='NO'),
        base=dict(relationship_type='CLUB_SENIOR', situation_type='CLUB',
                  misread_cost='LOW', recoverable=True),
        scene=(
            '동아리 공연 준비 중이다. 선배가 장비를 잘 다루는데, 나는 이번 주에 도움이 필요하다.\n\n'
            '나 "선배 혹시 이번 주 금요일에 시간 어떠세요?"\n'
            '선배 "금요일? 왜, 무슨 일 있어?"\n'
            '나 "아 그... 음향 세팅을 해야 하는데 제가 아직 잘 몰라서요."\n'
            '선배 "아 그거." (핸드폰 달력을 열어 본다) "금요일이 좀 애매하긴 한데."\n'
            '나 "..."\n'
            '선배 "몇 시쯤 생각했는데?"'),
    ),
    dict(
        anchor_id='A2b', scope_skill='S2',
        seed_origin='없음 · 이 core 의 씨앗이 하나뿐이라 같은 core 로 새로 씀',
        skill_family='listener_relationship_adaptation',
        invariant='부담 주지 않으면서 부탁해야 했다',
        core=dict(target_skill='PRODUCE',
                  required_inference='부담의 크기를 가늠해 표현 수위 정하기',
                  perspective_structure='상대가 나를 어떻게 봤을지 2층',
                  decidable_by_evidence='YES', direct_check_allowed='NO'),
        base=dict(relationship_type='DORM_SENIOR', situation_type='DORM',
                  misread_cost='LOW', recoverable=True),
        scene=(
            '기숙사 룸메이트는 나보다 두 학번 위다. 밤에 통화를 자주 하는데 나는 요즘 잠을 잘 못 잔다.\n\n'
            '나 "형, 혹시 요즘 많이 바쁘세요?"\n'
            '룸메 "어? 왜, 나 요즘 과제 때문에 좀."\n'
            '나 "아 그러시구나. 늦게까지 하시더라고요."\n'
            '룸메 "어 미안, 시끄러웠나?"\n'
            '나 "아니요 그런 건 아니고요." (잠깐 멈추고) "그냥 요즘 어떠신가 해서요."\n'
            '룸메 "아 그래? 뭐 별거 없어."'),
    ),
    # ── 새 S3 · 대화 속 함축 · 비문자 의미 이해 ──
    dict(
        anchor_id='A3a', scope_skill='S3', seed_origin='skill_family_seeds.json#S1',
        skill_family='indirect_meaning',
        invariant='상대가 껄끄러운 말을 돌려서 했다',
        core=dict(target_skill='RECOGNIZE',
                  required_inference='말하지 않은 부분을 맥락으로 채우기',
                  perspective_structure='상대의 의도 1층',
                  decidable_by_evidence='YES', direct_check_allowed='YES'),
        base=dict(relationship_type='FRIEND_CASUAL', situation_type='FRIEND_PRIVATE',
                  misread_cost='LOW', recoverable=True),
        scene=(
            '친구한테 주말에 같이 여행 가자고 물어봤다.\n\n'
            '나 "이번 주말에 바다 갈래? 차 빌려서 가면 될 것 같은데."\n'
            '친구 "오 좋지." (잠깐) "근데 이번 주말이 좀..."\n'
            '나 "왜, 뭐 있어?"\n'
            '친구 "아니 그런 건 아닌데, 요즘 좀 그래서."\n'
            '나 "그럼 다음 주로 미룰까?"\n'
            '친구 "음... 다음 주도 봐야 알 것 같아."'),
    ),
    dict(
        anchor_id='A3b', scope_skill='S3', seed_origin='skill_family_seeds.json#S3',
        skill_family='indirect_meaning',
        invariant='대답이 없는 것 자체가 대답이었다',
        core=dict(target_skill='RECOGNIZE',
                  required_inference='부재를 신호로 읽기',
                  perspective_structure='상대의 의도 1층',
                  decidable_by_evidence='NO', direct_check_allowed='YES'),
        base=dict(relationship_type='FRIEND_CASUAL', situation_type='FRIEND_PRIVATE',
                  misread_cost='LOW', recoverable=True),
        scene=(
            '친구 넷이 있는 단톡방에 내가 제안을 올렸다.\n\n'
            '나 "이번 달에 다 같이 1박으로 어디 갔다 오는 거 어때? 날짜는 맞춰볼게"\n'
            '(30분 뒤)\n'
            'A "오 좋다"\n'
            '(다음 날 저녁)\n'
            '나 "그럼 날짜 투표 올린다?"\n'
            '(아무 답 없음. B 와 C 는 읽었다)\n'
            '나 "일단 올려볼게"'),
    ),
]

# ─────────────────────────────────────────────────────────────
# 변형 열둘. 등급 정의는 variation_plan.py 를 그대로 따른다.
# surface_axes 는 손으로 적는다. 화제 · 장소 · 사람은 ctx 에 없어서 diff 로 못 뽑는다.
# 관계 · 상황 · 대가 · 회복은 **적지 않는다.** ctx 를 비교해 기계가 뽑는다.
#   앞 판에서 손으로 적었다가 네 곳이 어긋났다. check_scenes.py 가 잡았다.
# ─────────────────────────────────────────────────────────────

VARIANTS = [
    # ── A1a ──
    dict(anchor_id='A1a', grade='SAME_CONTEXT',
         surface_axes=['topic', 'place'],
         ctx=dict(relationship_type='FRIEND_CASUAL', situation_type='FRIEND_PRIVATE',
                  misread_cost='LOW', recoverable=True),
         attempt=1, regenerated=False, warning='',
         scene=(
             '카페에서 친구를 만났다. 요즘 배우는 것 이야기가 나왔다.\n\n'
             '친구 "요즘 뭐 배운다며?"\n'
             '나 "응 그거 배우는데 생각보다 어렵더라. 3단이 안 넘어가."\n'
             '친구 "3단?"\n'
             '나 "응 거기서 다들 막힌대. 나도 두 달째야."\n'
             '친구 "아..." (음료를 한 모금 마신다) "그렇구나."\n'
             '나 "너도 한번 해볼래?"')),
    dict(anchor_id='A1a', grade='NEAR',
         surface_axes=[],
         ctx=dict(relationship_type='TEAMMATE', situation_type='FRIEND_PRIVATE',
                  misread_cost='LOW', recoverable=True),
         attempt=2, regenerated=True,
         warning='1차 초안은 상황 설명에 "같은 조원은 아직 배경을 모른다" 를 적어 답을 알려 줬다. 지우고 다시 씀',
         scene=(
             '같은 조 사람과 과제 끝나고 밥을 먹으러 갔다. 내가 따로 하는 일 이야기가 나왔다.\n\n'
             '조원 "따로 뭐 하시는 거 있다고 들었어요."\n'
             '나 "아 네 그 대회 준비하고 있어요. 지난달에 예선 떨어져서 다시 준비 중이에요."\n'
             '조원 "대회요?"\n'
             '나 "네 그거요. 작년에도 나갔었는데 그때는 팀이 달라서."\n'
             '조원 "아 네." (수저를 든다) "고생하시겠네요."\n'
             '나 "뭐 재밌어서 하는 거죠."')),
    dict(anchor_id='A1a', grade='FAR',
         surface_axes=[],
         ctx=dict(relationship_type='INTERN_SUPERVISOR', situation_type='WORK',
                  misread_cost='HIGH', recoverable=False),
         attempt=1, regenerated=False,
         warning='FAR 에서 회복 가능성을 false 로 둔 근거가 약하다. 회의가 한 번뿐이라는 설정에 기댔다',
         scene=(
             '인턴 첫 주. 다른 팀 팀장님이 우리 팀 일을 처음 듣는 자리다. 이 자리에서 결정이 난다고 들었다.\n\n'
             '팀장 "그래서 이번 건은 어떻게 진행되고 있죠?"\n'
             '나 "네 저희가 지난번에 나온 피드백 반영해서 2안으로 가고 있습니다. '
             '1안은 리소스 문제로 접었고요."\n'
             '팀장 "피드백이라면?"\n'
             '나 "아 그 회의 때 나온 거요. 그때 방향을 바꾸기로 했어서."\n'
             '팀장 "..." (자료를 넘겨 본다) "제가 그 회의에는 없었네요."\n'
             '나 "아 네."\n'
             '팀장 "그럼 2안이 뭔지부터 들을까요."')),
    # ── A1b ──
    dict(anchor_id='A1b', grade='SAME_CONTEXT',
         surface_axes=['topic'],
         ctx=dict(relationship_type='TEAMMATE', situation_type='SCHOOL_GROUP',
                  misread_cost='LOW', recoverable=True),
         attempt=1, regenerated=False, warning='',
         scene=(
             '팀 프로젝트 회의에서 발표 자료 만드는 방법 이야기가 나왔다.\n\n'
             '나 "발표 자료는 순서가 중요해요. 보통 문제 제기를 먼저 하고, 그다음에 방법, '
             '마지막에 결과를 넣습니다."\n'
             '조원 "네."\n'
             '나 "문제 제기가 약하면 뒤가 다 흔들려요. 그리고 방법 부분은 너무 길면 지루해지니까 '
             '그림으로 넣는 게 낫고요. 결과는 숫자를 크게 보여주는 게 좋습니다."\n'
             '조원 "네 알겠습니다." (노트북에 이미 만들어 둔 목차를 띄운다)\n'
             '나 "아 만들어 오셨네요."')),
    dict(anchor_id='A1b', grade='NEAR',
         surface_axes=[],
         ctx=dict(relationship_type='TEAMMATE', situation_type='PART_TIME',
                  misread_cost='LOW', recoverable=True),
         attempt=1, regenerated=False, warning='',
         scene=(
             '카페 아르바이트. 오늘 새로 온 사람과 같이 마감을 한다.\n\n'
             '나 "마감은 순서가 있어요. 먼저 기계 청소하고, 그다음에 재료 정리하고, '
             '마지막에 바닥이에요."\n'
             '동료 "네."\n'
             '나 "기계는 이 버튼 누르면 물이 나오는데 그거 다 빠질 때까지 기다려야 해요. '
             '재료는 유통기한 앞에 있는 것부터 빼고요. 바닥은 의자 올리고 닦아요."\n'
             '동료 "네." (이미 기계 버튼을 눌러 두고 재료 칸을 열고 있다)\n'
             '나 "어 해보셨어요?"\n'
             '동료 "저 옆 지점에서 두 달 했어요."')),
    dict(anchor_id='A1b', grade='FAR',
         surface_axes=[],
         ctx=dict(relationship_type='CLIENT', situation_type='WORK',
                  misread_cost='HIGH', recoverable=True),
         attempt=2, regenerated=True,
         warning='1차는 면접 장면이었는데 "설명을 길게 한다" 가 면접에서는 자연스러워 등급 구분이 흐려졌다. 거래처 미팅으로 바꿈',
         scene=(
             '회사 대표로 처음 나간 미팅. 상대 회사에서 세 분이 나왔다.\n\n'
             '나 "저희 쪽 방식부터 말씀드리면, 저희는 우선 요구사항을 받고, 그걸 정리해서 '
             '다시 확인을 받고, 그다음에 착수합니다."\n'
             '상대 "네."\n'
             '나 "요구사항 받을 때는 서면으로 받는 게 원칙이고요, 확인 단계에서 한 번 더 '
             '조율하는 게 보통입니다. 착수하면 주 단위로 보고를 드리고요."\n'
             '상대 "..." (옆 사람과 눈을 마주친다) "저희가 작년에도 같은 방식으로 한 번 했었죠."\n'
             '나 "아 그러셨나요."\n'
             '상대 "그때 담당이 저였습니다."')),
    # ── A2a ──
    dict(anchor_id='A2a', grade='SAME_CONTEXT',
         surface_axes=['topic', 'place'],
         ctx=dict(relationship_type='CLUB_SENIOR', situation_type='CLUB',
                  misread_cost='LOW', recoverable=True),
         attempt=1, regenerated=False, warning='',
         scene=(
             '동아리에서 다음 달 전시를 준비한다. 선배가 인쇄 쪽을 잘 안다.\n\n'
             '나 "선배, 혹시 인쇄소 아시는 데 있으세요?"\n'
             '선배 "인쇄소? 왜, 뭐 뽑아야 돼?"\n'
             '나 "아 네 포스터를 좀 뽑아야 하는데 어디가 괜찮은지를 몰라서요."\n'
             '선배 "음 내가 쓰던 데가 있긴 한데." (잠깐 생각한다) "지금은 연락처가 어디 있나."\n'
             '나 "아 바쁘시면 괜찮아요."\n'
             '선배 "아니 찾아볼게. 언제까지 필요한데?"')),
    dict(anchor_id='A2a', grade='NEAR',
         surface_axes=[],
         ctx=dict(relationship_type='PART_TIME_MANAGER', situation_type='PART_TIME',
                  misread_cost='LOW', recoverable=True),
         attempt=1, regenerated=False,
         warning='관계를 바꾸면서도 direct_check_allowed 가 NO 로 유지되는 상대를 골라야 해서 점장으로 했다. '
                 '또래로 바꾸면 Core 가 달라져 NEAR 가 아니게 된다',
         scene=(
             '아르바이트하는 가게. 다음 주에 시험이 있어서 근무를 빼고 싶다.\n\n'
             '나 "점장님 혹시 다음 주 스케줄 나왔나요?"\n'
             '점장 "다음 주? 아직 짜는 중인데, 왜?"\n'
             '나 "아 그냥 여쭤봤어요." (잠깐) "다음 주에 시험이 좀 있어서요."\n'
             '점장 "아 시험." (스케줄 표를 본다) "며칠인데?"\n'
             '나 "수요일이랑 금요일이요. 근데 사람 없으면 나올 수 있어요."\n'
             '점장 "일단 볼게."')),
    dict(anchor_id='A2a', grade='FAR',
         surface_axes=[],
         ctx=dict(relationship_type='TEAM_LEAD', situation_type='WORK',
                  misread_cost='HIGH', recoverable=True),
         attempt=3, regenerated=True,
         warning='1차와 2차는 부탁이 너무 커서(휴직 · 프로젝트 이관) 상황 자체가 부자연스러웠다. '
                 '"마감을 하루 미뤄 달라" 로 낮췄다. 그래도 FAR 중 가장 억지스럽다고 본다',
         scene=(
             '입사 두 달째. 이번 건은 팀장님이 직접 챙기는 일이고 내일이 마감이다. '
             '나는 하루가 더 필요하다.\n\n'
             '나 "팀장님 지금 잠깐 시간 괜찮으실까요?"\n'
             '팀장 "네 말씀하세요."\n'
             '나 "내일 드리기로 한 거 말인데요." (잠깐) "지금 상태로 드리면 확인하실 게 좀 많을 것 같아서요."\n'
             '팀장 "..." (모니터에서 눈을 뗀다) "어느 정도 됐는데요?"\n'
             '나 "뼈대는 다 됐고 숫자 검증이 남았습니다."\n'
             '팀장 "내일 오전까지는 되고요?"\n'
             '나 "오전은 어렵고 오후면 확실합니다."')),
    # ── A2b ──
    dict(anchor_id='A2b', grade='SAME_CONTEXT',
         surface_axes=['topic'],
         ctx=dict(relationship_type='DORM_SENIOR', situation_type='DORM',
                  misread_cost='LOW', recoverable=True),
         attempt=1, regenerated=False, warning='',
         scene=(
             '룸메이트 형이 친구들을 방에 자주 부른다. 나는 다음 주에 시험이 있다.\n\n'
             '나 "형 다음 주에 혹시 약속 있으세요?"\n'
             '룸메 "다음 주? 왜?"\n'
             '나 "아 그냥요. 저 다음 주에 시험이 좀 몰려 있어서."\n'
             '룸메 "아 맞다 너 시험 기간이지." (잠깐) "왜, 애들 오면 시끄러워?"\n'
             '나 "아니요 그런 건 아니고요."\n'
             '룸메 "말해도 돼. 조절할게."')),
    dict(anchor_id='A2b', grade='NEAR',
         surface_axes=[],
         ctx=dict(relationship_type='DORM_SENIOR', situation_type='CLUB',
                  misread_cost='LOW', recoverable=True),
         attempt=3, regenerated=True,
         warning='1차는 관계와 상황을 같이 바꿔 FAR 에 가까워졌다. 관계를 그대로 두고 상황만 바꿈. '
                 '3차는 점검 중에 고쳤다 · 지문은 "동아리 선배인 형" 이라고만 하는데 화자는 '
                 '"룸메" 라 같은 사람인지 안 읽혔다. 지문에 룸메이트를 다시 넣었다',
         scene=(
             '룸메이트 형과 같은 동아리다. 이번 행사 준비를 같이 하는데 '
             '형이 맡은 부분이 늦어지고 있다.\n\n'
             '나 "형 준비 어떻게 되고 있어요?"\n'
             '룸메 "어 나 이번 주에 좀 바빠서 아직."\n'
             '나 "아 네." (잠깐) "제가 뭐 도와드릴 거 있을까요?"\n'
             '룸메 "아니야 내가 할게."\n'
             '나 "그... 다음 주 초에 한번 맞춰보면 좋을 것 같은데 어떠세요?"\n'
             '룸메 "그래 그때 보자."')),
    dict(anchor_id='A2b', grade='FAR',
         surface_axes=[],
         ctx=dict(relationship_type='PROFESSOR', situation_type='SCHOOL_OFFICIAL',
                  misread_cost='HIGH', recoverable=False),
         attempt=1, regenerated=False,
         warning='회복 불가로 둔 근거는 "마감이 지나면 정정이 안 된다" 는 설정이다. 학교마다 다를 수 있다',
         scene=(
             '졸업 요건 서류에 교수님 확인이 필요하다. 제출 마감이 오늘까지고 '
             '지나면 다음 학기로 밀린다고 들었다.\n\n'
             '나 "교수님 안녕하세요. 혹시 지금 잠깐 시간 괜찮으실까요?"\n'
             '교수 "지금? 곧 회의 들어가야 하는데."\n'
             '나 "아 네 그럼 나중에..." (잠깐) "저 서류에 확인을 좀 받아야 해서요."\n'
             '교수 "서류? 언제까지인데."\n'
             '나 "오늘까지입니다."\n'
             '교수 "..." (시계를 본다) "지금 뭐 들고 왔어요?"\n'
             '나 "네 여기 있습니다."')),
    # ── A3a ──
    dict(anchor_id='A3a', grade='SAME_CONTEXT',
         surface_axes=['topic', 'place'],
         ctx=dict(relationship_type='FRIEND_CASUAL', situation_type='FRIEND_PRIVATE',
                  misread_cost='LOW', recoverable=True),
         attempt=1, regenerated=False, warning='',
         scene=(
             '친구한테 같이 운동 등록하자고 했다.\n\n'
             '나 "너 그 헬스장 같이 다닐래? 둘이 등록하면 싸대."\n'
             '친구 "아 그거." (잠깐) "요즘 내가 좀 그래서."\n'
             '나 "왜, 시간 안 돼?"\n'
             '친구 "시간이 문제는 아닌데."\n'
             '나 "그럼 다음 달부터 할까?"\n'
             '친구 "음 다음 달은 또 어떻게 될지 모르겠다."')),
    dict(anchor_id='A3a', grade='NEAR',
         surface_axes=[],
         ctx=dict(relationship_type='CLUB_SENIOR', situation_type='FRIEND_PRIVATE',
                  misread_cost='LOW', recoverable=True),
         attempt=1, regenerated=False, warning='',
         scene=(
             '동아리 선배한테 다음 학기 스터디를 같이 하자고 물었다.\n\n'
             '나 "선배 다음 학기에 스터디 같이 하실래요? 주에 한 번만 하려고요."\n'
             '선배 "오 좋네." (잠깐) "근데 내가 다음 학기에 좀..."\n'
             '나 "많이 바쁘세요?"\n'
             '선배 "바쁘다기보다는, 뭐 어떻게 될지 몰라서."\n'
             '나 "그럼 일단 명단에 넣어 둘까요?"\n'
             '선배 "음 일단은 빼고 시작해."')),
    dict(anchor_id='A3a', grade='FAR',
         surface_axes=[],
         ctx=dict(relationship_type='INTERN_SUPERVISOR', situation_type='WORK',
                  misread_cost='HIGH', recoverable=True),
         attempt=1, regenerated=False, warning='',
         scene=(
             '인턴 중간에 사수에게 정규직 전환 이야기를 꺼냈다.\n\n'
             '나 "사수님 혹시 전환 관련해서 여쭤봐도 될까요?"\n'
             '사수 "아 그거." (키보드에서 손을 뗀다) "왜, 들은 거 있어요?"\n'
             '나 "아니요 그냥 제가 준비할 게 있나 해서요."\n'
             '사수 "음 뭐 지금 하는 것만 잘하면 되죠." (잠깐) "근데 올해는 자리가 어떻게 될지 '
             '위에서도 아직."\n'
             '나 "아 네."\n'
             '사수 "일단 하던 거 마무리부터 합시다."')),
    # ── A3b ──
    dict(anchor_id='A3b', grade='SAME_CONTEXT',
         surface_axes=['topic', 'participants'],
         ctx=dict(relationship_type='FRIEND_CASUAL', situation_type='FRIEND_PRIVATE',
                  misread_cost='LOW', recoverable=True),
         attempt=1, regenerated=False, warning='',
         scene=(
             '고등학교 친구들 단톡방에 내가 모임 이야기를 꺼냈다.\n\n'
             '나 "이번에 다 같이 한번 보자 언제가 괜찮아?"\n'
             '(한 시간 뒤)\n'
             'A "좋지 근데 나 요즘 일이 좀"\n'
             '(그날 밤)\n'
             '나 "그럼 날짜 몇 개 올려볼게"\n'
             '(다음 날까지 답 없음. 읽은 사람은 셋)\n'
             '나 "다들 바쁜가보다 나중에 다시 얘기하자"')),
    dict(anchor_id='A3b', grade='NEAR',
         surface_axes=[],
         ctx=dict(relationship_type='FRIEND_CASUAL', situation_type='PART_TIME',
                  misread_cost='LOW', recoverable=True),
         attempt=2, regenerated=True,
         warning='1차는 답이 없는 이유를 장면이 설명해 버렸다("다들 시험 기간이었다"). 지움',
         scene=(
             '아르바이트하는 곳 단톡방. 같이 일하는 또래들끼리 쓰는 방이다.\n\n'
             '나 "다음 주 토요일에 누가 저랑 근무 바꿔주실 수 있나요"\n'
             '(두 시간 뒤)\n'
             'A "저는 그날 이미 근무라서요ㅠ"\n'
             '나 "아 넵 혹시 다른 분들 중에 가능하신 분 계실까요"\n'
             '(다음 날 오전까지 답 없음. 읽음 표시는 넷)\n'
             '나 "일단 점장님께 여쭤볼게요"')),
    dict(anchor_id='A3b', grade='FAR',
         surface_axes=[],
         ctx=dict(relationship_type='CROSS_TEAM', situation_type='WORK',
                  misread_cost='HIGH', recoverable=True),
         attempt=1, regenerated=False,
         warning='메일 장면이라 턴이 대화보다 느슨하다. 대화체가 아니어서 다른 장면과 결이 다르다',
         scene=(
             '다른 팀에 협조를 요청하는 메일을 보냈다. 이번 주 안에 답이 와야 일정이 맞는다.\n\n'
             '나 (메일) "안녕하세요. 지난번 말씀드린 건으로 자료 공유 가능하실지 여쭙습니다. '
             '이번 주 중으로 회신 주시면 감사하겠습니다."\n'
             '(이틀 뒤, 답 없음)\n'
             '나 (메일) "안녕하세요. 아래 건 확인 부탁드립니다."\n'
             '(다음 날, 참조에 있던 다른 분이 짧게 회신) "담당자가 이번 주 휴가입니다."\n'
             '나 (메일) "아 네 알겠습니다. 복귀하시면 다시 여쭙겠습니다."\n'
             '(그 뒤로 회신 없음)')),
]


CTX_AXES = ('relationship_type', 'situation_type', 'misread_cost', 'recoverable')


def changed_axes(base, ctx, surface):
    """무엇이 바뀌었나. 맥락 축은 손으로 적지 않고 두 dict 를 비교해 뽑는다."""
    return sorted(surface) + [k for k in CTX_AXES if base.get(k) != ctx.get(k)]


def main():
    by_anchor = {a['anchor_id']: a for a in ANCHORS}
    rows, n = [], 0
    for a in ANCHORS:
        for v in VARIANTS:
            if v['anchor_id'] != a['anchor_id']:
                continue
            n += 1
            rows.append({
                'item_id': 'M%02d' % n,
                'anchor_id': a['anchor_id'],
                'scope_skill': a['scope_skill'],
                'skill_family': a['skill_family'],
                'seed_origin': a['seed_origin'],
                'invariant_sentence': a['invariant'],
                'core': a['core'],
                'anchor_context': a['base'],
                'anchor_scene': a['scene'],
                'intended_distance': v['grade'],
                'variant_context': v['ctx'],
                'planned_changed_axes': changed_axes(a['base'], v['ctx'],
                                                    v['surface_axes']),
                'surface_axes': v['surface_axes'],
                'generated_scene': v['scene'],
                'attempt_number': v['attempt'],
                'regenerated': v['regenerated'],
                'generation_warning': v['warning'],
                'generated_by': 'HUMAN_AUTHORED_BY_SPEC_SESSION',
                'NOT_A_VALIDATION_RESULT': 'DEVELOPER MANUAL SANITY CHECK',
            })
    with io.open(OUT, 'w', encoding='utf-8', newline='\n') as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + '\n')

    import collections
    print('장면 %d · 앵커 %d' % (len(rows), len(ANCHORS)))
    print('  skill ·', dict(collections.Counter(r['scope_skill'] for r in rows)))
    print('  등급 ·', dict(collections.Counter(r['intended_distance'] for r in rows)))
    print('  재생성 ·', sum(1 for r in rows if r['regenerated']))
    print('  경고 있는 항목 ·', sum(1 for r in rows if r['generation_warning']))
    print('  저장 ·', os.path.basename(OUT))
    return 0


if __name__ == '__main__':
    sys.exit(main())
