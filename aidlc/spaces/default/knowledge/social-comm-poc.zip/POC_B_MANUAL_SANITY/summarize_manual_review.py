# -*- coding: utf-8 -*-
"""사람이 채운 답을 열쇠와 맞춰 본다.

    python summarize_manual_review.py
    python summarize_manual_review.py --responses 다른파일.csv

  이것은 **개발자 수동 점검**이다. 성능도 검증도 아니다.
  열여덟 항목을 한 사람이 본 것이라 신뢰구간을 붙이지 않는다. 세는 것까지만 한다.

읽는 법
  자연스러움     1~5 평균. 낮으면 생성기가 억지 상황을 만든다
  맥락 충분      무슨 일인지 알 만한가. 낮으면 장면이 짧거나 설명이 빠졌다
  같은 능력      의도한 기술이 보존됐다고 보는가. 낮으면 변형이 Core 를 깨뜨렸다
  거리 일치      의도한 등급과 사람이 느낀 등급이 같은가
  답 노출        글이 어떻게 하라고 알려 주는가. **하나라도 YES 면 고쳐야 한다**

거리 일치를 볼 때
  맞은 개수만 보지 않는다. **어느 쪽으로 틀렸는지**가 더 쓸모 있다.
  FAR 로 만들었는데 NEAR 로 읽혔다면 변형이 약한 것이고,
  SAME_CONTEXT 로 만들었는데 NEAR 로 읽혔다면 표면만 바꾼다고 한 것이 실제로는 더 바꾼 것이다.
"""
from __future__ import annotations

import argparse
import collections
import csv
import io
import os
import sys
import unicodedata

sys.path.insert(0, HERE_BOOT := os.path.dirname(os.path.abspath(__file__)))
from build_review import RESPONSE_COLS  # noqa: E402  칸 이름은 저기서만 정한다

HERE = os.path.dirname(os.path.abspath(__file__))
KEY = os.path.join(HERE, 'MANUAL_REVIEW_KEY.csv')
RESP = os.path.join(HERE, 'manual_review_responses.csv')

GRADES = ('SAME_CONTEXT', 'NEAR', 'FAR')
GRADE_KO = {'SAME_CONTEXT': '같은 맥락', 'NEAR': '가까움', 'FAR': '멂', 'UNSURE': '모르겠다'}
SKILL_KO = {'S1': '청자 맞춤 정보 조절', 'S2': '관계 · 상황 맞춤 조정', 'S3': '함축 이해'}
ORDER = {'SAME_CONTEXT': 0, 'NEAR': 1, 'FAR': 2}

BANNER = 'DEVELOPER MANUAL SANITY CHECK · NOT A VALIDATION RESULT'


def read(path, what):
    if not os.path.exists(path):
        return None, '%s 가 없다 · %s' % (what, path)
    rows = list(csv.DictReader(io.open(path, encoding='utf-8-sig', newline='')))
    if not rows:
        return None, '%s 가 비었다 · %s' % (what, path)
    return rows, ''


def wide(t):
    """화면에서 차지하는 칸 수. 한글은 두 칸이다."""
    return sum(2 if unicodedata.east_asian_width(c) in 'WF' else 1 for c in t)


def pad(t, n):
    """한글 섞인 칸 맞추기. %-22s 는 글자를 세서 한글 표가 어긋난다."""
    return t + ' ' * max(0, n - wide(t))


def rpad(t, n):
    return ' ' * max(0, n - wide(t)) + t


def pct(a, b):
    return '%5.1f%% (%d/%d)' % (100.0 * a / b, a, b) if b else '   -   (0/0)'


def bar(x, lo=1.0, hi=5.0, w=18):
    n = int(round((x - lo) / (hi - lo) * w)) if hi > lo else 0
    return '█' * max(0, min(w, n)) + '·' * (w - max(0, min(w, n)))


def seed_tag(origin):
    """씨앗 표시는 id 까지만. 파일 경로를 그대로 쓰면 표가 밀린다."""
    if not origin or '#' not in origin:
        return '씨앗 없음'   # A2b 는 이 칸에 왜 없는지 설명이 들어 있다. 표에는 안 펼친다
    return '씨앗 ' + origin.rsplit('#', 1)[-1]


def group(rows, keyfn):
    out = collections.OrderedDict()
    for r in rows:
        out.setdefault(keyfn(r), []).append(r)
    return out


def block(title, buckets, merged):
    """한 묶음 기준으로 다섯 지표를 낸다."""
    print()
    print(title)
    print('  %s %4s  %s %s %s %s %s'
          % (pad('', 26), '수', pad('자연스러움', 25), pad('맥락 충분', 14),
             pad('같은 능력', 14), pad('거리 일치', 14), '답 노출'))
    for k, rs in buckets.items():
        n = len(rs)
        nat = [float(r['q1_naturalness']) for r in rs if r['q1_naturalness']]
        m = sum(nat) / len(nat) if nat else 0.0
        ctx = sum(1 for r in rs if r['q2_context_sufficient'] == 'YES')
        same = sum(1 for r in rs if r['q3_same_ability'] == 'SAME')
        hit = sum(1 for r in rs if r['q4_distance'] == r['intended_distance'])
        leak = sum(1 for r in rs if r['q5_answer_leak'] == 'YES')
        print('  %s %4d  %.2f %s %s %s %s %s'
              % (pad(k, 26), n, m, bar(m) if nat else ' ' * 18,
                 pct(ctx, n), pct(same, n), pct(hit, n), pct(leak, n)))
    _ = merged
    return


def fails(rows):
    """고쳐야 할 항목. 기준은 하나씩 적어 둔다."""
    out = []
    for r in rows:
        why = []
        if r['q5_answer_leak'] == 'YES':
            why.append('답을 알려 준다')
        if r['q1_naturalness'] and float(r['q1_naturalness']) <= 2:
            why.append('억지 상황 (%s점)' % r['q1_naturalness'])
        if r['q2_context_sufficient'] == 'NO':
            why.append('설명 부족')
        if r['q3_same_ability'] == 'DIFFERENT':
            why.append('다른 능력을 요구한다')
        if r['q4_distance'] not in ('', 'UNSURE') and r['q4_distance'] != r['intended_distance']:
            a, b = r['intended_distance'], r['q4_distance']
            d = ORDER.get(b, -1) - ORDER.get(a, -1)
            way = '더 멀게 읽혔다' if d > 0 else '더 가깝게 읽혔다'
            why.append('%s 로 만들었는데 %s 로 읽혔다 · %s'
                       % (GRADE_KO.get(a, a), GRADE_KO.get(b, b), way))
        if why:
            out.append((r, why))
    return out


def drift(rows):
    """의도 등급 x 읽힌 등급. 어느 쪽으로 쏠렸는지 본다."""
    print()
    print('의도한 거리 · 사람이 읽은 거리')
    cols = GRADES + ('UNSURE', '')
    print('  %s %s' % (pad('의도 \\ 읽힘', 12),
                       ' '.join(rpad(GRADE_KO.get(c, '미응답'), 10) for c in cols)))
    for g in GRADES:
        rs = [r for r in rows if r['intended_distance'] == g]
        cnt = collections.Counter(r['q4_distance'] for r in rs)
        cells = []
        for c in cols:
            n = cnt.get(c, 0)
            cells.append('%10s' % (('[%d]' % n) if c == g and n else (str(n) if n else '·')))
        print('  %s %s' % (pad(GRADE_KO[g], 12), ' '.join(cells)))
    print('  대괄호가 의도와 읽힘이 맞은 칸이다')


def main(argv):
    ap = argparse.ArgumentParser()
    ap.add_argument('--responses', default=RESP)
    ap.add_argument('--key', default=KEY)
    a = ap.parse_args(argv)

    key, err = read(a.key, '열쇠')
    if err:
        print(err)
        return 2
    resp, err = read(a.responses, '응답')
    if err:
        print(err)
        print()
        print('MANUAL_REVIEW.html 을 크롬으로 열어 다 채운 뒤')
        print('아래쪽 "CSV 내려받기" 로 manual_review_responses.csv 를 이 폴더에 둔다')
        return 2

    got = tuple(resp[0].keys())
    if got != RESPONSE_COLS:
        print('응답 CSV 의 칸 이름이 다르다')
        print('  기대 · %s' % ', '.join(RESPONSE_COLS))
        print('  실제 · %s' % ', '.join(got))
        print('  MANUAL_REVIEW.html 을 다시 만들었는지, 다른 파일을 준 것은 아닌지 본다')
        return 2

    kmap = {r['display_id']: r for r in key}
    rows, orphan = [], []
    for r in resp:
        k = kmap.get(r.get('display_id', ''))
        if k is None:
            orphan.append(r.get('display_id', '?'))
            continue
        rows.append(dict(r, **k))

    print('=' * 78)
    print(BANNER)
    print('=' * 78)
    print('열쇠 %d · 응답 %d · 맞춘 것 %d' % (len(key), len(resp), len(rows)))
    if orphan:
        print('  열쇠에 없는 응답 %d개 · %s' % (len(orphan), ', '.join(orphan[:8])))
    missing = [d for d in kmap if d not in {r['display_id'] for r in rows}]
    if missing:
        print('  응답이 없는 항목 %d개 · %s' % (len(missing), ', '.join(sorted(missing))))

    blank = [r['display_id'] for r in rows
             if not all(r.get(q) for q in ('q1_naturalness', 'q2_context_sufficient',
                                           'q3_same_ability', 'q4_distance',
                                           'q5_answer_leak'))]
    if blank:
        print('  덜 채운 항목 %d개 · %s' % (len(blank), ', '.join(sorted(blank))))
        print('  **덜 채운 것을 0 으로 세지 않는다.** 아래 비율의 분모에는 들어간다')

    if not rows:
        print()
        print('맞는 항목이 없다. display_id 가 서로 다른 파일이 아닌지 본다')
        return 2

    block('전체', collections.OrderedDict([('모두', rows)]), rows)
    block('기술별', group(sorted(rows, key=lambda r: r['scope_skill']),
                        lambda r: '%s %s' % (r['scope_skill'],
                                             SKILL_KO.get(r['scope_skill'], ''))), rows)
    block('거리별', group(sorted(rows, key=lambda r: ORDER.get(r['intended_distance'], 9)),
                        lambda r: GRADE_KO.get(r['intended_distance'],
                                               r['intended_distance'])), rows)
    block('앵커별', group(sorted(rows, key=lambda r: r['anchor_id']),
                        lambda r: '%s (%s)' % (r['anchor_id'],
                                               seed_tag(r['seed_origin']))), rows)
    block('다시 만든 것인가', group(sorted(rows, key=lambda r: r['regenerated']),
                             lambda r: '다시 만듦' if r['regenerated'] == 'YES'
                             else '한 번에 나옴'), rows)

    drift(rows)

    bad = fails(rows)
    print()
    print('고쳐야 할 항목 %d / %d' % (len(bad), len(rows)))
    for r, why in sorted(bad, key=lambda x: -len(x[1])):
        print('  %s  %s %s  %s'
              % (r['display_id'], r['scope_skill'],
                 pad(GRADE_KO.get(r['intended_distance'], ''), 10), ' · '.join(why)))
        if r['generation_warning']:
            print('      만들 때 적어 둔 것 · %s' % r['generation_warning'])
        if r['memo']:
            print('      메모 · %s' % r['memo'])

    leak = [r for r in rows if r['q5_answer_leak'] == 'YES']
    print()
    print('=' * 78)
    if leak:
        print('판정 · **답 노출 %d건.** 이것부터 고친다. 다른 수치는 그 다음이다' % len(leak))
    elif len(bad) > len(rows) // 3:
        print('판정 · 항목 셋 중 하나 넘게 걸린다. 생성 규칙을 손봐야 한다')
    elif bad:
        print('판정 · 걸린 %d건만 다시 만들면 된다' % len(bad))
    else:
        print('판정 · 눈으로 본 한 걸리는 것이 없다')
    print('이 줄들은 %s 다. 사람 대상 검증 결과가 아니다.' % BANNER)
    print('=' * 78)
    return 1 if leak else 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
