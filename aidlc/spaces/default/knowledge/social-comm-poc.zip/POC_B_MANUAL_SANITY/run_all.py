# -*- coding: utf-8 -*-
"""만드는 것과 확인하는 것을 순서대로 돌린다.

    python run_all.py

  1 장면 만들기          build_scenes.py
  2 규칙 확인            check_scenes.py
  3 화면·열쇠 만들기      build_review.py
  4 요약기 확인          가짜 답을 임시 폴더에 만들어 돌려만 본다

4를 왜 하나
  요약기는 사람 답이 있어야 돌아간다. 지금은 없다.
  **없는 답을 만들어 폴더에 두지 않는다.** 임시 폴더에 만들어 코드가 도는지만 보고 지운다.
  결과 숫자는 버린다. 쓰지 않는다.
"""
from __future__ import annotations

import csv
import io
import os
import random
import shutil
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
ENV = dict(os.environ, PYTHONIOENCODING='utf-8')


def run(label, args, cwd=HERE):
    p = subprocess.run([sys.executable] + args, cwd=cwd, capture_output=True,
                       text=True, encoding='utf-8', errors='replace', env=ENV)
    ok = p.returncode == 0
    tail = [x for x in (p.stdout or '').strip().split(chr(10)) if x.strip()]
    print('  %-22s %-4s %s' % (label, 'ok' if ok else 'FAIL', (tail[-1] if tail else '')[:52]))
    if not ok:
        for ln in tail[-10:]:
            print('        | %s' % ln[:104])
        for ln in (p.stderr or '').strip().split(chr(10))[-5:]:
            print('        | %s' % ln[:104])
    return ok


def smoke_summarizer():
    """가짜 답으로 요약기가 도는지만 본다. 임시 폴더에서 하고 지운다."""
    key = os.path.join(HERE, 'MANUAL_REVIEW_KEY.csv')
    if not os.path.exists(key):
        print('  %-22s %-4s 열쇠가 없다' % ('4 요약기 확인', 'FAIL'))
        return False
    rows = list(csv.DictReader(io.open(key, encoding='utf-8-sig', newline='')))
    tmp = tempfile.mkdtemp()
    try:
        fake = os.path.join(tmp, 'SMOKE_NOT_REAL_responses.csv')
        rng = random.Random(1)
        with io.open(fake, 'w', encoding='utf-8-sig', newline='') as fh:
            w = csv.writer(fh)
            w.writerow(['display_id', 'q1_naturalness', 'q2_context_sufficient',
                        'q3_same_ability', 'q4_distance', 'q5_answer_leak', 'memo'])
            for i, r in enumerate(rows):
                if i == 0:                       # 덜 채운 줄도 한 개 넣어 본다
                    w.writerow([r['display_id'], '3', '', '', '', '', ''])
                    continue
                w.writerow([r['display_id'], rng.choice('12345'), 'YES', 'SAME',
                            r['intended_distance'], 'NO', ''])
        p = subprocess.run([sys.executable, 'summarize_manual_review.py',
                            '--responses', fake], cwd=HERE, capture_output=True,
                           text=True, encoding='utf-8', errors='replace', env=ENV)
        # 답 노출이 없으니 0 이어야 한다
        ok = p.returncode == 0 and 'DEVELOPER MANUAL SANITY CHECK' in (p.stdout or '')
        print('  %-22s %-4s %s' % ('4 요약기 확인', 'ok' if ok else 'FAIL',
                                   '가짜 답으로 돌려만 봤다. 숫자는 버린다'))
        if not ok:
            for ln in (p.stdout or '').strip().split(chr(10))[-8:]:
                print('        | %s' % ln[:104])
            for ln in (p.stderr or '').strip().split(chr(10))[-5:]:
                print('        | %s' % ln[:104])
        return ok
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def main():
    print('POC B 수동 점검 묶음')
    print('  ** 개발자 수동 점검이다. 사람 대상 검증이 아니다 **')
    print()
    res = [
        run('1 장면 만들기', ['build_scenes.py']),
        run('2 규칙 확인', ['check_scenes.py']),
        run('3 화면·열쇠 만들기', ['build_review.py']),
        smoke_summarizer(),
    ]
    bad = [x for x in res if not x]

    real = os.path.join(HERE, 'manual_review_responses.csv')
    print()
    print('=' * 62)
    if bad:
        print('판정 · 실패 %d' % len(bad))
        return 1
    print('판정 · 만들기와 확인은 전부 통과')
    if os.path.exists(real):
        print('  사람 답이 있다 · python summarize_manual_review.py')
    else:
        print('  다음 · MANUAL_REVIEW.html 을 크롬으로 열어 18건을 채운다')
        print('  **사람 답은 아직 없다. 만들어 두지 않았다.**')
    return 0


if __name__ == '__main__':
    sys.exit(main())
