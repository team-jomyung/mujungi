"""화용 계층 다섯 클래스를 네 등급으로 나눈다.
있음/없음 이분법은 실제 상태를 못 담는다. 실제 대화에 붙은 라벨과
저자가 구성한 평가셋은 쓸 수 있는 곳이 다르다."""
import collections
M = [
 # 클래스, Gold(실제 대화 라벨), Benchmark(평가셋), Taxonomy 출처, 직접 주석
 ('CommunicativeAct',
  ('있음', '3i4K 61,254 발화(맥락 없음, CC BY-SA 4.0) · AI Hub 543·544 245만 발화(맥락 있음, 4분류)'),
  ('있음', '3i4K 테스트 분할'),
  ('있음', 'Searle 4분류 · 3i4K 7분류'),
  '세밀화만'),
 ('ResponseStrategy',
  ('있음', 'AI Hub 공감형 대화 472,055 발화 청자행동 4종(맥락 있음) · KMI 18,116턴 8종(합성)'),
  ('없음', ''),
  ('있음', 'ESConv 8전략 · AnnoMI · KMI 8종'),
  '세밀화만'),
 ('IntendedAct',
  ('없음', ''),
  ('있음', 'ReDi·ReCo·ReEx 240문항(맥락 있음, 같은 발화를 다른 맥락에 대비)'),
  ('있음', 'CCSARP 간접성 4단계'),
  '필요'),
 ('InterpretationCandidate',
  ('없음', ''),
  ('있음', '한국어 화용 평가셋 120문항 · MultiPragEval 한국어분 약 300문항'),
  ('있음', '그라이스 격률 4종'),
  '필요'),
 ('SocialCue',
  ('없음', ''),
  ('부분', 'KoCoSa 비꼼 탐지. 나머지 단서는 확인된 자료 없음'),
  ('부분', '여러 출처를 모아야 함'),
  '대부분 필요'),
]
print('=== 화용 계층 4등급 매핑표 ===\n')
w = 24
for cls, gold, bench, tax, ann in M:
    print(f'{cls}')
    print(f'  {"실제 대화 Gold":<14s} [{gold[0]}] {gold[1]}')
    print(f'  {"평가 Benchmark":<14s} [{bench[0]}] {bench[1]}')
    print(f'  {"Taxonomy 출처":<14s} [{tax[0]}] {tax[1]}')
    print(f'  {"직접 주석":<14s} {ann}\n')
g = collections.Counter(m[1][0] for m in M); b = collections.Counter(m[2][0] for m in M)
print(f'실제 대화 Gold  있음 {g["있음"]} · 없음 {g["없음"]}')
print(f'평가 Benchmark  있음 {b["있음"]} · 부분 {b["부분"]} · 없음 {b["없음"]}')
print('\n화용 평가셋 총량')
tot = [('한국어 화용 평가셋', 120), ('MultiPragEval 한국어분', 300), ('ReDi·ReCo·ReEx', 240), ('KoBALT 화용', 81)]
for n, v in tot: print(f'  {n:24s} {v:5d}')
print(f'  {"합계":24s} {sum(v for _, v in tot):5d} 문항')
print('\n주의: 위 평가셋은 전부 저자가 구성한 시나리오다. 실제 대화가 아니다.')
print('      한국어 화용 평가셋 120문항은 언어학 석사 4인이 직접 작성했다.')
