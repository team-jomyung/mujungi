"""데이터셋 매핑 결과를 세는 공용 도구.

화용 평가셋을 세 번 고치면서 정한 규칙을 코드로 옮긴 것이다.
변경을 세 종류로 나누고, 스키마 변경만 계층별로 센다.
"""
import collections

NO_SLOT = 'no_slot'      # 담을 클래스나 속성이 없어 새로 만들었다. 스키마 변경으로 센다
RENAME = 'rename'        # 자리는 있는데 이름이나 배치를 고쳤다. 세지 않는다
UNFILLED = 'unfilled'    # 자리도 이름도 맞는데 인스턴스를 아직 안 넣었다. 세지 않는다
HELD = 'held'            # 기준안이 그대로 맞았다
OUT_OF_SCOPE = 'oos'     # 기존 정의가 배제한다. 담지 않기로 정한 것이지 자리가 없는 게 아니다

KIND_LABEL = {
    NO_SLOT: '자리 없음',
    RENAME: '이름 바꿈',
    UNFILLED: '값 안 채움',
    HELD: '유지',
    OUT_OF_SCOPE: '범위 밖',
}
SCHEMA_CHANGING = {NO_SLOT}

DOMAIN = 'domain'
DATASET = 'dataset'
EVALUATION = 'evaluation'
VOCAB = 'vocab'
LAYER_LABEL = {DOMAIN: '도메인', DATASET: '데이터 표현',
               EVALUATION: '평가 모듈', VOCAB: '어휘 계층'}


class Mapping:
    """필드 하나를 기준안의 어느 자리에 넣었는지와 그 판정."""

    def __init__(self, field, target, kind, layer=None, note=''):
        if kind not in KIND_LABEL:
            raise ValueError(f'알 수 없는 판정: {kind}')
        if kind in SCHEMA_CHANGING and layer not in LAYER_LABEL:
            raise ValueError(f'{field}: 스키마 변경에는 계층이 필요하다')
        self.field = field
        self.target = target
        self.kind = kind
        self.layer = layer
        self.note = note


def report(dataset_name, mappings, baseline=''):
    counts = collections.Counter(m.kind for m in mappings)
    schema = [m for m in mappings if m.kind in SCHEMA_CHANGING]
    by_layer = collections.Counter(m.layer for m in schema)

    print(f'=== {dataset_name} 매핑 ===')
    if baseline:
        print(f'    기준안 {baseline}')
    print()
    width = max(len(m.field) for m in mappings)
    for m in mappings:
        print(f'  [{KIND_LABEL[m.kind]:6s}] {m.field:{width}s} → {m.target}')
        if m.note:
            print(f'           {m.note}')

    print()
    print(f'  필드 {len(mappings)}개')
    for kind in (HELD, RENAME, UNFILLED, OUT_OF_SCOPE, NO_SLOT):
        if counts[kind]:
            print(f'    {KIND_LABEL[kind]:8s} {counts[kind]}')

    print()
    if schema:
        print(f'  스키마 변경 {len(schema)}건')
        for layer in (DOMAIN, DATASET, EVALUATION, VOCAB):
            if by_layer[layer]:
                items = ', '.join(m.target for m in schema if m.layer == layer)
                print(f'    {LAYER_LABEL[layer]:8s} {by_layer[layer]}건  {items}')
    else:
        print('  스키마 변경 없음')

    print()
    print('  이름 바꿈·값 안 채움·범위 밖은 스키마 변경으로 세지 않는다.')
    print('  세 종류를 한 분모에 합치면 미매핑률이 부풀려진다.')
    return {'total': len(mappings), 'counts': dict(counts), 'schema': len(schema),
            'by_layer': {k: v for k, v in by_layer.items() if v}}
