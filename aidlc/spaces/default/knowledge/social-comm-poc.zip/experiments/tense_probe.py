import json, re, collections, os, statistics
D = r'C:\Users\baikj\.claude\jobs\52b4903e\tmp\drive'
data = json.load(open(os.path.join(D,'ctx','SDCI2502602061(평가).json'), encoding='utf-8'))
rows=[]; lens=[]
for d in data['document']:
    for ci in d['CI']:
        n=len(ci['discourse']['form']); lens.append(n)
        t=ci['inference']['type']
        for st in ci['inference']['statement']:
            rows.append((t, st['reg_infstmt'], st['adv_infstmt']))
PAST=re.compile(r'(았|었|였|했)(다|어|다\.|었다)?\.?$|(았|었|였|했)었?다\.?$|(다녀왔|봤|갔|왔|했)다\.?$')
FUT =re.compile(r'(것이다|겠다|것 같다|거야|을 것|ㄹ 것)\.?$')
def tense(s):
    s=s.strip()
    if FUT.search(s): return 'FUT'
    if PAST.search(s): return 'PAST'
    return 'PRES'
tt=collections.defaultdict(collections.Counter)
for t,r,a in rows:
    tt[(t,'정규')][tense(r)]+=1; tt[(t,'적대')][tense(a)]+=1
print('유형 × 극성 × 시제 (2025 전량)')
for k in sorted(tt): 
    c=tt[k]; tot=sum(c.values())
    print(f'  {k[0]:5s} {k[1]}  PAST {c["PAST"]:5d}  PRES {c["PRES"]:5d}  FUT {c["FUT"]:5d}   (n={tot})')
print('\n후행사건 정규문 표본 6')
for t,r,a in rows:
    if t=='후행사건': print('   ', r, '|', tense(r))
    if sum(1 for x in rows if x[0]=='후행사건')and rows.index((t,r,a))>0 and t=='후행사건': pass
    
import itertools
sub=[x for x in rows if x[0]=='후행사건'][:6]
print('\n원인 정규문 표본 6'); 
for t,r,a in [x for x in rows if x[0]=='원인'][:6]: print('   ', r, '|', tense(r))
lens.sort()
q=lambda p: lens[int(len(lens)*p)]
print(f'\n맥락 발화 수: 최소 {lens[0]}  p25 {q(.25)}  중앙 {q(.5)}  p75 {q(.75)}  p90 {q(.9)}  최대 {lens[-1]}  평균 {statistics.mean(lens):.1f}')
print(f'80발화 초과 맥락: {sum(1 for x in lens if x>80)}/{len(lens)}')
