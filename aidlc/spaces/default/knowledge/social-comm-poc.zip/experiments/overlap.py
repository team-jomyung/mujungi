import json, os, glob, collections, openpyxl
D = r'C:\Users\baikj\.claude\jobs\52b4903e\tmp\drive'
ctx = json.load(open(os.path.join(D,'ctx','SDCI2502602061(평가).json'), encoding='utf-8'))
ci_docs = set()
for d in ctx['document']:
    ci_docs.add(d['id'].split('.')[0])
print('맥락추론2025 문서', len(ci_docs))

xl = glob.glob(os.path.join(D,'kg','*.xlsx'))[0]
ws = openpyxl.load_workbook(xl, read_only=True).worksheets[0]
kg_docs = collections.Counter(); kw_docs = collections.defaultdict(set)
for i, r in enumerate(ws.iter_rows(values_only=True)):
    if i == 0: continue
    doc = str(r[1]).strip() if r[1] is not None else ''
    kw  = str(r[0]).strip() if r[0] is not None else ''
    if doc:
        base = doc.split('.')[0]
        kg_docs[base] += 1
        if kw: kw_docs[base].add(kw)
print('지식그래프2025 문서', len(kg_docs), '| 트리플', sum(kg_docs.values()))
inter = ci_docs & set(kg_docs)
print(f'교집합 문서: {len(inter)}')
print(f'  맥락추론 문서 중 KG 있는 비율: {len(inter)/len(ci_docs):.1%}')
print(f'  KG 문서 중 맥락추론 있는 비율: {len(inter)/len(kg_docs):.1%}')
# 그 교집합이 커버하는 세트/쌍 수
sets_in = pairs_in = 0; tot_sets = 0
for d in ctx['document']:
    base = d['id'].split('.')[0]
    for ci in d['CI']:
        tot_sets += 1
        if base in inter:
            sets_in += 1; pairs_in += len(ci['inference']['statement'])
print(f'교집합 문서에 속한 세트 {sets_in}/{tot_sets} ({sets_in/tot_sets:.1%}), 추론문 쌍 {pairs_in}')
print('교집합 문서당 평균 트리플', round(sum(kg_docs[b] for b in inter)/max(len(inter),1),1))
