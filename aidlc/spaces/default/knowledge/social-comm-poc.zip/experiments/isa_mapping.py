"""한국어 간접 화행 평가셋을 v0.2 더하기 합의된 v0.3 추가분에 매핑한다.

의도된 행위 계층을 실제 데이터로 시험하는 것이 목적이다. 마지막 탐색이다.
데이터 파일은 라이선스가 없어 이 폴더에 두지 않는다. 경로를 환경변수로 받는다.

    ISA_XLSX=<내려받은 파일> python isa_mapping.py

파일이 없으면 실측 절을 건너뛰고 매핑 판정만 출력한다.
"""
import os, re, collections
import mapping_score as M

SHEETS = ('ReDi', 'ReCo', 'ReEx')


def load():
    p = os.environ.get('ISA_XLSX') or os.path.join(
        os.environ.get('CLAUDE_JOB_DIR', ''), 'tmp', 'redi.xlsx')
    if not os.path.exists(p):
        return None
    try:
        import openpyxl
    except ImportError:
        return None
    wb = openpyxl.load_workbook(p)
    rows = []
    for sn in wb.sheetnames:
        ws = wb[sn]
        hdr = [c.value for c in ws[1]]
        for r in ws.iter_rows(min_row=2, values_only=True):
            if r[0] is None:
                continue
            d = dict(zip(hdr, r))
            d['_sheet'] = sn
            rows.append(d)
    return rows


def options(cell):
    return [x.strip() for x in re.findall(r'\d\)\s*([^\n]+)', str(cell or ''))]


rows = load()

print('=== 자료 성격 ===')
print('  이름       한국어 간접 화행 이해 평가셋 · ReDi / ReCo / ReEx')
print('  라이선스    없음. 권리 유보 상태이므로 내부 분석만 한다')
print('  생성       연구자 수작업 구성. 자연발화도 역할극도 아니다')
print('  주의       저장소 계정이 논문 저자인지 확인되지 않았다')
print()

if rows:
    print('=== 실물 확인 ===')
    print(f'  행 {len(rows)} · 시트 셋에 각 80')
    t = collections.Counter((r['TYPE'], r['Speech Act']) for r in rows)
    print()
    print('  표면 화행은 240건 모두 Representative 다.')
    print('  맥락 속 화행이 갈린다.')
    for k, v in sorted(t.items()):
        print(f'    {k[0]:9s} × {k[1]:15s} {v:4d}')
    mis = sum(1 for r in rows if r['Surface'] != r['Speech Act'])
    print(f'  표면과 의도가 어긋나는 항목 {mis} · 간접 항목 수와 같다')
    print()

    by_utt = collections.defaultdict(list)
    for r in rows:
        by_utt[str(r['Utterance']).strip()].append(r)
    both = 0
    for u, rs in by_utt.items():
        acts = {options(r['Choices'])[0] for r in rs if options(r['Choices'])}
        ctxs = {str(r['Context']).strip() for r in rs}
        if len(rs) >= 2 and len(ctxs) > 1 and len(acts) > 1:
            both += 1
    dist = collections.Counter(len(v) for v in by_utt.values())
    pairs = sum(v * (k // 2) for k, v in dist.items())
    print(f'  고유 발화 {len(by_utt)}건 · 등장 횟수 분포 {dict(sorted(dist.items()))}')
    print(f'  최소대립쌍 {pairs}쌍 · 검산 {sum(k * v for k, v in dist.items())} 행')
    print(f'  쌍의 수와 발화의 수가 다르다. 하나가 시트 둘에 중복 출제됐다.')
    print(f'  두 맥락에 나오는 발화 중 행위가 갈리는 것 {both} · 예외 없다')
    print()

    first = collections.Counter()
    for r in rows:
        o = options(r['Choices'])
        if o:
            first[o[0]] += 1
    print(f'  정답 자리에 쓰인 한국어 행위명 {len(first)}종')
    line = '    '
    for k, v in first.most_common():
        piece = f'{k} {v}'
        if len(line) + len(piece) > 76:
            print(line)
            line = '    '
        line += piece + ' · '
    print(line.rstrip(' ·'))
    print()

    x = collections.defaultdict(collections.Counter)
    for r in rows:
        o = options(r['Choices'])
        if o:
            x[r['Speech Act']][o[0]] += 1
    print('  네 범주가 열여덟 행위명을 어떻게 나누는가')
    for cat in ('Representative', 'Directive', 'Commissive', 'Expressive'):
        if cat in x:
            vals = ' · '.join(f'{k} {v}' for k, v in x[cat].most_common())
            print(f'    {cat:15s} {vals}')
    print()
    overlap = [a for a in first if sum(1 for c in x if a in x[c]) > 1]
    if overlap:
        print(f'  두 범주에 걸친 행위명 {overlap}')
        print('    경계 문서에서 다뤄야 할 실제 사례다.')
    print()
    dup = sum(1 for r in rows if len(set(options(r['Choices']))) < len(options(r['Choices'])))
    print(f'  결함 · 보기 문자열이 중복된 항목 {dup}건')
    print('  결함 · 정답이 보기 1번에 몰려 있다. 그대로 쓰면 안 되고 섞어야 한다.')
    print()
else:
    print('=== 실물 확인 건너뜀 ===')
    print('  ISA_XLSX 가 없거나 openpyxl 이 없다. 매핑 판정만 출력한다.')
    print()

print('=== 필드를 기준안에 매핑 ===\n')
MAPPINGS = [
 M.Mapping('Utterance', 'sco_Utterance', M.HELD,
   note='고유 발화 119건이 만드는 최소대립쌍 120쌍이다. 발화 노드 하나에 해석 주장 둘이 붙는다. 9.4 의 주장 객체가 없으면 같은 노드에 서로 다른 행위를 붙이게 된다'),

 M.Mapping('Context · 서술형 장면', 'EvaluationStimulus', M.HELD,
   note='화용 평가셋과 같은 모양이다. 발화 연속체가 아니라 삼인칭 상황문이므로 7.6 결정대로 담화 맥락을 넓히지 않는다'),

 M.Mapping('해석 주장의 맥락 대상', 'Context 상위 클래스 신설', M.NO_SLOT, M.DOMAIN,
   note='9.4 의 주장은 담화 맥락을 가리키게 되어 있는데 이 자료의 맥락은 서술형 장면이다. 두 종류를 함께 가리킬 상위 자리가 없다'),

 M.Mapping('TYPE · Direct 와 Indirect', 'PragmaticPhenomenon 간접성', M.HELD,
   note='비꼼 자료에서 만든 층위가 다른 자료의 다른 값을 그대로 받는다. 층위를 만든 목적과 다른 쓰임이다'),

 M.Mapping('Surface · 표면 화행', 'Utterance HAS_ACT CommunicativeAct', M.HELD,
   note='발화만 보고 읽히는 화행이다. v0.2 의 관계가 그대로 맞는다'),

 M.Mapping('Speech Act · 맥락 속 화행', '해석 주장에 붙는 CommunicativeAct', M.HELD,
   note='같은 어휘가 표면 자리와 의도 자리 둘에 온다. 간접성은 그 둘이 어긋나는 것이다. 자리 표시는 주장 객체가 진다'),

 M.Mapping('정답 행위명 18종', 'ext 어휘 → MAPS_TO → IntendedAct', M.RENAME,
   note='요청·비난·제안·거절·회피 같은 사회적 행위명이다. 이것이 의도된 행위 어휘다. 8.3 의 원천 어휘 기제를 그대로 쓴다'),

 M.Mapping('Choices 의 보기 역할', '역할 어휘를 벤치마크별로 나눈다', M.NO_SLOT, M.EVALUATION,
   note='7.2 의 역할 값 넷은 화용 평가셋의 것이다. 이 자료의 역할은 정답·반대 유형·무작위 둘이라 들어맞지 않는다. 역할 어휘도 원천과 정본을 나눠야 한다'),

 M.Mapping('Question', 'EvaluationPrompt', M.HELD,
   note='전 항목 동일한 지시문 하나다. 7.2 에서 만든 자리가 그대로 받는다'),
]
res = M.report('한국어 간접 화행 평가셋', MAPPINGS, baseline='v0.2 + 합의된 v0.3 추가분')

print()
print('=== 이 자료가 확인해 준 것 ===')
print('')
print('  1. 해석 주장을 객체로 만든 판단이 맞았다.')
print('     최소대립쌍 120쌍에서 맥락이 달라지면 행위가 달라진다. 예외가 없다.')
print('     발화만으로는 의도된 행위가 정해지지 않는다는 것을 통제 설계로 보여 준다.')
print('')
print('  2. 화용 현상 층위가 다른 자료에서도 쓰인다.')
print('     비꼼 자료에서 만든 자리가 이 자료의 간접성을 그대로 받는다.')
print('')
print('  3. 의도된 행위 어휘를 처음으로 실물에서 얻었다.')
print('     요청 · 비난 · 제안 · 거절 · 회피 · 경고 · 사과 같은 사회적 행위명이다.')
print('')
print('=== 이 자료가 새로 드러낸 것 ===')
print('')
print('  1. 맥락 대상의 상위 자리가 없다.')
print('     주장은 담화 맥락을 가리키는데 이 자료의 맥락은 서술형 장면이다.')
print('     7.6 에서 서비스가 필요해질 때 도입하자고 미룬 것인데,')
print('     이번에는 벤치마크 때문이 아니라 주장 객체의 구조 때문에 필요해졌다.')
print('')
print('  2. 보기 역할 어휘도 벤치마크마다 다르다.')
print('     화용 평가셋의 역할 넷을 정본처럼 적어 둔 것이 잘못이다.')
print('     전략 어휘에 적용한 원천과 정본 분리를 역할 어휘에도 해야 한다.')
print('')
print('  3. 화행 경계의 실제 사례가 나왔다.')
print('     제안이 지시 범주와 언약 범주 양쪽에 나타난다.')
print('     경계 문서에서 다룰 첫 사례다.')
print('')
print('=== 쓰기 전에 알아야 할 것 ===')
print('')
print('  라이선스가 없다. 권리 유보 상태이므로 내부 분석만 한다.')
print('  저장소 계정이 논문 저자인지 확인되지 않았다. 인용 전 확인이 필요하다.')
print('  열여덟 행위명 각각의 저자 정의가 논문에도 저장소에도 없다.')
print('  240개 항목 라벨의 작업자 간 일치도가 보고되지 않았다.')
print('  정답이 보기 1번에 몰려 있으므로 그대로 쓰면 안 된다.')
