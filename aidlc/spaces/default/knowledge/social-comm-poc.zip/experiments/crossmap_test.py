"""PoC 1 기준 C: 서로 다른 구조의 데이터셋을 v0.1 온톨로지에 정보 손실 없이 매핑할 수 있는가.
말뭉치 4종의 모든 구조 요소를 나열하고 v0.1에 자리가 있는지 판정한다."""
import os, csv, collections, json
HOME = os.path.expanduser('~')
G = os.path.join(HOME, '.claude', 'jobs', '52b4903e', 'tmp', 'drive', 'ysm', 'graph_out')

def rows(n):
    p = os.path.join(G, n)
    if not os.path.exists(p): return []
    with open(p, encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))

inf = rows('node_Inference.csv')
corpus_of = {r['uid']: r['corpus'] for r in inf}
ev = rows('rel_EVIDENCE_FOR.csv')
c = collections.Counter()
for r in ev:
    corp = corpus_of.get(r['to_uid'], '?')
    c[(corp, r['role'], 'span' if r['begin'].strip() else 'nospan')] += 1
print('=== ci2024 가 추가로 제공하는 것: 근거 span ===')
for k, v in sorted(c.items()):
    print(f'  {k[0]:8s} role={k[1]:10s} {k[2]:7s} {v:7d}')

V01 = {  # v0.1 이 담을 수 있는 것
 'Conversation','DiscourseContext','Utterance','Participant','Topic','Keyword','Corpus',
 'Concept','SemanticAssertion','SemanticRelationType','SemanticAttribute',
 'InferenceSet','InferenceStatement','InferenceType','AdversarialStrategy','HumanRating',
 'Verdict','ContextCandidate'}

# 데이터셋별 구조 요소와 v0.1 대응
ITEMS = [
 # (말뭉치, 구조 요소, 규모, v0.1 대응, 판정)
 ('ci2025','대화·발화·화자·관계·주제', '1,746 대화', 'Conversation/Utterance/Participant/Topic', 'OK'),
 ('ci2025','담화 맥락(부분 구간)', '3,712', 'DiscourseContext', 'OK'),
 ('ci2025','대상 발화', '3,712', 'TARGETS', 'OK'),
 ('ci2025','추론 유형 5종', '3,712', 'InferenceType', 'OK'),
 ('ci2025','정규/적대 3+3', '22,272 문장', 'InferenceSet/InferenceStatement', 'OK'),
 ('ci2025','적대 전략 4종', '11,136', 'AdversarialStrategy', 'OK'),
 ('ci2025','평가자 5인 2지표', '22,272', 'HumanRating', 'OK'),
 ('ci2025','한국언어문화 키워드', '3,712', 'Keyword', 'OK'),
 ('ci2024','추론 유형 5종(전제조건 포함)', '2,999 세그', 'InferenceType 값 확장 필요', 'PARTIAL'),
 ('ci2024','적대 전략 3종(통사·논리 포함)', '14,992', 'AdversarialStrategy 판본별', 'OK'),
 ('ci2024','근거 span begin/end', '35,564', '없음', 'MISSING'),
 ('ci2024','근거 역할 reference/clue', '49,268', '없음', 'MISSING'),
 ('summary2025','대화 요약문 2종(SC1/SC2)', '1,020', '없음', 'MISSING'),
 ('summary2025','요약 품질 점수 6종', '1,020', 'HumanRating 확장 필요', 'PARTIAL'),
 ('summary2025','소주제', '4,539', '없음', 'MISSING'),
 ('summary2025','화자별 관점 텍스트', '10,064', '없음', 'MISSING'),
 ('kg2025','개념 노드', '21,376', 'Concept', 'OK'),
 ('kg2025','트리플 + 근거 문장', '38,003', 'SemanticAssertion', 'OK'),
 ('kg2025','메타관계 44 / 속성 6', '-', 'SemanticRelationType/Attribute', 'OK'),
 ('kg2025','외래문화 표시', '-', 'Concept.is_cultural_import', 'OK'),
]
print('\n=== 기준 C: 말뭉치 4종 구조 요소를 v0.1 에 매핑 ===')
tally = collections.Counter()
for ds, item, size, target, verdict in ITEMS:
    tally[verdict] += 1
    print(f'  [{verdict:7s}] {ds:12s} {item:28s} {size:14s} → {target}')
n = len(ITEMS)
print(f'\n  손실 없이 매핑 {tally["OK"]}/{n} ({tally["OK"]/n:.0%})  부분 {tally["PARTIAL"]}  담을 자리 없음 {tally["MISSING"]}')
print('\n  → 담을 자리가 없는 5개는 데이터가 없어서가 아니라 v0.1 에 클래스가 없어서다. 설계 결함.')

# 화자 관점의 성격 확인
persp = rows('node_SpeakerPerspective.csv')
sub = rows('node_SubTopic.csv')
print('\n=== 화자 관점이 실제로 무엇을 담고 있는가 (표본) ===')
pat = collections.Counter()
for p in persp:
    s = p['summary'].strip()
    if not s or s == '(없음).': continue
    for k in ('반대한다','찬성한다','필요하다','생각한다','우려한다','기대한다','선호한다','중요하다','어렵다','좋다'):
        if s.endswith(k+'.') or s.endswith(k): pat[k] += 1
print('  어미 분포 상위:', pat.most_common(8))
for p in persp[:3]:
    print('   ·', p['summary'][:88])
print(f'\n  화자 관점은 소주제에 대한 화자의 입장을 한 문장으로 적은 것이다.')
print(f'  IntendedAct 는 아니지만 L3 와 L4 사이를 잇는 유일한 기존 자산이다. {len(persp)}건.')
