import json, os, random, collections, time
import numpy as np
from sentence_transformers import SentenceTransformer
D = r'C:\Users\baikj\.claude\jobs\52b4903e\tmp\drive'
random.seed(0); np.random.seed(0)
data = json.load(open(os.path.join(D, 'ctx', 'SDCI2502602061(평가).json'), encoding='utf-8'))
items = []
for d in data['document']:
    topic = d['metadata']['topic'].split('>')[0].strip()
    rel = d['metadata']['setting']['relation']
    for ci in d['CI']:
        seg = ci['discourse']['discourse_number']
        utts = [(f['id'], f['form']) for f in ci['discourse']['form']]
        inf = ci['inference']
        for k, st in enumerate(inf['statement']):
            try:
                er, ea = st['evaluation_reg'][0], st['evaluation_adv'][0]
                rw = list(er['context_worker'][0].values()); aw = list(ea['context_worker'][0].values())
            except (KeyError, IndexError):
                continue
            strict = min(rw) >= 4 and max(aw) <= 2 and er['language_avg'] >= 4 and ea['language_avg'] >= 4
            items.append(dict(doc=d['id'], seg=seg, k=k, type=inf['type'], topic=topic, rel=rel,
                              reg=st['reg_infstmt'], adv=st['adv_infstmt'], adv_type=st['adv_type'],
                              strict=strict, utts=utts, ref=set(inf['reference_id'])))
strict_items = [it for it in items if it['strict']]
print(f'statements={len(items)} strict={len(strict_items)}')
by_doc = collections.defaultdict(list)
for it in strict_items: by_doc[it['doc']].append(it)
N = 200
sel = [random.choice(by_doc[d]) for d in random.sample(sorted(by_doc), N)]

t0 = time.time()
m = SentenceTransformer('intfloat/multilingual-e5-small')
seg_ids, seg_forms, seg_slice = {}, [], {}
for it in sel:
    if it['seg'] in seg_slice: continue
    a = len(seg_forms); seg_forms += [u for _, u in it['utts']]; seg_ids[it['seg']] = [i for i, _ in it['utts']]
    seg_slice[it['seg']] = (a, len(seg_forms))
P = m.encode(['passage: ' + u for u in seg_forms], normalize_embeddings=True, batch_size=64, show_progress_bar=False)
Q = m.encode(['query: ' + it[key] for it in sel for key in ('reg', 'adv')], normalize_embeddings=True, batch_size=64, show_progress_bar=False)
print(f'encoded {len(seg_forms)} utterances + {len(Q)} statements in {time.time()-t0:.0f}s')

def score(qv, seg):
    a, b = seg_slice[seg]; return float((P[a:b] @ qv).max())
def auc(pos, neg):
    pos, neg = np.asarray(pos), np.asarray(neg)
    return float(((pos[:, None] > neg[None, :]).mean() + 0.5 * (pos[:, None] == neg[None, :]).mean()))

topic_groups = collections.defaultdict(list)
for j, it in enumerate(sel): topic_groups[it['topic']].append(j)
res = collections.defaultdict(list); hit = collections.Counter(); n_hard = 0
for i, it in enumerate(sel):
    qr, qa = Q[2 * i], Q[2 * i + 1]
    res['reg_own'].append(score(qr, it['seg'])); res['adv_own'].append(score(qa, it['seg']))
    cands = [j for j in topic_groups[it['topic']] if j != i]
    if cands:
        j = random.choice(cands); n_hard += 1
        res['reg_hard'].append(score(qr, sel[j]['seg'])); res['adv_hard'].append(score(qa, sel[j]['seg']))
    j = random.choice([x for x in range(N) if x != i])
    res['reg_rand'].append(score(qr, sel[j]['seg'])); res['adv_rand'].append(score(qa, sel[j]['seg']))
    # evidence retrieval: rank own-segment utterances by cosine with reg; is a reference utterance in top-k?
    a, b = seg_slice[it['seg']]; order = np.argsort(-(P[a:b] @ qr)); ids = seg_ids[it['seg']]
    for k in (1, 3, 5):
        if any(ids[o] in it['ref'] for o in order[:k]): hit[k] += 1
    hit['n_ref_avg'] += len(it['ref']); hit['n_utt_avg'] += len(ids)

print(f'\n=== NEI gate: is the statement about THIS discourse at all? (N={N}, hard-negatives={n_hard}, same topic category) ===')
print(f"AUC reg: own vs same-topic-other = {auc(res['reg_own'], res['reg_hard']):.3f} | own vs random-other = {auc(res['reg_own'], res['reg_rand']):.3f}")
print(f"AUC adv: own vs same-topic-other = {auc(res['adv_own'], res['adv_hard']):.3f} | own vs random-other = {auc(res['adv_own'], res['adv_rand']):.3f}")
print(f"(reference) truth AUC reg_own vs adv_own = {auc(res['reg_own'], res['adv_own']):.3f}")
for k in res: print(f'   mean {k:9s} = {np.mean(res[k]):.3f}  (sd {np.std(res[k]):.3f})')
own = np.array(res['reg_own']); hard = np.array(res['reg_hard']); rnd = np.array(res['reg_rand'])
print('\nthreshold table (reg): gate passes if max-cosine >= t')
for rec in (0.99, 0.95, 0.90):
    t = float(np.quantile(own, 1 - rec))
    print(f'   own-recall {rec:.0%} -> t={t:.3f} | false-pass same-topic-other={np.mean(hard >= t):.1%} | random-other={np.mean(rnd >= t):.1%}')
print('\n=== evidence retrieval inside own discourse (e5-small, top-k utterance contains a reference_id utterance) ===')
print(f"   hit@1={hit[1]/N:.1%} hit@3={hit[3]/N:.1%} hit@5={hit[5]/N:.1%} | avg refs/statement={hit['n_ref_avg']/N:.1f} avg utts/segment={hit['n_utt_avg']/N:.1f}")
json.dump({k: [round(x, 4) for x in v] for k, v in res.items()}, open(os.path.join(D, 'nei_gate_results.json'), 'w'), indent=0)
