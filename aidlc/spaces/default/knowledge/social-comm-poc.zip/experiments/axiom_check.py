import json, re, collections, os
D = r'C:\Users\baikj\.claude\jobs\52b4903e\tmp\drive'
data = json.load(open(os.path.join(D,'ctx','SDCI2502602061(평가).json'), encoding='utf-8'))
docs = data['document']

PAST = re.compile(r'(았다|었다|였다|았었다|었었다|했다|갔다|왔다|았어|었어|더라|았던|었던)\.?$')
FUT  = re.compile(r'(것이다|겠다|을 것|ㄹ 것|할 것|될 것|일 것|거야)\.?$')
NEG  = re.compile(r'(지 않|지 못|않다|못하|아니다|아니라|\b안 |\b못 )')
EMO  = ['좋다','싫다','기쁘','슬프','行','속상','서운','아쉽','안타깝','부럽','뿌듯','즐겁','행복','불안','걱정','두렵','무섭','화가','짜증','밉','귀찮','창피','부끄','당황','놀랍','신기','고맙','미안','후회','답답','편안','편하','흐뭇','설레','반갑','섭섭','허전','외롭','지겹','지루','불만','만족','실망','불편','궁금','대견','감동','서럽','민망','억울','원망','샘나','시원','통쾌','씁쓸','착잡','우울','love']

sets_ = []
for d in docs:
    did = d['id']
    for ci in d['CI']:
        seg = ci['discourse']['discourse_number']
        utt_ids = [f['id'] for f in ci['discourse']['form']]
        inf = ci['inference']
        stmts = inf['statement']
        sets_.append(dict(doc=did, seg=seg, utt_ids=utt_ids, n_utt=len(utt_ids),
                          type=inf['type'], ref=inf['reference_id'], stmts=stmts))

print(f'세트 {len(sets_)}  대화문 {len(set(s["doc"] for s in sets_))}  추론문 {sum(len(s["stmts"])*2 for s in sets_)}')
print('유형 분포', collections.Counter(s['type'] for s in sets_).most_common())

# S3 target utterance inside the context
s3 = sum(1 for s in sets_ if not set(s['ref']) <= set(s['utt_ids']))
# S4 exactly 3 statement pairs
s4 = collections.Counter(len(s['stmts']) for s in sets_)
# S5 每 pair has both reg & adv ; S6 adv has exactly one strategy
s5 = s6 = 0
strat = collections.Counter()
a1 = a2 = 0; tot_pair = 0
t1 = t2 = 0; t1_reg = t2_reg = 0
t4 = t5 = 0; n_desire = n_motiv = 0
t3 = 0; n_emo = 0
for s in sets_:
    for st in s['stmts']:
        tot_pair += 1
        reg, adv = st.get('reg_infstmt',''), st.get('adv_infstmt','')
        if not (reg and adv): s5 += 1
        at = st.get('adv_type','')
        if not at: s6 += 1
        strat[at] += 1
        if abs(len(reg.split()) - len(adv.split())) >= 3: a1 += 1
        if NEG.search(adv) and not NEG.search(reg): a2 += 1
        for text, isadv in ((reg, False), (adv, True)):
            if s['type'] == '후행사건' and PAST.search(text):
                if isadv: t1 += 1
                else: t1_reg += 1
            if s['type'] == '원인' and FUT.search(text):
                if isadv: t2 += 1
                else: t2_reg += 1
        if s['type'] == '욕구':
            n_desire += 1
            if any(e in reg for e in EMO): t4 += 1
        if s['type'] == '내적동기':
            n_motiv += 1
            if not any(e in reg for e in EMO): t5 += 1
        if s['type'] == '감정반응':
            n_emo += 1
print(f'\n[S3] 대상 발화가 맥락 밖: {s3}/{len(sets_)}')
print(f'[S4] 세트당 추론문 쌍 수 분포: {dict(s4)}')
print(f'[S5] reg/adv 결측 쌍: {s5}/{tot_pair}')
print(f'[S6] 전략 미기재: {s6}/{tot_pair}  |  전략 분포: {strat.most_common()}')
print(f'[A1] 어절 차 3 이상: {a1}/{tot_pair} ({a1/tot_pair:.2%})')
print(f'[A2] 적대문만 부정 표현: {a2}/{tot_pair} ({a2/tot_pair:.2%})')
print(f'[T1] 후행사건 과거형 - 적대 {t1} / 정규 {t1_reg}')
print(f'[T2] 원인 미래형   - 적대 {t2} / 정규 {t2_reg}')
print(f'[T4] 욕구 정규문에 감정어휘: {t4}/{n_desire} ({t4/max(n_desire,1):.1%})')
print(f'[T5] 내적동기 정규문에 감정어휘 없음: {t5}/{n_motiv} ({t5/max(n_motiv,1):.1%})')

# Q2 official 적합
fit = reg_fit = adv_fit = 0; strictN = 0; both = 0; miss = 0
for s in sets_:
    for st in s['stmts']:
        try:
            er, ea = st['evaluation_reg'][0], st['evaluation_adv'][0]
            rc, rl = er['context_avg'], er['language_avg']
            ac, al = ea['context_avg'], ea['language_avg']
            rw = list(er['context_worker'][0].values()); aw = list(ea['context_worker'][0].values())
        except (KeyError, IndexError):
            miss += 1; continue
        okr = rc >= 4 and rl >= 4
        oka = ac <= 2 and al >= 4
        reg_fit += okr; adv_fit += oka
        if okr and oka: both += 1
        if min(rw) >= 4 and max(aw) <= 2 and rl >= 4 and al >= 4: strictN += 1
print(f'\n[Q2] 표 24 기준 적합 - 정규 {reg_fit}/{tot_pair} ({reg_fit/tot_pair:.1%}) / 적대 {adv_fit}/{tot_pair} ({adv_fit/tot_pair:.1%}) / 쌍 둘 다 {both} ({both/tot_pair:.1%})')
print(f'[Tier S] 5인 전원 기준(정규 최저>=4, 적대 최고<=2): {strictN} ({strictN/tot_pair:.1%})  | 평가 결측 {miss}')
print(f'대화 길이: 최대 발화 {max(s["n_utt"] for s in sets_)}, 평균 {sum(s["n_utt"] for s in sets_)/len(sets_):.1f}')
