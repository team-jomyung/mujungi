"""KMI 를 v0.2 기준안에 매핑한다. 대응 전략 계층을 실제 데이터로 시험하는 것이 목적이다.

전체 재설계가 아니라 무엇이 유지되고 무엇만 바뀌는지 본다.
채점 규칙은 mapping_score.py 에 있다.
"""
import json, io, os, collections
import mapping_score as M

p = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'kmi.json')
d = json.load(io.open(p, encoding='utf-8'))
turns = [t for r in d for t in r['dialogue']]
lab = collections.Counter(t['label'] for t in turns if 'label' in t)

print('=== 실물 확인 ===')
print(f'  대화 {len(d):,d} · 턴 {len(turns):,d}')
role = collections.Counter(t['role'] for t in turns)
print(f'  상담자 {role["Therapist"]:,d} · 내담자 {role["Client"]:,d}')
print(f'  라벨 부착 {sum(lab.values()):,d} · 상담자 턴 전건, 내담자 턴 0건')
print(f'  모든 대화가 상담자로 시작해 상담자로 끝난다 ({role["Therapist"]-role["Client"]:,d} 차이 = 대화 수)')
print()
print('  라벨 여덟 · 파일에 실제로 쓰인 문자열')
for k, v in lab.most_common():
    print(f'    {k:20s} {v:6,d}  {v/sum(lab.values()):5.1%}')
print()
print('  주의 · 논문 표 1 은 여덟 번째를 Other 로 적지만 배포 파일은 General 이다.')
print('  주의 · 논문 표 2 의 분포는 합계가 8,561 로 상담자 턴 9,558 과 어긋난다. 파일 실측을 쓴다.')
print()

print('=== 필드를 기준안에 매핑 ===\n')
MAPPINGS = [
 M.Mapping('id', 'sco_Conversation.uid', M.HELD,
   note='대화 식별자. 자리가 있다'),

 M.Mapping('dialogue 배열 순서', 'HAS_UTTERANCE.seq', M.HELD,
   note='v0.2 가 이미 seq 속성을 갖는다. 턴 인덱스 필드가 없어도 순서는 보존된다'),

 M.Mapping('category_ko + category_en', 'sco_Topic · 어휘는 ext:', M.RENAME,
   note='주제 일곱 종. 클래스는 맞으나 국어원 주제 체계와 섞이면 안 되므로 3절의 ext: 이름공간으로 출처를 표시한다. 두 열은 한 주제의 두 언어 표기이지 주제 둘이 아니다'),

 M.Mapping('utterance_ko', '적재하지 않는다', M.OUT_OF_SCOPE,
   note='합성 상담 데이터셋이므로 도메인 근거 인스턴스로 적재하지 않는다. 모델이 썼기 때문이 아니다. 우리 서비스도 AI 발화를 다루므로 그 기준을 쓰면 우리 발화까지 배제된다'),

 M.Mapping('utterance_en', '적재하지 않는다', M.OUT_OF_SCOPE,
   note='영어 번역문. 발화를 적재하지 않으므로 번역도 적재하지 않는다. 넣기로 한다면 발화의 표현 하나이지 별개 발화가 아니다'),

 M.Mapping('label 값 여덟', 'ext_KmiStrategy → MAPS_TO → 정본 전략', M.NO_SLOT, M.VOCAB,
   note='값을 ResponseStrategy 하위로 바로 붙이면 동기면담 어휘가 우리 정본이 된다. 원천 어휘와 정본 어휘를 나누고 사상 관계로 잇는 자리가 없다'),

 M.Mapping('role · Therapist | Client', 'PARTICIPATES_IN.role 신설', M.NO_SLOT, M.DOMAIN,
   note='Participant 는 성별·연령 같은 인적 속성만 갖고 PARTICIPATES_IN 은 local_id 만 갖는다. 상담자와 내담자는 인적 속성이 아니라 이 대화에서 맡은 역할이다. 담을 자리가 없다'),

 M.Mapping('label 부착 지점', 'USES_STRATEGY · Utterance → ResponseStrategy', M.NO_SLOT, M.DOMAIN,
   note='v0.2 는 SUGGESTS 로 InterpretationCandidate 에서 ResponseStrategy 로 간다. 전략이 해석에서 도출된다는 구조다. KMI 는 전략을 산출된 발화에 붙인다. 발화에서 전략으로 가는 관계가 없다'),
]
res = M.report('KMI · 한국어 동기면담 대화', MAPPINGS, baseline='v0.2 + 합의된 v0.3 추가분')

print()
print('=== 이 데이터가 주지 않는 것 ===\n')
MISSING = [
 ('내담자 쪽 라벨',   '0건',
  'change talk 은 생성 지시문으로만 쓰였고 주석으로 남지 않았다. sustain talk 은 논문에 없다'),
 ('해석 노드',        '없음',
  '상담자가 내담자를 어떻게 해석했는지가 데이터에 없다. SUGGESTS 를 채울 수 없다'),
 ('원천 게시글',      '미포함',
  '마인드카페 글을 씨앗으로 썼으나 배포 파일에 원문이 없다. 대화의 바깥 맥락이 비어 있다'),
 ('분할',            '없음',
  'train/dev/test 가 제공되지 않는다. 우리가 나눠야 한다'),
]
w = max(len(a) for a, b, c in MISSING)
for a, b, c in MISSING:
    print(f'  {a:{w}s}  {b:8s} {c}')

print()
print('=== 생성 방식 ===\n')
print('  전량 합성이다. 사람이 쓴 발화는 0건이다.')
print('  상담자·내담자 시뮬레이터 모두 gpt-4-0125-preview 다.')
print('  사람은 생성에 개입하지 않았고 배포된 1,000건을 검수하거나 걸러내지 않았다.')
print('  사람이 한 것은 사후 표본 평가다. 대화 품질은 100건 표본, 라벨 정확도는 210 발화 표본에 96.0% 다.')
print('  라벨 정확도 검증 표에는 일곱 라벨만 있고 General 은 검증 대상에서 빠졌다.')
print()
print('  따라서 출처 분류는 "합성 + 사람 검증" 이 아니라 "합성 + 사후 표본 평가" 다.')
print('  전수 검증과 표본 평가를 같은 이름으로 부르면 안 된다.')

print()
print('=== 생성 규칙이 데이터에 남긴 자국 ===\n')
same3 = q3 = 0
for r in d:
    labs = [t['label'] for t in r['dialogue'] if t['role'] == 'Therapist']
    for i in range(len(labs) - 2):
        if labs[i] == labs[i+1] == labs[i+2]: same3 += 1
        if all(l in ('Open Question', 'Closed Question') for l in labs[i:i+3]): q3 += 1
first = collections.Counter(r['dialogue'][0]['label'] for r in d)
print(f'  논문이 밝힌 규칙 두 개: 같은 라벨 3연속 금지, 질문 3연속 금지')
print(f'  실측 · 같은 라벨 3연속 {same3:,d}건 · 질문 3연속 {q3:,d}건')
print(f'  실측 · 첫 턴은 1,000건 전부 {list(first)[0]}')
print()
print('  규칙이 완전히 지켜지지는 않았고, 첫 턴은 한 값으로 고정돼 있다.')
print('  분포를 대화 행동의 자연스러운 빈도로 읽으면 안 된다.')
