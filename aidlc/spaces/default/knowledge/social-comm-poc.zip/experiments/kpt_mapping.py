"""한국어 화용 평가셋 120문항을 현재 기준안에 매핑한다.
전체 재설계가 아니라 무엇이 유지되고 무엇만 바뀌는지 본다."""
import csv, io, collections, os, re
p = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'korean_pragmatics_testset.csv')
rows = list(csv.DictReader(io.open(p, encoding='utf-8-sig')))
print(f'=== 실물 확인 ===')
print(f'행 {len(rows)} · 열 {len(rows[0])}')
print('격률별', dict(collections.Counter(r['Type of Maxim'] for r in rows)))
print('정답 위치 분포', dict(collections.Counter(r['MCQ Answer'] for r in rows)))
det = set(r['MCQ Details'].strip() for r in rows)
print(f'보기 유형 패턴 {len(det)}종 (모든 행 동일)')
print('  ' + list(det)[0].replace('\n', ' / '))

# 보기 개수 검증
opt = collections.Counter()
for r in rows:
    opt[len(re.findall(r'^\(\d\)', r['MCQ'], re.M))] += 1
print('행별 보기 수 분포', dict(opt))

print('\n=== 열 9개를 기준안에 매핑 ===')
MAP = [
 ('ID',            'uid',                                   'OK',
  ''),
 ('Type of Maxim', 'ext:GriceanMaxim',                      'OK',
  'v0.3 제안의 외부 어휘 이름공간이 그대로 맞는다'),
 ('Context',       'EvaluationStimulus (장면부)',            'CHANGE',
  '2판은 DiscourseContext 에 새 kind 를 두자고 했다. 취소. 그 클래스 정의가 발화 연속체로 못 박혀 있어 뜻이 조용히 바뀐다'),
 ('Statement',     'EvaluationStimulus (대상 문장)',         'CHANGE',
  '우리 Utterance 정의는 구어에서 화자가 표현한 단위다. 연구자가 지은 문항은 그 정의에 안 맞는다'),
 ('MCQ 보기 (1)',   'Interpretation kind=pragmatic',         'CHANGE',
  '해석에 종류가 필요하다. 하위 클래스가 아니라 복수값 속성으로 둔다'),
 ('MCQ 보기 (2)',   'Interpretation kind=literal',           'CHANGE',
  '오답이 아니라 다른 층위의 해석이다. 기준안에 이 구분이 없다'),
 ('MCQ 보기 (3)',   'BenchmarkOption role=WRONG_IN_CONTEXT', 'CHANGE',
  '판정값 REFUTED 로 바로 사상하면 안 된다. 의도된 함축이 아니라는 뜻이지 맥락이 반박한다는 뜻이 아니다'),
 ('MCQ 보기 (4)',   'BenchmarkOption role=WRONG_OUT_OF_CONTEXT', 'CHANGE',
  '판정값 NEI 로 바로 사상하면 안 된다. NEI 후보이지 검증된 NEI 가 아니다'),
 ('MCQ Answer',    'role=CORRECT 에서 도출',                 'CHANGE',
  '2판은 Assessment 로 보냈다. 취소. 정답 키는 문항의 정의이고 Assessment 는 평가자 결과 자리다'),
 ('MCQ Details',   'BenchmarkOptionRole',                   'CHANGE',
  '도메인이 아니라 평가 모듈에 둔다. 해석의 성질이 아니라 이 벤치마크에서 맡은 역할이다'),
 ('OEQ',           'EvaluationPrompt',                      'CHANGE',
  '도메인에는 안 들어가지만 벤치마크 재현에 필요하므로 평가 모듈에 보존한다'),
 ('OEQ Answer',    'Interpretation kind=pragmatic (서술형)', 'OK',
  '선택지가 아니라 자유 서술. 해석이 후보와 독립된 개념이어야 하는 근거'),
]
t = collections.Counter(m[2] for m in MAP)
for col, tgt, v, note in MAP:
    mark = {'OK':'유지', 'CHANGE':'수정', 'SKIP':'해당없음'}[v]
    print(f'  [{mark:5s}] {col:16s} → {tgt}')
    if note: print(f'          {note}')
n = len([m for m in MAP if m[2] != 'SKIP'])
print(f'\n  매핑 대상 {n}개 중 유지 {t["OK"]} · 수정 {t["CHANGE"]}')
print(f'  유지율 {t["OK"]/n:.0%}  (초판 73% · 2판 42%)')
print('  세 번 고치는 동안 유지율이 계속 내려갔다. 초판이 매핑을 낙관했다는 뜻이다.')
print('')
print('  이 데이터가 강제한 Schema 변경 2건')
print('    도메인 1건    Interpretation.kind 복수값 속성')
print('    평가 모듈 1건  BenchmarkItem / BenchmarkOption / BenchmarkOptionRole /')
print('                  EvaluationStimulus / EvaluationPrompt')

print('')
print('=== 이 데이터가 준 것 ===')
print('1. 해석을 문자적과 화용적으로 나눠야 한다는 반례. 보기 (2)는 오답이 아니라 다른 층위다.')
print('2. 벤치마크 역할 어휘를 도메인에서 떼어내야 한다는 근거.')
print(f'3. 맥락 외 오답 {len(rows)}건. NEI 후보이지 검증된 NEI 는 아니다.')
print('4. 화용 계층 다섯 중 해석 하나만 건드린다. 화행·단서·의도·전략은 라벨이 없다.')
print('')
print('=== 배포 파일의 주의점 ===')
print(f'정답이 {len(rows)}행 전부 1번이다. CSV 그대로 쓰면 항상 1번을 고르는 모델이 100점을 받는다.')
print('우리가 쓸 때는 보기를 섞어야 한다.')
print('다만 원 논문은 평가 시 보기 순서를 바꿨다고 명시한다. 논문 점수 자체는 이 문제와 무관하다.')
