"""v0.2 로 같은 교차 매핑 시험을 다시 돌린다."""
import collections
ITEMS = [
 ('ci2025','대화·발화·화자·관계·주제','1,746 대화','Conversation/Utterance/Participant/Topic','OK','OK'),
 ('ci2025','담화 맥락(부분 구간)','3,712','DiscourseContext','OK','OK'),
 ('ci2025','대상 발화','3,712','TARGETS','OK','OK'),
 ('ci2025','추론 유형 5종','3,712','nikl:InferenceType','OK','OK'),
 ('ci2025','정규/적대 3+3','22,272 문장','InferenceSet/InferenceStatement','OK','OK'),
 ('ci2025','적대 전략 4종','11,136','nikl:AdversarialStrategy','OK','OK'),
 ('ci2025','평가자 5인 2지표','22,272','HumanRating','OK','OK'),
 ('ci2025','한국언어문화 키워드','3,712','Keyword','OK','OK'),
 ('ci2024','추론 유형 5종(전제조건)','2,999 세그','nikl:InferenceType.ci2024','PARTIAL','OK'),
 ('ci2024','적대 전략 3종','14,992','nikl:AdversarialStrategy.ci2024','OK','OK'),
 ('ci2024','근거 span begin/end','35,564','EVIDENCE_FOR{begin,end}','MISSING','OK'),
 ('ci2024','근거 역할 reference/clue','49,268','EVIDENCE_FOR{role}','MISSING','OK'),
 ('summary2025','대화 요약문 2종','1,020','Summary + SUMMARIZES','MISSING','OK'),
 ('summary2025','요약 품질 점수 6종','1,020','HumanRating(확장)','PARTIAL','OK'),
 ('summary2025','소주제','4,539','SubTopic + HAS_SUBTOPIC','MISSING','OK'),
 ('summary2025','화자별 관점','10,064','SpeakerStance + HAS_STANCE/STANCE_OF','MISSING','OK'),
 ('kg2025','개념 노드','21,376','Concept','OK','OK'),
 ('kg2025','트리플 + 근거 문장','38,003','SemanticAssertion','OK','OK'),
 ('kg2025','메타관계 44 / 속성 6','-','nikl:SemanticRelationType/Attribute','OK','OK'),
 ('kg2025','외래문화 표시','-','Concept.is_cultural_import','OK','OK'),
]
for ver, idx in (('v0.1', 4), ('v0.2', 5)):
    t = collections.Counter(r[idx] for r in ITEMS); n = len(ITEMS)
    print(f'{ver}  손실 없음 {t["OK"]:2d}/{n}  ({t["OK"]/n:4.0%})  부분 {t["PARTIAL"]}  자리 없음 {t["MISSING"]}')
print('\n변화한 항목')
for ds, item, size, tgt, a, b in ITEMS:
    if a != b:
        print(f'  {ds:12s} {item:24s} {a:8s} → {b}   ({tgt})')
print('\n=== 층별 데이터 커버리지 (설계 성패와 분리해서 읽을 것) ===')
LAYER = [
 ('M1 도메인 · 대화 구조', '전체', '100%', 'ci2025 전량', '직접 검증'),
 ('M1 도메인 · 개념 관계', '부분', '16.8%', 'kg2025 겹침 257/1746 문서', '부분 검증'),
 ('M1 도메인 · 화자 입장', '부분', '510 대화', 'summary2025, 맥락추론과 겹침 94', '부분 검증'),
 ('M2 데이터 표현 · 맥락 추론', '전체', '100%', 'ci2025 전량', '직접 검증'),
 ('M2 데이터 표현 · 근거 span', '부분', 'ci2024만', '2025에는 없음', '부분 검증'),
 ('M3 평가', '전체', '100%', 'ci2025 + summary2025', '직접 검증'),
 ('M4 실행', '해당 없음', '-', '실행 산출물', '해당 없음'),
 ('M5 확장 · 화용', '없음', '0%', '어떤 말뭉치에도 정답 없음', '미검증'),
]
for a, b, c, d, e in LAYER:
    print(f'  {a:28s} {b:6s} {c:9s} {d:34s} {e}')
