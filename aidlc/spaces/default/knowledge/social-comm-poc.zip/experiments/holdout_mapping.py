"""PoC 1 일반화 시험.

v0.2는 말뭉치 4종을 보고 만든 뒤 그 4종을 담아 20/20이 됐다. 이건 맞춘 것이지
일반화가 아니다. v0.2를 고정하고 설계 때 보지 않은 데이터셋을 넣어
스키마를 몇 개나 고쳐야 하는지, 못 담는 필드가 몇 퍼센트인지를 센다.
"""
import collections

# v0.2 가 가진 것 (고정)
V02_CLASSES = {
 'Conversation','DiscourseContext','Utterance','Participant','Topic','Keyword',
 'Concept','SemanticAssertion','SpeakerStance','SubTopic','Summary',
 'Corpus','InferenceSet','InferenceStatement','InferenceType','AdversarialStrategy',
 'SemanticRelationType','SemanticAttribute','HumanRating','Verdict','ContextCandidate',
 'CommunicativeAct','SocialCue','InterpretationCandidate','IntendedAct','ResponseStrategy'}
V02_STRUCTURAL_ASSUMPTIONS = [
 'Utterance 는 반드시 하나의 Conversation 에 속한다',
 'DiscourseContext 는 Utterance 의 연속 부분집합을 덮는다',
 'InterpretationCandidate 에는 정답 표시가 없다',
 'Verdict 는 (추론문, 맥락) 쌍에 붙는다',
]

# 보류 데이터셋 1: 3i4K (설계 때 보지 않음)
D1 = ('3i4K', '61,254 발화 · CC BY-SA 4.0', [
 ('발화 텍스트',        'Utterance',            'OK',      ''),
 ('라벨 진술',          'CommunicativeAct',     'OK',      ''),
 ('라벨 질문',          'CommunicativeAct',     'OK',      ''),
 ('라벨 명령',          'CommunicativeAct',     'OK',      ''),
 ('라벨 조각',          'CommunicativeAct',     'OK',      '값 추가'),
 ('라벨 수사의문문',     'CommunicativeAct + IntendedAct', 'PARTIAL',
  '표면형과 기능이 어긋난 상태. 두 클래스에 걸쳐 있어 한쪽에 못 넣는다'),
 ('라벨 수사명령문',     'CommunicativeAct + IntendedAct', 'PARTIAL', '같음'),
 ('라벨 억양의존',       '없음',                 'MISSING',
  '라벨이 붙지 않는다는 사실 자체가 라벨이다. 우리 스키마에 이 층위가 없다'),
 ('대화 소속 없음',      'Conversation 필수 위반', 'MISSING',
  'v0.2 는 모든 Utterance 가 Conversation 에 속한다고 가정한다'),
 ('화자 정보 없음',      'Participant 없음',      'OK',      '선택 항목이라 문제 없음'),
])

# 보류 데이터셋 2: 한국어 화용 평가셋 (Korean Pragmatics Test Set)
D2 = ('Korean Pragmatics Test Set', '120 문항 · 그라이스 격률 4종 각 30', [
 ('ID',                'uid',                  'OK',      ''),
 ('Context 시나리오',   'DiscourseContext',     'PARTIAL',
  '발화 연속체가 아니라 서술형 장면이다. COVERS 로 발화를 못 붙인다'),
 ('Statement',         'Utterance',            'PARTIAL', '역시 Conversation 없음'),
 ('MCQ 보기들',         'InterpretationCandidate', 'OK',   '여러 해석 후보 구조가 그대로 맞는다'),
 ('MCQ Answer',        '없음',                 'MISSING',
  '해석 후보 중 정답 표시. v0.2 의 InterpretationCandidate 에는 정답 개념이 없다'),
 ('Type of Maxim',     '없음',                 'MISSING',
  '그라이스 격률 어휘가 없다. 양·질·관계·양태'),
 ('OEQ / OEQ Answer',  '없음',                 'MISSING',
  '서술형 해석과 그 채점. 판정 계층에 서술형 자리가 없다'),
])

def run(ds):
    name, size, rows = ds
    t = collections.Counter(r[2] for r in rows); n = len(rows)
    print(f'\n### {name}  ({size})')
    for field, target, verdict, note in rows:
        mark = {'OK':'담김', 'PARTIAL':'부분', 'MISSING':'못 담음'}[verdict]
        print(f'  [{mark:6s}] {field:20s} → {target}')
        if note: print(f'            {note}')
    print(f'  담김 {t["OK"]}/{n}  부분 {t["PARTIAL"]}  못 담음 {t["MISSING"]}'
          f'   미매핑률 {(t["PARTIAL"]+t["MISSING"])/n:.0%}')
    return t, n

print('=== 보류 매핑 시험: v0.2 를 고정하고 설계 때 보지 않은 데이터셋을 넣는다 ===')
tot = collections.Counter(); N = 0
for ds in (D1, D2):
    t, n = run(ds); tot += t; N += n

print(f'\n=== 합계 ===')
print(f'  필드 {N}개 중 담김 {tot["OK"]}  부분 {tot["PARTIAL"]}  못 담음 {tot["MISSING"]}')
print(f'  미매핑률 {(tot["PARTIAL"]+tot["MISSING"])/N:.0%}   (참고: 설계 때 본 4종은 0%)')

FIXES = [
 ('Utterance 의 Conversation 필수 가정을 완화한다', '구조 가정', '두 데이터셋 모두 걸림'),
 ('DiscourseContext 에 서술형 장면을 담는 하위 유형을 둔다', '클래스 확장', '평가셋 계열 전부'),
 ('InterpretationCandidate 에 정답 표시와 서술형 해석을 둔다', '속성 2개', '평가셋 계열 전부'),
 ('표면형과 기능의 불일치를 나타내는 자리를 둔다', '관계 1개', '수사표현·억양의존'),
 ('그라이스 격률 어휘를 nikl 밖 외부 어휘로 둔다', '어휘 1종', '평가셋 계열 전부'),
]
print(f'\n=== 필요한 스키마 변경 {len(FIXES)}건 ===')
for f, kind, why in FIXES:
    print(f'  · {f}')
    print(f'      {kind} · {why}')
print('\n판정: 설계 때 본 4종은 20/20 이었으나 보지 않은 2종에서는 미매핑률이 53%다.')
print('      20/20 은 표현 가능성이지 일반화가 아니다. 두 기준을 나눠 불러야 한다.')
