"""온톨로지 클래스·관계별로 현재 확보한 데이터가 얼마나 채우는지 계산한다.
데이터 부족과 설계 결함을 구분하기 위한 근거표."""
import json, os, csv, glob, collections
HOME = os.path.expanduser('~')
D = os.path.join(HOME, '.claude', 'jobs', '52b4903e', 'tmp', 'drive')
G = os.path.join(D, 'ysm', 'graph_out')

ctx = json.load(open(os.path.join(D, 'ctx', 'SDCI2502602061(평가).json'), encoding='utf-8'))
docs = ctx['document']

def rows(name):
    p = os.path.join(G, name)
    if not os.path.exists(p): return
    with open(p, encoding='utf-8-sig', newline='') as f:
        yield from csv.DictReader(f)

print('=== ci2025 (대화 맥락 추론 2025) 필드 충족률 ===')
n_doc = len(docs); n_ctx = 0; n_set = 0
fill = collections.Counter(); tot = collections.Counter()
for d in docs:
    md = d['metadata']
    tot['Conversation.date'] += 1;  fill['Conversation.date'] += bool(md.get('date'))
    tot['Conversation.topic'] += 1; fill['Conversation.topic'] += bool(md.get('topic'))
    for sp in md.get('speaker', []):
        for f in ('age','sex','occupation','education','principal_residence','current_residence'):
            tot['Participant.'+f] += 1; fill['Participant.'+f] += bool(sp.get(f))
    tot['RELATED_TO.relation'] += 1; fill['RELATED_TO.relation'] += bool(md.get('setting',{}).get('relation'))
    for ci in d['CI']:
        n_ctx += 1; n_set += 1
        inf = ci['inference']
        tot['DiscourseContext.uid'] += 1; fill['DiscourseContext.uid'] += bool(ci['discourse'].get('discourse_number'))
        tot['COVERS'] += 1; fill['COVERS'] += bool(ci['discourse'].get('form'))
        tot['Keyword'] += 1; fill['Keyword'] += bool(ci.get('keyword'))
        tot['TARGETS'] += 1; fill['TARGETS'] += bool(inf.get('reference_id'))
        tot['HAS_TYPE'] += 1; fill['HAS_TYPE'] += bool(inf.get('type'))
        for st in inf['statement']:
            for k, lab in (('reg_infstmt','InferenceStatement.reg'), ('adv_infstmt','InferenceStatement.adv'),
                           ('adv_type','USES_STRATEGY')):
                tot[lab] += 1; fill[lab] += bool(st.get(k))
            tot['HumanRating.reg'] += 1; fill['HumanRating.reg'] += bool(st.get('evaluation_reg'))
            tot['HumanRating.adv'] += 1; fill['HumanRating.adv'] += bool(st.get('evaluation_adv'))
for k in sorted(tot):
    print(f'  {k:32s} {fill[k]:6d} / {tot[k]:6d}  {fill[k]/tot[k]:6.1%}')
print(f'  문서 {n_doc} · 맥락 {n_ctx} · 세트 {n_set}')

print('\n=== 협력적 대화 요약 2025 (summary2025) 구조 ===')
summ = list(rows('node_Summary.csv')); sub = list(rows('node_SubTopic.csv')); persp = list(rows('node_SpeakerPerspective.csv'))
print(f'  Summary {len(summ)} · SubTopic {len(sub)} · SpeakerPerspective {len(persp)}')
if summ:
    print('  Summary 필드:', list(summ[0].keys()))
    print('  SubTopic 필드:', list(sub[0].keys()))
    print('  SpeakerPerspective 필드:', list(persp[0].keys()))
    nonempty = sum(1 for p in persp if p['summary'].strip() and p['summary'].strip() != '(없음).')
    print(f'  관점 텍스트가 실제로 있는 것 {nonempty}/{len(persp)} ({nonempty/len(persp):.1%})')
    print('  관점 예시:', persp[0]['summary'][:70])
    docs_summ = set(s['uid'].split(':')[0] for s in summ)
    docs_ci = set(d['id'] for d in docs)
    print(f'  요약 대화 {len(docs_summ)} · 맥락추론과 겹침 {len(docs_summ & docs_ci)}')

print('\n=== kg2025 관계 어휘 ===')
sem = list(rows('rel_SEMANTIC.csv'))
if sem:
    rel = collections.Counter(r['relation'] for r in sem); att = collections.Counter(r['attribute'] for r in sem)
    print(f'  트리플 {len(sem)} · 메타관계 {len(rel)}종 · 속성 {len(att)}종')

print('\n=== v0.1 클래스별 현재 채움 ===')
STATUS = [
    ('Conversation','ci2025 + ci2024 + summary2025','Gold','100%'),
    ('DiscourseContext','ci2025','Gold','100%'),
    ('Utterance','ci2025','Gold','100%'),
    ('Participant','ci2025 metadata','Gold','100%'),
    ('Topic','ci2025 metadata','Gold','100%'),
    ('Keyword','ci2025 CI.keyword','Gold','100%'),
    ('Corpus','파생','Derived','100%'),
    ('Concept','kg2025','Gold','문서 257/1746 = 14.7%'),
    ('SemanticAssertion','kg2025','Gold','같음'),
    ('SemanticRelationType','kg2025 지침','Gold','44종 전부'),
    ('SemanticAttribute','kg2025 지침','Gold','6종'),
    ('InferenceSet','ci2025 파생','Derived','100%'),
    ('InferenceStatement','ci2025','Gold','100%'),
    ('InferenceType','ci2025','Gold','5종'),
    ('AdversarialStrategy','ci2025','Gold','4종'),
    ('HumanRating','ci2025 평가본','Gold','100%'),
    ('Verdict','정규/적대에서 파생','Derived','SUPPORTED/REFUTED만. NEI는 합성'),
    ('ContextCandidate','실행 산출물','Runtime','해당 없음'),
    ('CommunicativeAct','없음','-','0%'),
    ('SocialCue','없음','-','0%'),
    ('InterpretationCandidate','없음','-','0%'),
    ('IntendedAct','없음','-','0%'),
    ('ResponseStrategy','없음','-','0%'),
]
for c, src, kind, cov in STATUS:
    print(f'  {c:26s} {src:26s} {kind:9s} {cov}')
