import json, os, random, time, collections
import numpy as np
from sentence_transformers import SentenceTransformer
D = r'C:\Users\baikj\.claude\jobs\52b4903e\tmp\drive'
random.seed(0); np.random.seed(0)
data = json.load(open(os.path.join(D,'ctx','SDCI2502602061(평가).json'), encoding='utf-8'))

ctxs = []   # index unit = discourse context
for d in data['document']:
    topic = d['metadata']['topic']
    rel = d['metadata']['setting']['relation']
    for ci in d['CI']:
        seg = ci['discourse']['discourse_number']
        utts = [f['form'] for f in ci['discourse']['form']]
        kw = ci.get('keyword') or []
        ctxs.append(dict(seg=seg, doc=d['id'], text=' '.join(utts), topic=topic.split('>')[0].strip(),
                         rel=rel, kw=set(kw), n=len(utts),
                         stmts=[(s['reg_infstmt'], s['adv_infstmt']) for s in ci['inference']['statement']],
                         itype=ci['inference']['type']))
print(f'색인 단위(담화 맥락) {len(ctxs)}개, 평균 {np.mean([c["n"] for c in ctxs]):.1f}발화')
seg2i = {c['seg']: i for i, c in enumerate(ctxs)}

t0 = time.time()
m = SentenceTransformer('intfloat/multilingual-e5-small')
P = m.encode(['passage: ' + c['text'][:1800] for c in ctxs], normalize_embeddings=True, batch_size=48, show_progress_bar=False)
print(f'맥락 {len(ctxs)}개 인코딩 {time.time()-t0:.0f}s')

N = 600
qi = random.sample(range(len(ctxs)), N)
queries, gold = [], []
for i in qi:
    c = ctxs[i]
    k = random.randrange(len(c['stmts']))
    queries.append(c['stmts'][k][0]); gold.append(i)
Q = m.encode(['query: ' + q for q in queries], normalize_embeddings=True, batch_size=48, show_progress_bar=False)
S = Q @ P.T
print(f'질의 {N}개 인코딩 완료, 검색 공간 {len(ctxs)}')

def report(name, S, mask=None):
    Sx = S.copy()
    if mask is not None: Sx = np.where(mask, Sx, -1e9)
    order = np.argsort(-Sx, axis=1)
    ranks = np.array([np.where(order[r] == gold[r])[0][0] + 1 for r in range(N)])
    out = {k: float((ranks <= k).mean()) for k in (1, 3, 5, 10, 20)}
    mrr = float((1.0 / ranks).mean())
    print(f'{name:34s} R@1 {out[1]:.3f}  R@3 {out[3]:.3f}  R@5 {out[5]:.3f}  R@10 {out[10]:.3f}  R@20 {out[20]:.3f}  MRR {mrr:.3f}  중앙순위 {int(np.median(ranks))}')
    return ranks

print(f'\n=== 과제: 추론문(정규)을 주고 그 문장이 나온 담화 맥락을 {len(ctxs)}개 중에서 찾기 ===')
r_vec = report('R0 벡터 단독', S)

# R1a: 주제 카테고리로 후보 축소 (그래프 메타데이터가 주는 것)
topics = np.array([c['topic'] for c in ctxs])
mask_topic = np.stack([topics == ctxs[g]['topic'] for g in gold])
print(f'   (주제 카테고리 {len(set(topics))}종, 후보 평균 {mask_topic.sum(1).mean():.0f}개로 축소)')
r_topic = report('R1a 주제 필터 + 벡터', S, mask_topic)

# R1b: 키워드(한국언어문화) 교집합으로 축소
kws = [c['kw'] for c in ctxs]
have_kw = sum(1 for k in kws if k)
mask_kw = np.zeros((N, len(ctxs)), dtype=bool)
for r, g in enumerate(gold):
    gk = kws[g]
    mask_kw[r] = np.array([bool(gk & k) if gk else True for k in kws])
print(f'   (키워드 보유 맥락 {have_kw}/{len(ctxs)}, 후보 평균 {mask_kw.sum(1).mean():.0f}개로 축소)')
r_kw = report('R1b 키워드 필터 + 벡터', S, mask_kw)

# 적대문으로 검색하면? (같은 맥락을 찾아야 함)
qa = [ctxs[g]['stmts'][0][1] for g in gold]
Qa = m.encode(['query: ' + q for q in qa], normalize_embeddings=True, batch_size=48, show_progress_bar=False)
print()
r_adv = report('적대문 질의(정답 맥락 동일)', Qa @ P.T)

# 검색 후 판정: top-1 맥락을 주었을 때 정규/적대가 갈리는가
o1 = np.argmax(S, axis=1)
same = (o1 == np.array(gold)).mean()
print(f'\ntop-1이 정답 맥락인 비율 {same:.3f}')
json.dump({'R0_ranks': r_vec.tolist(), 'R1a_ranks': r_topic.tolist(), 'R1b_ranks': r_kw.tolist(),
           'n_ctx': len(ctxs), 'N': N}, open(os.path.join(D,'retrieval_results.json'),'w'))
