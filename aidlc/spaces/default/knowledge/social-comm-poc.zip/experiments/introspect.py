import json, os
D = r'C:\Users\baikj\.claude\jobs\52b4903e\tmp\drive'
def shape(o, ind=0, maxd=6):
    pad = '  ' * ind
    if ind > maxd: return pad + '...\n'
    if isinstance(o, dict):
        s = ''
        for k, v in list(o.items())[:14]:
            if isinstance(v, (dict, list)):
                s += f"{pad}{k}: {type(v).__name__}[{len(v)}]\n" + shape(v, ind + 1, maxd)
            else:
                s += f"{pad}{k}: {repr(v)[:70]}\n"
        return s
    if isinstance(o, list):
        return (shape(o[0], ind, maxd) if o else pad + '(empty)\n')
    return pad + repr(o)[:70] + '\n'
with open(os.path.join(D, 'ctx', 'SDCI2502602061(평가).json'), encoding='utf-8') as f:
    data = json.load(f)
print('=== ctx(평가).json top ===')
print(shape(data, maxd=7))
docs = data['document'] if isinstance(data, dict) and 'document' in data else data
print('n documents:', len(docs))
with open(os.path.join(D, 'tierS.json'), encoding='utf-8') as f:
    t = json.load(f)
print('=== tierS.json ===', type(t).__name__, len(t))
print(shape(t, maxd=3))
with open(os.path.join(D, 'testset_v0.json'), encoding='utf-8') as f:
    ts = json.load(f)
print('=== testset_v0.json keys ===', {k: len(v) for k, v in ts.items()})
print(shape({k: v for k, v in ts.items() if k != 'clean_pairs'}, maxd=3))
