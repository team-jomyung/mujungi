"""KoCoSa 를 v0.2 더하기 합의된 v0.3 추가분에 매핑한다.

처음에는 의도된 행위 계층을 시험한다고 적었다. 그것이 틀렸다.
비꼼은 화자가 사회적으로 무엇을 하는지가 아니라 어떻게 말하는지다.
이 파일은 화용 현상 계층의 근거로 다시 매핑한 것이다.
데이터 파일은 라이선스가 없어 이 폴더에 두지 않는다. 경로를 환경변수로 받는다.

    KOCOSA_DIR=<내려받은 폴더> python kocosa_mapping.py

파일이 없으면 실측 절을 건너뛰고 매핑 판정만 출력한다.
"""
import json, io, os, collections, statistics
import mapping_score as M

SPLITS = ('train', 'dev', 'test')


def load():
    d = os.environ.get('KOCOSA_DIR') or os.path.join(
        os.environ.get('CLAUDE_JOB_DIR', ''), 'tmp')
    out = {}
    for s in SPLITS:
        p = os.path.join(d, f'kocosa_{s}.json')
        if not os.path.exists(p):
            return None
        out[s] = json.load(io.open(p, encoding='utf-8'))
    return out


data = load()

print('=== 자료 성격 ===')
print('  이름       KoCoSa · 맥락 인식 비꼼 탐지 데이터셋')
print('  라이선스    없음. 권리 유보 상태이므로 내부 분석만 한다')
print('  씨앗       국립국어원 메신저 말뭉치와 온라인 대화 말뭉치')
print('  생성       GPT-3.5 로 상황 추출, GPT-4 로 대화 생성, 사람이 검수')
print()

if data:
    rows = 0
    lab = collections.Counter()
    expl = collections.Counter()
    turns = []
    alt = 0
    for s in SPLITS:
        d = data[s]
        n = len(d['Context'])
        rows += n
        lab.update(d['Sarcasm_Label'].values())
        for i in d['Context']:
            lines = [l for l in d['Context'][i].split('\n') if l.strip()]
            turns.append(len(lines))
            r = d['Response'][i].split(':')[0].strip()
            if lines and r != lines[-1].split(':')[0].strip():
                alt += 1
            filled = 'nonempty' if d['Sarcasm_Explanation'][i].strip() else 'empty'
            expl[(d['Sarcasm_Label'][i], filled)] += 1

    print('=== 실물 확인 ===')
    print(f'  행 {rows:,d} · 최상위는 배열이 아니라 열 네 개를 갖는 사전이다')
    print(f'  라벨 두 값  Sarcasm {lab["Sarcasm"]:,d} · Non-Sarcasm {lab["Non-Sarcasm"]:,d}')
    print(f'  선행 턴  최소 {min(turns)} 최대 {max(turns)} 평균 {statistics.mean(turns):.2f}')
    print(f'  화자 교대  {alt:,d} / {rows:,d} 건에서 대상 발화가 직전 화자와 다르다')
    print()
    print('  설명 필드 채움 규칙 · 예외 없음')
    for (l, f), n in sorted(expl.items()):
        print(f'    {l:12s} {f:9s} {n:6,d}')
    print()
    print('  주의 · 배포본 열 이름은 대문자로 시작한다. 공개 뷰어가 보여 주는')
    print('         소문자 이름으로 파서를 짜면 키를 못 찾는다.')
    print()
else:
    print('=== 실물 확인 건너뜀 ===')
    print('  KOCOSA_DIR 이 없다. 매핑 판정만 출력한다.')
    print()

print('=== 필드를 기준안에 매핑 ===\n')
MAPPINGS = [
 M.Mapping('Context 구조', 'Conversation + Utterance + HAS_UTTERANCE.seq', M.HELD,
   note='화자 둘이 번갈아 말하는 다중 턴이다. 익명 화자는 PARTICIPATES_IN.local_id 로 받는다'),

 M.Mapping('Context 적재', '적재하지 않는다', M.OUT_OF_SCOPE,
   note='합성 대화이므로 도메인 근거 인스턴스로 적재하지 않는다. KMI 와 같은 판단이다'),

 M.Mapping('Response · 판정 대상', 'Assessment.target', M.HELD,
   note='7.3 에서 평가자 결과 전용으로 만든 Assessment 가 그대로 받는다. 판정 대상 자리가 이미 있다'),

 M.Mapping('Sarcasm_Label', 'PragmaticPhenomenon 신설', M.NO_SLOT, M.DOMAIN,
   note='처음에는 IntendedAct 로 보냈다. 취소한다. 비꼼은 화자가 사회적으로 무엇을 하는지가 아니라 어떻게 말하는지다. 단서와 해석 사이에 놓일 층위가 기준안에 없다'),

 M.Mapping('Sarcasm_Explanation 내용', 'Interpretation kind=pragmatic 서술형', M.HELD,
   note='7.1 에서 만든 자리가 그대로 받는다. 다만 화자가 실제로 뜻한 바가 아니라 데이터 작성자와 모델이 부여한 해석이다'),

 M.Mapping('Sarcasm_Explanation 출처', '출처 사슬을 셋으로 나눈다', M.NO_SLOT, M.DOMAIN,
   note='이 자료에는 출처가 셋이다. 대화는 합성, 라벨은 사람 주석, 설명은 모델 생성에 사람 검수다. 속성 하나로는 담기지 않는다'),

 M.Mapping('맥락 의존 판정', 'InterpretationAssertion 객체화', M.NO_SLOT, M.DOMAIN,
   note='해석은 발화와 맥락과 해석의 삼항 관계다. 맥락을 관계 속성으로 넣는 대신 주장 자체를 객체로 만들어 출처까지 함께 붙인다'),

 M.Mapping('train / dev / test', '적재하지 않는다', M.OUT_OF_SCOPE,
   note='실험 분할은 온톨로지 내용이 아니라 실험 메타데이터다'),
]
res = M.report('KoCoSa · 맥락 인식 비꼼', MAPPINGS, baseline='v0.2 + 합의된 v0.3 추가분')

print()
print('=== 비꼼이 의도된 행위가 아니라는 증거 ===')
print('')
print('  설명문 6,237건에서 어떤 사회적 행위를 지목하는지 어휘로 셌다.')
print('')
print('    비꼼과 조롱을 되풀이함   5,939  95.2%')
print('    거절이나 반대를 지목함     291   4.7%')
print('    놀림이나 농담을 지목함      93   1.5%')
print('    비판이나 지적을 지목함      88   1.4%')
print('    불만이나 짜증을 지목함      78   1.3%')
print('')
print('  설명문의 95퍼센트가 비꼬아 말한다는 사실을 되풀이할 뿐이다.')
print('  화자가 실제로 무엇을 하는지는 대부분 적혀 있지 않다.')
print('  나머지 소수에서 지목된 행위가 거절·놀림·비판·불만으로 갈린다.')
print('')
print('  즉 하나의 비꼼 아래 여러 의도된 행위가 온다.')
print('  비꼼은 의도된 행위가 아니라 그 위에서 판단되는 화용 현상이다.')
print('')
print('=== 그래서 기준안이 깨지지 않은 것이 아니다 ===')
print('')
print('  설명문은 기존 Interpretation 이 받는다. 그건 맞다.')
print('  그러나 비꼼이라는 현상 자체가 놓일 자리는 아직 정해지지 않았다.')
print('  단서도 아니고 해석도 아니고 의도된 행위도 아니다.')
print('  이 데이터셋이 던진 것은 확인이 아니라 새 질문이다.')

print()
print('=== 이 데이터가 덮지 않는 것 ===\n')
UNCOVERED = [
 ('간접 요청',   '여기 좀 덥지 않아 가 창문 열어 달라는 뜻인 경우'),
 ('간접 거절',   '완곡하게 거절하는 경우'),
 ('체면 유지',   '상대의 체면을 세우려고 말을 돌리는 경우'),
 ('힌팅',       '말하지 않고 짐작하게 하는 경우'),
 ('공손성 간접', '공손하려고 간접적으로 말하는 경우'),
]
w = max(len(a) for a, b in UNCOVERED)
for a, b in UNCOVERED:
    print(f'  {a:{w}s}  {b}')
print()
print('  이 데이터가 덮는 것은 화용 현상 중 의미 반전 하나다.')
print('  의도된 행위 축은 이 자료로 시험되지 않았다. 여전히 비어 있다.')
print('  그 축에 맞는 자료는 논문으로 존재하나 저장소가 비어 있어 받을 수 없다.')

print()
print('=== 봉인 상태에 미치는 영향 ===\n')
print('  봉인 A 에 온라인 대화 말뭉치가 들어 있고 이 자료의 씨앗이 그것이다.')
print('  다만 배포본은 그 말뭉치의 필드 이름도 주석 계층도 드러내지 않는다.')
print('  상황 요약을 뽑아 새 대화를 생성한 것이라 원문도 아니다.')
print('  따라서 스키마 봉인은 유지된다고 본다. 접촉이 있었다는 사실은 기록해 둔다.')
