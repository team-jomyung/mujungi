"""화자 입장 데이터가 화용 계층에 어느 정도까지 닿는지 본다.
결론을 미리 정하지 않고, 입장 문장이 실제로 무엇을 담고 있는지 센다."""
import os, csv, collections, re
HOME = os.path.expanduser('~')
G = os.path.join(HOME, '.claude', 'jobs', '52b4903e', 'tmp', 'drive', 'ysm', 'graph_out')
def rows(n):
    with open(os.path.join(G, n), encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))
persp = [p for p in rows('node_SpeakerPerspective.csv')
         if p['summary'].strip() and p['summary'].strip() != '(없음).']
print(f'화자 입장 텍스트 {len(persp)}건')

CATS = {
 '찬반 표명': r'(찬성|반대)(한다|하는|했다)',
 '평가·판단': r'(좋다|나쁘다|중요하다|필요하다|어렵다|편리하다|불편하다)\.?$',
 '선호': r'(선호한다|좋아한다|즐긴다)\.?$',
 '의견 표명': r'(생각한다|여긴다|본다|믿는다)\.?$',
 '우려·기대': r'(우려한다|걱정한다|기대한다|바란다)\.?$',
 '경험 서술': r'(경험이 있다|해 왔다|했었다|다녔다)\.?$',
 '완곡·유보 표지': r'(수도 있다|것 같다|편이다|일 수 있다|하기도 한다)',
}
hit = collections.Counter()
for p in persp:
    s = p['summary'].strip()
    for k, pat in CATS.items():
        if re.search(pat, s): hit[k] += 1
print('\n문장 유형 (중복 집계)')
for k, _ in CATS.items():
    print(f'  {k:12s} {hit[k]:5d}  {hit[k]/len(persp):5.1%}')

print('\n완곡·유보 표지가 있는 문장 표본')
n = 0
for p in persp:
    s = p['summary'].strip()
    if re.search(CATS['완곡·유보 표지'], s) and n < 4:
        print('  ·', s[:92]); n += 1

print('\n판정')
print('  이 데이터는 소주제에 대한 화자의 입장을 요약한 것이다.')
print('  찬반과 평가는 잘 담기지만 발화 단위의 화행이나 간접 의도는 담기지 않는다.')
print('  단위가 소주제이지 발화가 아니라서, 어느 발화가 그 입장을 드러냈는지는 알 수 없다.')
print('  → 화용 계층의 대체재가 아니라 인접 자산이다. 약한 감독 신호로는 쓸 수 있다.')
