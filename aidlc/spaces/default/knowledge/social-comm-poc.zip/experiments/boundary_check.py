import json, os, collections
D = r'C:\Users\baikj\.claude\jobs\52b4903e\tmp\drive'
data = json.load(open(os.path.join(D,'ctx','SDCI2502602061(평가).json'), encoding='utf-8'))
rows = []
for d in data['document']:
    for ci in d['CI']:
        for k, st in enumerate(ci['inference']['statement']):
            try:
                er, ea = st['evaluation_reg'][0], st['evaluation_adv'][0]
                rw = list(er['context_worker'][0].values()); aw = list(ea['context_worker'][0].values())
            except (KeyError, IndexError): continue
            rows.append((er['context_avg'], rw, ea['context_avg'], aw, ci['inference']['type']))
n = len(rows)
print(f'쌍 {n}')
# 표24 판정 + 재평정 대상 여부 (재평정 = 수정/제거 판정 AND spread>=3)
def verdict_reg(a): return '적합' if a>=4 else ('수정' if a>=3 else '제거')
def verdict_adv(a): return '적합' if a<=2 else ('수정' if a<=3 else '제거')
cnt = collections.Counter(); spread_fit_reg = spread_fit_adv = 0
dissent_reg = dissent_adv = 0; both = 0
for ra, rw, aa, aw, t in rows:
    vr, va = verdict_reg(ra), verdict_adv(aa)
    cnt[('정규', vr)] += 1; cnt[('적대', va)] += 1
    sr, sa = max(rw)-min(rw), max(aw)-min(aw)
    if vr == '적합' and sr >= 3: spread_fit_reg += 1
    if va == '적합' and sa >= 3: spread_fit_adv += 1
    if min(rw) <= 2: dissent_reg += 1
    if max(aw) >= 4: dissent_adv += 1
    if min(rw) <= 2 and max(aw) >= 4: both += 1
print('표24 판정 분포:', dict(cnt))
print(f'\n[GPT 반론 검증] 적합 판정인데 평가자 최고-최저 차 >=3 → 보고서 재평정 대상에서 제외된 건')
print(f'  정규 {spread_fit_reg} ({spread_fit_reg/n:.2%})   적대 {spread_fit_adv} ({spread_fit_adv/n:.2%})')
print(f'  1인 이탈: 정규 1인 이하 2점 {dissent_reg} / 적대 1인 이상 4점 {dissent_adv} / 양쪽 동시 {both}')
# 점수 분포
h = collections.Counter()
for ra, rw, aa, aw, t in rows:
    h[('정규', round(ra*2)/2)] += 1
print('\n정규 맥락평균 분포 상위:', sorted([(k[1],v) for k,v in h.items()])[:6], '...', sorted([(k[1],v) for k,v in h.items()])[-4:])
