"""analyze_pilot.py 를 돌려 보기 위한 가짜 파일럿 데이터.

    python make_synthetic_events.py

DEMO 데이터다. 사람에게서 받은 것이 아니다.
원문은 넣지 않는다. 사용성 수치와 선택지 값만 만든다.
"""
import csv
import io
import json
import os
import random

HERE = os.path.dirname(os.path.abspath(__file__))
SEED = 777

REL = ['FRIEND_CLOSE', 'CLUB_PEER', 'CLUB_SENIOR', 'TEAMMATE', 'SUPERVISOR', 'UNKNOWN']
GOAL = ['ARRANGE', 'CHECK_INTENT', 'KEEP_MOOD', 'REQUEST', 'DECLINE', 'UNKNOWN']
BLOCKED = ['MEANING_UNCLEAR', 'HOW_TO_SAY', 'MOOD_TURNED', 'MISUNDERSTOOD', 'UNKNOWN']

EVENT_COLS = ['event_id', 'participant_id', 'timestamp', 'relationship_type',
              'user_goal_value', 'blocked_at', 'n_turns', 'n_difficult_turns',
              'seconds_to_complete', 'clarifying_questions', 'user_edits',
              'unknown_fields', 'redaction_hits', 'manual_pii_removals',
              'pii_review_failures']
FOLLOW_COLS = ['event_id', 'participant_id', 'asked_at',
               'relationship_type_followup', 'user_goal_value_followup', 'note']


def main():
    rng = random.Random(SEED)
    events, follows = [], []
    n_participants = 7
    eid = 0
    for pi in range(1, n_participants + 1):
        pid = f'P{pi:02d}'
        for _ in range(rng.choice([2, 2, 3])):
            eid += 1
            e_id = f'E{eid:03d}'
            rel = rng.choice(REL)
            goal = rng.choices(GOAL, weights=[3, 3, 2, 2, 2, 3])[0]
            unk = []
            if rel == 'UNKNOWN':
                unk.append('relationship_type')
            if goal == 'UNKNOWN':
                unk.append('user_goal_claim')
            hits = rng.choice([0, 0, 1, 1, 2, 3])
            events.append({
                'event_id': e_id, 'participant_id': pid,
                'timestamp': f'2026-09-{12 + pi:02d}T1{rng.randrange(0,9)}:00:00Z',
                'relationship_type': rel, 'user_goal_value': goal,
                'blocked_at': rng.choice(BLOCKED),
                'n_turns': rng.randrange(2, 8), 'n_difficult_turns': rng.randrange(1, 3),
                'seconds_to_complete': rng.randrange(140, 480),
                'clarifying_questions': rng.choice([2, 2, 3, 3, 4]),
                'user_edits': rng.choice([0, 0, 0, 1, 1, 2]),
                'unknown_fields': '|'.join(unk),
                'redaction_hits': hits,
                'manual_pii_removals': rng.choice([0, 0, 0, 1]),
                'pii_review_failures': 0,
            })
            # 후속 · 대략 일치하되 일부는 흔들린다
            if rng.random() < 0.85:
                r2 = rel if rng.random() < 0.85 else rng.choice(REL)
                g2 = goal if rng.random() < 0.7 else rng.choice(GOAL)
                follows.append({
                    'event_id': e_id, 'participant_id': pid,
                    'asked_at': f'2026-09-{15 + pi:02d}T19:00:00Z',
                    'relationship_type_followup': r2,
                    'user_goal_value_followup': g2,
                    'note': '',
                })

    with io.open(os.path.join(HERE, 'synthetic_events.csv'), 'w', encoding='utf-8', newline='') as f:
        w = csv.DictWriter(f, EVENT_COLS)
        w.writeheader()
        w.writerows(events)
    with io.open(os.path.join(HERE, 'synthetic_followups.csv'), 'w', encoding='utf-8', newline='') as f:
        w = csv.DictWriter(f, FOLLOW_COLS)
        w.writeheader()
        w.writerows(follows)
    with io.open(os.path.join(HERE, 'synthetic_events.json'), 'w', encoding='utf-8') as f:
        json.dump({'note': 'DEMO 데이터다. 사람에게서 받은 것이 아니다. 원문 없음.',
                   'seed': SEED, 'events': events, 'followups': follows},
                  f, ensure_ascii=False, indent=2)

    print(f'DEMO 데이터 · 참가자 {n_participants}명 · 사건 {len(events)}건 · 후속 {len(follows)}건 · seed {SEED}')
    print('  원문은 만들지 않았다. 사용성 수치와 선택지 값만 있다.')


if __name__ == '__main__':
    main()
