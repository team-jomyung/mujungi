"""POC C · 파일럿 결과를 센다.

    python analyze_pilot.py events.csv --followup followup.csv --out results/

frozen_spec_v0_1 §11.3 · §11.4 를 따른다.

원칙 넷
  1. 개인 원문을 report 에 출력하지 않는다
  2. 5~10명이므로 비율 추정을 하지 않는다. 세기만 한다
  3. goal 일관성에 문턱을 걸지 않는다. 중단 트리거만 본다
  4. context 는 자유 서술이라 정량 비교하지 않는다
"""
from __future__ import annotations

import argparse
import csv
import io
import json
import os
import statistics as st
from collections import Counter, defaultdict

# §11.4 · 전부 프로젝트 운영 기준이다. 문헌 근거가 아니다.
THRESHOLDS = {
    'seconds_to_complete_median': {'pass': 300, 'retry': 600, 'basis': 'operational'},
    'clarifying_questions_median': {'pass': 3, 'retry': 5, 'basis': 'operational'},
}
GOAL_TRIGGER = 0.5  # 불일치가 절반을 넘으면 중단 트리거. 문턱이 아니다.

PII_FORBIDDEN_IN_REPORT = ('sanitized_input', 'raw_input', 'event_text', 'utterance')


def read(path):
    if not path or not os.path.exists(path):
        return []
    with io.open(path, encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))


def num(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def med(xs):
    xs = [x for x in xs if x is not None]
    return st.median(xs) if xs else None


def analyze(events, followups):
    r = {}
    r['n_participants'] = len({e.get('participant_id') for e in events if e.get('participant_id')})
    r['n_events'] = len(events)
    r['events_per_participant'] = dict(Counter(e.get('participant_id') for e in events))

    secs = [num(e.get('seconds_to_complete')) for e in events]
    qs = [num(e.get('clarifying_questions')) for e in events]
    r['seconds_to_complete'] = {'median': med(secs), 'min': min([s for s in secs if s is not None], default=None),
                                'max': max([s for s in secs if s is not None], default=None),
                                'n': len([s for s in secs if s is not None])}
    r['clarifying_questions'] = {'median': med(qs), 'max': max([q for q in qs if q is not None], default=None)}

    edited = [e for e in events if num(e.get('user_edits')) and num(e.get('user_edits')) > 0]
    r['user_edit'] = {'events_with_edit': len(edited), 'total': len(events),
                      'note': '비율 추정을 하지 않는다. 건수로 읽는다'}

    unk = Counter()
    for e in events:
        for f in (e.get('unknown_fields') or '').split('|'):
            if f.strip():
                unk[f.strip()] += 1
    for fld, col in (('relationship_type', 'relationship_type'),
                     ('user_goal_claim', 'user_goal_value')):
        n = sum(1 for e in events if (e.get(col) or '').strip().upper() == 'UNKNOWN')
        if n:
            unk[fld] = max(unk[fld], n)
    r['unknown_counts'] = dict(unk)
    r['unknown_note'] = 'user_goal_claim 의 UNKNOWN 은 오류가 아니다. 정당한 답이다'

    hits = [num(e.get('redaction_hits')) for e in events]
    r['redaction'] = {
        'total_hits': int(sum([h for h in hits if h is not None])) if any(h is not None for h in hits) else None,
        'events_with_hits': len([h for h in hits if h]),
        'manual_removals': int(sum(num(e.get('manual_pii_removals')) or 0 for e in events)),
        'post_review_failures': int(sum(num(e.get('pii_review_failures')) or 0 for e in events)),
    }
    r['redaction']['note'] = ('post_review_failures 가 0 이 아니면 두 관문을 다 통과해 버린 것이다. '
                              '그 자체를 파일럿 결과로 보고한다')

    # 자기보고 일관성
    first = {}
    for e in events:
        eid = e.get('event_id')
        if eid:
            first[eid] = {'relationship': (e.get('relationship_type') or '').strip().upper(),
                          'goal': (e.get('user_goal_value') or '').strip().upper()}
    cons = {'relationship': {'match': 0, 'mismatch': 0, 'missing': 0, 'pairs': []},
            'goal': {'match': 0, 'mismatch': 0, 'missing': 0, 'pairs': []}}
    for f in followups:
        eid = f.get('event_id')
        if eid not in first:
            continue
        for key, col in (('relationship', 'relationship_type_followup'),
                         ('goal', 'user_goal_value_followup')):
            later = (f.get(col) or '').strip().upper()
            early = first[eid][key]
            if not later or not early:
                cons[key]['missing'] += 1
                continue
            if later == early:
                cons[key]['match'] += 1
            else:
                cons[key]['mismatch'] += 1
                cons[key]['pairs'].append({'event_id': eid, 'first': early, 'later': later})
    for key in cons:
        m, x = cons[key]['match'], cons[key]['mismatch']
        cons[key]['n_compared'] = m + x
        cons[key]['mismatch_fraction'] = (x / (m + x)) if (m + x) else None
    r['self_report_consistency'] = cons
    r['context_consistency'] = {
        'computed': False,
        'reason': '자유 서술이라 정량 일치율을 억지로 내지 않는다. 서술로만 기록한다(§11.3)',
    }

    miss = defaultdict(int)
    for e in events:
        for k, v in e.items():
            if v is None or str(v).strip() == '':
                miss[k] += 1
    r['missing_by_column'] = dict(sorted(miss.items(), key=lambda kv: -kv[1]))

    r['triggers'] = []
    gm = cons['goal']['mismatch_fraction']
    if gm is not None and gm > GOAL_TRIGGER:
        r['triggers'].append({
            'name': 'goal_self_report_inconsistency',
            'value': gm,
            'action': ('검증을 멈추고 설계를 다시 본다. 목표를 묻는 방식을 바꾸거나 '
                       '개인화 축을 관찰 가능한 행동으로 옮긴다(§11.4)'),
        })
    if r['redaction']['post_review_failures'] > 0:
        r['triggers'].append({
            'name': 'pii_leak_after_review',
            'value': r['redaction']['post_review_failures'],
            'action': 'PII 규칙과 확인 화면을 고치기 전에는 파일럿을 이어가지 않는다',
        })
    return r


def decide(r):
    d = {'per_criterion': {}, 'verdict': None, 'notes': []}
    s = r['seconds_to_complete']['median']
    T = THRESHOLDS['seconds_to_complete_median']
    d['per_criterion']['seconds_to_complete_median'] = {
        'value': s,
        'result': 'NA' if s is None else ('PASS' if s <= T['pass'] else ('RETRY' if s <= T['retry'] else 'FAIL')),
        'basis': T['basis']}
    q = r['clarifying_questions']['median']
    T = THRESHOLDS['clarifying_questions_median']
    d['per_criterion']['clarifying_questions_median'] = {
        'value': q,
        'result': 'NA' if q is None else ('PASS' if q <= T['pass'] else ('RETRY' if q <= T['retry'] else 'FAIL')),
        'basis': T['basis']}
    d['per_criterion']['goal_self_report_consistency'] = {
        'value': r['self_report_consistency']['goal']['mismatch_fraction'],
        'result': 'TRIGGER' if any(t['name'] == 'goal_self_report_inconsistency' for t in r['triggers']) else 'NO_TRIGGER',
        'basis': 'operational · 트리거이지 문턱이 아니다',
        'note': '5~10명으로는 비율을 추정할 수 없으므로 통과·실패를 가르지 않는다'}

    if r['triggers']:
        d['verdict'] = 'STOP_TRIGGER'
    elif any(v.get('result') == 'FAIL' for v in d['per_criterion'].values()):
        d['verdict'] = 'USABILITY_FAIL'
    elif any(v.get('result') == 'RETRY' for v in d['per_criterion'].values()):
        d['verdict'] = 'USABILITY_RETRY'
    else:
        d['verdict'] = 'NO_STOP_TRIGGER'
    d['notes'] = [
        'C 는 feasibility 확인이다. 가설 검정이 아니다',
        '임상 효과나 SCD 개선을 말하지 않는다',
        '참가자가 5~10명이므로 어떤 비율도 모집단으로 일반화하지 않는다',
    ]
    return d


def render(r, d, demo=False):
    L = []
    if demo:
        L += ['', '#' * 60, '#  DEMO ONLY · 샘플 데이터다. 검증 결과가 아니다.', '#' * 60]
    L += ['', '=' * 60, 'POC C · 개인 사건 수집 파일럿', '=' * 60,
          f"참가자 {r['n_participants']}명 · 사건 {r['n_events']}건", '',
          '── 사용성 ' + '─' * 48]
    s = r['seconds_to_complete']
    L.append(f"  최초 입력 시간 중앙값 · {s['median']}초" if s['median'] is not None else '  입력 시간 · 데이터 없음')
    if s['median'] is not None:
        L.append(f"    범위 {s['min']}~{s['max']}초 · n={s['n']}")
    L.append(f"  확인 질문 수 중앙값 · {r['clarifying_questions']['median']}개")
    L.append(f"  추출 결과를 고친 사건 · {r['user_edit']['events_with_edit']}/{r['user_edit']['total']}건")

    L += ['', '── UNKNOWN ' + '─' * 47]
    if r['unknown_counts']:
        for k, v in sorted(r['unknown_counts'].items(), key=lambda kv: -kv[1]):
            L.append(f"  {k:<24} {v}건")
    else:
        L.append('  없음')
    L.append(f"  · {r['unknown_note']}")

    L += ['', '── 개인정보 ' + '─' * 46,
          f"  규칙이 잡은 건수 · {r['redaction']['total_hits']}",
          f"  사용자가 확인 화면에서 더 지운 건수 · {r['redaction']['manual_removals']}",
          f"  저장 후 검토에서 그래도 남은 건수 · {r['redaction']['post_review_failures']}",
          f"  · {r['redaction']['note']}"]

    L += ['', '── 자기보고 일관성 · 24~72시간 뒤 ' + '─' * 25]
    for key, label in (('relationship', '관계'), ('goal', '목표')):
        c = r['self_report_consistency'][key]
        if c['n_compared']:
            L.append(f"  {label} · 일치 {c['match']} · 불일치 {c['mismatch']} · 비교 {c['n_compared']}건")
        else:
            L.append(f"  {label} · 비교할 후속 응답이 없다")
    L.append(f"  맥락 · 계산하지 않음 · {r['context_consistency']['reason']}")

    if r['missing_by_column']:
        L += ['', '── 결측 상위 ' + '─' * 46]
        for k, v in list(r['missing_by_column'].items())[:6]:
            L.append(f"  {k:<28} {v}건")

    L += ['', '=' * 60, f"판정 · {d['verdict']}", '=' * 60]
    for k, v in d['per_criterion'].items():
        val = v.get('value')
        val = f"{val:.2f}" if isinstance(val, float) else val
        L.append(f"  {v['result']:<12} {k} = {val}   [{v['basis']}]")
        if v.get('note'):
            L.append(f"               · {v['note']}")
    if r['triggers']:
        L += ['', '  ** 중단 트리거 **']
        for t in r['triggers']:
            L.append(f"   - {t['name']} = {t['value']}")
            L.append(f"     {t['action']}")
    L += ['', '  기억할 것']
    L += [f'   · {n}' for n in d['notes']]
    if demo:
        L += ['', '#' * 60, '#  다시 적는다 · DEMO ONLY.', '#' * 60]
    return '\n'.join(L)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('events')
    ap.add_argument('--followup', default=None)
    ap.add_argument('--out', default='results')
    ap.add_argument('--demo', action='store_true')
    args = ap.parse_args()

    events = read(args.events)
    followups = read(args.followup)

    for e in events:
        for bad in PII_FORBIDDEN_IN_REPORT:
            if bad in e:
                print(f'[경고] 입력에 원문 열 {bad!r} 이 있다. 리포트에 출력하지 않는다.')
                break

    r = analyze(events, followups)
    d = decide(r)
    txt = render(r, d, demo=args.demo)
    print(txt)

    os.makedirs(args.out, exist_ok=True)
    with io.open(os.path.join(args.out, 'pilot_report.txt'), 'w', encoding='utf-8') as f:
        f.write(txt + '\n')
    payload = dict(r)
    payload['decision'] = d
    payload['demo_only'] = bool(args.demo)
    # 개인 원문이 섞이지 않도록 한 번 더 거른다
    for k in list(payload.keys()):
        if any(bad in k for bad in PII_FORBIDDEN_IN_REPORT):
            payload.pop(k)
    with io.open(os.path.join(args.out, 'pilot_report.json'), 'w', encoding='utf-8') as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
    print(f'\n저장 · {args.out}/pilot_report.txt · .json')


if __name__ == '__main__':
    main()
