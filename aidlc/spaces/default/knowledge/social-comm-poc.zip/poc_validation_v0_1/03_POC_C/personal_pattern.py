"""개인 패턴 집계 · frozen_spec_v0_1 §8.2 를 코드로 옮긴 것.

**사람을 규정하는 Trait 를 만들지 않는다.**

금지 ·  UserA → cannot_understand → indirect_refusal
허용 ·  최근 8개 관련 사건에서 단서 노출 5회 · 고려 2회 · 명료화 1회

모든 지표는 **사건 참조로 저장**한다. 사건을 지우면 지표가 줄어든다.

    from personal_pattern import aggregate
    aggregate(events)
"""
from __future__ import annotations

from collections import Counter, defaultdict

MIN_SAMPLE = {
    'cue_consideration_rate': 3,
    'interpretation_diversity': 3,
    'clarification_rate': 3,
    'strategy_distribution': 3,
    'recent_trend': 16,          # 각 구간 8건 이상(§8.2)
    'confidence_calibration': 5,
}

# §8.2 · 사용자에게 보여도 되는가 · 추천에 써도 되는가
VISIBILITY = {
    'exposure_count':            {'user_visible': True,  'recommendation': True},
    'cue_consideration_rate':    {'user_visible': True,  'recommendation': True},
    'interpretation_diversity':  {'user_visible': True,  'recommendation': True},
    'clarification_rate':        {'user_visible': True,  'recommendation': True},
    'strategy_distribution':     {'user_visible': True,  'recommendation': True},
    'repeated_pattern_count':    {'user_visible': True,  'recommendation': True},
    'recent_trend':              {'user_visible': 'conditional', 'recommendation': True,
                                  'condition': '각 구간 8건 이상일 때만'},
    'confidence_calibration':    {'user_visible': False, 'recommendation': True,
                                  'reason': '"당신은 확신할 때 자주 틀립니다"로 읽힌다'},
    'last_practiced':            {'user_visible': True,  'recommendation': True},
}


def _rate(num, den, key, event_ids):
    """분모를 항상 함께 돌려준다. 3건 중 2건과 30건 중 20건은 다른 정보다."""
    ok = den >= MIN_SAMPLE.get(key, 1)
    return {
        'numerator': num, 'denominator': den,
        'value': (num / den) if den else None,
        'reportable': ok,
        'min_sample': MIN_SAMPLE.get(key, 1),
        'event_ids': event_ids,
    }


def aggregate(events, recent_n=8):
    """events · 사건 리스트. 각 사건은 최소 event_id 와 signature 를 갖는다."""
    events = [e for e in events if e.get('event_id')]
    ev_by_sig = defaultdict(list)
    for e in events:
        ev_by_sig[e.get('signature') or 'UNKNOWN'].append(e)

    out = {
        'n_events': len(events),
        'event_ids': [e['event_id'] for e in events],
        'visibility': VISIBILITY,
        'note': ('사건 기반 집계다. 사람을 규정하는 값이 아니다. '
                 '사건을 지우면 재계산된다.'),
    }

    # 1 노출 횟수 · 같은 불변항을 가진 사건 수
    out['exposure_count'] = {sig: len(v) for sig, v in ev_by_sig.items()}
    out['exposure_event_ids'] = {sig: [e['event_id'] for e in v] for sig, v in ev_by_sig.items()}

    # 2 단서 고려율 · 해당 단서를 언급한 사건 ÷ 그 단서가 있던 사건
    has_cue = [e for e in events if e.get('cue_considered') is not None]
    considered = [e for e in has_cue if e.get('cue_considered')]
    out['cue_consideration_rate'] = _rate(
        len(considered), len(has_cue), 'cue_consideration_rate',
        [e['event_id'] for e in has_cue])

    # 3 해석 다양성 · 사건당 해석 수의 중앙값
    ints = sorted(int(e['interpretations']) for e in events if e.get('interpretations') is not None)
    median = None
    if ints:
        m = len(ints) // 2
        median = ints[m] if len(ints) % 2 else (ints[m - 1] + ints[m]) / 2
    out['interpretation_diversity'] = {
        'median': median, 'denominator': len(ints),
        'reportable': len(ints) >= MIN_SAMPLE['interpretation_diversity'],
        'min_sample': MIN_SAMPLE['interpretation_diversity'],
        'event_ids': [e['event_id'] for e in events if e.get('interpretations') is not None],
    }

    # 4 명료화 발생률
    needed = [e for e in events if e.get('clarification') is not None]
    did = [e for e in needed if e.get('clarification')]
    out['clarification_rate'] = _rate(
        len(did), len(needed), 'clarification_rate', [e['event_id'] for e in needed])

    # 5 전략 분포
    strat = Counter(e['strategy'] for e in events if e.get('strategy'))
    out['strategy_distribution'] = {
        'counts': dict(strat), 'denominator': sum(strat.values()),
        'reportable': sum(strat.values()) >= MIN_SAMPLE['strategy_distribution'],
        'event_ids': [e['event_id'] for e in events if e.get('strategy')],
    }

    # 6 반복 패턴 수 · 같은 불변항이 3회 이상 나온 서명 수
    rep = {s: len(v) for s, v in ev_by_sig.items() if len(v) >= 3}
    out['repeated_pattern_count'] = {
        'count': len(rep), 'signatures': rep,
        'event_ids': [e['event_id'] for s in rep for e in ev_by_sig[s]],
    }

    # 7 최근 추세 · 최근 8건과 그 이전 8건. 각 8건 이상일 때만 보고
    ordered = sorted([e for e in events if e.get('timestamp')], key=lambda e: e['timestamp'])
    recent, prior = ordered[-recent_n:], ordered[-2 * recent_n:-recent_n]

    def _cue_rate(sub):
        h = [e for e in sub if e.get('cue_considered') is not None]
        return (sum(1 for e in h if e['cue_considered']) / len(h)) if h else None
    r_now, r_prev = _cue_rate(recent), _cue_rate(prior)
    out['recent_trend'] = {
        'recent_n': len(recent), 'prior_n': len(prior),
        'recent_cue_rate': r_now, 'prior_cue_rate': r_prev,
        'delta': (r_now - r_prev) if (r_now is not None and r_prev is not None) else None,
        'reportable': len(recent) >= recent_n and len(prior) >= recent_n,
        'min_sample': MIN_SAMPLE['recent_trend'],
        'caution': '표본이 적으면 우연이 변화로 보인다. 각 구간 8건 이상일 때만 보여 준다',
        'event_ids': [e['event_id'] for e in recent + prior],
    }

    # 8 확신 보정 · 확신 높았는데 틀린 비율. 사용자에게 보여주지 않는다
    conf = [e for e in events if e.get('confidence') == 'HIGH' and e.get('outcome_match') is not None]
    wrong = [e for e in conf if not e['outcome_match']]
    out['confidence_calibration'] = _rate(
        len(wrong), len(conf), 'confidence_calibration', [e['event_id'] for e in conf])
    out['confidence_calibration']['user_visible'] = False

    # 9 마지막 연습 시점
    out['last_practiced'] = {
        sig: max((e.get('last_practiced') or e.get('timestamp') or '') for e in v) or None
        for sig, v in ev_by_sig.items()}

    return out


def delete_event(events, event_id):
    """사건 삭제 · 집계를 재계산해 돌려준다."""
    remaining = [e for e in events if e.get('event_id') != event_id]
    return remaining, aggregate(remaining)


if __name__ == '__main__':
    import json
    demo = [
        {'event_id': f'E{i}', 'signature': 'sig-a' if i % 2 else 'sig-b',
         'cue_considered': i % 3 != 0, 'interpretations': 1 + i % 3,
         'clarification': i % 4 == 0, 'strategy': ['ASK', 'GUESS', 'WAIT'][i % 3],
         'timestamp': f'2026-09-{i+1:02d}', 'confidence': 'HIGH' if i % 2 else 'LOW',
         'outcome_match': i % 5 != 0}
        for i in range(20)
    ]
    a = aggregate(demo)
    print('사건', a['n_events'], '· 노출', a['exposure_count'])
    print('단서 고려율', a['cue_consideration_rate']['value'],
          '분모', a['cue_consideration_rate']['denominator'])
    print('최근 추세 보고 가능', a['recent_trend']['reportable'])
    rem, a2 = delete_event(demo, 'E0')
    print('E0 삭제 후 사건', a2['n_events'], '· 노출', a2['exposure_count'])
