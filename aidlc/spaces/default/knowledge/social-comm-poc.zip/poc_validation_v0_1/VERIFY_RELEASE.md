# VERIFY RELEASE · RC1

생성 2026-09-14 12:45:24

받은 사람이 **직접** 확인하는 절차다. 이 문서의 주장을 믿지 말고 돌려 본다.

## 0 · 한 줄로

```
cd poc_validation_v0_1
python poc.py verify-release --zip ../poc_validation_v0_1_RC1.zip
```

여덟 항목이 전부 `ok` 여야 한다. 하나라도 실패하면 exit 1 이다. 아래 1~7 은 같은 것을 손으로 따라가는 절차다.

8번 `숫자 · 인터페이스` 는 체크섬이 못 잡는 것을 본다. 파일은 온전한데 문서끼리 쌍 수가 다르거나, 선별기가 내려 주는 파일 이름과 `poc.py` 가 찾는 이름이 다른 경우다(ERR-04 · ERR-05).

## 1 · 풀기

```
unzip poc_validation_v0_1_RC1.zip
cd poc_validation_v0_1
```

## 2 · 해시 확인

```
cd poc_validation_v0_1
sha256sum -c SHA256SUMS.txt
```

**102줄이 전부 맞아야 한다.** 덮는 범위는 아래와 같다.

| | 수 |
|---|---|
| 패키지 안 일반 파일 | 99 |
| `RELEASE_MANIFEST.json` · `.md` | 2 |
| `../RC1_HANDOFF_FINAL.html` · ZIP 최상위 표지 | 1 |
| **합 · SHA256-covered** | **102** |

덮지 못한 것은 `SHA256SUMS.txt` 하나뿐이다. 자기 해시를 자기 안에 담을 수 없다.
표지 줄이 `../` 로 시작하므로 **패키지 폴더 안에서** 돌려야 한다.

Windows PowerShell 이면

```
Get-Content SHA256SUMS.txt | ForEach-Object {
  $h,$p = $_ -split '  ',2
  $a = (Get-FileHash $p -Algorithm SHA256).Hash.ToLower()
  if ($a -ne $h) { "MISMATCH $p" }
}
```

아무것도 안 나오면 전부 맞은 것이다.

## 3 · 시험

```
python poc.py test
```

네 가지가 통과해야 한다.

| 무엇 | 통과 기준 |
|---|---|
| 단위 시험 | `Ran N tests` · `OK` · 실패 0 |
| 문서 감사 | `지적 0건` |
| 누출 검사 | `지적 0건` 또는 `건너뜀` |
| 숫자 · 인터페이스 일치 | `판정 · 통과` |

누출 검사가 `건너뜀` 이면 `python poc.py bundles` 를 먼저 돌린다.

## 4 · 상태

```
python poc.py status
```

`있어야 할 것` 여덟 줄이 전부 `ok` 여야 한다.

## 5 · DEMO 재현

```
python 02_POC_A/analyze_agreement.py 02_POC_A/sample_rater_A.csv 02_POC_A/sample_rater_B.csv --out /tmp/chk --demo
```

이해 κ 0.519 · 수행 κ 0.614 가 나와야 한다.

**같은 숫자가 나온다는 것은 생성기가 씨앗 고정이라는 뜻이지,
이 숫자가 무엇을 검증한다는 뜻이 아니다.** 전부 DEMO 다.

## 6 · 개인정보 시험

```
cd 03_POC_C
python -m http.server 8765 --bind 127.0.0.1
```

브라우저에서 `http://localhost:8765/privacy_test.html` · **전체 실행**

**87건이 각자 기대한 분류와 맞아야 한다.** 내역은 다음과 같다.

| 등급 | 기대 | 뜻 |
|---|---|---|
| `PASS` | 74 | 회귀 통과 |
| `DEFECT` | 3 | `W06` `Y01` `Y02` · I-06 I-07 I-08 |
| `ACCEPT` | 6 | `Z01`~`Z06` · 알고 허용한 과잉 삭제 |
| `LIMIT` | 4 | `K01`~`K04` · 정규식이 원리상 못 함 |
| `STALE` | 0 | 메타데이터가 실제 동작과 어긋난 것 |

`STALE` 이 0이 아니면 시험 파일의 메타데이터가 실제 동작과 어긋난 것이다.

**87건이 맞았다는 것은 짜 둔 시험이 기대대로 나왔다는 뜻이다.**
`87건 통과` · `탐지 정확도 100%` · `PII 제거 검증 완료` 로 옮겨 적지 않는다.
DEFECT 3건과 LIMIT 4건은 지금도 막지 못하는 입력이고 `KNOWN_ISSUES.md` 에 번호로 적혀 있다.

## 7 · 꾸러미

```
python poc.py bundles
```

**역할 7개 폴더가 나오고** 누출 검사가 `지적 0건` 이어야 한다.

배포용 ZIP 은 **6개**다. 수가 다른 이유는 하나다.

```
역할 번들            7   admin · blind_selector · rater_A · rater_B
                         poc_c_operator · poc_c_participant · expert_review
배포용 role ZIP    - 6   admin 을 뺀 여섯
                    ---
admin                1   별도 ZIP 이 아니다. RC1 root 그 자체다
```

`admin` 은 패키지 전체 사본이므로 따로 압축하지 않는다.
운영자는 `poc_validation_v0_1_RC1.zip` 을 그대로 쓴다.

`rater_A` 와 `rater_B` 는 `판정할 쌍 파일이 아직 없다` 고 경고한다. **정상이다.**
선별된 blind 40쌍(H-02)이 아직 없기 때문이다.

## 확인해도 알 수 없는 것

위를 다 통과해도 **POC 는 아무것도 검증하지 않았다.**
사람 판정자가 아직 한 쌍도 보지 않았고 참가자가 아직 한 명도 없다.
`KNOWN_ISSUES.md` 의 `검증되지 않은 것` 을 읽는다.
