# Generator Prompt · 시나리오 변형 생성

> **Generator 는 자기 출력을 판정하지 않는다.** 등급을 스스로 정하지 않고, 목표 등급에 맞게 만들려고만 한다. 판정은 validator 와 규칙과 사람이 한다.

## 입력

```json
{
  "seed": {
    "id": "S1",
    "invariant_sentence": "상대가 껄끄러운 말을 돌려서 했다",
    "core": {
      "target_skill": "RECOGNIZE",
      "required_inference": "말하지 않은 부분을 맥락으로 채우기",
      "perspective_structure": "상대의 의도 1층",
      "decidable_by_evidence": "YES",
      "direct_check_allowed": "YES"
    },
    "base_context": {
      "relationship_type": "FRIEND_CASUAL",
      "situation_type": "FRIEND_PRIVATE",
      "misread_cost": "LOW",
      "recoverable": true
    }
  },
  "target_grade": "NEAR"
}
```

## 절대 규칙 · 등급과 무관

| | |
|---|---|
| **core 다섯을 그대로 유지한다** | 하나라도 바뀌면 다른 기술이 된다 |
| **표면 문장을 반드시 바꾼다** | 같으면 암기를 훈련하게 된다 |
| **한국의 청소년·이십대 상황으로 쓴다** | |
| **실명·연락처·학교명·회사명을 쓰지 않는다** | 전부 지어낸다 |
| **상대의 속마음을 단정하지 않는다** | "사실 걔는 귀찮았던 것이다" 금지 |
| **정답이나 해설을 붙이지 않는다** | |
| 자살·자해·성적 내용·혐오 표현 금지 | |

## 등급별 지시

### SAME_CONTEXT

바꾸는 것 · **화제 · 장소 · 등장인물 · 표면 문장**
그대로 두는 것 · **관계 유형 · 상황 종류 · 오판의 대가 · 되돌릴 수 있는 정도**

> 같은 사이의 같은 종류 자리에서, 다른 이야기로 같은 일이 벌어지게 쓴다.

### NEAR

바꾸는 것 · 위의 것 + **관계 유형 또는 상황 종류 중 하나**
그대로 두는 것 · **오판의 대가 · 되돌릴 수 있는 정도**

> 상대나 자리의 종류를 바꾸되 **잘못 짚었을 때의 대가는 비슷하게** 둔다.
> 대놓고 물어봐도 되는 정도가 `direct_check_allowed` 값과 어긋나면 안 된다.

### FAR

바꾸는 것 · 위의 것 + **오판의 대가 또는 되돌릴 수 있는 정도**
그대로 두는 것 · **core 다섯만**

> 관계도 자리도 크게 바꾸고 **잘못 짚으면 손해가 커지게** 만든다.
> 단 알아채야 하는 일 자체는 그대로다.

**FAR 에서 가장 흔한 실패** · 표면을 많이 바꾸라는 지시를 구조까지 바꾸는 것으로 읽는 것이다. `required_inference` 와 `perspective_structure` 는 손대지 않는다.

## 출력 · JSON 만

```json
{
  "dialogue": [
    {"speaker": "OTHER", "text": "..."},
    {"speaker": "SELF", "text": "..."},
    {"speaker": "OTHER", "text": "..."}
  ],
  "narration": "무슨 자리였고 내가 어디서 막혔는지 2~3문장",
  "context": {
    "relationship_type": "CLUB_SENIOR",
    "situation_type": "CLUB",
    "misread_cost": "LOW",
    "recoverable": true,
    "topic": "전시 준비",
    "place": "동아리방"
  },
  "intended_core": {
    "target_skill": "RECOGNIZE",
    "required_inference": "말하지 않은 부분을 맥락으로 채우기",
    "perspective_structure": "상대의 의도 1층",
    "decidable_by_evidence": "YES",
    "direct_check_allowed": "NO"
  },
  "intended_grade": "NEAR",
  "what_changed": ["relationship_type", "topic", "place"]
}
```

`intended_core` 는 **seed 의 core 를 그대로 옮겨 적는다.** 바꿔 적지 않는다. 다만 `direct_check_allowed` 는 새 관계에 맞게 다시 판단해 적는다. 그것이 바뀌면 수행 단계에서 다른 과제가 되는데, **그것은 NEAR 나 FAR 에서 일어날 수 있는 정상 결과**다.

설명이나 주석을 붙이지 않는다. **JSON 만 출력한다.**
