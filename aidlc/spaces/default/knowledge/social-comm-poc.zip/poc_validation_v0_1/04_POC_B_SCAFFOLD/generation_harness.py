"""POC B · 시나리오 생성 배관.

    python generation_harness.py --dry-run          provider 없이 배관만 확인
    python generation_harness.py --provider echo    같음
    python generation_harness.py --provider openai  실제 호출 · 환경변수 필요

    seed → generator → validator → rule check → 통과하면 candidate
                                              → 실패하면 regenerate (시도 횟수 기록)

원칙
  - 생성 모델과 판정 모델을 분리한다
  - validator 는 pre-filter 일 뿐이고 공식 기준은 사람이다
  - API 키를 코드에 넣지 않는다. 환경변수에서만 읽는다
  - A 가 통과하기 전에는 공식 결과를 만들지 않는다
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', '02_POC_A'))
from rule_engine import skill_identity, transfer_distance, SAME  # noqa: E402

GRADES = ('SAME_CONTEXT', 'NEAR', 'FAR')
MAX_ATTEMPTS = 5


# ─────────────────── provider adapter ───────────────────

class LLMProvider:
    """공급자 인터페이스. 특정 벤더에 묶지 않는다."""
    name = 'base'

    def generate(self, prompt: str, **kw) -> str:
        raise NotImplementedError

    def validate(self, prompt: str, **kw) -> str:
        raise NotImplementedError


class EchoProvider(LLMProvider):
    """배관 확인용. 모델을 부르지 않고 규격에 맞는 껍데기를 돌려준다.

    이것으로 만든 결과는 시나리오가 아니다. 성능을 말하지 않는다.
    """
    name = 'echo'

    def __init__(self, fail_every=3):
        self.n = 0
        self.fail_every = fail_every

    def generate(self, prompt, **kw):
        self.n += 1
        seed = kw.get('seed', {})
        grade = kw.get('grade', 'NEAR')
        core = dict(seed.get('core', {}))
        ctx = dict(seed.get('base_context', {}))
        # 일부러 가끔 구조를 깬다. 재시도 경로를 확인하려고
        broken = (self.n % self.fail_every == 0)
        if broken:
            core['required_inference'] = core.get('required_inference', '') + ' (다른 추론)'
        if grade in ('NEAR', 'FAR'):
            ctx['relationship_type'] = 'CLUB_SENIOR' if ctx.get('relationship_type') != 'CLUB_SENIOR' else 'SUPERVISOR'
        if grade == 'FAR':
            ctx['misread_cost'] = 'HIGH'
            ctx['recoverable'] = False
        return json.dumps({
            'dialogue': [
                {'speaker': 'OTHER', 'text': f'[echo · {seed.get("id")} · {grade}] 상대 발화'},
                {'speaker': 'SELF', 'text': '[echo] 내 발화'},
            ],
            'context': ctx,
            'intended_core': core,
            'intended_grade': grade,
            '_echo': True, '_broken_on_purpose': broken,
        }, ensure_ascii=False)

    def validate(self, prompt, **kw):
        cand = kw.get('candidate', {})
        seed = kw.get('seed', {})
        core_s, core_c = seed.get('core', {}), cand.get('intended_core', {})
        cmp_ = {k: (SAME if core_s.get(k) == core_c.get(k) else 'DIFFERENT')
                for k in ('target_skill', 'required_inference',
                          'perspective_structure', 'decidable_by_evidence',
                          'direct_check_allowed')}
        return json.dumps({'field_comparison': cmp_, 'reason': 'echo provider',
                           'confidence': 0.0, '_echo': True}, ensure_ascii=False)


class HTTPProvider(LLMProvider):
    """실제 공급자용 틀. 키는 환경변수에서만 읽는다.

    env_key 예 · ANTHROPIC_API_KEY · OPENAI_API_KEY
    실제 호출부는 팀이 채운다. 여기서는 벤더 SDK 를 import 하지 않는다.
    """
    def __init__(self, name, env_key, model):
        self.name = name
        self.model = model
        self.api_key = os.environ.get(env_key)
        if not self.api_key:
            raise RuntimeError(
                f'{env_key} 환경변수가 없다. 키를 코드나 파일에 적지 않는다.')

    def generate(self, prompt, **kw):
        raise NotImplementedError(
            'TODO · 팀이 채운다. 벤더 SDK 를 여기서 import 한다. '
            '생성 모델과 판정 모델을 다르게 지정할 것.')

    def validate(self, prompt, **kw):
        raise NotImplementedError('TODO · 팀이 채운다.')


def make_provider(name):
    if name in (None, 'echo', 'dry'):
        return EchoProvider()
    if name == 'anthropic':
        return HTTPProvider('anthropic', 'ANTHROPIC_API_KEY', 'claude-opus-5')
    if name == 'openai':
        return HTTPProvider('openai', 'OPENAI_API_KEY', 'gpt-4o')
    raise SystemExit(f'모르는 provider · {name}')


# ─────────────────── 규칙 검사 ───────────────────

def rule_check(seed, candidate, validator_out, target_grade):
    """validator 의 필드 비교를 규격 규칙에 넣어 등급을 낸다.

    validator 가 등급을 정하지 않는다. 필드만 비교하고 등급은 규칙이 정한다.
    """
    cmp_ = validator_out.get('field_comparison', {})
    base = dict(seed.get('base_context', {}))
    new = dict(candidate.get('context', {}))

    def changed(a, b):
        return 'CHANGED' if a != b else 'SAME'

    ann = dict(cmp_)
    ann.setdefault('target_skill', 'UNKNOWN')
    ann['relationship_changed'] = changed(base.get('relationship_type'), new.get('relationship_type'))
    ann['situation_type_changed'] = changed(base.get('situation_type'), new.get('situation_type'))
    ann['misread_cost_changed'] = changed(base.get('misread_cost'), new.get('misread_cost'))
    ann['recoverability_changed'] = changed(base.get('recoverable'), new.get('recoverable'))
    ann['topic_changed'] = 'CHANGED'
    ann['place_changed'] = 'CHANGED'
    ann['participants_changed'] = 'CHANGED'

    si_u = skill_identity(ann, 'understand')
    si_p = skill_identity(ann, 'perform')
    dist = transfer_distance(ann, si_u)

    ok = (si_u == SAME and dist == target_grade)
    reasons = []
    if si_u != SAME:
        reasons.append(f'SkillIdentity(이해)={si_u} · Core 가 보존되지 않았다')
    elif dist != target_grade:
        reasons.append(f'거리 {dist} · 목표 {target_grade}')
    return {'accepted': ok, 'skill_identity_understand': si_u,
            'skill_identity_perform': si_p, 'transfer_distance': dist,
            'reasons': reasons, 'annotation': ann}


# ─────────────────── 본체 ───────────────────

def run(seeds, provider, per_grade=3, max_attempts=MAX_ATTEMPTS, out_dir='b_output'):
    gen_prompt = open(os.path.join(HERE, 'generator_prompt.md'), encoding='utf-8').read() \
        if os.path.exists(os.path.join(HERE, 'generator_prompt.md')) else ''
    val_prompt = open(os.path.join(HERE, 'validator_prompt.md'), encoding='utf-8').read() \
        if os.path.exists(os.path.join(HERE, 'validator_prompt.md')) else ''

    results, log = [], []
    for seed in seeds:
        for grade in GRADES:
            for k in range(per_grade):
                attempts, accepted, last = 0, None, None
                while attempts < max_attempts:
                    attempts += 1
                    raw = provider.generate(gen_prompt, seed=seed, grade=grade, index=k)
                    try:
                        cand = json.loads(raw)
                    except json.JSONDecodeError:
                        log.append({'seed': seed['id'], 'grade': grade, 'attempt': attempts,
                                    'error': 'generator 출력이 JSON 이 아니다'})
                        continue
                    vraw = provider.validate(val_prompt, seed=seed, candidate=cand, grade=grade)
                    try:
                        vout = json.loads(vraw)
                    except json.JSONDecodeError:
                        log.append({'seed': seed['id'], 'grade': grade, 'attempt': attempts,
                                    'error': 'validator 출력이 JSON 이 아니다'})
                        continue
                    chk = rule_check(seed, cand, vout, grade)
                    last = chk
                    if chk['accepted']:
                        accepted = cand
                        break
                results.append({
                    'seed_id': seed['id'], 'target_grade': grade, 'variant_index': k,
                    'attempts': attempts, 'accepted': accepted is not None,
                    'first_pass': attempts == 1 and accepted is not None,
                    'candidate': accepted, 'last_check': last,
                    'failure_reasons': (last or {}).get('reasons', []),
                })
    os.makedirs(out_dir, exist_ok=True)
    payload = {
        'WARNING': 'NOT VALIDATION RESULT · provider=%s' % provider.name,
        'provider': provider.name,
        'generated_at': time.strftime('%Y-%m-%dT%H:%M:%S'),
        'n_requested': len(seeds) * len(GRADES) * per_grade,
        'results': results, 'log': log,
    }
    with open(os.path.join(out_dir, 'generation_output.json'), 'w', encoding='utf-8') as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
    return payload


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--seeds', default=os.path.join(HERE, 'seed_10.json'))
    ap.add_argument('--provider', default='echo')
    ap.add_argument('--per-grade', type=int, default=3)
    ap.add_argument('--out', default=os.path.join(HERE, 'b_output'))
    ap.add_argument('--dry-run', action='store_true')
    args = ap.parse_args()

    blocked = os.path.join(HERE, 'BLOCKED_UNTIL_A_PASS.md')
    if os.path.exists(blocked) and args.provider not in ('echo', 'dry') and not args.dry_run:
        print('=' * 62)
        print('  POC A 가 아직 통과하지 않았다. BLOCKED_UNTIL_A_PASS.md 참조.')
        print('  실제 provider 로 돌리려면 그 파일을 먼저 해제한다.')
        print('=' * 62)
        return 2

    seeds = json.load(open(args.seeds, encoding='utf-8'))['seeds']
    provider = make_provider('echo' if args.dry_run else args.provider)
    payload = run(seeds, provider, args.per_grade, out_dir=args.out)

    res = payload['results']
    acc = [r for r in res if r['accepted']]
    print('#' * 62)
    print('#  NOT VALIDATION RESULT · ENGINEERING DRY-RUN ONLY')
    print(f"#  provider = {provider.name}")
    print('#' * 62)
    print(f"요청 {payload['n_requested']}개 · 수락 {len(acc)}개")
    for g in GRADES:
        sub = [r for r in res if r['target_grade'] == g]
        a = [r for r in sub if r['accepted']]
        fp = [r for r in sub if r['first_pass']]
        att = sum(r['attempts'] for r in sub) / len(sub) if sub else 0
        print(f"  {g:<13} 수락 {len(a):>2}/{len(sub):<2} · 1회 성공 {len(fp):>2} · 평균 시도 {att:.2f}")
    print(f"\n저장 · {args.out}/generation_output.json")
    return 0


if __name__ == '__main__':
    sys.exit(main())
