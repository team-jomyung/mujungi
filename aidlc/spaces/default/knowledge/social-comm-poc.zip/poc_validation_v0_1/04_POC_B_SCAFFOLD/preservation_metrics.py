"""POC B · 사람 판정 결과로 구조 보존을 센다.

    python preservation_metrics.py human_eval.csv --generation b_output/generation_output.json

frozen_spec_v0_1 §11.2 · §11.4 를 따른다.

**사람 판정이 최종 기준이다.** validator 출력은 pre-filter 일 뿐 여기 들어오지 않는다.
A 가 통과하기 전에 돌리면 NOT VALIDATION RESULT 로 표시된다.
"""
from __future__ import annotations

import argparse
import csv
import io
import json
import os
from collections import Counter, defaultdict

GRADES = ('SAME_CONTEXT', 'NEAR', 'FAR')
CORE_PRESERVE = ('required_inference', 'perspective_structure',
                 'decidable_by_evidence', 'direct_check_allowed')

# §11.4 · 전부 프로젝트 운영 기준이다.
T = {
    'grade_accuracy': {'SAME_CONTEXT': {'pass': .80, 'retry': .60},
                       'NEAR': {'pass': .70, 'retry': .50},
                       'FAR': {'pass': .50, 'retry': .30}},
    'core_preservation': {'pass': .80, 'retry': .70},
    'avg_attempts': {'pass': 3, 'retry': 5},
}


def read_csv(p):
    with io.open(p, encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))


def analyze(human_rows, gen):
    gmap = {}
    for r in (gen or {}).get('results', []):
        key = f"{r['seed_id']}_{r['target_grade']}_{r['variant_index']}"
        gmap[key] = r

    out = {'n_human_rows': len(human_rows)}

    # 목표 등급 대 사람 판정 등급
    per_grade = defaultdict(lambda: {'n': 0, 'match': 0, 'human': Counter()})
    for h in human_rows:
        tg = (h.get('target_grade') or '').strip().upper()
        hj = (h.get('human_transfer_distance') or '').strip().upper()
        hsi = (h.get('human_skill_identity_understand') or '').strip().upper()
        if tg not in GRADES:
            continue
        g = per_grade[tg]
        g['n'] += 1
        g['human'][hj or '(빈칸)'] += 1
        # 등급이 맞으려면 축1 이 SAME 이어야 한다. 축1 이 아니면 등급 자체가 무효
        if hsi == 'SAME' and hj == tg:
            g['match'] += 1
    out['grade_accuracy'] = {
        g: {'n': v['n'], 'match': v['match'],
            'accuracy': (v['match'] / v['n']) if v['n'] else None,
            'human_distribution': dict(v['human'])}
        for g, v in per_grade.items()}

    overall_n = sum(v['n'] for v in per_grade.values())
    overall_m = sum(v['match'] for v in per_grade.values())
    out['grade_accuracy_overall'] = {'n': overall_n, 'match': overall_m,
                                     'accuracy': (overall_m / overall_n) if overall_n else None}

    # Core 보존율 · 사람이 SAME 이라고 본 비율
    pres = {}
    for f in CORE_PRESERVE:
        col = f'human_{f}'
        vals = [(h.get(col) or '').strip().upper() for h in human_rows]
        vals = [v for v in vals if v]
        same = sum(1 for v in vals if v == 'SAME')
        pres[f] = {'n': len(vals), 'preserved': same,
                   'rate': (same / len(vals)) if vals else None}
    out['core_preservation'] = pres

    # strategy_space · 수행 단계
    sp = [(h.get('human_strategy_space_preserved') or '').strip().upper() for h in human_rows]
    sp = [v for v in sp if v]
    out['strategy_space_preservation'] = {
        'n': len(sp), 'preserved': sum(1 for v in sp if v in ('YES', 'SAME')),
        'rate': (sum(1 for v in sp if v in ('YES', 'SAME')) / len(sp)) if sp else None,
        'note': '수행 단계 전용. direct_check_allowed 가 유지됐는가'}

    # 생성 비용
    if gmap:
        res = list(gmap.values())
        out['generation_cost'] = {}
        for g in GRADES:
            sub = [r for r in res if r['target_grade'] == g]
            if not sub:
                continue
            out['generation_cost'][g] = {
                'n': len(sub),
                'first_pass_rate': sum(1 for r in sub if r['first_pass']) / len(sub),
                'accept_rate': sum(1 for r in sub if r['accepted']) / len(sub),
                'avg_attempts': sum(r['attempts'] for r in sub) / len(sub),
            }
        reasons = Counter()
        for r in res:
            for x in r.get('failure_reasons', []):
                reasons[x.split('·')[0].strip()] += 1
        out['failure_reason_distribution'] = dict(reasons.most_common())
    else:
        out['generation_cost'] = None
        out['failure_reason_distribution'] = None

    return out


def decide(a):
    d = {'per_criterion': {}, 'verdict': None, 'notes': []}
    fails, retries = [], []

    for g in GRADES:
        v = a['grade_accuracy'].get(g)
        th = T['grade_accuracy'][g]
        if not v or v['accuracy'] is None:
            d['per_criterion'][f'grade_accuracy_{g}'] = {'result': 'NA', 'basis': 'operational'}
            continue
        acc = v['accuracy']
        r = 'PASS' if acc >= th['pass'] else ('RETRY' if acc >= th['retry'] else 'FAIL')
        if r == 'FAIL':
            fails.append(f'{g} 등급 일치율 {acc:.0%}')
        elif r == 'RETRY':
            retries.append(f'{g} 등급 일치율 {acc:.0%}')
        d['per_criterion'][f'grade_accuracy_{g}'] = {
            'result': r, 'value': acc, 'threshold': th['pass'], 'basis': 'operational'}

    low = [f for f, v in a['core_preservation'].items()
           if v['rate'] is not None and v['rate'] < T['core_preservation']['pass']]
    r = 'PASS' if not low else ('RETRY' if all(
        a['core_preservation'][f]['rate'] >= T['core_preservation']['retry'] for f in low) else 'FAIL')
    if r == 'FAIL':
        fails.append(f'Core 보존율 미달 {low}')
    elif r == 'RETRY':
        retries.append(f'Core 보존율 미달 {low}')
    rates = [v['rate'] for v in a['core_preservation'].values() if v['rate'] is not None]
    d['per_criterion']['core_preservation'] = {
        'result': r, 'below': low, 'value': min(rates) if rates else None,
        'value_note': '가장 낮은 필드의 보존율',
        'threshold': T['core_preservation']['pass'], 'basis': 'operational'}

    gc = a.get('generation_cost') or {}
    for g, v in gc.items():
        att = v['avg_attempts']
        r = 'PASS' if att <= T['avg_attempts']['pass'] else ('RETRY' if att <= T['avg_attempts']['retry'] else 'FAIL')
        if r == 'FAIL':
            fails.append(f'{g} 평균 시도 {att:.1f}회 · 이 등급을 MVP 에서 뺀다')
        d['per_criterion'][f'avg_attempts_{g}'] = {
            'result': r, 'value': att, 'threshold': T['avg_attempts']['pass'], 'basis': 'operational'}

    d['verdict'] = 'FAIL' if fails else ('RETRY' if retries else 'PASS')
    d['reasons'] = fails + retries
    d['notes'] = [
        '사람 판정이 최종 기준이다. validator 출력은 여기 들어오지 않았다',
        '등급별로 따로 본다. 합치지 않는다',
        'FAR 가 실패하면 근전이까지만 운영한다(§11.4)',
    ]
    return d


def render(a, d, official):
    L = []
    if not official:
        L += ['', '#' * 62, '#  NOT VALIDATION RESULT', '#  POC A 통과 확인이 없다. 배관 확인용 출력이다.', '#' * 62]
    L += ['', '=' * 62, 'POC B · 시나리오 구조 보존', '=' * 62,
          f"사람 판정 {a['n_human_rows']}행", '', '── 목표 등급 대 사람 판정 ' + '─' * 34]
    for g in GRADES:
        v = a['grade_accuracy'].get(g)
        if not v or v['accuracy'] is None:
            L.append(f'  {g:<13} 데이터 없음')
            continue
        L.append(f"  {g:<13} {v['match']}/{v['n']} = {v['accuracy']:.0%}   "
                 f"사람 판정 분포 {dict(v['human_distribution'])}")
    o = a['grade_accuracy_overall']
    if o['accuracy'] is not None:
        L.append(f"  전체          {o['match']}/{o['n']} = {o['accuracy']:.0%}  ← 참고. 등급별로 본다")

    L += ['', '── Core 보존율 ' + '─' * 45]
    for f, v in a['core_preservation'].items():
        if v['rate'] is None:
            L.append(f'  {f:<24} 데이터 없음')
        else:
            L.append(f"  {f:<24} {v['preserved']}/{v['n']} = {v['rate']:.0%}")
    s = a['strategy_space_preservation']
    if s['rate'] is not None:
        L.append(f"  strategy_space(수행)     {s['preserved']}/{s['n']} = {s['rate']:.0%}")

    if a.get('generation_cost'):
        L += ['', '── 생성 비용 ' + '─' * 47]
        for g, v in a['generation_cost'].items():
            L.append(f"  {g:<13} 1회 성공 {v['first_pass_rate']:.0%} · 수락 {v['accept_rate']:.0%} · 평균 시도 {v['avg_attempts']:.2f}")
    if a.get('failure_reason_distribution'):
        L += ['', '── 실패 사유 ' + '─' * 47]
        for k, v in a['failure_reason_distribution'].items():
            L.append(f'  {v:>3}건  {k}')

    L += ['', '=' * 62, f"판정 · {d['verdict']}", '=' * 62]
    for k, v in d['per_criterion'].items():
        val = v.get('value')
        val = f'{val:.2f}' if isinstance(val, float) else val
        L.append(f"  {v['result']:<6} {k} = {val}   [{v['basis']}]")
    if d['reasons']:
        L += ['', '  미달'] + [f'   - {r}' for r in d['reasons']]
    L += ['', '  기억할 것'] + [f'   · {n}' for n in d['notes']]
    if not official:
        L += ['', '#' * 62, '#  다시 적는다 · NOT VALIDATION RESULT', '#' * 62]
    return '\n'.join(L)


def poc_a_passed():
    p = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                     '..', '02_POC_A', 'results', 'agreement_report.json')
    if not os.path.exists(p):
        return False
    try:
        return json.load(io.open(p, encoding='utf-8')).get('decision', {}).get('verdict') == 'PASS'
    except Exception:
        return False


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('human_eval')
    ap.add_argument('--generation', default=None)
    ap.add_argument('--out', default='results')
    args = ap.parse_args()

    human = read_csv(args.human_eval)
    gen = json.load(io.open(args.generation, encoding='utf-8')) if args.generation and os.path.exists(args.generation) else None
    official = poc_a_passed()

    a = analyze(human, gen)
    d = decide(a)
    txt = render(a, d, official)
    print(txt)

    os.makedirs(args.out, exist_ok=True)
    with io.open(os.path.join(args.out, 'preservation_report.txt'), 'w', encoding='utf-8') as f:
        f.write(txt + '\n')
    payload = dict(a)
    payload['decision'] = d
    payload['official'] = official
    if not official:
        payload['WARNING'] = 'NOT VALIDATION RESULT · POC A 통과 확인 없음'
    with io.open(os.path.join(args.out, 'preservation_report.json'), 'w', encoding='utf-8') as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)


if __name__ == '__main__':
    main()
