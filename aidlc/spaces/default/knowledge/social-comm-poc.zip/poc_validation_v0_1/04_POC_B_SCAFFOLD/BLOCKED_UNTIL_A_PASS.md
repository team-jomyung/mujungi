# ⛔ POC B 는 아직 시작하지 않는다

## 왜

**검증 A 가 통과해야 B 가 의미를 갖는다.** B 의 최종 기준은 사람 판정인데, A 가 통과하지 않았다면 그 사람 판정이 재현되지 않는다는 뜻이다. 기준이 없는 측정은 측정이 아니다.

frozen spec §11.2 · "A 가 실패하면 B 를 진행하지 않는다. 규격을 고쳐 A 를 다시 한 뒤에 간다."

## 해제 조건

`02_POC_A/results/agreement_report.json` 의 `decision.verdict` 가 **`PASS`** 일 때.

`RETRY` 여도 시작하지 않는다.

## 해제되면

1. 이 파일 이름을 `UNBLOCKED_<날짜>.md` 로 바꾸고 A 결과 요약을 적는다
2. `seed_10.json` 을 확인한다
3. `generation_harness.py` 에 provider 를 연결한다. API 키는 환경변수로만
4. 90개(시드 10 × 등급 3 × 3개)를 생성한다
5. 생성 목표를 가리고 섞어 사람에게 판정시킨다
6. `preservation_metrics.py` 로 센다

## 그 전에 해도 되는 것

**엔지니어링 dry-run 은 해도 된다.** 배관이 도는지 보는 것이다.

단 산출물에 반드시 표시한다.

```
NOT VALIDATION RESULT · ENGINEERING DRY-RUN ONLY
```

그리고 그 수치를 **어떤 보고서에도 성능으로 적지 않는다.**

## 지금 상태

| | |
|---|---|
| A 판정 | **미실시** |
| B 시작 가능 | **아니오** |
| dry-run 허용 | 예 · 표시 필수 |
