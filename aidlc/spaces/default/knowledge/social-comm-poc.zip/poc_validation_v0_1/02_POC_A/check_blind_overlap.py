# -*- coding: utf-8 -*-
"""blind 후보끼리 겹침을 번호로만 알려 준다. 본문은 찍지 않는다.

    python check_blind_overlap.py                         합친 파일 하나를 본다
    python check_blind_overlap.py a.csv b.csv             여러 파일을 본다
    python check_blind_overlap.py --threshold 0.35

왜 있나
  후보를 두 작성자가 따로 만들었다. 서로의 결과를 보지 않았으므로 비슷한 장면이 겹칠 수 있다.
  겹친 두 쌍이 모두 선별되면 판정자는 사실상 같은 문제를 두 번 푼다. 일치도가 부풀려진다.

무엇을 재나
  상황 하나를 공백을 지운 글자 3-gram 집합으로 만들고 Jaccard 를 잰다.
  쌍과 쌍 사이 · 네 조합(A-A, A-B, B-A, B-B) 중 가장 큰 값
  쌍 안     · A 와 B 의 겹침. 표면 문장을 같게 쓰지 말라는 규칙을 본다

본문을 찍지 않는 이유
  이 스크립트를 돌리는 쪽이 규격 작성자일 수 있다. 규격 작성 세션이 후보 원문을 보면 선별을 할 수 없다.
  번호와 점수만 보고 판단은 선별하는 사람이 한다.

문턱은 운영 값이다. 짚은 쌍을 버리라는 뜻이 아니라 둘 중 하나만 남기라는 뜻이다.
"""
import argparse
import csv
import io
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))


def grams(text, n=3):
    t = re.sub(r'\s+', '', text or '')
    return {t[i:i + n] for i in range(max(0, len(t) - n + 1))}


def jac(a, b):
    return len(a & b) / len(a | b) if (a or b) else 0.0


def load(paths):
    rows = []
    for p in paths:
        with io.open(p, encoding='utf-8-sig', newline='') as f:
            for r in csv.DictReader(f):
                pid = (r.get('pair_id') or '').strip()
                if pid:
                    rows.append((pid, grams(r.get('event_A')), grams(r.get('event_B'))))
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('paths', nargs='*')
    ap.add_argument('--threshold', type=float, default=0.35)
    ap.add_argument('--within', type=float, default=0.60)
    a = ap.parse_args()
    paths = a.paths
    if not paths:
        c = json.loads(io.open(os.path.join(HERE, 'a1_counts.json'), encoding='utf-8').read())
        paths = [os.path.join(HERE, c['blind_candidates_file'])]
    rows = load(paths)

    cross = []
    for i in range(len(rows)):
        for j in range(i + 1, len(rows)):
            _, a1, b1 = rows[i]
            _, a2, b2 = rows[j]
            s = max(jac(a1, a2), jac(a1, b2), jac(b1, a2), jac(b1, b2))
            cross.append((s, rows[i][0], rows[j][0]))
    cross.sort(reverse=True)
    within = sorted(((jac(r[1], r[2]), r[0]) for r in rows), reverse=True)

    flagged = [x for x in cross if x[0] >= a.threshold]
    wflag = [x for x in within if x[0] >= a.within]

    print('후보 %d쌍 · 쌍끼리 비교 %d · 문턱 %.2f' % (len(rows), len(cross), a.threshold))
    print('쌍끼리 가장 겹치는 열 조합')
    for s, p, q in cross[:10]:
        print('  %.3f  %s ~ %s%s' % (s, p, q, '   ← 짚음' if s >= a.threshold else ''))
    print('짚은 조합 %d' % len(flagged))
    print('쌍 안 A~B 겹침 최대 %.3f · 문턱 %.2f 이상 %d' % (within[0][0] if within else 0.0, a.within, len(wflag)))
    for s, p in wflag:
        print('  %.3f  %s 안의 A 와 B' % (s, p))
    print()
    print('본문은 찍지 않았다. 짚은 번호를 선별하는 사람이 열어 보고 둘 중 하나만 남긴다.')
    return 0


if __name__ == '__main__':
    sys.exit(main())
