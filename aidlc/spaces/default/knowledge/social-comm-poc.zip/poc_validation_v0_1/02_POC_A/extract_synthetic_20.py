"""frozen_spec_v0_1.html 의 §5.1 · §5.2 표에서 20쌍을 뽑는다.

판정자용 CSV 에는 정답을 넣지 않는다.
문서가 적어 둔 예상 판정은 _gold/ 로 분리한다.

    python extract_synthetic_20.py
"""
import csv
import io
import os
import re
from collections import Counter

HERE = os.path.dirname(os.path.abspath(__file__))
SPEC = os.path.join(HERE, '..', '01_SPEC', 'frozen_spec_v0_1.html')


def strip(s):
    s = re.sub(r'<br\s*/?>', ' ', s)
    s = re.sub(r'<[^>]+>', '', s)
    s = (s.replace('&amp;', '&').replace('&lt;', '<')
          .replace('&gt;', '>').replace('&nbsp;', ' '))
    return re.sub(r'\s+', ' ', s).strip()


def main():
    html = io.open(SPEC, encoding='utf-8').read()
    tables = re.findall(r'<table>(.*?)</table>', html, re.S)
    target = [t for t in tables
              if '무엇이 다른가' in strip(t[:500]) or '무엇이 같은가' in strip(t[:500])]

    rows = []
    for ti, t in enumerate(target):
        for tr in re.findall(r'<tr>(.*?)</tr>', t, re.S):
            tds = re.findall(r'<td[^>]*>(.*?)</td>', tr, re.S)
            if len(tds) != 6:
                continue
            num, a, b, why, u, p = [strip(x) for x in tds]
            if not num.isdigit():
                continue
            rows.append({
                'pair_id': 'S%02d' % int(num),
                'event_A': a, 'event_B': b,
                'spec_rationale': why,
                'spec_understand': u, 'spec_perform': p,
                'spec_group': '5.1' if ti == 0 else '5.2',
            })
    rows.sort(key=lambda r: int(r['pair_id'][1:]))

    gold_dir = os.path.join(HERE, '_gold')
    os.makedirs(gold_dir, exist_ok=True)

    with io.open(os.path.join(HERE, 'existing_synthetic_20.csv'),
                 'w', encoding='utf-8', newline='') as f:
        w = csv.DictWriter(f, ['pair_id', 'event_A', 'event_B'])
        w.writeheader()
        for r in rows:
            w.writerow({k: r[k] for k in ('pair_id', 'event_A', 'event_B')})

    with io.open(os.path.join(gold_dir, 'existing_synthetic_20_SPEC_EXPECTED.csv'),
                 'w', encoding='utf-8', newline='') as f:
        cols = ['pair_id', 'spec_group', 'spec_rationale', 'spec_understand', 'spec_perform']
        w = csv.DictWriter(f, cols)
        w.writeheader()
        for r in rows:
            w.writerow({k: r[k] for k in cols})

    print('추출 쌍', len(rows))
    print('이해 분포', dict(Counter(r['spec_understand'] for r in rows)))
    print('수행 분포', dict(Counter(r['spec_perform'] for r in rows)))
    for r in rows[:2] + rows[-1:]:
        print(' ', r['pair_id'], '|', r['event_A'][:20], '|', r['event_B'][:20])


if __name__ == '__main__':
    main()
