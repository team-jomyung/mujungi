"""판정지 빈 양식을 만든다.

    python make_forms.py --pairs randomized_pairs.csv --out .

annotation_form.csv  ·  판정자가 채우는 빈 양식
annotation_form.json ·  같은 구조를 기계가 읽을 수 있게
"""
import argparse
import csv
import io
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))

COLUMNS = [
    # 식별
    ('pair_id', '쌍 번호', None),
    # 불변항 문장
    ('invariant_sentence_A', 'A 를 한 문장으로', 'free'),
    ('invariant_sentence_B', 'B 를 한 문장으로', 'free'),
    # Core 1
    ('target_skill_A', 'A 는 무엇을 하는 일인가', ['RECOGNIZE', 'PRODUCE', 'REPAIR', 'UNKNOWN']),
    ('target_skill_B', 'B 는 무엇을 하는 일인가', ['RECOGNIZE', 'PRODUCE', 'REPAIR', 'UNKNOWN']),
    ('target_skill', '둘이 같은가', ['SAME', 'DIFFERENT', 'UNKNOWN']),
    # Core 2
    ('required_inference', '머리로 메워야 하는 빈칸이 같은가', ['SAME', 'DIFFERENT', 'UNKNOWN']),
    # Core 3
    ('perspective_structure', '누구의 속을 짐작해야 하는가가 같은가', ['SAME', 'DIFFERENT', 'UNKNOWN']),
    # Core 4
    ('decidable_by_evidence_A', 'A 는 단서로 답을 고를 수 있는가', ['YES', 'NO', 'UNKNOWN']),
    ('decidable_by_evidence_B', 'B 는 단서로 답을 고를 수 있는가', ['YES', 'NO', 'UNKNOWN']),
    ('decidable_by_evidence', '둘이 같은가', ['SAME', 'DIFFERENT', 'UNKNOWN']),
    # Core 5 · 수행 전용
    ('direct_check_allowed_A', 'A 는 대놓고 물어봐도 되는가', ['YES', 'NO', 'UNKNOWN']),
    ('direct_check_allowed_B', 'B 는 대놓고 물어봐도 되는가', ['YES', 'NO', 'UNKNOWN']),
    ('direct_check_allowed', '둘이 같은가', ['SAME', 'DIFFERENT', 'UNKNOWN']),
    # 거리 입력
    ('topic_changed', '화제', ['CHANGED', 'SAME', 'UNKNOWN']),
    ('place_changed', '장소', ['CHANGED', 'SAME', 'UNKNOWN']),
    ('participants_changed', '등장인물', ['CHANGED', 'SAME', 'UNKNOWN']),
    ('relationship_changed', '상대와의 관계', ['CHANGED', 'SAME', 'UNKNOWN']),
    ('situation_type_changed', '상황의 종류', ['CHANGED', 'SAME', 'UNKNOWN']),
    ('misread_cost_changed', '잘못 짚었을 때의 대가', ['CHANGED', 'SAME', 'UNKNOWN']),
    ('recoverability_changed', '되돌릴 수 있는 정도', ['CHANGED', 'SAME', 'UNKNOWN']),
    # 최종
    ('skill_identity_understand', '알아채기 판정', ['SAME', 'DIFFERENT', 'UNDETERMINED']),
    ('skill_identity_perform', '대응하기 판정', ['SAME', 'DIFFERENT', 'UNDETERMINED']),
    ('transfer_distance', '거리 판정', ['SAME_CONTEXT', 'NEAR', 'FAR', 'UNDETERMINED', '']),
    # 자유
    ('supporting_field_difference', '판정에는 안 넣었지만 눈에 띈 차이', 'free'),
    ('rater_note', '기타 메모', 'free'),
]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--pairs', default=os.path.join(HERE, 'existing_synthetic_20.csv'))
    ap.add_argument('--out', default=HERE)
    args = ap.parse_args()

    pair_ids = []
    if os.path.exists(args.pairs):
        with io.open(args.pairs, encoding='utf-8-sig', newline='') as f:
            pair_ids = [r['pair_id'] for r in csv.DictReader(f)]

    names = [c[0] for c in COLUMNS]
    path = os.path.join(args.out, 'annotation_form.csv')
    with io.open(path, 'w', encoding='utf-8', newline='') as f:
        w = csv.writer(f)
        w.writerow(names)
        for pid in pair_ids:
            w.writerow([pid] + [''] * (len(names) - 1))

    spec = {
        'form': 'POC A annotation form',
        'spec_version': '0.1',
        'instructions': 'annotation_guideline_onepage.md 를 먼저 읽는다. 정답은 없다.',
        'rules_reminder': [
            '모른다는 정당한 답이다. 추측해서 채우지 않는다',
            '알아채기와 대응하기를 따로 적는다',
            'transfer_distance 는 알아채기가 SAME 일 때만 적는다',
            '다른 판정자와 상의하지 않는다',
        ],
        'columns': [
            {'name': n, 'label': l, 'type': 'free' if v == 'free' else ('id' if v is None else 'enum'),
             'values': v if isinstance(v, list) else None}
            for n, l, v in COLUMNS
        ],
        'pair_ids': pair_ids,
    }
    with io.open(os.path.join(args.out, 'annotation_form.json'), 'w', encoding='utf-8') as f:
        json.dump(spec, f, ensure_ascii=False, indent=2)

    print(f'양식 생성 · 열 {len(names)}개 · 행 {len(pair_ids)}개')
    print(f'  {path}')
    print(f"  {os.path.join(args.out, 'annotation_form.json')}")


if __name__ == '__main__':
    main()
