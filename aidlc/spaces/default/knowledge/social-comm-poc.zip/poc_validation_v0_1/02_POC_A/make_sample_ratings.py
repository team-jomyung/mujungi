"""분석 스크립트를 돌려 보기 위한 가짜 판정 데이터를 만든다.

    python make_sample_ratings.py

이것은 DEMO 데이터다. 사람이 낸 판정이 아니고 검증 결과도 아니다.
목적은 하나다. analyze_agreement.py 가 실제로 돌아가는지 확인하는 것.

만드는 방식 · rater A 는 규격이 §5 표에 적어 둔 판정과 맞아떨어지도록 필드를 역산해 채운다.
rater B 는 A 를 베끼되 일부러 몇 칸을 흔든다. 흔드는 자리와 수를 seed 로 고정한다.
"""
import csv
import io
import os
import random

HERE = os.path.dirname(os.path.abspath(__file__))
SEED = 424242

# §5 표의 예상 판정에 맞는 필드 조합을 손으로 역산해 둔 것.
# 형식 · (target_skill, required_inference, perspective_structure,
#         decidable_by_evidence, direct_check_allowed,
#         relationship_changed, situation_type_changed,
#         misread_cost_changed, recoverability_changed)
S = 'SAME'
D = 'DIFFERENT'
U = 'UNKNOWN'
C = 'CHANGED'

PROFILE = {
    # 5.1 · 다른 기술
    'S01': (S, S, S, S, D, C, S, S, S),      # 이해 NEAR · 수행 DIFFERENT
    'S02': (S, D, S, S, S, S, S, S, S),      # 둘 다 DIFFERENT
    'S03': (S, D, S, S, S, S, S, S, S),
    'S04': (S, S, S, D, S, S, S, S, S),
    'S05': (S, D, S, S, S, S, S, S, S),
    'S06': (S, S, D, S, S, S, S, S, S),
    'S07': (S, S, S, S, S, S, S, S, S),      # 둘 다 SAME · 과잉 병합 사례
    'S08': (D, S, S, S, S, S, S, S, S),
    'S09': (D, S, S, S, S, S, S, S, S),
    'S10': (S, S, D, S, S, S, S, S, S),
    # 5.2 · 같은 기술
    'S11': (S, S, S, S, S, C, S, S, S),      # NEAR / NEAR
    'S12': (S, S, S, S, S, S, S, S, S),      # SAME / SAME
    'S13': (S, S, S, S, S, C, S, S, S),
    'S14': (S, S, S, S, S, S, S, S, S),
    'S15': (S, S, S, S, S, S, C, S, S),      # 상황 유형 변경 → NEAR
    'S16': (S, S, S, S, S, S, S, S, S),
    'S17': (S, S, S, S, D, C, S, C, C),      # 이해 FAR · 수행 DIFFERENT
    'S18': (S, S, S, S, S, S, S, S, S),
    'S19': (S, S, S, S, D, C, S, C, C),
    'S20': (S, S, S, S, S, C, S, S, S),
}

FIELDS = ['target_skill', 'required_inference', 'perspective_structure',
          'decidable_by_evidence', 'direct_check_allowed',
          'relationship_changed', 'situation_type_changed',
          'misread_cost_changed', 'recoverability_changed']
CORE5 = FIELDS[:5]
COSMETIC = ['topic_changed', 'place_changed', 'participants_changed']


def row_for(pid, vals, note=''):
    r = {'pair_id': pid}
    for f, v in zip(FIELDS, vals):
        r[f] = v
    for f in COSMETIC:
        r[f] = C
    r['supporting_field_difference'] = ''
    r['rater_note'] = note
    return r


def main():
    rng = random.Random(SEED)
    ids = sorted(PROFILE)

    a_rows = [row_for(p, PROFILE[p]) for p in ids]

    # rater B · 네 쌍의 Core 를 흔들고 한 쌍은 UNKNOWN 을 넣는다
    shake = rng.sample(ids, 4)
    unk_pair = rng.choice([p for p in ids if p not in shake])
    b_rows = []
    for p in ids:
        vals = list(PROFILE[p])
        note = ''
        if p in shake:
            i = rng.randrange(5)
            vals[i] = D if vals[i] == S else S
            note = '헷갈려서 다르게 봤음'
        if p == unk_pair:
            vals[3] = U
            note = '단서가 있는지 판단이 안 됨'
        b_rows.append(row_for(p, vals, note))

    cols = ['pair_id'] + CORE5 + COSMETIC + FIELDS[5:] + \
           ['supporting_field_difference', 'rater_note']
    for name, rows in (('sample_rater_A.csv', a_rows), ('sample_rater_B.csv', b_rows)):
        with io.open(os.path.join(HERE, name), 'w', encoding='utf-8', newline='') as f:
            w = csv.DictWriter(f, cols)
            w.writeheader()
            for r in rows:
                w.writerow({k: r.get(k, '') for k in cols})

    print(f'DEMO 데이터 생성 · {len(ids)}쌍 · seed {SEED}')
    print(f'  rater B 가 흔든 쌍 {sorted(shake)} · UNKNOWN 넣은 쌍 {unk_pair}')
    print('  이것은 사람 판정이 아니다. 검증 결과가 아니다.')


if __name__ == '__main__':
    main()
