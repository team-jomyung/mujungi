"""POC A · 판정자 두 명의 일치도를 계산한다.

    python analyze_agreement.py rater_A.csv rater_B.csv --out results/

frozen_spec_v0_1 §11.1 과 §11.4 를 따른다.
- 축 1 Skill Identity : 이해·수행 각각 unweighted Cohen's κ
- 축 2 Transfer Distance : 두 판정자가 모두 이해 축 1 을 SAME 으로 본 쌍에서만
- Core field κ 5개
- 혼동 행렬 3개 + 진단용 6×6

의존성 없음. 표준 라이브러리만 쓴다.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import os
import random
import sys
from collections import Counter, defaultdict

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from rule_engine import (  # noqa: E402
    CORE_PERFORM, judge, check_invariant, RuleError,
)

SI_CATS = ['SAME', 'DIFFERENT', 'UNDETERMINED']
TD_CATS = ['SAME_CONTEXT', 'NEAR', 'FAR', 'UNDETERMINED']
LABEL_CATS = ['SAME_SKILL', 'NEAR_TRANSFER', 'FAR_TRANSFER',
              'SAME_SKILL_DISTANCE_UNDETERMINED', 'DIFFERENT_SKILL', 'UNDETERMINED']

BOOTSTRAP_N = 2000
BOOTSTRAP_SEED = 20260912

# §11.4. evidence_basis 가 operational 인 것은 우리가 정한 값이고 문헌 근거가 아니다.
THRESHOLDS = {
    'skill_identity_kappa': {'pass': 0.6, 'retry_low': 0.4, 'basis': 'adjacent_reference'},
    'core_field_kappa': {'pass': 0.5, 'basis': 'operational'},
    'undetermined_rate': {'pass_max': 0.20, 'retry_max': 0.30, 'basis': 'operational'},
    'transfer_distance_kappa': {'pass': 0.5, 'basis': 'operational', 'can_fail_alone': False},
}


# ─────────────────────────── κ ───────────────────────────

def cohen_kappa(a, b, categories, weights=None):
    """unweighted 가 기본. weights='linear' 면 순서형 선형 가중.

    계산이 불가능하면 (None, 사유) 를 돌려준다. 숫자를 억지로 만들지 않는다.
    """
    if len(a) != len(b):
        return None, 'rater 두 명의 판정 수가 다르다'
    n = len(a)
    if n == 0:
        return None, '대상 쌍이 0개다'

    cats = list(categories)
    idx = {c: i for i, c in enumerate(cats)}
    for v in list(a) + list(b):
        if v not in idx:
            return None, f'범주 밖의 값 {v!r}'

    k = len(cats)
    if weights == 'linear':
        w = [[1 - abs(i - j) / (k - 1) for j in range(k)] for i in range(k)]
    else:
        w = [[1.0 if i == j else 0.0 for j in range(k)] for i in range(k)]

    obs = [[0] * k for _ in range(k)]
    for x, y in zip(a, b):
        obs[idx[x]][idx[y]] += 1

    ra = [sum(obs[i]) / n for i in range(k)]
    cb = [sum(obs[i][j] for i in range(k)) / n for j in range(k)]

    po = sum(w[i][j] * obs[i][j] / n for i in range(k) for j in range(k))
    pe = sum(w[i][j] * ra[i] * cb[j] for i in range(k) for j in range(k))

    if abs(1 - pe) < 1e-12:
        used_a = {v for v in a}
        used_b = {v for v in b}
        if len(used_a) == 1 and len(used_b) == 1:
            reason = f'두 판정자가 한 범주만 사용했다 ({used_a.pop()}). κ 가 정의되지 않는다'
        else:
            reason = '기대 일치도가 1 이라 κ 가 정의되지 않는다'
        return None, reason

    return (po - pe) / (1 - pe), None


def kappa_ci(a, b, categories, weights=None, n_boot=BOOTSTRAP_N, seed=BOOTSTRAP_SEED):
    """percentile bootstrap. seed 와 반복 횟수를 고정한다."""
    point, err = cohen_kappa(a, b, categories, weights)
    if point is None:
        return None, None, None, err
    rng = random.Random(seed)
    n = len(a)
    vals = []
    for _ in range(n_boot):
        pick = [rng.randrange(n) for _ in range(n)]
        ka, kerr = cohen_kappa([a[i] for i in pick], [b[i] for i in pick], categories, weights)
        if ka is not None:
            vals.append(ka)
    if len(vals) < n_boot * 0.5:
        return point, None, None, f'bootstrap 표본 {len(vals)}/{n_boot} 만 계산됨. CI 를 내지 않는다'
    vals.sort()
    lo = vals[int(0.025 * len(vals))]
    hi = vals[min(int(0.975 * len(vals)), len(vals) - 1)]
    return point, lo, hi, None


def confusion(a, b, categories):
    idx = {c: i for i, c in enumerate(categories)}
    m = [[0] * len(categories) for _ in categories]
    for x, y in zip(a, b):
        if x in idx and y in idx:
            m[idx[x]][idx[y]] += 1
    return m


def fmt_matrix(m, categories, title):
    w = max(len(c) for c in categories) + 1
    out = [f'  {title}', '  ' + ' ' * w + '│' + ''.join(f'{c[:10]:>12}' for c in categories)]
    out.append('  ' + '─' * w + '┼' + '─' * (12 * len(categories)))
    for i, c in enumerate(categories):
        out.append(f'  {c:<{w}}│' + ''.join(f'{v:>12}' for v in m[i]))
    return '\n'.join(out)


# ─────────────────────── 입출력 ───────────────────────

def load_ratings(path):
    with open(path, encoding='utf-8-sig', newline='') as f:
        rows = list(csv.DictReader(f))
    out = {}
    problems = []
    for r in rows:
        pid = (r.get('pair_id') or '').strip()
        if not pid:
            continue
        ann = {k: (r.get(k) or '').strip().upper() for k in
               list(CORE_PERFORM) + ['topic_changed', 'place_changed', 'participants_changed',
                                     'relationship_changed', 'situation_type_changed',
                                     'misread_cost_changed', 'recoverability_changed']}
        try:
            res = judge(ann)
        except RuleError as e:
            problems.append((pid, str(e)))
            continue
        if not check_invariant(res):
            problems.append((pid, 'PERFORM=SAME 인데 UNDERSTAND 가 SAME 이 아니다. 입력 오류'))
        res['_fields'] = ann
        res['_note'] = (r.get('rater_note') or '').strip()
        res['_supporting'] = (r.get('supporting_field_difference') or '').strip()
        out[pid] = res
    return out, problems


# ─────────────────────── 본체 ───────────────────────

def analyze(pa, pb, origin_map=None):
    ids = sorted(set(pa) & set(pb))
    rep = {'n_pairs': len(ids), 'pair_ids': ids,
           'only_in_A': sorted(set(pa) - set(pb)), 'only_in_B': sorted(set(pb) - set(pa))}

    # 축 1
    rep['axis1'] = {}
    for stage in ('understand', 'perform'):
        key = f'skill_identity_{stage}'
        a = [pa[i][key] for i in ids]
        b = [pb[i][key] for i in ids]
        k, lo, hi, err = kappa_ci(a, b, SI_CATS)
        agree = sum(1 for x, y in zip(a, b) if x == y) / len(ids) if ids else 0
        rep['axis1'][stage] = {
            'kappa': k, 'ci_lower': lo, 'ci_upper': hi, 'error': err,
            'agreement_pct': agree,
            'confusion': confusion(a, b, SI_CATS),
            'prevalence_A': dict(Counter(a)), 'prevalence_B': dict(Counter(b)),
        }

    # 축 1 의 UNDETERMINED 비율. 거리 미결은 포함하지 않는다(§11.4).
    und = [i for i in ids
           if pa[i]['skill_identity_understand'] == 'UNDETERMINED'
           or pb[i]['skill_identity_understand'] == 'UNDETERMINED'
           or pa[i]['skill_identity_perform'] == 'UNDETERMINED'
           or pb[i]['skill_identity_perform'] == 'UNDETERMINED']
    rep['undetermined_rate_axis1'] = len(und) / len(ids) if ids else None
    rep['undetermined_pairs_axis1'] = und

    # 축 2 · 두 판정자가 모두 이해 축 1 을 SAME 으로 본 쌍에서만
    sub = [i for i in ids
           if pa[i]['skill_identity_understand'] == 'SAME'
           and pb[i]['skill_identity_understand'] == 'SAME']

    # 분모 투명화 · 어디서 몇 개가 빠졌는지 전부 적는다
    excl_disagree = [i for i in ids
                     if pa[i]['skill_identity_understand'] != pb[i]['skill_identity_understand']]
    excl_both_diff = [i for i in ids
                      if pa[i]['skill_identity_understand'] == pb[i]['skill_identity_understand'] == 'DIFFERENT']
    excl_both_und = [i for i in ids
                     if pa[i]['skill_identity_understand'] == pb[i]['skill_identity_understand'] == 'UNDETERMINED']
    td_unknown = [i for i in sub
                  if pa[i]['transfer_distance'] == 'UNDETERMINED'
                  or pb[i]['transfer_distance'] == 'UNDETERMINED']
    rep['axis2'] = {
        'subset_ids': sub, 'subset_n': len(sub),
        'subset_rule': '두 판정자가 모두 SkillIdentity(이해)=SAME 으로 본 쌍',
        'denominator_breakdown': {
            'total_pairs': len(ids),
            'identity_SAME_eligible': len(sub),
            'excluded_identity_disagreement': len(excl_disagree),
            'excluded_both_DIFFERENT': len(excl_both_diff),
            'excluded_both_UNDETERMINED': len(excl_both_und),
            'within_eligible_transfer_UNDETERMINED': len(td_unknown),
            'ids_identity_disagreement': excl_disagree,
            'check': (len(sub) + len(excl_disagree) + len(excl_both_diff)
                      + len(excl_both_und) == len(ids)),
        },
    }
    if sub:
        a = [pa[i]['transfer_distance'] for i in sub]
        b = [pb[i]['transfer_distance'] for i in sub]
        k, lo, hi, err = kappa_ci(a, b, TD_CATS)
        kw, lw, hw, errw = kappa_ci(
            [x for x, y in zip(a, b) if x != 'UNDETERMINED' and y != 'UNDETERMINED'],
            [y for x, y in zip(a, b) if x != 'UNDETERMINED' and y != 'UNDETERMINED'],
            ['SAME_CONTEXT', 'NEAR', 'FAR'], weights='linear')
        rep['axis2'].update({
            'kappa_unweighted': k, 'ci_lower': lo, 'ci_upper': hi, 'error': err,
            'kappa_linear_weighted': kw, 'weighted_error': errw,
            'weighted_note': 'UNDETERMINED 를 뺀 3범주에서만. 거리 순서가 있으므로 선형 가중이 정당하다',
            'agreement_pct': sum(1 for x, y in zip(a, b) if x == y) / len(sub),
            'confusion': confusion(a, b, TD_CATS),
            'prevalence_A': dict(Counter(a)), 'prevalence_B': dict(Counter(b)),
        })
    else:
        rep['axis2']['error'] = '두 판정자가 모두 이해 SAME 으로 본 쌍이 0개다. 축 2 를 계산할 수 없다'

    # Core field κ 5개
    rep['core_field_kappa'] = {}
    for f in CORE_PERFORM:
        a = [pa[i]['_fields'][f] for i in ids]
        b = [pb[i]['_fields'][f] for i in ids]
        k, lo, hi, err = kappa_ci(a, b, ['SAME', 'DIFFERENT', 'UNKNOWN'])
        rep['core_field_kappa'][f] = {
            'kappa': k, 'ci_lower': lo, 'ci_upper': hi, 'error': err,
            'agreement_pct': sum(1 for x, y in zip(a, b) if x == y) / len(ids) if ids else 0,
            'disagree_n': sum(1 for x, y in zip(a, b) if x != y),
        }

    # 진단용 6×6
    la = [pa[i]['label_understand'] for i in ids]
    lb = [pb[i]['label_understand'] for i in ids]
    rep['diagnostic_label_matrix'] = {
        'note': '진단용. 통과·실패 판단에 쓰지 않는다',
        'stage': 'understand',
        'confusion': confusion(la, lb, LABEL_CATS),
    }

    # 불일치 집중 자동 요약
    conc = sorted(
        ((f, d['disagree_n'], d['kappa']) for f, d in rep['core_field_kappa'].items()),
        key=lambda t: -t[1])
    rep['disagreement_concentration'] = [
        {'field': f, 'disagreements': n, 'kappa': k} for f, n, k in conc]

    # prevalence 경고
    warns = []
    for stage in ('understand', 'perform'):
        for who in ('prevalence_A', 'prevalence_B'):
            pv = rep['axis1'][stage][who]
            tot = sum(pv.values())
            if tot and max(pv.values()) / tot > 0.9:
                top = max(pv, key=pv.get)
                warns.append(
                    f'축1 {stage} {who[-1]} 가 {top} 에 {max(pv.values())}/{tot} 로 몰렸다. '
                    f'κ 가 prevalence 효과로 낮아질 수 있다')
    if rep['axis2'].get('subset_n', 0) and rep['axis2']['subset_n'] < 10:
        warns.append(f"축2 분모가 {rep['axis2']['subset_n']} 쌍뿐이다. κ 를 해석할 때 구간을 함께 본다")
    rep['warnings'] = list(warns)

    # ── subset 진단 · ALL / EXISTING_SYNTHETIC / BLIND
    # diagnostic only. 공식 threshold 는 ALL 에만 적용한다.
    rep['subset_diagnostic'] = None
    if origin_map:
        subsets = {'ALL': ids,
                   'EXISTING_SYNTHETIC': [i for i in ids if origin_map.get(i) == 'existing'],
                   'BLIND': [i for i in ids if origin_map.get(i) == 'blind']}
        diag = {}
        for name, sids in subsets.items():
            if not sids:
                diag[name] = {'n': 0, 'error': '해당 쌍이 없다'}
                continue
            entry = {'n': len(sids)}
            for stage in ('understand', 'perform'):
                key = f'skill_identity_{stage}'
                a = [pa[i][key] for i in sids]
                b = [pb[i][key] for i in sids]
                k, err = cohen_kappa(a, b, SI_CATS)
                entry[f'{stage}_kappa'] = k
                entry[f'{stage}_error'] = err
                entry[f'{stage}_agreement'] = sum(1 for x, y in zip(a, b) if x == y) / len(sids)
            diag[name] = entry
        rep['subset_diagnostic'] = {
            'note': 'diagnostic only · 공식 통과·실패 판단에 쓰지 않는다. threshold 는 ALL 에만 적용',
            'subsets': diag,
        }
        # 경고 · 전체는 높은데 blind 만 낮은 경우
        warns2 = []
        for stage in ('understand', 'perform'):
            ka = diag.get('ALL', {}).get(f'{stage}_kappa')
            kb = diag.get('BLIND', {}).get(f'{stage}_kappa')
            ke = diag.get('EXISTING_SYNTHETIC', {}).get(f'{stage}_kappa')
            if ka is not None and kb is not None:
                if ka >= 0.6 and kb < 0.6:
                    warns2.append(
                        f'축1 {stage} · 전체 κ={ka:.3f} 는 문턱을 넘지만 BLIND κ={kb:.3f} 는 못 넘는다. '
                        f'문제 출처가 결과를 끌어올렸을 수 있다')
                if ke is not None and abs(ke - kb) >= 0.2:
                    warns2.append(
                        f'축1 {stage} · EXISTING κ={ke:.3f} 와 BLIND κ={kb:.3f} 의 차이가 {abs(ke-kb):.3f} 다. '
                        f'두 출처가 다른 난도를 가진 것으로 보인다')
        rep['subset_diagnostic']['warnings'] = warns2
        rep['warnings'] = rep.get('warnings', []) + warns2

    # 불일치 목록
    dis = []
    for i in ids:
        for key, cats in (('skill_identity_understand', SI_CATS),
                          ('skill_identity_perform', SI_CATS),
                          ('transfer_distance', TD_CATS)):
            if pa[i][key] != pb[i][key]:
                dis.append({'pair_id': i, 'axis': key,
                            'rater_A': pa[i][key], 'rater_B': pb[i][key],
                            'fields_A': {f: pa[i]['_fields'][f] for f in CORE_PERFORM},
                            'fields_B': {f: pb[i]['_fields'][f] for f in CORE_PERFORM},
                            'note_A': pa[i]['_note'], 'note_B': pb[i]['_note']})
    rep['disagreements'] = dis
    return rep


def decide(rep):
    """§11.4 기준으로 PASS/RETRY/FAIL 을 낸다. 숫자 하나만 내지 않는다."""
    d = {'verdict': None, 'reasons': [], 'next_action': [], 'per_criterion': {}}
    T = THRESHOLDS
    fails, retries = [], []

    for stage in ('understand', 'perform'):
        s = rep['axis1'][stage]
        k, lo = s['kappa'], s['ci_lower']
        name = f'skill_identity_{stage}_kappa'
        if k is None:
            d['per_criterion'][name] = {'result': 'NA', 'reason': s['error'],
                                        'basis': T['skill_identity_kappa']['basis']}
            fails.append(f'{name} 계산 불가 · {s["error"]}')
            continue
        if k < T['skill_identity_kappa']['retry_low'] or (lo is not None and lo < 0.4):
            r = 'FAIL'; fails.append(f'{name}={k:.3f} (CI 하한 {lo})')
        elif k < T['skill_identity_kappa']['pass']:
            r = 'RETRY'; retries.append(f'{name}={k:.3f}')
        else:
            r = 'PASS'
        d['per_criterion'][name] = {'result': r, 'point': k, 'ci': [lo, s['ci_upper']],
                                    'threshold': T['skill_identity_kappa']['pass'],
                                    'basis': T['skill_identity_kappa']['basis']}

    low = [f for f, v in rep['core_field_kappa'].items()
           if v['kappa'] is not None and v['kappa'] < T['core_field_kappa']['pass']]
    na = [f for f, v in rep['core_field_kappa'].items() if v['kappa'] is None]
    if len(low) >= 2:
        r = 'FAIL'; fails.append(f'Core field κ 가 0.5 미만인 필드 {len(low)}개 · {low}')
    elif len(low) == 1:
        r = 'RETRY'; retries.append(f'Core field κ 미달 · {low[0]}')
    else:
        r = 'PASS'
    d['per_criterion']['core_field_kappa'] = {
        'result': r, 'below_threshold': low, 'not_computable': na,
        'threshold': T['core_field_kappa']['pass'], 'basis': T['core_field_kappa']['basis']}

    ur = rep['undetermined_rate_axis1']
    if ur is None:
        r = 'NA'
    elif ur > T['undetermined_rate']['retry_max']:
        r = 'FAIL'; fails.append(f'축1 UNDETERMINED 비율 {ur:.1%}')
    elif ur > T['undetermined_rate']['pass_max']:
        r = 'RETRY'; retries.append(f'축1 UNDETERMINED 비율 {ur:.1%}')
    else:
        r = 'PASS'
    d['per_criterion']['undetermined_rate'] = {
        'result': r, 'value': ur, 'scope': '축 1 만. 거리 미결 제외',
        'basis': T['undetermined_rate']['basis']}

    k2 = rep['axis2'].get('kappa_unweighted')
    if k2 is None:
        d['per_criterion']['transfer_distance_kappa'] = {
            'result': 'NA', 'reason': rep['axis2'].get('error') or '계산 불가',
            'basis': T['transfer_distance_kappa']['basis'], 'can_fail_alone': False}
    else:
        r = 'PASS' if k2 >= T['transfer_distance_kappa']['pass'] else 'RETRY'
        if r == 'RETRY':
            retries.append(f'Transfer Distance κ={k2:.3f} · 단독 실패 판정은 하지 않는다')
        d['per_criterion']['transfer_distance_kappa'] = {
            'result': r, 'point': k2, 'ci': [rep['axis2'].get('ci_lower'), rep['axis2'].get('ci_upper')],
            'threshold': T['transfer_distance_kappa']['pass'],
            'basis': T['transfer_distance_kappa']['basis'], 'can_fail_alone': False}

    if fails:
        d['verdict'] = 'FAIL'
    elif retries:
        d['verdict'] = 'RETRY'
    else:
        d['verdict'] = 'PASS'
    d['reasons'] = fails + retries

    top = rep['disagreement_concentration'][0] if rep['disagreement_concentration'] else None
    if d['verdict'] == 'PASS':
        d['next_action'] = ['POC B 를 시작한다 (04_POC_B_SCAFFOLD/BLOCKED_UNTIL_A_PASS.md 해제)']
    elif d['verdict'] == 'RETRY':
        d['next_action'] = [
            f"가장 많이 갈린 필드 {top['field']} ({top['disagreements']}건) 의 질문을 더 좁은 이분 질문으로 쪼갠다" if top else '불일치 분포를 본다',
            'v0.2 후보를 ISSUES_FOR_V0_2.md 에 적는다',
            '규격을 고친 뒤 같은 쌍으로 1회만 재측정한다',
            'POC B 는 시작하지 않는다',
        ]
    else:
        d['next_action'] = [
            '구조 동등성 핵심 가설을 재검토한다',
            f"불일치가 {top['field']} 에 몰렸다면 그 필드가 사람이 답할 수 없는 질문일 가능성을 본다" if top else '',
            'POC B 는 시작하지 않는다',
        ]
    return d


def render(rep, dec, demo=False):
    L = []
    if demo:
        L += ['', '#' * 62, '#  DEMO ONLY · 샘플 데이터로 돌린 것이다.',
              '#  이것은 검증 결과가 아니다. NOT A VALIDATION RESULT.', '#' * 62]
    L += ['', '=' * 62, 'POC A · 규격 재현성 분석', '=' * 62,
          f"대상 쌍 {rep['n_pairs']}개"]
    if rep['only_in_A'] or rep['only_in_B']:
        L.append(f"  한쪽에만 있는 쌍 · A {rep['only_in_A']} · B {rep['only_in_B']}")

    L += ['', '── 축 1 · Skill Identity ' + '─' * 36]
    for stage in ('understand', 'perform'):
        s = rep['axis1'][stage]
        if s['kappa'] is None:
            L.append(f"  {stage:<11} κ = NA · {s['error']}")
        else:
            ci = f"[{s['ci_lower']:.3f}, {s['ci_upper']:.3f}]" if s['ci_lower'] is not None else '[CI 없음]'
            L.append(f"  {stage:<11} κ = {s['kappa']:.3f}  95% CI {ci}  일치율 {s['agreement_pct']:.1%}")
    L.append(f"  축1 UNDETERMINED 비율 = "
             f"{rep['undetermined_rate_axis1']:.1%}" if rep['undetermined_rate_axis1'] is not None else '  NA')

    L += ['', '── 축 2 · Transfer Distance ' + '─' * 33,
          f"  분모 {rep['axis2']['subset_n']}쌍 · {rep['axis2']['subset_rule']}"]
    if rep['axis2'].get('kappa_unweighted') is None:
        L.append(f"  κ = NA · {rep['axis2'].get('error')}")
    else:
        a2 = rep['axis2']
        ci = f"[{a2['ci_lower']:.3f}, {a2['ci_upper']:.3f}]" if a2['ci_lower'] is not None else '[CI 없음]'
        L.append(f"  unweighted κ = {a2['kappa_unweighted']:.3f}  95% CI {ci}  일치율 {a2['agreement_pct']:.1%}")
        if a2.get('kappa_linear_weighted') is not None:
            L.append(f"  linear weighted κ = {a2['kappa_linear_weighted']:.3f}  (보조 · UNDETERMINED 제외)")
        elif a2.get('weighted_error'):
            L.append(f"  linear weighted κ = NA · {a2['weighted_error']}")

    bd = rep['axis2'].get('denominator_breakdown')
    if bd:
        L += ['', '  분모 내역']
        L += [f"    전체 쌍                         {bd['total_pairs']}",
              f"    identity SAME 자격                {bd['identity_SAME_eligible']}",
              f"    identity 불일치로 제외             {bd['excluded_identity_disagreement']}",
              f"    양쪽 DIFFERENT 로 제외             {bd['excluded_both_DIFFERENT']}",
              f"    양쪽 UNDETERMINED 로 제외          {bd['excluded_both_UNDETERMINED']}",
              f"    자격 안에서 transfer UNDETERMINED  {bd['within_eligible_transfer_UNDETERMINED']}"]
        if not bd['check']:
            L.append('    ! 분모 합이 전체와 맞지 않는다')
        if bd['identity_SAME_eligible'] < 15:
            L.append(f"    ! 분모가 {bd['identity_SAME_eligible']}쌍뿐이다. "
                     f"높은 κ 가 나와도 강하게 해석하지 않는다")

    sd = rep.get('subset_diagnostic')
    if sd:
        L += ['', '── subset 진단 · diagnostic only ' + '─' * 27,
              '  공식 통과·실패 판단에 쓰지 않는다. threshold 는 ALL 에만 적용한다.', '']
        L.append(f"  {'subset':<20}{'n':>4}  {'이해 κ':>9}  {'수행 κ':>9}")
        for name in ('ALL', 'EXISTING_SYNTHETIC', 'BLIND'):
            e = sd['subsets'].get(name, {})
            if not e or e.get('n', 0) == 0:
                L.append(f"  {name:<20}{0:>4}  {'-':>9}  {'-':>9}")
                continue
            ku = e.get('understand_kappa')
            kp = e.get('perform_kappa')
            fu = f'{ku:.3f}' if ku is not None else 'NA'
            fp = f'{kp:.3f}' if kp is not None else 'NA'
            L.append(f"  {name:<20}{e['n']:>4}  {fu:>9}  {fp:>9}")
        for w in sd.get('warnings', []):
            L.append(f'  ! {w}')

    L += ['', '── Core field κ 5개 ' + '─' * 41]
    for f, v in rep['core_field_kappa'].items():
        if v['kappa'] is None:
            L.append(f"  {f:<24} κ = NA · {v['error']}")
        else:
            L.append(f"  {f:<24} κ = {v['kappa']:>6.3f}  불일치 {v['disagree_n']:>2}건  일치율 {v['agreement_pct']:.1%}")

    L += ['', '── 혼동 행렬 ' + '─' * 48,
          fmt_matrix(rep['axis1']['understand']['confusion'], SI_CATS, 'Skill Identity · 이해 (행 = A, 열 = B)'), '',
          fmt_matrix(rep['axis1']['perform']['confusion'], SI_CATS, 'Skill Identity · 수행'), '']
    if rep['axis2'].get('confusion'):
        L += [fmt_matrix(rep['axis2']['confusion'], TD_CATS, 'Transfer Distance'), '']
    L += [fmt_matrix(rep['diagnostic_label_matrix']['confusion'], LABEL_CATS,
                     '사용자 표기 · 이해 · 진단용 only')]

    L += ['', '── 불일치 집중 ' + '─' * 46]
    for c in rep['disagreement_concentration']:
        k = f"{c['kappa']:.3f}" if c['kappa'] is not None else 'NA'
        L.append(f"  {c['field']:<24} 불일치 {c['disagreements']:>2}건  κ {k}")

    if rep['warnings']:
        L += ['', '── 경고 ' + '─' * 54]
        L += [f'  ! {w}' for w in rep['warnings']]

    L += ['', '=' * 62, f"판정 · {dec['verdict']}", '=' * 62]
    for name, v in dec['per_criterion'].items():
        basis = {'adjacent_reference': '인접 준거', 'operational': '프로젝트 운영 기준'}.get(v.get('basis'), '')
        extra = ''
        if v.get('point') is not None:
            ci = v.get('ci') or [None, None]
            extra = f" · {v['point']:.3f}" + (f" CI[{ci[0]:.3f},{ci[1]:.3f}]" if ci[0] is not None else '')
        L.append(f"  {v['result']:<6} {name}{extra}   [{basis}]")
        if v.get('reason'):
            L.append(f"         사유 · {v['reason']}")
    if dec['reasons']:
        L += ['', '  미달 항목']
        L += [f'   - {r}' for r in dec['reasons']]
    L += ['', '  다음 행동']
    L += [f'   {i}. {a}' for i, a in enumerate([a for a in dec['next_action'] if a], 1)]
    if demo:
        L += ['', '#' * 62, '#  다시 적는다 · DEMO ONLY. 검증 결과가 아니다.', '#' * 62]
    return '\n'.join(L)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('rater_a')
    ap.add_argument('rater_b')
    ap.add_argument('--out', default='results')
    ap.add_argument('--demo', action='store_true', help='샘플 데이터임을 출력에 표시')
    ap.add_argument('--key', default=None,
                    help='_gold/randomization_key.csv · subset 진단용. 판정 중에는 쓰지 않는다')
    args = ap.parse_args()

    pa, prob_a = load_ratings(args.rater_a)
    pb, prob_b = load_ratings(args.rater_b)
    for who, probs in (('A', prob_a), ('B', prob_b)):
        for pid, msg in probs:
            print(f'[입력 오류] rater {who} · {pid} · {msg}', file=sys.stderr)

    origin_map = {}
    if args.key and os.path.exists(args.key):
        with open(args.key, encoding='utf-8-sig', newline='') as f:
            for r in csv.DictReader(f):
                origin_map[(r.get('pair_id') or '').strip()] = (r.get('origin') or '').strip()
        print(f'[subset] 대조표 {len(origin_map)}행 읽음 · diagnostic only', file=sys.stderr)

    rep = analyze(pa, pb, origin_map)
    dec = decide(rep)
    txt = render(rep, dec, demo=args.demo)
    print(txt)

    os.makedirs(args.out, exist_ok=True)
    with open(os.path.join(args.out, 'agreement_report.txt'), 'w', encoding='utf-8') as f:
        f.write(txt + '\n')
    payload = {k: v for k, v in rep.items() if k != 'disagreements'}
    payload['decision'] = dec
    payload['demo_only'] = bool(args.demo)
    payload['ci_method'] = {'type': 'percentile bootstrap', 'n': BOOTSTRAP_N, 'seed': BOOTSTRAP_SEED}
    with open(os.path.join(args.out, 'agreement_report.json'), 'w', encoding='utf-8') as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
    with open(os.path.join(args.out, 'disagreements.csv'), 'w', encoding='utf-8', newline='') as f:
        w = csv.writer(f)
        w.writerow(['pair_id', 'axis', 'rater_A', 'rater_B'] +
                   [f'A_{x}' for x in CORE_PERFORM] + [f'B_{x}' for x in CORE_PERFORM] +
                   ['note_A', 'note_B'])
        for d in rep['disagreements']:
            w.writerow([d['pair_id'], d['axis'], d['rater_A'], d['rater_B']] +
                       [d['fields_A'][x] for x in CORE_PERFORM] +
                       [d['fields_B'][x] for x in CORE_PERFORM] +
                       [d['note_A'], d['note_B']])
    print(f'\n저장 · {args.out}/agreement_report.txt · .json · disagreements.csv')


if __name__ == '__main__':
    main()
