"""frozen_spec_v0_1 의 판정 규칙을 그대로 옮긴 엔진.

decision_rules_machine_readable.json 과 같은 규칙을 담는다.
새 의미 추론을 넣지 않는다. 필드 값을 받아 등급을 돌려줄 뿐이다.

    from rule_engine import judge
    judge(annotation_dict)
"""
from __future__ import annotations

SAME, DIFFERENT, UNKNOWN = 'SAME', 'DIFFERENT', 'UNKNOWN'
UNDETERMINED = 'UNDETERMINED'
NOT_COMPUTED = 'NOT_COMPUTED'

CORE_UNDERSTAND = (
    'target_skill',
    'required_inference',
    'perspective_structure',
    'decidable_by_evidence',
)
CORE_PERFORM = CORE_UNDERSTAND + ('direct_check_allowed',)

# 거리 축 입력. Core 는 여기 들어오지 않는다.
DISTANCE_RELATIONAL = ('relationship_changed', 'situation_type_changed')
DISTANCE_CONSTRAINT = ('misread_cost_changed', 'recoverability_changed')
DISTANCE_COSMETIC = ('topic_changed', 'place_changed', 'participants_changed')

CHANGED = 'CHANGED'


class RuleError(ValueError):
    """규격이 허용하지 않는 값이 들어왔다."""


def _check_comparison(name, value):
    if value not in (SAME, DIFFERENT, UNKNOWN):
        raise RuleError(f'{name} 는 SAME/DIFFERENT/UNKNOWN 이어야 한다. 받은 값 {value!r}')


def _check_change(name, value):
    if value not in (CHANGED, SAME, UNKNOWN):
        raise RuleError(f'{name} 는 CHANGED/SAME/UNKNOWN 이어야 한다. 받은 값 {value!r}')


def skill_identity(annotation, stage):
    """축 1. 해당 단계의 Core 필드만 본다.

    UNKNOWN 이 하나라도 있으면 UNDETERMINED 가 DIFFERENT 보다 먼저다.
    모른 채로 다르다고 말하지 않기 위해서다.
    """
    fields = CORE_UNDERSTAND if stage == 'understand' else CORE_PERFORM
    values = []
    for f in fields:
        if f not in annotation:
            raise RuleError(f'{stage} 판정에 필요한 {f} 가 없다')
        _check_comparison(f, annotation[f])
        values.append(annotation[f])

    if UNKNOWN in values:
        return UNDETERMINED
    if DIFFERENT in values:
        return DIFFERENT
    return SAME


def transfer_distance(annotation, si_understand):
    """축 2. Skill Identity(이해) 가 SAME 일 때만 계산한다."""
    if si_understand != SAME:
        return NOT_COMPUTED

    for f in DISTANCE_RELATIONAL + DISTANCE_CONSTRAINT + DISTANCE_COSMETIC:
        if f in annotation:
            _check_change(f, annotation[f])

    rel = [annotation.get(f, UNKNOWN) for f in DISTANCE_RELATIONAL]
    con = [annotation.get(f, UNKNOWN) for f in DISTANCE_CONSTRAINT]

    # 관계나 상황 유형을 모르면 거리를 매길 수 없다
    if UNKNOWN in rel:
        return UNDETERMINED

    relational_changed = CHANGED in rel
    if not relational_changed:
        return 'SAME_CONTEXT'

    # 여기부터 관계 또는 상황 유형이 바뀐 경우.
    # context_constraints 가 바뀌면 FAR, 모르면 NEAR 에서 멈춘다.
    if CHANGED in con:
        return 'FAR'
    return 'NEAR'


def user_facing_label(si, dist):
    if si == UNDETERMINED:
        return UNDETERMINED
    if si == DIFFERENT:
        return 'DIFFERENT_SKILL'
    # si == SAME
    if dist == 'SAME_CONTEXT':
        return 'SAME_SKILL'
    if dist == 'NEAR':
        return 'NEAR_TRANSFER'
    if dist == 'FAR':
        return 'FAR_TRANSFER'
    if dist == UNDETERMINED:
        return 'SAME_SKILL_DISTANCE_UNDETERMINED'
    raise RuleError(f'SkillIdentity=SAME 인데 거리가 {dist!r} 다')


def judge(annotation):
    """주석 하나를 받아 두 축과 사용자 표기를 모두 돌려준다."""
    si_u = skill_identity(annotation, 'understand')
    si_p = skill_identity(annotation, 'perform')
    dist = transfer_distance(annotation, si_u)
    return {
        'skill_identity_understand': si_u,
        'skill_identity_perform': si_p,
        'transfer_distance': dist,
        'label_understand': user_facing_label(si_u, dist),
        'label_perform': user_facing_label(si_p, dist),
    }


def check_invariant(result):
    """PERFORM 이 SAME 이면 UNDERSTAND 도 SAME 이어야 한다(§11.1)."""
    if result['skill_identity_perform'] == SAME:
        return result['skill_identity_understand'] == SAME
    return True
