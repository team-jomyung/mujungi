# POC A 결과 · 규격 재현성

> 이 칸들은 **실제 측정 뒤에** 채운다. 측정 전에는 비워 둔다. 가짜 값을 넣지 않는다.

## 실행 정보

| | |
|---|---|
| 측정일 | |
| 규격 버전 | v0.1 (FROZEN) |
| 판정자 A | 이름/역할 · 규격 작업 참여 여부 |
| 판정자 B | |
| blind set 작성자 | 사람인가 격리 LLM 세션인가 |
| blind set QC | |
| 쌍 수 | 기존 __ + blind __ = __ |
| randomization seed | |
| 판정 소요 시간 | A __시간 · B __시간 |

## 주 지표 · 축 1 Skill Identity

| 지표 | 점추정 | 95% CI | 일치율 | 문턱 | 판정 |
|---|---|---|---|---|---|
| 이해 κ | | | | 0.6 · 인접 준거 | |
| 수행 κ | | | | 0.6 · 인접 준거 | |
| 축1 UNDETERMINED 비율 | | — | — | 0.20 · 운영 기준 | |

## 주 지표 · 축 2 Transfer Distance

| 지표 | 값 | 비고 |
|---|---|---|
| 분모 | __쌍 | 두 판정자가 모두 이해 축1 = SAME |
| unweighted κ | | |
| 95% CI | | |
| linear weighted κ | | 보조 · UNDETERMINED 제외 |
| 문턱 0.5 · 운영 기준 | | **단독 실패 판정 없음** |

## 보조 · Core field κ 다섯

| 필드 | κ | 불일치 건수 | 문턱 0.5 |
|---|---|---|---|
| target_skill | | | |
| required_inference | | | |
| perspective_structure | | | |
| decidable_by_evidence | | | |
| direct_check_allowed | | | |

## 혼동 행렬

`results/agreement_report.txt` 를 그대로 붙인다.

## 불일치 분석

| | |
|---|---|
| 가장 많이 갈린 필드 | |
| 그 필드에서 갈린 쌍 | |
| 갈린 이유 · 판정자 메모에서 | |
| 기존 20쌍 κ | |
| blind 40쌍 κ | |
| 두 출처의 차이 | **크면 문제 출처가 결과에 영향을 준 것이다** |

## 최종 판정

**PASS · RETRY · FAIL 중 하나**

판정 근거 ·

다음 행동 ·

## v0.2 후보

`00_README/ISSUES_FOR_V0_2.md` 에 추가한 항목 번호를 적는다.

## 하지 않은 것

- 임상 효과를 측정하지 않았다
- SCD 당사자를 대상으로 하지 않았다
- 이 결과는 **규격이 재현되는지**만 말한다
