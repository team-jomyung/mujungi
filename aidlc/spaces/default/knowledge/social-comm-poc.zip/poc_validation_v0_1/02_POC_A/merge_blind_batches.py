# -*- coding: utf-8 -*-
"""blind 후보 묶음들을 한 파일로 합친다. 선별기는 파일 하나를 연다.

    python merge_blind_batches.py

입력   _incoming/blind_candidates_raw.csv     묶음 1 · B01~B40
       _incoming/blind_candidates_raw_2.csv   묶음 2 · B41~B80 (있으면)
출력   _incoming/blind_candidates_all.csv     a1_counts.json 의 blind_candidates_file

본문을 화면에 찍지 않는다. 이 스크립트를 돌리는 쪽이 규격 작성자일 수 있기 때문이다.
번호가 겹치거나 칸이 비면 합치지 않고 멈춘다.
"""
import csv
import io
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
BATCHES = ['_incoming/blind_candidates_raw.csv', '_incoming/blind_candidates_raw_2.csv']
COLS = ['pair_id', 'event_A', 'event_B']


def main():
    counts = json.loads(io.open(os.path.join(HERE, 'a1_counts.json'), encoding='utf-8').read())
    out_rel = counts['blind_candidates_file']
    rows, seen, problems, used = [], set(), [], []
    for rel in BATCHES:
        p = os.path.join(HERE, rel)
        if not os.path.exists(p):
            continue
        with io.open(p, encoding='utf-8-sig', newline='') as f:
            rd = csv.DictReader(f)
            if rd.fieldnames != COLS:
                problems.append('%s · 열이 %s 이다. %s 여야 한다' % (rel, rd.fieldnames, COLS))
                continue
            n = 0
            for r in rd:
                pid = (r['pair_id'] or '').strip()
                if not pid or not (r['event_A'] or '').strip() or not (r['event_B'] or '').strip():
                    problems.append('%s · 빈 칸 · %s' % (rel, pid or '(번호 없음)'))
                    continue
                if pid in seen:
                    problems.append('%s · 번호 중복 · %s' % (rel, pid))
                    continue
                seen.add(pid)
                rows.append({k: r[k].strip() for k in COLS})
                n += 1
            used.append((rel, n))
    if problems:
        print('합치지 않는다.')
        for x in problems:
            print('  ', x)
        return 1
    with io.open(os.path.join(HERE, out_rel), 'w', encoding='utf-8', newline='') as f:
        w = csv.DictWriter(f, COLS)
        w.writeheader()
        w.writerows(rows)
    ex = counts['rc1_execution']
    print('합침 ·', ' + '.join('%s %d' % (os.path.basename(r), n) for r, n in used), '=', len(rows))
    print('저장 ·', out_rel)
    if len(rows) < ex['blind_request_min']:
        print('[경고] 후보 %d쌍 · 의뢰 최소 %d쌍보다 적다. 선별에서 버릴 여유가 없다'
              % (len(rows), ex['blind_request_min']))
    return 0


if __name__ == '__main__':
    sys.exit(main())
