"""기존 합성 쌍과 선별된 blind 쌍을 섞어 판정용 쌍을 만든다.

개수와 blind 파일 이름은 a1_counts.json 한 곳에서 정한다(ERR-05). 지금 값은 합성 20 + blind 40 = 60쌍이다.
규격 v0.1 은 blind 20 이다. 다른 개수가 들어오면 섞기는 하되 경고를 찍는다.

    python randomize_pairs.py --existing existing_synthetic_20.csv \
                              --blind blind_selected_for_raters.csv \
                              --seed 20260912

출력
  randomized_pairs.csv        판정자에게 주는 것. 출처 표시 없음
  _gold/randomization_key.csv 어느 P 번호가 어느 원본인지. 분석할 때만 연다
"""
import argparse
import csv
import io
import json
import os
import random

HERE = os.path.dirname(os.path.abspath(__file__))
GOLD = os.path.join(HERE, '_gold')


def counts():
    return json.loads(io.open(os.path.join(HERE, 'a1_counts.json'), encoding='utf-8').read())


def default_blind():
    """선별기가 내려 주는 이름을 먼저 찾고, 없으면 옛 이름을 찾는다."""
    c = counts()
    for name in [c['blind_selected_filename']] + c.get('blind_selected_filename_legacy', []):
        if os.path.exists(os.path.join(HERE, name)):
            return os.path.join(HERE, name)
    return os.path.join(HERE, c['blind_selected_filename'])


def load(path, tag):
    if not os.path.exists(path):
        return []
    with io.open(path, encoding='utf-8-sig', newline='') as f:
        rows = list(csv.DictReader(f))
    out = []
    for r in rows:
        pid = (r.get('pair_id') or '').strip()
        a = (r.get('event_A') or '').strip()
        b = (r.get('event_B') or '').strip()
        if pid and a and b:
            out.append({'origin': tag, 'origin_id': pid, 'event_A': a, 'event_B': b})
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--existing', default=os.path.join(HERE, 'existing_synthetic_20.csv'))
    ap.add_argument('--blind', default=default_blind())
    ap.add_argument('--seed', type=int, default=20260912)
    ap.add_argument('--same-order', action='store_true',
                    help='두 판정자에게 같은 순서를 준다. 기본값이 같은 순서다')
    ap.add_argument('--different-order', action='store_true',
                    help='판정자마다 다른 순서를 준다')
    args = ap.parse_args()

    ex = load(args.existing, 'existing')
    bl = load(args.blind, 'blind')
    if not bl:
        print(f'[경고] blind set 이 없다 · {args.blind}')
        print('       blind_set_authoring_protocol.md 를 따라 먼저 만든다.')
        print('       지금은 기존 합성 쌍만으로 양식을 만든다. 이것은 공식 POC A 가 아니다.')

    want = counts()
    if bl and len(bl) != want['rc1_execution']['blind_select']:
        print(f"[경고] blind {len(bl)}쌍 · a1_counts.json {want['rc1_execution']['blind_select']}쌍 "
              f"· 규격 v0.1 {want['frozen_spec_v0_1']['blind']}쌍")
        print('       섞기는 한다. 결과 보고에 실제 개수를 적는다.')
    if len(ex) != want['rc1_execution']['existing_synthetic']:
        print(f"[경고] 기존 합성 {len(ex)}쌍 · a1_counts.json {want['rc1_execution']['existing_synthetic']}쌍")

    pool = ex + bl
    rng = random.Random(args.seed)
    rng.shuffle(pool)

    for i, r in enumerate(pool, 1):
        r['pair_id'] = 'P%02d' % i

    os.makedirs(GOLD, exist_ok=True)

    out_path = os.path.join(HERE, 'randomized_pairs.csv')
    with io.open(out_path, 'w', encoding='utf-8', newline='') as f:
        w = csv.DictWriter(f, ['pair_id', 'event_A', 'event_B'])
        w.writeheader()
        for r in pool:
            w.writerow({k: r[k] for k in ('pair_id', 'event_A', 'event_B')})

    key_path = os.path.join(GOLD, 'randomization_key.csv')
    with io.open(key_path, 'w', encoding='utf-8', newline='') as f:
        w = csv.DictWriter(f, ['pair_id', 'origin', 'origin_id'])
        w.writeheader()
        for r in pool:
            w.writerow({k: r[k] for k in ('pair_id', 'origin', 'origin_id')})

    manifest = {
        'seed': args.seed,
        'n_existing': len(ex),
        'n_blind': len(bl),
        'n_total': len(pool),
        'order_policy': 'different' if args.different_order else 'same',
    }
    with io.open(os.path.join(HERE, 'randomization_manifest.txt'), 'w', encoding='utf-8') as f:
        for k, v in manifest.items():
            f.write(f'{k}: {v}\n')

    if args.different_order:
        for who, off in (('A', 1), ('B', 2)):
            r2 = random.Random(args.seed + off)
            order = list(pool)
            r2.shuffle(order)
            p = os.path.join(HERE, f'randomized_pairs_rater_{who}.csv')
            with io.open(p, 'w', encoding='utf-8', newline='') as f:
                w = csv.DictWriter(f, ['pair_id', 'event_A', 'event_B'])
                w.writeheader()
                for r in order:
                    w.writerow({k: r[k] for k in ('pair_id', 'event_A', 'event_B')})
            print('  판정자별 순서 ·', p)

    print(f"섞음 · 기존 {len(ex)} + blind {len(bl)} = {len(pool)}쌍 · seed {args.seed}")
    print(f'  판정자용 · {out_path}')
    print(f'  대조표   · {key_path}  ← 판정 끝나기 전에는 열지 않는다')


if __name__ == '__main__':
    main()
