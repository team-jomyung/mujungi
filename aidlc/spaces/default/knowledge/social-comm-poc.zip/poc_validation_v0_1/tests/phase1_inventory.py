"""PHASE 1 · 실제 파일 전수조사.

    python tests/phase1_inventory.py

인수인계 문서를 믿지 않는다. 파일시스템이 ground truth 다.
디렉터리는 세지 않는다. 숨김 파일과 cache 도 전부 잡아 분류만 달리한다.
"""
from __future__ import annotations

import csv
import hashlib
import io
import json
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, 'tests')

# 인수인계 문서가 "요구 파일 47개" 라고 부른 목록. 원본 지시문에서 그대로 옮긴다.
REQUIRED = {
    '00_README': ['README.md', 'RUNBOOK.md', 'HUMAN_ACTIONS.md', 'ISSUES_FOR_V0_2.md'],
    '01_SPEC': ['frozen_spec_v0_1.html', 'frozen_spec_summary.md',
                'decision_rules_machine_readable.json'],
    '02_POC_A': ['annotation_guideline_onepage.md', 'annotation_form.csv', 'annotation_form.json',
                 'existing_synthetic_20.csv', 'blind_set_authoring_protocol.md',
                 'blind_set_generator_prompt.md', 'blind_set_qc_checklist.md',
                 'randomization_plan.md', 'randomize_pairs.py', 'analyze_agreement.py',
                 'sample_rater_A.csv', 'sample_rater_B.csv', 'POC_A_result_template.md'],
    '03_POC_C': ['pilot_protocol.md', 'consent_draft.md', 'participant_instruction.md',
                 'intake_questions.md', 'followup_24_72h.md',
                 'personal_social_event.schema.json', 'clarification_rules.json',
                 'pii_redaction_rules.md', 'retention_deletion_policy_draft.md',
                 'intake_prototype.html', 'synthetic_events.json', 'analyze_pilot.py',
                 'POC_C_result_template.md'],
    '04_POC_B_SCAFFOLD': ['BLOCKED_UNTIL_A_PASS.md', 'generator_prompt.md',
                          'validator_prompt.md', 'human_evaluation_form.csv', 'seed_10.json',
                          'generation_harness.py', 'preservation_metrics.py',
                          'POC_B_result_template.md'],
    '05_EXPERT_REVIEW': ['expert_review_packet.md', 'expert_questions.md',
                         'review_response_template.csv'],
    '06_FINAL': ['POC_execution_dashboard.md', 'decision_matrix.md', 'NEXT_ACTIONS.md'],
}
REQUIRED_SET = {f'{d}/{f}' for d, fs in REQUIRED.items() for f in fs}

# 산출물이 만들어지는 자리
GENERATED_DIRS = ('results_demo', 'b_output')
GENERATED_FILES = {
    '02_POC_A/annotation_form.csv', '02_POC_A/annotation_form.json',
    '02_POC_A/existing_synthetic_20.csv', '02_POC_A/sample_rater_A.csv',
    '02_POC_A/sample_rater_B.csv',
    '02_POC_A/_gold/existing_synthetic_20_SPEC_EXPECTED.csv',
    '03_POC_C/synthetic_events.json', '03_POC_C/synthetic_events.csv',
    '03_POC_C/synthetic_followups.csv',
    '04_POC_B_SCAFFOLD/human_evaluation_form.csv',
    '04_POC_B_SCAFFOLD/sample_human_eval_DEMO.csv',
    'tests/test_results.txt', 'tests/audit_results.txt',
}
CACHE_PAT = re.compile(r'(__pycache__|\.pyc$|\.pyo$|\.DS_Store$|Thumbs\.db$|~$|\.swp$|\.tmp$)')
OS_META = ('.DS_Store', 'Thumbs.db', 'desktop.ini')


def sha256(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for chunk in iter(lambda: f.read(65536), b''):
            h.update(chunk)
    return h.hexdigest()


def categorize(relpath, name, ext):
    parts = relpath.split('/')
    if CACHE_PAT.search(relpath) or '__pycache__' in parts:
        return 'cache'
    if name in OS_META:
        return 'os_metadata'
    if parts[0] == 'tests':
        if name.endswith('_results.txt'):
            return 'test_output'
        return 'test'
    if any(p in GENERATED_DIRS for p in parts):
        return 'demo_result'
    if parts[-2:-1] == ['_gold']:
        return 'data_restricted'
    if parts[-2:-1] == ['_incoming']:
        return 'data_restricted' if ext == '.csv' else 'doc'
    if ext == '.py':
        return 'source'
    if ext in ('.md', '.html'):
        return 'doc' if ext == '.md' else ('source' if 'prototype' in name or 'app' in name else 'doc')
    if ext in ('.csv', '.json', '.txt'):
        return 'data'
    return 'other'


def purpose(relpath, name, cat):
    if relpath.startswith('00_README'):
        return '인수인계 · 운영 문서'
    if relpath.startswith('01_SPEC'):
        return '동결 규격과 기계 판독 규칙'
    if relpath.startswith('02_POC_A'):
        return 'POC A · 규격 재현성'
    if relpath.startswith('03_POC_C'):
        return 'POC C · 사건 수집 파일럿'
    if relpath.startswith('04_POC_B'):
        return 'POC B · 구조 보존 (차단됨)'
    if relpath.startswith('05_EXPERT'):
        return '전문가 검토 패킷'
    if relpath.startswith('06_FINAL'):
        return '의사결정 · 대시보드'
    if relpath.startswith('tests'):
        return '시험과 품질 감사'
    return '분류 없음'


def demo_or_real(relpath, cat, text):
    if cat in ('demo_result',):
        return 'demo'
    low = relpath.lower()
    if 'sample_' in low or 'synthetic' in low or '_demo' in low:
        return 'demo'
    if text and ('DEMO ONLY' in text or 'NOT VALIDATION RESULT' in text):
        return 'demo_marked'
    if cat in ('cache', 'os_metadata'):
        return 'n/a'
    return 'real'


def main():
    rows = []
    for dp, dn, fn in os.walk(ROOT):
        for f in sorted(fn):
            full = os.path.join(dp, f)
            relp = os.path.relpath(full, ROOT).replace('\\', '/')
            ext = os.path.splitext(f)[1].lower()
            try:
                size = os.path.getsize(full)
                digest = sha256(full)
            except OSError as e:
                rows.append({'relative_path': relp, 'filename': f, 'extension': ext,
                             'bytes': -1, 'sha256': f'ERROR {e}', 'category': 'error',
                             'purpose': '', 'generated_or_source': '', 'demo_or_real': '',
                             'required_or_optional': '', 'executable': ''})
                continue
            cat = categorize(relp, f, ext)
            text = ''
            if ext in ('.py', '.md', '.json', '.html', '.csv', '.txt') and size < 400000:
                try:
                    text = io.open(full, encoding='utf-8', errors='replace').read()
                except OSError:
                    text = ''
            gen = 'generated' if (relp in GENERATED_FILES or cat in
                                  ('demo_result', 'cache', 'test_output')) else 'source'
            rows.append({
                'relative_path': relp,
                'filename': f,
                'extension': ext,
                'bytes': size,
                'sha256': digest,
                'category': cat,
                'purpose': purpose(relp, f, cat),
                'generated_or_source': gen,
                'demo_or_real': demo_or_real(relp, cat, text),
                'required_or_optional': 'required' if relp in REQUIRED_SET else 'optional',
                'executable': 'yes' if (ext == '.py' and '__main__' in text) else 'no',
            })

    rows.sort(key=lambda r: r['relative_path'])
    cols = ['relative_path', 'filename', 'extension', 'bytes', 'sha256', 'category',
            'purpose', 'generated_or_source', 'demo_or_real', 'required_or_optional',
            'executable']
    with io.open(os.path.join(OUT, 'ACTUAL_FILE_INVENTORY.csv'), 'w',
                 encoding='utf-8', newline='') as f:
        w = csv.DictWriter(f, cols)
        w.writeheader()
        w.writerows(rows)

    from collections import Counter
    by_cat = Counter(r['category'] for r in rows)
    by_gen = Counter(r['generated_or_source'] for r in rows)
    by_req = Counter(r['required_or_optional'] for r in rows)
    by_demo = Counter(r['demo_or_real'] for r in rows)

    ndirs = sum(len(dn) for _, dn, _ in os.walk(ROOT))
    countable = [r for r in rows if r['category'] not in ('cache', 'os_metadata')]
    missing_required = sorted(REQUIRED_SET - {r['relative_path'] for r in rows})

    summary = {
        'root': ROOT.replace('\\', '/'),
        'total_files_all': len(rows),
        'total_files_excluding_cache_and_os_meta': len(countable),
        'directories_not_counted': ndirs,
        'by_category': dict(by_cat),
        'by_generated_or_source': dict(by_gen),
        'by_required_or_optional': dict(by_req),
        'by_demo_or_real': dict(by_demo),
        'required_declared': len(REQUIRED_SET),
        'required_present': len(REQUIRED_SET) - len(missing_required),
        'required_missing': missing_required,
        'total_bytes': sum(r['bytes'] for r in rows if r['bytes'] > 0),
    }
    with io.open(os.path.join(OUT, 'ACTUAL_FILE_INVENTORY.json'), 'w', encoding='utf-8') as f:
        json.dump({'summary': summary, 'files': rows}, f, ensure_ascii=False, indent=2)

    print('=== 실제 전수조사 ===')
    print(f"전체 파일          {summary['total_files_all']}")
    print(f"cache·OS 제외      {summary['total_files_excluding_cache_and_os_meta']}")
    print(f"디렉터리(미포함)   {summary['directories_not_counted']}")
    print(f"총 바이트          {summary['total_bytes']:,}")
    print()
    print('범주별')
    for k, v in sorted(by_cat.items(), key=lambda kv: -kv[1]):
        print(f'  {k:<18} {v}')
    print()
    print('생성/원본')
    for k, v in by_gen.items():
        print(f'  {k:<18} {v}')
    print()
    print(f"요구 파일 선언 {summary['required_declared']} · 존재 {summary['required_present']}")
    if missing_required:
        for m in missing_required:
            print('  MISSING', m)
    print()
    print('저장 · tests/ACTUAL_FILE_INVENTORY.csv · .json')
    return 0


if __name__ == '__main__':
    sys.exit(main())
