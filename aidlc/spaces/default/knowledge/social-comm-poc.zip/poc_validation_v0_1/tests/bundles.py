# -*- coding: utf-8 -*-
"""역할별 번들을 만들고, 가면 안 되는 것이 갔는지 검사한다.

번들 규격과 금지 규칙을 한 파일에 둔다. 두 곳에 두면 반드시 어긋난다.

  python tests/bundles.py build          dist/ 를 새로 만든다
  python tests/bundles.py check          dist/ 를 검사한다
  python tests/bundles.py list           역할과 규칙을 보여 준다

면제 표시 · 검사기 자신이나 도구가 금칙어 목록을 들고 있으면 걸린다.
그 줄에 leakcheck-ok 를 적으면 넘어간다. 몇 건을 넘어갔는지 반드시 출력한다.
"""

import io
import json
import os
import re
import shutil
import sys
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
DIST = os.path.join(ROOT, 'dist')

TEXT_EXT = {'.md', '.py', '.json', '.html', '.csv', '.txt'}
EXEMPT_MARK = 'leakcheck' + '-ok'
RC_TAG = 'RC1'


def _a1_counts():
    """쌍 수의 유일한 출처 02_POC_A/a1_counts.json (ERR-05). 설명 문구를 여기서 만든다."""
    p = os.path.join(ROOT, '02_POC_A', 'a1_counts.json')
    return json.loads(io.open(p, encoding='utf-8').read())


_A1 = _a1_counts()
_EX = _A1['rc1_execution']
SELECT_DESC = ('blind 후보 %d~%d쌍에서 %d쌍을 고른다. 이 사람은 판정자가 될 수 없다'
               % (_EX['blind_request_min'], _EX['blind_request_max'], _EX['blind_select']))


# ─────────────────────── 번들 규격 ───────────────────────
#
# files  · 그대로 복사할 경로. 디렉터리로 끝나면 통째로
# rename · 원본 경로를 번들 안에서 다른 이름으로 둔다. 파일 이름 자체가 출처를 말할 때 쓴다
# needs  · 없으면 번들을 만들되 경고하고 안내문을 넣는다. 사람이 먼저 해야 하는 것
# rules  · 이 번들에 있으면 안 되는 것

RATER_RULES = {
    'no_path': ['_gold', 'sample_rater_', 'randomization_key', 'SPEC_EXPECTED',
                'blind_candidates', 'blind_set_generator_prompt', 'existing_synthetic',
                'frozen_spec_v0_1.html', 'analyze_agreement.py', 'decision_rules_machine_readable',
                'results_demo', 'audit', 'ACTUAL_FILE_INVENTORY'],
    'no_text': [
        (r'expected_label', '기대 라벨'),
        (r'intended_grade', '의도한 등급'),
        (r'SPEC_EXPECTED', '규격 기대값'),
        (r'randomization_key', '대조표'),
        (r'origin_id', '원본 번호'),
        (r'(?:kappa|κ)\s*[≥>=]+\s*0?\.\d', '문턱 수치'),
        (r'(?:문턱|threshold)\s*(?:은|는|:)?\s*0?\.\d', '문턱 수치'),
    ],
    'pair_ids_must_match': r'^P\d+$',
}

BUNDLES = {
    'admin': {
        'desc': '전부. 운영자 한 사람만 가진다',
        'files': ['.'],
        'rules': {},
    },

    'blind_selector': {
        'desc': SELECT_DESC,
        'files': [
            '02_POC_A/blind_selector.html',
            '02_POC_A/blind_set_qc_checklist.md',
            '02_POC_A/blind_set_authoring_protocol.md',
            '02_POC_A/check_blind_format.py',
            '02_POC_A/_incoming/blind_candidates_all.csv',
            '02_POC_A/_incoming/PROVENANCE.md',
            '02_POC_A/_incoming/PROVENANCE_batch2.md',
            '02_POC_A/_incoming/BLIND_CANDIDATE_STATUS.md',
            '02_POC_A/check_blind_overlap.py',
        ],
        'rules': {
            'no_path': ['_gold', 'sample_rater_', 'randomization_key', 'SPEC_EXPECTED',
                        'analyze_agreement.py', 'rule_engine.py'],
            'no_text': [(r'expected_label', '기대 라벨'),
                        (r'SPEC_EXPECTED', '규격 기대값'),
                        (r'randomization_key', '대조표')],
        },
    },

    'rater_A': {
        'desc': '판정자 A. 쌍을 읽고 다섯 가지와 일곱 가지를 적는다',
        'files': [
            '02_POC_A/rater_app.html',
            '02_POC_A/annotation_guideline_onepage.md',
            '02_POC_A/annotation_form.csv',
        ],
        'needs': [('02_POC_A/randomized_pairs_rater_A.csv', 'pairs_to_judge.csv'),
                  ('02_POC_A/randomized_pairs.csv', 'pairs_to_judge.csv')],
        'rules': RATER_RULES,
    },

    'rater_B': {
        'desc': '판정자 B. A 와 같은 자료를 받되 결과를 서로 보지 않는다',
        'files': [
            '02_POC_A/rater_app.html',
            '02_POC_A/annotation_guideline_onepage.md',
            '02_POC_A/annotation_form.csv',
        ],
        'needs': [('02_POC_A/randomized_pairs_rater_B.csv', 'pairs_to_judge.csv'),
                  ('02_POC_A/randomized_pairs.csv', 'pairs_to_judge.csv')],
        'rules': RATER_RULES,
    },

    'poc_c_operator': {
        'desc': 'POC C 파일럿 운영자. 참가자를 맞고 결과를 모은다',
        'files': [
            '03_POC_C/pilot_protocol.md',
            '03_POC_C/consent_draft.md',
            '03_POC_C/participant_instruction.md',
            '03_POC_C/followup_24_72h.md',
            '03_POC_C/retention_deletion_policy_draft.md',
            '03_POC_C/pii_redaction_rules.md',
            '03_POC_C/intake_questions.md',
            '03_POC_C/personal_social_event.schema.json',
            '03_POC_C/clarification_rules.json',
            '03_POC_C/analyze_pilot.py',
            '03_POC_C/personal_pattern.py',
            '03_POC_C/POC_C_result_template.md',
            '03_POC_C/privacy_test.html',
            '03_POC_C/privacy_test_cases.json',
            '03_POC_C/PRIVACY_TEST_RESULT.md',
            '03_POC_C/intake_prototype.html',
        ],
        'rules': {
            'no_path': ['_gold', 'sample_rater_', 'SPEC_EXPECTED'],
            'no_text': [(r'expected_label', '기대 라벨')],
        },
    },

    'poc_c_participant': {
        'desc': '참가자. 겪은 일을 적는 화면 하나뿐이다',
        'files': [
            '03_POC_C/intake_prototype.html',
            '03_POC_C/participant_instruction.md',
            '03_POC_C/consent_draft.md',
        ],
        'rules': {
            'no_path': ['_gold', 'sample_rater_', 'SPEC_EXPECTED', 'analyze', 'pilot_protocol',
                        'schema', 'rule', 'test', 'results_demo', 'synthetic'],
            'no_text': [(r'expected_label', '기대 라벨'),
                        (r'(?:kappa|κ)\s*[≥>=]+\s*0?\.\d', '문턱 수치')],
        },
    },

    'expert_review': {
        'desc': '외부 검토자. 규격과 질문지를 본다. 사람 판정 결과는 아직 없다',
        'files': [
            '05_EXPERT_REVIEW/expert_questions.md',
            '05_EXPERT_REVIEW/expert_review_packet.md',
            '05_EXPERT_REVIEW/review_response_template.csv',
            '01_SPEC/frozen_spec_summary.md',
            '01_SPEC/frozen_spec_v0_1.html',
            '00_README/ISSUES_FOR_V0_2.md',
        ],
        'rules': {
            'no_path': ['_gold', 'sample_rater_', 'SPEC_EXPECTED', 'randomization_key'],
            'no_text': [(r'randomization_key', '대조표')],
        },
    },
}

ROLE_ORDER = ['admin', 'blind_selector', 'rater_A', 'rater_B',
              'poc_c_operator', 'poc_c_participant', 'expert_review']


# ─────────────────────── 만들기 ───────────────────────

def _leaks(src, rules):
    """넣기 전에 검사한다. 검사기와 같은 규칙을 쓴다.

    만든 뒤에 걸러 내면 이미 한 번 디스크에 쓰인 뒤다.
    애초에 안 들어가게 하는 편이 낫다."""
    if not rules or os.path.splitext(src)[1].lower() not in TEXT_EXT:
        return None
    try:
        text = io.open(src, encoding='utf-8', errors='replace').read()
    except Exception as e:
        return '읽지 못함 · %s' % e
    pat = rules.get('pair_ids_must_match')
    if pat and src.lower().endswith('.csv'):
        bad = _bad_pair_ids(text, pat)
        if bad:
            return '쌍 번호가 출처를 말한다 · ' + ' '.join(bad[:4])
    for rx, why in rules.get('no_text', []):
        for m in re.finditer(rx, text, re.I):
            line = text.split('\n')[text.count('\n', 0, m.start())]
            if EXEMPT_MARK in line:
                continue
            return '%s · %s' % (why, m.group(0)[:30])
    return None


def _copy_into(src_rel, dst_dir, as_name=None, rules=None):
    src = os.path.join(ROOT, src_rel)
    if not os.path.exists(src):
        return None, '없음'
    why = _leaks(src, rules)
    if why:
        return None, why
    name = as_name or os.path.basename(src_rel)
    dst = os.path.join(dst_dir, name)
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    shutil.copy2(src, dst)
    return name, None


def _copy_all(dst_dir):
    """admin 용. 전체를 옮기되 캐시와 dist 자신은 뺀다."""
    n = 0
    for dp, dn, fn in os.walk(ROOT):
        dn[:] = [d for d in dn if d not in ('__pycache__', 'dist', '.git')]
        for f in fn:
            src = os.path.join(dp, f)
            rel = os.path.relpath(src, ROOT).replace('\\', '/')
            dst = os.path.join(dst_dir, rel)
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.copy2(src, dst)
            n += 1
    return n


def build():
    if os.path.isdir(DIST):
        shutil.rmtree(DIST)
    os.makedirs(DIST)

    report = []
    for role in ROLE_ORDER:
        spec = BUNDLES[role]
        out = os.path.join(DIST, role)
        os.makedirs(out, exist_ok=True)
        got, absent, notes = [], [], []
        rules = spec.get('rules') or {}

        if spec['files'] == ['.']:
            n = _copy_all(out)
            got = ['(전체 %d개)' % n]
        else:
            for rel in spec['files']:
                name, why = _copy_into(rel, out, rules=rules)
                if name:
                    got.append(rel)
                else:
                    absent.append('%s · %s' % (rel, why))

        # 사람이 먼저 해야 얻어지는 것
        for rel, as_name in spec.get('needs', []):
            if any(g.endswith(as_name) for g in got):
                continue
            name, why = _copy_into(rel, out, as_name, rules=rules)
            if name:
                got.append(rel + '  →  ' + as_name)
                break
            if why and why != '없음':
                absent.append('%s · %s' % (rel, why))
        else:
            if spec.get('needs'):
                notes.append(
                    '판정할 쌍 파일이 아직 없다.\n'
                    '02_POC_A 에서 아래를 먼저 돌린다.\n'
                    '    python randomize_pairs.py --different-order\n'
                    '그 전에 선별된 blind 쌍(%s)이 있어야 한다.\n'
                    % _A1['blind_selected_filename'] +
                    '섞지 않은 원본을 그대로 주면 쌍 번호가 출처를 말한다. 그러면 blind 가 아니다.')

        _write_role_readme(out, role, spec, got, absent, notes)
        report.append((role, len(got), len(absent), notes))

    return report


def zip_roles():
    """역할별 ZIP 을 만든다. admin 은 본 묶음과 같으므로 뺀다.

    ERR-02 · 예전에는 make_release 만 이것을 했다. 그래서 poc.py bundles 는
    폴더만 만들고 인수인계 문서가 적은 role ZIP 은 없었다."""
    made = []
    if not os.path.isdir(DIST):
        return made
    for role in sorted(os.listdir(DIST)):
        d = os.path.join(DIST, role)
        if not os.path.isdir(d) or role == 'admin':
            continue
        zp = os.path.join(DIST, '%s_%s.zip' % (role, RC_TAG))
        if os.path.exists(zp):
            os.remove(zp)
        n = 0
        with zipfile.ZipFile(zp, 'w', zipfile.ZIP_DEFLATED) as z:
            for dp, _, fn in os.walk(d):
                for f in sorted(fn):
                    fp = os.path.join(dp, f)
                    inner = os.path.relpath(fp, d).replace(os.sep, '/')
                    z.write(fp, role + '/' + inner)
                    n += 1
        made.append((role, n, os.path.getsize(zp)))
    return made


def _write_role_readme(out, role, spec, got, absent, notes):
    L = ['# ' + role, '', spec['desc'], '',
         '이 꾸러미에는 이 역할에 필요한 것만 들어 있다.',
         '다른 역할의 자료를 요청받으면 운영자에게 말한다.', '']
    if notes:
        L += ['## 먼저 해야 할 것', '']
        for n in notes:
            L += ['```', n, '```', '']
    L += ['## 들어 있는 것', '']
    for g in got:
        L.append('- `%s`' % g)
    if absent:
        L += ['', '## 넣지 않은 것', '']
        for a in absent:
            L.append('- `%s`' % a)
    rules = spec.get('rules') or {}
    if rules:
        L += ['', '## 이 꾸러미에 있으면 안 되는 것', '']
        # 이 목록 자체가 금칙어를 담는다. 면제 표시를 붙여야 검사기가 자기 꼬리를 물지 않는다
        for p in rules.get('no_path', []):
            L.append('- 경로에 `%s` 가 들어간 파일   <!-- %s -->' % (p, EXEMPT_MARK))
        for rx, why in rules.get('no_text', []):
            L.append('- %s   <!-- %s -->' % (why, EXEMPT_MARK))
        if rules.get('pair_ids_must_match'):
            L.append('- `P` 로 시작하지 않는 쌍 번호. 번호가 출처를 말하면 blind 가 아니다')
        L += ['', '`python tests/bundles.py check` 가 이것을 기계로 확인한다.']
    io.open(os.path.join(out, 'README.md'), 'w', encoding='utf-8').write('\n'.join(L) + '\n')


# ─────────────────────── 검사 ───────────────────────

def _text_files(d):
    for dp, dn, fn in os.walk(d):
        dn[:] = [x for x in dn if x != '__pycache__']
        for f in fn:
            p = os.path.join(dp, f)
            if os.path.splitext(f)[1].lower() in TEXT_EXT:
                yield p


def check():
    """(지적, 면제수, 건너뜀사유) 를 준다.

    dist 가 없는 것은 새는 것이 아니다. 지적이 아니라 건너뜀으로 알린다."""
    if not os.path.isdir(DIST):
        return [], 0, 'dist/ 가 없다. python tests/bundles.py build 를 먼저 돌린다.'

    findings, exempted = [], 0

    for role in ROLE_ORDER:
        out = os.path.join(DIST, role)
        if not os.path.isdir(out):
            findings.append((role, '번들이 없다', ''))
            continue
        rules = BUNDLES[role].get('rules') or {}
        if not rules:
            continue

        for p in _text_files(out):
            rel = os.path.relpath(p, out).replace('\\', '/')

            # 1 경로
            for bad in rules.get('no_path', []):
                if bad.lower() in rel.lower():
                    findings.append((role, '있으면 안 되는 파일 · %s' % bad, rel))

            try:
                text = io.open(p, encoding='utf-8', errors='replace').read()
            except Exception as e:
                findings.append((role, '읽지 못함 · %s' % e, rel))
                continue

            # 2 내용
            for rx, why in rules.get('no_text', []):
                for m in re.finditer(rx, text, re.I):
                    line_no = text.count('\n', 0, m.start()) + 1
                    line = text.split('\n')[line_no - 1]
                    if EXEMPT_MARK in line:
                        exempted += 1
                        continue
                    findings.append((role, '%s · %s' % (why, m.group(0)[:40]),
                                     '%s:%d' % (rel, line_no)))

            # 3 쌍 번호
            pat = rules.get('pair_ids_must_match')
            if pat and rel.lower().endswith('.csv'):
                bad_ids = _bad_pair_ids(text, pat)
                if bad_ids:
                    findings.append(
                        (role, '쌍 번호가 출처를 말한다 · %s' % ' '.join(bad_ids[:6]), rel))

    return findings, exempted, None


def _bad_pair_ids(text, pat):
    lines = [l for l in text.replace('\r\n', '\n').split('\n') if l.strip()]
    if not lines:
        return []
    head = [h.strip().strip('"').lstrip('﻿') for h in lines[0].split(',')]
    if 'pair_id' not in head:
        return []
    i = head.index('pair_id')
    rx = re.compile(pat)
    bad = []
    for l in lines[1:]:
        cells = l.split(',')
        if i >= len(cells):
            continue
        v = cells[i].strip().strip('"')
        if v and not rx.match(v):
            bad.append(v)
    return bad


# ─────────────────────── 출력 ───────────────────────

def main():
    cmd = sys.argv[1] if len(sys.argv) > 1 else 'check'

    if cmd == 'list':
        for role in ROLE_ORDER:
            s = BUNDLES[role]
            print('%-20s %s' % (role, s['desc']))
            print('%-20s 파일 %d · 규칙 %s' % (
                '', len(s['files']), '있음' if s.get('rules') else '없음'))
        return 0

    if cmd == 'build':
        rep = build()
        print('dist/ 를 만들었다 ·', DIST)
        print()
        for role, got, absent, notes in rep:
            mark = '!' if (absent or notes) else ' '
            print(' %s %-20s 넣음 %-3d %s' % (
                mark, role, got,
                ('· 못 넣음 %d' % absent) if absent else ''))
            for n in notes:
                print('%-24s· %s' % ('', n.split('\n')[0]))
        zips = zip_roles()
        if zips:
            print()
            print('  역할별 ZIP')
            for role, n, sz in zips:
                print('    dist/%-30s 파일 %-3d %s bytes' % (
                    '%s_%s.zip' % (role, RC_TAG), n, format(sz, ',')))
            print('    admin 은 본 묶음과 같아 따로 압축하지 않는다')
        print()
        cmd = 'check'

    findings, exempted, skipped = check()
    print('=' * 56)
    if skipped:
        print('  누출 검사 · 건너뜀')
        print('=' * 56)
        print('  ' + skipped)
        print()
        return 0
    if findings:
        print('  누출 검사 · 지적 %d건' % len(findings))
        print('=' * 56)
        for role, what, where in findings:
            print('  [%s] %s' % (role, what))
            if where:
                print('        %s' % where)
    else:
        print('  누출 검사 · 지적 0건')
        print('=' * 56)
        print('  역할별로 가면 안 되는 것이 가지 않았다.')
    if exempted:
        print()
        print('  면제 %d건 · %s 표시가 있는 줄은 넘어갔다.' % (exempted, EXEMPT_MARK))
        print('  도구가 금칙어 목록을 들고 있어서다. 면제 수가 늘면 이유를 확인한다.')
    print()
    return 1 if findings else 0


if __name__ == '__main__':
    sys.exit(main())
