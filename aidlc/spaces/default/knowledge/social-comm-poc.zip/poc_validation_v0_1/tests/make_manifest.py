# -*- coding: utf-8 -*-
"""배포 매니페스트를 실측으로만 만든다.

  python tests/make_manifest.py

세 파일이 나온다.
  RELEASE_MANIFEST.json   파일마다 경로 · 바이트 · sha256 · 분류
  RELEASE_MANIFEST.md     사람이 읽는 요약
  SHA256SUMS.txt          표준 형식. sha256sum -c 로 확인한다

**어떤 숫자도 문서에서 옮겨 적지 않는다.** 전부 지금 센 값이다.
인수인계 문서가 "47 + 10 + 4 = 61" 이라고 적고 총계는 72 였던 일(I-05)이
바로 두 숫자를 다른 방법으로 뽑고 대조하지 않아서 생겼다.
그래서 여기서는 내역의 합이 총계와 맞는지 직접 확인하고, 안 맞으면 실패한다.
"""

import io
import json
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from phase1_inventory import CACHE_PAT, sha256, categorize, purpose  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)

# dist 는 이 패키지에서 파생된 사본이다. 배포물에 넣지 않고 매니페스트에도 세지 않는다
SKIP_TOP = {'dist', '.git'}

# 집계에서 자기 자신을 빼는 이유는 총계 안정이다. checksum 과는 다른 문제다.
# 세면 돌릴 때마다 총계가 바뀌고 그 총계를 담은 파일이 다시 총계를 바꾼다
SELF_OUTPUT = {'RELEASE_MANIFEST.json', 'RELEASE_MANIFEST.md', 'SHA256SUMS.txt'}

# ZIP 최상위에 실리는 표지. 패키지 폴더 밖에 있지만 checksum 은 덮는다
COVER_NAME = 'RC1_HANDOFF_FINAL.html'


def walk():
    rows, cache_seen = [], []
    for dp, dn, fn in os.walk(ROOT):
        rel_dir = os.path.relpath(dp, ROOT).replace('\\', '/')
        top = rel_dir.split('/')[0]
        if top in SKIP_TOP:
            dn[:] = []
            continue
        dn[:] = [d for d in dn if d not in SKIP_TOP]
        for f in sorted(fn):
            p = os.path.join(dp, f)
            rel = os.path.relpath(p, ROOT).replace('\\', '/')
            if rel in SELF_OUTPUT:
                continue
            ext = os.path.splitext(f)[1].lower()
            is_cache = bool(CACHE_PAT.search(rel))
            if is_cache:
                # 캐시는 zip 에 들어가지 않는다. 목록에 남겨 두면 매니페스트와 archive 가 어긋난다.
                # 수는 따로 세고 files 배열에는 넣지 않는다
                cache_seen.append(rel)
                continue
            cat = categorize(rel, f, ext)
            rows.append({
                'path': rel,
                'bytes': os.path.getsize(p),
                'sha256': sha256(p),
                'ext': ext or '(없음)',
                'category': cat,
                'purpose': purpose(rel, f, cat),
            })
    rows.sort(key=lambda r: r['path'])
    return rows, sorted(cache_seen)


def summarize(rows, cache_seen):
    real = rows
    cache = cache_seen

    by_cat, by_dir, by_ext = {}, {}, {}
    for r in real:
        by_cat[r['category']] = by_cat.get(r['category'], 0) + 1
        top = r['path'].split('/')[0] if '/' in r['path'] else '(최상위)'
        by_dir[top] = by_dir.get(top, 0) + 1
        by_ext[r['ext']] = by_ext.get(r['ext'], 0) + 1

    total_bytes = sum(r['bytes'] for r in real)

    # 내역의 합이 총계와 맞는가. 이것이 I-05 가 놓친 확인이다
    checks = {
        'category_sum_equals_total': sum(by_cat.values()) == len(real),
        'dir_sum_equals_total': sum(by_dir.values()) == len(real),
        'ext_sum_equals_total': sum(by_ext.values()) == len(real),
        'files_array_has_no_cache': all('__pycache__' not in r['path'] for r in rows),
    }
    return {
        'files_excluding_cache': len(real),
        'files_including_cache': len(rows),
        'cache_files': len(cache),
        'total_bytes_excluding_cache': total_bytes,
        'by_category': dict(sorted(by_cat.items(), key=lambda x: (-x[1], x[0]))),
        'by_directory': dict(sorted(by_dir.items())),
        'by_extension': dict(sorted(by_ext.items(), key=lambda x: (-x[1], x[0]))),
        'consistency': checks,
        'all_consistent': all(checks.values()),
    }


def write_md(rows, s, stamp):
    L = []
    L.append('# RELEASE MANIFEST')
    L.append('')
    L.append('생성 %s · `tests/make_manifest.py`' % stamp)
    L.append('')
    L.append('> **모든 숫자는 이 파일을 만들 때 직접 센 값이다.**')
    L.append('> 어떤 수도 다른 문서에서 옮겨 적지 않았다.')
    L.append('> 내역의 합이 총계와 맞는지 기계가 확인하고, 안 맞으면 생성이 실패한다.')
    L.append('')
    L.append('## 총계')
    L.append('')
    L.append('| | 값 |')
    L.append('|---|---|')
    L.append('| **배포 파일** | **%d** |' % s['files_excluding_cache'])
    L.append('| 바이트 | %s |' % format(s['total_bytes_excluding_cache'], ','))
    L.append('| 빌드 환경의 캐시 · 배포하지 않음 | %d |' % s['cache_files'])
    L.append('')
    L.append('### zip 안의 파일 수와 맞춰 본다')
    L.append('')
    L.append('```')
    n = s['files_excluding_cache']
    L.append('배포 파일                        %3d' % n)
    L.append('이 매니페스트 자신 세 개        + %3d' % len(SELF_OUTPUT))
    L.append('                                ----')
    L.append('패키지 폴더 안                   %3d' % (n + len(SELF_OUTPUT)))
    L.append('%s · 표지 + %3d' % (COVER_NAME, 1))
    L.append('                                ----')
    L.append('zip 안의 파일                    %3d' % (n + len(SELF_OUTPUT) + 1))
    L.append('```')
    L.append('')
    L.append('표지는 패키지 폴더 밖에 두고 zip 최상위에만 싣는다. '
             '안에 넣으면 표지를 고칠 때마다 파일 수가 바뀌고 그 수가 표지에 적혀 있다.')
    L.append('')
    L.append('빌드 환경에 캐시 %d개가 있었고 **files 배열에도 zip 에도 들어가지 않았다.** '
             '목록은 `cache_excluded` 에 남긴다. '
             '캐시를 목록에 남기면 매니페스트와 archive 가 어긋난다(RC1 ERR-03).' % s['cache_files'])
    L.append('')
    L.append('세지 않은 것이 둘이다.')
    L.append('')
    L.append('- `dist/` · 이 패키지에서 파생된 사본이다')
    L.append('- `RELEASE_MANIFEST.json` · `.md` · `SHA256SUMS.txt` · 이 파일들 자신이다.')
    L.append('  세면 돌릴 때마다 총계가 바뀌고, 그 총계를 담은 파일이 다시 총계를 바꾼다')
    L.append('')

    L.append('## 폴더별')
    L.append('')
    L.append('| 폴더 | 파일 |')
    L.append('|---|---|')
    for k, v in s['by_directory'].items():
        L.append('| `%s` | %d |' % (k, v))
    L.append('| **합** | **%d** |' % sum(s['by_directory'].values()))
    L.append('')

    L.append('## 분류별')
    L.append('')
    L.append('| 분류 | 파일 |')
    L.append('|---|---|')
    for k, v in s['by_category'].items():
        L.append('| %s | %d |' % (k, v))
    L.append('| **합** | **%d** |' % sum(s['by_category'].values()))
    L.append('')

    L.append('## 확장자별')
    L.append('')
    L.append('| 확장자 | 파일 |')
    L.append('|---|---|')
    for k, v in s['by_extension'].items():
        L.append('| `%s` | %d |' % (k, v))
    L.append('| **합** | **%d** |' % sum(s['by_extension'].values()))
    L.append('')

    L.append('## 합이 맞는가')
    L.append('')
    L.append('| 확인 | 결과 |')
    L.append('|---|---|')
    label = {
        'category_sum_equals_total': '분류별 합 = 총계',
        'dir_sum_equals_total': '폴더별 합 = 총계',
        'ext_sum_equals_total': '확장자별 합 = 총계',
        'files_array_has_no_cache': 'files 배열에 캐시 없음',
    }
    for k, v in s['consistency'].items():
        L.append('| %s | %s |' % (label.get(k, k), '맞음' if v else '**틀림**'))
    L.append('')

    L.append('## 전체 파일')
    L.append('')
    L.append('| 경로 | 바이트 | 분류 | sha256 앞 16 |')
    L.append('|---|---|---|---|')
    for r in rows:
        L.append('| `%s` | %s | %s | `%s` |' % (
            r['path'], format(r['bytes'], ','), r['category'], r['sha256'][:16]))
    L.append('')
    L.append('전체 해시는 `SHA256SUMS.txt` 와 `RELEASE_MANIFEST.json` 에 있다.')
    L.append('')
    L.append('```')
    L.append('sha256sum -c SHA256SUMS.txt')
    L.append('```')
    return '\n'.join(L) + '\n'


def main():
    stamp = time.strftime('%Y-%m-%d %H:%M:%S')
    rows, cache_seen = walk()
    s = summarize(rows, cache_seen)

    if not s['all_consistent']:
        print('내역의 합이 총계와 맞지 않는다. 매니페스트를 쓰지 않는다.')
        for k, v in s['consistency'].items():
            if not v:
                print('  틀린 확인 ·', k)
        return 1

    # ── 집계와 checksum 적용 범위는 서로 다른 것이다.
    #
    #    집계(manifest-managed)  91  · 자기 산출물을 빼야 돌릴 때마다 총계가 안 바뀐다
    #    checksum 적용            94  · ZIP 에 실리는 일반 산출물은 전부 덮어야 한다
    #
    #    셋 중 둘은 순환이 아니다. RELEASE_MANIFEST.json 과 .md 는
    #    SHA256SUMS.txt 보다 먼저 쓰이고 그 내용을 담지 않는다. 그래서 덮을 수 있다.
    #    자기 해시를 자기 안에 못 담는 것은 SHA256SUMS.txt 하나뿐이다.

    man_json = os.path.join(ROOT, 'RELEASE_MANIFEST.json')
    man_md = os.path.join(ROOT, 'RELEASE_MANIFEST.md')
    sums_path = os.path.join(ROOT, 'SHA256SUMS.txt')

    io.open(man_json, 'w', encoding='utf-8').write(
        json.dumps({'generated_at': stamp, 'summary': s,
                    'cache_excluded': cache_seen, 'files': rows},
                   ensure_ascii=False, indent=2))
    io.open(man_md, 'w', encoding='utf-8').write(write_md(rows, s, stamp))

    covered = [(r['sha256'], r['path']) for r in rows]
    extra = []
    for p, rel in ((man_json, 'RELEASE_MANIFEST.json'), (man_md, 'RELEASE_MANIFEST.md')):
        extra.append((sha256(p), rel))
    cover = os.path.join(os.path.dirname(ROOT), COVER_NAME)
    if os.path.exists(cover):
        # ZIP 최상위에 실리는 표지. 패키지 폴더 기준으로 한 단계 위다
        extra.append((sha256(cover), '../' + COVER_NAME))
    covered += extra

    io.open(sums_path, 'w', encoding='utf-8', newline='\n').write(
        '\n'.join('%s  %s' % (h, p) for h, p in covered) + '\n')

    # 덮지 못한 것을 매니페스트에 명시한다. 조용히 빠지면 안 된다
    coverage = {
        'sha256_covered': len(covered),
        'manifest_managed': s['files_excluding_cache'],
        'covered_beyond_managed': [p for _, p in extra],
        'not_covered': [{'path': 'SHA256SUMS.txt',
                         'reason': '자기 해시를 자기 안에 담을 수 없다. 보편적 제약이다'}],
    }
    d = json.loads(io.open(man_json, encoding='utf-8').read())
    d['sha256_coverage'] = coverage
    io.open(man_json, 'w', encoding='utf-8').write(
        json.dumps(d, ensure_ascii=False, indent=2))
    io.open(man_md, 'a', encoding='utf-8').write(coverage_md(coverage))
    # md 를 덧쓴 뒤 해시가 바뀌었으므로 그 줄만 다시 계산한다
    covered = [(h, p) for h, p in covered if p != 'RELEASE_MANIFEST.md']
    covered.append((sha256(man_md), 'RELEASE_MANIFEST.md'))
    # json 도 마찬가지
    covered = [(h, p) for h, p in covered if p != 'RELEASE_MANIFEST.json']
    covered.append((sha256(man_json), 'RELEASE_MANIFEST.json'))
    io.open(sums_path, 'w', encoding='utf-8', newline='\n').write(
        '\n'.join('%s  %s' % (h, p) for h, p in sorted(covered, key=lambda x: x[1])) + '\n')

    print('실측 매니페스트를 만들었다.')
    print('  집계 대상 파일     %d   (자기 산출물 제외 · 총계를 안정시키려고)' % s['files_excluding_cache'])
    print('  checksum 적용      %d   (+ 매니페스트 2 + 표지 1)' % len(covered))
    print('  덮지 못한 것       1   SHA256SUMS.txt · 자기 해시를 자기 안에 못 담는다')
    print('  바이트             %s' % format(s['total_bytes_excluding_cache'], ','))
    print('  합 확인            전부 맞음')
    print()
    print('  RELEASE_MANIFEST.json · .md · SHA256SUMS.txt')
    return 0


def coverage_md(c):
    L = ['', '## checksum 적용 범위', '',
         '집계와 checksum 은 서로 다른 것이다. 집계는 총계를 안정시키려고 자기 산출물을 빼고,',
         'checksum 은 ZIP 에 실리는 일반 산출물을 전부 덮는다.', '',
         '| | 수 |', '|---|---|',
         '| 집계 대상 · manifest-managed | %d |' % c['manifest_managed'],
         '| checksum 적용 · SHA256-covered | **%d** |' % c['sha256_covered'], '',
         '집계에 없지만 checksum 은 덮는 것', '']
    for p in c['covered_beyond_managed']:
        L.append('- `%s`' % p)
    L += ['', '덮지 못한 것', '',
          '| 파일 | 이유 |', '|---|---|']
    for x in c['not_covered']:
        L.append('| `%s` | %s |' % (x['path'], x['reason']))
    L += ['', 'ZIP 안의 일반 산출물 중 checksum 밖에 있는 것은 `SHA256SUMS.txt` 하나뿐이다.', '']
    return '\n'.join(L)


if __name__ == '__main__':
    sys.exit(main())
