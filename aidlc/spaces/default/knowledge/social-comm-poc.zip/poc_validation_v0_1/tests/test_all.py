"""실행 패키지 자동 시험.

    python tests/test_all.py

의존성 없음. unittest 만 쓴다.
"""
import json
import io
import os
import re
import sys
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, '02_POC_A'))

from rule_engine import (  # noqa: E402
    judge, skill_identity, transfer_distance, user_facing_label,
    check_invariant, RuleError, CORE_UNDERSTAND, CORE_PERFORM,
)

S, D, U = 'SAME', 'DIFFERENT', 'UNKNOWN'
C = 'CHANGED'


def ann(**kw):
    base = {f: S for f in CORE_PERFORM}
    base.update({'topic_changed': C, 'place_changed': C, 'participants_changed': C,
                 'relationship_changed': S, 'situation_type_changed': S,
                 'misread_cost_changed': S, 'recoverability_changed': S})
    base.update(kw)
    return base


class TestSkillIdentity(unittest.TestCase):
    def test_all_same_is_same(self):
        r = judge(ann())
        self.assertEqual(r['skill_identity_understand'], S)
        self.assertEqual(r['skill_identity_perform'], S)

    def test_one_different_is_different(self):
        for f in CORE_UNDERSTAND:
            r = judge(ann(**{f: D}))
            self.assertEqual(r['skill_identity_understand'], D, f)
            self.assertEqual(r['skill_identity_perform'], D, f)

    def test_unknown_beats_different(self):
        """모르면 다르다고 말하지 않는다. UNDETERMINED 가 우선이다."""
        r = judge(ann(required_inference=U, perspective_structure=D))
        self.assertEqual(r['skill_identity_understand'], 'UNDETERMINED')

    def test_perform_only_field_splits_stages(self):
        """Core 5 만 다르면 이해는 SAME, 수행은 DIFFERENT."""
        r = judge(ann(direct_check_allowed=D))
        self.assertEqual(r['skill_identity_understand'], S)
        self.assertEqual(r['skill_identity_perform'], D)
        self.assertEqual(r['label_understand'], 'SAME_SKILL')
        self.assertEqual(r['label_perform'], 'DIFFERENT_SKILL')

    def test_perform_only_unknown_splits_stages(self):
        r = judge(ann(direct_check_allowed=U))
        self.assertEqual(r['skill_identity_understand'], S)
        self.assertEqual(r['skill_identity_perform'], 'UNDETERMINED')

    def test_invariant_perform_same_implies_understand_same(self):
        """§11.1 불변식. 무작위 조합으로 확인한다."""
        import itertools
        vals = [S, D, U]
        n = 0
        for combo in itertools.product(vals, repeat=5):
            a = ann(**dict(zip(CORE_PERFORM, combo)))
            r = judge(a)
            self.assertTrue(check_invariant(r), combo)
            n += 1
        self.assertEqual(n, 243)


class TestTransferDistance(unittest.TestCase):
    def test_same_context(self):
        r = judge(ann())
        self.assertEqual(r['transfer_distance'], 'SAME_CONTEXT')
        self.assertEqual(r['label_understand'], 'SAME_SKILL')

    def test_near_on_relationship_change(self):
        r = judge(ann(relationship_changed=C))
        self.assertEqual(r['transfer_distance'], 'NEAR')
        self.assertEqual(r['label_understand'], 'NEAR_TRANSFER')

    def test_near_on_situation_change(self):
        r = judge(ann(situation_type_changed=C))
        self.assertEqual(r['transfer_distance'], 'NEAR')

    def test_far_needs_both(self):
        r = judge(ann(relationship_changed=C, misread_cost_changed=C))
        self.assertEqual(r['transfer_distance'], 'FAR')
        self.assertEqual(r['label_understand'], 'FAR_TRANSFER')

    def test_constraint_change_alone_is_not_far(self):
        """관계가 그대로면 대가만 바뀌어도 FAR 가 아니다."""
        r = judge(ann(misread_cost_changed=C))
        self.assertEqual(r['transfer_distance'], 'SAME_CONTEXT')

    def test_relationship_unknown_makes_distance_undetermined(self):
        r = judge(ann(relationship_changed=U))
        self.assertEqual(r['skill_identity_understand'], S)
        self.assertEqual(r['transfer_distance'], 'UNDETERMINED')
        self.assertEqual(r['label_understand'], 'SAME_SKILL_DISTANCE_UNDETERMINED')

    def test_constraint_unknown_stops_at_near(self):
        """I-02 · context_constraints 만 모르면 NEAR 에서 멈춘다."""
        r = judge(ann(relationship_changed=C, misread_cost_changed=U, recoverability_changed=U))
        self.assertEqual(r['transfer_distance'], 'NEAR')

    def test_not_computed_when_identity_not_same(self):
        r = judge(ann(required_inference=D, relationship_changed=C))
        self.assertEqual(r['transfer_distance'], 'NOT_COMPUTED')
        self.assertEqual(r['label_understand'], 'DIFFERENT_SKILL')


class TestUserGoalDoesNotBlock(unittest.TestCase):
    def test_user_goal_is_not_an_input(self):
        """user_goal 은 어느 축의 입력도 아니다(§4.3)."""
        a = ann()
        a['user_goal'] = 'UNKNOWN'
        r = judge(a)
        self.assertEqual(r['skill_identity_understand'], S)
        self.assertEqual(r['skill_identity_perform'], S)
        self.assertEqual(r['transfer_distance'], 'SAME_CONTEXT')

    def test_supporting_fields_do_not_block(self):
        a = ann()
        for f in ('pragmatic_function', 'social_cue_function_type',
                  'partner_goal_explicit', 'interpretation_cardinality'):
            a[f] = 'UNKNOWN'
        r = judge(a)
        self.assertEqual(r['skill_identity_understand'], S)


class TestInputValidation(unittest.TestCase):
    def test_bad_value_raises(self):
        with self.assertRaises(RuleError):
            judge(ann(required_inference='MAYBE'))

    def test_missing_core_raises(self):
        a = ann()
        del a['perspective_structure']
        with self.assertRaises(RuleError):
            judge(a)

    def test_bad_change_flag_raises(self):
        with self.assertRaises(RuleError):
            judge(ann(relationship_changed='YES'))


class TestSpecConsistency(unittest.TestCase):
    """규격 문서와 실행 패키지가 같은 것을 가리키는지."""

    def setUp(self):
        p = os.path.join(ROOT, '01_SPEC', 'decision_rules_machine_readable.json')
        self.rules = json.load(io.open(p, encoding='utf-8'))

    def test_core_count_is_five(self):
        c = self.rules['core_equivalence_fields']
        self.assertEqual(c['count_understand'], 4)
        self.assertEqual(c['count_perform'], 5)
        self.assertEqual(len(c['perform']), 5)
        self.assertEqual(tuple(c['perform']), CORE_PERFORM)

    def test_engine_matches_json_rules(self):
        self.assertEqual(tuple(self.rules['core_equivalence_fields']['understand']),
                         CORE_UNDERSTAND)

    def test_guideline_asks_exactly_core_five(self):
        p = os.path.join(ROOT, '02_POC_A', 'annotation_guideline_onepage.md')
        txt = io.open(p, encoding='utf-8').read()
        self.assertIn('다섯 가지를 본다', txt)
        # 다섯 항목이 번호로 있는가
        for n in '12345':
            self.assertRegex(txt, r'###\s*' + n + r'\.')

    def test_form_has_all_core_fields(self):
        p = os.path.join(ROOT, '02_POC_A', 'annotation_form.json')
        if not os.path.exists(p):
            self.skipTest('annotation_form.json 이 아직 없다')
        spec = json.load(io.open(p, encoding='utf-8'))
        names = {c['name'] for c in spec['columns']}
        for f in CORE_PERFORM:
            self.assertIn(f, names, f)

    def _threshold_items(self):
        return {k: v for k, v in self.rules['thresholds'].items() if isinstance(v, dict)}

    def test_thresholds_mark_evidence_basis(self):
        items = self._threshold_items()
        self.assertGreaterEqual(len(items), 4)
        for k, v in items.items():
            self.assertIn('evidence_basis', v, k)
            self.assertIn(v['evidence_basis'], ('operational', 'adjacent_reference'), k)

    def test_only_one_threshold_claims_external_reference(self):
        ext = [k for k, v in self._threshold_items().items()
               if v['evidence_basis'] == 'adjacent_reference']
        self.assertEqual(ext, ['skill_identity_kappa'])


class TestPIIRedaction(unittest.TestCase):
    """intake_prototype.html 의 PII 규칙을 파이썬으로 다시 확인한다."""

    def setUp(self):
        p = os.path.join(ROOT, '03_POC_C', 'intake_prototype.html')
        self.html = io.open(p, encoding='utf-8').read()

    def test_all_ten_rules_present(self):
        for i in range(1, 11):
            self.assertIn(f"P{i:02d}", self.html)

    def test_stoplist_exists(self):
        self.assertIn('NOT_A_NAME', self.html)
        for w in ('동아리', '학과', '우리'):
            self.assertIn(w, self.html)

    def test_raw_input_not_retained_by_default(self):
        self.assertRegex(self.html, r"raw_input\s*:\s*null")

    def test_save_gated_by_checkbox(self):
        self.assertIn('save.disabled = true', self.html)

    def test_no_mind_reading_phrases(self):
        for bad in ('상대는 ~라는 뜻', '사실 그 사람은', '확실히 거절'):
            self.assertNotIn(bad, self.html)


class TestAggregation(unittest.TestCase):
    """사건 삭제 시 집계가 줄어드는가."""

    def setUp(self):
        sys.path.insert(0, os.path.join(ROOT, '03_POC_C'))
        import personal_pattern as pp
        self.pp = pp

    def test_delete_reduces_aggregate(self):
        events = [
            {'event_id': 'E1', 'signature': 'sig-a', 'cue_considered': True,
             'interpretations': 2, 'clarification': True, 'strategy': 'ASK',
             'timestamp': '2026-09-01', 'confidence': 'HIGH', 'outcome_match': True},
            {'event_id': 'E2', 'signature': 'sig-a', 'cue_considered': False,
             'interpretations': 1, 'clarification': False, 'strategy': 'GUESS',
             'timestamp': '2026-09-02', 'confidence': 'HIGH', 'outcome_match': False},
            {'event_id': 'E3', 'signature': 'sig-b', 'cue_considered': True,
             'interpretations': 3, 'clarification': True, 'strategy': 'ASK',
             'timestamp': '2026-09-03', 'confidence': 'LOW', 'outcome_match': True},
        ]
        before = self.pp.aggregate(events)
        after = self.pp.aggregate([e for e in events if e['event_id'] != 'E1'])
        self.assertEqual(before['exposure_count']['sig-a'], 2)
        self.assertEqual(after['exposure_count']['sig-a'], 1)
        self.assertLess(after['n_events'], before['n_events'])

    def test_no_trait_nodes(self):
        """사람을 규정하는 노드를 만들지 않는다."""
        events = [{'event_id': 'E1', 'signature': 's', 'cue_considered': False,
                   'interpretations': 1, 'clarification': False, 'strategy': 'GUESS',
                   'timestamp': '2026-09-01'}]
        agg = self.pp.aggregate(events)
        blob = json.dumps(agg, ensure_ascii=False)
        for bad in ('cannot_', 'is_bad_at', 'trait', 'deficit', '못한다', '결함'):
            self.assertNotIn(bad, blob)

    def test_min_sample_guard(self):
        events = [{'event_id': 'E1', 'signature': 's', 'cue_considered': True,
                   'interpretations': 1, 'clarification': True, 'strategy': 'ASK',
                   'timestamp': '2026-09-01'}]
        agg = self.pp.aggregate(events)
        self.assertFalse(agg['recent_trend']['reportable'])

    def test_traceability(self):
        events = [{'event_id': 'E1', 'signature': 's', 'cue_considered': True,
                   'interpretations': 1, 'clarification': True, 'strategy': 'ASK',
                   'timestamp': '2026-09-01'}]
        agg = self.pp.aggregate(events)
        self.assertIn('E1', agg['event_ids'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
