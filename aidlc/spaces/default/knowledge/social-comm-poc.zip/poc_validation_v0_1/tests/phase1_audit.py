"""PHASE 1 · 구현 존재성과 재현성 감사.

    python tests/phase1_audit.py

항목 3 · 핵심 파일이 존재하고 구현이 placeholder 가 아닌가
항목 5 · DEMO 산출물이 현재 코드로 다시 만들어지는가
"""
from __future__ import annotations

import ast
import io
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PY = sys.executable

CORE_FILES = [
    '02_POC_A/rule_engine.py',
    '02_POC_A/analyze_agreement.py',
    '02_POC_A/randomize_pairs.py',
    '02_POC_A/make_forms.py',
    '02_POC_A/check_blind_format.py',
    '03_POC_C/intake_prototype.html',
    '03_POC_C/personal_social_event.schema.json',
    '03_POC_C/clarification_rules.json',
    '03_POC_C/personal_pattern.py',
    '03_POC_C/analyze_pilot.py',
    '04_POC_B_SCAFFOLD/generation_harness.py',
    '04_POC_B_SCAFFOLD/preservation_metrics.py',
    '04_POC_B_SCAFFOLD/seed_10.json',
    '04_POC_B_SCAFFOLD/generator_prompt.md',
    '04_POC_B_SCAFFOLD/validator_prompt.md',
]

# 의도한 미구현. 팀이 채우기로 문서에 적힌 것.
INTENTIONAL_STUBS = {
    ('04_POC_B_SCAFFOLD/generation_harness.py', 'HTTPProvider.generate'),
    ('04_POC_B_SCAFFOLD/generation_harness.py', 'HTTPProvider.validate'),
    ('04_POC_B_SCAFFOLD/generation_harness.py', 'LLMProvider.generate'),
    ('04_POC_B_SCAFFOLD/generation_harness.py', 'LLMProvider.validate'),
}


def read(p):
    return io.open(p, encoding='utf-8', errors='replace').read()


def audit_python(relp, src):
    """빈 함수 · pass 만 있는 함수 · NotImplementedError 를 찾는다."""
    out = {'parse_ok': True, 'defs': 0, 'stub_defs': [], 'todo_count': 0,
           'has_main': '__main__' in src, 'loc': len([l for l in src.splitlines() if l.strip()])}
    out['todo_count'] = len(re.findall(r'\bTODO\b|\bFIXME\b', src))
    try:
        tree = ast.parse(src)
    except SyntaxError as e:
        out['parse_ok'] = False
        out['error'] = str(e)
        return out

    class V(ast.NodeVisitor):
        def __init__(self):
            self.stack = []

        def _qual(self, name):
            return '.'.join(self.stack + [name])

        def visit_ClassDef(self, node):
            self.stack.append(node.name)
            self.generic_visit(node)
            self.stack.pop()

        def _fn(self, node):
            out['defs'] += 1
            body = [n for n in node.body if not (isinstance(n, ast.Expr)
                    and isinstance(n.value, ast.Constant) and isinstance(n.value.value, str))]
            kind = None
            if not body:
                kind = 'empty'
            elif len(body) == 1 and isinstance(body[0], ast.Pass):
                kind = 'pass_only'
            elif len(body) == 1 and isinstance(body[0], ast.Raise):
                exc = body[0].exc
                nm = ''
                if isinstance(exc, ast.Call) and isinstance(exc.func, ast.Name):
                    nm = exc.func.id
                elif isinstance(exc, ast.Name):
                    nm = exc.id
                if nm == 'NotImplementedError':
                    kind = 'not_implemented'
            if kind:
                out['stub_defs'].append({'name': self._qual(node.name), 'kind': kind,
                                         'line': node.lineno})
            self.stack.append(node.name)
            self.generic_visit(node)
            self.stack.pop()

        visit_FunctionDef = _fn
        visit_AsyncFunctionDef = _fn

    V().visit(tree)
    return out


def audit_json(relp, src):
    try:
        d = json.loads(src)
    except json.JSONDecodeError as e:
        return {'parse_ok': False, 'error': str(e)}
    def count(o):
        if isinstance(o, dict):
            return 1 + sum(count(v) for v in o.values())
        if isinstance(o, list):
            return sum(count(v) for v in o)
        return 0
    return {'parse_ok': True, 'top_keys': len(d) if isinstance(d, dict) else len(d),
            'nodes': count(d)}


def audit_html(relp, src):
    return {'parse_ok': True,
            'script_chars': sum(len(m) for m in re.findall(r'<script[^>]*>(.*?)</script>', src, re.S)),
            'functions': len(re.findall(r'function\s+\w+\s*\(', src)),
            'has_doctype': src.lstrip().lower().startswith('<!doctype')}


def audit_md(relp, src):
    return {'parse_ok': True, 'headings': len(re.findall(r'^#{1,6}\s', src, re.M)),
            'tables': len(re.findall(r'^\|', src, re.M)),
            'todo_count': len(re.findall(r'\bTODO\b', src))}


def verdict_for(relp, size, info):
    if size == 0:
        return 'EMPTY'
    if not info.get('parse_ok', True):
        return 'BROKEN'
    if relp.endswith('.py'):
        real = [s for s in info['stub_defs']
                if (relp, s['name']) not in INTENTIONAL_STUBS]
        if info['defs'] and len(real) == info['defs']:
            return 'PLACEHOLDER'
        if real:
            return 'PARTIAL_STUB'
        if info['stub_defs']:
            return 'OK_WITH_INTENTIONAL_STUB'
        if info['loc'] < 15:
            return 'THIN'
        return 'IMPLEMENTED'
    if relp.endswith('.json'):
        return 'IMPLEMENTED' if info.get('nodes', 0) > 5 else 'THIN'
    if relp.endswith('.html'):
        return 'IMPLEMENTED' if info.get('script_chars', 0) > 2000 or size > 6000 else 'THIN'
    if relp.endswith('.md'):
        return 'IMPLEMENTED' if info.get('headings', 0) >= 2 and size > 500 else 'THIN'
    return 'UNKNOWN'


def run(cmd, cwd):
    import time
    t0 = time.time()
    p = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True,
                       encoding='utf-8', errors='replace',
                       env={**os.environ, 'PYTHONIOENCODING': 'utf-8'})
    return {'cmd': ' '.join(cmd), 'exit_code': p.returncode,
            'duration_s': round(time.time() - t0, 2),
            'stdout_tail': p.stdout[-1400:], 'stderr_tail': p.stderr[-600:]}


def reproduce_demos():
    """현재 코드로 DEMO 를 다시 만들어 핵심 숫자가 같은지 본다."""
    res = {}

    # A · 샘플 판정 재생성 후 분석
    a = os.path.join(ROOT, '02_POC_A')
    prev = None
    p_prev = os.path.join(a, 'results_demo', 'agreement_report.json')
    if os.path.exists(p_prev):
        prev = json.load(io.open(p_prev, encoding='utf-8'))
    tmp = tempfile.mkdtemp(prefix='repro_a_')
    r1 = run([PY, 'make_sample_ratings.py'], a)
    r2 = run([PY, 'analyze_agreement.py', 'sample_rater_A.csv', 'sample_rater_B.csv',
              '--out', tmp, '--demo'], a)
    now = None
    p_now = os.path.join(tmp, 'agreement_report.json')
    if os.path.exists(p_now):
        now = json.load(io.open(p_now, encoding='utf-8'))
    ok = bool(prev and now)
    cmp_ = {}
    if ok:
        for k in ('understand', 'perform'):
            pv = prev['axis1'][k]['kappa']
            nv = now['axis1'][k]['kappa']
            cmp_[f'axis1_{k}_kappa'] = {'before': pv, 'after': nv,
                                        'match': (pv is None and nv is None) or
                                                 (pv is not None and nv is not None and abs(pv - nv) < 1e-9)}
        cmp_['verdict'] = {'before': prev['decision']['verdict'],
                           'after': now['decision']['verdict'],
                           'match': prev['decision']['verdict'] == now['decision']['verdict']}
    res['poc_a_demo'] = {'runs': [r1, r2], 'comparison': cmp_,
                         'reproducible': ok and all(v['match'] for v in cmp_.values()),
                         'tmp': tmp}
    shutil.rmtree(tmp, ignore_errors=True)

    # C · 합성 사건 재생성 후 분석
    c = os.path.join(ROOT, '03_POC_C')
    prev = None
    p_prev = os.path.join(c, 'results_demo', 'pilot_report.json')
    if os.path.exists(p_prev):
        prev = json.load(io.open(p_prev, encoding='utf-8'))
    tmp = tempfile.mkdtemp(prefix='repro_c_')
    r1 = run([PY, 'make_synthetic_events.py'], c)
    r2 = run([PY, 'analyze_pilot.py', 'synthetic_events.csv', '--followup',
              'synthetic_followups.csv', '--out', tmp, '--demo'], c)
    now = None
    p_now = os.path.join(tmp, 'pilot_report.json')
    if os.path.exists(p_now):
        now = json.load(io.open(p_now, encoding='utf-8'))
    cmp_ = {}
    ok = bool(prev and now)
    if ok:
        for k in ('n_participants', 'n_events'):
            cmp_[k] = {'before': prev[k], 'after': now[k], 'match': prev[k] == now[k]}
        pv = prev['seconds_to_complete']['median']
        nv = now['seconds_to_complete']['median']
        cmp_['median_seconds'] = {'before': pv, 'after': nv, 'match': pv == nv}
        cmp_['verdict'] = {'before': prev['decision']['verdict'],
                           'after': now['decision']['verdict'],
                           'match': prev['decision']['verdict'] == now['decision']['verdict']}
    res['poc_c_demo'] = {'runs': [r1, r2], 'comparison': cmp_,
                         'reproducible': ok and all(v['match'] for v in cmp_.values()),
                         'tmp': tmp}
    shutil.rmtree(tmp, ignore_errors=True)

    # B · echo dry-run
    b = os.path.join(ROOT, '04_POC_B_SCAFFOLD')
    prev = None
    p_prev = os.path.join(b, 'b_output', 'generation_output.json')
    if os.path.exists(p_prev):
        prev = json.load(io.open(p_prev, encoding='utf-8'))
    tmp = tempfile.mkdtemp(prefix='repro_b_')
    r1 = run([PY, 'generation_harness.py', '--dry-run', '--out', tmp], b)
    now = None
    p_now = os.path.join(tmp, 'generation_output.json')
    if os.path.exists(p_now):
        now = json.load(io.open(p_now, encoding='utf-8'))
    cmp_ = {}
    ok = bool(prev and now)
    if ok:
        cmp_['n_requested'] = {'before': prev['n_requested'], 'after': now['n_requested'],
                               'match': prev['n_requested'] == now['n_requested']}
        pa = sum(1 for r in prev['results'] if r['accepted'])
        na = sum(1 for r in now['results'] if r['accepted'])
        cmp_['accepted'] = {'before': pa, 'after': na, 'match': pa == na}
        pf = sum(r['attempts'] for r in prev['results'])
        nf = sum(r['attempts'] for r in now['results'])
        cmp_['total_attempts'] = {'before': pf, 'after': nf, 'match': pf == nf}
    res['poc_b_dryrun'] = {'runs': [r1], 'comparison': cmp_,
                           'reproducible': ok and all(v['match'] for v in cmp_.values()),
                           'tmp': tmp}
    shutil.rmtree(tmp, ignore_errors=True)
    return res


def main():
    report = {'root': ROOT.replace('\\', '/')}

    # ── 항목 3
    impl = []
    for relp in CORE_FILES:
        full = os.path.join(ROOT, relp.replace('/', os.sep))
        if not os.path.exists(full):
            impl.append({'file': relp, 'exists': False, 'verdict': 'MISSING'})
            continue
        size = os.path.getsize(full)
        src = read(full)
        if relp.endswith('.py'):
            info = audit_python(relp, src)
        elif relp.endswith('.json'):
            info = audit_json(relp, src)
        elif relp.endswith('.html'):
            info = audit_html(relp, src)
        else:
            info = audit_md(relp, src)
        impl.append({'file': relp, 'exists': True, 'bytes': size,
                     'verdict': verdict_for(relp, size, info), 'detail': info})
    report['implementation_audit'] = impl

    # ── 항목 4
    print('=== 테스트 재실행 ===')
    runs = [run([PY, '-W', 'ignore', 'tests/test_all.py'], ROOT),
            run([PY, 'tests/audit.py'], ROOT)]
    for r in runs:
        print(f"  {r['cmd']:<34} exit={r['exit_code']}  {r['duration_s']}s")
    m = re.search(r'Ran (\d+) tests', runs[0]['stdout_tail'] + runs[0]['stderr_tail'])
    report['test_runs'] = {
        'unittest': {**runs[0],
                     'ran': int(m.group(1)) if m else None,
                     'ok': 'OK' in (runs[0]['stderr_tail'] + runs[0]['stdout_tail'])},
        'audit': {**runs[1],
                  'findings': (lambda mm: int(mm.group(1)) if mm else None)(
                      re.search(r'지적 (\d+)건', runs[1]['stdout_tail']))},
    }

    # ── 항목 5
    print()
    print('=== DEMO 재현 ===')
    report['reproducibility'] = reproduce_demos()
    for k, v in report['reproducibility'].items():
        print(f"  {k:<16} {'재현됨' if v['reproducible'] else 'NOT_REPRODUCIBLE'}")

    with io.open(os.path.join(ROOT, 'tests', 'PHASE1_AUDIT_RAW.json'), 'w', encoding='utf-8') as f:
        json.dump(report, f, ensure_ascii=False, indent=2)

    print()
    print('=== 구현 판정 ===')
    for r in impl:
        print(f"  {r['verdict']:<26} {r['file']}")
    print()
    print('저장 · tests/PHASE1_AUDIT_RAW.json')
    return 0


if __name__ == '__main__':
    sys.exit(main())
