# -*- coding: utf-8 -*-
"""RC 묶음을 만든다.

  python tests/make_release.py            만들고 검사한다
  python tests/make_release.py --skip-tests   시험을 건너뛴다. 권하지 않는다

순서가 중요하다. 시험이 깨진 채로 묶으면 깨진 것을 배포한다.

  1 시험 · 감사
  2 역할별 꾸러미 다시 만들기
  3 누출 검사
  4 문서 쓰기 · RELEASE_NOTES · KNOWN_ISSUES · VERIFY_RELEASE
  5 실측 매니페스트
  6 zip

zip 은 패키지 **밖**에 쓴다. 안에 두면 다음 zip 이 이전 zip 을 품는다.
"""

import argparse
import io
import os
import subprocess
import sys
import time
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
OUT = os.path.dirname(ROOT)            # social-comm-poc/
PKG = os.path.basename(ROOT)           # poc_validation_v0_1
PY = sys.executable or 'python'
RC = 'RC1'
ZIP_NAME = '%s_%s.zip' % (PKG, RC)

SKIP_DIRS = {'__pycache__', '.git', 'dist'}


def sh(args, title):
    print()
    print('── ' + title)
    env = dict(os.environ)
    env['PYTHONIOENCODING'] = 'utf-8'
    r = subprocess.run([PY] + args, cwd=ROOT, env=env)
    return r.returncode


# ─────────────────────── 문서 ───────────────────────

def release_notes(stamp):
    return '''# RELEASE NOTES · {rc}

생성 {stamp}

## 이 묶음이 무엇인가

**사람 판정을 시작할 수 있는 상태의 실행 패키지다. 검증 결과가 아니다.**

세 가지를 구분해서 읽는다.

| 등급 | 무엇 |
|---|---|
| **확인된 사실** | 코드가 돌고 시험이 통과하고 숫자가 재현된다 |
| **DEMO · 모의** | 씨앗 고정 생성기가 만든 것. 사람 판정이 아니다 |
| **아직 검증 안 됨** | POC A · B · C 전부. 사람이 시작하지 않았다 |

`RC1_HANDOFF_FINAL.html` 이 이 셋을 화면에서 나눠 보여 준다. ZIP 최상위에 있다.

## 이번에 새로 들어간 것

| 무엇 | 파일 |
|---|---|
| 판정 도구 | `02_POC_A/rater_app.html` |
| blind 선별 도구 | `02_POC_A/blind_selector.html` |
| 개인정보 회귀 시험 | `03_POC_C/privacy_test.html` · `privacy_test_cases.json` |
| 역할별 꾸러미와 누출 검사 | `tests/bundles.py` |
| 실측 매니페스트 | `tests/make_manifest.py` |
| 명령 입구 | `poc.py` |

## 고친 것

| 무엇 | 어디 |
|---|---|
| 다섯 자 이름에서 앞 글자가 남던 것 | `intake_prototype.html` P01 |
| 주민번호가 아닌 열세 자리에 저장이 막히던 것 | `intake_prototype.html` P10 |
| 치환 템플릿이 참가자 화면에 새던 것 | `intake_prototype.html` 로그 표시 |
| 감사가 자기 출력을 읽고 자기를 지적하던 것 | `tests/audit.py` |

자세한 것은 `03_POC_C/PRIVACY_TEST_RESULT.md`.

## 바로 할 수 있는 것

```
python poc.py status      지금 어디까지 됐나
python poc.py test        시험 · 감사 · 누출 검사
python poc.py bundles     역할별 꾸러미
```

## 사람이 해야 다음이 열린다

| | 무엇 | 막는 것 |
|---|---|---|
| H-01 | 판정자 2명 | POC A |
| H-02 | blind 후보 60~80쌍에서 40쌍 선별 | POC A |
| H-04 · H-05 | 기관 검토 · 참가자 5~10명 | POC C |

H-02 를 마치기 전에는 `poc.py prepare-a` 가 기존 20쌍만으로 양식을 만든다.
그것은 공식 POC A 가 아니다. 스크립트가 그렇게 경고한다.

## 하지 않은 것

- Frozen Spec v0.1 을 고치지 않았다. 발견한 문제는 `00_README/ISSUES_FOR_V0_2.md` 에만 적었다
- 임상 효과를 주장하지 않는다
- LLM 판정을 정답으로 쓰지 않는다
- 없는 검증 결과를 만들지 않았다
'''.format(rc=RC, stamp=stamp)


def known_issues(stamp):
    return '''# KNOWN ISSUES · {rc}

생성 {stamp}

**고치지 않고 남긴 것을 전부 적는다.** 묶음이 깨끗해 보이려고 빼지 않는다.

## 규격 쪽 · `00_README/ISSUES_FOR_V0_2.md` 에 자세히

| | 무엇 | 등급 |
|---|---|---|
| I-01 | §5.2 요약 숫자가 표와 불일치. 합 22 ≠ 20 | 문서 오류 |
| I-02 | `context_constraints` UNKNOWN 처리가 §4.2 와 §4.3 에서 다르게 읽힘 | 읽기 모호 |
| I-03 | Transfer Distance 가 PERFORM 라벨에서 사라짐 | 설계 질문 |
| I-04 | Core field κ 문턱 0.5 를 다섯에 일괄 적용 | 측정 가정 |
| I-05 | 인수인계 문서의 파일 수 내역이 총계와 안 맞음 | **해결됨** · 매니페스트를 실측으로만 만든다 |
| I-09 | A1 표본 · 규격은 blind 20 · 합계 40, RC1 실행은 blind 40 · 합계 60 | **실행 편차** · 판정 규칙은 그대로 · `02_POC_A/a1_counts.json` |

## 개인정보 규칙 쪽 · `03_POC_C/PRIVACY_TEST_RESULT.md` 에 자세히

### DEFECT · 고치지 않고 남긴 것 3건

| | 시험 번호 | 무엇 | 왜 안 고쳤나 |
|---|---|---|---|
| I-06 | `W06` | `20260912` 같은 여덟 자리 날짜를 학번으로 보고 지움 | 날짜를 지킬지 학번을 지킬지가 정책 결정이다 |
| I-07 | `Y01` | `02-123-4567` 유선번호를 못 잡음 | 자릿수가 들쭉날쭉해 범위를 정해야 한다 |
| I-08 | `Y02` | 외국인등록번호 성별자리 5~8 을 못 잡음 | 넓히면 임의의 열세 자리가 더 걸린다 |

### ACCEPT · 알고 허용한 과잉 삭제 6건

| 시험 번호 | 입력 | 지워지는 말 |
|---|---|---|
| `Z01` | 학생회 선배가 그랬다 | 학생회 |
| `Z02` | 인사팀 과장님이 불렀다 | 인사팀 |
| `Z03` | 개발팀 팀장님이 회의를 잡았다 | 개발팀 |
| `Z04` | 사진동아리 선배가 조언했다 | 사진동아리 |
| `Z05` | 컴공과 선배가 알려줬다 | 컴공과 |
| `Z06` | 알바하는 형이 그랬다 | 알바하는 |
 `NOT_A_NAME` 이 정확일치 목록이라 복합 소속어를 막지 못한다.

이름 쪽으로 틀리는 편을 택했다. 저장 전 화면이 편집 가능하므로 참가자가 되돌린다.

### LIMIT · 정규식이 원리상 못 하는 것 4건

| 시험 번호 | 입력 |
|---|---|
| `K01` | 민수가 그러는데 안 된대 |
| `K02` | 어제 지훈이랑 얘기했다 |
| `K03` | 수빈이 먼저 갔다 |
| `K04` | Jiwon told me it was fine |

호칭 없는 한글 이름과 영문 이름은 문자열만으로 일반 단어와 구분되지 않는다.
규칙을 더 넣으면 과잉 삭제가 늘 뿐이다.

**저장 직전 확인 화면이 이것을 막는 유일한 장치다.**

## 검증되지 않은 것

- **POC A** · 사람 판정 0건. `results_demo` 는 씨앗 고정 표본이다
- **POC B** · 시작하지 않았다. A 가 통과해야 연다. dry-run 은 EchoProvider 라 품질을 재지 않는다
- **POC C** · 참가자 0명. `results_demo` 는 합성 사건이다
- **개인정보 시험** · 87건이 각자 기대한 분류와 맞았다는 뜻이다.
  `87건 통과` · `탐지 정확도 100%` · `PII 제거 검증 완료` 같은 표현은 쓰지 않는다.
  내역은 PASS 74 · DEFECT 3 · ACCEPT 6 · LIMIT 4 · STALE 0 이고,
  DEFECT 와 LIMIT 는 지금도 막지 못하는 입력이다

## 환경

- Python 3.13 에서 만들고 돌렸다. 표준 라이브러리만 쓴다
- HTML 도구 셋은 Chrome 에서 확인했다. `rater_app.html` 과 `blind_selector.html` 은 `file://` 로 열린다
- `privacy_test.html` 은 원본에서 규칙을 꺼내 오므로 로컬 HTTP 가 필요하다.
  `file://` 로 열면 통과가 아니라 **중단**된다
'''.format(rc=RC, stamp=stamp)


def package_counts():
    """VERIFY_RELEASE 에 적을 파일 수. 손으로 적지 않고 make_manifest 와 같은 규칙으로 센다.

    예전에는 91 · 94 가 템플릿에 박혀 있었다. 파일을 하나 더하면 문서가 조용히 틀린다(ERR-05 와 같은 계열).
    이 함수가 도는 시점에 세 문서가 아직 없을 수 있으므로 없으면 더해서 센다."""
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    import make_manifest as mm
    rows, _cache = mm.walk()
    have = {r['path'] for r in rows}
    pending = [n for n in ('RELEASE_NOTES.md', 'KNOWN_ISSUES.md', 'VERIFY_RELEASE.md') if n not in have]
    n_general = len(rows) + len(pending)
    cover = 1 if os.path.exists(os.path.join(os.path.dirname(ROOT), mm.COVER_NAME)) else 0
    return {'n_general': n_general, 'n_covered': n_general + 2 + cover}


def verify_release(stamp):
    return '''# VERIFY RELEASE · {rc}

생성 {stamp}

받은 사람이 **직접** 확인하는 절차다. 이 문서의 주장을 믿지 말고 돌려 본다.

## 0 · 한 줄로

```
cd {pkg}
python poc.py verify-release --zip ../{zipname}
```

여덟 항목이 전부 `ok` 여야 한다. 하나라도 실패하면 exit 1 이다. 아래 1~7 은 같은 것을 손으로 따라가는 절차다.

8번 `숫자 · 인터페이스` 는 체크섬이 못 잡는 것을 본다. 파일은 온전한데 문서끼리 쌍 수가 다르거나, 선별기가 내려 주는 파일 이름과 `poc.py` 가 찾는 이름이 다른 경우다(ERR-04 · ERR-05).

## 1 · 풀기

```
unzip {zipname}
cd {pkg}
```

## 2 · 해시 확인

```
cd {pkg}
sha256sum -c SHA256SUMS.txt
```

**{n_covered}줄이 전부 맞아야 한다.** 덮는 범위는 아래와 같다.

| | 수 |
|---|---|
| 패키지 안 일반 파일 | {n_general} |
| `RELEASE_MANIFEST.json` · `.md` | 2 |
| `../RC1_HANDOFF_FINAL.html` · ZIP 최상위 표지 | 1 |
| **합 · SHA256-covered** | **{n_covered}** |

덮지 못한 것은 `SHA256SUMS.txt` 하나뿐이다. 자기 해시를 자기 안에 담을 수 없다.
표지 줄이 `../` 로 시작하므로 **패키지 폴더 안에서** 돌려야 한다.

Windows PowerShell 이면

```
Get-Content SHA256SUMS.txt | ForEach-Object {{
  $h,$p = $_ -split '  ',2
  $a = (Get-FileHash $p -Algorithm SHA256).Hash.ToLower()
  if ($a -ne $h) {{ "MISMATCH $p" }}
}}
```

아무것도 안 나오면 전부 맞은 것이다.

## 3 · 시험

```
python poc.py test
```

네 가지가 통과해야 한다.

| 무엇 | 통과 기준 |
|---|---|
| 단위 시험 | `Ran N tests` · `OK` · 실패 0 |
| 문서 감사 | `지적 0건` |
| 누출 검사 | `지적 0건` 또는 `건너뜀` |
| 숫자 · 인터페이스 일치 | `판정 · 통과` |

누출 검사가 `건너뜀` 이면 `python poc.py bundles` 를 먼저 돌린다.

## 4 · 상태

```
python poc.py status
```

`있어야 할 것` 여덟 줄이 전부 `ok` 여야 한다.

## 5 · DEMO 재현

```
python 02_POC_A/analyze_agreement.py 02_POC_A/sample_rater_A.csv 02_POC_A/sample_rater_B.csv --out /tmp/chk --demo
```

이해 κ 0.519 · 수행 κ 0.614 가 나와야 한다.

**같은 숫자가 나온다는 것은 생성기가 씨앗 고정이라는 뜻이지,
이 숫자가 무엇을 검증한다는 뜻이 아니다.** 전부 DEMO 다.

## 6 · 개인정보 시험

```
cd 03_POC_C
python -m http.server 8765 --bind 127.0.0.1
```

브라우저에서 `http://localhost:8765/privacy_test.html` · **전체 실행**

**87건이 각자 기대한 분류와 맞아야 한다.** 내역은 다음과 같다.

| 등급 | 기대 | 뜻 |
|---|---|---|
| `PASS` | 74 | 회귀 통과 |
| `DEFECT` | 3 | `W06` `Y01` `Y02` · I-06 I-07 I-08 |
| `ACCEPT` | 6 | `Z01`~`Z06` · 알고 허용한 과잉 삭제 |
| `LIMIT` | 4 | `K01`~`K04` · 정규식이 원리상 못 함 |
| `STALE` | 0 | 메타데이터가 실제 동작과 어긋난 것 |

`STALE` 이 0이 아니면 시험 파일의 메타데이터가 실제 동작과 어긋난 것이다.

**87건이 맞았다는 것은 짜 둔 시험이 기대대로 나왔다는 뜻이다.**
`87건 통과` · `탐지 정확도 100%` · `PII 제거 검증 완료` 로 옮겨 적지 않는다.
DEFECT 3건과 LIMIT 4건은 지금도 막지 못하는 입력이고 `KNOWN_ISSUES.md` 에 번호로 적혀 있다.

## 7 · 꾸러미

```
python poc.py bundles
```

**역할 7개 폴더가 나오고** 누출 검사가 `지적 0건` 이어야 한다.

배포용 ZIP 은 **6개**다. 수가 다른 이유는 하나다.

```
역할 번들            7   admin · blind_selector · rater_A · rater_B
                         poc_c_operator · poc_c_participant · expert_review
배포용 role ZIP    - 6   admin 을 뺀 여섯
                    ---
admin                1   별도 ZIP 이 아니다. RC1 root 그 자체다
```

`admin` 은 패키지 전체 사본이므로 따로 압축하지 않는다.
운영자는 `{zipname}` 을 그대로 쓴다.

`rater_A` 와 `rater_B` 는 `판정할 쌍 파일이 아직 없다` 고 경고한다. **정상이다.**
선별된 blind 40쌍(H-02)이 아직 없기 때문이다.

## 확인해도 알 수 없는 것

위를 다 통과해도 **POC 는 아무것도 검증하지 않았다.**
사람 판정자가 아직 한 쌍도 보지 않았고 참가자가 아직 한 명도 없다.
`KNOWN_ISSUES.md` 의 `검증되지 않은 것` 을 읽는다.
'''.format(rc=RC, stamp=stamp, zipname=ZIP_NAME, pkg=PKG, **package_counts())


# ─────────────────────── zip ───────────────────────

# 인수인계 문서는 패키지 밖에 둔다. 안에 넣으면 파일 수가 다시 순환한다.
# 대신 zip 최상위에 같이 실어 받는 쪽이 먼저 읽게 한다
COVER = 'RC1_HANDOFF_FINAL.html'


def zip_package():
    path = os.path.join(OUT, ZIP_NAME)
    if os.path.exists(path):
        os.remove(path)
    n = 0
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED) as z:
        for dp, dn, fn in os.walk(ROOT):
            dn[:] = [d for d in dn if d not in SKIP_DIRS]
            for f in sorted(fn):
                p = os.path.join(dp, f)
                rel = os.path.relpath(p, ROOT).replace('\\', '/')
                z.write(p, PKG + '/' + rel)
                n += 1
        cover = os.path.join(OUT, COVER)
        if os.path.exists(cover):
            z.write(cover, COVER)
            n += 1
    return path, n, os.path.getsize(path)


def zip_bundles():
    dist = os.path.join(ROOT, 'dist')
    made = []
    if not os.path.isdir(dist):
        return made
    for role in sorted(os.listdir(dist)):
        d = os.path.join(dist, role)
        if not os.path.isdir(d) or role == 'admin':
            continue           # admin 은 본 묶음과 같다. 두 번 넣지 않는다
        zp = os.path.join(dist, '%s_%s.zip' % (role, RC))
        if os.path.exists(zp):
            os.remove(zp)
        n = 0
        with zipfile.ZipFile(zp, 'w', zipfile.ZIP_DEFLATED) as z:
            for dp, _, fn in os.walk(d):
                for f in sorted(fn):
                    p = os.path.join(dp, f)
                    z.write(p, role + '/' + os.path.relpath(p, d).replace('\\', '/'))
                    n += 1
        made.append((role, n, os.path.getsize(zp)))
    return made


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--skip-tests', action='store_true')
    args = ap.parse_args()
    stamp = time.strftime('%Y-%m-%d %H:%M:%S')

    if not args.skip_tests:
        if sh(['-W', 'ignore', 'tests/test_all.py'], '1 단위 시험'):
            print('\n시험이 깨졌다. 묶지 않는다.')
            return 1
        if sh(['tests/audit.py'], '2 문서 감사'):
            print('\n감사가 지적했다. 묶지 않는다.')
            return 1

    if sh(['tests/bundles.py', 'build'], '3 역할별 꾸러미 · 누출 검사'):
        print('\n누출 검사가 지적했다. 묶지 않는다.')
        return 1

    print()
    print('── 4 문서')
    for name, fn in (('RELEASE_NOTES.md', release_notes),
                     ('KNOWN_ISSUES.md', known_issues),
                     ('VERIFY_RELEASE.md', verify_release)):
        io.open(os.path.join(ROOT, name), 'w', encoding='utf-8').write(fn(stamp))
        print('   ' + name)

    if sh(['tests/consistency.py'], '4b 숫자 · 인터페이스 일치'):
        print('\n쌍 수나 파일 이름이 문서끼리 어긋난다. 묶지 않는다.')
        return 1

    if sh(['tests/make_manifest.py'], '5 실측 매니페스트'):
        print('\n매니페스트 내역이 총계와 맞지 않는다. 묶지 않는다.')
        return 1

    print()
    print('── 6 zip')
    path, n, size = zip_package()
    print('   %-42s 파일 %d · %s bytes' % (os.path.basename(path), n, format(size, ',')))
    for role, rn, rs in zip_bundles():
        print('   dist/%-36s 파일 %d · %s bytes' % (
            '%s_%s.zip' % (role, RC), rn, format(rs, ',')))

    print()
    print('=' * 60)
    print('  %s 를 만들었다' % RC)
    print('=' * 60)
    print('  %s' % path)
    print()
    print('  받는 쪽은 VERIFY_RELEASE.md 를 따라 직접 확인한다.')
    print('  통과해도 POC 는 아무것도 검증하지 않았다. KNOWN_ISSUES.md 를 읽는다.')
    print()
    return 0


if __name__ == '__main__':
    sys.exit(main())
