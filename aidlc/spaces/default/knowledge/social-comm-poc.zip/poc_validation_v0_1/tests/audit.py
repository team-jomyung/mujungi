"""품질 감사 · 지시문 §12 의 체크리스트를 기계로 돌린다.

    python tests/audit.py

패키지 전체를 훑어 금지 사항을 어긴 곳을 찾는다.
"""
import io
import json
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
# dist 는 파생 사본이다. 감사하면 모든 파일을 두 번 세고
# 이 스크립트의 사본까지 읽어 자기 금칙어 목록에 걸린다.
# dist 는 tests/bundles.py check 가 따로 본다.
SKIP_DIRS = {'__pycache__', '_gold', 'results_demo', 'b_output', '_incoming', 'dist'}
TEXT_EXT = {'.md', '.py', '.json', '.html', '.csv', '.txt'}


# 감사 스크립트와 그 출력은 감사하지 않는다. 금지어 목록을 그대로 들고 있기 때문이다.
SELF = os.path.abspath(__file__)
# 경로로만 자기를 알아보면 복사되는 순간 못 알아본다. 이름으로도 본다
SELF_NAME = os.path.basename(__file__)
# 이 스크립트의 stdout 을 담는 파일은 전부 여기에 적는다.
# 하나라도 빠지면 감사가 자기 금칙어 목록을 읽고 자기를 지적한다.
SELF_OUTPUT = {'audit_results.txt', 'PHASE1_AUDIT_RAW.json', 'PHASE1_TEST_RUN.log'}


def files():
    for dp, dn, fn in os.walk(ROOT):
        dn[:] = [d for d in dn if d not in SKIP_DIRS]
        for f in fn:
            p = os.path.join(dp, f)
            if os.path.abspath(p) == SELF or f == SELF_NAME or f in SELF_OUTPUT:
                continue
            if os.path.splitext(f)[1] in TEXT_EXT:
                yield p


# 금지 목록을 적어 둔 자리는 위반이 아니다
NEGATION_MARKERS = (
    '않', '아니', '아님', '없다', '금지', 'forbidden', '말라', '말고', '쓰지', '부르지',
    '보여주지', '취급하지', '주장하지', 'not ', '뿐', '지 마', '이어야', '미조사', '미확장')


def negated(seg):
    return any(k in seg for k in NEGATION_MARKERS)


def read(p):
    try:
        return io.open(p, encoding='utf-8', errors='replace').read()
    except Exception:
        return ''


def rel(p):
    return os.path.relpath(p, ROOT).replace('\\', '/')


CHECKS = []


def check(name):
    def deco(fn):
        CHECKS.append((name, fn))
        return fn
    return deco


@check('frozen spec 와 다른 규칙을 새로 넣었나')
def c1(corpus):
    sys.path.insert(0, os.path.join(ROOT, '02_POC_A'))
    from rule_engine import CORE_UNDERSTAND, CORE_PERFORM
    rules = json.load(io.open(os.path.join(ROOT, '01_SPEC',
                      'decision_rules_machine_readable.json'), encoding='utf-8'))
    bad = []
    if tuple(rules['core_equivalence_fields']['understand']) != CORE_UNDERSTAND:
        bad.append('JSON 과 rule_engine 의 이해 Core 가 다르다')
    if tuple(rules['core_equivalence_fields']['perform']) != CORE_PERFORM:
        bad.append('JSON 과 rule_engine 의 수행 Core 가 다르다')
    return bad


@check('Core 가 다섯보다 늘거나 줄었나')
def c2(corpus):
    sys.path.insert(0, os.path.join(ROOT, '02_POC_A'))
    from rule_engine import CORE_PERFORM, CORE_UNDERSTAND
    bad = []
    if len(CORE_PERFORM) != 5:
        bad.append(f'CORE_PERFORM 이 {len(CORE_PERFORM)}개')
    if len(CORE_UNDERSTAND) != 4:
        bad.append(f'CORE_UNDERSTAND 가 {len(CORE_UNDERSTAND)}개')
    return bad


@check('Skill Identity 와 Transfer Distance 를 한 통계로 섞었나')
def c3(corpus):
    bad = []
    p = os.path.join(ROOT, '02_POC_A', 'analyze_agreement.py')
    t = read(p)
    if 'subset' not in t or 'skill_identity_understand' not in t:
        bad.append('축 2 의 부분집합 규칙이 코드에 없다')
    if "'전체'" in t and 'kappa' in t.split("'전체'")[0][-200:]:
        bad.append('두 축을 합친 κ 가 있는 것으로 보인다')
    return bad


@check('LLM 판정을 gold 라고 불렀나')
def c4(corpus):
    bad = []
    pats = [r'validator.{0,20}(정답|gold|ground.?truth)',
            r'(정답|gold|ground.?truth).{0,20}validator',
            r'모델 판정.{0,15}(기준|정답)']
    for p, t in corpus:
        for pat in pats:
            for m in re.finditer(pat, t, re.I):
                seg = t[max(0, m.start()-60):m.start()+80].replace('\n', ' ')
                if negated(seg):
                    continue
                bad.append(f'{rel(p)} · {seg[:90]}')
    return bad


@check('synthetic data 를 validation data 라고 불렀나')
def c5(corpus):
    bad = []
    for p, t in corpus:
        for m in re.finditer(r'(synthetic|구성한|가짜|DEMO)[^\n]{0,40}validation dataset', t, re.I):
            seg = t[max(0, m.start()-160):m.start()+200].replace('\n', ' ')
            if negated(seg):
                continue
            bad.append(f'{rel(p)} · {seg[:90]}')
    return bad


@check('SCD 임상 효과를 암시했나')
def c6(corpus):
    bad = []
    pats = [r'(SCD|화용).{0,12}(개선|향상|치료|효과가 있)',
            r'임상적?\s*효과[^\n]{0,10}(있|입증|확인)']
    for p, t in corpus:
        for pat in pats:
            for m in re.finditer(pat, t):
                seg = t[max(0, m.start()-70):m.start()+90].replace('\n', ' ')
                if any(k in seg for k in ('않', '아니', '없다', '주장하지', '말하지', '금지')):
                    continue
                bad.append(f'{rel(p)} · {seg[:90]}')
    return bad


@check('ASD 근거를 SCD 직접 근거처럼 썼나')
def c7(corpus):
    bad = []
    for p, t in corpus:
        for m in re.finditer(r'ASD[^\n]{0,25}(근거|연구)[^\n]{0,25}SCD', t):
            seg = t[max(0, m.start()-160):m.start()+200].replace('\n', ' ')
            if negated(seg) or any(k in seg for k in ('구분','따로','넘겨','등급')):
                continue
            bad.append(f'{rel(p)} · {seg[:90]}')
    return bad


@check('user_goal UNKNOWN 을 오류로 취급했나')
def c8(corpus):
    sys.path.insert(0, os.path.join(ROOT, '02_POC_A'))
    from rule_engine import judge
    a = {f: 'SAME' for f in ('target_skill', 'required_inference',
                             'perspective_structure', 'decidable_by_evidence',
                             'direct_check_allowed')}
    a.update({'relationship_changed': 'SAME', 'situation_type_changed': 'SAME',
              'misread_cost_changed': 'SAME', 'recoverability_changed': 'SAME',
              'user_goal': 'UNKNOWN'})
    r = judge(a)
    bad = []
    if r['skill_identity_understand'] != 'SAME':
        bad.append('user_goal UNKNOWN 이 이해 판정을 막는다')
    if r['skill_identity_perform'] != 'SAME':
        bad.append('user_goal UNKNOWN 이 수행 판정을 막는다')
    sch = json.load(io.open(os.path.join(ROOT, '03_POC_C',
                    'personal_social_event.schema.json'), encoding='utf-8'))
    g = sch['properties']['user_goal_claim']
    if not g.get('x-nullable'):
        bad.append('schema 에서 user_goal_claim 이 nullable 이 아니다')
    return bad


@check('상대 의도를 단정하는 문구가 있나')
def c9(corpus):
    bad = []
    pats = [r'상대는[^\n]{0,12}(뜻이었|것이었|의도)', r'그 사람은 사실',
            r'상대방의 의도는', r'확실히[^\n]{0,8}(거절|신호)']
    for p, t in corpus:
        for pat in pats:
            for m in re.finditer(pat, t):
                seg = t[max(0, m.start()-400):m.start()+120].replace('\n', ' ')
                if negated(seg) or 'forbidden' in seg or 'mind_reading' in seg or '절대' in seg:
                    continue
                bad.append(f'{rel(p)} · {seg[:90]}')
    return bad


@check('제3자 PII 를 저장하게 했나')
def c10(corpus):
    bad = []
    sch = json.load(io.open(os.path.join(ROOT, '03_POC_C',
                    'personal_social_event.schema.json'), encoding='utf-8'))
    props = sch['properties']
    if props['raw_input'].get('x-required'):
        bad.append('raw_input 이 필수로 되어 있다')
    rel_enum = props['relationship_type']['enum']
    if any(re.search(r'[가-힣]{2,4}(씨|님)', v) for v in rel_enum):
        bad.append('relationship_type enum 에 인명 형태가 있다')
    html = read(os.path.join(ROOT, '03_POC_C', 'intake_prototype.html'))
    if 'raw_input' in html and not re.search(r'raw_input\s*:\s*null', html):
        bad.append('프로토타입이 raw_input 을 보관한다')
    return bad


@check('운영 기준 문턱을 문헌 근거처럼 썼나')
def c11(corpus):
    rules = json.load(io.open(os.path.join(ROOT, '01_SPEC',
                      'decision_rules_machine_readable.json'), encoding='utf-8'))
    bad = []
    th = {k: v for k, v in rules['thresholds'].items() if isinstance(v, dict)}
    ext = [k for k, v in th.items() if v.get('evidence_basis') == 'adjacent_reference']
    if ext != ['skill_identity_kappa']:
        bad.append(f'외부 준거를 주장하는 문턱이 {ext} 다. skill_identity_kappa 하나여야 한다')
    for k, v in th.items():
        if 'evidence_basis' not in v:
            bad.append(f'{k} 에 evidence_basis 가 없다')
    return bad


@check('DEMO 산출물이 검증 결과처럼 보이나')
def c12(corpus):
    bad = []
    for d, f in (('02_POC_A/results_demo', 'agreement_report.txt'),
                 ('03_POC_C/results_demo', 'pilot_report.txt'),
                 ('04_POC_B_SCAFFOLD/results_demo', 'preservation_report.txt')):
        p = os.path.join(ROOT, d, f)
        if os.path.exists(p):
            t = read(p)
            if 'DEMO ONLY' not in t and 'NOT VALIDATION RESULT' not in t:
                bad.append(f'{d}/{f} 에 DEMO 표시가 없다')
    return bad


@check('API 키가 코드에 박혀 있나')
def c13(corpus):
    bad = []
    for p, t in corpus:
        if p.endswith('audit.py'):
            continue
        for m in re.finditer(r'(sk-[A-Za-z0-9]{12,}|api[_-]?key\s*=\s*[\'"][^\'"]{12,})', t, re.I):
            bad.append(f'{rel(p)} · {m.group(0)[:24]}...')
    return bad


def main():
    corpus = [(p, read(p)) for p in files()]
    print(f'감사 대상 파일 {len(corpus)}개\n')
    total = 0
    for name, fn in CHECKS:
        try:
            issues = fn(corpus)
        except Exception as e:
            issues = [f'감사 자체가 실패 · {e}']
        if issues:
            total += len(issues)
            print(f'  x  {name}  ({len(issues)}건)')
            for i in issues[:4]:
                print(f'        {i}')
            if len(issues) > 4:
                print(f'        ... 외 {len(issues)-4}건')
        else:
            print(f'  ok {name}')
    print()
    print('=' * 56)
    print(f'  지적 {total}건')
    print('=' * 56)
    return 1 if total else 0


if __name__ == '__main__':
    sys.exit(main())
