# PHASE 1 감사 보고

감사일 2026-09-12 · 대상 `poc_validation_v0_1/` · **파일시스템을 ground truth 로 삼았다. 인수인계 문서를 인용하지 않고 다시 쟀다.**

---

## 판정

# VERIFIED

조건 다섯을 전부 만족한다.

| 게이트 | 상태 |
|---|---|
| 실제 inventory 확보 | **완료** · `ACTUAL_FILE_INVENTORY.csv` · `.json` |
| 핵심 구현 파일 존재 확인 | **15/15** · placeholder 0 |
| 테스트 재실행 가능 | **완료** · exit 0 |
| 주요 demo 재현 가능 | **3/3 재현** · 수치 완전 일치 |
| blocker 파악 완료 | **3건** · 전부 사람 |

**Phase 2 로 진행해도 된다.**

---

## 1 · 실제 파일 수

| | 값 |
|---|---|
| 전체 파일 | **75** |
| cache · OS metadata 제외 | **73** |
| 디렉터리 (세지 않음) | 16 |
| 총 바이트 | 655,298 |

cache 2개는 `__pycache__/*.pyc` 로, 스크립트를 돌릴 때마다 다시 생긴다. **파일 수에서 제외한다.**

### 범주별

| 범주 | 수 | 뜻 |
|---|---|---|
| doc | 30 | `.md` 문서 |
| data | 15 | `.csv` · `.json` 입력·양식 |
| source | 13 | `.py` 와 `intake_prototype.html` |
| demo_result | 8 | DEMO 실행 산출물 |
| test | 3 | 시험·감사 스크립트 |
| data_restricted | 2 | `_gold/` · `_incoming/` |
| test_output | 2 | 시험·감사 저장 결과 |
| cache | 2 | `.pyc` · **제외** |

### 생성 대 원본

| | 수 |
|---|---|
| source (사람이 쓴 것) | 52 |
| generated (코드가 만든 것) | 23 |

**요구 파일 47개 선언 · 47개 전부 존재 · 누락 0.**

---

## 2 · "72개" 의 출처 역추적

### 결론

**72 라는 숫자 자체는 맞았다. 그 숫자를 설명한 내역이 틀렸다.**

| 인수인계 주장 | 실제 값 | 차이 | 원인 | 수정 필요 |
|---|---|---|---|---|
| 전체 72개 | **당시 72 · 현재 73** (cache 제외) | +1 | 감사 중 `phase1_inventory.py` 를 추가함 | 숫자 갱신 |
| 요구 파일 47개 | **47** | 0 | — | 없음 |
| 추가 파일 10개 | **10** | 0 | source 7 + data 3 | 없음 |
| 시험·감사 4개 | **당시 4 · 현재 6** | +2 | `phase1_inventory.py` · `phase1_audit.py` 추가 | 숫자 갱신 |
| **47+10+4 = 61** | **72** | **-11** | **내역에서 11개를 빠뜨렸다** | **설명 수정** |

### 빠뜨린 11개의 정체

| 무엇 | 수 | 목록 |
|---|---|---|
| DEMO 산출물 | 8 | A 3 (`agreement_report.json/.txt`, `disagreements.csv`) · C 2 · B 3 |
| 제한 데이터 | 2 | `_gold/existing_synthetic_20_SPEC_EXPECTED.csv` · `_incoming/blind_candidates_raw.csv` |
| 출처 기록 | 1 | `_incoming/PROVENANCE.md` |

**47 + 10 + 4 + 11 = 72.** 산술이 맞는다.

### 왜 이런 일이 생겼나

두 숫자를 **서로 다른 방법으로 뽑고 대조하지 않았다.**

- `72` 는 `find . -type f -not -path "*/__pycache__/*" | wc -l` 결과
- `47 / 10 / 4` 는 요구 목록과 눈으로 센 추가 파일

**코드가 만들어 낸 산출물을 어느 칸에도 넣지 않았다.** 그래서 합이 맞지 않았고, 문서에 적기 전에 더해 보지 않았다.

### 확인한 것과 배제한 것

| 가설 | 결과 |
|---|---|
| 디렉터리를 파일로 셌나 | **아니다.** 디렉터리 16개는 처음부터 제외됐다 |
| demo output 을 중복 집계했나 | **아니다.** 8개가 각각 한 번씩만 있다 |
| hidden · cache 를 포함했나 | **아니다.** `find` 가 `__pycache__` 를 제외했다 |
| 72 가 허수인가 | **아니다.** 당시 실제 값이다 |

**숫자를 맞추려고 파일을 재분류하지 않았다.** 내역이 틀렸을 뿐 총계는 실측이었다.

---

## 3 · 구현 존재성 감사

핵심 15개 전부 존재하고 **placeholder 가 없다.**

| 판정 | 수 | 파일 |
|---|---|---|
| `IMPLEMENTED` | **14** | rule_engine · analyze_agreement · randomize_pairs · make_forms · check_blind_format · intake_prototype.html · personal_social_event.schema.json · clarification_rules.json · personal_pattern · analyze_pilot · preservation_metrics · seed_10.json · generator_prompt.md · validator_prompt.md |
| `OK_WITH_INTENTIONAL_STUB` | **1** | `generation_harness.py` |
| `PLACEHOLDER` · `EMPTY` · `BROKEN` · `MISSING` | **0** | — |

### `generation_harness.py` 의 미구현 넷

| 함수 | 줄 | 성격 |
|---|---|---|
| `LLMProvider.generate` | 38 | **추상 인터페이스.** 하위 클래스가 채운다 |
| `LLMProvider.validate` | 41 | 같음 |
| `HTTPProvider.generate` | 108 | **의도한 TODO.** 벤더 SDK 선택은 팀 결정 |
| `HTTPProvider.validate` | 113 | 같음 |

전체 13개 함수 중 넷이고 **나머지 9개는 구현돼 있다.** `EchoProvider` 가 완전 구현이라 dry-run 이 돈다. TODO 주석 2개는 이 둘에 붙은 것이다.

**의도한 미구현이므로 PLACEHOLDER 로 판정하지 않았다.** 문서(`HUMAN_ACTIONS.md` H-07)와 코드 주석 양쪽에 팀이 채운다고 적혀 있다.

핵심 파이썬 파일의 유효 줄 합계는 **1,615줄**이다.

---

## 4 · 테스트 재실행

**인수인계 숫자를 인용하지 않고 지금 다시 돌렸다.**

| 명령 | exit | 결과 | 소요 |
|---|---|---|---|
| `python -W ignore tests/test_all.py` | **0** | **Ran 34 tests · OK** · 실패 0 · 건너뜀 0 | 0.27s |
| `python tests/audit.py` | **0** | **지적 0건** · 13항목 전부 통과 | 0.28s |

전체 로그는 `PHASE1_TEST_RUN.log`.

---

## 5 · DEMO 재현성

현재 코드로 다시 만들어 **핵심 숫자를 대조**했다.

| DEMO | 재현 | 대조한 값 |
|---|---|---|
| **POC A 일치도** | **재현됨** | 이해 κ `0.5192307692307693` · 수행 κ `0.6135265700483092` · 판정 `FAIL` · **전부 일치** |
| **POC C 파일럿** | **재현됨** | 참가자 7 · 사건 16 · 중앙값 390.5초 · 판정 `USABILITY_RETRY` · **전부 일치** |
| **POC B dry-run** | **재현됨** | 요청 90 · 수락 90 · 총 시도 134 · **전부 일치** |

`NOT_REPRODUCIBLE` 은 **0건**이다.

> **재현되는 이유를 적어 둔다.** 세 생성기가 전부 seed 고정이다(`make_sample_ratings.py` 424242 · `make_synthetic_events.py` 777 · `EchoProvider` 결정적). **같은 입력에서 같은 출력이 나온다는 뜻이지, 이 수치가 무엇을 검증한다는 뜻이 아니다.** 전부 DEMO 다.

---

## 6 · 인수인계 문서와 다른 점

| 인수인계가 적은 것 | 실제 | 등급 |
|---|---|---|
| "파일 72개" | 당시 72 · **현재 73** (cache 제외) · 전체 75 | 갱신 필요 |
| "47 + 10 + 4" | **합이 61 로 총계와 안 맞음.** 11개 누락 | **설명 오류** |
| "시험 34/34" | **확인됨** · exit 0 | 일치 |
| "감사 13항목 0건" | **확인됨** · exit 0 | 일치 |
| "핵심 파일 전부 구현" | **확인됨** · placeholder 0 | 일치 |
| "DEMO 재현 가능" | **확인됨** · 3/3 | 일치 |

**틀린 것은 하나다. 파일 수 내역.** 나머지 주장은 실측으로 확인됐다.

---

## 7 · 수정한 engineering bug

**없다.**

감사 중 코드 결함을 발견하지 못했다. 테스트도 감사도 재현도 전부 통과했다.

추가한 것은 감사 도구 둘뿐이다.

| 파일 | 목적 | 변경 전 | 변경 후 |
|---|---|---|---|
| `tests/phase1_inventory.py` | 전수조사 | 없었음 | 신규 · 기존 코드 건드리지 않음 |
| `tests/phase1_audit.py` | 구현·재현 감사 | 없었음 | 신규 · 기존 코드 건드리지 않음 |

**기존 파일을 한 줄도 고치지 않았다.**

---

## 8 · 수정하지 않은 spec issue

`ISSUES_FOR_V0_2.md` 의 4건 그대로다. **Frozen Spec 을 고치지 않았다.**

| | 내용 | 상태 |
|---|---|---|
| I-01 | §5.2 요약 숫자가 표와 불일치 (합 22 ≠ 20) | 기록만 |
| I-02 | `context_constraints` UNKNOWN 처리가 §4.2 와 §4.3 에서 다르게 읽힘 | 기록만 |
| I-03 | Transfer Distance 가 PERFORM 라벨에서 사라짐 | 기록만 |
| I-04 | Core field κ 문턱 0.5 를 다섯에 일괄 적용 | 기록만 |

여기에 이번 감사에서 하나를 더한다.

| | 내용 | 상태 |
|---|---|---|
| **I-05** | **인수인계 문서의 파일 수 내역이 총계와 맞지 않음.** 문서 오류이지 규격 문제가 아니므로 v0.2 가 아니라 **Phase 2 에서 RELEASE_MANIFEST 실측값으로 대체**한다 | Phase 2 처리 |

---

## 9 · Blocker

Phase 1 에서 새로 발견한 blocker 는 **없다.** 기존 셋 그대로다.

| # | 무엇 | 막는 것 |
|---|---|---|
| H-01 | 판정자 2명 | POC A |
| H-02 | blind 40쌍에서 20쌍 선별 | POC A |
| H-04·05 | 기관 검토 + 참가자 5~10명 | POC C |

---

## 10 · 남은 관찰

- **`__pycache__` 가 계속 다시 생긴다.** Phase 2 패키징에서 반드시 제외한다
- **`_gold/` 와 `_incoming/` 이 같은 트리에 있다.** 역할별 번들을 만들 때 새는 가장 큰 위험이다
- **개발자 절대경로 의존을 아직 확인하지 않았다.** Phase 2 clean-room 에서 본다
- **Python 버전 의존을 명시하지 않았다.** 현재 3.13 에서 돌았다. Phase 2 에서 적는다

---

## 산출물

| 파일 | 내용 |
|---|---|
| `ACTUAL_FILE_INVENTORY.csv` | 75행 · 11열 · sha256 포함 |
| `ACTUAL_FILE_INVENTORY.json` | 같은 내용 + 요약 통계 |
| `PHASE1_TEST_RUN.log` | 테스트·감사·재현 실행 로그 |
| `PHASE1_AUDIT_RAW.json` | 구현 감사와 재현 대조 원자료 |
| `PHASE1_AUDIT_REPORT.md` | 이 문서 |
