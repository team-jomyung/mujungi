# -*- coding: utf-8 -*-
"""숫자와 인터페이스 일치 검사. verify-release 8번 항목.

    python tests/consistency.py

왜 있나
  ERR-04 · 표본을 40 에서 60 으로 올렸는데 그 60쌍을 만드는 의뢰문은 40쌍짜리로 남았다.
  ERR-05 · 그 수정이 네 파일에만 들어가고 서른 곳 넘게 옛 숫자가 남았다.
           선별기가 내려 주는 파일 이름과 poc.py 가 찾는 파일 이름도 달랐다.
  체크섬은 이런 어긋남을 못 잡는다. 파일은 온전한데 숫자끼리 말이 안 되는 것이기 때문이다.

무엇을 보나
  1 인터페이스  선별기가 내려 주는 파일 이름 = a1_counts.json 의 이름
                poc.py 와 randomize_pairs.py 가 a1_counts.json 을 읽는가
  2 등록 숫자   파일을 읽지 못하는 곳(HTML, 문서)에 적힌 숫자가 a1_counts.json 과 같은가
                문장이 사라져 정규식이 안 맞으면 그것도 실패다. 조용히 넘어가지 않는다
  3 옛 문장     알려진 옛 표현이 남아 있으면 실패
  4 산술        값들끼리 말이 되는가 (유형 최소 x 유형 수 <= 선별 수 등)

면제
  동결 규격, 규격을 인용하는 이슈 목록, 1단계 감사 당시 기록, a1_counts.json 자신은 옛 숫자를 가져도 된다.
  이 파일 자신도 옛 문장 목록을 들고 있으므로 면제한다. 경로가 아니라 이름으로 알아본다.
  dist/ 에 복사돼도 같은 이름이라 면제가 따라간다 (audit.py 에서 세 번 터진 자기참조를 여기서 되풀이하지 않는다).
  면제 수는 항상 화면에 찍는다. 면제가 늘면 이유를 확인한다.
"""
from __future__ import annotations

import io
import json
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SELF_NAME = os.path.basename(__file__)
COUNTS_REL = '02_POC_A/a1_counts.json'
# 규격 v0.1 값을 일부러 인용하는 줄에 붙인다. bundles.py 의 leakcheck-ok 와 같은 방식
LINE_MARK = 'count' + '-ok'

SKIP_DIRS = {'dist', '__pycache__', '.git'}
TEXT_EXT = ('.md', '.html', '.py', '.json', '.txt', '.csv')

EXEMPT = {
    '01_SPEC/frozen_spec_v0_1.html': '동결 규격. 고치지 않는다',
    '02_POC_A/a1_counts.json': '옛 파일 이름을 호환 목록으로 가진다',
    'tests/PHASE1_AUDIT_REPORT.md': '1단계 감사 당시 기록',
    'tests/PHASE1_AUDIT_RAW.json': '1단계 감사 당시 기록',
    'tests/PHASE1_TEST_RUN.log': '1단계 감사 당시 기록',
    'tests/audit_results.txt': '감사 실행 로그',
    'tests/test_results.txt': '시험 실행 로그',
}

# 알려진 옛 표현. 쌍 수 자체가 아니라 옛 절차를 가리키는 문장만 넣는다.
# "기존 20쌍", "20쌍씩 나눠서" 처럼 지금도 맞는 문장은 넣지 않는다.
STALE = [
    # ERR-06 · 옛 판 시뮬레이션 수치. 이 꾸러미에도 두 곳에 박혀 있었다.
    # ISSUES_FOR_V0_2.md 는 파일 단위로 면제돼 있어서 안 보였다. 면제를 줄 단위로 좁혔다.
    ('확률 0.13,', 'ERR-06 · 지금 값은 0.175'),
    ('60쌍에서 0.81.', 'ERR-06 · 지금 값은 0.795'),
    ('주장할 확률이 **0.13**', 'ERR-06 · 지금 값은 0.175'),
    ('blind 20쌍', 'blind 는 선별 40쌍이다'),
    ('20쌍을 고른다', '고르는 수는 40쌍이다'),
    ('20쌍을 고를', '고르는 수는 40쌍이다'),
    ('20쌍 선별', '선별 수는 40쌍이다'),
    ('20쌍 고르기', '선별 수는 40쌍이다'),
    ('40쌍에서 20쌍', '후보 60~80쌍에서 40쌍이다'),
    ('합쳐서 40쌍', '합계는 60쌍이다'),
    ('판정용 40쌍', '판정용은 60쌍이다'),
    ('40쌍에 2~3시간', '60쌍 기준 시간이다'),
    ('40쌍이면 두세 시간', '60쌍 기준 시간이다'),
    ('P21~P40 먼저', '묶음은 셋이다'),
    ('B01 부터 B40', '번호는 B80 까지다'),
    ('30~40쌍', '후보는 60~80쌍이다'),
    ('30~40개', '후보는 60~80개다'),
    ('TARGET = 20', '선별 목표는 40이다'),
    ('TYPE_MIN = 2', '유형 최소는 3이다'),
    ('최소 두 쌍씩', '유형 최소는 세 쌍이다'),
    ('남긴 20쌍', '남기는 수는 40쌍이다'),
    ('같은 40쌍으로', '재측정은 같은 쌍으로 한다'),
    ('blind_set_20.csv', '파일 이름은 a1_counts.json 의 blind_selected_filename 이다'),
    ('일곱 항목', 'verify-release 는 여덟 항목이다'),
    ('독립 작성자의 20쌍', '독립 작성자 쌍은 40쌍이다'),
]

# 파일을 읽지 못하는 곳에 적힌 숫자. 정규식이 안 맞으면 실패로 센다.
CLAIMS = [
    ('02_POC_A/blind_selector.html', r'var TARGET = (\d+), TYPE_MIN = (\d+);',
     ('blind_select', 'type_min')),
    ('02_POC_A/blind_set_generator_prompt.md', r'\*\*사회적 상황 쌍\(pair\)\*\* (\d+)~(\d+)개를 만든다',
     ('blind_request_min', 'blind_request_max')),
    ('02_POC_A/blind_set_generator_prompt.md', r'pair_id\s+B01 부터 B(\d+) 까지',
     ('blind_request_max',)),
    ('02_POC_A/blind_set_qc_checklist.md', r'받은 후보 (\d+)~(\d+)쌍에서 \*\*(\d+)쌍\*\*을 고른다',
     ('blind_request_min', 'blind_request_max', 'blind_select')),
    ('02_POC_A/blind_set_qc_checklist.md', r'## 전체에서 본다 · (\d+)쌍을 고르는 기준',
     ('blind_select',)),
    ('02_POC_A/blind_set_authoring_protocol.md', r'후보 (\d+)~(\d+)쌍을 받는다',
     ('blind_request_min', 'blind_request_max')),
    ('02_POC_A/blind_set_authoring_protocol.md', r'\d\. (\d+)쌍을 남긴다',
     ('blind_select',)),
    ('02_POC_A/blind_set_authoring_protocol.md', r'합쳐서 (\d+)쌍으로 POC A 를 돌린다',
     ('total_min',)),
    ('00_README/HUMAN_ACTIONS.md', r'## H-02 · blind (\d+)쌍 고르기',
     ('blind_select',)),
    ('00_README/HUMAN_ACTIONS.md', r'\*\*소요\*\* · (\d+)쌍에',
     ('total_min',)),
    ('02_POC_A/annotation_guideline_onepage.md', r'(\d+)쌍이면 세 시간에서 다섯 시간',
     ('total_min',)),
]

READERS = ['poc.py', '02_POC_A/randomize_pairs.py', 'tests/bundles.py']
SELECTOR = '02_POC_A/blind_selector.html'
SELECTOR_DL = r"dl\('([^']+\.csv)',\s*raterCsv\(\)\)"


def read(rel):
    return io.open(os.path.join(ROOT, rel), encoding='utf-8').read()


def load_counts():
    return json.loads(read(COUNTS_REL))


def walk():
    for d, dirs, files in os.walk(ROOT):
        dirs[:] = [x for x in dirs if x not in SKIP_DIRS]
        for f in files:
            if f.endswith(TEXT_EXT):
                yield os.path.relpath(os.path.join(d, f), ROOT).replace(os.sep, '/')


def check_interface(c, out):
    ok = True
    sel = read(SELECTOR)
    m = re.search(SELECTOR_DL, sel)
    want = c['blind_selected_filename']
    if not m:
        out.append(('1 인터페이스', False, '선별기에서 다운로드 파일 이름을 찾지 못했다'))
        ok = False
    elif m.group(1) != want:
        out.append(('1 인터페이스', False, '선별기 %s · a1_counts %s' % (m.group(1), want)))
        ok = False
    else:
        out.append(('1 인터페이스', True, '선별기 = a1_counts · %s' % want))
    for rel in READERS:
        if 'a1_counts.json' not in read(rel):
            out.append(('1 인터페이스', False, '%s 가 a1_counts.json 을 읽지 않는다' % rel))
            ok = False
    if ok:
        out.append(('1 인터페이스', True, '읽는 쪽 %d개가 a1_counts.json 을 읽는다' % len(READERS)))
    return ok


def check_claims(c, out):
    ex = c['rc1_execution']
    bad = []
    for rel, rx, keys in CLAIMS:
        m = re.search(rx, read(rel))
        if not m:
            bad.append('%s · 문장이 없다 · %s' % (rel, rx[:40]))
            continue
        for i, k in enumerate(keys):
            got = int(m.group(i + 1))
            if got != ex[k]:
                bad.append('%s · %s 가 %d · a1_counts %d' % (rel, k, got, ex[k]))
    out.append(('2 등록 숫자', not bad, '%d개 문장 · 어긋남 %d' % (len(CLAIMS), len(bad))))
    return bad


# ERR-06 · 옛 판 A1 시뮬레이션 값. 문장 목록만으로는 새 표현을 놓친다.
# 실제로 이 꾸러미 안에서 두 곳을 놓쳤다. 하나는 파일 단위 면제 뒤에 숨어 있었다.
# 그래서 문장이 아니라 값과 맥락으로도 본다. 지금 값은 FINAL_CLOSURE 쪽 JSON 이 정본이다.
OLD_SIM_VALUES = (0.13, 0.81, 0.58, 0.90, 0.63, 0.28, 0.37)
SIM_CONTEXT = ('시뮬레이션', '문턱 주장', '문턱 초과', 'κ참값', '참 일치', 'A1_SAMPLE_SIZE', 'P(하한')
NUM_RX = re.compile(r'(?<![\d.])(\d\.\d+)(?![\d])')


def stale_by_value(line):
    """옛 값이 시뮬레이션 얘기를 하는 줄에 있으면 잡는다.
    훈련 81% 는 소수가 아니라 안 걸리고, AUC 0.58 은 맥락 낱말이 없어 안 걸린다."""
    if not any(w in line for w in SIM_CONTEXT):
        return []
    return [t for t in NUM_RX.findall(line)
            if any(abs(float(t) - o) < 1e-9 for o in OLD_SIM_VALUES)]


def check_stale(out):
    """줄 단위로 본다. 규격 v0.1 값을 일부러 인용하는 줄은 count-ok 표시로 넘긴다.

    bundles.py 의 leakcheck-ok 와 같은 방식이다. 면제 수를 항상 화면에 찍는다."""
    hits, exempt_files, exempt_lines = [], [], []
    for rel in walk():
        base = os.path.basename(rel)
        text = io.open(os.path.join(ROOT, rel), encoding='utf-8', errors='replace').read()
        # 문장 목록에만 기대면 새로운 표현을 놓친다. 값으로도 보므로 미리 건너뛰지 않는다
        if not any(p in text for p, _ in STALE) and not any(w in text for w in SIM_CONTEXT):
            continue
        if rel in EXEMPT or base == SELF_NAME:
            exempt_files.append((rel, EXEMPT.get(rel, '옛 문장 목록을 들고 있는 이 검사 자신')))
            continue
        for i, line in enumerate(text.split('\n'), 1):
            marked = LINE_MARK in line
            for p, why in STALE:
                if p not in line:
                    continue
                if marked:
                    exempt_lines.append('%s:%d' % (rel, i))
                else:
                    hits.append('%s:%d · "%s" · %s' % (rel, i, p, why))
            vals = stale_by_value(line)
            if vals:
                if marked:
                    exempt_lines.append('%s:%d (값)' % (rel, i))
                else:
                    hits.append('%s:%d · 값 %s · 시뮬레이션 맥락인데 옛 판 값이다 · ERR-06'
                                % (rel, i, ' · '.join(vals)))
    out.append(('3 옛 문장', not hits,
                '남은 것 %d · 면제 파일 %d · 면제 줄 %d' % (len(hits), len(exempt_files), len(exempt_lines))))
    return hits, exempt_files, exempt_lines


def check_arith(c, out):
    ex = c['rc1_execution']
    rules = [
        (ex['type_min'] * ex['type_count'] <= ex['blind_select'], '유형 최소 x 유형 수 <= 선별 수'),
        (ex['blind_request_min'] >= ex['blind_select'], '의뢰 최소 >= 선별 수'),
        (ex['blind_request_min'] <= ex['blind_request_max'], '의뢰 최소 <= 의뢰 최대'),
        (ex['existing_synthetic'] + ex['blind_select'] == ex['total_min'], '합성 + 선별 = 최소 합계'),
        (ex['total_min'] % ex['session_chunk'] == 0, '최소 합계가 묶음 크기로 나뉜다'),
    ]
    bad = [why for ok, why in rules if not ok]
    out.append(('4 산술', not bad, '%d개 규칙 · 어긋남 %d' % (len(rules), len(bad))))
    return bad


def main():
    c = load_counts()
    out = []
    check_interface(c, out)
    claim_bad = check_claims(c, out)
    stale, exempt_files, exempt_lines = check_stale(out)
    arith_bad = check_arith(c, out)

    print('=' * 60)
    print('  숫자 · 인터페이스 일치 검사')
    print('=' * 60)
    for name, ok, detail in out:
        print('  %-12s %s %s' % (name, 'ok' if ok else 'X ', detail))
    for b in claim_bad:
        print('    등록 숫자 ·', b)
    for h in stale[:40]:
        print('    옛 문장 ·', h)
    if len(stale) > 40:
        print('    ... 외 %d' % (len(stale) - 40))
    for b in arith_bad:
        print('    산술 ·', b)
    print()
    print('  면제 파일 %d · 옛 숫자를 가져도 되는 파일' % len(exempt_files))
    for rel, why in exempt_files:
        print('    %s · %s' % (rel, why))
    if exempt_lines:
        print('  면제 줄 %d · 규격 v0.1 값을 일부러 인용한 줄' % len(exempt_lines))
        for x in exempt_lines:
            print('    %s' % x)
    print()
    print('  규격 v0.1 blind %d쌍 · RC1 실행 blind %d쌍 · 차이는 a1_counts.json deviation_from_spec'
          % (c['frozen_spec_v0_1']['blind'], c['rc1_execution']['blind_select']))
    failed = any(not ok for _, ok, _ in out)
    print('  판정 ·', '실패' if failed else '통과')
    return 1 if failed else 0


if __name__ == '__main__':
    sys.exit(main())
