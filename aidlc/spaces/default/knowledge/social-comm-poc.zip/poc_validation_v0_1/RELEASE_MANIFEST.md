# RELEASE MANIFEST

생성 2026-09-14 12:45:27 · `tests/make_manifest.py`

> **모든 숫자는 이 파일을 만들 때 직접 센 값이다.**
> 어떤 수도 다른 문서에서 옮겨 적지 않았다.
> 내역의 합이 총계와 맞는지 기계가 확인하고, 안 맞으면 생성이 실패한다.

## 총계

| | 값 |
|---|---|
| **배포 파일** | **99** |
| 바이트 | 1,045,355 |
| 빌드 환경의 캐시 · 배포하지 않음 | 7 |

### zip 안의 파일 수와 맞춰 본다

```
배포 파일                         99
이 매니페스트 자신 세 개        +   3
                                ----
패키지 폴더 안                   102
RC1_HANDOFF_FINAL.html · 표지 +   1
                                ----
zip 안의 파일                    103
```

표지는 패키지 폴더 밖에 두고 zip 최상위에만 싣는다. 안에 넣으면 표지를 고칠 때마다 파일 수가 바뀌고 그 수가 표지에 적혀 있다.

빌드 환경에 캐시 7개가 있었고 **files 배열에도 zip 에도 들어가지 않았다.** 목록은 `cache_excluded` 에 남긴다. 캐시를 목록에 남기면 매니페스트와 archive 가 어긋난다(RC1 ERR-03).

세지 않은 것이 둘이다.

- `dist/` · 이 패키지에서 파생된 사본이다
- `RELEASE_MANIFEST.json` · `.md` · `SHA256SUMS.txt` · 이 파일들 자신이다.
  세면 돌릴 때마다 총계가 바뀌고, 그 총계를 담은 파일이 다시 총계를 바꾼다

## 폴더별

| 폴더 | 파일 |
|---|---|
| `(최상위)` | 4 |
| `00_README` | 4 |
| `01_SPEC` | 3 |
| `02_POC_A` | 33 |
| `03_POC_C` | 22 |
| `04_POC_B_SCAFFOLD` | 12 |
| `05_EXPERT_REVIEW` | 3 |
| `06_FINAL` | 3 |
| `tests` | 15 |
| **합** | **99** |

## 분류별

| 분류 | 파일 |
|---|---|
| doc | 38 |
| data | 17 |
| source | 17 |
| test | 13 |
| demo_result | 8 |
| data_restricted | 4 |
| test_output | 2 |
| **합** | **99** |

## 확장자별

| 확장자 | 파일 |
|---|---|
| `.md` | 36 |
| `.py` | 23 |
| `.csv` | 15 |
| `.json` | 14 |
| `.html` | 5 |
| `.txt` | 5 |
| `.log` | 1 |
| **합** | **99** |

## 합이 맞는가

| 확인 | 결과 |
|---|---|
| 분류별 합 = 총계 | 맞음 |
| 폴더별 합 = 총계 | 맞음 |
| 확장자별 합 = 총계 | 맞음 |
| files 배열에 캐시 없음 | 맞음 |

## 전체 파일

| 경로 | 바이트 | 분류 | sha256 앞 16 |
|---|---|---|---|
| `00_README/HUMAN_ACTIONS.md` | 4,832 | doc | `c679ed98b17c9205` |
| `00_README/ISSUES_FOR_V0_2.md` | 9,327 | doc | `2393c4f91ed5de5e` |
| `00_README/README.md` | 5,374 | doc | `85ca927b95579223` |
| `00_README/RUNBOOK.md` | 3,428 | doc | `a2945d0c2d8dfccd` |
| `01_SPEC/decision_rules_machine_readable.json` | 10,983 | data | `93b32b4e1b650767` |
| `01_SPEC/frozen_spec_summary.md` | 3,743 | doc | `144fa909b6717cd4` |
| `01_SPEC/frozen_spec_v0_1.html` | 106,821 | doc | `64f5ec1e1fa8c170` |
| `02_POC_A/POC_A_result_template.md` | 2,076 | doc | `9896f13ad36a67e5` |
| `02_POC_A/_gold/existing_synthetic_20_SPEC_EXPECTED.csv` | 2,076 | data_restricted | `9b26dbac994734d5` |
| `02_POC_A/_incoming/BLIND_CANDIDATE_STATUS.md` | 2,478 | doc | `ac7154988c01eb5c` |
| `02_POC_A/_incoming/PROVENANCE.md` | 3,492 | doc | `2e8c1a7e333632ed` |
| `02_POC_A/_incoming/PROVENANCE_batch2.md` | 4,581 | doc | `772e1ceb96b16b14` |
| `02_POC_A/_incoming/blind_candidates_all.csv` | 60,272 | data_restricted | `7ecef4e13d6e3ab7` |
| `02_POC_A/_incoming/blind_candidates_raw.csv` | 28,025 | data_restricted | `f134af2d3fe11b93` |
| `02_POC_A/_incoming/blind_candidates_raw_2.csv` | 32,329 | data_restricted | `bef29cb7afbf7dae` |
| `02_POC_A/a1_counts.json` | 1,572 | data | `8aad3aa6b573f032` |
| `02_POC_A/analyze_agreement.py` | 28,217 | source | `5ee512effa73cda7` |
| `02_POC_A/annotation_form.csv` | 1,115 | data | `491c23390ba57239` |
| `02_POC_A/annotation_form.json` | 5,827 | data | `b1d80a45925a1e37` |
| `02_POC_A/annotation_guideline_onepage.md` | 7,102 | doc | `93ac809da6fcc4fc` |
| `02_POC_A/blind_selector.html` | 23,505 | doc | `0c6da5d0e1e4169f` |
| `02_POC_A/blind_set_authoring_protocol.md` | 2,743 | doc | `63ab38eb0a2e48c8` |
| `02_POC_A/blind_set_generator_prompt.md` | 4,528 | doc | `0f772462f19a5e38` |
| `02_POC_A/blind_set_qc_checklist.md` | 2,406 | doc | `3e7b60df4be7d7d8` |
| `02_POC_A/check_blind_format.py` | 3,856 | source | `ba17f35e67f967f3` |
| `02_POC_A/check_blind_overlap.py` | 3,590 | source | `0d262b5e0f405663` |
| `02_POC_A/existing_synthetic_20.csv` | 1,575 | data | `842b438ee71a6747` |
| `02_POC_A/extract_synthetic_20.py` | 2,714 | source | `aef620eda89a1807` |
| `02_POC_A/make_forms.py` | 4,614 | source | `b1cbf3cac17ad8f2` |
| `02_POC_A/make_sample_ratings.py` | 4,111 | source | `7c30252b517cde10` |
| `02_POC_A/merge_blind_batches.py` | 2,745 | source | `3f8320ac5c6dd21a` |
| `02_POC_A/randomization_plan.md` | 1,982 | doc | `5016da35a79dc7e4` |
| `02_POC_A/randomize_pairs.py` | 5,356 | source | `a5c33144668738cd` |
| `02_POC_A/rater_app.html` | 29,940 | source | `aa469cf4cc32872d` |
| `02_POC_A/results_demo/agreement_report.json` | 8,966 | demo_result | `d6ec6e050f748ff1` |
| `02_POC_A/results_demo/agreement_report.txt` | 7,548 | demo_result | `6cc1040b8972e66f` |
| `02_POC_A/results_demo/disagreements.csv` | 2,017 | demo_result | `3ae05a14542cd256` |
| `02_POC_A/rule_engine.py` | 4,198 | source | `f919921befaf201a` |
| `02_POC_A/sample_rater_A.csv` | 1,890 | data | `0ea61d7743196698` |
| `02_POC_A/sample_rater_B.csv` | 2,056 | data | `c733501baa3ae349` |
| `03_POC_C/POC_C_result_template.md` | 3,090 | doc | `e14b0ae21e6f3c07` |
| `03_POC_C/PRIVACY_TEST_RESULT.md` | 11,937 | doc | `c88a2571e35af9c8` |
| `03_POC_C/analyze_pilot.py` | 12,348 | source | `20dc7b0e10a553dc` |
| `03_POC_C/clarification_rules.json` | 4,037 | data | `992bd9d47749c4c5` |
| `03_POC_C/consent_draft.md` | 2,880 | doc | `266e3595bf650542` |
| `03_POC_C/followup_24_72h.md` | 2,250 | doc | `6341ba1a5350a1f7` |
| `03_POC_C/intake_prototype.html` | 23,965 | source | `05f9cdcab2584d7f` |
| `03_POC_C/intake_questions.md` | 4,335 | doc | `3bdb1bac2f51e445` |
| `03_POC_C/make_synthetic_events.py` | 4,049 | source | `b0cd5f58b1df3444` |
| `03_POC_C/participant_instruction.md` | 2,181 | doc | `5dc8838a87ea0aa4` |
| `03_POC_C/personal_pattern.py` | 7,769 | source | `1e9b2b90f33d47f0` |
| `03_POC_C/personal_social_event.schema.json` | 12,895 | data | `ad35377a807c9c1d` |
| `03_POC_C/pii_redaction_rules.md` | 2,508 | doc | `0c514f6e6ac6cafc` |
| `03_POC_C/pilot_protocol.md` | 3,220 | doc | `7d2f1c7dee698ee0` |
| `03_POC_C/privacy_test.html` | 16,389 | doc | `80115267c0df6a8e` |
| `03_POC_C/privacy_test_cases.json` | 13,889 | data | `65f54e265cc6e29b` |
| `03_POC_C/results_demo/pilot_report.json` | 3,257 | demo_result | `ff517f5e3b9fa1ff` |
| `03_POC_C/results_demo/pilot_report.txt` | 2,927 | demo_result | `7ae0ac6a0d565dbb` |
| `03_POC_C/retention_deletion_policy_draft.md` | 1,876 | doc | `fe58f8eb1cf42842` |
| `03_POC_C/synthetic_events.csv` | 1,587 | data | `b327a5724ff2e1b8` |
| `03_POC_C/synthetic_events.json` | 11,488 | data | `9b55ab6ac20006df` |
| `03_POC_C/synthetic_followups.csv` | 831 | data | `152548bef3fa504b` |
| `04_POC_B_SCAFFOLD/BLOCKED_UNTIL_A_PASS.md` | 1,403 | doc | `5b8e75ee0ec26b5a` |
| `04_POC_B_SCAFFOLD/POC_B_result_template.md` | 1,867 | doc | `ca6bff096c1fa8c6` |
| `04_POC_B_SCAFFOLD/b_output/generation_output.json` | 166,512 | demo_result | `0162a7cf7b1a27ef` |
| `04_POC_B_SCAFFOLD/generation_harness.py` | 11,193 | source | `bbe8930e9e0a3229` |
| `04_POC_B_SCAFFOLD/generator_prompt.md` | 3,827 | doc | `4096742affe8e500` |
| `04_POC_B_SCAFFOLD/human_evaluation_form.csv` | 3,417 | data | `a4a0a6f7700242e0` |
| `04_POC_B_SCAFFOLD/preservation_metrics.py` | 10,679 | source | `49cd852ded829efd` |
| `04_POC_B_SCAFFOLD/results_demo/preservation_report.json` | 3,418 | demo_result | `81248249c9a35d58` |
| `04_POC_B_SCAFFOLD/results_demo/preservation_report.txt` | 2,565 | demo_result | `e65b2fd9788f182c` |
| `04_POC_B_SCAFFOLD/sample_human_eval_DEMO.csv` | 6,777 | data | `eba723887976caee` |
| `04_POC_B_SCAFFOLD/seed_10.json` | 6,080 | data | `054f022cc31dc0a4` |
| `04_POC_B_SCAFFOLD/validator_prompt.md` | 2,664 | doc | `5b8102a440c52aba` |
| `05_EXPERT_REVIEW/expert_questions.md` | 3,050 | doc | `bf79119819e8ecaf` |
| `05_EXPERT_REVIEW/expert_review_packet.md` | 3,130 | doc | `7db2bd2f80617a2a` |
| `05_EXPERT_REVIEW/review_response_template.csv` | 166 | data | `9c40fdba81f532da` |
| `06_FINAL/NEXT_ACTIONS.md` | 1,047 | doc | `2a52dfedf1ac29a2` |
| `06_FINAL/POC_execution_dashboard.md` | 1,849 | doc | `419cda0925db836b` |
| `06_FINAL/decision_matrix.md` | 2,880 | doc | `c29390b778d3650a` |
| `KNOWN_ISSUES.md` | 3,750 | doc | `94d34786eba32d50` |
| `RELEASE_NOTES.md` | 2,433 | doc | `0a2506165b23ffb5` |
| `VERIFY_RELEASE.md` | 4,666 | doc | `60fc2d12823a7da9` |
| `poc.py` | 18,369 | source | `6aa089914eea3707` |
| `tests/ACTUAL_FILE_INVENTORY.csv` | 14,724 | test | `9c674467126e8959` |
| `tests/ACTUAL_FILE_INVENTORY.json` | 36,583 | test | `98dc6ff3a4eb4aef` |
| `tests/PHASE1_AUDIT_RAW.json` | 15,557 | test | `780476b758a028b3` |
| `tests/PHASE1_AUDIT_REPORT.md` | 9,406 | test | `c9060c2c91a97e7e` |
| `tests/PHASE1_TEST_RUN.log` | 1,297 | test | `36a12382a4442116` |
| `tests/audit.py` | 10,987 | test | `b18357838d1c849e` |
| `tests/audit_results.txt` | 827 | test_output | `d3db79041794a94e` |
| `tests/bundles.py` | 18,923 | test | `c6ef05324cf7bbc2` |
| `tests/consistency.py` | 12,919 | test | `284474f0ecccfb80` |
| `tests/make_manifest.py` | 13,652 | test | `1163c203ed6f6c2b` |
| `tests/make_release.py` | 16,890 | test | `cbb22143a26e3629` |
| `tests/phase1_audit.py` | 12,794 | test | `f1f1d330a52e40fb` |
| `tests/phase1_inventory.py` | 9,687 | test | `fb7f5d65b8e49184` |
| `tests/test_all.py` | 11,665 | test | `cdcb98f8715bf50f` |
| `tests/test_results.txt` | 3,984 | test_output | `b6ec2dfd33ac3134` |

전체 해시는 `SHA256SUMS.txt` 와 `RELEASE_MANIFEST.json` 에 있다.

```
sha256sum -c SHA256SUMS.txt
```

## checksum 적용 범위

집계와 checksum 은 서로 다른 것이다. 집계는 총계를 안정시키려고 자기 산출물을 빼고,
checksum 은 ZIP 에 실리는 일반 산출물을 전부 덮는다.

| | 수 |
|---|---|
| 집계 대상 · manifest-managed | 99 |
| checksum 적용 · SHA256-covered | **102** |

집계에 없지만 checksum 은 덮는 것

- `RELEASE_MANIFEST.json`
- `RELEASE_MANIFEST.md`
- `../RC1_HANDOFF_FINAL.html`

덮지 못한 것

| 파일 | 이유 |
|---|---|
| `SHA256SUMS.txt` | 자기 해시를 자기 안에 담을 수 없다. 보편적 제약이다 |

ZIP 안의 일반 산출물 중 checksum 밖에 있는 것은 `SHA256SUMS.txt` 하나뿐이다.
