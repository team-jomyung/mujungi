# -*- coding: utf-8 -*-
"""POC 실행 패키지 입구.

흩어진 스크립트를 한 자리에서 부른다. 새 기능은 없다.
RUNBOOK.md 에 적힌 명령을 그대로 감싼 것이고, 어느 명령을 돌렸는지 화면에 보여 준다.

  python poc.py status        지금 어디까지 됐나
  python poc.py test          시험 · 감사 · 누출 검사
  python poc.py bundles       역할별 꾸러미를 다시 만든다
  python poc.py prepare-a     A 를 위한 쌍 섞기와 양식 만들기
  python poc.py analyze-a     A 두 판정자 결과를 견준다
  python poc.py prepare-c     C 를 위한 연습용 사건 만들기
  python poc.py analyze-c     C 파일럿 결과를 본다
  python poc.py dryrun-b      B 를 모의로 돌린다. 실제 생성이 아니다
  python poc.py verify-release  배포물 검증 여덟 항목. 하나라도 실패하면 exit != 0

아무 명령도 이 파일에서 판정하지 않는다. 판정은 원래 스크립트가 한다.
"""

import argparse
import io
import os
import subprocess
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))
PY = sys.executable or 'python'

A = os.path.join(ROOT, '02_POC_A')
C = os.path.join(ROOT, '03_POC_C')
B = os.path.join(ROOT, '04_POC_B_SCAFFOLD')
T = os.path.join(ROOT, 'tests')


def a1_counts():
    """A1 쌍 수와 blind 파일 이름. 02_POC_A/a1_counts.json 한 곳에서만 정한다(ERR-05)."""
    import json
    return json.loads(io.open(os.path.join(A, 'a1_counts.json'), encoding='utf-8').read())


def blind_selected():
    """선별된 blind 파일 이름. 없으면 None. 옛 이름도 받는다."""
    c = a1_counts()
    for name in [c['blind_selected_filename']] + c.get('blind_selected_filename_legacy', []):
        if os.path.exists(os.path.join(A, name)):
            return name
    return None


def run(args, cwd=None, title=None):
    """한 명령을 돌리고 무엇을 돌렸는지 보여 준다."""
    where = cwd or ROOT
    shown = ' '.join(['python'] + [os.path.relpath(a, where) if os.path.isabs(a) else a
                                   for a in args])
    print()
    print('── ' + (title or shown))
    print('   %s   (%s)' % (shown, os.path.relpath(where, ROOT) or '.'))
    print()
    env = dict(os.environ)
    env['PYTHONIOENCODING'] = 'utf-8'
    r = subprocess.run([PY] + args, cwd=where, env=env)
    return r.returncode


def exists(*parts):
    return os.path.exists(os.path.join(*parts))


def count_files():
    n = 0
    for dp, dn, fn in os.walk(ROOT):
        dn[:] = [d for d in dn if d not in ('__pycache__', 'dist', '.git')]
        n += len(fn)
    return n


# ─────────────────────── status ───────────────────────

def cmd_status(_):
    print()
    print('POC 실행 패키지 · %s' % ROOT)
    print('파일 %d개 (캐시와 dist 제외)' % count_files())
    print()

    print('있어야 할 것')
    core = [
        ('규격 요약',        '01_SPEC/frozen_spec_summary.md'),
        ('규칙 엔진',        '02_POC_A/rule_engine.py'),
        ('일치도 분석',      '02_POC_A/analyze_agreement.py'),
        ('판정 도구',        '02_POC_A/rater_app.html'),
        ('blind 선별 도구',  '02_POC_A/blind_selector.html'),
        ('입력 시험판',      '03_POC_C/intake_prototype.html'),
        ('개인정보 시험',    '03_POC_C/privacy_test.html'),
        ('B 모의 장치',      '04_POC_B_SCAFFOLD/generation_harness.py'),
    ]
    for label, rel in core:
        print('  %-2s %-16s %s' % ('ok' if exists(ROOT, rel) else 'X', label, rel))

    print()
    print('사람이 해야 끝나는 것')
    cnt = a1_counts()
    ex = cnt['rc1_execution']
    bs = blind_selected()
    human = [
        ('H-01', '판정자 2명 확보',            None),
        ('H-02', 'blind 후보 %d~%d쌍에서 %d쌍 선별'
                 % (ex['blind_request_min'], ex['blind_request_max'], ex['blind_select']),
                 '02_POC_A/' + (bs or cnt['blind_selected_filename'])),
        ('H-04', '기관 검토',                  None),
        ('H-05', 'POC C 참가자 5~10명',        None),
    ]
    for code, label, rel in human:
        if rel is None:
            state = '확인 불가 · 사람이 안다'
        else:
            state = '됨' if exists(ROOT, rel) else '아직'
        print('  %-6s %-26s %s' % (code, label, state))

    print()
    print('다음에 돌릴 수 있는 것')
    if not bs:
        print('  선별된 blind 가 없다. 먼저 dist/blind_selector 를 넘긴다.')
        print('  그 전까지 prepare-a 는 기존 합성 %d쌍만으로 양식을 만든다. 공식 POC A 가 아니다.'
              % ex['existing_synthetic'])
    else:
        print('  python poc.py prepare-a')

    got = [f for f in ('rater_A_filled.csv', 'rater_B_filled.csv') if exists(A, f)]
    if len(got) == 2:
        print('  python poc.py analyze-a')
    else:
        print('  판정자 결과 %d/2 · analyze-a 는 아직' % len(got))

    print()
    print('DEMO 로만 있는 것')
    for label, rel in [('A 일치도', '02_POC_A/results_demo'),
                       ('C 파일럿', '03_POC_C/results_demo'),
                       ('B 보존',   '04_POC_B_SCAFFOLD/results_demo')]:
        if exists(ROOT, rel):
            print('  %-8s %s   ← 사람 판정이 아니다. 검증 결과로 읽지 않는다' % (label, rel))

    print()
    print('꾸러미')
    dist = os.path.join(ROOT, 'dist')
    if os.path.isdir(dist):
        for d in sorted(os.listdir(dist)):
            p = os.path.join(dist, d)
            if os.path.isdir(p):
                n = sum(len(f) for _, _, f in os.walk(p))
                print('  %-20s 파일 %d' % (d, n))
    else:
        print('  없다 · python poc.py bundles')
    print()
    return 0


# ─────────────────────── test ───────────────────────

def cmd_test(_):
    """네 검사를 돌린다. 단위 시험 · 문서 감사 · 누출 검사 · 숫자 일치.

    ERR-01 · 예전에는 dist 가 없으면 누출 검사를 건너뛰고도 '전체 · 통과' 에 exit 0 이었다.
    셋 중 하나가 안 돌았는데 초록이면 그것은 거짓이다.
    이제 건너뛴 검사가 있으면 판정이 '불완전' 이고 exit 2 로 나간다."""
    rc = 0
    rc |= run(['-W', 'ignore', os.path.join(T, 'test_all.py')], ROOT, '단위 시험')
    rc |= run([os.path.join(T, 'audit.py')], ROOT, '문서 감사')
    rc |= run([os.path.join(T, 'consistency.py')], ROOT, '숫자 · 인터페이스 일치')

    skipped = not os.path.isdir(os.path.join(ROOT, 'dist'))
    if skipped:
        print()
        print('── 누출 검사 · 건너뜀')
        print('   dist/ 가 없다. 검사가 돌지 않았다.')
    else:
        rc |= run([os.path.join(T, 'bundles.py'), 'check'], ROOT, '누출 검사')

    print()
    print('=' * 56)
    if rc:
        print('  전체 · 실패 있음 · 위를 본다')
        code = 1
    elif skipped:
        print('  전체 · 불완전 · 검사 중 하나가 돌지 않았다')
        code = 2
    else:
        print('  전체 · 통과')
        code = 0
    print('=' * 56)
    if skipped:
        print()
        print('  누출 검사가 돌게 하려면 먼저 · python poc.py bundles')
        print('  검사가 안 돈 것을 통과라고 부르지 않는다.')
    print()
    print('  통과는 짜 둔 시험을 통과했다는 뜻이다.')
    print('  POC 가 성공했다는 뜻이 아니다. 사람 판정은 아직 시작하지 않았다.')
    print()
    return code


def cmd_bundles(_):
    return run([os.path.join(T, 'bundles.py'), 'build'], ROOT, '역할별 꾸러미')


# ─────────────────────── verify-release ───────────────────────

def cmd_verify_release(args):
    """배포물 하나를 여덟 항목으로 검증한다. 하나라도 실패하면 exit != 0.

    받는 쪽이 이 한 줄만 돌리면 되게 하는 것이 목적이다."""
    import hashlib
    import json
    import zipfile

    steps, fails = [], []

    def step(name, ok, detail=''):
        steps.append((name, ok, detail))
        if not ok:
            fails.append(name)

    print()
    print('=' * 60)
    print('  RELEASE 검증 · 여덟 항목')
    print('=' * 60)

    # 1 체크섬
    sums = os.path.join(ROOT, 'SHA256SUMS.txt')
    if not os.path.exists(sums):
        step('1 체크섬', False, 'SHA256SUMS.txt 가 없다')
    else:
        ok = bad = miss = 0
        for line in io_lines(sums):
            h, _, rel = line.partition('  ')
            if not rel:
                continue
            p = os.path.join(ROOT, rel)
            if not os.path.exists(p):
                miss += 1
                continue
            if sha256_of(p) == h:
                ok += 1
            else:
                bad += 1
        step('1 체크섬', bad == 0 and miss == 0,
             '%d줄 · 맞음 %d · 다름 %d · 없음 %d' % (ok + bad + miss, ok, bad, miss))

    # 2 단위 시험
    step('2 단위 시험', run(['-W', 'ignore', os.path.join(T, 'test_all.py')],
                        ROOT, '2 단위 시험') == 0)

    # 3 문서 감사
    step('3 문서 감사', run([os.path.join(T, 'audit.py')], ROOT, '3 문서 감사') == 0)

    # 4 꾸러미 빌드 + 5 누출 검사 + 6 role ZIP
    build_rc = run([os.path.join(T, 'bundles.py'), 'build'], ROOT, '4 꾸러미 · 5 누출 검사')
    step('4 꾸러미 빌드', os.path.isdir(os.path.join(ROOT, 'dist')))
    step('5 누출 검사', build_rc == 0)

    dist = os.path.join(ROOT, 'dist')
    zips = sorted(f for f in os.listdir(dist) if f.endswith('.zip')) if os.path.isdir(dist) else []
    roles = sorted(d for d in os.listdir(dist)
                   if os.path.isdir(os.path.join(dist, d))) if os.path.isdir(dist) else []
    expected_zip = len([r for r in roles if r != 'admin'])
    step('6 역할 ZIP', len(zips) == expected_zip and expected_zip > 0,
         '역할 %d · ZIP %d · admin 제외' % (len(roles), len(zips)))

    # 7 매니페스트와 archive 의 파일 집합이 정확히 같은가
    zpath = args.zip or os.path.join(os.path.dirname(ROOT),
                                     os.path.basename(ROOT) + '_RC1.zip')
    manp = os.path.join(ROOT, 'RELEASE_MANIFEST.json')
    if not os.path.exists(zpath):
        # 못 돈 검사를 통과라고 부르지 않는다. ERR-01 과 같은 원칙이다
        step('7 매니페스트 = archive', False,
             'zip 을 찾지 못했다. --zip 으로 경로를 준다')
        print('      찾아본 곳 ·', zpath)
        print('      예 · python poc.py verify-release --zip ../poc_validation_v0_1_RC1.zip')
    elif not os.path.exists(manp):
        step('7 매니페스트 = archive', False, 'RELEASE_MANIFEST.json 이 없다')
    else:
        man = json.loads(io.open(manp, encoding='utf-8').read())
        listed = {f['path'] for f in man['files']}
        z = zipfile.ZipFile(zpath)
        pkg = os.path.basename(ROOT) + '/'
        inzip = {n[len(pkg):] for n in z.namelist() if n.startswith(pkg)}
        selfout = {'RELEASE_MANIFEST.json', 'RELEASE_MANIFEST.md', 'SHA256SUMS.txt'}
        only_man = sorted(listed - inzip)
        only_zip = sorted(inzip - listed - selfout)
        same = not only_man and not only_zip
        step('7 매니페스트 = archive', same,
             '매니페스트 %d · archive %d · 매니페스트에만 %d · archive에만 %d'
             % (len(listed), len(inzip), len(only_man), len(only_zip)))
        for p in only_man[:5]:
            print('      매니페스트에만 ·', p)
        for p in only_zip[:5]:
            print('      archive에만 ·', p)

    # 8 숫자와 인터페이스가 서로 말이 되는가 · ERR-04 · ERR-05
    # 체크섬은 파일이 온전한지만 본다. 의뢰문이 40쌍이든 60쌍이든 체크섬은 맞는다
    step('8 숫자 · 인터페이스', run([os.path.join(T, 'consistency.py')],
                                ROOT, '8 숫자 · 인터페이스 일치') == 0)

    print()
    print('=' * 60)
    for name, ok, detail in steps:
        print('  %-24s %s %s' % (name, 'ok' if ok else 'X ', detail))
    print('=' * 60)
    if fails:
        print('  실패 %d항목 · %s' % (len(fails), ' · '.join(fails)))
    else:
        print('  여덟 항목 전부 통과')
        print()
        print('  통과해도 POC 는 아무것도 검증하지 않았다. 도구가 온전하다는 뜻뿐이다.')
    print()
    return 1 if fails else 0


def io_lines(path):
    with io.open(path, encoding='utf-8') as f:
        for line in f:
            line = line.rstrip('\n')
            if line.strip():
                yield line


def sha256_of(path):
    import hashlib
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(65536), b''):
            h.update(chunk)
    return h.hexdigest()


# ─────────────────────── A ───────────────────────

def cmd_prepare_a(args):
    cnt = a1_counts()
    if not blind_selected():
        print()
        print('[경고] %s 가 없다.' % cnt['blind_selected_filename'])
        print('       기존 합성 %d쌍만으로 양식을 만든다. 이것은 공식 POC A 가 아니다.'
              % cnt['rc1_execution']['existing_synthetic'])
        print('       선별된 blind %d쌍은 dist/blind_selector 를 사람에게 넘겨야 나온다.'
              % cnt['rc1_execution']['blind_select'])
    rc = run(['randomize_pairs.py'] + (['--different-order'] if args.different_order else []),
             A, '쌍 섞기')
    if rc:
        return rc
    rc = run(['make_forms.py', '--pairs', 'randomized_pairs.csv'], A, '판정 양식')
    if rc:
        return rc
    return run([os.path.join(T, 'bundles.py'), 'build'], ROOT, '꾸러미 다시 만들기')


def cmd_analyze_a(args):
    a, b = args.rater_a, args.rater_b
    for p in (a, b):
        if not os.path.exists(os.path.join(A, p)) and not os.path.exists(p):
            print('없는 파일 · %s' % p)
            print('판정자가 rater_app.html 에서 내보낸 CSV 를 02_POC_A 에 둔다.')
            return 2
    cmd = ['analyze_agreement.py', a, b, '--out', args.out]
    if args.key:
        cmd += ['--key', args.key]
    return run(cmd, A, '일치도')


# ─────────────────────── C ───────────────────────

def cmd_prepare_c(_):
    print()
    print('연습용 사건을 만든다. 참가자 자료가 아니다.')
    return run(['make_synthetic_events.py'], C, '연습용 사건')


def cmd_analyze_c(args):
    cmd = ['analyze_pilot.py', args.events]
    if args.followup:
        cmd += ['--followup', args.followup]
    cmd += ['--out', args.out]
    return run(cmd, C, 'C 파일럿')


# ─────────────────────── B ───────────────────────

def cmd_dryrun_b(_):
    print()
    print('=' * 56)
    print('  이것은 모의 실행이다. 실제 생성이 아니다.')
    print('  EchoProvider 는 입력을 그대로 돌려준다. 품질을 재지 않는다.')
    print('  POC B 는 A 가 통과한 뒤에 시작한다.')
    print('=' * 56)
    rc = run(['generation_harness.py', '--provider', 'echo'], B, 'B 모의 생성')
    if rc:
        return rc
    return run(['preservation_metrics.py', 'sample_human_eval_DEMO.csv',
                '--generation', 'b_output/generation_output.json',
                '--out', 'results_dryrun'], B, 'B 보존 지표 · DEMO 입력')


# ─────────────────────── 입구 ───────────────────────

def main():
    ap = argparse.ArgumentParser(
        prog='poc.py', description='POC 실행 패키지 입구',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='어느 명령도 판정하지 않는다. 원래 스크립트를 부를 뿐이다.')
    sub = ap.add_subparsers(dest='cmd')

    sub.add_parser('status', help='지금 어디까지 됐나')
    sub.add_parser('test', help='시험 · 감사 · 누출 검사')
    sub.add_parser('bundles', help='역할별 꾸러미와 role ZIP 을 만든다')

    p = sub.add_parser('verify-release', help='배포물을 여덟 항목으로 검증한다')
    p.add_argument('--zip', default=None, help='검증할 zip 경로. 생략하면 상위 폴더에서 찾는다')

    p = sub.add_parser('prepare-a', help='쌍 섞기와 양식 만들기')
    p.add_argument('--different-order', action='store_true', default=True,
                   help='판정자마다 순서를 다르게 한다. 기본값')

    p = sub.add_parser('analyze-a', help='두 판정자 결과를 견준다')
    p.add_argument('rater_a', nargs='?', default='rater_A_filled.csv')
    p.add_argument('rater_b', nargs='?', default='rater_B_filled.csv')
    p.add_argument('--out', default='results')
    p.add_argument('--key', default=None,
                   help='_gold/randomization_key.csv · 판정이 끝난 뒤에만 쓴다')

    sub.add_parser('prepare-c', help='연습용 사건 만들기')

    p = sub.add_parser('analyze-c', help='C 파일럿 결과')
    p.add_argument('events', nargs='?', default='synthetic_events.csv')
    p.add_argument('--followup', default='synthetic_followups.csv')
    p.add_argument('--out', default='results')

    sub.add_parser('dryrun-b', help='B 모의 실행. 실제 생성이 아니다')

    args = ap.parse_args()
    if not args.cmd:
        ap.print_help()
        print()
        return cmd_status(args)

    fn = {
        'status': cmd_status, 'test': cmd_test, 'bundles': cmd_bundles,
        'prepare-a': cmd_prepare_a, 'analyze-a': cmd_analyze_a,
        'prepare-c': cmd_prepare_c, 'analyze-c': cmd_analyze_c,
        'verify-release': cmd_verify_release,
        'dryrun-b': cmd_dryrun_b,
    }[args.cmd]
    return fn(args)


if __name__ == '__main__':
    sys.exit(main())
