# 다음 행동

## 오늘 · 사람만 할 수 있는 것

1. **판정자 두 명 섭외** · H-01 · A 를 막고 있다
2. **blind 후보 80쌍에서 40쌍 고르기** · H-02 · 고르는 사람은 판정자가 될 수 없다
3. **C 참가자 모집 시작** · H-05 · 사흘 이상 걸리므로 가장 먼저

## 1·2 가 끝나면 · 명령 두 줄

```bash
cd poc_validation_v0_1/02_POC_A
python randomize_pairs.py
python make_forms.py --pairs randomized_pairs.csv
```

그다음 판정자에게 셋만 준다 · `annotation_guideline_onepage.md` · `randomized_pairs.csv` · `annotation_form.csv`

## 판정이 돌아오면

```bash
python analyze_agreement.py rater_A_filled.csv rater_B_filled.csv --out results
```

`POC_A_result_template.md` 를 채우고 `06_FINAL/decision_matrix.md` 로 간다.

## 하지 말 것

- v0.1 규격 파일을 고치는 것
- `--demo` 나 `--dry-run` 수치를 결과로 적는 것
- A 통과 전에 B 를 시작하는 것
- `_gold/` 를 판정자에게 주는 것
- 빈 칸에 가짜 값을 넣는 것
