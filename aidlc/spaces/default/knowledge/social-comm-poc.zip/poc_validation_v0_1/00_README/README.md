# POC Validation Package · v0.1

**이 파일 하나만 읽고 다음 행동을 알 수 있게 만들었다.**

---

## 지금 상태 한 줄

> 규격은 동결됐고, 판정 도구와 분석 코드는 돌아간다.
> **막힌 곳은 사람 셋이다.** 판정자 2명과 blind set QC 1명.

| | |
|---|---|
| 규격 | `01_SPEC/frozen_spec_v0_1.html` · **FROZEN · 고치지 않는다** |
| POC A | 실행 가능. **사람 대기** |
| POC C | 실행 가능. **참가자 대기** |
| POC B | **차단됨.** A 통과 전 시작 금지 |
| 자동 시험 | 34/34 통과 |

---

## 내일 아침 첫 세 가지

1. **판정자 두 명을 구한다.** 규격 작업에 참여하지 않은 사람. `00_README/HUMAN_ACTIONS.md` H-01
2. **blind 후보 80쌍에서 40쌍을 고른다.** `02_POC_A/_incoming/blind_candidates_all.csv` · 고르는 사람은 판정자가 될 수 없다. H-02
3. **POC C 참가자 모집을 시작한다.** 모집과 동의에 시간이 걸리고 3일 간격 재질문이 필요하다. H-05

세 번째를 먼저 시작해도 된다. **C 는 A·B 와 독립이다.**

---

## 폴더 지도

```
00_README/          여기부터
  README.md           이 파일
  RUNBOOK.md          날짜순 실행 절차
  HUMAN_ACTIONS.md    사람이 해야만 하는 것 목록
  ISSUES_FOR_V0_2.md  발견한 문제. 지금 고치지 않는다

01_SPEC/            동결된 규격
  frozen_spec_v0_1.html              원본. 고치지 않는다
  frozen_spec_summary.md             한 장 요약
  decision_rules_machine_readable.json  규칙을 기계가 읽는 형태로

02_POC_A/           규격 재현성 · 실행 가능
  annotation_guideline_onepage.md    판정자가 읽는 것. 이것만 준다
  randomized_pairs.csv               판정자가 보는 문제 (선별 전에는 합성 20쌍뿐 · 선별 후 60쌍)
  a1_counts.json                     쌍 수와 blind 파일 이름의 유일한 출처
  annotation_form.csv / .json        판정지 빈 양식
  _incoming/blind_candidates_all.csv 격리 작성자 둘이 따로 낸 후보 80쌍 (두 묶음)
  _gold/                             정답·대조표. 판정 끝나기 전 열지 않는다
  rule_engine.py                     규격 규칙 엔진
  analyze_agreement.py               κ 계산과 판정
  results_demo/                      DEMO 실행 결과. 검증 결과 아님

03_POC_C/           사건 수집 파일럿 · 실행 가능
  pilot_protocol.md                  절차
  consent_draft.md                   동의서 초안. 기관 검토 필요
  participant_instruction.md         참여자 안내
  intake_prototype.html              브라우저에서 바로 도는 입력 화면
  personal_social_event.schema.json  저장 구조
  clarification_rules.json           언제 묻고 언제 UNKNOWN 인가
  pii_redaction_rules.md             개인정보 규칙
  personal_pattern.py                사건 기반 집계
  analyze_pilot.py                   결과 분석

04_POC_B_SCAFFOLD/  구조 보존 · 차단됨
  BLOCKED_UNTIL_A_PASS.md            ← 먼저 읽는다
  generator_prompt.md / validator_prompt.md
  generation_harness.py              provider adapter. 키는 환경변수
  preservation_metrics.py

05_EXPERT_REVIEW/   A 결과 나온 뒤 전문가에게
06_FINAL/           대시보드 · 의사결정 표 · 다음 행동
tests/              34개 시험 · test_results.txt
```

---

## 바로 돌려 볼 수 있는 것

```bash
cd poc_validation_v0_1

# 자동 시험
python tests/test_all.py

# POC A 분석 · DEMO 데이터로
cd 02_POC_A
python make_sample_ratings.py
python analyze_agreement.py sample_rater_A.csv sample_rater_B.csv --out results_demo --demo

# POC C 분석 · DEMO 데이터로
cd ../03_POC_C
python make_synthetic_events.py
python analyze_pilot.py synthetic_events.csv --followup synthetic_followups.csv --out results_demo --demo

# POC C 입력 화면 · 브라우저에서 파일 열기
#   03_POC_C/intake_prototype.html

# POC B 배관 확인 · 모델 호출 없음
cd ../04_POC_B_SCAFFOLD
python generation_harness.py --dry-run
```

**`--demo` 와 `--dry-run` 으로 낸 수치는 검증 결과가 아니다.** 출력에 그렇게 표시된다.

---

## 신뢰구간 계산 방법

`analyze_agreement.py` 의 95% CI 는 **percentile bootstrap** 이다.

| | |
|---|---|
| 반복 | 2,000 |
| seed | 20260912 |
| 방식 | 쌍 단위 복원추출 후 κ 재계산, 2.5 / 97.5 분위 |
| 계산 불가 시 | 숫자를 만들지 않고 `NA` 와 사유를 적는다 |

**bootstrap 표본의 절반 이상에서 κ 가 정의되지 않으면 CI 를 내지 않는다.**

---

## 이 패키지가 지키는 선

- **LLM 판정을 정답으로 쓰지 않는다.** A 의 판정자는 사람 2명, B 의 최종 기준도 사람
- **synthetic annotation test set 을 validation dataset 이라고 부르지 않는다**
- **Core 는 다섯이다.** 늘리거나 줄이지 않는다
- **Skill Identity 와 Transfer Distance 를 한 통계로 섞지 않는다**
- **user_goal 이 UNKNOWN 인 것은 오류가 아니다**
- **상대의 의도를 확정 문장으로 출력하지 않는다**
- **제3자 개인정보를 저장하지 않는다**
- **운영 기준 문턱을 문헌 근거처럼 적지 않는다.** 외부 준거가 있는 것은 κ 0.6 하나뿐
- **임상 효과나 SCD 개선을 주장하지 않는다**
