# RUNBOOK · 실행 순서

날짜는 상대적이다. D0 는 시작하는 날.

---

## D0 · 준비

| | 누가 | 무엇 |
|---|---|---|
| 1 | 전원 | `01_SPEC/frozen_spec_v0_1.html` 을 연다. **동결 상태임을 확인한다** |
| 2 | 리드 | 판정자 2명 섭외 · **H-01** |
| 3 | 리드 | blind 후보 80쌍에서 40쌍 고르기 · **H-02** |
| 4 | 리드 | `python 02_POC_A/randomize_pairs.py` |
| 5 | 리드 | `python 02_POC_A/make_forms.py --pairs 02_POC_A/randomized_pairs.csv` |
| 6 | 리드 | 기관 검토 확인 · **H-04** |
| 7 | 리드 | C 참가자 모집 시작 · **H-05** |

**확인** · `randomized_pairs.csv` 에 `origin` 열이 없는가. 40행인가. `_gold/` 를 판정자에게 주지 않았는가.

---

## D1 · A 배포 · C 시작

**POC A**

판정자 두 명에게 각각 셋만 준다.

```
annotation_guideline_onepage.md
randomized_pairs.csv
annotation_form.csv
```

말해 줄 것 · "정답은 없습니다. 규칙대로 읽으면 나오는 답을 적어 주세요. **모르겠다는 정당한 답입니다.** 다른 분과 상의하지 마세요."

**POC C**

동의서 받고 `intake_prototype.html` 로 최초 입력. 1인 2~3건. **시작 시각을 기록한다.**

---

## D2 · A 회수와 계산

```bash
cd 02_POC_A
python analyze_agreement.py rater_A_filled.csv rater_B_filled.csv --out results
```

나오는 것 · `agreement_report.txt` · `.json` · `disagreements.csv`

**H-03** · 기존 20 / blind 20 의 κ 를 따로 내어 비교한다.

`POC_A_result_template.md` 를 채운다.

---

## D2 분기

### PASS

1. `04_POC_B_SCAFFOLD/BLOCKED_UNTIL_A_PASS.md` 를 `UNBLOCKED_<날짜>.md` 로 바꾸고 A 요약을 적는다
2. **H-07** provider 연결
3. `python generation_harness.py --provider <이름>` 으로 90개 생성
4. 생성 목표를 가리고 섞어 사람에게 판정시킨다 · `human_evaluation_form.csv`
5. `python preservation_metrics.py <채운 파일> --generation b_output/generation_output.json --out results`

### RETRY

1. `disagreements.csv` 와 필드 κ 를 본다
2. 가장 많이 갈린 필드를 **더 좁은 이분 질문으로 쪼갠다**
3. **v0.2 후보를 `ISSUES_FOR_V0_2.md` 에 적는다.** 규격을 바로 고치지 않는다
4. 같은 쌍으로 **1회만** 재측정
5. **POC B 를 시작하지 않는다**

### FAIL

1. 구조 동등성 핵심 가설을 재검토한다
2. 불일치가 한 필드에 몰렸다면 그 필드가 **사람이 답할 수 없는 질문**일 가능성을 본다
3. **H-08** 전문가 검토를 앞당긴다
4. **POC B 를 시작하지 않는다**

---

## D3~D4 · C 후속

최초 입력에서 **24~72시간 사이**에 한 번만.

`followup_24_72h.md` 대로. **처음 답을 보여주지 않는다.** 관계와 목표 둘만.

```bash
cd 03_POC_C
python analyze_pilot.py events.csv --followup followups.csv --out results
```

**중단 트리거** · goal 불일치가 절반을 넘으면 멈추고 설계를 다시 본다.

---

## D5 이후

1. A · B · C 결과를 `06_FINAL/decision_matrix.md` 에 넣는다
2. **빈 칸에 가짜 값을 넣지 않는다**
3. **H-08** 전문가 검토
4. `06_FINAL/NEXT_ACTIONS.md` 를 갱신한다

---

## 매일 확인

- [ ] `ISSUES_FOR_V0_2.md` 에 새 항목을 적었는가
- [ ] v0.1 파일을 고치지 않았는가
- [ ] `--demo` 나 `--dry-run` 수치를 결과로 적지 않았는가
- [ ] `_gold/` 가 판정자에게 가지 않았는가
