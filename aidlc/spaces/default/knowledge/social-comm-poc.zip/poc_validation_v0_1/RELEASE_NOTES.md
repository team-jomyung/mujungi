# RELEASE NOTES · RC1

생성 2026-09-14 12:45:24

## 이 묶음이 무엇인가

**사람 판정을 시작할 수 있는 상태의 실행 패키지다. 검증 결과가 아니다.**

세 가지를 구분해서 읽는다.

| 등급 | 무엇 |
|---|---|
| **확인된 사실** | 코드가 돌고 시험이 통과하고 숫자가 재현된다 |
| **DEMO · 모의** | 씨앗 고정 생성기가 만든 것. 사람 판정이 아니다 |
| **아직 검증 안 됨** | POC A · B · C 전부. 사람이 시작하지 않았다 |

`RC1_HANDOFF_FINAL.html` 이 이 셋을 화면에서 나눠 보여 준다. ZIP 최상위에 있다.

## 이번에 새로 들어간 것

| 무엇 | 파일 |
|---|---|
| 판정 도구 | `02_POC_A/rater_app.html` |
| blind 선별 도구 | `02_POC_A/blind_selector.html` |
| 개인정보 회귀 시험 | `03_POC_C/privacy_test.html` · `privacy_test_cases.json` |
| 역할별 꾸러미와 누출 검사 | `tests/bundles.py` |
| 실측 매니페스트 | `tests/make_manifest.py` |
| 명령 입구 | `poc.py` |

## 고친 것

| 무엇 | 어디 |
|---|---|
| 다섯 자 이름에서 앞 글자가 남던 것 | `intake_prototype.html` P01 |
| 주민번호가 아닌 열세 자리에 저장이 막히던 것 | `intake_prototype.html` P10 |
| 치환 템플릿이 참가자 화면에 새던 것 | `intake_prototype.html` 로그 표시 |
| 감사가 자기 출력을 읽고 자기를 지적하던 것 | `tests/audit.py` |

자세한 것은 `03_POC_C/PRIVACY_TEST_RESULT.md`.

## 바로 할 수 있는 것

```
python poc.py status      지금 어디까지 됐나
python poc.py test        시험 · 감사 · 누출 검사
python poc.py bundles     역할별 꾸러미
```

## 사람이 해야 다음이 열린다

| | 무엇 | 막는 것 |
|---|---|---|
| H-01 | 판정자 2명 | POC A |
| H-02 | blind 후보 60~80쌍에서 40쌍 선별 | POC A |
| H-04 · H-05 | 기관 검토 · 참가자 5~10명 | POC C |

H-02 를 마치기 전에는 `poc.py prepare-a` 가 기존 20쌍만으로 양식을 만든다.
그것은 공식 POC A 가 아니다. 스크립트가 그렇게 경고한다.

## 하지 않은 것

- Frozen Spec v0.1 을 고치지 않았다. 발견한 문제는 `00_README/ISSUES_FOR_V0_2.md` 에만 적었다
- 임상 효과를 주장하지 않는다
- LLM 판정을 정답으로 쓰지 않는다
- 없는 검증 결과를 만들지 않았다
