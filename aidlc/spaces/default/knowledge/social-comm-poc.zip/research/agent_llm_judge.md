# LLM-as-a-Judge: Reliability, Bias, Calibration, and Human Gold Data

> **TOOLING NOTE — WebSearch did NOT work.** The `WebSearch` tool returned *"Web search was not performed: this session has used its web search budget (200 of 200 WebSearch calls)"* on the very first call. **I fell back entirely to `WebFetch`** against arXiv abstract pages, **ar5iv.labs.arxiv.org full-text HTML** (by far the most productive route), ACL Anthology, PubMed Central, and the Semantic Scholar Graph API — plus local `pypdf` text extraction for three PDFs that WebFetch could not parse.
>
> **Consequence for coverage:** without search, every paper here was reached by naming an arXiv ID / DOI / anthology ID directly. **This is a deep dive on papers I could name, not an exhaustive survey.** Relevant 2025–2026 work may exist that I never had the chance to discover.

**Date compiled:** 2026-09-12

**Evidence-depth key**

| Flag | Meaning |
|---|---|
| **FULL** | I read full-text tables / sections (ar5iv HTML or extracted PDF) |
| **ABSTRACT ONLY** | Abstract / landing page only — full text not read |
| **META ONLY** | Bibliographic metadata only — full text never read |

---

## A. LLM-as-a-Judge reliability and bias

### A1. Named bias types — the paper that named or measured each

| Bias | Source | Measured magnitude | Depth |
|---|---|---|---|
| **Position / order** | Zheng et al. 2023, *Judging LLM-as-a-Judge with MT-Bench and Chatbot Arena*, NeurIPS 2023 Datasets & Benchmarks — https://arxiv.org/abs/2306.05685 | Consistency under candidate swap (Table 2, default prompt): **GPT-4 65.0%, GPT-3.5 46.2%, Claude-v1 23.8%**. GPT-4 favored position 1 in **30.0%** of cases | **FULL** |
| **Position (independent replication)** | Wang et al. 2023, *Large Language Models are not Fair Evaluators* — https://arxiv.org/abs/2305.17926 | Reordering alone made **Vicuna-13B beat ChatGPT on 66 of 80** Vicuna-Benchmark queries with ChatGPT as judge | **ABSTRACT ONLY** |
| **Position (scale study)** | Shi et al. 2024/2025, *Judging the Judges: A Systematic Study of Position Bias in LLM-as-a-Judge*, AACL-IJCNLP 2025 — https://arxiv.org/abs/2406.07791 | 15 LLM judges, 2 benchmarks (MTBench, DevBench), 22 tasks, ~40 solution-generating models, **>150,000 evaluation instances**. Metrics: repetition stability, position consistency, preference fairness. Bias is **systematic, not random**; the **quality gap between candidates** strongly modulates it; prompt-component length has weak influence. Exact consistency percentages not on landing page | **ABSTRACT ONLY** |
| **Verbosity / length** | Zheng et al. 2023 (above) | "Repetitive list" attack **failure rate: Claude-v1 91.3%, GPT-3.5 91.3%, GPT-4 8.7%** (Table 3) — i.e. Claude and GPT-3.5 were fooled >9 times in 10 | **FULL** |
| **Verbosity (dedicated paper)** | Saito, Wachi, Wataoka & Akimoto 2023, *Verbosity Bias in Preference Labeling by Large Language Models* — https://arxiv.org/abs/2310.10076 | States "GPT-4 prefers longer answers more than humans" and proposes a metric to measure it. **NUMERIC MAGNITUDE NOT RETRIEVABLE** — abstract gives direction only | **ABSTRACT ONLY** |
| **Length (correction method)** | Dubois, Galambosi, Liang & Hashimoto 2024, *Length-Controlled AlpacaEval*, COLM 2024 — https://arxiv.org/abs/2404.04475 | GLM conditioned on zero length-difference raised Spearman correlation with LMSYS Chatbot Arena **0.94 → 0.98** | **ABSTRACT ONLY** |
| **Self-enhancement / self-preference** | Zheng et al. 2023 (above) | **Read from Figure 2b — APPROXIMATE, figure-read, not a table value:** GPT-4 favors its own outputs by **~10 percentage points** win rate vs humans; Claude-v1 by **~25 pp** | **FULL** (but figure-read) |
| **Style over substance** | Wu & Aji 2023, *Style Over Substance: Evaluation Biases for Large Language Models* — https://arxiv.org/abs/2307.03025 | On a curated dataset of intentionally flawed answers, **answers containing factual errors were rated MORE favorably than answers that were too short or contained grammatical errors** — by crowd annotators, expert annotators, and LLMs. Proposed Multi-Elo Rating System (MERS) "significantly enhances" LLM-based evaluation on factual accuracy, but shows **no significant improvement for crowd-sourced evaluation** | **ABSTRACT ONLY** |
| **Formatting + full 12-bias taxonomy** | Ye et al. 2024, *Justice or Prejudice? Quantifying Biases in LLM-as-a-Judge* (CALM framework) — https://arxiv.org/abs/2410.02736 | **12 biases:** position, verbosity, compassion-fade, bandwagon, distraction, fallacy-oversight, authority, sentiment, diversity, chain-of-thought, self-enhancement, refinement-aware. Robustness rates (RR) — **GPT-4o:** verbosity 0.977, fallacy-oversight 0.984, **position 0.776, sentiment 0.699**. **Claude-3.5:** 0.952 / 0.985 / position 0.832 / sentiment 0.660. **GPT-4-Turbo:** 0.915 / 0.969 / 0.818 / 0.653. **GPT-3.5:** 0.900 / 0.917 / **position 0.566** / 0.804. Position bias is the largest remaining vulnerability and worsens with more answer options; sentiment bias drops accuracy on superior responses to **0.243–0.271** under certain emotional framings | **FULL** |
| **Cognitive biases (6 types, CoBBLEr)** | Koo et al. 2023/2024, *Benchmarking Cognitive Biases in Large Language Models as Evaluators*, ACL 2024 Findings — https://arxiv.org/abs/2309.17012 | 15 LLMs across four size ranges, peer-evaluation setup. **Bias indications in ~40% of comparisons on average.** **Rank-Biased Overlap between human and machine preference rankings = 49.6%.** Includes "egocentric bias" (model ranks its own outputs highly) | **ABSTRACT ONLY** |
| **Familiarity (low-perplexity) bias, inconsistency, anchoring** | Stureborg, Alikaniotis & Suhara 2024, *Large Language Models are Inconsistent and Biased Evaluators* — https://arxiv.org/abs/2405.01724 | Familiarity bias (preference for lower-perplexity text), skewed rating distributions, anchoring effects in multi-attribute evaluation, low inter-sample agreement, sensitivity to prompt differences humans would consider insignificant. Datasets SummEval (analysis) and RoSE (mitigation). **SELF-CONSISTENCY RATES AND SKEW MAGNITUDES NOT RETRIEVABLE** from landing page | **ABSTRACT ONLY** |

### A2. Reported agreement between LLM judges and human annotators

> An agreement number without its task is useless. Every row below carries the task, dataset, and sample size.

| Study | Task / dataset | Judge result | Human baseline | Depth |
|---|---|---|---|---|
| Zheng et al. 2023 — https://arxiv.org/abs/2306.05685 | **MT-Bench, pairwise, INCLUDING ties** (setup S1) | GPT-4 **66%** (1,343 votes, turn 1); **66%** (1,325 votes, turn 2) | Human–human **63%** (721 votes) / **67%** (707 votes) | **FULL** |
| same | **MT-Bench, NON-TIE VOTES ONLY** (setup S2) | GPT-4 pairwise **85%** (859 votes) / **85%** (864 votes) | Human–human **81%** (479) / **82%** (474) | **FULL** |
| same | MT-Bench non-tie, **single-answer grading** | GPT-4 **85%** (739 votes) / **84%** (776 votes) | as above | **FULL** |
| same | **Chatbot Arena**, including ties | GPT-4 pairwise **64%** (3,066 votes) | — | **FULL** |
| same | **Chatbot Arena**, non-tie only | GPT-4 pairwise **87%** (1,944 votes) | — | **FULL** |
| Thakur, Choudhary, Ramayapally, Vaidyanathan & Hupkes 2024/2025, *Judging the Judges*, GEM² workshop — https://arxiv.org/abs/2406.12624 | **TriviaQA answer correctness**, 400 randomly sampled questions, 13 judge models × 9 exam-taker models | **Scott's π (×100):** GPT-4-Turbo ≈87, Llama-3.1-70B ≈88, Llama-3-70B ≈88, Llama-3.1-8B ≈77, Llama2-13B ≈74, Llama2-70B ≈69, Mistral-7B ≈66, **JudgeLM-7B ≈65**, Gemma-2B ≈26; lexical baselines: "contains" ≈64, exact-match ≈47. Percent agreement 80%+ for most | **Inter-human Scott's π = 96.2 ± 1.07; raw agreement 98.52% ± 0.42%** (1,200 questions, 3 annotators). Validation on 600 Llama-3.1-70B questions: π = 95.78 ± 0.30, 98.72% ± 0.10% | **FULL** |
| same | score-level deviation | Best judges' scores **differ from humans by up to 5 points**; the authors note **high percent agreement can coexist with 10–20 point score differences** (Figure 2). Model *ranking* Spearman ρ stays high even for weak judges (Table 11: "contains" 0.99 ± 0.02, Mistral-7B 0.98 ± 0.03, GPT-4 0.98 ± 0.03). Leniency bias: most models put P(correct) well above 0.50 when misaligned (Figure 6a) | — | **FULL** |
| Verga et al. 2024 (PoLL) — https://arxiv.org/abs/2404.18796 | short-form QA | **GPT-4 Cohen's κ: NQ 0.627, TriviaQA 0.841, HotpotQA 0.830** | — | **FULL** |
| Bavaresco et al. 2024/2025, *LLMs instead of Human Judges?* (JUDGE-BENCH), ACL 2025 — https://arxiv.org/abs/2406.18403 | **20 NLP evaluation tasks, 11 LLM judges** (open-weight + proprietary) | **Cohen's κ range across datasets: −0.24 to 0.84.** **Spearman ρ range: −0.03 to 0.82.** Best: **GPT-4o, mean κ = 0.28 ± 0.32, mean ρ = 0.50 ± 0.21**. Worst: OLMo-7B, κ = 0.10 ± 0.18, ρ = 0.30 ± 0.17 | **Over 50% of datasets fall below moderate agreement (κ < 0.41 or ρ < 0.50).** Toxicity and safety evaluations score near zero or **negative**; engagingness "consistently low across all models" | **FULL** |
| Zeng et al. 2023/2024, *Evaluating Large Language Models at Evaluating Instruction Following* (LLMBar), ICLR 2024 — https://arxiv.org/abs/2310.07641 | instruction-following preference, **419 manually curated output pairs** | GPT-4 vanilla: **Natural 93.5%, Adversarial avg 75.0%** (Neighbor 64.2%, GPTInst 76.6%, GPTOut 76.6%, Manual 75.0%). Other judges on Adversarial: ChatGPT **37.0%**, LLaMA-2-Chat **30.4%**, PaLM2 62.0%, Falcon 44.6% | **Expert human annotator agreement 94%** overall (Natural 90%, Adversarial 95%) | **FULL** |
| Tan et al. 2024/2025, *JudgeBench*, ICLR 2025 — https://arxiv.org/abs/2410.12784 | **350 objectively-labeled hard response pairs** (154 knowledge, 98 reasoning, 56 math, 42 coding), built by sampling GPT-4o responses to hard questions with ground truth and pairing one correct with one incorrect | **RANDOM BASELINE = 50%.** Prompted: GPT-4o vanilla **50.86%**, GPT-4o + Arena-Hard prompt **56.57%**, VertexAI Evaluation **44.57%**. Foundation models w/ Arena-Hard prompt: Llama-3.1-405B 56.86%, Claude-3.5-Sonnet 64.29%, o1-preview 75.43%, o3-mini(high) 80.86%. **Fine-tuned judges: Skywork-70B 57.43%, Skywork-8B 53.43%, Prometheus2-8x7B 40.29%, AutoJ 36.57%, PandaLM 13.14%.** Reward models: Skywork-Reward-Gemma-2-27B 64.29%, InternLM2-20B-Reward 63.43%. Category breakdown for GPT-4o Arena-Hard judge: knowledge 50.65%, reasoning 54.08%, math 75.00%, coding 59.52% | — | **FULL** |
| Gilardi, Alizadeh & Kubli 2023, *ChatGPT Outperforms Crowd-Workers for Text-Annotation Tasks*, PNAS 120(30) — https://arxiv.org/abs/2303.15056 | **2,382 tweets**; relevance, stance, topic, frame detection | ChatGPT zero-shot accuracy exceeded MTurk crowd-workers on 4 of 5 tasks; **intercoder agreement higher than both crowd-workers and trained annotators** across all tasks. Cost **< \$0.003 per annotation, ~20× cheaper than MTurk** | — | **ABSTRACT ONLY** |

**How to read this section.** The widely quoted "LLM judges match humans at 80%+" figure comes specifically from **pairwise chat-helpfulness judging with tie votes excluded**. The same judges fall to **κ ≈ 0.1–0.3** on subjective / expert-knowledge tasks (JUDGE-BENCH) and to **chance** on objectively-hard pairs (JudgeBench). Do not carry the MT-Bench number into a subjective-judgment pipeline.

### A3. What happens when the SAME model generates and evaluates

| Finding | Source | Numbers | Depth |
|---|---|---|---|
| **Self-recognition causally drives self-preference** | Panickssery, Bowman & Feng 2024, *LLM Evaluators Recognize and Favor Their Own Generations* — https://arxiv.org/abs/2404.13076 | **Out-of-the-box pairwise self-recognition accuracy:** GPT-4 **73.5%**; GPT-3.5 ~53.5% (XSUM) / 48.1% (CNN/DM); Llama-2 ~51.4% / 50.5%. **Out-of-the-box pairwise self-preference score:** GPT-4 **0.705 (XSUM) / 0.912 (CNN)**; GPT-3.5 0.582 / 0.431; Llama-2 0.511 / 0.505. **After fine-tuning on 500 examples**, GPT-3.5 and Llama-2 exceed **90%** self-recognition, and the example-level Kendall τ between self-recognition and self-preference rose **0.41 → 0.74** (GPT-3.5, XSUM). Task = **summarization**; datasets XSUM and CNN/DailyMail, 1,000 articles each. Controlled experiments reported to rule out straightforward confounders | **FULL** |
| Self-enhancement in chat judging | Zheng et al. 2023 | GPT-4 ~+10 pp, Claude-v1 ~+25 pp own-output win rate vs humans (**figure-read, approximate**) | **FULL** |
| **Mechanism may be FAMILIARITY, not identity** | Wataoka, Takahashi & Ri 2024, *Self-Preference Bias in LLM-as-a-Judge*, NeurIPS 2024 Safe Generative AI workshop — https://arxiv.org/abs/2410.21819 | Introduces a quantitative self-preference metric; finds GPT-4 exhibits substantial bias. Key claim: LLM judges assign **higher scores to lower-perplexity text than humans do, regardless of whether the judge generated it** — concluding perplexity/familiarity, not explicit self-identification, is the underlying mechanism. **EXACT BIAS MAGNITUDES AND METRIC DEFINITION NOT RETRIEVABLE** | **ABSTRACT ONLY** |
| Judges mis-evaluate machine-generated text generally | Bavaresco et al. 2024 (JUDGE-BENCH) | Alignment with humans is **better on human-generated text than on model-generated text**, "suggesting LLMs display a bias towards their own generation" | **FULL** |

### A4. Is using a DIFFERENT model as judge sufficient? — No, not on its own

| Evidence | Source | Numbers | Depth |
|---|---|---|---|
| **PREFERENCE LEAKAGE — the bias survives switching judges when the models are related** | Li et al. 2025, *Preference Leakage: A Contamination Problem in LLM-as-a-judge*, ICLR 2026 — https://arxiv.org/abs/2502.01534 | **Preference-leakage score by relationship:** **same model 28.7%** (Arena-Hard) / **18.4%** (AlpacaEval 2.0), **avg 23.6%**. **Inheritance (teacher→student):** 19.3% avg with same instructions, 22.3% avg with different instructions. **Same family, same series: 8.9% avg. Same family, different series: 2.8% avg.** Judge/generator models: GPT-4o-2024-11-20, Gemini-1.5-flash, Llama-3.3-70B-Instruct-turbo. Student models: Mistral-7B-v0.1, Qwen-2.5-14B. Benchmarks: Arena-Hard (500 questions), AlpacaEval 2.0 (805 questions). **Human confirmation:** manual annotation of 100 AlpacaEval samples, 3 annotators, **78.6 agreement** — bias confirmed. Gemini-1.5 showed the strongest bias toward its student models, then GPT-4o, with Llama-3.3 least. Authors: this contamination "is harder to detect compared to previously identified biases in LLM-as-a-judge scenarios" | **FULL** |
| Cross-family panel **reduces but does not remove** it | Verga et al. 2024 (PoLL) — https://arxiv.org/abs/2404.18796 | A panel of **disjoint model families** cut inter-dataset standard deviation to **2.2 vs GPT-3.5's 6.1** on multi-hop QA | **FULL** |
| Familiarity bias is model-agnostic | Wataoka et al. 2024; Stureborg et al. 2024 | A different judge still over-rewards low-perplexity text | **ABSTRACT ONLY** |

**Practical conclusion.** A different-family judge removes *literal* self-preference but not (a) **family / inheritance leakage** — measured at ~8.9% for same-family-different-series and ~19–22% for teacher→student, i.e. the same order of magnitude as the ~23.6% literal self-judging effect — nor (b) generic **low-perplexity familiarity bias**, which is model-agnostic. If your generator is distilled from, or shares a family with, your judge, switching judge vendors has not solved the problem.

---

## B. What improves judge reliability

| Intervention | Source | Measured effect | Depth |
|---|---|---|---|
| **REFERENCE ANSWER (reference-guided judging)** | Zheng et al. 2023, §3.4 — https://arxiv.org/abs/2306.05685 | Math / reasoning grading failure rate **14/20 (70%) → 3/20 (15%)** when the judge is made to produce its own answer independently first, then grade against it | **FULL** |
| **CHAIN-OF-THOUGHT before verdict** | Zheng et al. 2023, §3.4 | Same task: **14/20 (70%) → 6/20 (30%)** — clearly **less effective than a reference**. Authors: "even with the CoT prompt, we find that in many cases LLM makes exactly the same mistake as the given answers" | **FULL** |
| **CoT — evidence FOR** | Liu, Iter, Xu, Wang, Xu & Zhu 2023, *G-Eval: NLG Evaluation using GPT-4 with Better Human Alignment* — https://arxiv.org/abs/2303.16634 | GPT-4 backbone with chain-of-thought + form-filling reaches **Spearman 0.514** with humans on the **SummEval summarization** task, "significantly outperforming previous methods." **Kendall-Tau values and Topical-Chat results NOT RETRIEVABLE** from landing page | **ABSTRACT ONLY** |
| **CoT — evidence AGAINST** | Chiang & Lee 2023, *A Closer Look into Automatic Evaluation Using Large Language Models*, EMNLP 2023 Findings — https://arxiv.org/abs/2310.05657 | Verbatim: "**auto Chain-of-Thought (CoT) used in G-Eval does not always make G-Eval more aligned with human ratings**"; forcing numeric-only output is suboptimal; and **prompting the LLM to explain its rating "consistently improves the correlation between the ChatGPT and human ratings."** So: *rationale helps, automatic CoT does not reliably.* **NO EFFECT SIZES on landing page** | **ABSTRACT ONLY** |
| Baseline feasibility of LLM evaluation | Chiang & Lee 2023, *Can Large Language Models Be an Alternative to Human Evaluations?*, ACL 2023 — https://arxiv.org/abs/2305.01937 | Texts rated higher by human experts are also rated higher by LLMs; results stable across instruction formats and sampling algorithms. Tasks: open-ended story generation and adversarial attacks. **NO CORRELATION COEFFICIENTS OR AGREEMENT PERCENTAGES on landing page** | **ABSTRACT ONLY** |
| **SELF-RATIONALIZATION (train on own rationales via DPO)** | Trivedi et al. 2024, *Self-rationalization improves LLM as a fine-grained judge* — https://arxiv.org/abs/2410.05495 | **62% human-evaluation win rate on average** vs models trained only via SFT on rationale; **+3% to 9%** over larger models; high scoring accuracy on BigGen Bench and RewardBench; achieved **after just two iterations**, no extra external training data | **ABSTRACT ONLY** |
| **RULES / explicit criteria, + reference, + swap** | Zeng et al. 2023 (LLMBar) — https://arxiv.org/abs/2310.07641 | GPT-4 gains on the **Adversarial** subset: **Rules alone +5.4 pp; Swap (order de-bias) +5.1 pp; Metrics+Reference +7.8 pp.** Best combination: Adversarial **75.0% → 82.8%**, Natural **93.5% → 96.0%** — **still 12.2 pp below the 95% human level on Adversarial** | **FULL** |
| **RUBRIC-conditioned fine-tuned judge** | Kim et al. 2023/2024, *Prometheus: Inducing Fine-grained Evaluation Capability in Language Models*, ICLR 2024 — https://arxiv.org/abs/2310.08491 | 13B open evaluator. Feedback Collection training set = **1K fine-grained score rubrics, 20K instructions, 100K responses + language feedback generated by GPT-4**. **Pearson 0.897 with human evaluators vs GPT-4's 0.882** across 45 customized rubrics (ChatGPT 0.392). Comparable to GPT-4 across 1,222 customized rubrics on four benchmarks | **ABSTRACT ONLY** |
| **Fine-tuned judge, v2** | Kim et al. 2024, *Prometheus 2*, EMNLP 2024 — https://arxiv.org/abs/2405.01535 | **Direct assessment, Pearson vs humans.** Feedback Bench (**the authors' own in-distribution benchmark — interpret with caution**): Prometheus2-8x7B **0.898**, Prometheus1-13B 0.860, GPT-4 0.753. **FLASK (human): Prometheus2-8x7B 0.555 vs GPT-4 0.679** — still behind. Vicuna Bench / MT Bench ~0.68 vs GPT-4 ~0.69. **Pairwise ranking accuracy vs humans:** HHH Alignment **85.52% vs GPT-4 90.95%** (Auto-J 75.57%); MT Bench Human Judgement **71.96% vs 79.90%**; Auto-J Eval **79.98% vs 83.12%** | **FULL** |
| **Fine-tuned judge with explicit debiasing** | Zhu, Wang & Wang 2023/2025, *JudgeLM: Fine-tuned Large Language Models are Scalable Judges*, ICLR 2025 — https://arxiv.org/abs/2310.17631 | 7B / 13B / 33B scales. **Agreement with GPT-4 exceeds 90%** (note: agreement with *GPT-4*, not with humans), stated to surpass human-to-human agreement. Addresses **position, knowledge, and format bias** via **swap augmentation, reference support, and reference drop**. JudgeLM-7B evaluates 5,000 samples in 3 minutes on 8 A100 GPUs. **PER-TECHNIQUE QUANTIFIED GAINS NOT RETRIEVABLE** | **ABSTRACT ONLY** |
| **COUNTER-EVIDENCE on fine-tuned judges** | Tan et al. 2024 (JudgeBench); Thakur et al. 2024 | On hard objective pairs: **Prometheus2-8x7B 40.29%, AutoJ 36.57%, PandaLM 13.14%** against a 50% chance baseline. On TriviaQA, **JudgeLM-7B Scott's π ≈ 65 vs GPT-4-Turbo's ≈ 87**. Fine-tuned judges **generalize poorly off their training distribution** | **FULL** |
| **PANEL OF JUDGES (PoLL)** | Verga et al. 2024, *Replacing Judges with Juries: Evaluating LLM Generations with a Panel of Diverse Models* — https://arxiv.org/abs/2404.18796 | **Panel = Command R + Claude-3-Haiku + GPT-3.5.** Six datasets: NQ, TriviaQA, HotpotQA (single-hop), HotpotQA (multi-hop), Bamboogle, Chatbot Arena Hard. **Cohen's κ vs human: NQ 0.763 (GPT-4 0.627), TriviaQA 0.906 (0.841), HotpotQA 0.867 (0.830)**; Bamboogle 0.896 (GPT-3.5 0.846); HotpotQA multi-hop 0.871 (0.827). **Chatbot Arena ranking: Pearson 0.917 (GPT-4 0.817), Kendall τ 0.778 (0.667).** **COST: 7–8× cheaper than a single GPT-4 judge** (\$1.25 in / \$4.25 out per M tokens vs GPT-4-Turbo \$10 / \$30). Variance: PoLL std-dev **2.2 vs GPT-3.5's 6.1** | **FULL** |
| **MULTI-AGENT DEBATE (ChatEval)** | Chan et al. 2023, *ChatEval: Towards Better LLM-based Evaluators through Multi-Agent Debate* — https://arxiv.org/abs/2308.07201 | **FairEval:** multi-agent GPT-4 **63.8% vs single-agent 61.3%** (κ 0.40 vs 0.36); multi-agent ChatGPT **60.0% vs 53.8%** (κ 0.33 vs 0.27). **Topical-Chat:** multi-agent GPT-4 avg Spearman **0.684 vs G-EVAL-4's 0.588** (+16.3% relative); Kendall-Tau **0.632 vs 0.575**. Multi-agent ChatGPT: Spearman 0.552 vs 0.544. Default config: **2 agents, 2 discussion turns**, one-by-one communication. **THE PAPER CONTAINS NO COST OR TOKEN-OVERHEAD ANALYSIS** | **FULL** |
| **Multiple-evidence + balanced-position calibration** | Wang et al. 2023 — https://arxiv.org/abs/2305.17926 | Three strategies: **Multiple Evidence Calibration** (generate justifications before rating), **Balanced Position Calibration** (aggregate across orders), and **Human-in-the-Loop Calibration** using "balanced position diversity entropy" to flag difficult examples for human intervention. Reported to reduce bias and align closer with human judgment. **EFFECT SIZES NOT ON LANDING PAGE** | **ABSTRACT ONLY** |
| **FEW-SHOT judge** | Zheng et al. 2023, §D.2 | Position-bias consistency with three exemplars: **GPT-4 65.0 → 77.5%, Claude-v1 23.8 → 63.7%, GPT-3.5 46.2 → 55.0%**. But the authors caution "**high consistency may not imply high accuracy**" and human agreement was similar to zero-shot | **FULL** |
| Criteria calibration from human labels (AutoCalibrate) | Liu et al. 2023, *Calibrating LLM-Based Evaluator* — https://arxiv.org/abs/2309.13308 | Multi-stage gradient-free method: encode human preference from labeled data, draft criteria via in-context learning, self-refine top criteria. Claims "significant improvement in correlation with expert evaluation." **NO NUMBERS, NO DATASET NAMES, NO HUMAN-LABEL COUNTS RETRIEVABLE** | **ABSTRACT ONLY** |
| Fine-grained skill rubrics | Ye et al. 2023/2024, *FLASK: Fine-grained Language Model Evaluation based on Alignment Skill Sets*, ICLR 2024 Spotlight — https://arxiv.org/abs/2307.10928 | Decomposes coarse-level scoring into skill-set-level scoring per instruction; reports "a high correlation between model-based and human-based evaluations." **NO NUMERIC CORRELATION VALUE RETRIEVABLE** | **ABSTRACT ONLY** |
| Survey (context only) | Gu et al. 2024/2025, *A Survey on LLM-as-a-Judge* — https://arxiv.org/abs/2411.15594 | Organizes reliability strategies into consistency enhancement, bias mitigation, and scenario adaptation; proposes a benchmark. **NO QUANTITATIVE CLAIMS on landing page** | **ABSTRACT ONLY** |
| Prompt-template sensitivity | Wei et al. 2024/2025, *Systematic Evaluation of LLM-as-a-Judge in LLM Alignment Tasks*, ICLR 2025 "Building Trust in LLMs" workshop — https://arxiv.org/abs/2408.13006 | Reports "significant impact of prompt templates on LLM judge performance" and "mediocre alignment level between the tested LLM judges and human evaluators" on TL;DR Summarization and HH-RLHF-Helpfulness. **NO NUMERIC VALUES on landing page** | **ABSTRACT ONLY** |

### Reference-based vs reference-free — what is actually measured

The one clean effect size is **Zheng et al.'s 70% → 15% failure-rate reduction** on math/reasoning grading when a reference answer is supplied.

The structural argument is **Deutsch, Dror & Roth 2022, *On the Limitations of Reference-Free Evaluations of Generated Text* — https://arxiv.org/abs/2210.12563** (**PRE-2023 — but it concerns metrics rather than LLM judges, so it is not superseded by LLM-judge progress**). A reference-free metric is equivalent to using one generation model to evaluate another, which creates three problems: (1) test-time optimization can artificially inflate scores, (2) inherent bias toward similar models, and (3) **penalization of superior outputs including human-written text**. They recommend demoting reference-free metrics to diagnostic tools rather than performance measures. **ABSTRACT ONLY.**

> **A general cross-task effect size for reference-based vs reference-free LLM judging: NOT FOUND AFTER SEARCH.** See the non-findings section for terms and databases.

---

## C. Calibration, abstention and selective prediction

### C1. The selective-prediction framework (foundational; pre-LLM; not superseded)

| Concept | Source | Result | Depth |
|---|---|---|---|
| **Risk–coverage tradeoff, SGR algorithm** | Geifman & El-Yaniv 2017, *Selective Classification for Deep Neural Networks*, NeurIPS 2017 — https://arxiv.org/abs/1705.08500 | **Selective risk** = error rate among the instances the model does *not* reject. **Coverage** = the fraction of test instances it predicts on. The user sets a desired risk level; the classifier rejects instances as needed to guarantee it with high probability. Reported result: **2% top-5 error on ImageNet with probability 99.9%, at almost 60% test coverage** | **ABSTRACT ONLY.** **PRE-2023 — foundational method, not an LLM-judge claim** |
| **Learned calibrator beats softmax under domain shift** | Kamath, Jia & Liang 2020, *Selective Question Answering under Domain Shift*, ACL 2020 — https://arxiv.org/abs/2006.09462 | On mixtures of SQuAD and five additional QA datasets: a trained calibrator **answers 56% of questions while maintaining 80% accuracy**, versus **48% coverage at 80% accuracy** using the model's softmax probabilities directly. Key insight: calibrators benefit from observing out-of-domain model behavior even when the test domain differs | **ABSTRACT ONLY.** **PRE-2023** |

**How coverage-vs-risk is reported in this literature:** set a target risk (or, for judges, a target human-agreement level) → report the **coverage achieved at that risk**. That is the correct shape for a human-escalation operating point.

### C2. Is verbalized confidence calibrated? — No, it is systematically overconfident

| Source | Finding | Depth |
|---|---|---|
| Xiong et al. 2023/2024, *Can LLMs Express Their Uncertainty?*, ICLR 2024 — https://arxiv.org/abs/2306.13063 | "**LLMs, when verbalizing their confidence, tend to be overconfident**," possibly imitating human patterns of confidence expression. Five dataset types × five LLMs including GPT-4 and LLaMA-2-Chat. **White-box AUROC 0.605 vs black-box 0.522.** No single technique consistently outperforms others; all struggle on challenging knowledge-intensive tasks. Human-inspired prompts, sampling consistency, and better aggregation mitigate but do not solve overconfidence | **ABSTRACT ONLY** |
| Tian et al. 2023, *Just Ask for Calibration*, EMNLP 2023 — https://arxiv.org/abs/2305.14975 | **Counterpoint, specific to RLHF-tuned models:** "verbalized confidences emitted as output tokens are typically **better-calibrated than the model's conditional probabilities**," **often reducing expected calibration error by a relative 50%**. Models: ChatGPT, GPT-4, Claude. Datasets: TriviaQA, SciQ, TruthfulQA. **PER-MODEL/PER-DATASET ECE VALUES NOT ON LANDING PAGE** | **ABSTRACT ONLY** |
| Kadavath et al. 2022, *Language Models (Mostly) Know What They Know* — https://arxiv.org/abs/2207.05221 | "Larger models are **well-calibrated on diverse multiple choice and true/false questions when they are provided in the right format**." P(True) and P(IK) both studied; models predict P(IK) well and partially generalize across tasks but **struggle with calibration of P(IK) on new tasks**. **NO ECE / AUROC FIGURES ON LANDING PAGE** | **ABSTRACT ONLY.** **2022 — PRE-2023, flag as potentially superseded; Tian et al. 2023 documents RLHF-era calibration degradation that postdates this** |
| **Jung, Brahman & Choi 2024** — https://arxiv.org/abs/2407.18370 | **Measured directly on judges:** verbalized confidences "**consistently lead to over-confidence when used for preference evaluation**," with **ECE ≈ 0.215–0.217 even for GPT-4-turbo**. Their Simulated-Annotators method reaches **ECE 0.095 (AlpacaEval) and 0.039 (TL;DR)**, **AUROC 0.723** versus predictive-probability's 0.642 (ECE 0.217 / 0.196). Table 1 covers GPT-4-turbo, GPT-3.5-turbo and Mistral-7B-it (Llama is **not** in Table 1) | **FULL** |
| Wagner et al. 2024, *Black-box Uncertainty Quantification Method for LLM-as-a-Judge* — https://arxiv.org/abs/2410.11594 | Builds a confusion matrix from token probabilities over possible ratings to derive uncertainty labels. Reports "a strong correlation between the accuracy of LLM evaluations and the derived uncertainty scores." **NO CALIBRATION MEASURES, CORRELATION COEFFICIENTS, OR ESCALATION OPERATING POINTS RETRIEVABLE** | **ABSTRACT ONLY** |

**Bottom line:** raw verbalized confidence from an LLM judge is **not** a usable escalation signal (ECE ≈ 0.22 even for GPT-4). Agreement-simulation or consistency-based confidence estimation is.

### C3. Human-in-the-loop routing — the one paper with a real operating point

**Jung, Brahman & Choi 2024, *Trust or Escalate: LLM Judges with Provable Guarantees for Human Agreement*** — https://arxiv.org/abs/2407.18370 — **FULL**

Three components: **Selective Evaluation** (judge assesses its own confidence and decides when to trust its judgement), **Simulated Annotators** (a confidence-estimation method that improves calibration and enables broader coverage), and **Cascaded Selective Evaluation** (start with cheap models, escalate to stronger ones only when necessary).

| Dataset | Target human agreement (1 − α) | Calibration set | **Coverage achieved** | Guarantee success rate | Evaluator composition |
|---|---|---|---|---|---|
| TL;DR | **0.90** | \|D_cal\| = **500**, δ = 0.1 | **55.7%** | 90.8% | Mistral-7B 28.3% / GPT-3.5-turbo 28.2% / GPT-4-turbo 43.5% |
| ChatArena | **0.85** | \|D_cal\| = **500** | **63.2%** | 91.0% | Mistral-7B 23.7% / GPT-3.5-turbo 58.8% / GPT-4-turbo 17.5% |

- Without selective evaluation, **GPT-4 has 100% coverage and a 0.0 guarantee success rate.**
- **Threshold calibration procedure:** *fixed sequence testing* — test "from the largest value of λ to a progressively smaller value, and stop at the last time R̂⁺(λ) is below the target risk α."
- Headline claim: on a Chatbot Arena subset where **GPT-4 almost never achieves 80% human agreement**, the method **guarantees over 80% human agreement with almost 80% test coverage** while using models as cheap as Mistral-7B.

**Related routing / cascade work (cost-driven, not agreement-guaranteed):**

| Source | Numbers | Depth |
|---|---|---|
| Chen, Zaharia & Zou 2023, *FrugalGPT* — https://arxiv.org/abs/2305.05176 | LLM cascade learns which model combinations to use per query: **up to 98% cost reduction while matching GPT-4 performance**, or **+4% accuracy at equivalent cost**. **THE EXACT ESCALATION SCORE THRESHOLD AND DATASET LIST ARE NOT ON THE LANDING PAGE** | **ABSTRACT ONLY** |
| Ong et al. 2024/2025, *RouteLLM: Learning to Route LLMs with Preference Data* — https://arxiv.org/abs/2406.18665 | Routers trained on human preference data + augmentation: "**significant cost reductions—by over 2 times in certain cases—without compromising the quality of responses**"; significant transfer when strong/weak models are swapped. **EXACT QUALITY-THRESHOLD OPERATING POINTS (e.g. "95% of GPT-4"), BENCHMARK NAMES, AND THRESHOLD-SELECTION METHOD ARE NOT ON THE LANDING PAGE** | **ABSTRACT ONLY** |

### C4. Active learning / uncertainty sampling for annotation budget reduction

**Settles, B. 2009. *Active Learning Literature Survey*. Computer Sciences Technical Report 1648, University of Wisconsin–Madison.** Source PDF: https://burrsettles.com/pub/settles.activelearning.pdf (PDF metadata confirms `/Author: Burr Settles`, `/Title: Active Learning Literature Survey`; creation date 2010-01-26). — **FULL, via local `pypdf` extraction.** **PRE-2023 — a method survey; still the standard reference.**

- **Illustrative result:** 30 labels drawn at random → **70% accuracy**; 30 labels selected by **uncertainty sampling → 90% accuracy** (logistic regression on a two-Gaussian toy set). A text-classification learning curve (baseball vs hockey, 20 Newsgroups) shows uncertainty sampling dominating random sampling over the first 100 queries.
- **Adoption evidence, verbatim:** "Tomanek and Olsson (2009) report in a survey that **91% of researchers who used active learning in large-scale annotation projects had their expectations fully or partially met**." Also: "the survey also states that **20% of respondents opted not to use active learning** in such projects, specifically because they were 'not convinced that [it] would work well in their scenario.'"
- **Cautions, verbatim:**
  - "Somewhat surprisingly, **Schein and Ungar (2007) showed that active learning can sometimes require more labeled instances than passive learning** even when using the same model class, in their case logistic regression."
  - "**Guo and Schuurmans (2008) found that off-the-shelf query strategies, when myopically employed in a batch-mode setting are often much worse than random sampling.**"
  - "Gasperin (2009) reported negative results for active learning in an anaphora resolution task."
  - "Baldridge and Palmer (2009) found a curious inconsistency in how well active learning helps that seems to be correlated with the proficiency of the annotator (specifically, a domain expert was better utilized by an active learner than a domain novice, who was better suited to a passive learner)."
- **Structural caveat, verbatim:** the resulting labeled set is "a **biased distribution, not drawn i.i.d.** from the underlying natural density," implicitly tied to the model class that selected the queries, so it may not transfer if the model class changes.
- Settles also notes the selective-repeated-labeling problem with noisy oracles (Sheng et al. 2008; Donmez et al. 2009): when to query a new instance versus re-label an existing one.
- **The survey gives NO aggregate percentage figure for label savings.** A single headline number of the form "active learning saves X% of annotation effort": **NOT ESTABLISHED.**

**Li, Shi, Ziems, Kan, Chen, Liu & Yang 2023, *CoAnnotating: Uncertainty-Guided Work Allocation between Human and Large Language Models for Data Annotation*, EMNLP 2023** — https://arxiv.org/abs/2310.15638 — **FULL**

- **Uncertainty estimate:** entropy `−Σⱼ P_θ(a_ij|p_ij) ln P_θ(a_ij|p_ij)` computed over responses generated from **7 different prompt variants**, not repeated identical prompts.
- **Six datasets:** TREC and AG News (topic classification); MRPC and TempoWiC (semantic similarity); SemEval-2016 Tweet Stance Detection and Conversation Gone Awry (nuanced comprehension).
- **The "21% improvement over random baseline":** entropy-guided allocation reached macro-F1 **56.9 on TempoWiC at 40% ChatGPT allocation** versus the random baseline's **53.2** — a **3.7-point absolute gain**.
- **AG News (straightforward task):** roughly **33% of instances can be allocated to ChatGPT** while maintaining human-level F1.
- **CRITICAL for any subjective pipeline:** on Stance Detection and Conversation Gone Awry, "**any level of outsourcing to the current version of ChatGPT compromises annotation quality.**"
- Cost model assumed: **\$15/hour** human annotation with **5 independent annotators** per instance where the source dataset paper did not specify.

---

## D. How much human gold data is needed

### D1. The hard statistical result — the single most important item in this report

**Dorner, Nastl & Hardt 2024/2025, *Limits to scalable evaluation at the frontier: LLM as Judge won't beat twice the data*, ICLR 2025** — https://arxiv.org/abs/2410.13341 — **ABSTRACT ONLY**

> "**When the judge is no more accurate than the evaluated model, no debiasing method can decrease the required amount of ground truth labels by more than half.**"

Empirically, realized savings are "**even more modest than what our theoretical limit suggests**." The condition — judge accuracy not exceeding the evaluated model's — is precisely the situation when assessing frontier systems. **An LLM judge that is not clearly better than the system it judges buys at most a 2× reduction in required human labels, never elimination.**

Supporting statistical machinery:

| Source | Guarantee / number | Depth |
|---|---|---|
| Angelopoulos, Bates, Fannjiang, Jordan & Zrnic 2023, *Prediction-Powered Inference* — https://arxiv.org/abs/2301.09633 | "Provably valid confidence intervals for quantities such as means, quantiles, and linear and logistic regression coefficients, **without making any assumptions on the machine-learning algorithm** that supplies the predictions." Inputs: a small gold-standard labeled set **plus** ML predictions on unlabeled data. "More accurate predictions translate to smaller confidence intervals." **NO NUMERIC CI-WIDTH-REDUCTION OR LABEL-SAVINGS EXAMPLE ON THE PAGE** | **ABSTRACT ONLY** |
| Boyeau, Angelopoulos, Yosef, Malik & Jordan 2024, *AutoEval Done Right: Using Synthetic Data for Model Evaluation* — https://arxiv.org/abs/2403.07008 | Remains unbiased while improving sample efficiency: "**increase the effective human-labeled sample size by up to 50%** on experiments with GPT-4." **SPECIFIC DATASETS NOT ON LANDING PAGE** | **ABSTRACT ONLY** |
| Chaganty, Mussman & Liang 2018, *The price of debiasing automatic metrics in natural language evaluation*, ACL 2018 — https://arxiv.org/abs/1807.02202 | Control variates yield an unbiased estimator cheaper than human evaluation alone, but realized savings were only **7–13% on summarization and open-response question answering**. They prove theoretical bounds showing the estimator cannot be improved, identifying the bottlenecks as **automatic-metric quality and the human evaluation prompt itself** — fundamental limitations, not implementation issues | **ABSTRACT ONLY.** **PRE-2023 (pre-LLM-judge) — the impossibility argument still stands** |

### D2. Kappa bands — every one is a CONVENTION, not an empirical threshold

| Scale | **Exact bands** | Citation | Depth / verification |
|---|---|---|---|
| **Landis & Koch 1977** | **< 0.00 poor; 0.00–0.20 slight; 0.21–0.40 fair; 0.41–0.60 moderate; 0.61–0.80 substantial; 0.81–1.00 almost perfect** | Landis JR, Koch GG. "The measurement of observer agreement for categorical data." **Biometrics 33(1):159–174, 1977.** DOI: https://doi.org/10.2307/2529310 — PMID 843571 | **META ONLY for the primary.** JSTOR (https://www.jstor.org/stable/2529310) failed to load; PubMed (https://pubmed.ncbi.nlm.nih.gov/843571/) hit a cookie wall. Semantic Scholar API confirmed title / journal / year / DOI / PMID (abstract field null; citation count 81,252). **Bands verified via two reproductions:** (a) **Artstein & Poesio 2008 Figure 1**, extracted verbatim from the PDF: *"K = 0.0 0.2 0.4 0.6 0.8 1.0 / Poor Slight Fair Moderate Substantial Perfect … Kappa values and strength of agreement according to Landis and Koch (1977)"*; (b) **Wikipedia (SECONDARY)**, which gives the 0.21 / 0.41 / 0.61 / 0.81 boundaries and the label "almost perfect" |
| **Fleiss 1981** | **> 0.75 excellent; 0.40–0.75 fair to good; < 0.40 poor** | Fleiss JL, *Statistical Methods for Rates and Proportions*, 2nd ed., 1981 | **SECONDARY (Wikipedia). NOT independently verified against the primary text** |
| **Cohen 1960** (the statistic itself) | — | Cohen J. "A Coefficient of Agreement for Nominal Scales." **Educational and Psychological Measurement 20(1):37–46, 1960.** DOI: https://doi.org/10.1177/001316446002000104 | **META ONLY** (Semantic Scholar; abstract field null; citation count 44,105) |
| **McHugh 2012** (stricter, health-oriented) | **0–.20 none (0–4% of data reliable); .21–.39 minimal (4–15%); .40–.59 weak (15–35%); .60–.79 moderate (35–63%); .80–.90 strong (64–81%); above .90 almost perfect (82–100%)** | McHugh ML. "Interrater reliability: the kappa statistic." **Biochemia Medica 22(3):276–282, 2012.** DOI: https://doi.org/10.11613/BM.2012.031 — PMID 23092060, PMCID PMC3900052 | **FULL.** Verbatim: *"Cohen's suggested interpretation may be too lenient for health related studies because it implies that a score as low as 0.41 might be acceptable."* And: *"any kappa below 0.60 indicates inadequate agreement among the raters and little confidence should be placed in the study results."* |
| **Krippendorff** (content-analysis convention, inherited by CL) | **α > 0.800 = good reliability; 0.667 < α < 0.800 = tentative conclusions only** | Krippendorff 1980, p.147, transmitted via Carletta 1996, p.252; Krippendorff 2004a, p.242 | **FULL**, via verbatim Artstein & Poesio extraction |
| **Neuendorf 2002, p.3** | **≥ .90 acceptable to all; ≥ .80 acceptable in most situations; below that, great disagreement** | Neuendorf KA, *The Content Analysis Guidebook*, 2002 | **FULL**, as quoted in Artstein & Poesio |

**These are explicitly conventions, and the computational-linguistics literature says so in writing.**

**Artstein R, Poesio M. "Survey Article: Inter-Coder Agreement for Computational Linguistics." *Computational Linguistics* 34(4):555–596, 2008.** DOI: https://doi.org/10.1162/coli.07-034-R2 — **FULL, verbatim from local PDF extraction of https://aclanthology.org/J08-4004.pdf:**

> "Even after testing significance and establishing confidence intervals for agreement coefficients, we are still faced with the problem of interpreting the meaning of the resulting values. … **deciding what counts as an adequate level of agreement for a specific purpose is still little more than a black art**."

> "**the description of the 0.67 boundary in Krippendorff (1980) was actually 'highly tentative and cautious,'** and in later work Krippendorff clearly considers 0.8 the absolute minimum value of α to accept for any serious purpose: '**Even a cutoff point of α = .800 … is a pretty low standard**' (Krippendorff 2004a, page 242)."

> "**we doubt that a single cutoff point is appropriate for all purposes.** For some CL studies, particularly on discourse, useful corpora have been obtained while attaining reliability only at the 0.7 level. We agree therefore with Craggs and McGee Wood (2005) that **setting a specific agreement threshold should not be a prerequisite for publication**. Instead, as recommended by Di Eugenio and Glass (2004) and others, researchers should report in detail on the methodology that was followed in collecting the reliability data (number of coders, whether they coded independently, whether they relied exclusively on an annotation manual), whether agreement was statistically significant, and provide a confusion matrix or agreement table so that readers can find out whether overall figures of agreement hide disagreements on less common categories."

Their own position: "**if a threshold needs to be set, 0.8 is a good value**" — subject to the caveat above. They also note (Cohen 1960, p.44) that testing agreement against *chance* is trivial; the relevant question is deviation from *perfect* agreement, and the relevant notion of significance is a **confidence interval**.

**Wikipedia (SECONDARY, primary attribution NOT verified by me)** adds that "**Landis and Koch supplied no evidence to support it, basing it instead on personal opinion**" and that "these guidelines may be more harmful than helpful," because code prevalence, observer bias, and the number of categories all substantially influence kappa.

**Counter-position worth knowing:** Passonneau RJ, Carpenter B. "The Benefits of a Model of Annotation." **TACL 2:311–326, 2014.** DOI: https://doi.org/10.1162/tacl_a_00185 (Anthology ID Q14-1025) — "**Standard agreement measures for interannotator reliability are neither necessary nor sufficient to ensure a high quality corpus.**" A probabilistic annotation model yields a **per-item certainty measure** for each gold-standard label while **reducing cost to less than half** of the conventional approach. **Their specific statements about kappa thresholds and required annotators-per-item are NOT RETRIEVABLE from the anthology landing page.** — **ABSTRACT ONLY**

**If your labels are span- or retrieval-shaped rather than fixed-category:** Hripcsak G, Rothschild AS. "Agreement, the F-Measure, and Reliability in Information Retrieval." **JAMIA 12(3):296–298, 2005.** DOI: https://doi.org/10.1197/jamia.M1733 — PMID 15684123. When negative cases are uncountable or undefined, **κ approaches positive specific agreement, which is numerically identical to the average pairwise F-measure**. Use F, not κ. — **FULL (PMC). PRE-2023 but statistical, not superseded.**

### D3. What actually drives annotation agreement — meta-analysis of 96 studies / 346 indices

**Bayerl PS, Paul KI. "What Determines Inter-Coder Agreement in Manual Annotations? A Meta-Analytic Investigation." *Computational Linguistics* 37(4):699–725, 2011.** DOI: https://doi.org/10.1162/COLI_a_00074 — **FULL, via local `pypdf` extraction of https://aclanthology.org/J11-4004.pdf**

Synthesized **96 annotation studies** across three domains (word-sense disambiguation, prosodic transcription, phonetic transcription), based on **346 agreement indices**. Identified **seven significant moderators**.

| Moderator | Effect | Statistic |
|---|---|---|
| **Annotator training (yes/no)** | trained **81%** vs untrained **70%** mean agreement | Q_b = 9.90, p = 0.002 |
| **Training intensity** | **high 86% / low 75% / none 70%**. Phonetic transcription: **78% / 67% / 26%** (p < 0.01). Prosodic: high **93%** vs **83%** for the other two (p < 0.01). Word-sense disambiguation results were not replicated | Q_b = 20.09, p < 0.001 |
| **Number of annotators** | **More annotators → LOWER agreement** (negative β). Verbatim: "a general tendency for an increasing number of annotators to increase the difficulty in reaching agreement" | their Table 3 |
| **Number of categories in the coding scheme** | **β = −0.28, p < 0.001** overall; replicated in all three domains (WSD β = −0.29 p < 0.001 after removing one outlier; prosodic β = −0.21 p < 0.01; phonetic β = −0.22 p < 0.05). Implication: schemes should be as sparse as the reliability requirement allows | — |
| **Annotation purpose** | basis for (semi-)automatic annotation **86%**; scheme development **84%**; proof of data quality **81%**; reliability study **74%** | Q_b = 36.85, p < 0.001 |
| **Domain expertise** | **No significant effect overall** — experts **81%**, novices **81%** (Q_b = 0.84, p = 0.659). **But** within word-sense disambiguation, experts **88%** vs non-experts **73%** (p < 0.01). **Mixed groups agree less than homogeneous groups** | — |
| **Domain (baseline difficulty)** | word-sense disambiguation **78%**, prosodic transcription **86%**, phonetic transcription **75%** | Q_b = 46.92, p < 0.001 |

They also record that high thresholds are frequently unreachable in practice, citing the **i2b2 smoking-status challenge where agreement between medical experts reached only 60%** (Uzuner, Szolovits & Kohane 2006), and note that "values lower than 80% are generally considered too low for training sets."

### D4. Calibration sample sizes, double annotation, and adjudication

| Question | Answer |
|---|---|
| **Standard calibration sample size for NLP annotation** | **NOT ESTABLISHED.** No convention found in the NLP literature. Artstein & Poesio explicitly decline to set one and recommend reporting methodology plus a confusion matrix in place of hitting a number |
| **Sample size to *estimate* kappa (biostatistics)** | Bujang MA, Baharum N. "Guidelines of the minimum sample size requirements for Kappa agreement test." **Epidemiology Biostatistics and Public Health 14(2), 2017.** DOI: https://doi.org/10.2427/12267 — required N ranges from **2 to 698** depending on effect size, and **roughly doubles when marginal rating frequencies are unequal**. — **META ONLY.** Retrieved via Semantic Scholar Graph API; full text never read. The "abstract" text the fetcher returned reads like a paraphrase rather than a verbatim abstract, so **treat the 2–698 range as indicative, not quotable** |
| **Sample size to *train raters to* a kappa criterion (clinical)** | Tractenberg RE, Yumoto F, Jin S, Morris JC. "Sample size requirements for training to a kappa agreement criterion on Clinical Dementia Ratings." **Alzheimer Disease and Associated Disorders, 2010.** DOI: https://doi.org/10.1097/WAD.0b013e3181d489c6 — PMID 20473138, PMCID PMC2924444. Simulation study concludes "**testing raters on 5 or more patients per CDR level (total N=25)**" ensures 95% confidence. — **META ONLY** |
| **Reliability pilot-study size** | Bujang MA, Omar ED, Foo DHP, Hon YK. "Sample size determination for conducting a pilot study to assess reliability of a questionnaire." **Restorative Dentistry & Endodontics 49(1), 2024.** DOI: https://doi.org/10.5395/rde.2024.49.e3 — PMID 38449496, PMCID PMC10912549. Narrative review recommending "**a minimum sample size of 30 respondents**" after accounting for 20% non-response. — **META ONLY** |
| **An actually-used calibration set for an LLM-judge escalation threshold** | **500 examples**, δ = 0.1 — Jung, Brahman & Choi 2024, for both TL;DR and ChatArena. **This is the only empirically grounded number of this kind I found in the judge literature.** — **FULL** |
| **Double annotation + adjudication as a documented standard practice with prescribed sample sizes** | **NOT FOUND AFTER SEARCH.** See the non-findings section below for terms and databases tried |

---

## Explicit non-findings

| Question asked | Status |
|---|---|
| Threshold of judge–human agreement at which a judge may replace annotators | **NOT ESTABLISHED.** No paper proposes one. Jung et al. 2024 instead let the practitioner set the target (α) and report the coverage achieved at it — that is the field's current best framing |
| Minimum human gold-set size required to validate an LLM judge | **NOT ESTABLISHED.** The only empirical datapoint is 500 (Jung et al.'s calibration set) |
| An empirically grounded kappa acceptability threshold | **NOT ESTABLISHED.** All published bands are conventions. McHugh's ≥ 0.60 and Krippendorff's ≥ 0.800 are the two most citable, and Artstein & Poesio describe threshold-setting as "little more than a black art" |
| A calibrated-confidence threshold for auto-accepting a judge verdict | **NOT ESTABLISHED.** Verbalized confidence has ECE ≈ 0.22 even for GPT-4 as judge; use risk-controlled thresholding, not a fixed confidence cutoff |
| General cross-task effect size for reference-based vs reference-free LLM judging | **NOT FOUND AFTER SEARCH.** Only task-specific evidence exists (70% → 15% failure rate on math grading). **Terms tried:** "reference-free vs reference-based LLM evaluation effect size", "reference-guided judge correlation gain". **Databases/sources tried:** arXiv abstract pages, ar5iv full text of 2306.05685 and 2310.07641, ACL Anthology. Semantic Scholar keyword search was unavailable (WebSearch dead; the S2 search endpoint returned HTTP 429 on one attempt) |
| Per-technique gains for JudgeLM's swap augmentation / reference support / reference drop | **NOT FOUND.** arXiv landing page only (https://arxiv.org/abs/2310.17631); ar5iv full text not attempted due to remaining fetch budget |
| Numeric effect sizes for AutoCalibrate (https://arxiv.org/abs/2309.13308) and FLASK (https://arxiv.org/abs/2307.10928) | **NOT FOUND.** Both abstracts assert "significant" / "high" without numbers. Only landing pages were fetched |
| Verbosity-bias magnitude in Saito et al. (https://arxiv.org/abs/2310.10076) | **NOT FOUND.** The abstract states the direction of the effect only |
| Stureborg et al. self-consistency rates and score-distribution skew magnitudes | **NOT FOUND.** Landing page only (https://arxiv.org/abs/2405.01724) |
| Position-consistency and preference-fairness percentages in Shi et al. (https://arxiv.org/abs/2406.07791) | **NOT FOUND.** Abstract does not give them; ar5iv full text not attempted |
| Clinical / NLP double-annotation + adjudication protocol with prescribed sample sizes | **NOT FOUND AFTER SEARCH.** **Terms tried:** "clinical corpus annotation double annotation adjudication", "i2b2 annotation guidelines sample size", "Xia Yetisgen-Yildiz clinical corpus annotation challenges and strategies", "annotation calibration sample size NLP". **Databases/sources tried:** arXiv, ACL Anthology, PubMed Central, Semantic Scholar Graph API. The direct URL https://faculty.washington.edu/melihay/publications/BioTxtM2012.pdf returned **HTTP 404**. Bayerl & Paul quantify *training* and *annotator-count* effects but prescribe no adjudication protocol. The nearest formal alternative in the literature is Passonneau & Carpenter's probabilistic annotation model |
| Sim & Wright 2005 commentary on whether kappa benchmarks are arbitrary or empirically grounded | **NOT RETRIEVED.** Sim J, Wright CC. "The Kappa Statistic in Reliability Studies: Use, Interpretation, and Sample Size Requirements." *Physical Therapy* 85(3):257–268, 2005. DOI: https://doi.org/10.1093/ptj/85.3.257 — Oxford Academic full text is **PAYWALLED**; only the abstract was visible. **I did not substitute a guess** |
| Landis & Koch primary-source verbatim table | **NOT RETRIEVED FROM THE PRIMARY.** JSTOR failed to load; PubMed hit a cookie wall. Bands were taken from two reproductions and labeled as such above |

---

## What I could not complete

1. **WebSearch was unavailable for the entire task** (budget exhausted at 200/200 before my first call). Every paper here was reached by naming an arXiv ID, DOI, or anthology ID directly and fetching it. **I cannot claim coverage.** There may be relevant 2025–2026 work I had no mechanism to discover. Treat this as a deep dive on nameable papers, not a systematic review.
2. **Several papers are ABSTRACT ONLY where their full text would have contained the numbers requested** — flagged individually throughout. The largest such gaps: AutoCalibrate, FLASK, JudgeLM per-technique ablations, Saito's verbosity metric, Shi et al.'s position-consistency percentages, and Stureborg et al.'s consistency rates.
3. **Two threshold sources were blocked** — Landis & Koch's primary table (JSTOR load failure, PubMed cookie wall) and Sim & Wright 2005 (Oxford Academic paywall). I used verified reproductions and labeled them as reproductions rather than reconstructing the tables from memory.
4. **No documented standard for double-annotation / adjudication sample sizes in NLP or clinical annotation was found**, and I did not invent one.
5. **No numbers in this document were estimated, interpolated, or inferred.** The only approximations are the two MT-Bench self-enhancement values read off Figure 2b, which are labeled as figure-read in place.

---

## Resources used

arXiv abstract pages; **ar5iv.labs.arxiv.org full-text HTML** (by far the most productive fallback once WebSearch was gone); ACL Anthology (landing pages and PDFs); PubMed Central; JSTOR (**blocked — page failed to load**); PubMed (**cookie wall**); Oxford Academic (**paywalled**); Semantic Scholar Graph API (one HTTP 429, succeeded on retry); Wikipedia (**secondary, labeled as such wherever used**); and local `pypdf` text extraction for `aclanthology.org/J08-4004.pdf` (Artstein & Poesio), `aclanthology.org/J11-4004.pdf` (Bayerl & Paul), and `burrsettles.com/pub/settles.activelearning.pdf` (Settles).

**Verbatim extraction working files** (retained for verification):
- `C:\Users\baikj\.claude\projects\C--Users-baikj-desktop\52b4903e-156c-4e8b-b251-ec177309825b\tool-results\aptext.txt` — Artstein & Poesio threshold passages
- `C:\Users\baikj\.claude\projects\C--Users-baikj-desktop\52b4903e-156c-4e8b-b251-ec177309825b\tool-results\bayerl_hits.txt` — Bayerl & Paul moderator results
- `C:\Users\baikj\.claude\projects\C--Users-baikj-desktop\52b4903e-156c-4e8b-b251-ec177309825b\tool-results\settles.txt` — Settles active-learning cautions

---

## Recency flags

Every LLM-judge result cited is **2023–2025**. Items flagged **PRE-2023** — Kadavath 2022, Deutsch et al. 2022, Kamath et al. 2020, Settles 2009, Geifman & El-Yaniv 2017, Chaganty et al. 2018, plus the kappa literature (1960 / 1977 / 2005 / 2008 / 2011 / 2012) — are **statistical machinery or annotation methodology rather than LLM-judge claims**, so model progress does not supersede them.

The **one genuine staleness risk is Kadavath et al. 2022 on calibration**, which predates the RLHF-era calibration degradation documented by Tian et al. 2023.

---

## Headline takeaways for a subjective-judgment pipeline

1. **The "judges match humans at 80%+" claim is load-bearing on a narrow setting** — chat helpfulness, pairwise, ties dropped. On subjective tasks GPT-4o averages Cohen's κ = 0.28 across 20 NLP tasks, and more than half those datasets fall below moderate agreement. Toxicity and safety go negative.
2. **A different-family judge does not buy a clean judge.** Preference leakage measures 8.9% for same-family-different-series and 19–22% for teacher→student, against ~23.6% for literal self-judging.
3. **The strongest single reliability lever measured is a reference answer** (70% → 15% failure rate), not chain-of-thought (70% → 30%). Rationale-before-verdict helps; automatic CoT does not reliably.
4. **Do not gate on verbalized confidence** (ECE ≈ 0.22 even for GPT-4 as judge). Gate on a risk-controlled threshold calibrated on roughly 500 human-labeled examples; expect ~56–63% coverage at an 85–90% agreement guarantee.
5. **Dorner et al.'s bound is the ceiling on the whole ambition:** a judge no more accurate than the system it judges cannot cut required human labels by more than half.
6. **No kappa threshold in the literature is empirical.** If a number is required, McHugh's 0.60 (health) or Krippendorff's 0.80 (content analysis) are the citable conventions — and the write-up should state in plain words that they are conventions, not validated thresholds.
