# Measuring change in pragmatic / social communication: instruments, generalization, and the knowledge–performance gap

**Prepared:** 2026-09-12
**Agent:** outcome-research

---

## TOOL STATUS — READ FIRST

**WebSearch did NOT work.** It returned verbatim: *"Web search was not performed: this session has used its web search budget (200 of 200 WebSearch calls)."*

**I fell back entirely to WebFetch** against:
- Europe PMC REST API (`https://www.ebi.ac.uk/europepmc/webservices/rest/search?query=...&resultType=core&format=json`)
- Europe PMC full-text XML endpoints (`.../rest/PMC#######/fullTextXML`)
- PMC article pages (`pmc.ncbi.nlm.nih.gov`)
- Semantic Scholar Graph API
- Publisher pages (Pearson, PRO-ED, University of Manchester SCIP)

**Blocked during this session:** Wiley (`onlinelibrary.wiley.com`) 403 on both article and `pdfdirect` URLs; ASHA (`pubs.asha.org`) 403; CORE API 403; `research.manchester.ac.uk` 403; `scholar.archive.org` anti-scraping; DuckDuckGo HTML CAPTCHA. These blocks are the direct cause of the unresolved items below.

---

## WHAT I COULD NOT COMPLETE

Stated explicitly rather than filled in:

1. **TOPICC / TOPICC-2 inter-rater reliability** — NOT FOUND AFTER SEARCH. This is the most important gap for this project.
2. **SLDT (Social Language Development Test) psychometrics, subtest list, age bands, price** — NOT FOUND AFTER SEARCH.
3. **ACE 6-11 psychometrics** — NOT FOUND AFTER SEARCH.
4. **Adams et al. 2012 SCIP RCT exact effect sizes / CIs / p-values** — ABSTRACT ONLY; magnitudes unavailable.
5. **Schlosser 2004 specific GAS reliability figures** — ABSTRACT ONLY; the abstract says reliability "will be discussed" without giving numbers.

Full search terms and databases tried for each are in the **GAPS** section at the end.

---

## NAMING CORRECTION

The task brief listed *"AMP (Assessment of Comprehension and Expression) pragmatics subtests"*. **These are two different instruments:**

- **AMP = Assessment of Metapragmatics** (Collins, Lockton & Adams, 2014) — a research task using scripted films.
- **ACE 6-11 = Assessment of Comprehension and Expression 6-11** (Adams, Coke, Crutchley, Hesketh & Reeves, 2001) — a published UK language battery.

Both are covered separately below.

---

## POPULATION KEY

Used throughout. Every study below carries an explicit population flag.

| Abbrev | Meaning |
|---|---|
| **SCD / SPCD** | Social (pragmatic) communication disorder |
| **PLI** | Pragmatic language impairment |
| **DLD / SLI** | Developmental language disorder / specific language impairment |
| **ASD** | Autism spectrum disorder |
| **TD** | Typical development |

---

# A. INSTRUMENTS

## A1. Construct, level tapped, rater, referencing

| Instrument | Construct | Comprehension / Production / Generalization | Rater | Standardized? |
|---|---|---|---|---|
| **TOPICC** | Conversational pragmatic behaviour, 12 coded aspects, from a semi-structured conversation-elicitation task | **Production** (observed conversation with an examiner) | Trained clinician/researcher coder; blinded in the RCT | Criterion-referenced; no published norms found |
| **TOPICC-2** | Revised TOPICC; observational rating of conversational interaction | **Production** | Clinician/researcher | Criterion-referenced |
| **AMP** (Assessment of Metapragmatics) | Metapragmatic explicitation — identifying and describing pragmatic errors depicted in scripted films | **Comprehension / explicit knowledge** — explicitly *not* production | Examiner-scored; child responds | Research instrument; developmental reference data only |
| **ACE 6-11** | Receptive + expressive language incl. non-literal comprehension, inference | Mostly **comprehension**; some production | Clinician | Standardized (UK). Psychometrics NOT FOUND AFTER SEARCH |
| **SCIP-SCCheck** | Five social-communication difficulty areas (A–E: social context understanding, nonverbal communication, conversation aspects, inappropriate comments, non-literal language) | **Screening / eligibility — NOT a change measure** | Clinician | Criterion-referenced; used as inclusion criterion (min. 2 of 5) |
| **SCIP-GAS** | Parent-prioritised individualised communication goals | **Generalization** (goals set in family-relevant contexts) | Parent **and** practitioner, rated independently | Individualised; not norm-referenced |
| **SLDT** | Social language: taking perspective, making inferences, negotiation, multiple interpretations | **Comprehension / reasoning** about social language, not observed conversation | Clinician-administered direct test | Norm-referenced |
| **CCC-2** | 10 subscales of communication; Social Interaction Deviance Composite (SIDC) isolates pragmatic/social disproportion | **Generalization proxy** — everyday behaviour recalled by an informant | Parent (teacher version used in validation) | Norm-referenced |
| **CELF-5 Pragmatics Profile** | Pragmatic behaviours; now yields scaled scores | **Generalization proxy** (clinician judgement of typical behaviour) | Clinician | Norm-referenced (scaled scores) |
| **CELF-5 Pragmatics Activities Checklist** | Verbal/nonverbal behaviour in activity-based interaction | Production, observed | Clinician | **Criterion-referenced**, for planning |
| **Pragmatics Profile** (Dewart & Summers) | Everyday functional communication | **Generalization** | Parent/carer, structured interview | Criterion-referenced, descriptive |

**Source for SCIP-SCCheck area structure:** Adams et al. 2020 feasibility study full text, PMC7510260. No reliability statistics reported for it anywhere located.

## A2. Reliability figures, with the study each came from

### TOPICC / TOPICC-2
**NOT FOUND AFTER SEARCH.** No inter-rater, test-retest or internal-consistency figure retrieved.

- **Search terms tried:** `"Targeted Observation of Pragmatics in Children's Conversations"`; `TOPICC AND (reliability OR "inter-rater" OR psychometric OR development)`; `FULL_TEXT:"TOPICC" AND FULL_TEXT:"reliability"`; `FULL_TEXT:"Targeted Observation of Pragmatics"`; `TOPICC "Targeted Observation of Pragmatics" inter-rater reliability Adams`
- **Databases / sites tried:** Europe PMC REST API, PubMed, Semantic Scholar Graph API (DOI lookup), `sites.manchester.ac.uk/scip` plus `/resources/` and `/for-practitioners/` (both **404**), `scholar.archive.org`, CORE API, `research.manchester.ac.uk`, DuckDuckGo HTML
- **Blocked by:** Wiley **403** (article + `pdfdirect`), Manchester repo **403**, CORE API **403**, scholar.archive.org anti-scraping, DuckDuckGo **CAPTCHA**
- **Most likely location:** methods section of Adams et al. (2012) IJLCD full text. Requires institutional access.

### AMP
> *"satisfactory internal consistency and inter-rater reliability"* — **NO NUMERIC COEFFICIENTS given in the abstract.**

Developmental gradient: metapragmatic awareness on **74%** of items at age 6, rising to **95%** at ages 10–11. n = 40 TD + 48 communication-impaired, ages 6–11.

**ABSTRACT ONLY.** Collins A, Lockton E, Adams C (2014), *J Commun Disord* 52:31–43. DOI [10.1016/j.jcomdis.2014.07.001](https://doi.org/10.1016/j.jcomdis.2014.07.001), PMID 25173072.
**POPULATION: TD + mixed communication impairment.**

### CCC-2
- Internal consistency subscales **.66–.80**
- Test-retest **.86–.96**
- Inter-rater: subscales **.157–.559**; composites **.360–.790**
- Responsiveness: **NOT REPORTED**

**Source:** Pereira T, Lopes AC, Ramalho AM, Lousada M (2025), *Autism Dev Lang Impair* 10. DOI [10.1177/23969415251341251](https://doi.org/10.1177/23969415251341251), PMC12078967 — **FULL TEXT READ.**
**POPULATION of that review: autistic children (ASD).**

### CCC-2 SIDC
Parent–teacher inter-rater agreement **r = 0.79**.

**ABSTRACT ONLY.** Norbury CF, Nash M, Baird G, Bishop D (2004), *IJLCD* 39(3):345–364. DOI [10.1080/13682820410001654883](https://doi.org/10.1080/13682820410001654883), PMID 15204445.
**POPULATION: SLI, PLI and ASD** (n=87 special education + 24 Scotland + 27 clinic-referred).

### SLDT
**NOT FOUND AFTER SEARCH.**

- **Search terms tried:** `"Social Language Development Test"`; `FULL_TEXT:"Social Language Development Test"` (returned **hitCount 0**); `"Social Language Development Test" proedinc reliability normative update`
- **Databases / sites tried:** Europe PMC REST, `proedinc.com` (four different product URL patterns, **all 404**), proedinc.com search endpoint (returned unrelated products), DuckDuckGo HTML (**CAPTCHA**)
- **Only confirmed uses located:**
  - Adams & Gaile 2020 — **POPULATION: SPCD + HFASD**
  - D'Angelo EJ, Morelli N, Lincoln SH, Graber K, Tembulkar S, Gaudet A, Gonzalez-Heydrich J (2019), *Schizophrenia Research*. DOI [10.1016/j.schres.2018.07.028](https://doi.org/10.1016/j.schres.2018.07.028), PMID 30077431. n=81, ages 7–18. **POPULATION: psychosis-spectrum youth.** Found *"social language ability was not associated with social impairment."* **ABSTRACT ONLY.**

### CELF-5 Pragmatics Profile
**NO reliability figures on the publisher page.**
Source: [Pearson CELF-5 product page](https://www.pearsonassessments.com/store/usassessments/en/Store/Professional-Assessments/Speech-%26-Language/Clinical-Evaluation-of-Language-Fundamentals-%7C-Fifth-Edition/p/100000705.html), retrieved 2026-09-12.

### Pragmatics Profile (original)
None retrieved; the tool is *"out of print and outdated"* per its own revisers. Dutch derivative (EPV) norming n=390 / n=534, *"reliability scores are high"* — **no coefficients.**

**ABSTRACT ONLY.**
- Tan V, Smidt A, Herman G, Munro N, Summers S (2023), *IJLCD*. DOI [10.1111/1460-6984.12922](https://doi.org/10.1111/1460-6984.12922), PMID 37431989. Revised version: **64 questions**, skill-based rather than age-based, conditional logic.
- Cocquyt M, Mommaerts MY, Dewart H, Zink I (2015), *IJLCD*. DOI [10.1111/1460-6984.12167](https://doi.org/10.1111/1460-6984.12167), PMID 25950833. **POPULATION: infants 6–30 months, Dutch.**

### Adams & Bishop conversational coding scheme
> *"Exchange structure, turntaking, conversational repair and use of cohesive devices could be assessed with adequate inter-rater and test-retest reliability"* — **QUALITATIVE ONLY, no coefficients in abstract.**

n=57 language-impaired + 67 controls, ages 4–12.

**ABSTRACT ONLY.** Adams C, Bishop DV (1989), *Br J Disord Commun* 24(3):211–239. DOI [10.3109/13682828909019889](https://doi.org/10.3109/13682828909019889), PMID 2627544.
**POPULATION: semantic-pragmatic disorder subgroup within language impairment** — the historical label for what is now SCD.

### Bishop & Adams inappropriacy judgement
> *"adequate inter-rater reliability"*; *"test-retest correlations for inappropriacy were significant"* — **NO COEFFICIENTS.**

**ABSTRACT ONLY.** Bishop DV, Adams C (1989), *Br J Disord Commun* 24(3):241–263. DOI [10.3109/13682828909019890](https://doi.org/10.3109/13682828909019890), PMID 2627545.
**POPULATION: as above.**

## A3. Sensitivity to change — the single most important finding in Section A

> **"None of the standardized instruments reported responsiveness, and therefore nothing can be concluded about the ability to detect changes over time."**
>
> And: *"all present some evidence of validity and reliability, but none report responsiveness."*

**Pereira T, Lopes AC, Ramalho AM, Lousada M (2025).** Psychometric Properties of the Standardised Instruments that are Used to Measure (Pragmatic) Intervention Effects in Autistic Children: A Systematic Review. *Autism & Developmental Language Impairments* 10. DOI [10.1177/23969415251341251](https://doi.org/10.1177/23969415251341251), PMC12078967 — **FULL TEXT READ.**
**19 standardized instruments across 49 intervention studies, PRISMA. POPULATION: autistic children (ASD).**

Instruments covered: SRS-2, Vineland-II, SSQ, PLS-5, MSEL, SSRS/SSIS, TASSK-R, CSBS, ADOS-2, CASL, CCC-2, TPS, New RDLS, TL-ALPE, Bayley-III, BOSCC, ASSP, ABAS-II, EAC.
**It does NOT separately review CELF, SLDT, TOPICC, or the Pragmatics Profile.**

### Three comparators from that table worth attention

| Instrument | Reliability | Note |
|---|---|---|
| **BOSCC** (Brief Observation of Social Communication Change) | Inter-rater ICC **0.97–0.98**; test-retest ICC social-communication **0.89**, RRB **0.79**, core total **0.90**; internal consistency social communication α=**0.83**, repetitive behaviour α=**0.41** | **Best-documented observational option found.** Responsiveness NR |
| **ADOS-2** | Inter-rater **0.94–0.97**; test-retest **0.83–0.87**; internal consistency social affect α **0.87–0.92**, RRB α **0.51–0.66** | Responsiveness NR |
| **TASSK-R** (knowledge test used in PEERS trials) | Internal consistency **α = 0.56** | Flagged because much of the "knowledge gain" literature in Section C rests on it |

### Direct change evidence for the pragmatic instruments

**TOPICC-2 and SLDT "Making Inferences" were the ONLY secondary measures that improved** in the SCIP feasibility study.

Adams C, Gaile J (2020), *Res Dev Disabil* 105:103752. DOI [10.1016/j.ridd.2020.103752](https://doi.org/10.1016/j.ridd.2020.103752), PMID 32771922.
**POPULATION: SPCD + HFASD, n=20, ages 5–11.**

> ⚠️ **SINGLE-ARM FEASIBILITY, NO CONTROL GROUP** — "improvement" here cannot be separated from practice effects, regression to the mean, or maturation.

## A4. Age range, burden, publisher, licensing, item reproducibility

| Instrument | Age | Burden | Publisher / status | Items publicly reproducible? |
|---|---|---|---|---|
| **TOPICC / TOPICC-2** | Developed on 5;11–10;8 (SCIP RCT) | Conversation sample + 12-dimension coding; requires training | University of Manchester SCIP project, [sites.manchester.ac.uk/scip](https://sites.manchester.ac.uk/scip/). **LICENSING TERMS NOT CONFIRMED** — resources page 404'd | No — not published in the papers |
| **AMP** | 6–11 | Filmed stimuli + scored verbal responses | Research instrument (Manchester) | No |
| **ACE 6-11** | 6–11 | Full battery | GL Assessment (UK) — **NOT CONFIRMED** by retrieval | No — proprietary |
| **SCIP-SCCheck** | 5–11 | Brief 5-area checklist | Manchester SCIP | Area structure (A–E) described in the feasibility paper; items not published |
| **SCIP-GAS** | 5–11 (main trial revised to 6–11) | 3 parent goals + step-refinement at T1; ratings at T2. **100% questionnaire return** at both timepoints | Manchester SCIP | Individualised by design — nothing to reproduce |
| **SLDT** | Elementary and Adolescent versions exist | Direct test | Originally LinguiSystems, now **PRO-ED** | No — proprietary. Age bands and burden NOT FOUND AFTER SEARCH |
| **CCC-2** | **4–16** | ~70-item parent checklist | **Pearson**, qualification level B | No — proprietary |
| **CELF-5 Pragmatics Profile / Activities Checklist** | **5–21** | Profile scored within CELF-5; Checklist is an activity-based observation for planning | **Pearson**; kits from **$950.30**, also on Q-global; qualification level B (page retrieved 2026-09-12 — treat pricing as of that date) | No — proprietary |
| **Pragmatics Profile** | Preschool / school-age / adult versions | Structured parent interview; revised online version has **64 questions** with conditional logic | Originally NFER-Nelson, now **OUT OF PRINT**; revision via Tan et al. 2023 | Items not reproduced here |

### ⚠️ Warning on TOPICC age misuse

Alduais A, Majorano M, Bastianello T (2025), *Appl Neuropsychol Child* 14(1):29–45. DOI [10.1080/21622965.2023.2224483](https://doi.org/10.1080/21622965.2023.2224483), PMID 37337141.

Applied the TOPICC to Italian preschoolers aged **49–84 months** — **below the age band the instrument was developed on** — with n=15 in the clinical group and only **8 matched cases**. **No TOPICC psychometrics reported.**
**POPULATION: Italian preschoolers with and without neurodevelopmental disorders (mixed, NOT SCD).**
**Treat as weak evidence.**

---

# B. GENERALIZATION AND TRANSFER

## B1. Stokes & Baer (1977) — confirmed against the abstract

**NINE tactics, not eight.**

Stokes TF, Baer DM (1977). An implicit technology of generalization. *J Appl Behav Anal* 10(2):349–367. DOI [10.1901/jaba.1977.10-349](https://doi.org/10.1901/jaba.1977.10-349), PMID 16795561.

1. **Train and Hope** ✅ *(name confirmed verbatim)*
2. Sequential Modification
3. Introduce to Natural Maintaining Contingencies
4. Train Sufficient Exemplars
5. Train Loosely
6. Use Indiscriminable Contingencies
7. Program Common Stimuli
8. **Mediate Generalization** ✅ *(name confirmed verbatim)*
9. Train "To Generalize"

Framing: generalization had been treated as a byproduct of inadequate discrimination training, and *"generalization is equally deserving of an active conceptualization and technology."*

## B2. What the SCIP RCT actually reports — THIS CORRECTS AN ASSUMPTION IN THE BRIEF

Adams C, Lockton E, Freed J, Gaile J, Earl G, McBean K, Nash M, Green J, Vail A, Law J (2012). The Social Communication Intervention Project: a randomized controlled trial. *IJLCD* 47(3):233–244. DOI [10.1111/j.1460-6984.2011.00146.x](https://doi.org/10.1111/j.1460-6984.2011.00146.x), PMID 22512510.

> **ABSTRACT ONLY** — Wiley returned **403** on both the article page and the `pdfdirect` PDF.

**Design:** single-blind RCT, **n=88**, ages **5;11–10;8**, UK services, randomised **2:1** to SCIP vs treatment-as-usual, up to 20 sessions from specialist therapists, assessed pre / immediately post / 6-month follow-up, intention-to-treat.

**POPULATION: pragmatic language impairment / SCD, WITH OR WITHOUT ASD features.** The paper itself states roughly **75% overlap between PLI and ASD** in the sample. **This is NOT clean SCD evidence.**

| Outcome | Rater | Result |
|---|---|---|
| Structural language (**PRIMARY outcome**) | Standardized direct test | **NO significant effect** |
| Narrative ability | Direct | **NO significant effect** |
| Conversational competence | **BLIND-RATED OBSERVATION** | **SIGNIFICANT effect** |
| Pragmatic functioning | Parent report | **SIGNIFICANT effect** |
| Classroom learning skills | Teacher report | **SIGNIFICANT effect** |

### The pattern is NOT "parent-report moved, blinded observation did not"

In SCIP the **blind-rated conversational measure was AMONG THE POSITIVE FINDINGS**, and the null sat on the standardized structural-language primary outcome. The paper's own conclusion:

> *"evidence supports intervention effects on blind-rated and parent/teacher communication outcomes, though not standardized language measures."*

**Two caveats I could not resolve without full text:**
1. Exact effect sizes, CIs and p-values are **UNAVAILABLE** — the abstract gives direction and significance only.
2. The conversational competence rating came from an **elicited conversation with an examiner** — proximal / near-transfer, not an untrained naturalistic setting. The teacher-rated classroom measure is the closest thing to a far-transfer outcome in this trial.

### Companion papers (both ABSTRACT ONLY)

- Adams C, Lockton E, Gaile J, Earl G, Freed J (2012), *IJLCD* 47:245–256. DOI [10.1111/j.1460-6984.2012.00147.x](https://doi.org/10.1111/j.1460-6984.2012.00147.x), PMID 22512511. Implementation/fidelity; n=57; *"satisfactory treatment fidelity"*; only half of parents attended sessions. **POPULATION: PLI/SCD ± ASD.**
- Baxendale J, Lockton E, Adams C, Gaile J (2013), *IJLCD* 48(1):41–53, PMID 23317383. Parent and teacher perceptions. **POPULATION: PLI.**

## B3. Does pragmatic intervention generalize to untrained contexts?

### Parsons et al. (2017) — FULL TEXT READ

Parsons L, Cordier R, Munro N, Joosten A, Speyer R (2017). A systematic review of pragmatic language interventions for children with autism spectrum disorder. *PLoS One*. DOI [10.1371/journal.pone.0172242](https://doi.org/10.1371/journal.pone.0172242), PMID 28426832.
**POPULATION: ASD. 21 studies, 925 participants, ages 21 months–14 years.**

> *"The long-term effects of these interventions and the generalisation of learning to new contexts is largely unknown."*

And decisively:

> *"Outcome measurement often assessed pragmatic language in the context in which the intervention was administered or via a decontextualised assessment instrument, so conclusions cannot be drawn as to the generalisability of skills following these interventions."*

Follow-up data existed in only **9 papers**, 5 weeks–12 months post-intervention.

**Effect sizes:**

| Comparison | Hedges' g | 95% CI |
|---|---|---|
| Overall | **0.500** | 0.352–0.647 |
| Between-groups (intervention vs control) | **0.274** | 0.088–0.460 |
| Child + parent coaching | 0.760 | — |
| Child-focused only | 0.482 | — |
| Parent education only | **NON-SIGNIFICANT** | — |
| Clinic-based | 0.535 | — |
| School-based | 0.408 (approaching significance) | — |
| Home-based | **NON-SIGNIFICANT** | — |
| Group delivery | 0.553 | — |
| vs waitlist control | 0.518 | — |
| vs treatment-as-usual | **NON-SIGNIFICANT** | — |
| vs alternative treatment | **NON-SIGNIFICANT** | — |

Across 17 intervention groups: 24% large, 29% medium, 29% small effect.

On observational measures specifically: they *"produced only a small effect size in comparison to other types of outcome measures... further investigation of the psychometric properties of available instruments is required."*

**Zero studies covered adolescents 13–18.**

### Jensen de López et al. (2022) — FULL TEXT READ

Jensen de López KM, Kraljević JK, Struntze ELB (2022). *IJLCD* 57(4):764–781. DOI [10.1111/1460-6984.12716](https://doi.org/10.1111/1460-6984.12716), PMC9544814.
**POPULATION: DLD. 11 studies.**

Does not analyse generalization substantively. Recommends:

> *"future intervention studies include outcome measures with high levels of ecological validity to certify that there has been a transfer of the intervention to the everyday activities of the child."*

**NOTE:** this review **EXPLICITLY EXCLUDED Adams et al. 2012** as ASD-focused:

> *"we revealed dozens of systematic reviews on interventions that included pragmatic skills such as narrative (Adams et al., 2012) or conversation skills... but they mostly included populations of children with autism spectrum disorder."*

### Parsons et al. (2019)

Parsons L, Cordier R, Munro N, Joosten A (2019), *Int J Speech Lang Pathol*. DOI [10.1080/17549507.2018.1492630](https://doi.org/10.1080/17549507.2018.1492630), PMID 30175619. **POPULATION: ASD. ABSTRACT ONLY.**

> *"consideration should be given to using observational measures of pragmatic language away from the clinic environment to evaluate generalisation."*

## B4. Near-transfer vs far-transfer measurement design

> ⚠️ **There is NO communication-specific near/far transfer measurement literature I could locate.** Everything below is cognitive training. **ALL NON-COMMUNICATION POPULATIONS.** The design mechanism transfers; the effect sizes do not.

| Source | Population | Finding |
|---|---|---|
| **Wu et al. (2026)**, *Front Med*. DOI [10.3389/fmed.2026.1893135](https://doi.org/10.3389/fmed.2026.1893135), PMID 42583048 | Nephrology trainees | **THE MOST USEFUL DESIGN WARNING.** An explicit *"methodological cautionary tale"*: near-transfer scores were **5.6 points higher** while the study lacked far-transfer tasks entirely, identifying *"assessment-task alignment"* as a validity threat that **MASKS** whether generalizability occurred. **ABSTRACT ONLY** |
| **Wang et al. (2026)**, *Front Hum Neurosci*. DOI [10.3389/fnhum.2026.1902938](https://doi.org/10.3389/fnhum.2026.1902938), PMID 42609444 | Mixed adult | Meta-analysis, 23 studies: trained tasks **g = 0.191** significant; *"effects on untrained working-memory outcomes were smaller and not statistically significant."* **ABSTRACT ONLY** |
| **Vargek et al. (2026)**, *J Intell*. DOI [10.3390/jintelligence14040056](https://doi.org/10.3390/jintelligence14040056), PMID 42042237 | Older adults | Near-transfer prediction AUC **0.56–0.74**; *"models predicting far transfer demonstrated limited performance."* **ABSTRACT ONLY** |
| **Tommasi et al. (2026)**, *Front Child Adolesc Psychiatry*. DOI [10.3389/frcha.2026.1801077](https://doi.org/10.3389/frcha.2026.1801077), PMID 42199316 | Children, attention/EF | *"promising improvements primarily in near-transfer"* while *"transfer to untrained skills (far transfer) remain[s] limited."* **ABSTRACT ONLY** |
| **Tao et al. (2026)**, *J Intell*. DOI [10.3390/jintelligence14070140](https://doi.org/10.3390/jintelligence14070140), PMID 42505951 | School-age children, working memory | Asymmetric transfer; *"functional overlap between trained processes and task demands"* determines transfer success. **ABSTRACT ONLY** |

## B5. Practice effects, rater drift, regression to the mean

> ⚠️ **NO communication-assessment-specific literature found.** All below is neuropsychological or behavioural-observation methodology. **Populations noted individually.**

| Threat | Evidence | Population | Standard mitigation |
|---|---|---|---|
| **Practice effects** | Duff K et al. (2026), *Clin Neuropsychol* 40(6):1590–1605. DOI [10.1080/13854046.2025.2550356](https://doi.org/10.1080/13854046.2025.2550356), PMID 40844017. Significant improvement across **ONE WEEK** in 194 adults, p<.001, largest on memory tests. **ABSTRACT ONLY** | Older adults | Alternate forms |
| **Retest effects** | Wang Y et al. (2026), *JAMA Netw Open* 9(8):e2628782. DOI [10.1001/jamanetworkopen.2026.28782](https://doi.org/10.1001/jamanetworkopen.2026.28782), PMID 42584890. ACHIEVE secondary analysis, n=977: global cognition **β=0.11 (95% CI 0.07–0.15)**, executive **β=0.15 (0.10–0.20)**, memory **β=0.12 (0.06–0.18)** — *"approximately offsetting 1 year of model-estimated age-related cognitive decline."* **ABSTRACT ONLY** | Older adults | Statistical adjustment for retest |
| **Alternate/parallel forms — CONFIRMED EFFECTIVE** | Bergman I et al. (2025), *Scand J Psychol* 66(1):1–14. DOI [10.1111/sjop.13054](https://doi.org/10.1111/sjop.13054), PMID 39072723. n=149, 1-month retest: practice effects on speeded tests but **NOT** on *"reaction time, sustained attention, verbal memory and naming (alternate forms), nor visuospatial functions."* **ABSTRACT ONLY** | Healthy Swedish adults | Parallel forms |
| **Regression to the mean** | Aiello EN et al. (2024), *BMC Neurol* 24(1):427. DOI [10.1186/s12883-024-03920-9](https://doi.org/10.1186/s12883-024-03920-9), PMID 39497078. Regression-based reliable change indices account for baseline confounders; MoCA ICC=**0.67**, no practice effect (t(32)=0.29, p=.778). **ABSTRACT ONLY** | Non-demented Parkinson's disease | Regression-based RCIs, **not** simple difference scores |
| **Rater drift** | Basha SAJ et al. (2025), *Prev Sci*. DOI [10.1007/s11121-025-01864-1](https://doi.org/10.1007/s11121-025-01864-1), PMID 41491758. FIMP fidelity coding tracked over **17 YEARS**: *"year did not significantly contribute"* to scoring variability under systematic protocols. **THE ONLY DIRECT DRIFT EVIDENCE FOUND. ABSTRACT ONLY** | GenerationPMTO implementation raters (adults, not children) | Protocolised recalibration |

---

# C. KNOWLEDGE VS PERFORMANCE — THE CLEAREST EVIDENCE IN THIS REPORT

## C1. The headline meta-analysis

**Gates JA, Kang E, Lerner MD (2017).** Efficacy of group social skills interventions for youth with autism spectrum disorder: A systematic review and meta-analysis. *Clinical Psychology Review* 52:164–181. DOI [10.1016/j.cpr.2017.01.006](https://doi.org/10.1016/j.cpr.2017.01.006), PMID 28130983. **19 RCTs.**

> **POPULATION: ASD YOUTH — NOT SCD.**

Full abstract retrieved verbatim.

| Outcome category | Hedges' g | p |
|---|---|---|
| **Overall aggregate** | **0.51** | <0.001 |
| Self-report | 0.92 | <0.001 |
| Task-based measures | 0.58 | <0.001 |
| Parent-report | 0.47 | <0.001 |
| Observer-report | 0.40 | <0.001 |
| Teacher-report | — | **0.11 — NON-SIGNIFICANT** |
| **→ SOCIAL KNOWLEDGE** (moderator of self-report) | **1.15** | **<0.01** |
| **→ SOCIAL PERFORMANCE** (moderator of self-report) | **0.28** | **0.31 — NOT STATISTICALLY SIGNIFICANT** |

Verbatim — the self-report effect was:

> *"wholly attributable to youth reporting that they learned about skilled social behaviors (social knowledge; g=1.15, p<0.01), but not that they enacted them (social performance; g=0.28, p=0.31)."*

Authors' conclusion, verbatim: interventions *"may not generalize to school settings or self-reported social behavior."*

### Direct answer

**Yes — knowledge improved roughly 4× more than performance, and the performance effect was NOT statistically significant.** But the population is **ASD, not SCD.**

## C2. Corroboration

### Wolstencroft et al. (2018) — FULL TEXT READ

Wolstencroft J, Robinson L, Srinivasan R, Kerry E, Mandy W, Skuse D (2018), *J Autism Dev Disord* 48(7):2293–2307. DOI [10.1007/s10803-018-3485-1](https://doi.org/10.1007/s10803-018-3485-1), PMC5996019.

> **POPULATION: high-functioning ASD, VIQ ≥ 70, ages 6–25.** 8 studies in meta-analysis, 125 treatment / 121 waitlist.

| Measure | SMD | 95% CI | p |
|---|---|---|---|
| SRS total | **−0.85** | −1.12 to −0.59 | 0.000 (Z=6.35) |
| SRS Social Communication | −0.89 | −1.2 to −0.59 | 0.000 |
| SRS Restricted Interests / RRB | −0.9 | −1.23 to −0.57 | 0.000 |
| SRS Social Awareness | −0.57 | −0.87 to −0.28 | 0.000 |
| SRS Social Cognition | −0.53 | −0.98 to −0.09 | 0.019 |
| SRS Social Motivation | −0.55 | −1.02 to −0.07 | 0.023 |
| SSRS Social Skills subscale | 0.56 | 0.18 to 0.95 | 0.004 |
| SSRS Problem Behaviors | −0.55 | −1.13 to 0.03 | **0.06 — NON-SIGNIFICANT** |

**Moderators on SRS total:** parent groups −0.91 (−1.20 to −0.61) vs no parent groups −0.63 (−1.23 to −0.02), p=0.04; >40 hours −0.93 (−1.36 to −0.50) vs ≤40 hours −0.76 (−1.13 to −0.39); summer camp −0.90 vs weekly −0.77.

**Teacher reports: NON-SIGNIFICANT effects.**

**CRITICALLY, this meta-analysis COULD NOT TEST the knowledge/performance split.** Verbatim:

> *"In this review, the assessment of social skills acquisition is focused on changes in social performance as measured by parental report, because the GSSIs meeting our criteria for inclusion had in common parent-rated outcomes. We acknowledge that a more complete account would include social knowledge acquisition but the relevant data were lacking."*

It restates Gates' finding verbatim:

> *"Self-reports of knowledge acquisition were associated with large effect sizes in contrast to small effect sizes for parent and observer reports of performance. The self-report effect sizes appeared to be driven by increases in social knowledge rather than improvements in social performance."*

It recommends *"future trials distinguish gains in children's social knowledge from social performance."*

**Blinding warning, verbatim:**

> *"The incomplete blinding of outcome by participants, personnel and outcome assessors conferred a 'high risk' for all of the studies. A few studies did employ observational outcome measures (where the coders were blind to the participants' group status) but these were always used in conjunction with outcome measures where the assessors were not blind."*

**Bias warnings:** *"Parents are the most commonly used informants, but their reports are prone to expectancy bias."* And: *"A risk with participants rating themselves is that they tend to overestimate perceived improvements in their social skills."*

**On who can detect generalization:** *"Teachers and blinded study administrative assessors can report on whether changes of performance generalise to other settings, outside the family."*

### Gates et al. (2023) critical review — FULL TEXT READ

Gates JA, McNair ML, Richards JK, Lerner MD (2023). Social Knowledge & Performance in Autism: A Critical Review & Recommendations. *Clin Child Fam Psychol Rev* 26(3):665–689. DOI [10.1007/s10567-023-00449-0](https://doi.org/10.1007/s10567-023-00449-0), PMC10613329.
**POPULATION: ASD.**

**Gresham's (1997) framework:** social **ACQUISITION** deficits (*"not knowing what to do"*) vs social **PERFORMANCE** deficits (*"doing what they may know"*).

Conclusion: *"social knowledge deficits are neither definitional nor reliably related to outcomes in autism."*

Their reading of Gates 2017:

> *"large effect sizes are driven solely by self-reported increases in social knowledge measurement, while tools that look at teacher, parent, and observational data... find no change in intervention."*

**Criticism of knowledge tests:** instruments like TASSK and the Children's Assertive Behavior Scales *"assess social knowledge, via whether someone selects the appropriate... answer... but not whether they would necessarily enact that specific response in a real-world social situation."*

**Recommendations for measuring performance instead:**
1. Frequency-based rating — SSIS asks informants to rate **how often** a person engages in a skill.
2. Observed-behaviour instruments such as the Quality of Play Questionnaire, which *"captures observed behavior... measuring what a child/person did as opposed to what they know."*
3. Multi-informant, with self-report prioritised.
4. Outcomes that matter to the person — loneliness, depression, anxiety, connection, friendship quality.

### Gates et al. (2023) empirical companion

Gates JA, Gerber AH, Miller CE, Lerner MD (2023), *Child Development*. DOI [10.1111/cdev.13889](https://doi.org/10.1111/cdev.13889), PMID 36573397. n=211.

> *"performance deficits were most—and acquisition deficits least—prominent within autistic profiles."*

**POPULATION: ASD + non-autistic comparison. ABSTRACT ONLY.**

## C3. The only SCD-population study — and it points the other way

> ⚠️ **THIS IS THE ONLY STUDY IN SECTION C WHERE THE POPULATION IS ACTUALLY SCD.**

**Lockton E, Adams C, Collins A (2016).** Do children with social communication disorder have explicit knowledge of pragmatic rules they break? A comparison of conversational pragmatic ability and metapragmatic awareness. *IJLCD* 51(5):508–517. DOI [10.1111/1460-6984.12227](https://doi.org/10.1111/1460-6984.12227), PMID 26916221. Full abstract retrieved verbatim.

**POPULATION: n=39 children with SCD, ages 6;1–10;7, recruited from NHS speech and language therapy caseloads across the North West of England and South East Scotland.**

**Design:** AMP (metapragmatic knowledge, scripted films) vs TOPICC (observed conversational performance, 12 coded aspects), regression analysis.

**Findings:**
- Expressive language score was a **significant predictor** of TOPICC score.
- **AMP score, added into the regression model, did NOT explain a significant amount of unique variance in TOPICC score.**
- Over half of the children showed moderate or marked impairment in one or two pragmatic behaviours on TOPICC.
- On **just over half** of the occasions where a child showed moderate/marked impairment of a pragmatic rule on TOPICC, **the same child demonstrated metapragmatic awareness of that same rule** on AMP.
- On **25%** of occasions they demonstrated the most sophisticated level of metapragmatic explicitation.

**Authors' implication, verbatim:** it *"may be beneficial for speech and language therapy to focus on improving motivation for use and better understanding of the impact of one's own pragmatic performance on others, rather than solely teaching awareness of pragmatic rules that are already understood but not used."*

**This is a knowledge–performance dissociation measured WITHIN THE SAME CHILDREN in the SCD population** — stronger internal evidence than a between-informant meta-analytic moderator.
**Limits:** n=39, cross-sectional, **NO INTERVENTION ARM** — it shows the gap exists but not that intervention widens it.

### Related

Adams C, Lockton E, Collins A (2018), *J Speech Lang Hear Res* 61(3):604–618. DOI [10.1044/2017_JSLHR-L-17-0026](https://doi.org/10.1044/2017_JSLHR-L-17-0026), PMID 29471463. n=82.
**POPULATION: SCD vs DLD vs TD, ages 6–11.**

Both SCD and DLD groups had significantly lower MP scores than TD. **MP ability correlated with age and language ability but NOT with pragmatic impairment.** After controlling for language and age, SCD showed significantly lower social understanding than DLD.
**ABSTRACT ONLY** (ASHA 403).

---

# D. MULTIDIMENSIONAL CONVERSATIONAL OUTCOME

## D1. Goal Attainment Scaling

### Introduction to this field

Schlosser RW (2004). Goal attainment scaling as a clinical measurement technique in communication disorders: a critical review. *J Commun Disord* 37(3):217–239. DOI [10.1016/j.jcomdis.2003.09.003](https://doi.org/10.1016/j.jcomdis.2003.09.003), PMID 15063144.

Stated attributes: grading of goal achievement, comparability/aggregation across goals and clients, adaptability to ICF levels, versatility across populations, linkage to expected outcomes, team coordination.

> **ABSTRACT ONLY** — the abstract states *"Reliability and validity of GAS will be discussed"* **WITHOUT giving any figures.**
> **POPULATION: communication disorders generally.**

### The SCIP-GAS is NOT classic GAS

From the SCIP feasibility full text (**PMC7510260**): parents give **three** priority goals at baseline; each is rated:

| Score | Meaning |
|---|---|
| −1 | Got worse |
| 0 | No change |
| +1 / +2 | Partial achievement |
| **+3** | **Fully achieved — stipulated as "expected achievement"** |
| +4 | Slightly exceeded |
| +5 | Greatly exceeded |

Summed across three goals → a **0–15 total**. This is a per-goal progress rating summed, **NOT the Kiresuk & Sherman five-level T-score transformation.**

**Results, n=20:**
- Parent mean **6.75 (SD 3.1)**
- Practitioner mean **8.6 (SD 2.2)**
- **100% questionnaire return** at T1 and T2 for both SCIP-GAS and CCC-2
- **82.5%** of parent narrative comments supported their own SCIP-GAS ratings

**Interpretive bands stipulated by the SCIP team:**

| Score | Band |
|---|---|
| 0–3 | Not clinically significant |
| 4–5 | Borderline |
| 6–9 | Clinically significant |
| 10–15 | Highly significant |

> ⚠️ **THESE BANDS ARE THE SCIP TEAM'S OWN STIPULATION.** I found **NO independent validation and NO established cut score** for them.
> **STATUS: NOT ESTABLISHED.**

**POPULATION: SPCD + HFASD, n=20 (24 recruited), ages 5–11 (revised to 6–11 for main trial). Single-arm, no control.**

Adams C, Gaile J (2020), *Res Dev Disabil* 105:103752. DOI [10.1016/j.ridd.2020.103752](https://doi.org/10.1016/j.ridd.2020.103752), PMID 32771922.
Adams C, Gaile J, Roddam H, Baxendale J, Clitheroe L, Emsley R (2020), *Pilot Feasibility Stud* 6:137. DOI [10.1186/s40814-020-00658-2](https://doi.org/10.1186/s40814-020-00658-2), PMID 32983554, PMC7510260 — **FULL TEXT READ.**

### GAS reliability and criticism

| Source | Population | Finding |
|---|---|---|
| **Steenbeek D, Ketelaar M, Galama K, Gorter JW (2007)**, *Dev Med Child Neurol* 49(7):550–556. DOI [10.1111/j.1469-8749.2007.00550.x](https://doi.org/10.1111/j.1469-8749.2007.00550.x), PMID 17593130 | **Paediatric rehabilitation** (cerebral palsy etc., NOT communication) | Only 3 studies on GAS properties found. *"Interrater reliability had been investigated in one study and had been found to be good"* — **NO NUMERIC VALUE.** **NO studies examined content reliability.** *"insufficient knowledge about its reliability with children."* GAS judged *"a responsive method for individual goal setting and for treatment evaluation."* **ABSTRACT ONLY** |
| **Krasny-Pacini A, Evans J, Sohlberg MM, Chevignard M (2016)**, *Arch Phys Med Rehabil* 97(1):157–170. DOI [10.1016/j.apmr.2015.08.424](https://doi.org/10.1016/j.apmr.2015.08.424), PMID 26343173 | Rehabilitation research generally | *"GAS methodology is used with different levels of rigor"*; proposes appraisal criteria to *"increase awareness of potential sources of bias"*; states *"precision, validity, and reliability can be obtained when using GAS"* with proper implementation. **ABSTRACT ONLY** |
| **Krasny-Pacini A, Hiebel J, Pauly F, Godon S, Chevignard M (2013)**, *Ann Phys Rehabil Med* 56(3):212–230. DOI [10.1016/j.rehab.2013.02.002](https://doi.org/10.1016/j.rehab.2013.02.002), PMID 23562111 | Rehabilitation | Recommends setting the patient's initial level to **−2**, describing all five GAS levels in detail, and — **IMPORTANT HERE** — using *"medians and rank tests"* **GIVEN GAS'S ORDINAL NATURE.** Treating a GAS sum as interval data is a known error, which bears directly on the SCIP-GAS 0–15 sum. **ABSTRACT ONLY** |
| **Bard-Pondarré R, Villepinte C, Roumenoff F, Lebrault H, Bonnyaud C, Pradeau C, Bensmail D, Isner-Horobeti ME, Krasny-Pacini A (2023)**, *J Rehabil Med* 55:jrm6498. DOI [10.2340/jrm.v55.6498](https://doi.org/10.2340/jrm.v55.6498), PMC10301855 | Rehabilitation | **THE SHARPEST CRITICISM:** *"GAS is not a 'scale' but a heterogeneous group of methodologies"* lacking consensus quality standards; unresolved issues include *"definition of 0 level, time-frame and means employed to attain the goal."* **ABSTRACT ONLY** |
| **Budgett et al. (2026)**, PsyArXiv preprint. DOI [10.31234/osf.io/8bm6p_v1](https://doi.org/10.31234/osf.io/8bm6p_v1) | Psychosocial dementia trial | Inter-rater **ICC = 0.99**; intra-rater **Cohen's κ = 0.91**; GAS completion 86% at 6 months, 82% at 12 months; correlations with QoL measures *"significant but modest."* **⚠️ PREPRINT, NOT PEER REVIEWED** |
| **Haladay et al. (2026)**, *BMC Musculoskelet Disord*. DOI [10.1186/s12891-026-10033-6](https://doi.org/10.1186/s12891-026-10033-6), PMID 42216206 | Chronic low back pain, adults | GAS T-Score **ICC = 0.782**; 95% goal comparison agreement; training time 7 hours; implementation 9 minutes. **ABSTRACT ONLY** |

## D2. Conversational / behavioural coding measures and their published reliability

| Measure | Dimensions | Published reliability | Population |
|---|---|---|---|
| **Prutting & Kirchner Pragmatic Protocol** (1987), *J Speech Hear Disord* 52(2):105–119. DOI [10.1044/jshd.5202.105](https://doi.org/10.1044/jshd.5202.105), PMID 3573742 | Descriptive taxonomy, **30 parameters**. Four distinct profiles separated six diagnostic groups | **NO RELIABILITY FIGURES IN ABSTRACT. ABSTRACT ONLY** | Six mixed diagnostic groups |
| **Adams & Bishop (1989)** scheme. DOI [10.3109/13682828909019889](https://doi.org/10.3109/13682828909019889) | Exchange structure, turntaking, repairs, cohesion | *"adequate inter-rater and test-retest reliability"* — **QUALITATIVE ONLY** | Semantic-pragmatic disorder within language impairment; n=57 impaired + 67 controls, ages 4–12 |
| **Bishop & Adams (1989)** inappropriacy judgement. DOI [10.3109/13682828909019890](https://doi.org/10.3109/13682828909019890) | Conversational inappropriacy | *"adequate inter-rater reliability"*; *"test-retest correlations for inappropriacy were significant"* — **NO COEFFICIENTS** | As above |
| **Bishop DV, Chan J, Adams C, Hartley J, Weir F (2000)**, *Dev Psychopathol* 12(2):177–199. DOI [10.1017/s0954579400002042](https://doi.org/10.1017/s0954579400002042), PMID 10847623 | Conversational **responsiveness**. PLI subgroup *"more likely than control children to give no response"*, *"made very little use of nonverbal responses"* | **NO COEFFICIENTS IN ABSTRACT. ABSTRACT ONLY** | **SLI with a PLI subgroup**, n=18 ages 6–8 + matched controls |
| **Topic maintenance** — Abbot-Smith K, Matthews D, Bannard C, Nice J, Malkin L, Williams D, Hobson W (2025), *Autism* 29(3):684–697. DOI [10.1177/13623613241286610](https://doi.org/10.1177/13623613241286610), PMID 39431626 | Off-topic responses, generic minimal acknowledgments, topic-supporting responses (**62% base rate**). Within-group variability related to theory of mind and age in **both** groups | **INTER-RATER COEFFICIENTS NOT IN ABSTRACT. ABSTRACT ONLY** | **Autistic vs neurotypical**, ages 5–9, three studies |
| **BOSCC** (via Pereira 2025 full text) | Broad social communicative behaviour, direct observation | **Inter-rater ICC 0.97–0.98**; test-retest ICC social-communication **0.89**, RRB **0.79**, core total **0.90**. **BEST-DOCUMENTED OBSERVATIONAL OPTION FOUND** | ASD |

> **HONEST SUMMARY OF D2:** the classic conversational coding schemes in this field report reliability **QUALITATIVELY** (*"adequate"*) rather than numerically in their abstracts. I could not obtain the full texts — Taylor & Francis / *British Journal of Disorders of Communication* 1989 is not open access — to extract coefficients.

## D3. Referential communication / common ground task measures

| Source | Population | Measure |
|---|---|---|
| **Karin E, Geva R, Bar-Yehuda S, Estrugo Y, Bauminger-Zviely N (2026)**, *J Autism Dev Disord*. DOI [10.1007/s10803-024-06642-6](https://doi.org/10.1007/s10803-024-06642-6), PMID 39570556. **ABSTRACT ONLY** | **TD n=64, autistic n=84, ages 6–16** | **Tangram-card common ground task.** Efficiency = fewer words + shorter duration across **6 turns**. Both groups improved. Better motor skills and joint action synchronization correlated with more efficient CG performance; motor coordination **mediated** the group difference |
| **Karin E, Zviely NB, Estrugo Y, Sabag M, Geva R (2025)**, *Autism Research*. DOI [10.1002/aur.70006](https://doi.org/10.1002/aur.70006), PMID 40099346. **ABSTRACT ONLY** | **Autistic n=84, control n=56, ages 6–16** | Control dyads achieved common conceptualization *"faster and with fewer words."* Path analysis: vocabulary and theory of mind contributed **independently** to CG efficiency |
| **Bovet V, Knutsen D, Fossard M (2024)**, *Psychon Bull Rev*. DOI [10.3758/s13423-023-02359-2](https://doi.org/10.3758/s13423-023-02359-2), PMID 37582917. **ABSTRACT ONLY** | Adult dialogue studies | Systematic review of **DIRECT** measures (explicit questions about shared knowledge) vs **INDIRECT** measures (discourse analysis) of common ground in matching-task dialogues. **The right starting point for measure selection** |
| **Ćwiek A, Fuchs S, Pouw W, Kadavá Š (2026)**, *Behav Res Methods*. DOI [10.3758/s13428-026-03071-4](https://doi.org/10.3758/s13428-026-03071-4), PMID 42283796. **ABSTRACT ONLY** | Adults | Expressibility ratings across 207 concepts predicted guessability and fewer corrective attempts |

The tangram/matching-task paradigm gives the field's cleanest **objective, non-rater** metrics: **words-to-criterion, turns-to-criterion, time-to-criterion, and the slope of reduction across repeated rounds.**

> **NO PUBLISHED RELIABILITY COEFFICIENTS retrieved for these.**

## D4. Arguments against collapsing conversational quality into a single score

### Adams C (2002) — the most authoritative citation for this point, and from the SCIP author herself

Adams C (2002). Practitioner review: the assessment of language pragmatics. *J Child Psychol Psychiatry*. DOI [10.1111/1469-7610.00226](https://doi.org/10.1111/1469-7610.00226), PMID 12455920.
**POPULATION: child language pragmatics generally. ABSTRACT ONLY.**

> *"Formal testing of pragmatics has limited potential to reveal typical pragmatic abnormalities."*

Advocates multifaceted assessment spanning *"speech acts, conversational and narrative abilities, the understanding of implicature and intent"*, with naturalistic elicitation of communicative intent for younger children, rather than a single formal score. Calls for improved norms and research into inference, topic management and coherence.

### Others

| Source | Population | Argument |
|---|---|---|
| **Parsons et al. (2017)** PLoS One — FULL TEXT READ | ASD | *"Skills were usually targeted in isolation with just seven interventions targeting a combination of pragmatic language skills... Targeting skills in isolation neglects the dynamic and complex nature of social interactions."* And: *"The structured nature of standardised lab-based assessments fails to capture the complex dynamics of the social context and is often not the ideal assessment medium for children with ASD."* |
| **Gates et al. (2023)** PMC10613329 — FULL TEXT READ | ASD | Single knowledge scores fail because *"if an autistic person knows what to do in a social interaction... they should, theoretically, be able to do it"* — an assumption the data reject. Recommends frequency-based ratings, observed behaviour, multi-informant with self-report prioritised, and person-meaningful outcomes |
| **Taylor AL, Leitão S, Smart S et al. (2026)**, *IJLCD*. DOI [10.1111/1460-6984.70246](https://doi.org/10.1111/1460-6984.70246), PMID 41968406. **ABSTRACT ONLY** | Early-years school children, oral language | Multidimensional classification produced significantly **more** children in a stable-low group than a single cut-point method; *"the use of a multidimensional assessment may result in greater consistency of categorical classifications over time for students with language difficulties."* |
| **Morris F et al. (2026)**, *Children*. DOI [10.3390/children13050611](https://doi.org/10.3390/children13050611), PMID 42194137. **ABSTRACT ONLY** | **FASD**, sample sizes 77–274 | Divergent validity: CELF domains correlated with CCC Semantics and Coherence subdomains and GCC, but **no significant correlations between CCC Speech and any CELF domain** — subdomains are separable and composites conflate them |
| **Krasny-Pacini et al. (2013)** | Rehabilitation | GAS is **ordinal**; summing and averaging it is a statistical error — *"medians and rank tests"* recommended. **Applies directly to the SCIP-GAS 0–15 sum** |
| **Lee SC et al. (2026)**, *Autism Research*. DOI [10.1002/aur.70264](https://doi.org/10.1002/aur.70264), PMID 42260987. **ABSTRACT ONLY** | Preschool-to-school-age autistic and neurotypical | Rasch analysis established five levels of ToM performance; only 20% of items were comparable with neurotypical children, so composite scores would mask group differences |

---

# E. WHAT COULD BE AUTOMATED FROM TEXT — MY ANALYSIS, NOT A LITERATURE FINDING

> ⚠️ **FLAGGING CLEARLY: no source I read evaluated automated scoring of these constructs.** This mapping is my inference from how each measure is operationalised.

## Automatable — objective, no rater judgement

| Construct | Basis |
|---|---|
| **Referential efficiency** — words/turns/time to criterion, reduction slope across rounds | Karin et al. (2025, 2026) operationalise it exactly this way; it is counting, not judging |
| **Turn-taking mechanics** — interruptions, overlaps, response latency, no-response rate | Given timestamps. Adams & Bishop (1989) and Bishop et al. (2000) code precisely these; *"gave no response"* is machine-detectable |
| **Repair / clarification requests** — frequency, type, success | Discrete, lexically marked events in the Adams & Bishop scheme |
| **Cohesion** — referential and lexical ties | Classic computational discourse feature |

## Probably automatable with a labelled corpus

| Construct | Basis |
|---|---|
| **Topic maintenance** — on-topic / off-topic / generic minimal acknowledgment | Abbot-Smith et al. (2025) used exactly this three-way scheme with a 62% base rate |
| **Informativeness** | **PARTIAL** — tractable only in referential tasks where the target referent is known |
| **Metapragmatic knowledge (AMP-type)** | Scored from transcribed verbal responses to fixed stimuli. **BUT SEE THE WARNING BELOW** |

## NOT automatable from text

| Construct | Why |
|---|---|
| **"Inappropriacy" / global conversational quality judgement** | This is the rater's construct, and its human reliability is reported only as *"adequate"* with no coefficient (Bishop & Adams 1989) |
| **SCIP-GAS goal attainment** | Goals are idiosyncratic, parent-defined, and rated against family context |
| **CCC-2 / CELF-5 Pragmatics Profile** | Informant recall of behaviour across settings, not text. By construction |

## ⚠️ THE LOAD-BEARING WARNING FOR ANY AUTOMATION PLAN

The easiest construct to automate is metapragmatic **KNOWLEDGE**, and that is precisely the construct the evidence says **does NOT predict performance**:

- **Lockton et al. 2016** — AMP added no unique variance in TOPICC. **SCD population.**
- **Gates et al. 2017** — knowledge g=1.15 vs performance g=0.28, n.s. **ASD population.**

An automated pipeline that scores what is easy will measure the wrong thing and will show gains where behaviour has not changed. **The automatable measures that sit on the PERFORMANCE side of the divide are the referential-efficiency and turn-taking families, computed from an actual interaction transcript.**

## ⚠️ SECOND WARNING

Pereira et al. 2025 found that **not one of 19 standardized instruments reports responsiveness.** There is no established benchmark against which to validate an automated change score, and no published minimal important difference. Any threshold would have to be derived from your own data, not cited.

**STATUS: NOT ESTABLISHED.**

---

# GAPS — FULL SEARCH RECORD

### 1. TOPICC / TOPICC-2 inter-rater reliability — NOT FOUND AFTER SEARCH

- **Search terms:** `"Targeted Observation of Pragmatics in Children's Conversations"`; `TOPICC AND (reliability OR "inter-rater" OR psychometric OR development)`; `FULL_TEXT:"TOPICC" AND FULL_TEXT:"reliability"`; `FULL_TEXT:"Targeted Observation of Pragmatics"`; `TOPICC "Targeted Observation of Pragmatics" inter-rater reliability Adams`
- **Databases / sites:** Europe PMC REST API, PubMed, Semantic Scholar Graph API (DOI lookup), `sites.manchester.ac.uk/scip` plus `/resources/` and `/for-practitioners/` (both 404), `scholar.archive.org`, CORE API, `research.manchester.ac.uk`, DuckDuckGo HTML
- **Blocked by:** Wiley 403 (article + `pdfdirect`), Manchester repo 403, CORE API 403, scholar.archive.org anti-scraping, DuckDuckGo CAPTCHA
- **Most likely location:** methods section of Adams et al. 2012 IJLCD. **Requires institutional access.**

### 2. SLDT psychometrics / subtests / age bands / price — NOT FOUND AFTER SEARCH

- **Search terms:** `"Social Language Development Test"`; `FULL_TEXT:"Social Language Development Test"` (**hitCount 0**); `"Social Language Development Test" proedinc reliability normative update`
- **Databases / sites:** Europe PMC REST, `proedinc.com` (four product URL patterns, all 404), proedinc.com search endpoint (returned unrelated products), DuckDuckGo HTML (CAPTCHA)

### 3. ACE 6-11 psychometrics — NOT FOUND AFTER SEARCH

- **Search terms:** `"Assessment of Comprehension and Expression" OR "ACE 6-11"`
- **Database:** Europe PMC REST — returned 40 results, **none** about the instrument itself

### 4. Adams et al. 2012 exact effect sizes / CIs / p-values — ABSTRACT ONLY

Direction and statistical significance confirmed; magnitudes unavailable. Wiley 403.

### 5. Schlosser 2004 specific GAS reliability criticisms — ABSTRACT ONLY

The abstract states reliability and validity *"will be discussed"* without giving figures; full text not accessible.

---

# POPULATION CAVEAT — READ BEFORE USING SECTION C

> **NOTHING IN SECTION C IS SCD-POPULATION EVIDENCE EXCEPT LOCKTON ET AL. 2016.**

- Gates 2017, Gates 2023 (critical review), Gates 2023 (*Child Dev*), Wolstencroft 2018, Parsons 2017, Pereira 2025 — **ALL ASD**
- The SCIP trial sample was **PLI/SCD with ~75% ASD overlap** by the authors' own account — **not clean SCD either**
- Jensen de López 2022 — **DLD**
- Bishop/Adams 1989 — historical *"semantic-pragmatic disorder"* label within a language-impaired sample

### Why a clean SCD evidence base barely exists

Saul J, Griffiths S, Norbury CF (2023). Prevalence and functional impact of social (pragmatic) communication disorders. *J Child Psychol Psychiatry* 64(3):376–387. DOI [10.1111/jcpp.13705](https://doi.org/10.1111/jcpp.13705), PMC10087005. **ABSTRACT ONLY.**

**POPULATION: population-based community sample of 386 children aged 5–6**, identified via parent and teacher CCC-2.

> *"very few children had isolated social-communication difficulties (0-1.3%)"* whereas *"a larger proportion of children (range: 6.1-10.5%) had social-pragmatic skills outside the expected range alongside structural language difficulties and/or autism spectrum symptoms."*

---

# COMPLIANCE NOTES

- **No proprietary test items are reproduced anywhere in this report.**
- **No cut scores were invented.** The SCIP-GAS bands are attributed to their authors and explicitly marked **NOT ESTABLISHED**.
- **Every number carries a DOI or stable URL.**
- **No code was written.**
- Every study carries an explicit population flag (SCD/SPCD vs PLI vs DLD/SLI vs ASD vs TD vs other).
