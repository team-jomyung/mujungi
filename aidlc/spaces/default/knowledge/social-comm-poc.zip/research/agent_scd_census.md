# SCD / SPCD Direct-Evidence Census

> **TOOL STATUS: WebSearch DID NOT WORK — budget exhausted (200 of 200 WebSearch calls used in this session).**
> Every source below was gathered by falling back to WebFetch against: Europe PMC REST API (search + fullTextXML endpoints), PubMed search-result pages, Crossref REST API, OpenAlex API, Unpaywall API, and the Semantic Scholar Graph API.

Compiled 2026-09-12. Scope: direct empirical evidence on Social (Pragmatic) Communication Disorder (SCD / SPCD), DSM-5 code 315.39 / F80.82.

---

## 0. Two corrections to the task brief, before the rows

1. **AMP = "Assessment of Metapragmatics"** (Collins, Lockton & Adams 2014), a scripted-film task. It is **not** "Assessment of Comprehension and Expression". ACE (Adams 2001, GL Assessment) is a different instrument, used as a language measure in the SCIP studies.
   Source: <https://www.ebi.ac.uk/europepmc/webservices/rest/search?query=EXT_ID:26916221&resultType=core&format=json>

2. **"TOPICC" is ambiguous in bibliographic databases.** A Europe PMC keyword search for `TOPICC` returns 53 hits dominated by *Trichotomous Outcome Prediction in Critical Care*, a US paediatric ICU study (e.g. PMID 37456559). Only 3 of the hits are the pragmatics instrument. Any automated citation count for "TOPICC" is contaminated.

---

## 1. Summary table

| # | Source | N | Age | Language | Task type | Flag |
|---|---|---|---|---|---|---|
| 1 | Yuan & Dollaghan 2018 | 594 items / 206 consensus | n/a | English (US instruments) | Item-to-criterion mapping | DIRECT SCD (no participants) |
| 2 | Yuan & Dollaghan 2020 | SPCD 54 / ASD 278 / TC 274 | NOT IN ABSTRACT | English (US) | Parent questionnaire, retrospective DB | DIRECT SPCD-labelled, algorithmic |
| 3 | Lockton, Adams & Collins 2016 | 39 | 6;1–10;7 | English (UK) | Scripted films + semi-structured conversation | DIRECT SCD (Manchester usage) |
| 4 | Adams et al. 2012 SCIP RCT | 88 | 5;11–10;8 | English (UK) | Intervention trial + conversation rating | **PLI / ASD-adjacent — NOT SPCD** |
| 4b | Adams et al. 2012 implementation | 57 | school-age | English (UK) | Same trial, fidelity report | Same trial as #4 — do not sum |
| 5 | Adams et al. 2020 SCIP feasibility | 46 referred / 22 started / 20 completed | 5;0–10;11 | English (UK) | Single-arm intervention | DIRECT SPCD |
| 6 | Adams & Gaile 2020 | 20 | 5–11 | English (UK) | Intervention + TOPICC-2 + SLDT | DIRECT SPCD **+ HFASD mixed** |
| 7 | Adams, Lockton & Collins 2018 | 82 across 3 groups | 6–11 | English (UK) | Scripted films (AMP) | DIRECT SCD |
| 8 | Gaile & Adams 2018 | 5 children / 8 sessions | 5;11–10;3 | English (UK) | Filmed therapy, qualitative | DIRECT SPCD-labelled |
| 9 | Svindt & Surányi 2021 | SPCD 13 / ASD 19 / TD 39 | NOT IN ABSTRACT | Hungarian | Scripted sentence-picture verification | DIRECT SPCD |
| 10 | Mandy et al. 2017 | 1,081 total; 88 SPCD | 4–18 | English (UK) | Parent report (3Di, CCC, SDQ) | SPCD by algorithm |
| 11 | Saul, Griffiths & Norbury 2023 | 386 | 5–6 | English (UK) | CCC-2 algorithms, population sample | SPCD-criteria prevalence |
| 12 | Ellis Weismer et al. 2021 (IJLCD) | 393 | 13–14 | English (US) | Checklist, secondary database | SPCD by algorithm |
| 13 | Dame et al. 2024 | SCD 9 / ASD 10 | NOT IN ABSTRACT | French (inferred) | Standardised battery | DIRECT SCD, pilot scale |
| 14 | Gabbatore et al. 2025 | BES-NOS 16→14 / TD 16 | 7–15 (M=10.93) | Italian | ABaCo battery | **NOT diagnosed SPCD** |
| 15 | Azizpour et al. 2026 | SCD 60 / non-SCD 60 | 14–18 | Persian (inferred) | CAT-Q self-report | DIRECT SCD label, self-report |
| 16 | Gabbatore et al. 2023 | 18 studies reviewed | n/a | n/a | Systematic review | Review, not primary evidence |

---

## 2. Per-source rows

### Row 1 — Yuan H & Dollaghan C (2018)

**FLAG: DIRECT SCD (instrument study, no participants)**

- **Source:** Yuan H, Dollaghan C. "Measuring the Diagnostic Features of Social (Pragmatic) Communication Disorder: An Exploratory Study." *Am J Speech Lang Pathol* 2018;27(2):647–656.
- **DOI:** 10.1044/2018_AJSLP-16-0219 · **PMID** 29587307
- **URL:** <https://www.ebi.ac.uk/europepmc/webservices/rest/search?query=EXT_ID:29587307&resultType=core&format=json>
- **Population:** NONE. No human participants. Unit of analysis = test items.
- **Diagnosis / inclusion criterion:** N/A
- **N:** 594 items screened; **206 consensus-mapped items**
- **Age:** N/A · **Language:** English (US instruments)
- **Task type:** item-to-DSM-5-criterion mapping. Not conversation.
- **Number of items / categories:** 594 items identified; **4** DSM-5 SPCD diagnostic areas; raters mapped to **6 categories** (the 4 areas + "more than one" + "none"); **206** items assigned by *both* raters to the same SPCD feature.
- **Raters:** first author + **5 second raters**, each mapping subsets after a brief training process.
- **Inter-rater reliability:** percent agreement **76%–82%**; **Cohen's kappa .69–.76** ("substantial agreement").
- **WHICH SOURCE INSTRUMENTS WERE POOLED: NOT RETRIEVED.** The abstract says only "594 items from assessment tools commonly used to measure social communication abilities in people with pragmatic language impairment were identified" and "Sources and item numbers for the 206 items … are provided" — without naming them. Article is closed access (isOpenAccess = N; Unpaywall shows no OA location). **ABSTRACT ONLY for this field.**
- **Publicly accessible?** No. Paywalled (ASHA).
- **License / copyright limits:** standard ASHA copyright; the item lists sit inside the paywalled article.
- **CAUTION:** this is an item-mapping exercise, **not** empirical data on people with SPCD. Do not cite as evidence about SPCD speakers.
- **DISCREPANCY FLAGGED:** the Gabbatore et al. 2023 review states "594 records considered, 220 were assigned … to at least one of the four SPCD characteristics" (<https://www.ebi.ac.uk/europepmc/webservices/rest/PMC10468801/fullTextXML>). The primary abstract says **206**. 206 is the consensus figure from the source itself; 220 is unverified and may be a different count (e.g. first-author-only assignment) or a review error. **Use 206.**

### Row 2 — Yuan H & Dollaghan C (2020)

**FLAG: DIRECT SPCD-labelled but ALGORITHMIC, not diagnosed**

- **Source:** "Applying Item Response Theory Modeling to Identify Social (Pragmatic) Communication Disorder." *JSLHR* 2020;63(6):1916–1932.
- **DOI:** 10.1044/2020_JSLHR-19-00284 · **PMID** 32539641
- **URL:** <https://www.ebi.ac.uk/europepmc/webservices/rest/search?query=DOI%3A%2210.1044%2F2020_JSLHR-19-00284%22&resultType=core&format=json>
- **Population:** National Database for Autism Research (NDAR) records.
- **Diagnosis / inclusion criterion:** defined **retrospectively** from NDAR classifications + ADI-R responses. The paper's own word is "putative". Not clinician-diagnosed SPCD.
- **N:** putative SPCD **n = 54**; ASD n = 278; TC n = 274
- **Age: NOT REPORTED IN ABSTRACT** · **Language:** English (US)
- **Task type:** parent questionnaire (Social Communication Questionnaire–Lifetime), retrospective database. **No conversation data.**
- **Number of items / categories:** 7 social-communication items; 5 RRBI items
- **Inter-rater reliability:** not an inter-rater design; IRT model fit only.
- **Results:** the 7 SC items separated SPCD from TC at sensitivity **and** specificity **> 80%**; the 5 RRBI items separated SPCD from ASD at **< 70%**.
- **Publicly accessible?** No (closed).
- **ABSTRACT ONLY** (age, recruitment detail and IRT parameters not retrieved).

### Row 3 — Lockton E, Adams C & Collins A (2016)

**FLAG: DIRECT SCD (Manchester usage), conversation data**

- **Source:** "Do children with social communication disorder have explicit knowledge of pragmatic rules they break? A comparison of conversational pragmatic ability and metapragmatic awareness." *Int J Lang Commun Disord* 2016;51(5):508–517.
- **DOI:** 10.1111/1460-6984.12227 · **PMID** 26916221
- **URL:** <https://www.ebi.ac.uk/europepmc/webservices/rest/search?query=EXT_ID:26916221&resultType=core&format=json>
- **Population:** children with social communication disorder (CwSCD), recruited from NHS speech and language therapy caseloads across **North West England and South East Scotland**.
- **DIAGNOSIS / INCLUSION CRITERION: NOT RETRIEVED.** The abstract identifies them only as "CwSCD … recruited from NHS speech and language therapy caseloads". No test names, cut-offs, or ASD-exclusion procedure appear in the abstract. **ABSTRACT ONLY for this field.**
- **N:** 39 · **Age:** 6;1–10;7 · **Language:** English (UK)
- **Task type:** two tasks — (a) **AMP**, scripted films depicting pragmatic errors (**scripted**); (b) **TOPICC**, "a semi-structured conversation-elicitation task" (naturalistic but elicited, not free conversation).
- **Number of categories:** TOPICC — **12 aspects of pragmatics** coded for presence of impairment.
- **INTER-RATER RELIABILITY: NOT RETRIEVED** (not in abstract; full text inaccessible — see the access-failure table).
- **PAPER'S ACTUAL STATED CONCLUSION (verbatim):** "Findings indicate that some CwSCD have an awareness of the pragmatic rules they themselves violate in conversation. This finding suggests that, for some CwSCD, it may be beneficial for speech and language therapy to focus on improving motivation for use and better understanding of the impact of one's own pragmatic performance on others, rather than solely teaching awareness of pragmatic rules that are already understood but not used."
- **Key negative result (verbatim):** "Expressive language score was a significant predictor of TOPICC score. However, AMP score, when added into the regression model, did not explain a significant amount of unique variance in TOPICC score." Over half of CwSCD showed moderate or marked impairment in one or two pragmatic behaviours on TOPICC; on just over half of the occasions where a child showed moderate/marked impairment of a rule on TOPICC, the same child demonstrated MPA for that same rule on AMP; on 25% of occasions they demonstrated the most sophisticated level of MP explicitation.
- **Publicly accessible?** Bronze OA at Wiley per Unpaywall (publishedVersion, **license = null**), but the PDF endpoint serves a CAPTCHA to automated fetch. Effectively not machine-accessible.
- **CAUTION:** this is "SCD" as the Manchester group used the term around DSM-5's introduction; the same cohort lineage is elsewhere called PLI. Treat as SCD-labelled, **not** as DSM-5-diagnosed SPCD.

### Row 4 — Adams C et al. (2012) — the SCIP RCT

**FLAG: PLI / ASD-ADJACENT — NOT SPCD**

- **Source:** Adams C, Lockton E, Freed J, Gaile J, Earl G, McBean K, Nash M, Green J, Vail A, Law J. "The Social Communication Intervention Project: a randomized controlled trial of the effectiveness of speech and language therapy for school-age children who have pragmatic and social communication problems with or without autism spectrum disorder." *Int J Lang Commun Disord* 2012;47(3):233–244.
- **DOI:** 10.1111/j.1460-6984.2011.00146.x · **PMID** 22512510
- **URL:** <https://www.ebi.ac.uk/europepmc/webservices/rest/search?query=EXT_ID:22512510&resultType=core&format=json>
- **Population:** "pragmatic language impairment (PLI) or social communication disorder (SCD)", **with or without ASD**. Verbatim: "The substantial overlap between the presence of PLI and ASD (**75%**) across the whole cohort suggests that the intervention may also be applicable to some verbally able children with ASD who have pragmatic communication needs."
- **Diagnosis / inclusion criterion:** recruited from UK speech and language therapy services as having "pragmatic and social communication needs". Detailed criteria **NOT RETRIEVED** (full text CAPTCHA-blocked). **ABSTRACT ONLY for criteria.**
- **N:** **88** randomised, **2:1** to SCIP vs treatment-as-usual · **Age:** 5;11–10;8 · **Language:** English (UK)
- **Task type:** intervention trial; up to **20** sessions of direct intervention from a manual, delivered by a specialist research SLT working with supervised assistants.
- **Outcome measures used:** PRIMARY = structural language. SECONDARY = narrative; parent-reported pragmatic functioning and social communication; **blind-rated perceptions of conversational competence** (the TOPICC-based measure); teacher-reported ratings of classroom learning skills. Taken pre-intervention, immediately post-intervention, and at 6-month follow-up. Analysis by intention to treat.
- **WHAT CHANGED:** significant treatment effects for blind-rated perceptions of conversational competence, parent-reported pragmatic functioning and social communication, and teacher-reported classroom learning skills.
- **WHAT DID NOT:** no significant treatment effect for the primary outcome (structural language ability) or for narrative ability.
- **Inter-rater reliability: NOT RETRIEVED**
- **Publicly accessible?** Bronze OA listed at Wiley (license null), CAPTCHA-blocked.
- **CAUTION:** pre-DSM-5 recruitment; 75% of the cohort also had ASD features, which would **exclude** them from an SPCD diagnosis. Do not present this as direct SPCD evidence.

### Row 4b — Adams C et al. (2012) — SCIP implementation paper

**FLAG: same trial as Row 4**

- **Source:** Adams C, Lockton E, Gaile J, Earl G, Freed J. "Implementation of a manualized communication intervention for school-aged children with pragmatic and social communication needs in a randomized controlled trial: the Social Communication Intervention Project." *IJLCD* 2012;47(3):245–256.
- **DOI:** 10.1111/j.1460-6984.2012.00147.x · **PMID** 22512511
- **URL:** <https://www.ebi.ac.uk/europepmc/webservices/rest/search?query=EXT_ID:22512511&resultType=core&format=json>
- **N:** **57** school-aged children with complex pragmatic communication needs (CwPLI) received the manualised intervention.
- **Key intervention components named (verbatim):** "therapies aimed at improving conversation skills, narrative construction, comprehension monitoring, understanding of social cues and metapragmatic awareness."
- **Also reports:** delivery protocol, staffing requirements, a mapping procedure for individualisation, a school–therapy alliance checklist, and treatment fidelity (delivered vs planned content, quality of therapy).
- **Publicly accessible?** No.
- **OVERLAP: SAME TRIAL AS ROW 4 — DO NOT ADD 57 TO 88.**

### Row 5 — Adams C et al. (2020) — SCIP feasibility study

**FLAG: DIRECT SPCD · OPEN ACCESS**

- **Source:** Adams C, Gaile J, Roddam H, Baxendale J, Clitheroe L, Emsley R. "Evaluation of a manualised speech and language therapy programme for children with social communication disorder: the SCIP feasibility study." *Pilot Feasibility Stud* 2020;6:137.
- **DOI:** 10.1186/s40814-020-00658-2 · **PMID** 32983554 · **PMCID** PMC7510260 · **License CC BY**
- **Full text URL:** <https://www.ebi.ac.uk/europepmc/webservices/rest/PMC7510260/fullTextXML>
- **Trial registration:** ISRCTN48030419 (registered retrospectively, 1 January 2017)
- **N — INTERNAL DISCREPANCY INSIDE THE PAPER, FLAGGED:** the **abstract** says "Fifteen speech and language practitioners identified **24 children** aged 5–11 years with SPCD"; the **Methods** say "Forty-six children were referred to the study; **22 children started** intervention but only **20 completed**." **Use 20 completers.**
- **Age:** "aged between 5 years and 0 months and 10 years 11 months", mean 102 months (SD 19.50) · **Language:** English (UK, England)
- **INCLUSION CRITERIA (verbatim, three criteria):**
  - "non-verbal performance on Ravens Coloured Progressive Matrices centile ≥ 5"
  - "score in the communication impaired range (< 55) on the Children's Communication Checklist-2 General Communication Composite (CCC-2)"
  - "social communication problems as observed by the practitioner, defined as a minimum of two out of five social communication difficulties on the SCIP social communication checklist"
  - ADOS-2 Module 3 also administered.
- **Number of sessions:** "up to a maximum of **20 direct therapy sessions**", delivered in school or at home.
- **Measures named in this paper:** SCIP-GAS (primary endpoint; parents rated three individualised goals on a scale from **−1** "got worse" to **+5** "greatly exceeded"), CCC-2, CELF-4, ACE, ADOS-2 Module 3. Also practitioner audio-diaries, post-intervention interviews with 6 practitioners and 6 parents, and a Delphi expert-panel consultation on trial design.
- **TOPICC-2 and SLDT do not appear in this paper** — they are reported in the companion paper (Row 6).
- **Reliability:** **no inter-rater or intra-rater reliability statistics are reported.**
- **Results (verbatim):** "Outcomes analysis indicated all children except one made some progress on parent ratings; all children made progress on practitioner ratings."
- **Publicly accessible?** YES, CC BY.
- **Competing interests (verbatim):** "Adams and Gaile are the authors of the SCIP intervention programme and receive royalties from the publishers."
- **Funding:** NIHR Research for Patient Benefit, grant PB-PG-1014-35011.

### Row 6 — Adams C & Gaile J (2020) — the SCIP-GAS / TOPICC-2 / SLDT paper

**FLAG: DIRECT SPCD **+ HFASD MIXED****

- **Source:** "Evaluation of a parent preference-based outcome measure after intensive communication intervention for children with social (pragmatic) communication disorder and high-functioning autism spectrum disorder." *Res Dev Disabil* 2020;105:103752.
- **DOI:** 10.1016/j.ridd.2020.103752 · **PMID** 32771922
- **URL:** <https://www.ebi.ac.uk/europepmc/webservices/rest/search?query=EXT_ID:32771922&resultType=core&format=json>
- **Population:** children with SPCD **or** High-Functioning ASD — a **mixed** sample, not SPCD-pure.
- **Diagnosis / inclusion criterion:** "15 UK speech and language practitioners identified 20 children aged 5-11 years with pragmatics/language needs." Criterion detail **not in this abstract** — but see Row 5 criteria, same cohort.
- **N:** 20 · **Age:** 5–11 years · **Language:** English (UK)
- **Number of sessions:** 20 SCIP therapy sessions.
- **Task type:** intervention + observational conversation rating (TOPICC-2) + scripted test (SLDT).
- **Measures:** PRIMARY = **SCIP-GAS** goal attainment scale — at T1 parents provided three prioritised communication goals, refined into a series of steps; after intervention (T2) parents *and* practitioners independently rated each goal compared to T1, and parents provided a narrative on outcomes. SECONDARY = Children's Communication Checklist-2; **Social Language Development Test (SLDT)**; observational ratings of conversational interaction (**TOPICC-2**).
- **Results (verbatim):** "All children except one progressed on T2 SCIP-GAS parent outcomes. All children progressed on practitioner SCIP-GAS ratings. 82.5 % of parent comments supported their own SCIP-GAS ratings. Secondary outcomes measures: Only SLDT Making Inferences scores and TOPICC-2 ratings showed improvement at T2."
- **Inter-rater reliability: NOT REPORTED IN ABSTRACT — ABSTRACT ONLY.**
- **Publicly accessible?** NO. Unpaywall returns `"oa_status":"closed"`, `"oa_locations":[]` (<https://api.unpaywall.org/v2/10.1016/j.ridd.2020.103752?email=...>).
- **OVERLAP — DO NOT SUM WITH ROW 5.** The feasibility paper states verbatim: "Further discussion and analysis of clinical significance and outcomes of pragmatics intervention are presented elsewhere [36]." Same funder, same 15 practitioners, same n = 20 completers, same 20 sessions, same age band, same authors. These are **two reports of one cohort.** I could not read reference [36] itself to confirm the citation text — the reference-list entry was not returned by the fullTextXML extraction.

### Row 7 — Adams C, Lockton E & Collins A (2018)

**FLAG: DIRECT SCD**

- **Source:** "Metapragmatic Explicitation and Social Attribution in Social Communication Disorder and Developmental Language Disorder: A Comparative Study." *JSLHR* 2018;61(3):604–618.
- **DOI:** 10.1044/2017_JSLHR-L-17-0026 · **PMID** 29471463
- **URL:** <https://www.ebi.ac.uk/europepmc/webservices/rest/search?query=EXT_ID:29471463&resultType=core&format=json>
- **Population:** children with SCD, DLD, and typical language development.
- **N:** **82 total across three groups. PER-GROUP Ns NOT REPORTED IN ABSTRACT.**
- **Age:** 6–11 years · **Language:** English (UK)
- **Diagnosis / inclusion criterion: NOT RETRIEVED — ABSTRACT ONLY.**
- **Task type:** AMP only — an experimental task in which pragmatic errors are identified in **filmed (scripted) interactions**. **No conversation data.**
- **Scoring:** responses scored for complexity/type of explicitation (MP score) and attribution of social characteristics to the films' characters (SU score).
- **Results:** SCD and DLD both significantly below TD on MP score and explicitation sophistication. After controlling for language and age, the **SCD group scored significantly lower than the DLD group on SU**. MP scores correlated with age/language ability but **not** with pragmatic impairment.
- **Inter-rater reliability: NOT RETRIEVED — ABSTRACT ONLY.**
- **Publicly accessible?** No.
- **OVERLAP RISK:** the 39 CwSCD in Lockton 2016 and the SCD group here come from the same Manchester AMP programme and plausibly are the same children. **UNVERIFIED. DO NOT SUM Rows 3 and 7.**

### Row 8 — Gaile J & Adams C (2018)

**FLAG: DIRECT SPCD-labelled, therapy-process data**

- **Source:** "Metacognition in speech and language therapy for children with social (pragmatic) communication disorders: implications for a theory of therapy." *IJLCD* 2018;53(1):55–69.
- **DOI:** 10.1111/1460-6984.12326 · **PMID** 28621083
- **URL:** <https://www.ebi.ac.uk/europepmc/webservices/rest/search?query=EXT_ID:28621083&resultType=core&format=json>
- **N:** 5 children; 8 filmed therapy sessions analysed · **Age:** 5;11–10;3 · **Language:** English (UK)
- **Diagnosis / inclusion criterion: NOT RETRIEVED — ABSTRACT ONLY.**
- **Task type:** filmed therapy interaction, mixed inductive–deductive qualitative coding framework + thematic analysis. **Not** a standardised conversation elicitation.
- **Number of categories:** four themes — metacognitive person knowledge, task knowledge, strategy knowledge, and monitoring/control.
- **Reliability: NOT REPORTED IN ABSTRACT — ABSTRACT ONLY.**
- **Publicly accessible?** No.
- **OVERLAP:** likely drawn from the SCIP programme — relationship to Rows 4/5 **UNVERIFIED**.

### Row 9 — Svindt V & Surányi B (2021)

**FLAG: DIRECT SPCD, Hungarian**

- **Source:** "The comprehension of grammaticalized implicit meanings in SPCD and ASD children: A comparative study." *Int J Lang Commun Disord* 2021;56(6):1147.
- **DOI:** 10.1111/1460-6984.12657 · **PMID** 34453388
- **URL:** <https://www.ebi.ac.uk/europepmc/webservices/rest/search?query=AUTH%3A%22Svindt%22%20AND%20(pragmatic%20OR%20%22communication%20disorder%22)&resultType=core&format=json>
- **N:** **71 total — SPCD n = 13, ASD n = 19, TD controls n = 39**
- **Age: NOT REPORTED IN ABSTRACT** · **Language:** Hungarian
- **Diagnosis / inclusion criterion: NOT RETRIEVED — ABSTRACT ONLY.**
- **Task type:** **scripted** sentence–picture verification task assessing comprehension of implicatures, presuppositions and entailments. **No conversation data.**
- **Results (verbatim):** "While both children with SPCD and children with ASD performed significantly more poorly than the TD group, only the comprehension profile of the SPCD group differed significantly from that of the TD group." Performance correlated with theory of mind in ASD but with receptive grammar in SPCD. Conclusion: "the communicative impairments in ASD and in SPCD differ qualitatively, rather than quantitatively."
- **Inter-rater reliability: NOT REPORTED IN ABSTRACT.**
- **Publicly accessible?** No.
- **NOTE:** one of only ~6 "ad hoc experimental" SPCD studies identified by the Gabbatore 2023 review.

### Row 10 — Mandy W, Wang A, Lee I & Skuse D (2017)

**FLAG: SPCD BY ALGORITHM, large clinic sample**

- **Source:** "Evaluating social (pragmatic) communication disorder." *J Child Psychol Psychiatry* 2017;58(10):1166–1175.
- **DOI:** 10.1111/jcpp.12785 · **PMID** 28741680
- **URL:** <https://www.ebi.ac.uk/europepmc/webservices/rest/search?query=DOI%3A%2210.1111%2Fjcpp.12785%22&resultType=core&format=json>
- **Population:** young people who had attended a specialist social communication disorders clinic for children with fluent language and normal-range intelligence.
- **Diagnosis / inclusion criterion (verbatim):** "An algorithm was designed using 3Di and CCC items to implement DSM-5 SPCD criteria." **Algorithmic, not clinician-diagnosed.**
- **N:** **1,081 total; 88 met SPCD criteria; 801 met DSM-5 ASD criteria; 192 neither** ("clinical comparison group")
- **Age:** 4–18 · **Language:** English (UK)
- **Task type:** standardised parent-report only (Developmental, Dimensional and Diagnostic Interview [3Di]; Child Communication Checklist [CCC]; Strengths and Difficulties Questionnaire [SDQ]). **No conversation data.**
- **Results:** average interitem correlation among SPCD core symptoms **= .22** ("moderate degree"); SPCD cases had autistic social difficulties intermediate between ASD and the clinical comparison group; **63.5%** scored in the abnormal range of the SDQ Total Problems scale.
- **CONCLUSION (verbatim):** "We did not find evidence that SPCD is qualitatively distinct from ASD. Rather, it appears to lie on the borderlands of the autism spectrum, describing those with autistic traits that fall just below the threshold for an ASD diagnosis. SPCD may have clinical utility for identifying people with autistic traits that are insufficiently severe for ASD diagnosis, but who nevertheless require support."
- **Publicly accessible?** Accepted manuscript free at <https://discovery.ucl.ac.uk/1567611/1/Mandy%20et%20al.%20Accepted%20Version.pdf>
- **NOTE:** this is the strongest published challenge to SPCD's construct validity.

### Row 11 — Saul J, Griffiths S & Norbury CF (2023)

**FLAG: SPCD-CRITERIA prevalence study · OPEN ACCESS**

- **Source:** "Prevalence and functional impact of social (pragmatic) communication disorders." *J Child Psychol Psychiatry* 2023;64(3):376–387.
- **DOI:** 10.1111/jcpp.13705 · **PMID** 36114685 · **PMCID** PMC10087005 · **License CC BY**
- **URL:** <https://www.ebi.ac.uk/europepmc/webservices/rest/search?query=DOI%3A%2210.1111%2Fjcpp.13705%22&resultType=core&format=json>
- **Population:** population-based community sample.
- **Diagnosis / inclusion criterion (verbatim):** "We used parent and teacher responses to the CCC-2 to approximate inclusion (poor social-pragmatic skills) and exclusion (poor structural language skills or autistic symptomatology) criteria for social (pragmatic) communication disorder (SPCD)."
- **N:** 386 · **Age:** 5–6 years · **Language:** English (UK)
- **Task type:** checklist algorithms plus academic and behavioural outcome data. **No conversation data.**
- **HEADLINE NUMBERS (verbatim):** "Regardless of the diagnostic algorithm used, the resulting prevalence rates for social-pragmatic deficits indicated that very few children had isolated social-communication difficulties (**0-1.3%**). However, a larger proportion of children (range: **6.1-10.5%**) had social-pragmatic skills outside the expected range alongside structural language difficulties and/or autism spectrum symptoms, and this profile was associated with a range of adverse academic and behavioural outcomes."
- **Conclusion (verbatim):** "…these rarely occur in isolation. Exclusionary criteria that include structural language may lead to underidentification of individuals with social-pragmatic deficits that may benefit from tailored support and intervention."
- **Inter-rater reliability:** N/A (checklist study).
- **Publicly accessible?** YES, CC BY.
- **NOTE:** this is the number that constrains any claim about SPCD sample availability. Pure SPCD is ~0–1.3% at ages 5–6.

### Row 12 — Ellis Weismer S, Tomblin JB, Durkin MS, Bolt D & Palta M (2021)

**FLAG: SPCD BY ALGORITHM on pre-existing data**

- **Source:** "A preliminary epidemiologic study of social (pragmatic) communication disorder in the context of developmental language disorder." *Int J Lang Commun Disord* 2021;56(6):1235–1248.
- **DOI:** 10.1111/1460-6984.12664 · **PMID** 34383380
- **URL:** <https://www.ebi.ac.uk/europepmc/webservices/rest/search?query=DOI%3A%2210.1111%2F1460-6984.12664%22&resultType=core&format=json>
- **Population:** EpiSLI Database adolescents.
- **Diagnosis / inclusion criterion:** two case definitions based on DSM-5 criteria applied to the Children's Communication Checklist.
- **N:** 393 · **Age:** 13–14 · **Language:** English (US)
- **Task type:** checklist / secondary database analysis. **No conversation data.**
- **Results:** SCD prevalence **7%–11%** depending on definition. Where pragmatic deficits co-occurred with language deficits, SCD was significantly more common in children with prior language-disorder histories. Under the stricter "disproportionate pragmatic difficulty" definition, SCD distributed equally across groups, with male sex a significant risk factor.
- **Inter-rater reliability: NOT REPORTED IN ABSTRACT — ABSTRACT ONLY.**
- **Publicly accessible?** No.
- **COMPANION / OVERLAP:** Ellis Weismer et al. 2021, *J Autism Dev Disord* 51:2686, DOI 10.1007/s10803-020-04737-4 — same research programme. **POSSIBLE OVERLAP, DO NOT SUM.**

### Row 13 — Dame C et al. (2024)

**FLAG: DIRECT SCD, pilot scale · OPEN ACCESS**

- **Source:** "Developmental Profile of Children with Autism Spectrum Disorder Versus Social Communication Disorder: A Pilot Study." *Children (Basel)* 2024;11(10):1241.
- **DOI:** 10.3390/children11101241 · **PMID** 39457206 · **PMCID** PMC11506113 · **License CC BY**
- **URL:** <https://www.ebi.ac.uk/europepmc/webservices/rest/search?query=EXT_ID:39457206&resultType=core&format=json>
- **N:** **9 children with SCD vs 10 with ASD**
- **Age: NOT REPORTED IN ABSTRACT** · **Language:** French clinical setting **INFERRED from author affiliations — NOT STATED IN ABSTRACT**
- **Diagnosis / inclusion criterion:** clinical SCD vs ASD distinction per DSM-5 (absence of restricted and repetitive behaviours or interests). Detailed criterion **NOT RETRIEVED — ABSTRACT ONLY.**
- **Task type:** standardised battery — Vineland Adaptive Behavior Scales, ADOS, Short Sensory Profile, Bishop's Children's Communication Checklist, a pragmatics evaluation, WISC-IV. **No natural conversation corpus.**
- **Results:** ADOS total score and the second subtotal "Restricted and Repetitive Behaviors" significantly higher in ASD (*p* = 0.022); Vineland Socialization standard score significantly lower in ASD (mean 51 ± 19) than SCD (mean 80 ± 28), *p* = 0.037; working memory index significantly lower in ASD (*p* = 0.013).
- **Inter-rater reliability: NOT REPORTED IN ABSTRACT.**
- **Publicly accessible?** YES, CC BY.

### Row 14 — Gabbatore I, Marchetti Guerrini A & Bosco FM (2025)

**FLAG: NOT DIAGNOSED SPCD — hypothesised cases only · OPEN ACCESS**

- **Source:** "Looking for social pragmatic communication disorder in the complex world of Italian special needs: an exploratory study." *Sci Rep* 2025;15:348.
- **DOI:** 10.1038/s41598-024-83280-z · **PMID** 39747328 · **PMCID** PMC11696771 · **License CC BY-NC-ND**
- **Full text URL:** <https://www.ebi.ac.uk/europepmc/webservices/rest/PMC11696771/fullTextXML>
- **Population:** children with BES-NOS (Italian "special educational needs, not otherwise specified"), explicitly excluding children with certified diagnoses such as ADHD or SLD; plus TD controls.
- **DIAGNOSIS CRITERION: NO PARTICIPANT HAD AN SPCD DIAGNOSIS.** The study searches for undiagnosed cases via cluster analysis.
- **N:** 16 BES-NOS recruited, **14 analysed** (7 girls, 7 boys); 16 TD (6 females)
- **Age:** BES-NOS "age range was 7 to 15 years (M = 10.93; SD = 2.30)"; recruitment range stated as 7–16.
- **Language:** Italian ("Italian native speakers")
- **Task type:** ABaCo battery — "composed of five scales, i.e., linguistic, extralinguistic, paralinguistic, contextual, and conversational" with "**172 items** that include vis-à-vis interactions and short videos on various communicative phenomena". Partly scripted, partly interactive.
- **Number of categories:** 5 scales, 172 items.
- **INTER-RATER RELIABILITY:** verbatim finding — "No inter-rater reliability figures are reported in the Methods or Results sections."
- **Result:** cluster analysis flagged "Cluster 1, consisting of **8 children** (2 girls, 6 boys)" as possible undiagnosed SPCD.
- **Publicly accessible?** YES, CC BY-NC-ND (**ND = no derivatives**; do not adapt the text).
- **CAUTION: do not count these 8 children as SPCD participants.** They are hypothesised, unconfirmed cases.

### Row 15 — Azizpour A, Hemati Alamdarloo G, Shojaei S & Moradi S (2026)

**FLAG: DIRECT SCD label, self-report only · OPEN ACCESS**

- **Source:** "The hidden cost of fitting in: social camouflage in adolescents with social communication disorder." *Front Psychol* 2026;17:1839647.
- **DOI:** 10.3389/fpsyg.2026.1839647 · **PMID** 42325324 · **PMCID** PMC13279079 · **License CC BY**
- **URL:** <https://www.ebi.ac.uk/europepmc/webservices/rest/search?query=EXT_ID:42325324&resultType=core&format=json>
- **N:** **120 adolescents — 60 diagnosed with SCD, 60 without SCD**, matched on age, gender and educational level.
- **Age:** 14–18 · **Population:** Mashhad-Marghab region, Fars province, Iran · **Language:** Persian **INFERRED, NOT STATED IN ABSTRACT**
- **Diagnosis / inclusion criterion:** stated only as "diagnosed with SCD". **NOT RETRIEVED — ABSTRACT ONLY.**
- **Task type:** CAT-Q (Camouflaging Autistic Traits Questionnaire), self-report — captures compensation, masking and assimilation. **No conversation data.**
- **Results:** adolescents with SCD reported significantly higher overall social camouflaging than adolescents without SCD; male adolescents reported higher camouflaging than female adolescents.
- **Inter-rater reliability:** N/A (self-report).
- **Publicly accessible?** YES, CC BY.
- **NOTE:** this is the largest single diagnosed-SCD sample I found (n = 60), but it is self-report and the diagnostic pathway is unverified.
- **OVERLAP:** the same author team published "Intolerance of uncertainty in adolescents with and without social communication disorder: group and gender differences", *Front Psychiatry* 2026, DOI 10.3389/fpsyt.2026.1803782, PMID 42064161. **Almost certainly the same or an overlapping sample. DO NOT SUM.**

### Row 16 — Gabbatore I, Marchetti Guerrini A & Bosco FM (2023)

**REVIEW, not primary evidence · OPEN ACCESS**

- **Source:** "The fuzzy boundaries of the social (pragmatic) communication disorder (SPCD): Why the picture is still so confusing?" *Heliyon* 2023;9(8):e19062.
- **DOI:** 10.1016/j.heliyon.2023.e19062 · **PMID** 37664706 · **PMCID** PMC10468801 · OA
- **Full text URL:** <https://www.ebi.ac.uk/europepmc/webservices/rest/PMC10468801/fullTextXML>
- **Review method (verbatim):** databases "Medline (PubMed), Scopus, and Web of Science"; keywords "social pragmatic communication disorder", "DSM-5", "differential diagnosis", "child". Inclusion: "Articles published after 2013, when the DSM-5 was published and written in English. SPCD as a diagnostic label as a core topic." Exclusion: "Review, meta-analysis and expert opinions were excluded."
- **KEY FINDING (verbatim):** "the majority of the studies included in the review (**twelve out of eighteen**) were based on the analysis of data sets previously collected for other purposes." Only **6 of 18** were ad hoc experimental studies. "Of these eleven studies, seven aimed to differentiate between SPCD diagnosis and ASD."
- **On SPCD vs ASD (verbatim):** "Some authors suggested that SPCD could be considered a mild form of autism, encompassing all children who fall just below the thresholds for an ASD diagnosis." But "five out of six ad hoc experimental studies … highlighted that this category is a clear and distinct diagnostic entity that does not overlap with other diagnostic categories."
- **On SPCD vs PLI (verbatim):** "PLI may represent a subset of Specific Language Impairment (SLI)"; "In DSM-5, the diagnostic entity used to identify specific difficulties in pragmatics is SPCD." **The review does not equate PLI and SPCD.**
- **Use this for:** the defensible claim that fewer than ten studies worldwide have prospectively collected data from people identified as SPCD.
- **LIMITATION:** Table 1 of this review (the per-study sample/measure table) is rendered as **image panels** in the XML and could not be transcribed. I reconstructed the included-study set from the Crossref reference list instead: <https://api.crossref.org/works/10.1016/j.heliyon.2023.e19062>

---

## 3. TOPICC and TOPICC-2

### TOPICC (Targeted Observation of Pragmatics in Children's Conversations)

- **WHAT IT IS (VERIFIED):** "the Targeted Observation of Pragmatics in Children's Conversations (TOPICC), a semi-structured conversation-elicitation task from which 12 aspects of pragmatics were coded for presence of impairment."
  Source: Lockton et al. 2016 abstract, <https://www.ebi.ac.uk/europepmc/webservices/rest/search?query=EXT_ID:26916221&resultType=core&format=json>
- **NUMBER OF CATEGORIES (VERIFIED):** **12 aspects of pragmatics.**
- **PRIMARY CITATION**, found verbatim in the SCIP feasibility reference list: "Adams C, Lockton E, Gaile J, Freed J. Speech and language therapy in practice. 2011. TOPICCAL applications: assessing children's conversation skills: turning a research instrument into a clinical profile; pp. 7–9."
  This is a **trade-magazine article** — not peer-reviewed, not indexed in PubMed or Crossref. It is the only primary TOPICC citation I could locate.
- **SECONDARY DESCRIPTION:** Westby C. "Observational Pragmatics Scales: Targeted Observation of Pragmatics in Children's Conversation (TOPICC) Observation Scale." *Word of Mouth*, 2017. DOI 10.1177/1048395017692993c. Found via <https://api.crossref.org/works?query.bibliographic=Targeted+Observation+of+Pragmatics+in+Children%27s+Conversations+TOPICC+Adams> — paywalled, **content NOT READ**.
- **RELIABILITY FIGURES: NOT FOUND AFTER SEARCH.** No published inter-rater or intra-rater figure for TOPICC was retrievable from any open source.
- **ARE ITEMS PUBLICLY AVAILABLE / LICENSE / COPYRIGHT: NOT VERIFIED.** What *is* verified: the parent programme is commercial — "Adams C, Gaile J. The Social Communication Intervention Programme manual. Cheshire: Napier Hill Press; 2015" and the competing-interests statement "Adams and Gaile are the authors of the SCIP intervention programme and receive royalties from the publishers" (PMC7510260).
  **RECOMMENDATION: treat TOPICC as third-party copyrighted material until a licence is confirmed in writing. Do not reproduce its items.**

### TOPICC-2

- **VERIFIED:** it exists; used as "observational ratings of conversational interaction (TOPICC-2)" and was one of only two secondary measures showing improvement in Adams & Gaile 2020 (PMID 32771922).
- **NUMBER OF CATEGORIES, RATING SCALE, RELIABILITY, PUBLIC AVAILABILITY, LICENCE: NOT FOUND AFTER SEARCH.** No open description of TOPICC-2 exists in any source I could reach.
- Note: TOPICC-2 does not appear anywhere in the open-access SCIP feasibility paper's full text. I searched that full text for the strings "TOPICC", "SLDT", "Social Language Development" and "conversation"; only the 2011 TOPICCAL reference matched on "TOPICC", and "SLDT" / "Social Language Development" produced no hits at all.

---

## 4. Question 6 — studies with a diagnosed SCD/SPCD sample AND natural conversation data

This is the narrowest cell in the census. Complete list of what qualifies, and how weakly:

| Study | Conversation data? | Diagnosis strength |
|---|---|---|
| Lockton et al. 2016 (n=39) | YES — TOPICC semi-structured elicitation | "SCD" per NHS SLT caseload; criterion NOT RETRIEVABLE |
| Adams & Gaile 2020 (n=20) | YES — TOPICC-2 observational ratings | SPCD/HFASD **mixed**; CCC-2 <55 + practitioner checklist |
| Adams et al. 2012 RCT (n=88) | YES — blind-rated conversational competence | **PLI, 75% ASD overlap — not SPCD** |
| Gaile & Adams 2018 (n=5) | Therapy-session video, not conversation elicitation | SPCD-labelled |
| Every other row above | NO | — |

### NOT FOUND AFTER SEARCH

No study was found that recruited a **DSM-5 SPCD-diagnosed sample (with ASD excluded by formal assessment)** and collected and released a **natural conversation corpus**.

**Exact search terms tried:**

- `"social communication disorder" AND (conversation OR conversational)`
- `"social (pragmatic) communication disorder"`
- `"SPCD" OR "social (pragmatic) communication disorder" AND diagnos* AND PUB_YEAR:[2014 TO 2026]`
- `"Targeted Observation of Pragmatics"`
- `TOPICC AND pragmatics`
- `TOPICC AND (pragmatic OR conversation) AND OPEN_ACCESS:y`
- `"Targeted Observation of Pragmatics" AND OPEN_ACCESS:y`
- `"Social Communication Intervention Project"`
- `AUTH:"Adams C" AND "social communication" AND PUB_YEAR:[2013 TO 2026]`
- `AUTH:"Svindt V"` and `AUTH:"Svindt" AND (pragmatic OR "communication disorder")`
- `Lockton Adams Collins social communication disorder`
- `(pragmatic language OR pragmatics) AND "assessment tools" AND review AND OPEN_ACCESS:y AND FIRST_PDATE:[2018-01-01 TO 2026-12-31]`
- OpenAlex title-search `social pragmatic communication disorder` (sorted by citation count)
- OpenAlex title-search `social communication disorder` (sorted by citation count)
- OpenAlex full search `Targeted Observation of Pragmatics in Children's Conversations`
- Crossref bibliographic query `Targeted Observation of Pragmatics in Children's Conversations TOPICC Adams`
- Semantic Scholar query `Targeted Observation of Pragmatics in Children's Conversations`

**Databases / endpoints queried:** Europe PMC REST API (`/search` and `/PMC*/fullTextXML`), PubMed search-result pages, Crossref REST API (`/works`), OpenAlex API (`/works`), Unpaywall API (`/v2/{doi}`), Semantic Scholar Graph API, University of Manchester Research Explorer, archive.org Wayback availability API.

---

## 5. What I could not complete, and why

These are stated as gaps rather than filled in:

1. **Lockton 2016 Methods numbers** — diagnosis criterion, how ASD was handled, the TOPICC rating scale, and inter-rater reliability. The article is Bronze OA at Wiley, but the PDF endpoint serves a CAPTCHA to automated fetch; the r.jina.ai proxy hit the same wall; the Manchester Research Explorer record lists a submitted version but exposes no PDF; the fatcat/archive.org lookup refused connection. **I did not guess at these numbers.**
2. **Which source instruments Yuan & Dollaghan 2018 pooled.** Closed access, not named in the abstract, no OA copy anywhere per Unpaywall.
3. **TOPICC and TOPICC-2 reliability figures, TOPICC-2 item counts, and licence/copyright status.** The only primary TOPICC source is a 2011 trade-magazine article that is not indexed anywhere machine-readable; `socialcommunicationintervention.org` does not resolve (DNS NXDOMAIN) and has no Wayback snapshots.
4. **Per-group Ns for Adams, Lockton & Collins 2018** (N = 82 across three groups). Closed access, not in the abstract.
5. **Confirming reference [36] of the SCIP feasibility paper**, which would definitively prove the Row 5 / Row 6 cohort overlap. The fullTextXML extraction did not return that reference-list entry. The overlap is strongly evidenced by matching funder, practitioner count, N, session count, age band and authorship — but it remains **inference, not a quoted citation**.
6. **Table 1 of the Gabbatore 2023 review** (per-study samples and measures) is rendered as image panels in the XML and could not be transcribed. The included-study set was reconstructed from the Crossref reference list instead.

---

## 6. Access failures — for the record

| Target | Method | Result |
|---|---|---|
| WebSearch | tool | **BUDGET EXHAUSTED, 200/200** |
| pubmed.ncbi.nlm.nih.gov abstract pages | WebFetch | Cookie wall (search-**result** pages work; abstract pages do not) |
| Wiley `pdfdirect` (Lockton 2016, SCIP RCT) | WebFetch + r.jina.ai proxy | CAPTCHA / 403 |
| europepmc.org/article/MED/... HTML | WebFetch | Nav shell only (the REST API works) |
| research.manchester.ac.uk search page | WebFetch | 403 (direct publication-UUID URL works) |
| socialcommunicationintervention.org | WebFetch | DNS NXDOMAIN; archive.org Wayback: **no snapshots** |
| api.fatcat.wiki | WebFetch | ECONNREFUSED |
| DuckDuckGo html + lite | WebFetch | CAPTCHA |
| Mojeek | WebFetch | 403 |
| Bing RSS | WebFetch | Returned unrelated cached results (YouTube pages) |
| Timler 2021 ASHA test-accuracy review (would have tabulated TOPICC) | Unpaywall | `oa_status: closed`, no locations |
| Semantic Scholar (first attempt) | WebFetch | 429; succeeded on retry |
| Heliyon review Table 1 | PMC fullTextXML | Rendered as image panels, not transcribable |

---

## 7. Three things worth carrying into the research document

1. **The direct-SPCD empirical base is roughly a dozen studies, most of them secondary analyses of datasets collected for autism research.** Gabbatore 2023: 12 of 18 reused existing data; only 6 were purpose-built.
2. **Isolated SPCD is rare in the population — 0–1.3% at ages 5–6** (Saul et al. 2023, CC BY, PMC10087005). Any plan that assumes a recruitable SPCD-pure sample should state this.
3. **SPCD's construct validity is contested in print.** Mandy et al. 2017 (N = 1,081): "We did not find evidence that SPCD is qualitatively distinct from ASD." Svindt & Surányi 2021 argues the opposite from n = 13. The document should not present SPCD as a settled category.
