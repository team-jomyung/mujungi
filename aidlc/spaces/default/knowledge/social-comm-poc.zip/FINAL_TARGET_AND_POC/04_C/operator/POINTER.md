# 진행자 꾸러미는 packages/ 에 있다

`../../01_A1/packages/c_operator/`

`build_packages.py` 가 만든다. 여기 사본을 두지 않는다.
내용 · README · POC_C_FINAL_PROTOCOL.md · personal_event_schema.json
