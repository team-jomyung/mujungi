# 참가자 꾸러미는 packages/ 에 있다

`../../01_A1/packages/c_participant/`

`build_packages.py` 가 만든다. 여기 사본을 두지 않는다.
내용 · README · 동의서 · 참가자 안내 · 입력 시험판 HTML
