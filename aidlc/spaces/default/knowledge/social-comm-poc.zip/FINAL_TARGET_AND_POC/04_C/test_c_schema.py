# -*- coding: utf-8 -*-
"""개인 사건 스키마가 규칙을 지키는가.

    python test_c_schema.py

무엇을 보나
  1 상대의 속마음을 사실로 저장하는 필드가 없는가
  2 인식 상태 다섯이 다 있는가
  3 재확인 필드 셋이 표시돼 있는가
  4 제3자 PII 차단 필드가 있는가

**심어 보고 터지는지도 확인한다.** 조용히 통과하는 검사는 없는 것만 못하다.
이 저장소에서 그 일이 세 번 있었다.
"""
from __future__ import annotations

import copy
import io
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
SCHEMA = os.path.join(HERE, 'personal_event_schema.json')
BANNED = ('partner_true_intent', 'partner_true_emotion', 'true_motive',
          'partner_intent', 'partner_emotion', 'unobserved_motive')
STATES = ('OBSERVED', 'INFERRED', 'POSSIBLE_INTERPRETATION',
          'USER_CONFIRMED', 'VALIDATED')
RECONFIRM = ('relationship', 'difficult_turn', 'user_goal')


def names_of(o, acc):
    if isinstance(o, dict):
        for k, v in o.items():
            acc.add(k)
            names_of(v, acc)
    elif isinstance(o, list):
        for v in o:
            names_of(v, acc)
    return acc


def check(sch):
    bad = []
    for n in names_of(sch, set()):
        if n.lower() in BANNED:
            bad.append('상대의 속마음을 사실로 저장하는 필드 · %s' % n)
    txt = json.dumps(sch, ensure_ascii=False)
    for s in STATES:
        if s not in txt:
            bad.append('인식 상태가 빠졌다 · %s' % s)
    flds = sch.get('fields', {})
    for f in RECONFIRM:
        if f not in flds:
            bad.append('재확인 필드가 없다 · %s' % f)
        elif not flds[f].get('reconfirm_at_24_72h'):
            bad.append('재확인 표시가 없다 · %s' % f)
    if 'third_party_pii_removed' not in flds:
        bad.append('제3자 PII 차단 필드가 없다')
    return bad


def drop_state(d):
    d['epistemic_states'] = {k: v for k, v in d['epistemic_states'].items()
                             if k != 'VALIDATED'}
    # 본문 어디에도 안 남아야 실제로 빠진 것이다
    d.pop('why_epistemic_state', None)
    for f in d.get('fields', {}).values():
        if isinstance(f, dict) and isinstance(f.get('epistemic_state'), list):
            f['epistemic_state'] = [x for x in f['epistemic_state'] if x != 'VALIDATED']
        if isinstance(f, dict) and isinstance(f.get('item_schema'), dict):
            st = f['item_schema'].get('state')
            if isinstance(st, str):
                f['item_schema']['state'] = st.replace('| VALIDATED', '')
        if isinstance(f, dict) and isinstance(f.get('note'), list):
            f['note'] = [x for x in f['note'] if 'VALIDATED' not in x]


def main():
    if not os.path.exists(SCHEMA):
        print('스키마가 없다 · %s' % SCHEMA)
        return 2
    sch = json.load(io.open(SCHEMA, encoding='utf-8'))
    bad = check(sch)
    print('  필드 이름 %d개 · 문제 %d' % (len(names_of(sch, set())), len(bad)))
    for x in bad:
        print('    FAIL · %s' % x)
    if bad:
        return 1

    cases = [
        ('금지 필드를 넣는다',
         lambda d: d['fields'].__setitem__('partner_true_intent', {'type': 'str'})),
        ('인식 상태를 하나 뺀다', drop_state),
        ('재확인 표시를 끈다',
         lambda d: d['fields']['relationship'].__setitem__('reconfirm_at_24_72h', False)),
        ('제3자 차단 필드를 뺀다',
         lambda d: d['fields'].pop('third_party_pii_removed', None)),
    ]
    fired = 0
    for label, mut in cases:
        d = copy.deepcopy(sch)
        mut(d)
        if check(d):
            fired += 1
        else:
            print('    >>> "%s" 를 해도 안 터진다' % label)
    print('  심은 결함 %d개 중 %d개가 터졌다' % (len(cases), fired))
    if fired != len(cases):
        return 1
    print('  ok')
    return 0


if __name__ == '__main__':
    sys.exit(main())
