# -*- coding: utf-8 -*-
"""POC B 를 dry-run 으로 돌린다. 경로를 손으로 적지 않는다.

    python run_poc_b.py --out _dryrun

**A1 · A2 가 끝나기 전에는 이 결과가 검증이 아니다.** 배선 확인이다.
생성기 본체는 `runtime_deps.py` 가 찾는다 (배포본이면 runtime/ · 저장소면 FINAL_CLOSURE).
"""
from __future__ import annotations

import argparse
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))


def main(argv):
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', default=os.path.join(HERE, '_dryrun'))
    a = ap.parse_args(argv)
    out = a.out if os.path.isabs(a.out) else os.path.join(HERE, a.out)
    if not os.path.isdir(out):
        os.makedirs(out)

    import runtime_deps as RD
    missing = RD.add_paths(['generator', 'rule_engine'])
    if missing:
        ok, lines = RD.check()
        print('생성기를 못 찾았다 · %s' % missing)
        for x in lines:
            print('  ' + x)
        return 2
    gen = RD.resolve('generator')
    env = dict(os.environ, PYTHONIOENCODING='utf-8')
    # rule_engine 이 있는 폴더를 자식 프로세스가 찾을 수 있게 넘긴다.
    # 저장소에서는 poc_validation_v0_1/02_POC_A, 배포본에서는 runtime/rule_engine 이다
    env['PYTHONPATH'] = os.pathsep.join(
        [RD.resolve('rule_engine') or '', gen, env.get('PYTHONPATH', '')])

    steps = [('변형 계획', ['variation_plan.py']),
             ('생성 dry-run', ['run_generation.py', '--dry-run',
                             '--out', os.path.join(out, 'poc_b_dryrun')])]
    bad = 0
    for label, args in steps:
        p = subprocess.run([sys.executable] + args, cwd=gen, capture_output=True,
                           text=True, encoding='utf-8', errors='replace', env=env)
        tail = (p.stdout or '').strip().split(chr(10))
        print('  %-16s %-4s %s' % (label, 'ok' if p.returncode == 0 else 'FAIL',
                                   (tail[-1] if tail else '')[:60]))
        if p.returncode != 0:
            bad += 1
            for ln in (p.stderr or '').strip().split(chr(10))[-6:]:
                print('        | %s' % ln[:110])
    if bad:
        return 1
    print('  NOT A VALIDATION RESULT · DRY-RUN. A1 과 A2 가 기준을 세운 뒤에야 검증이다.')
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
