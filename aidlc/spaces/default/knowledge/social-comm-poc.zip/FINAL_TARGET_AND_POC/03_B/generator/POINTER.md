# 생성기 본체는 FINAL_CLOSURE 에 있다

```
FINAL_CLOSURE/04_GENERATION/generator/
  run_generation.py     생성 · --dry-run 없이 부르면 POC A 미통과로 막는다
  variation_plan.py     변형 계획
  prompts.py            소재 목록   ← 타겟 변경으로 **여기만 바뀐다**
  isolation.py          생성기와 판정자 분리 · assert_no_leak
```

## 타겟 결정으로 바뀌는 것

`prompts.py` 의 **소재 목록만** 바꾼다. 생성 규칙과 등급 정의는 그대로다.

| | 바꾼다 | 유지 |
|---|---|---|
| 장면 | 학교 중심 → 대학 · 동아리 · 인턴 · 아르바이트 · 첫 직장 | 변형 축 다섯 |
| 관계 어휘 | 선생님 · 반 친구 → 선배 · 교수 · 팀장 · 동기 | 등급 정의 |
| stakes | 성적 → 평가 · 채용 · 팀 관계 | 수락 규칙 |

`TARGET_IMPACT_MATRIX.csv` 에서 이 자산은 **SCENARIO_CHANGE** 다.

## 아직 돌리지 않는다

A1 과 A2 가 기준을 세우기 전에는 생성물을 판정할 자가 없다.
`run_generation.py` 는 `--dry-run` 없이 부르면 막고 exit 1 을 낸다. **고장이 아니라 설계다.**
