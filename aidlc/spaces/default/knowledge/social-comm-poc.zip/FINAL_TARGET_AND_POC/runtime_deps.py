# -*- coding: utf-8 -*-
"""런타임 의존을 한 곳에서 찾는다. 사본을 작업 트리에 만들지 않는다.

    import runtime_deps as RD
    RD.add_paths()                 필요한 경로를 sys.path 에 넣는다
    RD.check()                     전부 풀리는가. (ok, 상세) 를 돌려준다

왜 있나
  `run_a2.py` 는 판정 하네스를, POC B 는 생성기와 rule_engine 을, 채점기는 rubric CSV 를 쓴다.
  전에는 각 스크립트가 `../../FINAL_CLOSURE/...` 를 손으로 적었다.
  그러면 **이 폴더만 zip 으로 풀었을 때 전부 깨진다.** 실제로 깨졌다.

어떻게 푸나
  두 자리를 순서대로 본다.

    1 runtime/          배포본을 풀었을 때. make_release.py 가 빌드 시점에 넣는다
    2 ../FINAL_CLOSURE  저장소에서 작업할 때. 여기가 정본이다

  **저장소에는 사본을 두지 않는다.** 2번을 그대로 쓴다.
  **배포본에는 1번이 들어간다.** 그 사본은 MANIFEST 의 sha256 으로 정본과 대조된다.
  그래서 사본이 따로 놀면 검사가 잡는다.

  둘 다 없으면 **조용히 넘어가지 않는다.** check() 가 실패를 돌려주고
  verify_pre_human.py 가 FAIL 로 찍는다.
"""
from __future__ import annotations

import hashlib
import io
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
VENDOR = os.path.join(HERE, 'runtime')
REPO = os.path.dirname(HERE)

# (별칭, 저장소에서의 경로, 배포본에서의 경로, 종류)
#   종류 · 'dir' 은 sys.path 에 넣는다 · 'file' 은 있기만 하면 된다
DEPS = [
    ('judge_harness', 'FINAL_CLOSURE/03_AUTOMATION/judge_harness',
     'runtime/judge_harness', 'dir'),
    ('bias_tests', 'FINAL_CLOSURE/03_AUTOMATION/bias_tests',
     'runtime/bias_tests', 'dir'),
    ('generator', 'FINAL_CLOSURE/04_GENERATION/generator',
     'runtime/generator', 'dir'),
    ('rule_engine', 'poc_validation_v0_1/02_POC_A',
     'runtime/rule_engine', 'dir'),
    ('scoring', 'FINAL_CLOSURE/05_PERFORMANCE/automatic_scoring',
     'runtime/scoring', 'dir'),
    ('rubric_csv', 'FINAL_CLOSURE/05_PERFORMANCE',
     'runtime/rubric', 'dir'),
]

# 배포본에 실제로 넣는 파일. 폴더를 통째로 넣지 않는다.
# 넣을 것만 적으면 무엇이 런타임 의존인지가 목록으로 남는다.
VENDOR_FILES = {
    'judge_harness': ['judge_harness.py', 'gold_split.py', 'a2_breakdowns.py'],
    'bias_tests': ['perturbations.py', 'run_bias_tests.py'],
    'generator': ['isolation.py', 'prompts.py', 'variation_plan.py',
                  'run_generation.py', 'skill_family_seeds.json'],
    'rule_engine': ['rule_engine.py'],
    'scoring': ['score_harness.py'],
    'rubric_csv': ['UNDERSTAND_RUBRIC.csv', 'PERFORM_RUBRIC.csv',
                   'SKILL_SPECIFIC_METRICS.csv'],
}


def _vendored(alias):
    return os.path.join(VENDOR, alias)


def _canonical(alias):
    for a, src, _dst, _k in DEPS:
        if a == alias:
            return os.path.normpath(os.path.join(REPO, src))
    return None


def resolve(alias):
    """이 별칭의 실제 폴더. 배포본 사본이 있으면 그것, 없으면 저장소 정본."""
    v = _vendored(alias)
    if os.path.isdir(v):
        return v
    c = _canonical(alias)
    if c and os.path.isdir(c):
        return c
    return None


def add_paths(aliases=None):
    """필요한 폴더를 sys.path 앞에 넣는다. 못 찾은 별칭 목록을 돌려준다."""
    missing = []
    for alias, _s, _d, kind in DEPS:
        if aliases and alias not in aliases:
            continue
        p = resolve(alias)
        if p is None:
            missing.append(alias)
            continue
        if kind == 'dir' and p not in sys.path:
            sys.path.insert(0, p)
    return missing


def sha16(path):
    return hashlib.sha256(io.open(path, 'rb').read()).hexdigest()[:16]


def check():
    """전부 풀리는가. (ok, 줄 목록) 을 돌려준다. 조용히 통과하지 않는다."""
    lines, ok = [], True
    mode = 'VENDORED' if os.path.isdir(VENDOR) else 'REPO'
    for alias, src, _dst, _k in DEPS:
        p = resolve(alias)
        if p is None:
            ok = False
            lines.append('%-14s **없다** · 저장소에도 배포본에도 없다 · %s' % (alias, src))
            continue
        want = VENDOR_FILES.get(alias, [])
        miss = [f for f in want if not os.path.exists(os.path.join(p, f))]
        where = 'runtime/' if p.startswith(VENDOR) else '저장소'
        if miss:
            ok = False
            lines.append('%-14s %s · **파일 없음** %s' % (alias, where, miss))
        else:
            lines.append('%-14s %s · 파일 %d개' % (alias, where, len(want)))
    return ok, [mode] + lines


def verify_vendor_matches_canonical():
    """배포본 사본이 저장소 정본과 같은 바이트인가.

    사본은 반드시 따로 논다. 그래서 사본을 둘 때는 반드시 대조를 함께 둔다.
    저장소가 없는 곳(고객 기계)에서는 대조할 대상이 없으므로 SKIP 을 돌려준다.
    """
    if not os.path.isdir(VENDOR):
        return None, ['배포본 사본이 없다 · 저장소 정본을 직접 쓴다']
    drift, lines = [], []
    for alias, src, _dst, _k in DEPS:
        can = _canonical(alias)
        ven = _vendored(alias)
        if not (can and os.path.isdir(can)):
            lines.append('%-14s 정본 없음 · 대조 못 함 (고객 기계로 본다)' % alias)
            continue
        for f in VENDOR_FILES.get(alias, []):
            a, b = os.path.join(can, f), os.path.join(ven, f)
            if not os.path.exists(b):
                drift.append('%s/%s · 사본 없음' % (alias, f))
            elif sha16(a) != sha16(b):
                drift.append('%s/%s · 정본 %s · 사본 %s'
                             % (alias, f, sha16(a), sha16(b)))
    if drift:
        return False, lines + drift
    return True, lines + ['사본이 정본과 같다']


if __name__ == '__main__':
    ok, lines = check()
    for x in lines:
        print('  ' + x)
    print('  판정 · %s' % ('푼다' if ok else '못 푼다'))
    m, ml = verify_vendor_matches_canonical()
    if m is not None:
        for x in ml:
            print('  ' + x)
        print('  사본 대조 · %s' % ('같다' if m else '다르다'))
    sys.exit(0 if ok else 1)
