# 채점 하네스 본체는 FINAL_CLOSURE 에 있다

`FINAL_CLOSURE/05_PERFORMANCE/automatic_scoring/score_harness.py`

## 아직 쓰지 않는다

순서가 있다. 뒤집지 않는다.

```
사람 rubric 신뢰도     평정자 2명이 같은 응답에 같은 점수를 주는가
   ↓                   안 되면 rubric 을 고친다. LLM 으로 넘어가지 않는다
사람 합의              gold 점수
   ↓
LLM 채점 타당화        LLM 이 사람 gold 를 재현하는가
   ↓
확신도 라우팅
```

**rubric 이 사람끼리도 안 맞으면 LLM 이 재현할 대상이 없다.**
A2 와 같은 구조다. 같은 실수를 반복하지 않으려고 같은 순서를 쓴다.

지금 상태 · `../TARGET_SPECIFIC_RUBRIC.md` 의 행동 앵커가 **초안**이다.
