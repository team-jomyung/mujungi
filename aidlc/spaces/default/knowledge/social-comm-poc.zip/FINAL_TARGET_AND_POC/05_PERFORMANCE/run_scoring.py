# -*- coding: utf-8 -*-
"""수행 채점기를 dry-run 으로 돌린다.

    python run_scoring.py --out _dryrun

**사람 rubric 신뢰도를 재기 전에는 채점 결과가 뜻이 없다.** 배선 확인이다.
채점기 본체와 rubric CSV 는 `runtime_deps.py` 가 찾는다.
"""
from __future__ import annotations

import argparse
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))


def main(argv):
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', default=os.path.join(HERE, '_dryrun'))
    a = ap.parse_args(argv)
    out = a.out if os.path.isabs(a.out) else os.path.join(HERE, a.out)
    if not os.path.isdir(out):
        os.makedirs(out)

    import runtime_deps as RD
    missing = RD.add_paths(['scoring', 'rubric_csv'])
    if missing:
        ok, lines = RD.check()
        print('채점기를 못 찾았다 · %s' % missing)
        for x in lines:
            print('  ' + x)
        return 2
    sc = RD.resolve('scoring')
    rub = RD.resolve('rubric_csv')
    need = ('UNDERSTAND_RUBRIC.csv', 'PERFORM_RUBRIC.csv')
    miss = [f for f in need if not os.path.exists(os.path.join(rub, f))]
    if miss:
        print('rubric CSV 가 없다 · %s' % miss)
        return 2

    env = dict(os.environ, PYTHONIOENCODING='utf-8')
    p = subprocess.run([sys.executable, 'score_harness.py'], cwd=sc,
                       capture_output=True, text=True, encoding='utf-8',
                       errors='replace', env=env)
    tail = (p.stdout or '').strip().split(chr(10))
    print('  %-16s %-4s %s' % ('채점 dry-run', 'ok' if p.returncode == 0 else 'FAIL',
                               (tail[-1] if tail else '')[:60]))
    if p.returncode != 0:
        for ln in (p.stderr or '').strip().split(chr(10))[-6:]:
            print('        | %s' % ln[:110])
        return 1
    print('  NOT A VALIDATION RESULT. 사람 rubric 신뢰도가 먼저다.')
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
