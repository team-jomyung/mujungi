# -*- coding: utf-8 -*-
"""배포본을 만든다. 런타임 의존을 빌드 시점에 넣어 **혼자 돌게** 한다.

    python make_release.py
    python make_release.py --test      만든 뒤 깨끗한 폴더에 풀어 전부 돌려 본다

왜 있나
  앞 판은 이 폴더만 zip 으로 풀면 `run_a2.py` 가 깨졌다. 옆에 FINAL_CLOSURE 가 있어야 했다.
  POC B 와 채점기는 POINTER 파일뿐이었다. **배포본이 스스로 돌지 못했다.**

사본을 어떻게 다루나
  **작업 트리에는 사본을 두지 않는다.** 저장소에서는 FINAL_CLOSURE 를 직접 쓴다.
  **배포본에만** `runtime/` 으로 넣는다. 그리고 `RUNTIME_MANIFEST.json` 에 sha256 을 적는다.
  나중에 정본이 바뀌면 `runtime_deps.verify_vendor_matches_canonical()` 이 다르다고 말한다.

  사본이 나쁜 것이 아니라 **대조 없는 사본이 나쁘다.**
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import runtime_deps as RD  # noqa: E402

NAME = 'FINAL_TARGET_AND_POC_RC1'
SKIP_DIRS = {'__pycache__', '.git', '_selftest', '_dryrun', 'runtime', 'results'}
SKIP_EXT = ('.pyc',)


def sha(path):
    return hashlib.sha256(io.open(path, 'rb').read()).hexdigest()


def stage(dst):
    """작업 트리를 옮긴다. 임시 산출물은 뺀다."""
    n = 0
    for dp, dn, fn in os.walk(HERE):
        dn[:] = [d for d in dn if d not in SKIP_DIRS]
        rel = os.path.relpath(dp, HERE)
        for f in fn:
            if f.endswith(SKIP_EXT):
                continue
            src = os.path.join(dp, f)
            out = os.path.join(dst, rel, f) if rel != '.' else os.path.join(dst, f)
            d = os.path.dirname(out)
            if not os.path.isdir(d):
                os.makedirs(d)
            shutil.copy2(src, out)
            n += 1
    return n


def vendor(dst):
    """런타임 의존을 runtime/ 으로 넣는다. 무엇을 넣었는지 해시와 함께 적는다."""
    man, n = [], 0
    for alias, src, _d, _k in RD.DEPS:
        canon = os.path.normpath(os.path.join(REPO, src))
        want = RD.VENDOR_FILES.get(alias, [])
        outd = os.path.join(dst, 'runtime', alias)
        if not os.path.isdir(outd):
            os.makedirs(outd)
        for f in want:
            a = os.path.join(canon, f)
            if not os.path.exists(a):
                man.append({'alias': alias, 'file': f, 'status': 'MISSING',
                            'canonical': src})
                continue
            shutil.copy2(a, os.path.join(outd, f))
            man.append({'alias': alias, 'file': f, 'status': 'OK',
                        'canonical': src + '/' + f, 'sha256': sha(a)})
            n += 1
    # blind 후보도 넣는다. select_primary dry-run 이 이것을 읽는다
    bc = os.path.join(REPO, 'poc_validation_v0_1', '02_POC_A', '_incoming',
                      'blind_candidates_all.csv')
    if os.path.exists(bc):
        d = os.path.join(dst, 'runtime', 'blind')
        if not os.path.isdir(d):
            os.makedirs(d)
        shutil.copy2(bc, os.path.join(d, 'blind_candidates_all.csv'))
        man.append({'alias': 'blind', 'file': 'blind_candidates_all.csv',
                    'status': 'OK', 'canonical': 'poc_validation_v0_1/02_POC_A/_incoming',
                    'sha256': sha(bc)})
        n += 1
    io.open(os.path.join(dst, 'runtime', 'RUNTIME_MANIFEST.json'), 'w',
            encoding='utf-8', newline='\n').write(json.dumps({
                'built': time.strftime('%Y-%m-%d %H:%M'),
                'note': '작업 트리에는 사본이 없다. 배포본에만 넣는다. '
                        '정본이 바뀌면 runtime_deps.verify_vendor_matches_canonical() 이 잡는다',
                'files': man}, ensure_ascii=False, indent=2) + '\n')
    miss = [m for m in man if m['status'] != 'OK']
    return n, miss


def main(argv):
    ap = argparse.ArgumentParser()
    ap.add_argument('--test', action='store_true')
    ap.add_argument('--out', default=REPO)
    a = ap.parse_args(argv)

    ok, lines = RD.check()
    print('런타임 의존')
    for x in lines:
        print('  ' + x)
    if not ok:
        print('  **못 푼다.** 배포본을 만들 수 없다.')
        return 2

    tmp = tempfile.mkdtemp()
    root = os.path.join(tmp, NAME)
    os.makedirs(root)
    n_files = stage(root)
    n_vend, miss = vendor(root)
    if miss:
        print('넣지 못한 의존 %d개' % len(miss))
        for m in miss:
            print('  %s/%s' % (m['alias'], m['file']))
        return 2

    zpath = os.path.join(a.out, NAME + '.zip')
    with zipfile.ZipFile(zpath, 'w', zipfile.ZIP_DEFLATED) as z:
        for dp, dn, fn in os.walk(root):
            for f in fn:
                p = os.path.join(dp, f)
                z.write(p, os.path.relpath(p, tmp))
    size = os.path.getsize(zpath)
    with zipfile.ZipFile(zpath) as z:
        n_in = sum(1 for i in z.infolist() if not i.is_dir())
    print()
    print('%s.zip · 파일 %d (본체 %d + 런타임 %d) · %s bytes · sha %s'
          % (NAME, n_in, n_files, n_vend, format(size, ','), sha(zpath)[:16]))
    print('  %s' % zpath)

    if not a.test:
        shutil.rmtree(tmp, ignore_errors=True)
        return 0

    # 깨끗한 폴더에 풀어 전부 돌려 본다. 저장소가 안 보이는 자리에서 한다
    print()
    print('깨끗한 폴더에 풀어 확인한다')
    clean = tempfile.mkdtemp()
    with zipfile.ZipFile(zpath) as z:
        z.extractall(clean)
    cr = os.path.join(clean, NAME)
    env = dict(os.environ, PYTHONIOENCODING='utf-8')
    bad = 0
    for label, args in (('런타임 의존', ['runtime_deps.py']),
                        ('dry-run 일곱', ['run_all_dryruns.py', '--quick']),
                        ('사람 투입 전 확인', ['verify_pre_human.py'])):
        p = subprocess.run([sys.executable] + args, cwd=cr, capture_output=True,
                           text=True, encoding='utf-8', errors='replace', env=env)
        tail = [x for x in (p.stdout or '').strip().split(chr(10)) if x.strip()]
        print('  %-18s %-4s %s' % (label, 'ok' if p.returncode == 0 else 'FAIL',
                                   (tail[-1] if tail else '')[:58]))
        if p.returncode != 0:
            bad += 1
            for ln in tail[-8:]:
                print('        | %s' % ln[:106])
            for ln in (p.stderr or '').strip().split(chr(10))[-4:]:
                print('        | %s' % ln[:106])
    print('  깨끗한 폴더 · %s' % cr)
    shutil.rmtree(tmp, ignore_errors=True)
    if bad:
        print('  판정 · **배포본이 혼자 못 돈다**')
        return 1
    print('  판정 · 배포본이 혼자 돈다')
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
