# -*- coding: utf-8 -*-
"""사람을 넣기 전에 한 명령으로 전부 확인한다.

    python verify_pre_human.py
    python verify_pre_human.py --skip-slow      시뮬레이션 재현 확인을 건너뛴다

전부 통과해야만 마지막 줄에 READY_FOR_HUMANS 를 찍는다.
**건너뛴 것이 있으면 통과라고 쓰지 않는다.** 몇 개를 건너뛰었는지 함께 적는다.
(이 저장소의 ERR-01 이 그 실수였다. 세 검사 중 하나가 안 돌았는데 "전체 통과" 였다.)

무엇을 보나
  1 산출물 존재      요구된 디렉터리와 파일이 있는가
  2 타겟 보고 완성도  후보 · 열 · FATAL BLOCKER · 최종 선택이 다 있는가
  3 A1 시뮬 재현성    두 번 돌려 같은 바이트가 나오는가
  4 A1 꾸러미 누출    판정자에게 가는 파일에 정답·상대 판정·유형이 없는가
  5 A2 스키마         gold 열과 판정 필드가 맞는가
  6 A2 분할 누출      calibration 과 held_out 이 겹치는가
  7 C 스키마          개인 사건 필드에 단정 금지 필드가 있는가
  8 역할 꾸러미 누출   각 역할 ZIP 에 그 역할이 보면 안 되는 것이 있는가
  9 HTML 무결성       링크와 참조 파일이 실제로 있는가
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import os
import re
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
ENV = dict(os.environ, PYTHONIOENCODING='utf-8')

import leakcheck as LK

# script/style 안은 태그가 아니다. JS 의 비교 연산자나 템플릿이 태그로 읽히면
# 멀쩡한 문서가 "닫힘 짝 없음" 으로 걸린다. 본문에서 먼저 걷어낸다.
SCRIPT_RX = re.compile(
    r'<(?:script|style)\b[^>]*>.*?</(?:script|style)\s*>', re.S | re.I)

JUDGED = ('required_inference', 'perspective_structure',
          'decidable_by_evidence', 'direct_check_allowed')


class Res(object):
    def __init__(self):
        self.rows = []
        self.skipped = []

    def add(self, name, ok, msg, detail=None):
        self.rows.append((name, ok, msg, detail or []))

    def skip(self, name, why):
        self.skipped.append((name, why))


def rel(p):
    return os.path.relpath(p, ROOT).replace(os.sep, '/')


def find_first(rels):
    """여러 후보 자리 중 먼저 있는 것. 배포본과 저장소가 다른 자리를 쓴다."""
    for rel in rels:
        p = os.path.join(HERE, rel.replace('/', os.sep))
        if os.path.exists(p):
            return p
    return None


def read_csv(p):
    with io.open(p, encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))


# ───────────────────────── 1 산출물 존재 ─────────────────────────

REQUIRED = [
    '00_DECISION/TARGET_SELECTION_REPORT.html',
    '00_DECISION/TARGET_FEASIBILITY_MATRIX.csv',
    '00_DECISION/TARGET_IMPACT_MATRIX.csv',
    '00_DECISION/FINAL_DECISIONS.md',
    '01_A1/A1_SELECTION_BIAS_AUDIT.md',
    '01_A1/A1_SEQUENTIAL_DESIGN.md',
    '01_A1/A1_SAMPLE_SIZE_SIMULATION.csv',
    '01_A1/A1_FINAL_PROTOCOL.md',
    '01_A1/select_primary.py',
    '01_A1/a1_sequential_simulation.py',
    '02_A2/A2_FINAL_PROTOCOL.md',
    '02_A2/build_consensus.py',
    '02_A2/run_a2.py',
    '03_B/POC_B_FINAL_PROTOCOL.md',
    '04_C/POC_C_FINAL_PROTOCOL.md',
    '04_C/CAPTURE_FEASIBILITY.md',
    '05_PERFORMANCE/PERFORMANCE_PROTOCOL.md',
    '05_PERFORMANCE/TARGET_SPECIFIC_RUBRIC.md',
    '06_HUMAN/HUMAN_ROLE_MATRIX.md',
    '06_HUMAN/HUMAN_BLOCKERS.md',
    '06_HUMAN/HUMAN_TIME_ESTIMATE.md',
    'FINAL_PRE_HUMAN_REPORT.html',
]


def check_files(r):
    miss = [p for p in REQUIRED if not os.path.exists(os.path.join(HERE, p))]
    r.add('1 산출물 존재', not miss,
          '%d/%d' % (len(REQUIRED) - len(miss), len(REQUIRED)),
          ['없다 · %s' % m for m in miss])


# ───────────────────────── 2 타겟 보고 완성도 ─────────────────────────

FEAS_COLS = ('TARGET', 'AGE', 'DIAGNOSIS_REQUIRED', 'DIRECT_STUDY_COUNT',
             'DIRECT_PARTICIPANT_DATA', 'DIRECT_AGE_EVIDENCE', 'KOREAN_DIRECT_DATA',
             'PUBLIC_DATASET_COUNT', 'NATURAL_CONVERSATION', 'MULTI_TURN',
             'PRAGMATIC_ANNOTATION', 'RELATIONSHIP_METADATA', 'CONTEXT_METADATA',
             'OUTCOME_DATA', 'LONGITUDINAL_DATA', 'INTERVENTION_EVIDENCE',
             'ASSESSMENT_TOOL', 'STANDARDIZED_TOOL', 'KOREAN_TOOL', 'PUBLIC_DOWNLOAD',
             'LICENSE', 'COMMERCIAL_USE', 'LLM_USE', 'RECRUITMENT_DIFFICULTY',
             'IRB_DIFFICULTY', 'VULNERABLE_POPULATION_RISK',
             'NEW_DATA_COLLECTION_FEASIBILITY',
             'UNDERSTAND_EVALUATION', 'PERFORM_EVALUATION', 'NEAR_TRANSFER',
             'FAR_TRANSFER', 'MAINTENANCE', 'REAL_WORLD_OUTCOME',
             'HUMAN_GOLD_FEASIBILITY', 'LLM_JUDGE_FEASIBILITY',
             'POPULATION_TYPE', 'FATAL_BLOCKER', 'VERDICT')


def check_target(r):
    p = os.path.join(HERE, '00_DECISION/TARGET_FEASIBILITY_MATRIX.csv')
    if not os.path.exists(p):
        r.skip('2 타겟 보고', 'TARGET_FEASIBILITY_MATRIX.csv 가 아직 없다')
        return
    rows = read_csv(p)
    bad = []
    cols = list(rows[0].keys()) if rows else []
    miss = [c for c in FEAS_COLS if c not in cols]
    if miss:
        bad.append('빠진 열 %d · %s' % (len(miss), miss[:6]))
    if len(rows) < 11:
        bad.append('후보가 %d개다. 최소 11개를 비교해야 한다' % len(rows))
    # 임상/준임상/비임상을 섞어 세지 않았는가
    pt = {(x.get('POPULATION_TYPE') or '').strip().upper() for x in rows}
    ok_pt = {'CLINICAL', 'SUBCLINICAL', 'NONCLINICAL'}
    off = pt - ok_pt
    if off:
        bad.append('POPULATION_TYPE 어휘 밖 · %s' % sorted(off))
    verd = {(x.get('VERDICT') or '').strip().upper() for x in rows}
    ok_v = {'RECOMMENDED', 'VIABLE_BUT_RISKY', 'NOT_RECOMMENDED'}
    offv = verd - ok_v
    if offv:
        bad.append('VERDICT 어휘 밖 · %s' % sorted(offv))
    empty = sum(1 for x in rows for c in FEAS_COLS if c in cols and not (x.get(c) or '').strip())
    r.add('2 타겟 보고', not bad,
          '후보 %d · 열 %d · 빈 칸 %d' % (len(rows), len(cols), empty), bad)


def check_decisions(r):
    p = os.path.join(HERE, '00_DECISION/FINAL_DECISIONS.md')
    if not os.path.exists(p):
        r.skip('2b 최종 결정', 'FINAL_DECISIONS.md 가 아직 없다')
        return
    s = io.open(p, encoding='utf-8').read()
    # 타겟 이름은 세 층이 아니라 네 이름이다. PRODUCT_TARGET 은 PROVISIONAL 이어야 한다
    need = ['SCD 13~25', '1순위', '2순위', '3순위',
            'PRODUCT_TARGET', 'TECHNICAL_POC_TARGET', 'FUTURE_EXTENSION',
            'EVIDENCE_DATA_POPULATION', 'PROVISIONAL']
    miss = [x for x in need if x not in s]
    # 네 답 중 정확히 하나가 있어야 한다
    picks = [x for x in ('YES', 'NARROW', 'BROADEN', 'CHANGE TARGET')
             if re.search(r'\*\*%s\*\*' % re.escape(x), s)]
    bad = []
    if miss:
        bad.append('빠진 항목 · %s' % miss)
    if len(picks) != 1:
        bad.append('YES / NARROW / BROADEN / CHANGE TARGET 중 굵게 표시된 것이 %d개다. 하나여야 한다 · %s'
                   % (len(picks), picks))
    # PRODUCT_TARGET 을 확정된 것처럼 쓰면 잡는다
    if 'PRODUCT_TARGET' in s and 'PROVISIONAL' not in s:
        bad.append('PRODUCT_TARGET 이 PROVISIONAL 로 표시돼 있지 않다')
    if '기술검증 집단의 선택이지 제품 시장의 최종 선택이 아니다' not in s:
        bad.append('타겟 조사의 범위를 밝힌 문장이 없다')
    r.add('2b 최종 결정', not bad, '선택 · %s' % (picks[0] if len(picks) == 1 else '?'), bad)


# ───────────────────────── 3 시뮬레이션 재현성 ─────────────────────────

def check_sim_repro(r, skip_slow):
    script = os.path.join(HERE, '01_A1', 'a1_sequential_simulation.py')
    out = os.path.join(HERE, '01_A1', 'A1_SAMPLE_SIZE_SIMULATION.csv')
    if not os.path.exists(out):
        r.skip('3 시뮬 재현성', '결과 CSV 가 아직 없다')
        return
    if skip_slow:
        r.skip('3 시뮬 재현성', '--skip-slow')
        return
    # 검사가 검사 대상을 망가뜨리면 안 된다.
    # 처음 판은 --quick 을 두 번 돌려 전체 판 CSV 를 덮어썼다. 경고는 찍었지만
    # 경고를 안 읽는 사람이 언젠가 돌린다. 그래서 원본을 옆에 두고 끝나면 되돌린다.
    import shutil
    import tempfile
    before = hashlib.sha256(io.open(out, 'rb').read()).hexdigest()
    keep = os.path.join(tempfile.mkdtemp(), 'keep.csv')
    shutil.copy2(out, keep)
    siblings = [os.path.join(os.path.dirname(script), f)
                for f in ('A1_SEQUENTIAL_SIMULATION.csv', 'A1_SIMULATION_META.json')]
    kept = [(f, os.path.join(os.path.dirname(keep), os.path.basename(f)))
            for f in siblings if os.path.exists(f)]
    for src, dst in kept:
        shutil.copy2(src, dst)
    try:
        p = subprocess.run([sys.executable, os.path.basename(script), '--quick'],
                           cwd=os.path.dirname(script), capture_output=True,
                           text=True, encoding='utf-8', env=ENV)
        if p.returncode != 0:
            r.add('3 시뮬 재현성', False, '시뮬레이션이 터졌다', [(p.stderr or '')[-300:]])
            return
        q1 = hashlib.sha256(io.open(out, 'rb').read()).hexdigest()
        subprocess.run([sys.executable, os.path.basename(script), '--quick'],
                       cwd=os.path.dirname(script), capture_output=True,
                       text=True, encoding='utf-8', env=ENV)
        q2 = hashlib.sha256(io.open(out, 'rb').read()).hexdigest()
    finally:
        # 전체 판 결과를 되돌린다. 검사 전과 같은 바이트여야 한다
        shutil.copy2(keep, out)
        for src, dst in kept:
            shutil.copy2(dst, src)
    ok = (q1 == q2)
    after = hashlib.sha256(io.open(out, 'rb').read()).hexdigest()
    note = ['--quick 두 번 · %s' % ('같은 바이트' if ok else '다르다'),
            '전체 판 결과 · %s' % ('되돌렸다' if after == before else '되돌리지 못했다')]
    if after != before:
        ok = False
    r.add('3 시뮬 재현성', ok, '--quick sha 앞 12 %s · 전체 판 %s'
          % (q1[:12], before[:12]), note)


# ───────────────────────── 4 A1 꾸러미 누출 ─────────────────────────

def scan_leak(paths, who):
    """구현은 leakcheck.py 한 곳에만 있다."""
    hits = []
    for p in paths:
        hits += LK.scan_file(p, who)
    return hits


def check_a1_packages(r):
    pk = os.path.join(HERE, '01_A1', 'packages')
    if not os.path.isdir(pk):
        r.skip('4 A1 꾸러미 누출', 'packages/ 가 아직 없다')
        return
    bad, n = LK.scan_packages(pk)
    # 검사할 파일이 0 개인데 통과라고 쓰지 않는다.
    # 이 저장소에서 "아무것도 안 보는 검사가 초록을 찍는" 일이 세 번 있었다
    if n == 0:
        r.add('4 A1 꾸러미 누출', False, '검사할 파일이 0개다',
              ['packages/ 아래 역할 폴더가 비어 있다'])
        return
    r.add('4 A1 꾸러미 누출', not bad, '파일 %d개 검사' % n, bad[:10])


# ───────────────────────── 5·6 A2 ─────────────────────────

def check_a2_schema(r):
    # dry-run 이 남긴 자리를 먼저 본다. 배포본에는 _selftest 가 없다
    p = find_first(['_dryrun/a1_consensus_gold.csv',
                    '02_A2/_dryrun/a1_consensus_gold.csv',
                    '02_A2/_selftest/a1_consensus_gold.csv'])
    if p is None:
        r.add('5 A2 스키마', False, 'gold 예시가 없다',
              ['python run_all_dryruns.py 를 먼저 돌린다'])
        return
    rows = read_csv(p)
    cols = list(rows[0].keys()) if rows else []
    bad = []
    for f in JUDGED:
        if f not in cols:
            bad.append('판정 필드 열이 없다 · %s' % f)
        if f + '__source' not in cols:
            bad.append('출처 열이 없다 · %s__source' % f)
    src = {(x.get(f + '__source') or '').strip().upper()
           for x in rows for f in JUDGED}
    ok_src = {'CONSENSUS', 'ADJUDICATED', 'DISAGREE', 'MISSING', ''}
    off = src - ok_src
    if off:
        bad.append('__source 어휘 밖 · %s' % sorted(off))
    r.add('5 A2 스키마', not bad, '열 %d · 쌍 %d' % (len(cols), len(rows)), bad)


def check_a2_split(r):
    p = find_first(['_dryrun/a2_results/split_manifest.json',
                    '02_A2/_dryrun/a2_results/split_manifest.json',
                    '02_A2/_selftest/results/split_manifest.json'])
    if p is None:
        r.add('6 A2 분할 누출', False, 'split_manifest.json 이 없다',
              ['python run_all_dryruns.py 를 먼저 돌린다'])
        return
    m = json.load(io.open(p, encoding='utf-8'))
    sp = m.get('split', {})
    bad = []
    keys = sorted(sp)
    for i in range(len(keys)):
        for j in range(i + 1, len(keys)):
            ov = set(sp[keys[i]]) & set(sp[keys[j]])
            if ov:
                bad.append('%s ∩ %s = %s' % (keys[i], keys[j], sorted(ov)[:5]))
    r.add('6 A2 분할 누출', not bad,
          ' · '.join('%s %d' % (k, len(sp[k])) for k in keys), bad)


# ───────────────────────── 7 C 스키마 ─────────────────────────

BANNED_C_FIELDS = ('partner_true_intent', 'partner_true_emotion', 'true_motive',
                   'partner_intent', 'partner_emotion', 'unobserved_motive')
REQUIRED_C_STATES = ('OBSERVED', 'INFERRED', 'POSSIBLE_INTERPRETATION',
                     'USER_CONFIRMED', 'VALIDATED')


def check_c_schema(r):
    p = os.path.join(HERE, '04_C', 'personal_event_schema.json')
    if not os.path.exists(p):
        r.skip('7 C 스키마', 'personal_event_schema.json 이 아직 없다')
        return
    sch = json.load(io.open(p, encoding='utf-8'))
    names = set()

    def walk(o, path=''):
        if isinstance(o, dict):
            for k, v in o.items():
                names.add(k)
                walk(v, path + '/' + str(k))
        elif isinstance(o, list):
            for v in o:
                walk(v, path)
    walk(sch)
    bad = [n for n in names if n.lower() in BANNED_C_FIELDS]
    txt = json.dumps(sch, ensure_ascii=False)
    miss = [s for s in REQUIRED_C_STATES if s not in txt]
    out = []
    if bad:
        out.append('상대의 속마음을 사실로 저장하는 필드 · %s' % bad)
    if miss:
        out.append('인식 상태가 빠졌다 · %s' % miss)
    r.add('7 C 스키마', not out, '필드 이름 %d개' % len(names), out)


# ───────────────────────── 8 역할 꾸러미 누출 ─────────────────────────

ROLE_FORBIDDEN = {
    'rater_A': ('rater_B', 'gold', 'consensus', 'adjudic'),
    'rater_B': ('rater_A', 'gold', 'consensus', 'adjudic'),
    'blind_selector': ('gold', 'consensus'),
    'c_participant': ('gold', 'consensus', 'rater', 'schema'),
    'performance_rater': ('gold_score', 'other_rater'),
}


def check_role_bundles(r):
    base = os.path.join(HERE, '01_A1', 'packages')
    if not os.path.isdir(base):
        r.skip('8 역할 꾸러미 누출', 'packages/ 가 아직 없다')
        return
    bad, n = [], 0
    for role, forb in ROLE_FORBIDDEN.items():
        d = os.path.join(base, role)
        if not os.path.isdir(d):
            continue
        for f in sorted(os.listdir(d)):
            n += 1
            low = f.lower()
            for x in forb:
                if x in low:
                    bad.append('%s/ 에 %s 가 있다 (금지어 "%s")' % (role, f, x))
    if n == 0:
        r.add('8 역할 꾸러미 누출', False, '검사할 파일이 0개다',
              ['역할 폴더가 비어 있다. 0개를 검사하고 통과라고 쓰지 않는다'])
        return
    r.add('8 역할 꾸러미 누출', not bad, '파일 %d개' % n, bad)


# ───────────────────────── 9 HTML 무결성 ─────────────────────────

def check_html(r):
    bad, n = [], 0
    for dp, dn, fn in os.walk(HERE):
        dn[:] = [d for d in dn if d not in ('__pycache__', '.git', '_selftest')]
        for f in fn:
            if not f.endswith('.html'):
                continue
            n += 1
            p = os.path.join(dp, f)
            s = io.open(p, encoding='utf-8', errors='replace').read()
            # script/style 안은 태그가 아니다. JS 의 비교 연산자와 템플릿이 태그로 읽혀
            # intake_prototype.html 이 '닫힘 짝 없음' 으로 잘못 걸렸다. 본문에서 먼저 걷어낸다
            s = SCRIPT_RX.sub(' ', s)
            ids = set(re.findall(r'\sid="([^"]+)"', s))
            for h in re.findall(r'href="#([^"]+)"', s):
                if h not in ids:
                    bad.append('%s · 앵커 #%s 가 없다' % (f, h))
            for src in re.findall(r'(?:src|href)="(?!#|https?:|mailto:|data:)([^"]+)"', s):
                tgt = os.path.normpath(os.path.join(dp, src.split('#')[0].split('?')[0]))
                if src and not os.path.exists(tgt):
                    bad.append('%s · 참조 파일이 없다 · %s' % (f, src))
            # 태그 짝
            VOID = {'br', 'hr', 'img', 'meta', 'link', 'input', 'col', 'area',
                    'base', 'source', 'track', 'wbr'}
            st = []
            for m in re.finditer(r'<(/?)([a-zA-Z][\w-]*)([^>]*?)(/?)>', s):
                c, nm, sc = m.group(1), m.group(2).lower(), m.group(4)
                if nm in VOID or sc:
                    continue
                if c:
                    if st and st[-1] == nm:
                        st.pop()
                    else:
                        bad.append('%s · 닫힘 짝 없음 </%s>' % (f, nm))
                else:
                    st.append(nm)
            if st:
                bad.append('%s · 열림 짝 없음 <%s>' % (f, st[-1]))
    if n == 0:
        r.add('9 HTML 무결성', False, 'HTML 파일이 0개다',
              ['보고서 HTML 이 아직 없다'])
        return
    r.add('9 HTML 무결성', not bad, 'HTML %d개' % n, bad[:12])


# ───────────────── 10 보고서가 인용한 시뮬레이션 값 ─────────────────

def check_quoted_numbers(r):
    """보고서에 적힌 시뮬레이션 값이 CSV 의 값과 같은가.

    이 저장소에서 같은 계열로 세 번 터졌다(ERR-04 · 05 · 06).
    마지막 것이 바로 이것이다 · 문서가 인용한 시뮬레이션 수치가 코드의 출력이 아니었다.

    그리고 순차 설계를 고친 뒤로는 **차이가 전 조건에서 0 이어야 한다.**
    0 이 아니면 반복검정 보정 없이 두 번 보는 구조가 되살아난 것이다.
    """
    seqp = os.path.join(HERE, '01_A1', 'A1_SEQUENTIAL_SIMULATION.csv')
    gridp = os.path.join(HERE, '01_A1', 'A1_SAMPLE_SIZE_SIMULATION.csv')
    rep = os.path.join(HERE, 'FINAL_PRE_HUMAN_REPORT.html')
    for p in (seqp, gridp, rep):
        if not os.path.exists(p):
            r.skip('10 인용 수치', '%s 가 아직 없다' % os.path.basename(p))
            return []
    seq = [x for x in read_csv(seqp) if x['prevalence'] == 'balanced']
    grid = {(x['kappa_true'], x['n']): x for x in read_csv(gridp)
            if x['prevalence'] == 'balanced'}
    s = io.open(rep, encoding='utf-8').read()
    bad = []

    # 1 · 순차 설계가 반복검정을 만들지 않는가. 전 조건에서 차이 0
    off = [(x['kappa_true'], x['sequential_minus_fixed']) for x in seq
           if abs(float(x['sequential_minus_fixed'])) > 1e-9]
    if off:
        bad.append('순차와 고정의 차이가 0 이 아니다 · %s · '
                   '1단계 성공 주장이 되살아났는지 본다' % off[:3])

    # 2 · 1단계 성공 종료가 구조상 0 인가
    on = [(x['kappa_true'], x['p_stop_stage1_claim']) for x in seq
          if float(x['p_stop_stage1_claim']) > 0]
    if on:
        bad.append('1단계에서 성공 주장이 일어났다 · %s' % on[:3])

    # 3 · 보고서가 인용한 최소·권장 근거가 CSV 와 같은가
    for k, n in (('0.8', '60'), ('0.8', '120')):
        g = grid.get((k, n))
        if not g:
            bad.append('격자에 κ%s n%s 이 없다' % (k, n))
            continue
        want = round(float(g['p_claim_threshold']), 2)
        m = re.search(r'κ참값 0\.8 에서 문턱 주장 확률 ([\d.]+)' if n == '60'
                      else r'같은 조건에서 ([\d.]+)', s)
        if m is None:
            bad.append('보고서에서 κ%s n%s 근거 문장을 못 찾았다' % (k, n))
        elif abs(float(m.group(1)) - want) > 0.005:
            bad.append('κ%s n%s · 보고서 %s · CSV %.2f' % (k, n, m.group(1), want))

    r.add('10 인용 수치', not bad,
          '순차 차이 전부 0 · 1단계 성공 0 · 표본 근거 2개', bad)
    return bad


# ───────────────────────── 실행 ─────────────────────────

def check_runtime(r):
    """런타임 의존이 풀리는가. **없으면 반드시 FAIL 이다.**

    앞 판은 이 검사가 아예 없었다. 그래서 이 폴더만 zip 으로 풀면
    run_a2.py 가 깨지는데도 verify 가 READY_FOR_HUMANS 를 찍었다.
    """
    sys.path.insert(0, HERE)
    try:
        import runtime_deps as RD
    except Exception as e:                                     # noqa: BLE001
        r.add('11 런타임 의존', False, 'runtime_deps.py 를 못 불렀다 · %s' % e)
        return []
    ok, lines = RD.check()
    r.add('11 런타임 의존', ok, lines[0] + ' · ' + str(len(lines) - 1) + '개',
          [] if ok else lines[1:])
    # 배포본 사본이 있으면 정본과 같은 바이트인지 본다
    m, ml = RD.verify_vendor_matches_canonical()
    if m is False:
        r.add('11b 사본 대조', False, '사본이 정본과 다르다', ml)
    elif m is True:
        r.add('11b 사본 대조', True, '사본 = 정본', [])
    return [] if ok else lines[1:]


def check_skill_scope(r):
    """기술 범위 문서와 기계용 JSON 이 같은가. 손으로 고치면 잡는다."""
    md = os.path.join(HERE, 'SKILL_SCOPE_V0_1_FINAL.md')
    js = os.path.join(HERE, '03_B', 'skill_scope_v0_1.json')
    rub = os.path.join(HERE, '05_PERFORMANCE', 'TARGET_SPECIFIC_RUBRIC.md')
    for p in (md, js, rub):
        if not os.path.exists(p):
            r.skip('12 기술 범위', '%s 가 없다' % os.path.basename(p))
            return []
    d = json.load(io.open(js, encoding='utf-8'))
    bad = []
    scored = d.get('scored_skills', [])
    if not scored:
        bad.append('scored_skills 가 비었다')
    ms = io.open(md, encoding='utf-8').read()
    mr = io.open(rub, encoding='utf-8').read()
    # 채점 기술이 rubric 에 전부 있는가
    for sid in scored:
        if sid not in mr:
            bad.append('rubric 에 %s 가 없다' % sid)
    # 뺀 기술이 채점 목록에 없는가
    for e in d.get('exclude', []):
        if e['id'] in scored:
            bad.append('EXCLUDE 인 %s 가 채점 목록에 있다' % e['id'])
    n_core, n_cond = len(d.get('core', [])), len(d.get('conditional', []))
    if ('CORE** | %d' % n_core) not in ms:
        bad.append('문서의 CORE 수가 JSON 과 다르다')
    r.add('12 기술 범위', not bad,
          'CORE %d · CONDITIONAL %d · 채점 %d' % (n_core, n_cond, len(scored)), bad)
    return bad


def main(argv):
    ap = argparse.ArgumentParser()
    ap.add_argument('--skip-slow', action='store_true')
    a = ap.parse_args(argv)

    r = Res()
    check_files(r)
    check_target(r)
    check_decisions(r)
    check_sim_repro(r, a.skip_slow)
    check_a1_packages(r)
    check_a2_schema(r)
    check_a2_split(r)
    check_c_schema(r)
    check_role_bundles(r)
    check_html(r)
    check_quoted_numbers(r)
    check_runtime(r)
    check_skill_scope(r)

    print('=' * 62)
    print('  사람 투입 전 확인')
    print('=' * 62)
    for name, ok, msg, det in r.rows:
        print('  %-18s %-4s %s' % (name, 'ok' if ok else 'FAIL', msg))
        for d in det:
            print('        - %s' % d)
    for name, why in r.skipped:
        print('  %-18s %-4s %s' % (name, '건너뜀', why))

    failed = [x for x in r.rows if not x[1]]
    print('-' * 62)
    print('  검사 %d · 실패 %d · 건너뜀 %d' % (len(r.rows), len(failed), len(r.skipped)))
    if failed:
        print('  판정 · 실패')
        return 1
    if r.skipped:
        # 건너뛴 것을 통과라고 부르지 않는다. ERR-01 이 그 실수였다
        print('  판정 · 돌린 것은 전부 통과. **건너뛴 %d개는 확인하지 않았다**' % len(r.skipped))
        print('  NOT_READY · 건너뛴 항목을 채운 뒤 다시 돌린다')
        return 1
    print('  판정 · 전부 통과')
    print()
    print('  READY_FOR_HUMANS')
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
