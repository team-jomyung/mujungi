# A1 판정자 일치도

판정자 둘의 CSV 를 합쳐 만든 것이다. **합의한 칸만 gold 가 된다.**
갈린 칸은 비워 두고 `a1_needs_adjudication.csv` 로 뺐다. 기계가 고르지 않는다.

| | |
|---|---|
| 쌍 | 60 |
| 판정자 A 파일 | `rater_A_DRYRUN.csv` |
| 판정자 B 파일 | `rater_B_DRYRUN.csv` |
| 조정 파일 | **없음** |
| 조정이 필요한 칸 | **127** |

## 필드별 일치도

| 필드 | κ | n | 관측일치 |
|---|---|---|---|
| `required_inference` | 0.824 | 60 | 0.883 |
| `perspective_structure` | 0.874 | 60 | 0.917 |
| `decidable_by_evidence` | 0.740 | 60 | 0.833 |
| `direct_check_allowed` | 0.794 | 60 | 0.867 |
| `skill_identity_understand` | 0.749 | 60 | 0.833 |
| `skill_identity_perform` | 0.709 | 60 | 0.817 |
| `transfer_distance` | 0.898 | 60 | 0.933 |
| `topic_changed` | 0.875 | 60 | 0.917 |
| `place_changed` | 0.671 | 60 | 0.783 |
| `participants_changed` | 0.722 | 60 | 0.817 |
| `relationship_changed` | 0.626 | 60 | 0.750 |
| `situation_type_changed` | 0.690 | 60 | 0.800 |
| `misread_cost_changed` | 0.800 | 60 | 0.867 |
| `recoverability_changed` | 0.800 | 60 | 0.867 |

**주 산출물은 문턱 통과가 아니라 점추정·CI·혼동행렬이다.**
κ 0.6 은 우리가 정한 운영 기준이고 외부 준거가 없다
(`FINAL_CLOSURE/01_EVIDENCE/EVIDENCE_LEDGER.csv`).

## 판정 필드 혼동행렬

### `required_inference`

| A \ B | SAME | DIFFERENT | UNKNOWN |
|---|---|---|---|
| **SAME** | 22 | 1 | 0 |
| **DIFFERENT** | 0 | 15 | 3 |
| **UNKNOWN** | 1 | 2 | 16 |

### `perspective_structure`

| A \ B | SAME | DIFFERENT | UNKNOWN |
|---|---|---|---|
| **SAME** | 14 | 2 | 0 |
| **DIFFERENT** | 0 | 19 | 1 |
| **UNKNOWN** | 2 | 0 | 22 |

### `decidable_by_evidence`

| A \ B | SAME | DIFFERENT | UNKNOWN |
|---|---|---|---|
| **SAME** | 8 | 3 | 1 |
| **DIFFERENT** | 3 | 18 | 1 |
| **UNKNOWN** | 2 | 0 | 24 |

### `direct_check_allowed`

| A \ B | SAME | DIFFERENT | UNKNOWN |
|---|---|---|---|
| **SAME** | 20 | 1 | 0 |
| **DIFFERENT** | 3 | 21 | 1 |
| **UNKNOWN** | 2 | 1 | 11 |

## 조정이 필요한 칸

| pair_id | 필드 | A | B |
|---|---|---|---|
| B04 | `direct_check_allowed` | DIFFERENT | SAME |
| B04 | `misread_cost_changed` | DIFFERENT | SAME |
| B06 | `decidable_by_evidence` | SAME | DIFFERENT |
| B06 | `direct_check_allowed` | UNKNOWN | DIFFERENT |
| B06 | `situation_type_changed` | UNKNOWN | SAME |
| B07 | `direct_check_allowed` | DIFFERENT | UNKNOWN |
| B07 | `skill_identity_understand` | DIFFERENT | SAME |
| B07 | `place_changed` | DIFFERENT | UNKNOWN |
| B07 | `participants_changed` | DIFFERENT | SAME |
| B10 | `recoverability_changed` | SAME | DIFFERENT |
| B11 | `decidable_by_evidence` | DIFFERENT | SAME |
| B11 | `recoverability_changed` | DIFFERENT | UNKNOWN |
| B12 | `place_changed` | SAME | UNKNOWN |
| B13 | `required_inference` | UNKNOWN | SAME |
| B13 | `place_changed` | SAME | UNKNOWN |
| B14 | `perspective_structure` | UNKNOWN | SAME |
| B14 | `topic_changed` | DIFFERENT | UNKNOWN |
| B15 | `relationship_changed` | DIFFERENT | UNKNOWN |
| B15 | `misread_cost_changed` | DIFFERENT | SAME |
| B16 | `decidable_by_evidence` | UNKNOWN | SAME |
| B16 | `transfer_distance` | SAME | DIFFERENT |
| B16 | `participants_changed` | UNKNOWN | DIFFERENT |
| B16 | `relationship_changed` | SAME | DIFFERENT |
| B17 | `skill_identity_understand` | DIFFERENT | UNKNOWN |
| B19 | `perspective_structure` | SAME | DIFFERENT |
| B19 | `skill_identity_understand` | SAME | DIFFERENT |
| B19 | `place_changed` | UNKNOWN | DIFFERENT |
| B19 | `relationship_changed` | SAME | DIFFERENT |
| B23 | `required_inference` | UNKNOWN | DIFFERENT |
| B23 | `decidable_by_evidence` | DIFFERENT | SAME |
| B23 | `relationship_changed` | SAME | DIFFERENT |
| B23 | `recoverability_changed` | DIFFERENT | SAME |
| B25 | `skill_identity_understand` | SAME | UNKNOWN |
| B25 | `relationship_changed` | SAME | UNKNOWN |
| B26 | `perspective_structure` | SAME | DIFFERENT |
| B26 | `direct_check_allowed` | SAME | DIFFERENT |
| B26 | `transfer_distance` | DIFFERENT | SAME |
| B29 | `place_changed` | UNKNOWN | DIFFERENT |
| B29 | `participants_changed` | DIFFERENT | UNKNOWN |
| B29 | `situation_type_changed` | SAME | DIFFERENT |
| B29 | `misread_cost_changed` | UNKNOWN | SAME |
| B30 | `decidable_by_evidence` | DIFFERENT | UNKNOWN |
| B30 | `topic_changed` | DIFFERENT | UNKNOWN |
| B30 | `relationship_changed` | UNKNOWN | SAME |
| B30 | `situation_type_changed` | SAME | UNKNOWN |
| B30 | `recoverability_changed` | UNKNOWN | SAME |
| B31 | `required_inference` | DIFFERENT | UNKNOWN |
| B31 | `participants_changed` | SAME | UNKNOWN |
| B31 | `relationship_changed` | SAME | UNKNOWN |
| B31 | `situation_type_changed` | SAME | UNKNOWN |
| B31 | `misread_cost_changed` | DIFFERENT | SAME |
| B33 | `situation_type_changed` | SAME | DIFFERENT |
| B36 | `decidable_by_evidence` | SAME | DIFFERENT |
| B36 | `skill_identity_perform` | DIFFERENT | UNKNOWN |
| B36 | `place_changed` | UNKNOWN | SAME |
| B37 | `direct_check_allowed` | DIFFERENT | SAME |
| B38 | `skill_identity_perform` | UNKNOWN | SAME |
| B38 | `topic_changed` | DIFFERENT | SAME |
| B38 | `participants_changed` | DIFFERENT | SAME |
| B38 | `misread_cost_changed` | UNKNOWN | DIFFERENT |
| … | 67개 더 | | |

**조정하는 사람은 판정자 둘 중 하나가 아니어야 한다.**
조정 결과를 `pair_id,field,final` 로 적어 `--adjudication` 에 넣고 다시 돌린다.
