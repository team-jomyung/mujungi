# 검색 로그 — 한국어 언어·화용 평가도구 조사 (2026-09-14)

## 0. 중대 제약사항
이 세션에서 WebSearch(구글 커스텀 검색) 도구는 **세션 전체 예산 200회 중 200회가 이미 다른 병렬 에이전트(같은 세션에서 동시 실행 중인 다수의 리서치 에이전트: dataset-auditor x4, evidence-verifier x4, blind-author x4 등)에 의해 소진**되어 있었다. 이 태스크를 위해 시도한 5건의 WebSearch 호출은 전부 "this session has used its web search budget (200 of 200)" 오류로 실패했다(2026-09-14, 최초 시도 시각).

대체 수단으로 아래를 사용:
- WebFetch (특정 URL 직접 접근) — Google/Naver/DuckDuckGo/Bing 검색 엔진은 차단(캡차·403·무관 캐시 리다이렉트)되어 사용 불가 확인됨
- RISS(riss.kr) 검색 결과 페이지 — **서버사이드 렌더링이라 WebFetch로 정상 접근 가능함을 확인**, 이후 주력 검색 도구로 사용
- 판매처 직접 접근: 아이소리몰(isorimall.com, 파라다이스복지재단 유통), 인싸이트(inpsyt.co.kr, 학지사) — 카테고리 페이지는 접근 가능, 사이트 자체 검색(search) 기능은 SPA라 접근 불가
- e-csd.org(CSD 학술지 원문), Crossref API(api.crossref.org), Semantic Scholar API(요청 과다로 429 다발, 거의 사용 못함)

## 1. 차단/실패한 검색 시도
| 도구/URL | 검색어 | 결과 |
|---|---|---|
| WebSearch | KOPLAC 한국 아동 메타-화용언어검사 가격 파라다이스복지재단 | 실패 — 세션 예산 소진(0/200 잔여) |
| WebSearch | KOPLAC 화용언어검사 실시 자격 언어재활사 | 실패 — 동일 |
| WebSearch | 아동화용언어체크리스트 CPLC 표준화 2024 2025 출판 | 실패 — 동일 |
| WebSearch | CCC-2 아동용의사소통체크리스트 한국판 표준화 인싸이트 | 실패 — 동일 |
| WebSearch | K-SIB-R 한국판 적응행동검사 가격 실시자격 | 실패 — 동일 |
| WebFetch google.com/search | KOPLAC 화용언어검사 가격 | 실패 — Google 접근 오류 페이지만 반환 |
| WebFetch search.naver.com | KOPLAC 화용언어검사 가격 | 실패 — "Claude Code is unable to fetch from search.naver.com" (도메인 차단) |
| WebFetch html.duckduckgo.com/html | KOPLAC 화용언어검사 가격 | 실패 — 캡차 페이지 |
| WebFetch html.duckduckgo.com/html | CCC-2 한국판 화용언어 표준화 | 실패 — 캡차 페이지 |
| WebFetch html.duckduckgo.com/html | 성인 화용언어 평가도구 La Trobe | 실패 — 캡차 페이지 |
| WebFetch bing.com/search | KOPLAC 화용언어검사 가격 파라다이스 | 실패 — 무관한 캐시(MISUMI 산업부품 사이트) 반환 |
| WebFetch inpsyt.co.kr (홈, 검색페이지) | REVT 등 | 실패/불충분 — SPA라 정적 HTML에 상품정보 없음 |
| Semantic Scholar API (x3) | La Trobe Korean / AQ Korean / RAADS-R Korean | 실패 — HTTP 429 Too Many Requests |
| WebFetch inpsyt.co.kr/psy/item/view/{REVT,KSIBR,UTAP2,PRES,SCQ,CSLT}_CO_SG | 상품코드 추측 | 실패 — HTTP 500 (코드 불일치로 추정) |

## 2. 성공한 검색 — RISS(riss.kr/search/Search.do?query=...) (날짜 전부 2026-09-14)
| 검색어 | 결과 건수(표시분) | 핵심 결과 |
|---|---|---|
| K-SIB-R 적응행동검사 | 국내논문 3+, 학위논문 3+, 단행본 3 | 학지사 2007 실시요강 확인, 표준화 표본 상세 없음 |
| PRES 취학전 아동 언어발달척도 | 논문 3+, 학위논문 3+, 단행본 3 | 김영태(2000) 개발논문(CSD 5-1) 확인 |
| REVT 수용표현어휘력검사 | 논문 3+, 학위논문 3, 단행본 2 | 김영태 외(2009) 개발/타당도 논문 확인, 서울장애인종합복지관 출판 |
| ADOS 한국판 자폐진단관찰스케쥴 | 2건(학위논문) | 도구 자체 표준화 논문은 미확인, 활용 연구만 |
| U-TAP 우리말 조음음운검사 | 논문 3+, 학위논문 3, 단행본 3 | U-TAP2(2018) 타당도 논문(CSD 23-4) 확인 |
| KISE-SAB 국립특수교육원 | 단행본 3(교과서 인용 수준) | 도구 상세정보 확보 실패 |
| 화용언어검사 한국어 | 논문 3 | "화용언어능력" 표현만, 특정 검사명 없음 |
| K-Vineland Vineland 적응행동척도 | 논문 3+, 학위논문 3, 단행본/저널 각 1+ | K-Vineland-3 표준화 활발(2023-2025), K-Vineland-2(2015) 확인 |
| BAPQ | 국내논문 2, 학위논문 2, 해외논문 다수 | 김효정·김기호(2022,2025) BAPQ 개념 활용 논문 확인, 정식 한국어 타당화 논문은 미확인 |
| RAADS-R | 해외논문(독일·페르시아·브라질판)만 | 한국어판 0건 |
| 라트로브 의사소통(La Trobe) | 0건 (2회 재검색: "라트로브 의사소통 설문지 La Trobe", "라트로브 의사소통") | 한국어판 확인 안 됨 |
| 자폐스펙트럼 지수 성인 타당화 / 김혜리 자폐스펙트럼지수 한국판 | 0건 (2회) | K-AQ 확인 안 됨 |
| KOSECT | 논문 3+, 연구보고서 1 | 구문의미이해력검사 확인 — 화용 아닌 구문검사 |
| K-ADI-R 자폐진단면담지 | 0건 | 확인 안 됨 |
| TOPS 한국판 언어문제해결력 | 1건(무관 가능성) | 한국 표준화판 확인 안 됨 |
| 성인 화용언어 뇌손상 | 1건(무관 단행본) | 성인 화용 도구 확인 안 됨 |
| 화용언어체크리스트 성인용 | 0건 | 확인 안 됨 |
| 아동화용언어체크리스트 CPLC | 국내논문 3+, 학위논문 5, 연구보고서 2 (2015~2025) | 오소정(2018) 타당도 연구 확인, 상용 출판 근거 없음 |
| 사회반응척도 SRS 한국판 | 0건 | K-SRS 확인 안 됨 |
| 사회적의사소통설문지 타당화 | 관련 1건 | **김주현 외(2015), 소아청소년정신의학 26(3), "한국어판 사회적 의사소통 설문지 타당화 연구" 확인** |
| 성인 사회적 의사소통 척도 한국어 타당화 | 0건 | 확인 안 됨 |
| 배소영 화용언어검사 실시자 자격 | 0건 | 확인 안 됨 |
| 화용능력검사 화용발달검사 | 0건 | KOPLAC/CPLC 외 제3의 도구 확인 안 됨 |
| 성인기 자폐스펙트럼 선별 척도 개발 | 0건 | 확인 안 됨 |
| C-SLT 아동 사회적 언어 검사 | 1건 | **천근아(2024), 인싸이트, 만 6-12세 확인** |
| COCL 의사소통장애 평정척도 | 0건 | 확인 안 됨 |
| 아동용의사소통체크리스트 한국판 | 단행본 3(교과서) | CCC-2 한국 표준화 확인 안 됨 |
| K-CCC | 완전 무관 결과만(심혈관/화학/공학) | K-CCC라는 도구 자체가 존재하지 않는 것으로 판단 |
| 오소정 화용 표준화 | 논문 3 | 2023-2026년 최신 CPLC 표준화/출판 발표 확인 안 됨 |

## 3. 성공한 검색 — 판매처 직접 접근
| URL | 확인 내용 |
|---|---|
| https://www.isorimall.com (홈) | 카테고리 구조 확인: 진단평가도구>언어(cate1=1000&cate2=1012) |
| https://www.isorimall.com/category/995812?cate1=1000&cate2=1012 (1p) | KOPLAC SET 160,000원/검사지 120,000원/지침서 40,000원, C-SLT 130,000원 등 20개 상품 |
| 동일 URL &page=2 | LSSC 200,000원, U-TAP2 120,000원, PK-WAB-R 490,000원 등 20개 상품, PRES/REVT/SCQ/Vineland/ADOS/ADI/TOPS 없음 |
| 동일 URL &page=3 | REVT 380,000원, PRES 300,000원, 구문의미이해력검사(KOSECT) 97,000원, 언어문제해결력검사 100,000원 등 14개 상품 |
| https://www.isorimall.com/category/995812...&pid=bea0044 | KOPLAC SET 상세: "사용기관 외 업체 구매가 불가능합니다", 소요시간 60-90분 |
| https://www.isorimall.com/category/995812...&pid=baa0779 | C-SLT 상세: 판매가 10,000원(옵션 항목으로 추정, SET 전체가 아닐 가능성) |
| https://www.inpsyt.co.kr/sitemap.xml | 상품코드 패턴 확인(예: LSSC_CO_SG), REVT/K-SIB-R 등 코드 특정 실패 |
| https://inpsyt.co.kr/psy/item/view/LSSC_CO_SG | LSSC 가격 확인: SET 200,000원 / 전문가지침서 10,000원 / 기록용지·온라인코드 4,000원 |
| https://www.paradise.or.kr | 4대 사업 영역 확인(장애인식개선/문화예술향유/현장지원/수익사업), 개별 제품 가격 없음 |
| https://www.paradise.or.kr/front/businessinfo/businessinfo.asp?cate=23 | 판매 채널이 아이소리몰(isorimall.com)임을 확인, 가격 정보 자체는 없음 |

## 4. 성공한 검색 — 학술 API/원문
| 소스 | 검색어 | 결과 |
|---|---|---|
| Crossref API (api.crossref.org/works) | Korean pragmatic language children communication checklist | Song, Yang, Kim Y.T., Yim(2016) CCC 메타분석(doi:10.12963/csd.16302) 등 확인, CCC-2 한국 표준화 논문은 없음 |
| e-csd.org (doi.org/10.12963/csd.18467 경유) | KOPLAC 원 개발논문 | 실시자(언어병리 전공 대학원생/석사), 내용타당도 검토자(1급 언어재활사, 10년 이상 경력) 확인. 대상 만 5-12세. 표준화 표본 총 492명(예비 222+규준 270), 서울·경기 거주 아동 |

## 5. NOT FOUND 최종 목록 (검색 완료, 확인 불가로 결론)
- CCC-2 한국 표준화판 자체 (RISS + Crossref, 2026-09-14)
- K-SIB-R 가격/실시자격 (RISS + inpsyt 코드 추측, 2026-09-14)
- TOPS 한국판 (RISS, 2026-09-14)
- K-WFA 지시 대상 특정 (RISS + 카탈로그, 2026-09-14)
- K-ADI-R (RISS, 2026-09-14)
- K-SRS 사회반응척도 한국판 (RISS, 2026-09-14) — 표기가 다를 가능성 있어 후속 재검색 권고
- La Trobe Communication Questionnaire 한국판 (RISS 2회, 2026-09-14)
- K-AQ 자폐스펙트럼지수 한국판 (RISS 2회, 2026-09-14) — 해외 다수 언어판 존재와 대비되어 이례적, 재검색 권고
- K-RAADS-R (RISS, 2026-09-14)
- K-BAPQ 정식 타당화 논문 (RISS, 2026-09-14) — 번역판 연구 활용 흔적은 있음
- COCL 의사소통장애 평정척도 (RISS, 2026-09-14)
- 화용언어체크리스트 성인용 (RISS, 2026-09-14)
- CPLC 상용 출판 여부 (RISS, 2026-09-14)

## 6. 후속 조사 권고 (이번 세션에서 못한 것)
- WebSearch 예산이 복구되면 구글/네이버로 "K-AQ", "RAADS-R 한국판", "BAPQ 한국판" 재검색 — RISS 미등재 학회 자료·석사논문·병원 자체 개발 척도가 있을 가능성 배제 못함
- KCI(kci.go.kr), DBpia(dbpia.co.kr) 직접 검색 — 이번 세션에서 시도 자체를 못함(시간 제약)
- 인싸이트(inpsyt.co.kr) 정확한 상품코드 확보 — 고객센터 문의 또는 로그인 후 검색 기능 이용 필요(비로그인 SPA라 WebFetch 한계)
- C-SLT(천근아, 2024)의 정확한 SET 가격, 하위검사 구성, 화용 영역 상세 — 지침서 목차 원문 확인 필요
