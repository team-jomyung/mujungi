# -*- coding: utf-8 -*-
"""타겟 후보 실현가능성 표를 만든다. 손으로 적지 않고 근거 파일에서 세어 채운다.

    python build_target_matrix.py

근거
  FINAL_CLOSURE/01_EVIDENCE/SCD_STUDY_CENSUS.csv      T1~T3 의 연구 수·자료 성격
  FINAL_CLOSURE/01_EVIDENCE/DATASET_CENSUS_*.csv      공개 데이터셋·라이선스
  00_DECISION/_agent_target_clinical.md               T4~T7
  00_DECISION/_agent_target_nonclinical.md            T8~T11
  00_DECISION/_recruit_ko_draft.md · _tools_ko_draft.md   모집·도구·IRB

규칙
  임상군 · 준임상 · 비임상을 섞어 세지 않는다. POPULATION_TYPE 으로 나눈다.
  단위가 다른 수를 합치지 않는다. participant / study / dataset 을 구분해 적는다.
  모르는 칸은 UNKNOWN 으로 적고 비우지 않는다. 비우면 읽는 쪽이 0 으로 읽는다.
"""
from __future__ import annotations

import csv
import io
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
CENSUS = os.path.normpath(os.path.join(
    HERE, '..', '..', 'FINAL_CLOSURE', '01_EVIDENCE', 'SCD_STUDY_CENSUS.csv'))

COLS = ['TARGET', 'POPULATION_TYPE', 'AGE', 'DIAGNOSIS_REQUIRED',
        'DIRECT_STUDY_COUNT', 'DIRECT_PARTICIPANT_DATA', 'DIRECT_AGE_EVIDENCE',
        'KOREAN_DIRECT_DATA', 'PUBLIC_DATASET_COUNT', 'NATURAL_CONVERSATION',
        'MULTI_TURN', 'PRAGMATIC_ANNOTATION', 'RELATIONSHIP_METADATA',
        'CONTEXT_METADATA', 'OUTCOME_DATA', 'LONGITUDINAL_DATA',
        'INTERVENTION_EVIDENCE', 'ASSESSMENT_TOOL', 'STANDARDIZED_TOOL',
        'KOREAN_TOOL', 'PUBLIC_DOWNLOAD', 'LICENSE', 'COMMERCIAL_USE', 'LLM_USE',
        'RECRUITMENT_DIFFICULTY', 'IRB_DIFFICULTY', 'VULNERABLE_POPULATION_RISK',
        'NEW_DATA_COLLECTION_FEASIBILITY',
        'UNDERSTAND_EVALUATION', 'PERFORM_EVALUATION', 'NEAR_TRANSFER',
        'FAR_TRANSFER', 'MAINTENANCE', 'REAL_WORLD_OUTCOME',
        'HUMAN_GOLD_FEASIBILITY', 'LLM_JUDGE_FEASIBILITY',
        'FATAL_BLOCKER', 'VERDICT', 'EVIDENCE_NOTE']


def scd_counts():
    """SCD 후보 셋의 수를 census 에서 직접 센다."""
    rows = list(csv.DictReader(io.open(CENSUS, encoding='utf-8', newline='')))
    DIRECT = ('STRICT_DIRECT_SCD_PARTICIPANT_STUDIES',
              'DIRECT_BUT_ALGORITHMIC_OR_PUTATIVE', 'MIXED_SPCD_ASD')
    out = {}
    for key, tag in (('6-12', '6-12'), ('13-18', '13-17'), ('18-25', '18-25')):
        sub = [x for x in rows if x['bucket'] in DIRECT
               and tag in ((x['age_bins'] or '') + ' ' + (x['age'] or ''))]
        strict = [x for x in sub if x['bucket'] == DIRECT[0]]
        out[key] = {
            'studies': len(sub),
            'strict': len(strict),
            'full': len([x for x in sub if x['fulltext_or_abstract'] == 'FULL']),
            'natural': len([x for x in sub if 'YES' in (x['natural_conversation'] or '').upper()]),
            'annot': len([x for x in sub if (x['annotation'] or '').upper().startswith('YES')]),
            'longi': len([x for x in sub if (x['longitudinal'] or '').upper().startswith('YES')]),
            'public': len([x for x in sub if (x['public_data'] or '').upper().startswith('YES')]),
            'korean': len([x for x in sub if '한국' in (x['language'] or '')]),
        }
    return out


# 공통 사실 · 네 후보 전부에 걸리는 것 (근거 · _agent_target_clinical §6 · _tools_ko_draft)
KO_TOOL_GAP = 'NONE · 한국어 표준화 화용도구는 KOPLAC 5;0~12;11 뿐 · 13세 위는 공백'
NO_PUBLIC = '0 · 13~25 임상군 다중턴 자연대화+화용주석 공개셋 0'


def build():
    c = scd_counts()
    R = []

    def add(**kw):
        row = {k: kw.get(k, 'UNKNOWN') for k in COLS}
        R.append(row)

    # ── 임상군 ──
    for key, name, age, note in (
            ('6-12', 'T1 SCD/SPCD 아동 6~12', '6-12',
             'census 직접 %d건 중 STRICT %d · 전문 %d'),
            ('13-18', 'T2 SCD/SPCD 청소년 13~18', '13-18',
             'census 직접 %d건 중 STRICT %d · 전문 %d'),
            ('18-25', 'T3 SCD/SPCD 청년 18~25', '18-25',
             'census 직접 %d건 중 STRICT %d · 전문 %d')):
        d = c[key]
        young = (key != '6-12')
        add(TARGET=name, POPULATION_TYPE='CLINICAL', AGE=age, DIAGNOSIS_REQUIRED='YES',
            DIRECT_STUDY_COUNT='%d study' % d['studies'],
            DIRECT_PARTICIPANT_DATA='STRICT %d study' % d['strict'],
            DIRECT_AGE_EVIDENCE=('WEAK · STRICT %d · 그중 전문 %d · n=1 포함' % (d['strict'], d['full'])
                                 if young else 'MODERATE · STRICT %d' % d['strict']),
            KOREAN_DIRECT_DATA='NONE · census 64건 중 한국어 SCD 연구 %d' % d['korean'],
            PUBLIC_DATASET_COUNT='%d dataset' % d['public'],
            NATURAL_CONVERSATION='%d study' % d['natural'],
            MULTI_TURN='NONE' if d['natural'] == 0 else 'PARTIAL',
            PRAGMATIC_ANNOTATION='%d study' % d['annot'],
            RELATIONSHIP_METADATA='NONE', CONTEXT_METADATA='NONE',
            OUTCOME_DATA='PARTIAL · 과제 수행만' if not young else 'NONE',
            LONGITUDINAL_DATA='%d study' % d['longi'],
            INTERVENTION_EVIDENCE=('WEAK · NDTx-01 n=39 (10~18 · ASD 또는 SCD) 1건'
                                   if young else 'PARTIAL · 아동 중재 메타분석 있음'),
            ASSESSMENT_TOOL='PARTIAL · 영어권만' if young else 'YES · KOPLAC 등',
            STANDARDIZED_TOOL='NONE · 해당 연령 없음' if young else 'YES',
            KOREAN_TOOL=KO_TOOL_GAP if young else 'YES · KOPLAC 5;0~12;11',
            PUBLIC_DOWNLOAD='NONE', LICENSE='N/A · 공개 데이터 없음',
            COMMERCIAL_USE='N/A', LLM_USE='N/A',
            RECRUITMENT_DIFFICULTY='VERY_HIGH · 병원 IRB 만 1~2개월 · 협회 경로 응답속도 미검증',
            IRB_DIFFICULTY='HIGH · 심의면제 불가 (사전사후 연결 = 개인식별정보)',
            VULNERABLE_POPULATION_RISK=('HIGH · 미성년 대리동의 · 법문상 면제 불가'
                                        if key != '18-25' else 'MODERATE · 성인이나 진단군'),
            NEW_DATA_COLLECTION_FEASIBILITY='NOT_IN_3_MONTHS',
            UNDERSTAND_EVALUATION='FEASIBLE · 우리 과제로 만든다',
            PERFORM_EVALUATION='FEASIBLE · 우리 과제로 만든다',
            NEAR_TRANSFER='FEASIBLE', FAR_TRANSFER='WEAK · 선행연구 없음',
            MAINTENANCE='FEASIBLE', REAL_WORLD_OUTCOME='NOT_ESTABLISHED · 대조군 연구 0건',
            HUMAN_GOLD_FEASIBILITY='FEASIBLE · 판정자는 타겟 집단이 아니어도 된다',
            LLM_JUDGE_FEASIBILITY='FEASIBLE',
            FATAL_BLOCKER=('모집 불가(3개월) · 한국어 평가도구 없음 · 공개 데이터 0'
                           if young else '모집 불가(3개월) · 공개 데이터 0'),
            VERDICT='NOT_RECOMMENDED',
            EVIDENCE_NOTE=(note % (d['studies'], d['strict'], d['full'])
                           + ' · 자연대화 %d · 화용주석 %d · 종단 %d'
                           % (d['natural'], d['annot'], d['longi'])))

    common_clin = dict(
        POPULATION_TYPE='CLINICAL', DIAGNOSIS_REQUIRED='YES',
        PUBLIC_DATASET_COUNT=NO_PUBLIC, PUBLIC_DOWNLOAD='NONE',
        LICENSE='N/A · 공개 데이터 없음', COMMERCIAL_USE='N/A', LLM_USE='N/A',
        KOREAN_TOOL=KO_TOOL_GAP,
        IRB_DIFFICULTY='HIGH · 심의면제 불가',
        NEW_DATA_COLLECTION_FEASIBILITY='NOT_IN_3_MONTHS',
        UNDERSTAND_EVALUATION='FEASIBLE', PERFORM_EVALUATION='FEASIBLE',
        NEAR_TRANSFER='FEASIBLE', MAINTENANCE='FEASIBLE',
        FAR_TRANSFER='WEAK · 선행연구 없음',
        REAL_WORLD_OUTCOME='NOT_ESTABLISHED · 대조군 연구 0건',
        HUMAN_GOLD_FEASIBILITY='FEASIBLE', LLM_JUDGE_FEASIBILITY='FEASIBLE')

    add(TARGET='T4 ASD 청소년 13~18', AGE='13-18',
        DIRECT_STUDY_COUNT='9 study · 메타분석 1 (2796 participant)',
        DIRECT_PARTICIPANT_DATA='YES · 직접 대화 연구 9',
        DIRECT_AGE_EVIDENCE='STRONG · 해당 연령 표본 다수',
        KOREAN_DIRECT_DATA='PARTIAL · NDTx-01 n=39 (KCT0009140)',
        NATURAL_CONVERSATION='PARTIAL · 영어권 · 공개 안 됨',
        MULTI_TURN='PARTIAL', PRAGMATIC_ANNOTATION='PARTIAL · 영어권',
        RELATIONSHIP_METADATA='NONE', CONTEXT_METADATA='NONE',
        OUTCOME_DATA='YES · RCT 2편', LONGITUDINAL_DATA='PARTIAL',
        INTERVENTION_EVIDENCE='MODERATE · Noora RCT n=30 · NDTx-01 n=39',
        ASSESSMENT_TOOL='YES · YiPP 9~17 등 영어권 3종',
        STANDARDIZED_TOOL='YES · 영어권만',
        RECRUITMENT_DIFFICULTY='HIGH · 협회 4곳 컨택 확보 · 응답속도 미검증',
        VULNERABLE_POPULATION_RISK='HIGH · 미성년 대리동의 · 면제 불가',
        FATAL_BLOCKER='공개 데이터 없음 · 한국어 평가도구 없음 · 3개월 모집 어려움',
        VERDICT='VIABLE_BUT_RISKY',
        EVIDENCE_NOTE='임상군 중 데이터 실현가능성 1위 · 막히는 것은 연구 부재가 아니라 재료 부재',
        **common_clin)

    add(TARGET='T5 ASD 청년 18~25', AGE='18-25',
        DIRECT_STUDY_COUNT='UNKNOWN · 18~25 를 분리한 표본 0',
        DIRECT_PARTICIPANT_DATA='NONE · 성인 ASD 연구는 있으나 연령 분리 안 됨',
        DIRECT_AGE_EVIDENCE='NONE · 18~25 분리 표본 0건',
        KOREAN_DIRECT_DATA='NONE',
        NATURAL_CONVERSATION='NONE', MULTI_TURN='NONE',
        PRAGMATIC_ANNOTATION='NONE', RELATIONSHIP_METADATA='NONE',
        CONTEXT_METADATA='NONE', OUTCOME_DATA='NONE', LONGITUDINAL_DATA='NONE',
        INTERVENTION_EVIDENCE='WEAK', ASSESSMENT_TOOL='NONE · 해당 연령 없음',
        STANDARDIZED_TOOL='NONE',
        RECRUITMENT_DIFFICULTY='VERY_HIGH · 한국 모집 경로 부재',
        VULNERABLE_POPULATION_RISK='MODERATE · 성인이라 동의 구조는 단순',
        FATAL_BLOCKER='연령 검증 불가 · 평가 불가 · 한국 모집 경로 부재 (셋 동시)',
        VERDICT='NOT_RECOMMENDED',
        EVIDENCE_NOTE='동의 구조가 가장 단순하다는 점만이 장점',
        **common_clin)

    add(TARGET='T6 PLI · 화용언어곤란 계열', AGE='13-25',
        DIRECT_STUDY_COUNT='UNKNOWN · 13~25 대화자료 0건',
        DIRECT_PARTICIPANT_DATA='NONE', DIRECT_AGE_EVIDENCE='NONE',
        KOREAN_DIRECT_DATA='NONE', NATURAL_CONVERSATION='NONE', MULTI_TURN='NONE',
        PRAGMATIC_ANNOTATION='NONE', RELATIONSHIP_METADATA='NONE',
        CONTEXT_METADATA='NONE', OUTCOME_DATA='NONE', LONGITUDINAL_DATA='NONE',
        INTERVENTION_EVIDENCE='WEAK', ASSESSMENT_TOOL='NONE', STANDARDIZED_TOOL='NONE',
        RECRUITMENT_DIFFICULTY='VERY_HIGH · 진단 경계 미해결 · 한국 모집 선례 0',
        VULNERABLE_POPULATION_RISK='HIGH',
        FATAL_BLOCKER='직접 근거 없음 · 모집 불가 · 진단 경계 학계 미해결',
        VERDICT='NOT_RECOMMENDED',
        EVIDENCE_NOTE='다섯 항목 전부 걸린다 · 국내 DB(RISS·KISS·DBpia) 미조회 한계 있음',
        **common_clin)

    add(TARGET='T7 DLD + 사회적화용곤란', AGE='13-25',
        DIRECT_STUDY_COUNT='1 study · 사실상 2000년 논문 1건',
        DIRECT_PARTICIPANT_DATA='NONE', DIRECT_AGE_EVIDENCE='NONE',
        KOREAN_DIRECT_DATA='NONE', NATURAL_CONVERSATION='NONE', MULTI_TURN='NONE',
        PRAGMATIC_ANNOTATION='NONE', RELATIONSHIP_METADATA='NONE',
        CONTEXT_METADATA='NONE', OUTCOME_DATA='NONE', LONGITUDINAL_DATA='NONE',
        INTERVENTION_EVIDENCE='NONE · 중재 메타분석 0 · feasibility n=9 하나',
        ASSESSMENT_TOOL='NONE', STANDARDIZED_TOOL='NONE',
        RECRUITMENT_DIFFICULTY='VERY_HIGH · 한국 코호트 없음',
        VULNERABLE_POPULATION_RISK='HIGH · 언어이해 곤란이 설명동의 자체를 위협',
        FATAL_BLOCKER='직접 근거 없음 · 중재 근거 부재 · 모집 불가 · 동의 능력 문제',
        VERDICT='NOT_RECOMMENDED',
        EVIDENCE_NOTE='임상군 중 데이터 실현가능성 최하위',
        **common_clin)

    # ── 준임상 ──
    for name, age, minor in (('T8 비진단 사회적 의사소통 곤란 청소년 13~18', '13-18', True),
                             ('T9 비진단 사회적 의사소통 곤란 청년 18~25', '18-25', False)):
        add(TARGET=name, POPULATION_TYPE='SUBCLINICAL', AGE=age,
            DIAGNOSIS_REQUIRED='NO · 선별도구로 식별',
            DIRECT_STUDY_COUNT='UNKNOWN · 준임상 대상 중재 연구 0건',
            DIRECT_PARTICIPANT_DATA='NONE',
            DIRECT_AGE_EVIDENCE='NONE · 관찰 코호트만 있고 중재 연구 없음',
            KOREAN_DIRECT_DATA='NONE',
            PUBLIC_DATASET_COUNT='0 dataset', NATURAL_CONVERSATION='NONE',
            MULTI_TURN='NONE', PRAGMATIC_ANNOTATION='NONE',
            RELATIONSHIP_METADATA='NONE', CONTEXT_METADATA='NONE',
            OUTCOME_DATA='NONE', LONGITUDINAL_DATA='NONE',
            INTERVENTION_EVIDENCE='NONE · 준임상 집단 중재 연구 0건',
            ASSESSMENT_TOOL='NONE', STANDARDIZED_TOOL='NONE', KOREAN_TOOL=KO_TOOL_GAP,
            PUBLIC_DOWNLOAD='NONE', LICENSE='N/A', COMMERCIAL_USE='N/A', LLM_USE='N/A',
            RECRUITMENT_DIFFICULTY=('BLOCKED · 한국어 선별도구가 없어 '
                                    '**누구를 부를지 정의할 수 없다**'),
            IRB_DIFFICULTY='HIGH · 선별 척도 응답이 민감정보로 다투어질 수 있다',
            VULNERABLE_POPULATION_RISK=('HIGH · 미성년 대리동의 면제 불가' if minor
                                        else 'LOW · 비진단 성인'),
            NEW_DATA_COLLECTION_FEASIBILITY='NOT_FEASIBLE · 모집 정의 불가',
            UNDERSTAND_EVALUATION='FEASIBLE', PERFORM_EVALUATION='FEASIBLE',
            NEAR_TRANSFER='FEASIBLE', FAR_TRANSFER='WEAK',
            MAINTENANCE='FEASIBLE', REAL_WORLD_OUTCOME='NOT_ESTABLISHED',
            HUMAN_GOLD_FEASIBILITY='FEASIBLE', LLM_JUDGE_FEASIBILITY='FEASIBLE',
            FATAL_BLOCKER='**선별도구 부재로 집단 정의 불가** · 중재 선행연구 0건',
            VERDICT='NOT_RECOMMENDED',
            EVIDENCE_NOTE='한국어판이 확인된 선별도구는 전부 우리 연령대 아래이거나 다른 구성개념')

    # ── 비임상 ──
    add(TARGET='T10 일반 청소년 사회적 맥락 훈련', POPULATION_TYPE='NONCLINICAL',
        AGE='13-18', DIAGNOSIS_REQUIRED='NO',
        DIRECT_STUDY_COUNT='PARTIAL · 학교 기반 사회성 훈련 연구 있음',
        DIRECT_PARTICIPANT_DATA='PARTIAL', DIRECT_AGE_EVIDENCE='MODERATE',
        KOREAN_DIRECT_DATA='NONE · 화용 대화자료 기준',
        PUBLIC_DATASET_COUNT='0 dataset · 사회적 화용 대화 기준',
        NATURAL_CONVERSATION='NONE', MULTI_TURN='NONE', PRAGMATIC_ANNOTATION='NONE',
        RELATIONSHIP_METADATA='NONE', CONTEXT_METADATA='NONE',
        OUTCOME_DATA='PARTIAL', LONGITUDINAL_DATA='PARTIAL',
        INTERVENTION_EVIDENCE='MODERATE · 일반 사회성 훈련',
        ASSESSMENT_TOOL='NONE · 화용 기준', STANDARDIZED_TOOL='NONE',
        KOREAN_TOOL=KO_TOOL_GAP, PUBLIC_DOWNLOAD='NONE', LICENSE='N/A',
        COMMERCIAL_USE='N/A', LLM_USE='N/A',
        RECRUITMENT_DIFFICULTY='HIGH · 학교 경유 필수 · 학교장 승인 + 대리동의',
        IRB_DIFFICULTY='HIGH · 미성년 · 면제 불가',
        VULNERABLE_POPULATION_RISK='HIGH · 미성년 대리동의 면제 불가',
        NEW_DATA_COLLECTION_FEASIBILITY='NOT_IN_3_MONTHS',
        UNDERSTAND_EVALUATION='FEASIBLE', PERFORM_EVALUATION='FEASIBLE',
        NEAR_TRANSFER='FEASIBLE', FAR_TRANSFER='WEAK', MAINTENANCE='FEASIBLE',
        REAL_WORLD_OUTCOME='NOT_ESTABLISHED',
        HUMAN_GOLD_FEASIBILITY='FEASIBLE', LLM_JUDGE_FEASIBILITY='FEASIBLE',
        FATAL_BLOCKER='3개월 내 학교 경유 모집 불가 · 미성년 동의 구조',
        VERDICT='NOT_RECOMMENDED',
        EVIDENCE_NOTE='제품 가치는 별개로 두고 데이터·모집만 본 판정')

    add(TARGET='T11 대학생 · 사회 초년생 사회적 의사소통 훈련',
        POPULATION_TYPE='NONCLINICAL', AGE='18-25', DIAGNOSIS_REQUIRED='NO',
        DIRECT_STUDY_COUNT='PARTIAL · 성인 사회적 기술 훈련 메타분석 있음',
        DIRECT_PARTICIPANT_DATA='PARTIAL',
        DIRECT_AGE_EVIDENCE='MODERATE · 대학생 표본 연구 다수',
        KOREAN_DIRECT_DATA='PARTIAL · 국립국어원 일상대화 말뭉치 · ETRI KEMDy20 연령 겹침',
        PUBLIC_DATASET_COUNT='2 dataset · 신청 필요 · 화용 주석 없음',
        NATURAL_CONVERSATION='PARTIAL · 일상대화 말뭉치 (임상군 아님)',
        MULTI_TURN='YES', PRAGMATIC_ANNOTATION='NONE',
        RELATIONSHIP_METADATA='PARTIAL', CONTEXT_METADATA='PARTIAL',
        OUTCOME_DATA='PARTIAL', LONGITUDINAL_DATA='NONE',
        INTERVENTION_EVIDENCE='MODERATE · 디지털 전달 메타분석 (Cai 2026)',
        ASSESSMENT_TOOL='NONE · 화용 기준', STANDARDIZED_TOOL='NONE',
        KOREAN_TOOL=KO_TOOL_GAP,
        PUBLIC_DOWNLOAD='CONDITIONAL · 국립국어원 이용약정 · ETRI 국내망',
        LICENSE='CONDITIONAL · 이용약정 제12조 5항 영리 사전승낙',
        COMMERCIAL_USE='CONDITIONAL · 사전승낙 필요',
        LLM_USE='CONDITIONAL · 비보관 옵트아웃 전제',
        RECRUITMENT_DIFFICULTY='LOW · 대학 공고 · 온라인 패널 · 3~5주',
        IRB_DIFFICULTY='MODERATE · 심의면제 불가하나 최소위험 · 신속심의 가능성',
        VULNERABLE_POPULATION_RISK='LOW · 비진단 성인',
        NEW_DATA_COLLECTION_FEASIBILITY='**FEASIBLE_IN_3_MONTHS**',
        UNDERSTAND_EVALUATION='FEASIBLE', PERFORM_EVALUATION='FEASIBLE',
        NEAR_TRANSFER='FEASIBLE', FAR_TRANSFER='WEAK · 선행연구 없음',
        MAINTENANCE='FEASIBLE', REAL_WORLD_OUTCOME='NOT_ESTABLISHED',
        HUMAN_GOLD_FEASIBILITY='FEASIBLE', LLM_JUDGE_FEASIBILITY='FEASIBLE',
        FATAL_BLOCKER='NONE · 치명 차단 없음',
        VERDICT='RECOMMENDED',
        EVIDENCE_NOTE='**3개월 안에 모집·평가까지 돌릴 수 있는 유일한 후보** · '
                      '단 화용 평가도구는 우리가 만들어야 한다 (모든 후보 공통)')
    return R


def main():
    rows = build()
    p = os.path.join(HERE, 'TARGET_FEASIBILITY_MATRIX.csv')
    with io.open(p, 'w', encoding='utf-8', newline='') as fh:
        w = csv.DictWriter(fh, fieldnames=COLS)
        w.writeheader(); w.writerows(rows)
    import collections
    print('후보 %d · 열 %d' % (len(rows), len(COLS)))
    print('  POPULATION_TYPE ·', dict(collections.Counter(r['POPULATION_TYPE'] for r in rows)))
    print('  VERDICT ·', dict(collections.Counter(r['VERDICT'] for r in rows)))
    print('  저장 ·', os.path.basename(p))
    for r in rows:
        print('    %-46s %-16s %s' % (r['TARGET'][:46], r['VERDICT'], r['FATAL_BLOCKER'][:50]))
    return 0


if __name__ == '__main__':
    sys.exit(main())
