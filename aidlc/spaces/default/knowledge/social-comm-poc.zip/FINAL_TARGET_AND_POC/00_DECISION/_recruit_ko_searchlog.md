# 검색 기록 — 한국 연구참가자 모집 경로 조사
작성일: 2026-09-14

## 0. 조사 도구 상태 (중요)
이 세션은 다수의 병렬 에이전트(약 30개 팀원)가 WebSearch 예산을 공유하는 세션이었다. 이 조사를 위해 띄운 서브에이전트 3개(집단1-협회단체 담당, 집단1병원+집단2 담당, 집단3 담당)가 착수한 시점에 **세션 WebSearch 예산이 이미 200/200 소진**되어 있어 WebSearch를 단 한 번도 성공적으로 실행하지 못했다. 오케스트레이터(본인)가 직접 WebSearch를 1회 테스트했으나 동일하게 차단 확인.

이후 조사는 전부 **WebFetch(URL 직접 접속)**로만 수행했다. 즉 "모르는 대상의 URL을 찾는" 것은 불가능했고, "이미 알거나 추정한 URL이 실제로 존재/작동하는지 검증"하는 것만 가능했다. 검색엔진 결과 페이지 자체를 WebFetch로 열어보는 우회도 시도했으나:
- `search.naver.com` — 접속 자체 거부 ("Claude Code is unable to fetch from search.naver.com")
- `www.google.com/search` — 접근 오류 페이지만 반환
- `duckduckgo.com/html` — CAPTCHA 벽
- `www.bing.com/search` — 응답은 오나 대부분 질의와 무관한 필러 콘텐츠(K-pop, 중국 기업, MS 커뮤니티 등) 반환. 간헐적으로 유의미한 도메인 후보를 던져줬으나(kpat.or.kr, broso.or.kr) 신뢰도가 낮아 별도 직접 검증 필요했음
- `web.archive.org` — 접속 자체 거부

**결론: 이 보고서의 "NOT FOUND AFTER DEFINED SEARCH" 항목 다수는 "존재하지 않음"이 아니라 "이번 세션의 도구 제약으로 확인 못함"이다.** WebSearch 예산이 복구된 뒤 재조사를 권장한다.

---

## 1. 서브에이전트 A (집단1 협회·단체 + 온라인 커뮤니티 담당) 로그
| 순서 | 검색어/URL | 도구 | 결과 |
|---|---|---|---|
| 1 | "한국자폐인사랑협회 공식 홈페이지" 등 11개 쿼리 일괄 | WebSearch | 전부 실패 — 예산 소진 |
| 2 | https://www.autismkorea.kr | WebFetch | 성공 — 한국자폐인사랑협회 공식 사이트 확인 |
| 3 | search.naver.com (2건) | WebFetch | 실패 — 접속 거부 |
| 4 | bing.com "한국장애인부모회 공식 홈페이지" | WebFetch | kpat.or.kr 후보 제시 (신뢰도 낮음) |
| 5 | duckduckgo.com/html (2건) | WebFetch | CAPTCHA 벽 |
| 6 | ko.wikipedia.org/wiki/한국장애인부모회, /전국장애인부모연대 | WebFetch | 둘 다 404 (전용 문서 없음) |
| 7 | bing.com "한국장애인부모회"(UTF-8 인코딩) | WebFetch | kpat.or.kr / kpat.kr 응답 |
| 8 | bing.com "중앙장애아동 발달장애인지원센터" | WebFetch | broso.or.kr 응답 |
| 9 | bing.com "전국장애인부모연대"(3회) | WebFetch | 무관한 필러만 |
| 10 | bing.com "한국자폐학회"(2회) | WebFetch | 무관한 결과 |
| 11 | bing.com "한국자폐교육학회" | WebFetch | 무관한 필러 |
| 12 | bing.com "세바다"(2회), "에스타스 estas"(2회) | WebFetch | 실존 확인 실패 |
| 13 | bing.com "서울시 발달장애인지원센터 or.kr" | WebFetch | seoul.go.kr 일반 페이지만 |
| 14 | bing.com "느린학습자 부모 네이버 카페" | WebFetch | 무관한 필러 |
| 15 | google.com/search "전국장애인부모연대" 등 | WebFetch | 접근 오류 페이지 |
| 16 | namu.wiki/w/한국장애인부모회, /전국장애인부모연대 | WebFetch | 둘 다 404 |
| 17 | www.broso.or.kr 재확인(2회) | WebFetch | 본문 완전히 비어있음 (JS 렌더링 추정) |
| 18 | www.kpat.or.kr / http 버전 | WebFetch | HTTP 500 에러 |

## 2. 서브에이전트 B (집단1 병원·발달센터 + 집단2 담당) 로그
- WebSearch 5건 시도 (5개 병원 연구협력 관련) → 전부 예산 소진으로 미실행 (2026-09-14)
- WebFetch `amc.seoul.kr` → 302 리다이렉트 후 성공: 아산생명과학연구원 하위 임상시험센터·IRB 메뉴 확인
- WebFetch `snuh.org` → 접속 성공하나 메뉴 콘텐츠 파싱 실패(JS)
- WebFetch `samsunghospital.com` → 인코딩 오류로 파싱 실패
- WebFetch `snubh.org` → 성공: "발달·자폐·사회성 클리닉", "임상시험센터" 확인
- WebFetch `sev.severance.healthcare` → 성공, 세부 진료과 개별 페이지는 미도달
- WebFetch `youthcenter.or.kr` → HTTP 403 차단 (도메인 실재하나 콘텐츠 접근 불가)
- WebFetch `youthcenter.seoul.kr` → DNS 오류

## 3. 서브에이전트 C (집단3 담당) 로그
- WebSearch 6건 전부 차단 (SONA/엠브레인/한국리서치/오픈서베이/Prolific/MTurk 관련)
- WebFetch 성공: hrc.co.kr, embrain.com, opensurvey.co.kr(→opensurvey.io 리다이렉트), sona-systems.com, irb.or.kr, prolific.com, nibp.kr, mturk.com/worker/help
- WebFetch 실패: panel.embrain.com(DNS), www.panelpower.co.kr(DNS), everytime.kr(빈 콘텐츠)

## 4. 오케스트레이터(본인) 직접 조사 로그 (2026-09-14)
| URL/쿼리 | 도구 | 결과 |
|---|---|---|
| "한국자폐인사랑협회 연구협조" | WebSearch | 실패 — 세션 예산 200/200 소진 확인 |
| bing.com "전국장애인부모연대 공식 홈페이지" | WebFetch | 무관한 필러 (Google 지원페이지, Zhihu 등) |
| bing.com "한국장애인부모회 공식 홈페이지" | WebFetch | 무관한 필러 |
| bing.com "한국자폐학회" | WebFetch | 무관한 필러 |
| bing.com "중앙장애아동 발달장애인지원센터 공식" | WebFetch | 무관한 필러(중앙일보 등) |
| https://www.koddi.or.kr | WebFetch | **성공** — 한국장애인개발원 공식 확인. "장애아동·발달장애인지원" 메뉴(`/service/children.jsp`) 확인. 연구협력 전용 메뉴는 없음 |
| bing.com "세바다 자폐성장애 당사자" | WebFetch | 무관한 필러 |
| bing.com "estas 에스타스 자폐성장애 당사자 단체" | WebFetch | 무관한 필러 |
| ko.wikipedia.org 내부검색 "전국장애인부모연대" | WebFetch | **부분 성공** — 전용 문서는 없으나 실존 조직임을 간접 확인(김신영 배우 문서 내 "2015년 홍보대사" 언급) |
| ko.wikipedia.org 내부검색 "한국장애인부모회" | WebFetch | **부분 성공** — 전용 문서는 없으나 실존 조직임을 간접 확인(홍경민·박가원·김주리·이찬종 문서 내 언급) |
| https://www.kpaap.or.kr | WebFetch | DNS 실패 — 잘못된 도메인 추정 |
| https://www.kpat.or.kr | WebFetch | HTTP 500 에러 (서버는 존재하나 콘텐츠 접근 불가) |
| ko.wikipedia.org 내부검색 "세바다 자폐" | WebFetch | **성공** — "세바다" 전용 문서 확인 (신경다양성 지지모임, 2026-08-14 최종수정) |
| ko.wikipedia.org 내부검색 "한국자폐학회" | WebFetch | 전용 문서 없음 확인 |
| ko.wikipedia.org/wiki/세바다 | WebFetch | **성공** — 설립 2021-10-17, 대표 조미정, 공식 블로그 http://blog.sebada.kr 확인 |
| ko.wikipedia.org/wiki/Estas | WebFetch | **성공** — 설립 2013-09-13, Facebook https://www.facebook.com/estasKorea 확인 |
| web.archive.org (kpat.or.kr) | WebFetch | 접속 거부 |
| https://www.koddi.or.kr (재확인, 메뉴 구조 프롬프트) | WebFetch | 성공 — 전체 메뉴 구조 확인 |
| https://www.amc.seoul.kr/asan/depts/child/main.do | WebFetch | 콘텐츠 파싱 실패(이미지 경로만) |
| https://www.samsunghospital.com/dept/main/index.do?DP_CODE=CPS | WebFetch | 302 리다이렉트 루프, 콘텐츠 미확보 |
| https://www.koddi.or.kr/service/children.jsp | WebFetch | **성공** — 전국 17개 시도 장애아동·발달장애인지원센터 현황, 지역센터 도메인 패턴(broso.or.kr) 확인 |
| http://www.samsunghospital.com/dept/main/index.do?DP_CODE=CPS | WebFetch | 302 리다이렉트 루프 지속, 콘텐츠 미확보 |
| https://sev.severance.healthcare/sev/department/psychiatry-child-adolescent.do | WebFetch | 404 (경로 추정 실패) |
| https://www.snuh.org/pub/dept/child_psychia/intro/index.do | WebFetch | 404 (경로 추정 실패) |
| https://www.tillionpro.com | WebFetch | DNS 실패 |
| https://www.dtspring.com | WebFetch | 접속되나 무관한 중국 기업(산둥성 자성기기 제조사) — 오도메인 |
| https://opensurvey.io/pricing | WebFetch | **성공** — "오픈서베이 데이터스페이스" SaaS 구독 가격(₩39,000/₩129,000 등) 확인. 단, 이는 셀프서비스 설문툴 가격이며 패널 응답자 단가는 별도 |
| https://panel.embrain.com | WebFetch | DNS 실패 |
| https://www.hrc.co.kr | WebFetch | **성공** — "HRC Master Sample"(hrc-ms.com) 링크, 연락처(02-3014-1000, hankook@hrc.co.kr) 확인 |
| https://www.broso.or.kr (재확인) | WebFetch | 본문 비어있음 (JS 렌더링 추정, 도메인 실재는 koddi.or.kr에서 교차 확인됨) |
| https://www.tillion.co.kr | WebFetch | DNS 실패 |
| https://www.dataspring.co.kr | WebFetch | DNS 실패 |
| https://www.embrain.com | WebFetch | **성공** — Family Site에서 "패널파워" 링크(panel.co.kr/web/) 및 자체 셀프서비스 툴 "이지서베이"(ezsurvey.co.kr) 확인 |
| https://www.hrc-ms.com | WebFetch | 접속되나 제목 외 콘텐츠 파싱 실패 |
| https://www.youthhub.kr | WebFetch | 접속됨(DNS 정상)이나 콘텐츠 파싱 실패(JS 추정) |
| https://www.prolific.com/demographics | WebFetch | 404 |
| https://www.panel.co.kr/web/ | WebFetch | **성공(부분)** — 페이지 제목 "엠브레인 패널파워" 확인, 가격정보는 JS 렌더링으로 미확보 |
| https://www.bumo.or.kr | WebFetch | **성공** — 전국장애인부모연대 공식 홈페이지 확정 (대표 윤종술, TEL 02-723-4804, jbumo@hanmail.net) |
| https://www.kpaema.or.kr | WebFetch | DNS 실패 |
| https://www.bumo.or.kr (메뉴 구조 재확인) | WebFetch | 성공 — 전체 메뉴 확인, "전국장애인가족지원센터협의회" 하위조직(지역센터안내 메뉴 포함) 발견. 연구협력 전용 메뉴는 없음, 1:1상담/이메일로 문의 가능 |
| https://www.kpad.or.kr (https/http 각 1회) | WebFetch | "self signed certificate" 오류 — 도메인은 실재 가능성 있으나(서버 응답 있음) 인증서 문제로 콘텐츠 확인 불가 |

## 5. 미해결 항목 요약 (재조사 필요)
- 한국장애인부모회 공식 URL 확정 (kpat.or.kr=500에러, kpad.or.kr=인증서오류 — 둘 다 서버는 존재하는 것으로 보이나 콘텐츠 미확인)
- 한국자폐학회, 한국자폐교육학회 — 공식 URL 전혀 못 찾음
- 지역발달장애인지원센터 개별 URL (broso.or.kr 자체가 JS 렌더링이라 세부페이지 미확인)
- 프랜차이즈 발달센터/사설 언어치료실 구체 목록
- 네이버 카페 등 온라인 커뮤니티 이름·규모 (검색 자체 불가)
- 데이터스프링, 틸리언(프로) 공식 도메인
- 참가비 상식선의 1차 출처(공개된 금액 기준표)
