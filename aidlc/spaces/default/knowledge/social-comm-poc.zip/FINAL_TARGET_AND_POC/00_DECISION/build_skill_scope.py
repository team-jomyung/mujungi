# -*- coding: utf-8 -*-
"""Skill Scope v0.1 을 최종 판정한다. D-05 를 HUMAN BLOCKER 로 남기지 않는다.

    python build_skill_scope.py

무엇이 바뀌었나
  타겟이 **비임상 18~25 (TECHNICAL_POC_TARGET)** 로 정해졌다.
  앞 판정은 임상 표본의 행동 결과(A-EMP)를 CORE 의 요건으로 삼았다.
  타겟이 비임상이면 그 요건이 그대로일 수 없다. **규칙을 다시 적는다.**

  그렇다고 규칙을 느슨하게 만드는 것이 아니다. **요건을 바꾸되 똑같이 적용한다.**
  그리고 텍스트 제품이므로 **관찰 가능성이 새 탈락 사유가 된다.**

판정 규칙 · 한 번 적고 모두에 똑같이 적용한다

  CORE         구인 근거 있음 AND 비임상 변이 근거 있음
               AND 텍스트로 관찰 가능 AND 생성 가능 AND 채점 가능
  CONDITIONAL  위 중 하나가 비었으나 **조건을 달면 훈련할 수 있다**
  SEED_ONLY    구인은 있으나 이 과제 형태의 근거가 없다. 씨앗으로만 쓴다
  EXCLUDE      **텍스트로 볼 수 없다.** 음성·영상이 있어야 한다

  마지막 줄이 이번에 새로 생긴 탈락 사유다. 앞 판은 FUTURE_AUDIO 로 미뤘는데
  **제품이 텍스트인 이상 미루는 것이 아니라 빼는 것이 맞다.** 필요해지면 그때 다시 넣는다.
"""
from __future__ import annotations

import csv
import io
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
OUT_CSV = os.path.join(HERE, 'SKILL_SCOPE_V0_1_FINAL.csv')
OUT_MD = os.path.normpath(os.path.join(HERE, '..', 'SKILL_SCOPE_V0_1_FINAL.md'))
OUT_JSON = os.path.normpath(os.path.join(HERE, '..', '03_B', 'skill_scope_v0_1.json'))

COLS = ['skill_id', 'skill_ko', 'clinical_construct_evidence',
        'direct_nonclinical_evidence', 'korean_data', 'text_observability',
        'scenario_generation', 'performance_measurability', 'automation',
        'verdict', 'condition', 'rationale']

# 근거 출처는 전부 기존 문서에서 온다. 새 주장을 만들지 않는다.
#   FINAL_CLOSURE/02_SCOPE/ONTOLOGY_SCOPE_FINAL.md
#   FINAL_CLOSURE/01_EVIDENCE/EVIDENCE_LEDGER.csv · DATASET_CENSUS_KO.csv
#   00_DECISION/_agent_target_nonclinical.md
S = [
    dict(
        skill_id='S1', skill_ko='청자 맞춤 정보 조절 (상대 지식 · 정보량)',
        clinical_construct_evidence='STRONG · DSM-5 A2 · Bishop & Adams 1989 II "too much or too little information"',
        direct_nonclinical_evidence='MODERATE · Arvidsson 2022 전형 청소년 11~12 · 15~16 · Diez-Itza 2022 성인',
        korean_data='PARTIAL · 화용 평가셋 양 격률 30문항 · ToM-Diary',
        text_observability='YES · 사용자가 무엇을 말했고 상대가 무엇을 알았는지 글에 남는다',
        scenario_generation='YES · 관계·장면을 바꿔도 정보 격차 구조가 유지된다',
        performance_measurability='YES · 말한 정보량과 상대가 이미 아는 것의 차이로 앵커를 쓴다',
        automation='YES · 텍스트만으로 판정 가능',
        verdict='CORE', condition='',
        rationale='일곱 기준을 전부 통과한다. 규격 Core 다섯이 상대지식과 정보량을 구분하지 못해 한 서명으로 합친 판정도 그대로 유지한다'),
    dict(
        skill_id='S2', skill_ko='관계 · 상황 맞춤 조정',
        clinical_construct_evidence='STRONG · DSM-5 A2 에 예시까지 · Bishop 1994 행동 결과',
        direct_nonclinical_evidence='STRONG · Holtgraves & Yang 1992 한국 표본 · P·D·R 이 비가산적으로 상호작용',
        korean_data='YES · 한국어 화행 연구 다수 · 관계는 우리 스키마 필수값',
        text_observability='YES · 관계 유형이 사건 스키마의 필수 필드다',
        scenario_generation='YES · 관계 변형이 POC B 의 주축이다',
        performance_measurability='YES · 같은 내용을 관계에 따라 다르게 말했는가로 본다',
        automation='CONDITIONAL · 관계별 성능을 따로 내야 한다. direct_check_allowed 가 규범으로 흐를 자리',
        verdict='CORE',
        condition='A2 에서 **관계별 성능을 반드시 분리 보고**한다. 한 숫자로 합치지 않는다',
        rationale='비임상 성인에게 오히려 더 두껍다. 대학·직장 진입기가 관계 조정을 가장 자주 요구하는 자리다'),
    dict(
        skill_id='S3', skill_ko='대화 속 함축 · 비문자 의미 이해',
        clinical_construct_evidence='STRONG · DSM-5 A4 명시 · Bishop & Adams 1989 II · Svindt 2021 SPCD 표시 표본 1건',
        direct_nonclinical_evidence='MODERATE · 일반 화용 문헌에서 가장 많이 측정된 구인',
        korean_data='YES · 간접 화행 평가셋 240 · 한국어 화용 평가셋',
        text_observability='YES · 오간 말에서 직접 보인다',
        scenario_generation='YES · 씨앗이 가장 풍부하다',
        performance_measurability='YES · 알아챘는가 / 못 알아챘는가가 응답에 드러난다',
        automation='YES',
        verdict='CORE', condition='',
        rationale='우리 제품의 중심 기술이다. 비임상에서도 구인 타당성이 가장 안정적이다'),
    dict(
        skill_id='S4', skill_ko='응답성 · 상호성',
        clinical_construct_evidence='MODERATE · PLI 행동 결과 둘(Bishop 2000 · Bishop 1994) · 한국 SCD 관찰(Jin & Pae 2014)',
        direct_nonclinical_evidence='WEAK · 비임상 성인에서 응답성 자체를 잰 결과를 찾지 못했다',
        korean_data='PARTIAL · 일상 대화 말뭉치에 턴 구조는 있으나 주석 없음',
        text_observability='CONDITIONAL · **다중 턴이 있어야 보인다.** 한 턴만 적힌 사건에서는 안 보인다',
        scenario_generation='YES',
        performance_measurability='CONDITIONAL · 턴이 둘 이상일 때만',
        automation='YES',
        verdict='CONDITIONAL',
        condition='사건에 **상대 턴이 둘 이상** 있을 때만 판정한다. 없으면 N/A 로 둔다',
        rationale='임상 근거는 있으나 비임상 변이 근거가 얇고 관찰에 조건이 붙는다. 훈련은 하되 근거 기반이라 부르지 않는다'),
    dict(
        skill_id='S5', skill_ko='수리 · 명료화 (오해받았을 때 되돌리기)',
        clinical_construct_evidence='MODERATE · DSM-5 A3 에 명시 · 그러나 SCD/PLI 행동 결과는 부호화만',
        direct_nonclinical_evidence='MODERATE · Dingemanse 2015 수리 형식 셋 · 범언어 보편 구조',
        korean_data='PARTIAL',
        text_observability='CONDITIONAL · **상대의 오해 턴과 되돌릴 턴이 둘 다** 있어야 한다',
        scenario_generation='YES',
        performance_measurability='YES · 되돌렸는가 / 반복했는가',
        automation='YES',
        verdict='CONDITIONAL',
        condition='사건에 **오해 턴 + 되돌릴 기회**가 둘 다 있을 때만',
        rationale='진단 기준 문장에 있고 PERFORM 지표 P4 가 이미 잰다. 빼지 않되 조건을 단다'),
    dict(
        skill_id='S6', skill_ko='내가 모를 때 묻기 (명료화 요청)',
        clinical_construct_evidence='WEAK · DSM-5 에 명시 없음 · 인접 근거만',
        direct_nonclinical_evidence='MODERATE · 정보 요청은 비임상에서 흔히 측정된다',
        korean_data='PARTIAL',
        text_observability='YES',
        scenario_generation='YES',
        performance_measurability='YES',
        automation='YES',
        verdict='CONDITIONAL',
        condition='**인접 근거라는 표시를 붙여** 보고한다. 진단 기준에 없다',
        rationale='S5 와 역할이 다르다. 문헌이 수리를 모드가 아니라 역할로 나눈다'),
    dict(
        skill_id='S7', skill_ko='화제 운용 (화제 전환 · 유지)',
        clinical_construct_evidence='WEAK · DSM-5 에 이름이 직접 없다 · SCD/PLI 화제 행동 결과를 못 찾았다',
        direct_nonclinical_evidence='WEAK · 비임상 변이 근거도 못 찾았다',
        korean_data='PARTIAL · 협력적 대화 요약 말뭉치의 소주제 경계가 간접 근거',
        text_observability='CONDITIONAL · 긴 대화여야 보인다. 우리 사건은 짧다',
        scenario_generation='CONDITIONAL',
        performance_measurability='WEAK · 짧은 사건에서 화제 운용을 채점할 앵커를 못 쓴다',
        automation='YES',
        verdict='SEED_ONLY',
        condition='씨앗 생성에만 쓴다. **판정도 채점도 하지 않는다**',
        rationale='앞 판은 CONDITIONAL 이었다. **내렸다.** 우리 사건 길이(3~6문장 · 2턴)에서 화제 운용을 잴 수 없다는 것이 이번에 분명해졌다'),
    dict(
        skill_id='S8', skill_ko='반어 · 비꼼 · 간접 거절 (그 자체를 과제로)',
        clinical_construct_evidence='WEAK · A4 가 유머·중의성을 예시로 들지만 SCD 표본에서 이 과제 형태 결과 없음',
        direct_nonclinical_evidence='MODERATE · 비임상 반어 이해 연구는 많다',
        korean_data='YES · KoCoSa 비꼼 · 간접 화행 240',
        text_observability='YES',
        scenario_generation='YES',
        performance_measurability='CONDITIONAL · S3 과 겹친다. 따로 채점하면 같은 것을 두 번 센다',
        automation='YES',
        verdict='SEED_ONLY',
        condition='S3(함축 이해)의 **씨앗 소재로만** 쓴다. 독립 기술로 채점하지 않는다',
        rationale='구인이 S3 에 포함된다. 따로 두면 점수가 이중 계산된다'),
    dict(
        skill_id='S9', skill_ko='운율 · 준언어 (말투 · 억양 · 쉼)',
        clinical_construct_evidence='MODERATE · 임상 문헌에 있다',
        direct_nonclinical_evidence='MODERATE',
        korean_data='PARTIAL · ETRI KEMDy20 에 비유창 표기가 있으나 약관 미확인',
        text_observability='**NO** · 음성이 있어야 보인다',
        scenario_generation='NO', performance_measurability='NO', automation='NO',
        verdict='EXCLUDE',
        condition='제품이 음성을 다루게 되면 그때 다시 넣는다',
        rationale='앞 판은 FUTURE_AUDIO 로 미뤘다. **텍스트 제품인 이상 미루는 것이 아니라 빼는 것이 맞다.** 미뤄 두면 범위에 있는 것처럼 읽힌다'),
    dict(
        skill_id='S10', skill_ko='비언어 (시선 · 거리 · 표정)',
        clinical_construct_evidence='STRONG · DSM-5 A 에 포함',
        direct_nonclinical_evidence='STRONG',
        korean_data='NONE',
        text_observability='**NO** · 영상이 있어야 보인다',
        scenario_generation='NO', performance_measurability='NO', automation='NO',
        verdict='EXCLUDE',
        condition='영상 제품이 되면 그때',
        rationale='진단 기준의 큰 축이지만 우리 매체로 볼 수 없다. **범위 밖이라고 명확히 적는다**'),
]


def main():
    with io.open(OUT_CSV, 'w', encoding='utf-8', newline='') as fh:
        w = csv.DictWriter(fh, fieldnames=COLS)
        w.writeheader()
        w.writerows([{k: r.get(k, '') for k in COLS} for r in S])

    core = [r for r in S if r['verdict'] == 'CORE']
    cond = [r for r in S if r['verdict'] == 'CONDITIONAL']
    seed = [r for r in S if r['verdict'] == 'SEED_ONLY']
    excl = [r for r in S if r['verdict'] == 'EXCLUDE']

    # POC B 와 rubric 이 읽을 기계용 파일. 문서와 따로 놀지 않게 같은 표에서 만든다
    io.open(OUT_JSON, 'w', encoding='utf-8', newline='\n').write(json.dumps({
        'version': 'v0_1_final',
        'target': 'TECHNICAL_POC_TARGET · 18~25 nonclinical self-selected',
        'note': '이 파일은 build_skill_scope.py 가 만든다. 손으로 고치지 않는다',
        'core': [{'id': r['skill_id'], 'ko': r['skill_ko']} for r in core],
        'conditional': [{'id': r['skill_id'], 'ko': r['skill_ko'],
                         'condition': r['condition']} for r in cond],
        'seed_only': [{'id': r['skill_id'], 'ko': r['skill_ko']} for r in seed],
        'exclude': [{'id': r['skill_id'], 'ko': r['skill_ko'],
                     'why': r['text_observability']} for r in excl],
        'scored_skills': [r['skill_id'] for r in core + cond],
        'generation_skills': [r['skill_id'] for r in core + cond + seed],
    }, ensure_ascii=False, indent=2) + '\n')

    L = ['# Skill Scope v0.1 · 최종', '',
         '2026-09-14 · **D-05 를 닫는다.** HUMAN BLOCKER 로 남기지 않는다.', '',
         '대상 · **TECHNICAL_POC_TARGET · 18~25 비임상 자기선택**', '',
         '이 문서와 `03_B/skill_scope_v0_1.json` 은 `00_DECISION/build_skill_scope.py` 가 만든다.',
         '**손으로 고치지 않는다.** 고치면 `verify_pre_human.py` 가 잡는다.', '',
         '---', '', '## 0 · 결론', '',
         '| 판정 | 수 | 무엇 |', '|---|---|---|',
         '| **CORE** | %d | %s |' % (len(core), ' · '.join(r['skill_id'] for r in core)),
         '| **CONDITIONAL** | %d | %s |' % (len(cond), ' · '.join(r['skill_id'] for r in cond)),
         '| SEED_ONLY | %d | %s |' % (len(seed), ' · '.join(r['skill_id'] for r in seed)),
         '| **EXCLUDE** | %d | %s |' % (len(excl), ' · '.join(r['skill_id'] for r in excl)),
         '',
         '**채점하는 기술은 CORE %d + CONDITIONAL %d = %d 개다.**'
         % (len(core), len(cond), len(core) + len(cond)),
         '생성에는 SEED_ONLY 까지 %d 개를 쓴다.' % (len(core) + len(cond) + len(seed)),
         '', '---', '', '## 1 · 판정 규칙 · 한 번 적고 모두에 똑같이 적용한다', '',
         '```',
         'CORE         구인 근거 있음 AND 비임상 변이 근거 있음',
         '             AND 텍스트로 관찰 가능 AND 생성 가능 AND 채점 가능',
         'CONDITIONAL  위 중 하나가 비었으나 조건을 달면 훈련할 수 있다',
         'SEED_ONLY    구인은 있으나 이 과제 형태의 근거가 없다. 씨앗으로만',
         'EXCLUDE      텍스트로 볼 수 없다. 음성 · 영상이 있어야 한다',
         '```', '',
         '### 앞 판과 무엇이 다른가', '',
         '| | 앞 (임상 타겟) | 지금 (비임상 타겟) |', '|---|---|---|',
         '| CORE 요건 | A-EMP · **임상 표본의 행동 결과** | 구인 근거 + **비임상 변이 근거** |',
         '| 매체 | 명시 안 함 | **텍스트로 볼 수 없으면 EXCLUDE** |',
         '| 음성 · 영상 | FUTURE_AUDIO 로 미룸 | **EXCLUDE 로 뺀다** |', '',
         '마지막 줄이 중요하다. 미뤄 두면 **범위에 있는 것처럼 읽힌다.**',
         '제품이 텍스트인 이상 빼는 것이 정직하다. 필요해지면 그때 다시 넣는다.', '',
         '---', '', '## 2 · 판정표', '',
         '| # | 기술 | 구인 | 비임상 | 한국어 | 텍스트 | 생성 | 채점 | 자동화 | **판정** |',
         '|---|---|---|---|---|---|---|---|---|---|']
    short = lambda v: (v.split('·')[0].strip() or v)[:12]
    for r in S:
        L.append('| %s | %s | %s | %s | %s | %s | %s | %s | %s | **%s** |'
                 % (r['skill_id'], r['skill_ko'],
                    short(r['clinical_construct_evidence']),
                    short(r['direct_nonclinical_evidence']),
                    short(r['korean_data']), short(r['text_observability']),
                    short(r['scenario_generation']),
                    short(r['performance_measurability']),
                    short(r['automation']), r['verdict']))
    L += ['', '자세한 근거는 `00_DECISION/SKILL_SCOPE_V0_1_FINAL.csv` 의 `rationale` 열.', '',
          '---', '', '## 3 · 조건이 붙은 기술', '',
          '| # | 기술 | 조건 |', '|---|---|---|']
    for r in cond + seed:
        L.append('| %s | %s | %s |' % (r['skill_id'], r['skill_ko'], r['condition']))
    L += ['', '**CONDITIONAL 은 "훈련은 하되 근거 기반이라고 부르지 않는다" 는 뜻이다.**',
          '조건이 충족되지 않은 사건에서는 **N/A 로 두고 점수를 만들지 않는다.**', '',
          '---', '', '## 4 · 뺀 것', '', '| # | 기술 | 왜 |', '|---|---|---|']
    for r in excl:
        L.append('| %s | %s | %s |' % (r['skill_id'], r['skill_ko'], r['rationale']))
    L += ['', '**비언어(S10)는 진단 기준의 큰 축이다.** 그런데 우리 매체로 볼 수 없다.',
          '"우리가 사회적 의사소통을 다룬다" 고 말할 때 **이 축이 빠져 있다는 것을 함께 적는다.**', '',
          '---', '', '## 5 · 이 판정이 바꾸는 것', '',
          '| 어디 | 무엇 |', '|---|---|',
          '| `05_PERFORMANCE/TARGET_SPECIFIC_RUBRIC.md` | 채점 기술을 CORE %d + CONDITIONAL %d 로 확정 · 앵커를 그 기술에만 쓴다'
          % (len(core), len(cond)) + ' |',
          '| `03_B` POC B prompts | 생성 기술을 %d 개로 · EXCLUDE 는 씨앗에서도 뺀다' % (len(core) + len(cond) + len(seed)) + ' |',
          '| `03_B/skill_scope_v0_1.json` | 기계가 읽는 정본. 이 스크립트가 만든다 |', '',
          '---', '', '## 6 · 이 판정이 약속하지 않는 것', '',
          '- CORE 기술이 **임상적으로 타당하다**는 것. 구인 근거는 임상 문헌에서 왔지만 대상은 비임상이다',
          '- 비임상 변이 근거가 **강하다**는 것. 대부분 MODERATE 이고 일부는 못 찾았다',
          '- 이 일곱 기준이 **완전하다**는 것. 다른 기준을 넣으면 순위가 바뀔 수 있다',
          '- 뺀 기술이 **중요하지 않다**는 것. 볼 수 없을 뿐이다', '']
    io.open(OUT_MD, 'w', encoding='utf-8', newline='\n').write('\n'.join(L))

    print('기술 %d · CORE %d · CONDITIONAL %d · SEED_ONLY %d · EXCLUDE %d'
          % (len(S), len(core), len(cond), len(seed), len(excl)))
    print('  채점 %d · 생성 %d' % (len(core) + len(cond), len(core) + len(cond) + len(seed)))
    for r in S:
        print('  %-4s %-34s %s' % (r['skill_id'], r['skill_ko'][:34], r['verdict']))
    return 0


if __name__ == '__main__':
    sys.exit(main())
