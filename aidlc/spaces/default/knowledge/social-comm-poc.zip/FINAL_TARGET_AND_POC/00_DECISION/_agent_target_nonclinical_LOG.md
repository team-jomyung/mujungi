# 검색 기록 · 비임상 타겟 후보 넷

조사일 **2026-09-14**. 조사자 target-nonclinical 에이전트.
본 보고서는 `_agent_target_nonclinical.md`.

## 0 · 조사 조건

**WebSearch 는 세션 시작 시점에 이미 예산이 소진되어 있었다(200/200).** 첫 호출에서 다음을 받았다.

```
Web search was not performed: this session has used its web search budget
(200 of 200 WebSearch calls).
```

브리프의 지시("WebSearch 예산이 소진되면 식별자 기반 직접 조회로 전환한다")에 따라 **전량 식별자 기반 직접 조회**로 수행했다. 사용한 경로는 아래 여섯이다.

| 경로 | 엔드포인트 | 용도 |
|---|---|---|
| Europe PMC REST | `ebi.ac.uk/europepmc/webservices/rest/search` | 생의학·정신의학 문헌. `resultType=core` 로 초록 확보 |
| Crossref REST | `api.crossref.org/works/{DOI}` | DOI 직접 조회. 심리·교육 저널 서지+초록 |
| OpenAlex REST | `api.openalex.org/works?search=` | 심리·교육·전산 문헌. Europe PMC 가 못 덮는 영역 |
| Semantic Scholar | `api.semanticscholar.org/graph/v1` | **429 Too Many Requests 로 3회 중 2회 실패. 조기 포기** |
| 국가법령정보 공동활용 API (DRF) | `law.go.kr/DRF/lawSearch.do` · `lawService.do` | **법령 조문 전문. `OC=test` 로 인증 통과** |
| 공식 도메인 직접 조회 | 각 제품·기관 사이트 | 제품 사양·가격·기관 안내 |

### 전환 판단 셋

**하나 · Europe PMC 는 심리·교육 저널을 못 덮는다.** Durlak 2011(*Child Development*)·Taylor 2017(*Child Development*) 검색이 0건으로 돌아왔다. → Crossref DOI 직접 조회로 전환해 둘 다 확보.

**둘 · Semantic Scholar 는 연속 호출에서 429 를 낸다.** 4회 중 2회 실패. → OpenAlex 로 전환. 이후 실패 없음.

**셋 · law.go.kr 의 사람용 URL 은 JS 렌더링이라 조문이 안 나온다.** `law.go.kr/법령/...` · `m.law.go.kr/법령/...` 모두 제목만 반환. → **DRF 공동활용 API 로 전환하니 `OC=test` 로 조문 전문이 나왔다.** 이번 조사에서 가장 값어치 있는 경로 전환이다.

---

## 1 · Europe PMC 질의 (13건)

| # | 검색어 | 결과 | 쓰임 |
|---|---|---|---|
| 1 | `"Social and Communication Disorders Checklist"` | SCDC 부모보고 확인. ALSPAC 7·11·14·16세. 일본판 ROC 0.78(PMC8170580). 힌디판 절단점 9 | §1-1 |
| 2 | `("Social Responsiveness Scale" AND "self-report" AND adult)` | SRS-2 성인 자기보고판 존재. T≥60 을 BAP 기준으로 사용한 예. 한국어판 정보 0 | §1-1 |
| 3 | `("Autism Spectrum Quotient" AND Korean)` | **K-AQ 아동판(4~11세)만 존재.** PMID 39377897, N=144 participant(ASD 72·비임상 대조 72), α=.962, 절단점 58.5, 민감도 .931, 특이도 .986 | §1-1 |
| 4 | `("social skills training" AND "meta-analysis" AND ("college students" OR "university students" OR "nonclinical"))` | 211 hits. **대학생 비임상 SST 효과크기 0건** | §3-2 |
| 5 | `"La Trobe Communication Questionnaire"` | LCQ 30 item · 성인 · 자기+지인보고 · 4요인 · α>0.9 · 재검사>0.80. **건강 성인 규준 미확립. 한국어판 0** | §1-2 |
| 6 | `("Children's Communication Checklist" AND (Korean OR adolescent OR self-report))` | CCC-2 4~17세 **부모 질문지**. 비진단 일반학교 아동 136명 적용례. **한국어판 0** | §1-1 |
| 7 | `("Liebowitz Social Anxiety Scale" AND Korean)` | 93 hits. **K-LSAS-SR 실재**(자기보고). 성인 19~40세 SAD 표본. 절단점·신뢰도 초록에 없음 | §1-1 |
| 8 | `("social emotional learning" AND "meta-analysis" AND "follow-up")` | **Kim D, Lim JH, An J (2022) PLoS One** PMID 35749356 · PMC9231796, 한국 SEL 22편, 전체 0.27. Lin 2026(중국) 52편·13,969명 | §3-2 |
| 9 | `("Social Avoidance and Distress" AND Korean)` | **K-SADS 언급 2편뿐. 문항·표본·절단점·신뢰도 전부 없음.** 구성개념도 다름 | §1-1 주의 |
| 10 | `("Broad Autism Phenotype Questionnaire")` | BAPQ 36 item · 3하위(Aloof·Rigid·**Pragmatic Language**) · 자기+정보제공자 · 대학생 타당화 있음. **한국어판 0**(말라얄람·중국어·스페인어·칸나다어는 있음) | §1-2 |
| 11 | `DOI:"10.1007/s10567-019-00308-x"` | **de Mooij 2020 초록 전문.** 비임상 97편 · 839 effect size · 프로그램 60개 · **d=.369** [.292,.447] · **추적 미분석** | §3-2 |
| 12 | `("virtual reality" OR "serious game" OR "digital intervention") AND "social skills" AND "university students"` | **비임상 대학생 디지털 훈련 엄밀 RCT 0건.** Sarpourian 2022(PMC9489082, N=30, 준실험) · Gado 2025(PMC12031922, N=48, 실험실) | §3-4 |
| 13 | `("conversational agent" OR chatbot) AND ("social skills" OR "social communication") AND (adolescent OR "young adult" OR "college student")` | **비임상 청소년·청년 대상 대화 에이전트 사회기술 훈련 연구 0건** | §5 |
| 14 | `("mobile app" OR "smartphone app" OR "digital intervention") AND "social skills" AND adolescents AND ("randomized controlled trial" OR RCT)` | 확인된 앱 중재 **전부 진단군**: JAY(PMC13255400) · VR 메타(PMC13132534) · 게임화(PMC12781649). **Cai 2026(PMC13185340) 만 비임상** | §3-2 · §5 |
| 15 | `("digital-based interventions" OR "digital based") AND "social and emotional learning" AND "K-12"` | **Cai 2026 초록 전문.** 37편 · 4,742 participant · SES 0.631→보정 0.369 · AA 0.267→보정 0.078(유의성 상실) · PB 0.285→보정 0.353 | §3-2 |
| 16 | `("Social Responsiveness Scale" AND Korean AND (validity OR validation OR reliability))` | **K-SRS-2 는 10~60개월 부모보고판.** Lee 2025 PMID 40524376·PMC12304546, N=1,326(ASD 822·비ASD 504). **일반 인구 타당화 아님** | §1-1 |
| 17 | `(("Autism Spectrum Screening Questionnaire" OR "Social Communication Questionnaire") AND Korean)` | K-SCQ 10~60개월 부모보고, 절단점 13.5/9.5/10.5/7.5/9.5 | §1-1 |
| 18 | `("Autism Spectrum Screening Questionnaire" AND ("Korean" OR "Korea") AND (school OR screening))` | **K-ASSQ 절단점 ≥14**(Bal 2022 PMC9058040, 표본 14,423/3,702/4,837 participant). Kim 2025 JAACAP Open PMID 40520973, 62,083 participant. **자기보고판 0건** | §1-4 |
| 19 | `("total population sample" AND autism AND Korea)` | **Kim YS 2011 PMID 21558103.** 55,266 participant(7~12세 전원), ASSQ, 2.64%(CI 1.91~3.37), **3분의 2가 일반학교 미진단** | §1-4 |
| 20 | `("social communication" AND prevalence AND ("general population" OR "community sample") AND adolescents)` | **일반 인구 청소년 사회적 의사소통 곤란 유병률 0건** | §1-4 |
| 21 | `DOI:"10.1017/S0033291721002166"` OR `"Developmental trajectories of autistic social traits in the general population"` | **Pender 2023 초록 전문.** N=9,744 participant, SCDC 7·10·13·16세. **Persistent High 2.3% · Increasing 7.3% · Decreasing 6.9% · Persistent Low 83.5%** | §1-4 |
| 22 | `("pragmatic language" OR "social communication") AND "self-report" AND ("young adults" OR "college students") AND (questionnaire OR scale)` | **비임상 청년 대상 화용 자기보고 전용 척도 0건.** BAPQ·SRS-2 만 반환 | §1-2 |
| 23 | `("communication competence" OR "interpersonal competence") AND Korean AND ("college students" OR "university students" OR nursing students)` | **PCI · ICQ** 가 한국 대학생 표본에 반복 사용(Choi 2021 PMID 34183923·PMC8219634, N=218 participant). **한국어 타당화 여부·문항수·신뢰도 초록에서 미확인** | §3-1 |
| 24 | `DOI:"10.1038/s41598-024-83953-9"` | **전이 분석 초록 전문.** FIELD 프레임워크, 52 experiment(ASD). **"디지털 대안이 아니라 대면 중재에서 전이가 두드러졌다"** | §3-3 |

---

## 2 · Crossref DOI 직접 조회 (3건)

| DOI | 논문 | 확보한 것 |
|---|---|---|
| `10.1111/j.1467-8624.2010.01564.x` | **Durlak, Weissberg, Dymnicki, Taylor, Schellinger (2011)** *Child Development* | 초록 전문. **213 study · 270,034 participant · 학업 11 백분위 상승.** 영역별 효과크기는 초록 밖 |
| `10.1111/cdev.12864` | **Taylor, Oberle, Durlak, Weissberg (2017)** *Child Development* 88(4):1156-1171 | **82 study · 97,406 participant · 평균연령 11.09 · 추적 6개월~18년 ·** 저SES 41.1% · 유색인종 45.9% · 미국 외 38개. **실생활 결과: 졸업률 · 안전한 성행동** |
| `10.1007/s10567-019-00308-x` | **de Mooij, Fekkes, Scholte, Overbeek (2020)** *Clin Child Fam Psychol Rev* 23(2):250-264 | 저자·권호·페이지 확정. 초록은 Crossref 에 없어 Europe PMC 로 보완 |

---

## 3 · OpenAlex 질의 (6건)

| # | 검색어 | 결과 |
|---|---|---|
| 1 | `pragmatic language assessment adolescents self-report questionnaire` | **13~25세 자기보고 화용 도구 0건.** CAT-Q(DOI 10.1007/s10803-018-3792-6) 발견 |
| 2 | `CANDOR corpus conversation turn-taking large multimodal dataset` | **CANDOR** DOI `10.1126/sciadv.adf3197`, *Science Advances*, **CC-BY-NC** |
| 3 | `Korean spoken dialogue corpus everyday conversation speaker relationship` | **한국어 자연발생 대화 코퍼스 0건** |
| 4 | `social skills training typically developing children adolescents meta-analysis Beelmann` | **de Mooij 2020 발견**(비임상 다층 메타분석). Beelmann & Lösel 원본은 미반환 |
| 5 | `near transfer far transfer social cognition training generalization everyday life` | **사회적 의사소통 훈련에서 near/far 를 분리한 비임상 연구 0건.** 반환된 전이 연구는 작업기억 계열. Sci Rep 2024 전이 분석 발견 |
| 6 | `social communication intervention subclinical autistic traits young adults randomized` | **준임상·무진단 집단 대상 중재 연구 0건.** 반환된 것은 전부 상관·특성·종단 연구 |
| 7 | `large language model roleplay social skills practice interpersonal communication training evaluation` | **arXiv 2404.04204 "Social Skill Training with LLMs"** 발견. PATIENT-Ψ(EMNLP 2024) 발견 |
| 8 | `Korean university students social anxiety prevalence communication apprehension survey` | **한국 대학생 사회불안·의사소통 불안 유병률 0건** |
| 9 | `Pragmatics Profile everyday communication skills Dewart Summers` | **Pragmatics Profile 사양 미확인.** 2024 TBI 개정판(DOI 10.1111/1460-6984.13030)만 확인 |

---

## 4 · 국가법령정보 공동활용 API (DRF) — 이번 조사의 핵심 경로

### 성공 · 조문 전문 확보

| 호출 | 결과 |
|---|---|
| `lawSearch.do?OC=test&target=law&query=생명윤리 및 안전에 관한 법률 시행규칙&type=XML` | **MST 271595** · 공포 2025-06-02 · **시행 2025-12-03** |
| `lawSearch.do?OC=test&target=law&query=생명윤리 및 안전에 관한 법률&type=XML` | 본법 **MST 276665**(시행 2025-10-01) · 시행령 **277879** · 시행규칙 **271595** |
| `lawService.do?OC=test&target=lawjosub&MST=271595&JO=001300&type=XML` | **시행규칙 제13조 전문 확보.** 제1항 본문 + 각 호(1호 가~라목 · 2호 · 3호) + **제2항 취약 대상 단서** |
| `lawService.do?OC=test&target=lawjosub&MST=276665&JO=001600&type=XML` | **법 제16조 전문 확보.** 제1항 서면동의 · **제2항 대리동의** · **제3항 동의면제 요건(대리인 동의는 면제 불가)** · 제4항 설명의무 |
| `lawService.do?OC=test&target=law&MST=271595&type=XML` (전문 + '취약' 질의) | **제13조제2항이 「의약품 등의 안전에 관한 규칙」 별표 4 제2호더목에 위임**함을 확인. **시행규칙 자체에는 정의 조문 없음** |
| `lawSearch.do?OC=test&target=law&query=의약품 등의 안전에 관한 규칙&type=XML` | **MST 284019** · 식품의약품안전처 · 시행 2026-03-05 |
| `lawSearch.do?OC=test&target=licbyl&query=의약품 임상시험 관리기준&type=XML` | **별표ID 18000689** "의약품 임상시험 관리기준(제30조제1항 관련)" 확정 |

### 실패 · 별표 본문 3회 시도 전부 실패

| 호출 | 결과 |
|---|---|
| `lawService.do?OC=test&target=licbyl&ID=18000689&type=HTML` | 네비게이션 요소만 반환 |
| `lawService.do?OC=test&target=licbyl&ID=18000689&type=XML` | 동일 |
| `lawService.do?OC=test&target=licbyl&ID=18000689&type=JSON` | 동일 |

**판정.** 별표는 별도 첨부파일로 배포되는 것으로 보인다. **취약한 환경에 있는 시험대상자의 열거 목록을 확정하지 못했다.** 위임 경로(시행규칙 제13조제2항 → 의약품규칙 별표 4 제2호더목 → 별표ID 18000689)는 확정했으므로 다음 세션이 이어받을 수 있다.

### 실패 · 사람용 URL (JS 렌더링)

| URL | 결과 |
|---|---|
| `law.go.kr/법령/생명윤리및안전에관한법률시행규칙` | 제목만 반환 |
| `law.go.kr/법령/생명윤리및안전에관한법률시행규칙/제13조` | 조문 없음 |
| `m.law.go.kr/법령/생명윤리및안전에관한법률시행규칙` | **HTTP 404** |

---

## 5 · 기관·공식 도메인 직접 조회

| URL | 결과 |
|---|---|
| `public.irb.or.kr/` | 공용위원회 e-IRB. 하위 페이지 URL 확보 |
| `public.irb.or.kr/pt/pt01/PT0103/PT0103R01.do` | **인간대상연구 정의(법 제2조제1호) 원문 확보.** 심의면제 사유 **요약 세 줄**까지. **신속심의 대상 유형은 미기재** |
| `irb.or.kr/` | **폐쇄 안내.** `public.irb.or.kr` · `review.irb.or.kr` · `nibp.kr` 로 분산 |
| `nibp.kr/` | 국가생명윤리정책원 홈. **심의면제·신속심의·취약 대상 지침 하위 URL 미노출** |
| `irb.snu.ac.kr/` | **로그인 게이트.** 콘텐츠 0 |
| `cre.re.kr/` | **DNS 미해결 (ENOTFOUND)** |
| `kli.korean.go.kr/request/corpusRegist.do` | (`corpus.korean.go.kr` 에서 301 리다이렉트) **일상 대화 음성 말뭉치 2020~2025 전 연도판 배포 확인.** 구어(v1.2)·메신저(v2.0)·온라인 대화(2021 v1.1). 신청 시 이용기간 최소 5일. **영리 이용 가부 미기재** |
| `kli.korean.go.kr/corpus/main/requestMain.do` | 모두의 말뭉치 **141종**. **연도판별 규모·화자 메타·상세 URL 미노출** |
| `aihub.or.kr/aihubdata/data/list.do?searchKeyword=대화` | **인터뷰 진행 멀티턴 데이터**(한국어, 10,887,968 bytes) · 금융분야 고객상담(319,957,349 bytes) · 베트남·말레이시아 콜센터(538,805,232 bytes). **일상 사회적 대화 0건** |
| `aihub.or.kr/aihubdata/data/list.do?currMenu=115&...` (전체 목록) | 977개 중 최신 20개만 노출. **대화 데이터셋 목록 확인 불가** |
| `opensurvey.io/` | (`opensurvey.co.kr` 에서 302) **패널 규모·연령 커버리지·가격 전부 미공개.** 청소년 패널 가부 미기재 |
| `pearsonassessments.com/.../p/100001940.html` | **SSIS SEL 확보.** 3~18세 · 부모/교사/**학생 자기보고** · 10~25분 · **Level B** · 키트 $583.60 / 디지털 $425.30 / 인쇄 $523.60 / 폼 25매 $72.10 / 매뉴얼 $174.20. **문항 수 미기재** |
| `wpspublish.com/srs-2-...` | **HTTP 403 Forbidden.** SRS-2 가격·자격·연령 확인 불가 |
| `autismresearchcentre.com/tests/autism-spectrum-quotient-aq/` | AQ 청소년판 · 영문판+채점표 무료 다운로드 · **20개 이상 언어 번역본. 한국어 없음.** **이용약관 문구가 페이지에 없음** |
| `pg.casel.org/` | **등재 프로그램 수·연령 범위·평가 기준 전부 미기재.** 등급명(SELect·Promising·SEL-Supportive)만 |
| `yoodli.ai/` | **직장인 대상**(영업·관리자·L&D). 학생·구직자 아님. Google Cloud 15,000명+ · Snowflake 1,200시간+ · Harness 75%. SOC 2 Type 2 · GDPR. **동료심사 연구 없음** |
| `virtualspeech.com/` | 기업 + 학교·대학. 브라우저+VR. **어려운 대화·고객 대화·멘토링 포함.** 자체 수치 25.9% 향상 · 170k+ 롤플레이 · 93% 추천. IE University · Central Connecticut State University. **동료심사 연구 없음** |
| `mursion.com/` | 기업 L&D. 아바타 시뮬레이션. Fortune 100 의 1/3 이상. 1,800만 분+ · 관련성 91% · 자신감 80%. **고등교육 학생 특화 아님. 동료심사 연구 링크 없음** |
| `arxiv.org/abs/2404.04204` | **Yang, Ziems, Held, Shaikh, Bernstein, Mitchell (2024)** "Social Skill Training with Large Language Models". **AI Partner / AI Mentor (APAM) 프레임워크.** 2024-04-05 제출. **초록 기준 사람 대상 연구 보고 없음** |

---

## 6 · Semantic Scholar (조기 포기)

| 호출 | 결과 |
|---|---|
| `paper/search?query=impact of enhancing students social and emotional learning...` | **HTTP 429** |
| `paper/search?query=Taylor Oberle Durlak Weissberg follow-up effects...` | 성공. **Taylor 2017 DOI `10.1111/cdev.12864` 확정**(인용 2,065회) |
| `paper/search?query=Korean adolescents social skills training program effect meta-analysis` | **HTTP 429** |
| `paper/search?query=The impact of enhancing students social and emotional learning...` | **HTTP 429** |

**4회 중 3회 429. 이후 OpenAlex 로 전환하고 다시 쓰지 않았다.**

---

## 7 · 프로젝트 내 선행 실사 인용

이번 조사에서 **재확인하지 않고 인용만** 한 파일 둘. 본 보고서에 〔타 세션〕으로 표기했다.

| 파일 | 인용한 내용 |
|---|---|
| `research/국내_화용평가도구.md` | KOPLAC 만 5;0~12;11 · CPLC 5~13세 · **15~30세 한국어 표준화 화용 도구 확인 불가** · RISS 화용언어 표준화 성인 0건 · 청소년 화용언어 국내 도구 개발 0건 |
| `research/데이터셋_실사.md` | **SCD 라벨 대화 데이터 전 세계 0건** · 국어원 말뭉치 2023판 1,973 conversation·2,168 participant·start/end 시간정보·화자 간 관계·접촉 빈도·약관 제12조 5항 · ETRI KEMDy20 80 participant·19~39세·9,900 utterance·2026-04-13부터 wav 제외 · INCA-A 109,465 code(일반 아동·영어) · CANDOR 1,656 conversation |

---

## 8 · NOT FOUND AFTER DEFINED SEARCH · 목록

브리프 형식대로 **검색 DB · 검색어 · 날짜**를 붙여 다시 모은다. 전부 **2026-09-14**.

| # | 찾지 못한 것 | DB | 검색어 |
|---|---|---|---|
| 1 | 준임상·무진단 사회적 의사소통 집단 대상 **중재 연구** | OpenAlex | `social communication intervention subclinical autistic traits young adults randomized` |
| 2 | 비임상 청소년·청년 대상 **대화 에이전트 사회기술 훈련** 연구 | Europe PMC | `("conversational agent" OR chatbot) AND ("social skills" OR "social communication") AND (adolescent OR "young adult" OR "college student")` |
| 3 | 비임상 대학생 **디지털 사회적 의사소통 훈련 엄밀 RCT** | Europe PMC | `("virtual reality" OR "serious game" OR "digital intervention") AND "social skills" AND "university students"` |
| 4 | **한국어 자연발생 대화 코퍼스**(학술 문헌 경로) | OpenAlex | `Korean spoken dialogue corpus everyday conversation speaker relationship` |
| 5 | 13~25세 **자기보고 화용 도구** | OpenAlex | `pragmatic language assessment adolescents self-report questionnaire` |
| 6 | 비임상 청년 대상 **화용 자기보고 전용 척도** | Europe PMC | `("pragmatic language" OR "social communication") AND "self-report" AND ("young adults" OR "college students") AND (questionnaire OR scale)` |
| 7 | 사회적 의사소통 훈련에서 **near/far 전이 분리**(비임상) | OpenAlex | `near transfer far transfer social cognition training generalization everyday life` |
| 8 | 일반 인구 청소년 **사회적 의사소통 곤란 유병률** | Europe PMC | `("social communication" AND prevalence AND ("general population" OR "community sample") AND adolescents)` |
| 9 | 한국 대학생 **사회불안·의사소통 불안 유병률** | OpenAlex | `Korean university students social anxiety prevalence communication apprehension survey` |
| 10 | **CCC-2 한국어판** | Europe PMC | `("Children's Communication Checklist" AND (Korean OR adolescent OR self-report))` |
| 11 | **BAPQ 한국어판** | Europe PMC | `("Broad Autism Phenotype Questionnaire")` |
| 12 | **LCQ 한국어판** | Europe PMC | `"La Trobe Communication Questionnaire"` |
| 13 | **SSIS 한국어판** | Pearson 제품 페이지 + Europe PMC #4 | — |
| 14 | **AQ 한국어판**(청소년·성인) | 자폐연구센터 배포 페이지 | 20개 이상 번역본 목록에 한국어 없음 |
| 15 | **K-ASSQ 자기보고판** | Europe PMC | `("Autism Spectrum Screening Questionnaire" AND ("Korean" OR "Korea") AND (school OR screening))` |
| 16 | **T8·T9 전용 제품** | Europe PMC ×2 (#13 #14) | 확인된 앱 중재는 전부 진단군 |
| 17 | **AI Hub 일상 사회적 대화 데이터** | aihub.or.kr 검색 | `대화` |

### 위 목록에 대한 경고 하나

**10~14번(한국어판 없음)은 국제 DB 기준이다.** RISS·KCI·학위논문 등 **국내 학술 DB 직접 검색은 이번에 수행되지 않았다**(WebSearch 예산 소진). 국내 학위논문 수준의 한국어 타당화가 존재할 가능성이 남아 있다. **"없다"가 아니라 "국제 DB 에서 안 나왔다"로 읽어야 한다.**

---

## 9 · 다음 세션이 첫 번째로 돌릴 것

우선순위 순. 앞의 둘이 후보 판정을 뒤집을 수 있다.

| 순위 | 무엇 | 왜 | 어떻게 |
|---|---|---|---|
| **1** | **RISS · KCI 에서 BAPQ · LCQ · CCC-2 한국어 타당화** | 나오면 **T9-B1 이 반증되고 T9 가 되살아난다** | WebSearch 복구 후 국내 DB 직접 검색 |
| **2** | **「의약품 등의 안전에 관한 규칙」 별표 4 제2호더목 원문** | **미성년자·대학생이 취약 대상에 열거되는가가 T8·T10 의 IRB 등급과 T11 의 모집 설계를 가른다** | 별표ID 18000689. DRF 3종 실패했으므로 첨부파일 다운로드 경로 또는 대학 IRB 지침 PDF |
| **3** | **국어원 일상 대화 음성 말뭉치의 연령 구성** | T10·T11 이 이 자료를 쓸 수 있는지가 걸림. 13~18세·19~25세 화자가 몇 명인가 | 연도판 구축 보고서 직접 열람 |
| **4** | **국내 제품 실재 여부** | §5 의 국내 칸이 통째로 비어 있다 | 앱스토어·구글플레이·제품 도메인 |
| **5** | **소속 기관 IRB 표준운영지침의 신속심의 기준** | 법령은 심의/면제 둘만 규정한다. 신속심의는 기관 지침 수준 | 기관 직접 수령 |
| **6** | **Durlak 2011 · Taylor 2017 영역별 효과크기** | 초록 밖. 본문 필요 | OA 사본 또는 도서관 |
| **7** | **CASEL Program Guide 등재 수·기준** | T10 경쟁 지형 판정 | `pg.casel.org` 하위 페이지 |
