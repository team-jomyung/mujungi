# 검색 기록 — `_agent_target_clinical.md` 근거 로그

검색일: **2026-09-14 (전량 동일 날짜)**
조사자: agent `target-clinical`

## 0 · 도구 상태 및 제약

| 도구 | 상태 | 비고 |
|---|---|---|
| **WebSearch** | **사용 불가** | 세션 착수 시점에 예산 소진 (200/200). **일반 웹 검색 0회 수행** |
| WebFetch | 사용 | 7회. 리디렉션 2회, 404 3회 |
| Bash + curl + jq + python | 주력 | PubMed E-utilities · PMC efetch · Crossref REST · 기관 사이트 직접 fetch |
| MCP `plugin:github`, `plugin:playwright` | **연결 실패** | 세션 시작 시 연결 오류. 브라우저 자동화 경로 사용 불가 |

**조회하지 못한 DB (한계):** RISS · KISS · DBpia · Google Scholar · ERIC · PsycINFO · Web of Science · Scopus · ProQuest 학위논문 · ClinicalTrials.gov · CRIS(한국 임상연구정보서비스, 등록번호만 논문에서 확인).

---

## 1 · PubMed E-utilities 검색 (esearch, 2026-09-14)

엔드포인트: `https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed`

### 1.1 후보별 census 검색 (count 확인용)

| # | 라벨 | 검색식 | 결과 (record) |
|---|---|---|---|
| Q1 | T4 ASD × 대화 × 청소년 | `(autism[tiab] OR autistic[tiab]) AND (conversation*[tiab] OR "language sample"[tiab] OR "spontaneous speech"[tiab] OR discourse[tiab]) AND (adolescen*[tiab] OR teen*[tiab] OR youth[tiab])` | **177** |
| Q2 | T5 ASD × 대화 × 청년 | `(autism[tiab] OR autistic[tiab]) AND (conversation*[tiab] OR "language sample"[tiab] OR "spontaneous speech"[tiab] OR discourse[tiab]) AND ("young adult*"[tiab] OR "emerging adult*"[tiab] OR "college student*"[tiab] OR "university student*"[tiab])` | **46** |
| Q3 | T6 PLI/SCD × 청소년·청년 | `("pragmatic language impairment"[tiab] OR "social communication disorder"[tiab] OR "social (pragmatic) communication disorder"[tiab] OR SPCD[tiab] OR "semantic pragmatic disorder"[tiab]) AND (adolescen*[tiab] OR teen*[tiab] OR "young adult*"[tiab])` | **37** |
| Q4 | T6 PLI/SCD × 대화자료 | `("pragmatic language impairment"[tiab] OR "social communication disorder"[tiab] OR "social (pragmatic) communication disorder"[tiab] OR SPCD[tiab]) AND (conversation*[tiab] OR "language sample"[tiab] OR discourse[tiab] OR narrative[tiab])` | **20** (전수 제목 확인) |
| Q5 | T7 DLD × 화용 × 청소년·청년 | `("developmental language disorder"[tiab] OR "specific language impairment"[tiab]) AND (pragmatic*[tiab] OR "social communication"[tiab]) AND (adolescen*[tiab] OR teen*[tiab] OR "young adult*"[tiab])` | **15** (전수 제목 확인) |
| Q6 | T7 DLD × 화용 × 대화자료 | `("developmental language disorder"[tiab] OR "specific language impairment"[tiab]) AND (pragmatic*[tiab] OR "social communication"[tiab]) AND (conversation*[tiab] OR "language sample"[tiab] OR discourse[tiab])` | **19** |
| Q7 | 공개 코퍼스 신호 | `(autism*[tiab] OR "developmental language disorder"[tiab] OR "social communication disorder"[tiab]) AND ("publicly available"[tiab] OR "open access"[tiab] OR "data availability"[tiab] OR TalkBank[tiab] OR CHILDES[tiab]) AND (conversation*[tiab] OR corpus[tiab] OR transcript*[tiab])` | **44** |

### 1.2 모수·탐색 검색

| # | 라벨 | 검색식 | 결과 (record) | 비고 |
|---|---|---|---|---|
| Q8 | T4 첫 시도 (실패) | `autism spectrum disorder AND (conversation OR discourse) AND corpus AND (adolescent OR teen)` | **1** | 검색식이 과도하게 제한적. 폐기하고 Q1 로 대체 |
| Q9 | ASD × 화용 × 청소년 | `(autism[tiab] OR ASD[tiab]) AND (pragmatic[tiab] OR pragmatics[tiab]) AND adolescen*[tiab]` | **88** | 상위 40건 제목 확인 |
| Q10 | ASD 코퍼스·데이터셋 | `(autism[tiab] OR autistic[tiab]) AND (corpus[tiab] OR dataset[tiab] OR databank[tiab] OR "language sample"[tiab]) AND (conversation*[tiab] OR discourse[tiab] OR narrative[tiab] OR spontaneous[tiab])` | **61** | 상위 40건 제목 확인. Boston College ACL/COLING 논문 발견 |
| Q11 | PLI/SCD 전체 모수 | `"pragmatic language impairment"[tiab] OR "social communication disorder"[tiab] OR "social (pragmatic) communication disorder"[tiab] OR "semantic pragmatic disorder"[tiab]` | **210** | 상위 40건 제목 확인 |
| Q12 | DLD × 화용 전체 모수 | `("developmental language disorder"[tiab] OR "specific language impairment"[tiab] OR DLD[tiab]) AND (pragmatic*[tiab] OR "social communication"[tiab])` | **165** | 상위 40건 제목 확인 |

### 1.3 평가도구·주석체계 검색

| # | 대상 | 검색식 | 결과 (record) | 판정 |
|---|---|---|---|---|
| Q13 | TOPICC | `"TOPICC"[tiab] OR "Targeted Observation of Pragmatics"[tiab]` | **7** | 그중 **화용 관련 3건**. 나머지 4건은 동명 소아중환자 연구(TOPICC study). 전부 학령기 아동 |
| Q14 | INCA-A | `"Inventory of Potential Communicative Acts"[tiab] OR "INCA-A"[tiab]` | **1** | 만다린 DLD 아동 프로토콜 (PMID 42164795) 뿐 |
| Q15 | DPICS | `"Dyadic Parent-Child Interaction Coding System"[tiab] OR DPICS[tiab]` | 다수 | 전부 PCIT 계열 (유아·부모-자녀 순응 코딩). 화용 체계 아님 |
| Q16 | YiPS/PRS | `"Yale in vivo Pragmatic Protocol"[tiab] OR "in vivo pragmatic"[tiab] OR "Pragmatic Rating Scale"[tiab]` | **14** | PRS 는 나오나 "Yale in vivo Pragmatic Protocol" 문자열 자체로는 미검출 |
| Q17 | YiPP 저자 경유 | `Simmons ES[au] AND (pragmatic*[tiab] OR conversation*[tiab])` | **0** | 저자명 표기 차이 (Schoen Simmons) |
| Q18 | YiPP 저자 경유 2 | `Paul R[au] AND autis*[tiab] AND (conversation*[tiab] OR pragmatic*[tiab])` | **7** | **성공.** PMID 25029348 (YiPP 원논문) 확보 |
| Q19 | SLDT / TOPL | `"Social Language Development Test"[tiab] OR "Test of Pragmatic Language"[tiab] OR "TOPL"[tiab]` | 다수 | TOPL-2 브라질판(PMID 26398257), Williams 증후군 비교(PMID 23184135), Volden 2010(PMID 20220047) 확보. **SLDT-A 는 미검출** |
| Q20 | CCC-2 | `"Children's Communication Checklist"[tiab] OR CCC-2[tiab]` | **210** | 상위 30 제목 확인. **아랍어판·스페인어판 있으나 한국어판 없음** |

### 1.4 중재 근거 검색

| # | 라벨 | 검색식 | 결과 (record) |
|---|---|---|---|
| Q21 | T4 메타분석 | `(autism*[tiab] OR autistic[tiab]) AND ("social skills"[tiab] OR "social competence"[tiab] OR "social communication"[tiab] OR pragmatic*[tiab]) AND (adolescen*[tiab]) AND (meta-analysis[ti] OR meta-analytic[ti] OR "systematic review"[ti])` | **66** (상위 30 확인) |
| Q22 | 전이·유지 | `(autism*[tiab] OR autistic[tiab]) AND (conversation*[tiab] OR pragmatic*[tiab] OR "social communication"[tiab]) AND (generaliz*[tiab] OR "far transfer"[tiab] OR "near transfer"[tiab] OR maintenance[tiab] OR "follow-up"[ti]) AND (adolescen*[tiab] OR "young adult*"[tiab])` | 상위 25 확인. Noora RCT · PEERS 대만 · Question Bank 발견 |

### 1.5 한국 관련 검색

| # | 라벨 | 검색식 | 결과 (record) | 비고 |
|---|---|---|---|---|
| Q23 | 한국 화용 | `(Korea*[tiab] OR Korean[tiab]) AND (pragmatic*[tiab] OR "social communication"[tiab]) AND (autism*[tiab] OR autistic[tiab] OR "language disorder"[tiab] OR "language impairment"[tiab])` | **26** | **전수 제목 확인.** NDTx-01 RCT · KASLAT · 한국 ASD 진료지침 발견. **한국어 화용 코퍼스 0건** |
| Q24 | 한국 ASD 유병률 | `Korea*[tiab] AND (autism*[tiab] OR autistic[tiab]) AND (prevalence[tiab] OR epidemiolog*[tiab])` | **15** (상위 확인) | NHIS 청구자료 논문(PMID 37899221) 발견 |
| Q25 | 한국 IRB·연구윤리 | `(Korea*[tiab]) AND ("institutional review board"[tiab] OR IRB[tiab] OR "research ethics"[tiab]) AND (minor*[tiab] OR child*[tiab] OR assent[tiab] OR vulnerable[tiab])` | **15** (상위 확인) | **PMID 40065714 (생명윤리법 × 2024 헬싱키선언 개정 분석) 확보 — 대리동의 의무 근거** |

---

## 2 · PubMed efetch — 전문 초록 확보 (rettype=abstract)

| PMID | 논문 | 용도 |
|---|---|---|
| 36340582 | Predicting pragmatic discourse features in the language of adults with ASD (ACL-SRW 2021) | T5 화용주석 코퍼스 |
| 36338791 | Evaluating Transformer-based LMs for Neuroatypical Language (COLING 2022) | 동일 코퍼스 |
| 39364340 | Normal but Different (ADLI 2024) | T4 10–18세 자발담화 |
| 35722978 | ToM in naturalistic conversations (Autism 2023) | T4 8–16세 dyad |
| 34383380 | Preliminary epidemiologic study of SCD in context of DLD (IJLCD 2021) | T6 유병률 7–11% |
| 38060810 | Competing views on PLI interventions: umbrella review | T6 중재 근거 |
| 34388006 | Psychometrics of PRS-SC (JSLHR 2021) | 화용 평정 |
| 40214154 | NDTx-01 RCT (Psychiatry Clin Neurosci 2025) | **한국 T4 모집·중재 벤치마크** |
| 26446644 | Idiom Comprehension / KASLAT (Yonsei Med J 2015) | 한국어 화용 과제 |
| 40056598 | PEERS 메타분석 (Asian J Psychiatr 2025) | T4/T5 중재 |
| 38988677 | Social Skills Interventions for Adolescents with Level 1 ASD 메타분석 | **T4 통합 효과크기** |
| 25029348 | YiPP 원논문 (JSLHR 2014) | **T4 평가도구** |
| 18607708 | Conversational behaviors in youth with HFASD (JADD 2009) | T4 12–18세 PRS |
| 20220047 | CCC-2 vs TOPL 비교 (AJSLP 2010) | 평가도구 비교 |
| 39954218 | **Noora AI RCT** (JADD 2026) | **가장 가까운 선행 제품 연구** |
| 34247667 | PEERS 대만 (Psychol Med 2023) | T5 · maintenance |
| 33820435 | Question Bank intervention (JSLHR 2021) | T4/T5 |
| 22512510 | **SCIP RCT** (IJLCD 2012) | **T6 중재 근거** |
| 26916221 | Metapragmatic awareness in CwSCD (IJLCD 2016) | T6 |
| 21558103 | Kim et al. 한국 ASD 유병률 2.64% (Am J Psychiatry 2011) | **모집 근거** |
| 37899221 | 한국 NHIS ID/PDD 유병률·의료비 (Psychiatry Investig 2023) | **모집 근거** |
| 40065714 | 2024 헬싱키선언 개정 × 한국 생명윤리법 (JKMS 2025) | **윤리 근거** |
| 37024960 | Sex differences in temporal dynamics of natural conversations (Mol Autism 2023) | T4 자연대화 |
| 36722653 | Consistency of automated language measures (Autism Res 2023) | T5 6–23세 |
| 33818766 | Descriptive assessment of conversational skills (JABA 2021) | T5 |
| 40673774 | BCDLD feasibility (AJSLP 2025) | T7 — 6;06–8;02세 확인 |
| 38130070 | InterAction VR for adolescents with DLD | **T7 유일한 13–16세 중재, n=9** |
| 42582773 | Who are Adults with DLD? (ADLI 2026) | T7 — 평균 37세 확인 |

## 3 · PMC efetch — 본문 확보

| PMCID | 논문 | 추출 내용 |
|---|---|---|
| **PMC13346298** | Noora RCT | 표본 30(15/15) · 연령 11–35 · **일반화 대화샘플 실험 +37.67%p (SD 28.34) vs 대기 +2.53%p (SD 21.28), Mann-Whitney U 유의** · 사전 스크리닝 탈락(assent 거부 2명 · 대화 불가 5명 · 사전점수 초과 6명) · 동의/assent 절차 원문 |
| **PMC11893356** | 생명윤리법 분석 | **"the Bioethics Act mandates proxy consent even for minimal-risk research"** 등 원문 인용 2건 |
| PMC11447814 | Zane & Grossman 2024 | 연령 10–18 확인. **data availability 문구 기계 검색 → 전사 공개 없음** |
| PMC10080787 | Cho et al. 2023 | 45+47 participant 확인. data availability 문구 미검출 |
| PMC9620696 | "Like" 담화표지 | 21+20 participant, 10–17세 확인. data availability 미검출 |
| PMC9763550 | ToM dyad 연구 | 50 dyad, 8–16세, 5분 비구조화 확인. **OSF 공개 대상은 "APIM 분석 데이터와 SPSS syntax" — 전사본 아님** |

**PMC 링크 확인**: elink.fcgi 로 PMID → PMCID 매핑 (39364340→PMC11447814, 37024960→PMC10080787, 36382079→PMC9620696, 35722978→PMC9763550)

---

## 4 · Crossref REST API

엔드포인트: `https://api.crossref.org/works?query.bibliographic=...`

| # | 검색어 | 결과 | 확보 |
|---|---|---|---|
| C1 | `autism adolescent conversation corpus` (연결 테스트) | 550,228 | 테스트 목적 |
| C2 | `KOPLAC Korean meta-pragmatic language assessment children` | 10건 반환 | **doi:10.12963/csd.18467** (KOPLAC 타당도·신뢰도, Communication Sciences & Disorders 2018) · doi:10.12963/csd.18481 (경도지적장애 아동 KOPLAC 적용) · doi:10.1075/tilar.36.14cho (Pragmatic bootstrapping in Korean children with ASD, 2026) |
| C3 | `화용언어 검사 아동 개발 타당도` (한글) | **실패** — 응답 파싱 오류(jq invalid numeric literal). 한글 쿼리 인코딩 문제. **재시도하지 못함** |

---

## 5 · 기관 사이트 직접 조회

| 사이트 | URL | 결과 |
|---|---|---|
| **ASDBank 인덱스** | `https://talkbank.org/asd/access/` (원 URL `asd.talkbank.org/access/` 에서 301) | 코퍼스 15행 전체 파싱. "Age/N" 열이 실제로는 participant 수임을 개별 문서에서 확인 |
| ASDBank Eigsti | `.../English/Eigsti.html` | **48 participant, 3–6세**, 30분 자유놀이, participant 당 첫 100 utterance |
| ASDBank Nadig | `.../English/Nadig.html` | **38 participant**, 학령전 종단, 사용제한 없음 명시 |
| ASDBank QuigleyMcNally | `.../English/QuigleyMcNally.html` | **40 participant**, 생후 3–12개월 영아 + ASD 형제 |
| ASDBank AAC | `.../English/AAC.html` | **18 participant**, 30개월 초과 minimally speaking, ADOS-2 module 1 |
| ASDBank NYU-Emerson | `.../English/NYU-Emerson.html` | **30 participant**, young autistic children |
| ASDBank Flusberg | `.../English/Flusberg.html` | **6 participant**, 아동 |
| ASDBank Rollins | `.../English/Rollins.html` | **5 participant**, 시작 시 평균 2;7세 |
| **TalkBank 접근등급** | `https://talkbank.org/0share/access.html` | 4단계 원문 확보. approved access 대상 임상뱅크 목록에 **ASDBank 미포함** |
| TalkBank 라이선스 | `https://talkbank.org/` 푸터 | `creativecommons.org/licenses/by-nc-sa/4.0/deed.en` → **CC BY-NC-SA 4.0** |
| TalkBank rules/ethics | `/share/rules.html`, `/share/`, `/share/ethics.html` | **전부 404.** 실제 경로는 `/0share/` 계열 |
| **KOPLAC 원문** | `doi:10.12963/csd.18467` → `e-csd.org/journal/view.php?doi=...` | **"5- to 12-year-old children"** · 270 participant · 3영역 과제 · α .40–.91 · 파라다이스복지재단 출판 |
| **SFARI Base** | `https://www.sfari.org/resource/sfari-base/` | 6개 코호트 명시. **전사 대화·언어샘플 제공 여부 미기재.** 접근: 기관 계정 + RDA + IRB 문서 + 과학팀 심사 |
| **LDC 카탈로그** | `catalog.ldc.upenn.edu/search?q=autism` | WebFetch 500 / curl 파싱 시 결과 0건 (동적 렌더링). **NOT FOUND AFTER DEFINED SEARCH** |
| **AI Hub** `자폐` | `aihub.or.kr/aihubdata/data/list.do?...searchKeyword=자폐` | **2건** — 소아청소년 정신질환 진단 안저 이미지 · 소아 뇌파. 둘 다 안심존 |
| AI Hub `발달장애` | 동일 엔드포인트 | **3건** — 소아청소년 심리검사·뇌영상(2) · 소아 뇌파. 전부 안심존 |
| AI Hub `언어발달` | 동일 | **2건** — 위 심리검사·뇌영상 |
| AI Hub `화용` | 동일 | **4건** — 물류·상표·3D·특허. 전부 무관 |
| AI Hub `청소년 대화` | 동일 | **4건** — 한국어 감정태깅 자유대화(청소년) 다운수 1,542 · 한국어 감성 대화 말뭉치 다운수 14,963. **둘 다 비임상, 다운로드 가능** |
| **law.go.kr** | `/DRF/lawService.do?...` · `/법령/생명윤리및안전에관한법률` | HTTP 500(2,002B) / HTTP 200(1,263B 프레임 셸). **본문 추출 실패** |
| **elaw.klri.re.kr** | `/eng_service/lawTwoView.do?hseq=61232` · `lawSearch.do` | 동적 로딩. **본문 추출 실패** |
| **irb.or.kr** | `https://irb.or.kr/` | HTTP 200 (8,432B). **세부 심의등급 지침 페이지는 탐색하지 못함 (시간 배분)** |
| Pearson (CCC-2) | US 스토어 URL · UK 스토어 URL | **404 / 내용 없음.** CCC-2 연령범위·가격 확보 실패 |

---

## 6 · NOT FOUND AFTER DEFINED SEARCH 목록 (요약)

각 항목은 위 표의 검색을 수행한 결과 발견되지 않은 것이다. 검색일은 전부 **2026-09-14**.

| 항목 | 수행한 검색 |
|---|---|
| 13~25세 임상군 다중턴 자연대화 + 화용주석 **공개 데이터셋** | TalkBank ASDBank 전 코퍼스 직접 열람 · SFARI Base 페이지 · LDC 카탈로그 · PubMed Q7 · 개별 논문 PMC data-availability 기계검색 6건 |
| 한국어 ASD/DLD/SCD **화용 대화 코퍼스** | PubMed Q23(26건 전수) · Crossref C2 · AI Hub 4개 키워드 |
| **CCC-2 한국어판** | PubMed Q20(210건 중 상위 30) · Q23(26건 전수) |
| **YiPP / TOPL / TOPICC 한국어판** | PubMed Q13·Q16·Q18·Q19·Q23 |
| **18~25세만을 표본으로 한** ASD 자연대화 연구 | PubMed Q2(46건) · Q22 |
| **T6 13~25세 대화자료 참여자 연구** | PubMed Q3(37건) · Q4(20건 전수 제목 확인) |
| **T7 13~25세 대화자료 참여자 연구** | PubMed Q5(15건 전수 제목 확인) · Q6(19건) |
| **T7 DLD 화용 중재 메타분석** | PubMed Q5 · Q6 · Q12 |
| **한국 성인(18~25) ASD 모집 선례** | PubMed Q2 · Q23 · Q24 |
| **한국 DLD 청소년 코호트·모집 선례** | PubMed Q5 · Q12 · Q23 |
| **생명윤리법 제15조·제16조 조문 원문** | law.go.kr 2회 · elaw.klri.re.kr 2회 (전부 본문 추출 실패) |
| **한국 IRB 심의등급 배정 기준 문서** | irb.or.kr 접속만 성공, 세부 페이지 미탐색 |
| **CCC-2 정확 연령범위·가격 (출판사 1차 출처)** | Pearson US · UK 각 1회 (404 / 내용 없음) |
| **TOPL-2 연령범위·가격** | 조사하지 못함 (시간 배분) |
| **ASDBank 비영어 6개 코퍼스 연령** | 개별 문서 미열람 (시간 배분) |
| **LDC autism 관련 코퍼스 유무** | catalog.ldc.upenn.edu 2회 시도, 동적 렌더링으로 파싱 실패 |

---

## 7 · 후속 조사 권고 (우선순위)

1. **RISS · KISS · DBpia 조회** — T6·T7 한국어 판정의 신뢰도가 여기에 달려 있다. 특히 `화용언어` `사회적 의사소통` `청소년` `언어발달장애` 키워드.
2. **Noora RCT (PMC13346298) 와 NDTx-01 (PMID 40214154) 전문 정독** — 가장 가까운 선행 제품 연구 2편. 설계·측정·모집 절차를 그대로 참조 가능.
3. **KOPLAC 저자(김영태 그룹 계열) 접촉** — 13세 이상 확장판 존재 여부 확인. 이 한 가지가 네 후보 전부의 "평가 불가" 블로커를 풀 수 있다.
4. **소속 기관 IRB 사무국에 심의등급 직접 문의** — 3.3 의 추론을 사실로 대체.
5. **Prud'hommeaux 랩(Boston College) 코퍼스 공개 여부 이메일 문의** — T5 유일한 화용주석 자연대화 자원.
6. **LDC 카탈로그 수동 확인** — 동적 페이지라 자동 조회 실패. 브라우저로 직접 확인 필요.
