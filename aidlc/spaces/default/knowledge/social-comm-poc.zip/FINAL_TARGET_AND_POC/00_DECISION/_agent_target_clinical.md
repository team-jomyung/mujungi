# 임상군 타겟 후보 4종 · 데이터 실현가능성 조사

조사일: **2026-09-14**
조사자: agent `target-clinical`
조사 범위: T4(ASD 13~18) · T5(ASD 18~25) · T6(PLI/화용언어곤란) · T7(DLD + 사회적화용곤란)

## 0 · 이 문서를 읽는 법

### 0.1 증거 등급 표기

| 표기 | 뜻 |
|---|---|
| `[FULL TEXT]` | 본문(PMC 전문 또는 기관 사이트 원문)을 직접 열어 확인 |
| `[ABSTRACT ONLY]` | PubMed 초록만 확인. 본문 미확인 |
| `[TITLE ONLY]` | 제목·서지만 확인. 초록도 미확인 |
| `[NOT FOUND AFTER DEFINED SEARCH]` | 정의된 검색을 수행했으나 없음. 검색 DB·검색어·날짜는 `_agent_target_clinical_LOG.md` 참조 |
| (빈칸) | 조사하지 못함. 사유를 함께 적음 |

### 0.2 단위 규칙

`participant`(사람) · `utterance`(발화) · `conversation`(대화 세션) · `item`(문항) · `record`(검색 결과 레코드) 를 **절대 합산하지 않는다.**
아래 모든 "건수"는 **PubMed 검색 레코드 수(record)** 이거나 **사람 수(participant)** 이며, 어느 쪽인지 매번 명시한다.

### 0.3 검색 도구 제약 (중요)

- 이 세션은 **WebSearch 예산이 착수 시점에 이미 소진**(200/200)되어 일반 웹 검색을 1건도 수행하지 못했다.
- 전량 **식별자 기반 직접 조회**로 전환했다: PubMed E-utilities(esearch/esummary/efetch) · PMC efetch · Crossref REST API · 기관 사이트 직접 fetch(TalkBank / e-csd.org / AI Hub / SFARI).
- 결과적으로 **회색문헌(학위논문·학회 발표·비색인 한국 학술지)의 커버리지가 낮다.** 특히 한국어 자료에 대한 "없다" 판정은 *PubMed + Crossref + AI Hub 범위 내에서 없다* 는 뜻이며, **RISS·KISS·DBpia 는 조회하지 못했다.** 이 한계는 T6·T7 의 한국어 항목에 가장 크게 작용한다.

---

## 1 · 데이터

### 1.1 후보별 연구 건수 (단위: PubMed record)

검색일 2026-09-14. 검색식 전문은 LOG 파일 참조. **이 수치는 참여자 연구만 걸러낸 수가 아니라 리뷰·비언어 연구가 섞인 원 레코드 수다.**

| 항목 | T4 ASD 13~18 | T5 ASD 18~25 | T6 PLI/SCD | T7 DLD+화용 |
|---|---|---|---|---|
| 집단 자체 (모수 검색식) | ASD 전체는 수만 건 규모라 의미 없음 → 교차검색으로 대체 | 동일 | PLI/SCD/SPCD/의미화용장애 **210 record** | DLD/SLI × pragmatic/social-communication **165 record** |
| 집단 × 대화자료 × 연령대 | **177 record** | **46 record** | (13~25 교차) **37 record** | (13~25 교차) **15 record** |
| 집단 × 대화자료 (연령 무관) | (위에 포함) | (위에 포함) | **20 record** | **19 record** |

기계적 검색 결과 수 자체는 확인됨. 개별 논문 검증은 1.2 참조.

### 1.2 13~25세 표본을 실제로 가진 참여자 연구 (손으로 검증한 것만)

여기부터가 실제 판단 근거다. 위 record 수와 달리 **한 건씩 열어 연령을 확인한 것만** 적는다.

#### T4 · ASD 13~18 — 확인된 참여자 연구 9건

| # | 연구 | participant 수 | 연령 | 자료 유형 | 다중 턴 | 화용 주석 | 증거 |
|---|---|---|---|---|---|---|---|
| 1 | Paul, Orlovski, Marcinko & Volkmar 2009, JADD (PMID 18607708) | 29 ASD + 26 TD = **55 participant** | **12–18세** | ADOS 구조화 면담 비디오 | 예 | **Pragmatic Rating Scale (PRS; Landa et al. 1992)**. 항목의 약 1/3에서 군간 유의차 | `[ABSTRACT ONLY]` |
| 2 | Schoen Simmons, Paul & Volkmar 2014, JSLHR (PMID 25029348) | **118 participant** | **9–17세** | YiPP 반구조화 동적 대화 평가 | 예 | **YiPP 4영역**: discourse management / communicative functions / conversational repair / presupposition | `[ABSTRACT ONLY]` |
| 3 | Zane & Grossman 2024, ADLI (PMID 39364340 / PMC11447814) | **38 participant** (19 autistic) | **10–18세** | "double interview" 자발 담화, 전사 | 예 | 의미적 비관습성 / 형태통사 오류 코딩 (기성 화용 체계 아님) | `[FULL TEXT]` |
| 4 | "Like, it's important" 담화표지 2022, Autism (PMID 36382079 / PMC9620696) | 21 ASD + 20 NonAu = **41 participant** | **10–17세** | 반구조화 면담 | 예 | 담화표지 빈도·용법 (기성 화용 체계 아님) | `[FULL TEXT]` |
| 5 | 자연대화 속 마음이론 2023, Autism (PMID 35722978 / PMC9763550) | **50 dyad** | **8–16세** | 5분 **비구조화 자연대화**. dyad 유형 3종(AUT-TD / TD-TD / AUT-AUT) | 예 | conversational ToM 코딩 | `[FULL TEXT]` |
| 6 | Cho et al. 2023, Mol Autism (PMID 37024960 / PMC10080787) | 45 autistic + 47 NT = **92 participant** | school-aged children 및 청소년 (정확 범위 본문 미확정) | 낯선 성인 confederate 와의 **자연대화** | 예 | 턴 타이밍 동역학 — 화용 주석 체계 아님 | `[FULL TEXT 부분]` |
| 7 | Koegel et al. 2021, JSLHR (PMID 33820435) | 미확인 | 청소년+성인 | Question Bank 중재, 사회적 질문 개시 | 예 | — | `[TITLE ONLY]` |
| 8 | Bambara et al. 2021, JSLHR (PMID 34735289) | 미확인 | 청소년 ASD | 또래 지원, 대화 상대에 대한 관심 표현 | 예 | — | `[TITLE ONLY]` |
| 9 | Koegel et al. 2026 Noora RCT, JADD (PMID 39954218 / PMC13346298) | **30 participant** 무작위배정 (15/15) | **11–35세** | 사전·사후 **사람과의 자연대화 샘플** (일반화 측정) | 예 | 공감 반응 정오 채점 | `[FULL TEXT]` |

추가 관련(연령 걸침): French-speaking (pre)adolescents 휴지 패턴 2026 (PMID 42084464) `[TITLE ONLY]` · 청소년 파트너 중심 대화 단기중재 2023 (PMID 35298756) `[TITLE ONLY]` · LuDiCa 대화적 읽기 자폐 청소년 2024 (PMID 38305847) `[TITLE ONLY]`.

#### T5 · ASD 18~25 — 확인된 참여자 연구 5건 (대부분 "성인 전체"이지 18~25 한정이 아님)

| # | 연구 | participant 수 | 연령 | 자료 유형 | 다중 턴 | 화용 주석 | 증거 |
|---|---|---|---|---|---|---|---|
| 1 | Yang et al. 2021 ACL-SRW (PMID 36340582 / PMC9633181) | 초록에 명시 없음 ("currently collecting") | **성인** | 협동과제 중 **양자 자연대화** (실험 세팅) | 예 | **politeness · uncertainty · informativeness 3점 척도**, utterance 단위. 자체 개발 체계 | `[FULL TEXT 초록]` |
| 2 | Liu et al. 2022 COLING (PMID 36338791 / PMC9633182) | 위와 동일 코퍼스 | 성인 | 동일 | 예 | 동일 | `[ABSTRACT ONLY]` |
| 3 | Fombonne 그룹 2023, Autism Res (PMID 36722653) | **64 participant** | **6–23세** (평균 12.8세, 78.1% 남성) | 표현언어 샘플링 맥락 3종 | 예 | 자동언어측정(ALM) 6종 — 화용 주석 아님. 4주 재검사신뢰도 보고 | `[ABSTRACT ONLY]` |
| 4 | Chien et al. 2023, Psychol Med (PMID 34247667) | **82 participant** | 청년 | PEERS RCT, 관찰자 평정 대화행동 | 예 | 시선·제스처·표정·대화 유지·상호성 관찰 평정 | `[ABSTRACT ONLY]` |
| 5 | 자폐 성인 사회화용 추론·서사담화 2023, Autism (PMID 36416017) | 미확인 | 성인 | 서사담화 | 부분 | — | `[TITLE ONLY]` |

추가: 청년 대화기술 기술적 벤치마크 2021, JABA (PMID 33818766) `[TITLE ONLY]` · 자폐 성인 filled pause 2024 (PMID 37133610) `[TITLE ONLY]` · 자폐 성인 비유창성 2026 (PMID 41457448) `[TITLE ONLY]`.

> **T5 핵심 소견**: 18~25 **만**을 표본으로 한 자연대화 연구는 검증 범위 안에서 **0건**. 전부 "성인" 또는 "6–23" 처럼 범위가 넓게 걸쳐 있어 **18~25 구간의 participant 수를 분리해 셀 수 없다.**

#### T6 · PLI / 화용언어곤란 — 13~25세 × 대화자료 참여자 연구 0건

- PLI/SCD × 대화자료 **20 record 전량 제목 확인** → 전부 학령전기·학령기(대략 5–12세) 이거나 성인 유전증후군(Fragile X · Williams) 이거나 TBI. `[TITLE ONLY · 20건 전수]`
- 중등학령기를 다룬 유일한 건: *Pragmatic comprehension in secondary school-aged students with specific developmental language disorder*, 2000 (PMID 10824222) — **T7 쪽 검색에서 나온 것이고 SLI 라벨이며 26년 전 자료.** `[TITLE ONLY]`
- PLI/SCD × 청소년·청년 **37 record** 중 청소년 SCD 직접 연구로 확인된 것: 사회적 위장(camouflage) 2026 (PMID 42325324) · 불확실성 인내 2026 (PMID 42064161) — **둘 다 설문 기반, 대화자료 없음.** `[TITLE ONLY]`
- ASD 와 섞인 것: NDTx-01 RCT (PMID 40214154) — "ASD **또는** SCD" 로 모집. **SCD 단독 인원을 분리해 셀 수 없다.** `[FULL TEXT 초록]`

#### T7 · DLD + 사회적화용곤란 — 13~25세 × 대화자료 참여자 연구 0건 / 중재 1건

- DLD/SLI × pragmatic × 청소년·청년 **15 record 전수 제목 확인** 결과: 또래 피해 · 정서행동 문제 · 철자 · 직업어휘 등 **심리사회적 결과 연구**이고 **대화자료 연구는 0건.** `[TITLE ONLY · 15건 전수]`
- 유일한 13~18 직접 중재: InterAction VR 사회정서 훈련 2024 (PMID 38130070) — **9 participant, 13–16세, 6세션 feasibility.** 결과는 "참가자 간·참가자 내 편차가 컸고 훈련한 기술별로도 일정하지 않았다". `[ABSTRACT ONLY]`
- DLD 대화 중재 최신 근거 BCDLD 2025 (PMID 40673774) 는 **6 participant, 6;06–8;02세** — 청소년 아님. `[ABSTRACT ONLY]`
- DLD 성인 프로파일 Engage with DLD 2026 (PMID 42582773) 는 **92 adult participant, DLD군 평균 약 37세** — 18~25 아님. `[ABSTRACT ONLY]`

### 1.3 화용 주석 체계 — 팀리드가 지목한 3종의 실제 상태

| 체계 | PubMed record (2026-09-14) | 대상 연령 | 13~25 적용 가능성 | 증거 |
|---|---|---|---|---|
| **TOPICC** (Targeted Observation of Pragmatics in Children's Conversation, Adams 그룹) | 검색 7건 중 **화용 관련 3건** (나머지는 동명 소아중환자 연구 TOPICC) | 학령기 아동 (SCIP 계열에서 5–11세대) | **낮음.** 청소년 적용 사례 미발견 | `[TITLE ONLY]` |
| **INCA-A** (Inventory of Potential Communicative Acts) | **1건** | 발달장애 아동 | **낮음.** 유일 히트가 만다린 DLD 아동 프로토콜 (PMID 42164795) | `[TITLE ONLY]` |
| **DPICS** (Dyadic Parent-Child Interaction Coding System) | 다수이나 전부 PCIT 계열 | 유아·학령전기, 부모-자녀 | **없음.** 화용 체계가 아니라 아동 순응·부모 행동 코딩 | `[TITLE ONLY]` |

**추가로 확인된, 실제로 13~25에 쓸 수 있는 체계**

| 체계 | 연령 | 성격 | 증거 |
|---|---|---|---|
| **Pragmatic Rating Scale (PRS)** — Landa et al. 1992 | 학령기~성인 (Paul 2009 에서 12–18세 적용 확인) | 대화 관찰 평정. 연구 도구 | `[ABSTRACT ONLY]` |
| **PRS-SC** (학령기판) — 2021 (PMID 34388006) | 학령기 | 위의 학령기 개정 | `[TITLE ONLY]` |
| **YiPP 4영역 채점** — Schoen Simmons 2014 | 9–17세 | 반구조화 대화 프로토콜 겸 채점 체계 | `[ABSTRACT ONLY]` |
| **politeness / uncertainty / informativeness 3점 척도** — Boston College (Prud'hommeaux 랩) | 성인 | utterance 단위. 신경망 자동예측 F1 > 0.82 보고 | `[FULL TEXT 초록]` |

### 1.4 관계·맥락 메타데이터

| 후보 | 관계 메타데이터 (상대가 누구인가) | 맥락 메타데이터 (어디서 무슨 일로) | 증거 |
|---|---|---|---|
| T4 | **부분적으로 있음.** 연구자·검사자(Paul 2009 · Zane & Grossman 2024 · YiPP), 낯선 성인 confederate(Cho 2023), **또래**(ToM dyad 연구는 dyad 유형 3종을 변인으로 설계) | **있음.** ADOS 면담 / double interview / 5분 비구조화 / 협동과제 등 과제 맥락 명시 | `[FULL TEXT · 개별 논문]` |
| T5 | **있음.** 신경전형 또래와의 협동과제 양자대화 (Boston College) | **있음.** collaborative tasks | `[FULL TEXT 초록]` |
| T6 | — | 해당 연령대 대화자료 자체가 없어 논의 불가 | — |
| T7 | — | 동일 | — |

> 위 "있음"은 **개별 논문의 방법 기술에 있다**는 뜻이지 **배포되는 데이터셋에 필드로 붙어 있다**는 뜻이 아니다. 배포 데이터셋은 1.5 참조.

### 1.5 공개 데이터셋 — 이 조사의 가장 중요한 결과

#### ASDBank (TalkBank) — 전 코퍼스 개별 검증

1차 출처: https://talkbank.org/asd/access/ (코퍼스별 문서 페이지를 직접 열람)

| 코퍼스 | 언어 | participant 수 | 연령 | 매체 | 13~25 포함 |
|---|---|---|---|---|---|
| Eigsti | 영어 | 48 | **3–6세** (30분 자유놀이, participant 당 첫 100 utterance) | 없음 | 아니오 |
| Nadig | 영어 | 38 | **학령전기 종단** (Bang & Nadig 2015 모-자 입력 연구) | 없음 | 아니오 |
| NYU-Emerson | 영어 | 30 | **young autistic children** (부모-아동 상호작용) | 비디오 | 아니오 |
| AAC | 영어 | 18 | **30개월 초과 minimally speaking** (ADOS-2 module 1 수준) | 비디오 | 아니오 |
| Flusberg | 영어 | 6 | 아동 | 없음 | 아니오 |
| Rollins | 영어 | 5 | **시작 시 평균 2;7세** | 대기중 | 아니오 |
| QuigleyMcNally | 영어 | 40 | **생후 3–12개월 영아** + ASD 아동의 형제 | 소실 | 아니오 |
| Asymmetries | 네덜란드어 | 26 | **6–12세** | 오디오 | 아니오 |
| DengSiok | 광둥어 | 30–40 | 미확인 | 오디오 | 미확인 |
| ROGPOP | 크로아티아어 | 29, 24 | 미확인 | 비디오 protected | 미확인 |
| FoudonReboul / Nadig | 프랑스어 | 8 / 26 | 미확인 | 없음 | 미확인 |
| Thessaloniki | 그리스어 | 10 / 1 | 미확인 | 비디오 | 미확인 |
| Shanghai | 만다린 | 15 | 미확인 | 오디오 | 미확인 |
| PerLA-Munoz | 스페인어 | 20 | 미확인 | 없음 | 미확인 |

> **영어 코퍼스 7종 전부 본문 확인 결과 13세 이상 표본이 없다.** 비영어 6종은 개별 문서를 열지 못해 "미확인"으로 남긴다 (조사 시간 배분 문제).

**라이선스**: TalkBank 전체가 **CC BY-NC-SA 4.0** (talkbank.org 푸터의 `creativecommons.org/licenses/by-nc-sa/4.0` 링크로 확인). `[FULL TEXT]`

**접근 등급** (https://talkbank.org/0share/access.html, 원문 기준): 4단계 — Open access / **Registration required** / **Approved access** ("academic researchers with a verified university or research lab position") / Controlled access. 원문에서 approved access 대상으로 **명시된 임상 뱅크는 AphasiaBank · DementiaBank · FluencyBank · TBIBank · RHDBank 와 HomeBank 대부분이며 ASDBank 는 명시되어 있지 않다.** 따라서 ASDBank 는 registration 등급으로 보이나 **명문 확인은 못 했다.** `[FULL TEXT]`

**IRB 관련 원문**: "TalkBank materials have already received IRB review at the contributor's home institution and no further IRB approval is needed for use of these data." `[FULL TEXT]`

#### 그 외 공개 경로

| 경로 | 4후보 13~25 대화자료 | 접근 조건 | 증거 |
|---|---|---|---|
| **SFARI Base** (SSC / SPARK / Simons Searchlight / AIC 등 6개 코호트) | **전사 대화·언어 샘플 제공 여부가 공개 페이지에 명시되어 있지 않음** | 기관 소속 계정 + 소속기관 RDA 동의 + **IRB 문서 제출** + SFARI 과학팀 심사 | `[FULL TEXT]` + 일부 `[NOT FOUND]` |
| **LDC 카탈로그** | autism 검색 결과 파싱 실패(동적 페이지). **확인 불가** | — | `[NOT FOUND AFTER DEFINED SEARCH]` |
| **개별 논문 데이터 공개** | T4 논문 4건 PMC 전문에서 data-availability 문구 기계 검색 → **전사 자료를 공개한 건 0건.** ToM 연구(PMC9763550)만 "APIM 분석용 데이터와 SPSS syntax 를 OSF 에 공개" = **전사본이 아니라 분석 산출 수치** | — | `[FULL TEXT]` |
| **Boston College 화용주석 코퍼스** | 공개 여부 미기재. 2021년 논문 시점 "currently collecting" | — | `[FULL TEXT 초록]` |

> **결론: 네 후보 통틀어, 13~25세 임상군의 다중 턴 자연대화 + 화용 주석이 붙은 공개 데이터셋은 이 조사 범위 안에서 0개다.**

### 1.6 한국어 자료

| 항목 | 결과 | 증거 |
|---|---|---|
| AI Hub `자폐` 검색 | **2건** — 「소아청소년 정신질환 진단 안저 이미지 데이터」 · 「소아 뇌파 검사 데이터」. **둘 다 안심존(온라인) 전용, 대화자료 아님** | `[FULL TEXT · 사이트 직접 조회]` |
| AI Hub `발달장애` 검색 | **3건** — 「소아청소년 심리검사 및 뇌영상 데이터」(2종) · 「소아 뇌파 검사 데이터」. **전부 안심존, 대화자료 아님** | `[FULL TEXT]` |
| AI Hub `언어발달` 검색 | **2건** — 위 심리검사·뇌영상과 동일 | `[FULL TEXT]` |
| AI Hub `화용` 검색 | **4건** — 물류공간예측 · 유사상표 이미지 · 텍스트-3D · 특허 자동분류. **전부 무관** | `[FULL TEXT]` |
| AI Hub 비임상 청소년 대화 | 「**한국어 감정이 태깅된 자유대화(청소년)**」 다운로드 가능(다운수 1,542) · 「한국어 감성 대화 말뭉치」 다운로드 가능(다운수 14,963). **둘 다 비임상** | `[FULL TEXT]` |
| 한국어 ASD/DLD/SCD 화용 대화 코퍼스 | **NOT FOUND AFTER DEFINED SEARCH** (PubMed + Crossref + AI Hub, 2026-09-14). RISS·KISS·DBpia 미조회 — "존재하지 않는다"가 아니라 "이 세 경로에서 찾지 못했다"로 읽을 것 | `[NOT FOUND]` |
| 한국어 ASD 화용 과제 | KASLAT (Korean Autism Social Language Task) — 관용어 이해 과제. **42 participant, 6–11세** (ASD 16 · ADHD 16 · 정상 10). **대화가 아니라 item 기반 이해 과제이고 연령도 벗어남** | `[FULL TEXT 초록]` (PMID 26446644) |

---

## 2 · 평가

### 2.1 표준화 화용 평가도구

| 도구 | 연령 범위 | 후보 적용 | 공개/비용 | 증거 |
|---|---|---|---|---|
| **CCC-2** (Children's Communication Checklist-2, Bishop) | 검증 범위 내 상한 미확정. **13–14세 적용 실증 있음** (EpiSLI 8학년 표본) | T4 상단 / T6 / T7 | Pearson 상용. **정확 연령범위·가격은 출판사 페이지 2회 시도 모두 404 또는 내용 없음** | `[FULL TEXT · 사용 실증]` + `[NOT FOUND · 출판사 제원]` |
| **TOPL / TOPL-2** (Test of Pragmatic Language) | 미확인 | T4 | 상용(PRO-ED). **가격 미확인** | `[ABSTRACT ONLY]` |
| **YiPP** (Yale in vivo Pragmatic Protocol) | **9–17세** | **T4 정확히 적합 · T5 부적합** | 연구 프로토콜. **배포 조건 NOT FOUND** | `[ABSTRACT ONLY]` (PMID 25029348) |
| **PRS** (Pragmatic Rating Scale, Landa 1992) | 학령기~성인. 12–18세 적용 실증 | T4 · T5 | 연구 평정척도 | `[ABSTRACT ONLY]` |
| **TOPICC** | 학령기 아동 | T6(아동) — **13~25 부적합** | 연구 도구 | `[TITLE ONLY]` |
| **e-ABaCo** (원격 실시 communicative-pragmatic 평가) | 미확인 | 미확인 | 2025년 논문 존재 (PMID 40357514) | `[TITLE ONLY]` |

> **핵심**: T4(13–18)는 YiPP · PRS · CCC-2 로 **덮인다.** T5(18–25)를 덮는 표준화 화용 평가도구는 **이 조사 범위에서 확인되지 않았다** — YiPP 는 17세에서 끊기고 CCC-2 는 아동용이다.

### 2.2 한국어판

| 항목 | 내용 |
|---|---|
| **KOPLAC** (한국아동 메타-화용언어검사, Korean meta-Pragmatic Language Assessment for Children) | **있음. 유일하게 확인된 한국어 표준화 화용검사** |
| 연령 (원문 인용) | **"5- to 12-year-old children"** — 학령전 5–6세 + 초등 1–6학년 |
| 표준화 표본 | **270 participant** (학령전 120 + 학령 150, 서울·경기) |
| 과제 구성 | 시청각 담화과제 3영역 — 의사소통 조율(대화 상대·상황 맥락) / 담화·이야기 정보 추론 / 상위언어 인식(간접표현·지시·반어·은유) |
| 심리측정 | 내용타당도 평균 4.11/5.0 · 구인타당도 r=.35–.81 · 공인타당도(REVT) r=.52–.57 · Cronbach α **.40–.91** · 검사-재검사 .79–.99 · 반분 .652–.726 |
| 출판 | **파라다이스복지재단 상용 출판** (규준 포함). 비용 미확인 |
| **판정** | **T4·T5·T6·T7 전부 연령 미달로 사용 불가.** 추가로 α 하한 .40 은 하위영역 신뢰도가 낮은 곳이 있다는 뜻이라 변화 측정에 그대로 쓰기 위험 |

`[FULL TEXT · e-csd.org, doi:10.12963/csd.18467]`

- CCC-2 한국어판: **NOT FOUND AFTER DEFINED SEARCH** (PubMed "Korea* AND pragmatic AND autism/language disorder" 26 record 전수 확인 + CCC-2 검색 210 record 상위 30 확인 — 아랍어판·스페인어판은 나오나 한국어판 없음, 2026-09-14)
- YiPP / TOPL / TOPICC 한국어판: **NOT FOUND AFTER DEFINED SEARCH** (동일)

> **이것이 네 후보 전부에 걸리는 공통 블로커다: 한국에서 13~25세의 화용 능력을 표준화된 방식으로 잴 도구가 없다.**

### 2.3 중재 전후 변화를 잰 연구 (효과크기 포함)

| 연구 | 후보 | participant 수 | 설계 | 효과크기 | 증거 |
|---|---|---|---|---|---|
| **Narzisi et al. 2024 메타분석**, Clin Neuropsychiatry (PMID 38988677) | **T4** | **36 RCT / 2,796 participant**, 9–18세, Level 1 ASD | 대기자·표준케어 대조 | 사회기술 **SMD 0.3745 [0.2396, 0.5093]** · 행동증상 **0.3154 [0.1783, 0.4525]** · 불안/우울 **0.2780 [0.0432, 0.5128]**. 저자 결론 "small-to-moderate". **유의한 이질성 + 출판편향 근거 있음** | `[FULL TEXT 초록]` |
| **Cheng et al. 2025 PEERS 메타분석**, Asian J Psychiatr (PMID 40056598) | **T4+T5 혼합** | **21 RCT + 10 non-RCT** | — | 사회기술 지식·적용·정서지능 개선. **통합 효과크기 수치가 초록에 없음.** 중요: "**The PEERS intervention produced the smallest effect using PEERS in East Asia**" | `[FULL TEXT 초록]` |
| **Chien et al. 2023 PEERS 대만**, Psychol Med (PMID 34247667) | **T5** | **82 participant** 청년 ASD, 무작위배정 | PEERS vs TAU | 효과크기 수치 초록에 없음. **3개월·6개월 추적에서 대부분 유지** | `[ABSTRACT ONLY]` |
| **Koegel et al. 2026 Noora RCT**, JADD (PMID 39954218) | **T4+T5 걸침** | **30 participant** (15/15), 11–35세 | AI(LLM) vs 대기자, 4주 | **일반화 대화샘플 변화량: 실험 +37.67%p (SD 28.34) vs 대기 +2.53%p (SD 21.28)**, Mann-Whitney U 유의. 저자 보고 z기반 효과크기 "medium to large" | `[FULL TEXT]` |
| **Yoo et al. 2025 NDTx-01 RCT**, Psychiatry Clin Neurosci (PMID 40214154) | **T4 (+T6 혼합)** | **39 randomized / 38 분석** (19/19), 10–18세, **ASD 또는 SCD** | 모바일게임 SST + TAU vs TAU, 6주 | 1차: K-Vineland-II 적응행동종합 **+5.89 (SD 5.61) vs +1.21 (SD 5.99), p=0.037**. 2차: SRS-2 제한적관심·반복행동 **-9.11 (SD 10.26) vs -2.89 (SD 7.13), p=0.037**. **논문은 효과크기를 보고하지 않음** — 보고된 평균·SD로 내가 계산하면 d≈0.81 이나 이는 **저자 보고치가 아니므로 인용 시 반드시 그렇게 표기할 것** | `[FULL TEXT 초록]` |
| **Adams et al. 2012 SCIP RCT**, IJLCD (PMID 22512510) | **T6** | **88 participant**, **5;11–10;8세**, 2:1 배정, 최대 20세션 | 단일맹검 RCT, ITT | **1차 결과(구조적 언어)에서 효과 없음. 서사능력에서도 효과 없음.** 맹검 평정 대화능력 · 부모보고 화용기능 · 교사보고 교실학습기술에서 유의. 6개월 추적 | `[FULL TEXT 초록]` |
| **Alduais et al. 2025 umbrella review** (PMID 38060810) | **T6** | 3,609 studies → **42 review** 포함 | 우산리뷰 | **통합 효과크기 없음.** "positive impact" 라는 서술적 결론만 | `[FULL TEXT 초록]` |
| **T7 DLD 청소년 화용 중재** | **T7** | — | — | **메타분석 NOT FOUND AFTER DEFINED SEARCH.** 확인된 것은 InterAction VR feasibility **9 participant, 13–16세**, 결과 편차 큼 | `[ABSTRACT ONLY]` |

### 2.4 near transfer / far transfer / maintenance

**정의 구분을 반드시 유지한다:**
- **near transfer** = 훈련한 과제와 형태가 유사한 과제에서의 향상 (예: 앱 안 점수)
- **far transfer** = 훈련하지 않은 실제 대화에서의 향상
- **maintenance** = 중재 종료 후 시간이 지나도 유지

| 연구 | near | far | maintenance | 증거 |
|---|---|---|---|---|
| Noora RCT (T4/T5) | **예** — 앱 내 정답률 추적 (일 10 trial × 5일 × 4주, 목표 200 trial) | **부분적 예** — 사후 *사람과의* 대화샘플에서 +37.67%p. **단 이것은 연구실 대화샘플이지 실생활이 아니다.** 저자도 "additional research with generalization probes is needed" 라고 명시 | **없음** — 추적 측정 없음 | `[FULL TEXT]` |
| SCIP RCT (T6) | — | **부분적 예** — 맹검 평정 대화능력 + 교사보고 교실학습기술(다른 맥락) | **예** — 6개월 추적 | `[FULL TEXT 초록]` |
| PEERS 대만 (T5) | 예 (사회기술 지식) | 관찰자 평정 대화행동 개선 "경향" | **예** — 3개월·6개월 대부분 유지 | `[ABSTRACT ONLY]` |
| NDTx-01 (T4/T6) | 예 | **아니오** — 1차 결과가 보호자 보고 적응행동 척도. 실제 대화 측정 없음 | **없음** — 6주 시점까지만 | `[FULL TEXT 초록]` |
| Narzisi 메타 (T4) | — | **아니오** — 저자 스스로 "measurement of the outcomes" 를 주요 비뚤림 원천으로 지목. 결과 대부분이 평정척도 | 개별 RCT 편차 | `[FULL TEXT 초록]` |
| T6 / T7 의 13~25 | **NOT FOUND AFTER DEFINED SEARCH** | 동일 | 동일 | `[NOT FOUND]` |

> **과제 수행 향상 vs 실제 생활 변화 — 분리해 적으면:**
> - **과제 수행 향상**: T4·T5 에서 반복 확인됨 (Narzisi SMD≈0.37 · Noora 앱 내 정답률 · PEERS 사회기술 지식).
> - **실제 생활 변화**: **확인된 연구 0건.** 가장 가까운 것이 Noora 의 "연구실에서 사람과 나눈 대화샘플" 과 SCIP 의 "교사보고 교실학습기술" 이며, 둘 다 실생활 관계·참여 결과(친구 형성 · 취업 · 삶의 질)를 대조군과 함께 측정한 것이 아니다.

---

## 3 · 모집과 윤리

### 3.1 한국에서의 모집 난이도

| 지표 | 수치 | 함의 | 증거 |
|---|---|---|---|
| 한국 지역사회 ASD 유병률 | **2.64%** (95% CI 1.91–3.37). 대상 모집단 = 한국 한 지역사회 7–12세 **전원 55,266 participant** | 잠재 모집단 자체는 크다 | Kim et al. 2011, Am J Psychiatry (PMID 21558103) `[FULL TEXT 초록]` |
| 위 연구의 결정적 단서 | "**Two-thirds of ASD cases in the overall sample were in the mainstream school population, undiagnosed and untreated**" | **잠재 대상의 2/3가 진단조차 없다 → 임상 경로로는 닿을 수 없다** | 동일 `[FULL TEXT 초록]` |
| 한국 NHIS 청구자료 PDD 유병률 | **인구 10만 명당 22.0–44.6** (2007–2019) = **0.022–0.045%** | 진단코드를 달고 의료체계에 잡히는 사람은 지역사회 유병률의 **약 1/60~1/120 수준** | Psychiatry Investig 2023 (PMID 37899221) `[FULL TEXT 초록]` |
| 실측 모집 벤치마크 | NDTx-01 RCT: **서울성모 + 대구가톨릭 + 삼성서울 3개 기관 다기관**으로 적격자 **39 participant** 확보 | **대학병원 3곳을 동원해야 39명.** T4 한국 모집의 현실적 상한 근사치 | PMID 40214154 `[FULL TEXT 초록]` |
| 동의 단계 이탈 | Noora RCT: 무작위배정 전 **청소년 2명이 assent 거부**, 5명이 대화 불가, 6명이 사전점수 60% 초과로 제외 | **assent 거부는 실제로 발생하는 탈락 사유** | PMC13346298 `[FULL TEXT]` |

**후보별 한국 모집 난이도 판정**

| 후보 | 난이도 | 근거 |
|---|---|---|
| **T4** ASD 13–18 | **중.** 어렵지만 **선례가 있다** — 3개 병원으로 39명. 특수교육·발달센터 경로도 존재 | 위 표 |
| **T5** ASD 18–25 | **상.** 학령기를 벗어나면 서비스 연결이 끊긴다. **한국 성인 ASD 모집 선례를 이 조사에서 찾지 못함** | `[NOT FOUND AFTER DEFINED SEARCH]` |
| **T6** PLI/SCD | **최상.** SCD/SPCD 는 한국 임상에서 독립 진단명으로 널리 쓰이지 않는다. NDTx-01 도 "ASD 또는 SCD" 로 묶어 모집했고 SCD 단독 인원을 보고하지 않았다 → **SCD 단독 모집 가능성 자체가 미검증** | PMID 40214154 `[FULL TEXT 초록]` |
| **T7** DLD + 화용 | **최상.** 한국 DLD 청소년 코호트·모집 선례 **NOT FOUND AFTER DEFINED SEARCH**. 게다가 DLD 는 학령기 이후 언어치료 서비스에서 이탈하는 경향 | `[NOT FOUND]` |

### 3.2 취약계층 해당 여부 및 동의 구조

| 후보 | 취약계층 | 동의 구조 |
|---|---|---|
| **T4** (13–18) | **예 — 이중 취약**: ① 미성년자 ② 장애인 | 법정대리인 동의 + 본인 assent. **assent 거부 시 참여 불가** |
| **T5** (18–25) | **조건부.** 성인이므로 미성년 취약성 없음. 지적장애 동반 시 동의능력 평가 필요 | 본인 동의. **네 후보 중 동의 구조가 가장 단순** |
| **T6** | **예** (대부분 미성년) | T4 와 동일 |
| **T7** | **예** (대부분 미성년) + **언어이해 곤란 자체가 설명동의의 유효성을 위협** | T4 와 동일 + **동의서 easy-read 화 필요** |

**한국 법제의 결정적 제약** `[FULL TEXT · PMC11893356]`

Kim OJ, J Korean Med Sci 2025 (PMID 40065714) 본문 인용:

> "the Bioethics Act mandates **proxy consent even for minimal-risk research**, creating unnecessary barriers to studying vulnerable groups and hindering the collection of data essential for evidence-based interventions."

> "The most pressing issue in aligning Korea's 2013 Bioethics Act with the 2024 revision of the DoH is its **overly restrictive policies regarding research involving vulnerable populations**."

즉 **한국에서는 최소위험 연구여도 취약군에 대해 대리동의가 의무**다. T4·T6·T7 은 이 조항을 정면으로 맞는다. T5 는 성인이므로 비켜간다.

- 생명윤리법 제15조(심의)·제16조(동의) **조문 원문: NOT FOUND AFTER DEFINED SEARCH.** law.go.kr 은 프레임 구조로 본문 추출 실패(HTTP 500 / 1.2KB), elaw.klri.re.kr 은 동적 로딩으로 본문 추출 실패. **위 인용은 동 법을 분석한 심사 논문의 서술이지 조문 원문이 아니다.**

### 3.3 IRB 심의 등급 예상

| 후보 | 예상 등급 | 근거 |
|---|---|---|
| **T4** | **정규심의(full board) 가능성 높음** | 미성년 + 장애인 이중 취약군. 3.2 의 대리동의 의무로 심의면제 경로가 막힘 |
| **T5** | **신속심의(expedited) 가능성 있음** | 성인 · 최소위험 · 본인동의. 지적장애 동반 표본을 포함하면 정규심의로 상승 |
| **T6 / T7** | **정규심의** | T4 와 동일 조건 |

> 이 등급 예상은 **추론이며 근거 문서를 확보하지 못했다.** 한국 기관생명윤리위원회 심의등급 배정 기준 문서: **NOT FOUND AFTER DEFINED SEARCH** (irb.or.kr 은 HTTP 200 응답이나 세부 지침 페이지를 탐색하지 못함 — 시간 배분 문제). **이 칸은 IRB 사무국에 직접 문의해 확정할 것.**

**참고 — 공개 데이터를 쓰면 IRB 부담이 사라지는 경로가 있다.** TalkBank 원문: "TalkBank materials have already received IRB review at the contributor's home institution and **no further IRB approval is needed** for use of these data." 단 1.5 에서 확인했듯 **ASDBank 에는 13~25세 자료가 없다.** `[FULL TEXT]`

---

## 4 · 중재 근거 요약 (2.3 · 2.4 의 압축)

| 후보 | 메타분석 | 통합 효과크기 | 과제 수행 향상 | 실제 생활 변화 |
|---|---|---|---|---|
| **T4** | **있음** (Narzisi 2024: 36 RCT / 2,796 participant, 9–18세) | 사회기술 **SMD 0.3745 [0.2396, 0.5093]** — small-to-moderate. 이질성·출판편향 있음 | **확인됨** | **확인 안 됨.** 결과변수 대부분이 평정척도 |
| **T5** | **부분** (PEERS 메타 Cheng 2025 — 청소년·청년 혼합, 통합 ES 미보고) | **NOT FOUND** (초록에 수치 없음) | 확인됨 (PEERS 대만 82 participant, 3·6개월 유지) | **확인 안 됨** |
| **T6** | **umbrella review 만** (Alduais 2025: 42 review) — **통합 ES 없음** | **NOT FOUND** | SCIP RCT(88 participant, **5;11–10;8세**)에서 맹검 대화능력 평정 향상. **단 표준화 언어검사는 무효과** | 교사보고 교실학습기술 향상 = 다른 맥락 전이 근거 1건. **13~25 에서는 0건** |
| **T7** | **NOT FOUND AFTER DEFINED SEARCH** | — | InterAction VR **9 participant, 13–16세** feasibility — "향상 정도가 참가자 간·내, 기술별로 일정하지 않았다" | **0건** |

---

## 5 · 후보별 FATAL BLOCKER 후보

### T4 · ASD 청소년 13~18

| 블로커 유형 | 해당 | 내용 |
|---|---|---|
| 직접 근거 없음 | **아니오** | 13~18 직접 대화 참여자 연구 9건 검증. 메타분석 1건(2,796 participant) |
| 연령 검증 불가 | **아니오** | Paul 2009(12–18) · YiPP(9–17) · Zane & Grossman(10–18) 등 연령 명시 검증 |
| 모집 불가 | **아니오 (단 비용 큼)** | 한국 3개 대학병원 다기관 = 39 participant 실측 선례 |
| 평가 불가 | **부분 해당** | 영어권은 YiPP·PRS·CCC-2 로 덮이나 **한국어 표준화 화용검사는 KOPLAC(5–12세)뿐이라 13~18 을 못 덮는다** |
| 라이선스 불가 | **해당** | **13~25 공개 대화 데이터셋 0개.** ASDBank 영어 7개 코퍼스 전수 확인 결과 전부 12세 이하 |

**→ T4 의 FATAL BLOCKER 후보: ① 공개 데이터 부재 ② 한국어 화용 평가도구 연령 공백.**
둘 다 "연구가 없다"가 아니라 "**재료가 없다**"는 성격이라, 자체 수집 + 평가도구 자체 제작으로 우회 가능하되 **그 비용이 곧 프로젝트의 핵심 리스크**가 된다.

### T5 · ASD 청년 18~25

| 블로커 유형 | 해당 | 내용 |
|---|---|---|
| 직접 근거 없음 | **부분 해당** | 성인 ASD 연구는 있으나 **18~25 만을 분리한 표본이 0건.** "6–23세 평균 12.8세" 처럼 범위가 뭉개져 있어 해당 구간 participant 수를 셀 수 없다 |
| 연령 검증 불가 | **해당 (심각)** | 위와 동일. **이 후보의 가장 큰 문제** |
| 모집 불가 | **해당** | 한국 성인 ASD 모집 선례 NOT FOUND. 학령기 이후 서비스 연결 단절 |
| 평가 불가 | **해당 (심각)** | **18~25 를 덮는 표준화 화용 평가도구를 영어권에서도 확인하지 못했다.** YiPP 17세 상한 · CCC-2 아동용 · KOPLAC 12세 상한 |
| 라이선스 불가 | **해당** | Boston College 화용주석 코퍼스가 유일한 유망 자원이나 **공개 여부 미기재** |

**→ T5 의 FATAL BLOCKER 후보: ① 연령 검증 불가 ② 평가 불가 ③ 한국 모집 경로 부재.** 세 개가 동시에 걸린다.

### T6 · PLI / 화용언어곤란

| 블로커 유형 | 해당 | 내용 |
|---|---|---|
| 직접 근거 없음 | **해당 (심각)** | **13~25 × 대화자료 참여자 연구 0건.** PLI/SCD 대화자료 20 record 전수 확인 결과 전부 학령전·학령기 또는 타 증후군 |
| 연령 검증 불가 | **해당** | 청소년 SCD 연구 2건은 설문 기반, 대화 없음 |
| 모집 불가 | **해당 (심각)** | **진단 경계 자체가 불안정.** "The fuzzy boundaries of SPCD"(PMID 37664706) · "ASD·SPCD·DLD — multimorbidity or mutual exclusivity?"(PMID 39032223). 유병률 7–11%(13–14세)도 **CCC-2 절단점 기반이지 임상 진단이 아니다**(Ellis Weismer 2021, EpiSLI 393 participant). 한국에서 SCD 단독 모집 선례 없음 |
| 평가 불가 | **해당** | TOPICC 은 학령기 아동용. 한국어판 없음 |
| 라이선스 불가 | **해당** | 공개 데이터 0개 |

**→ T6 의 FATAL BLOCKER 후보: ① 직접 근거 없음(13~25 대화자료 0건) ② 모집 불가(진단 경계 불안정 + 한국 진단 경로 부재).** 다섯 항목 전부 걸린다.

### T7 · DLD + 사회적화용곤란

| 블로커 유형 | 해당 | 내용 |
|---|---|---|
| 직접 근거 없음 | **해당 (최심각)** | **13~25 × 대화자료 참여자 연구 0건.** 15 record 전수 확인 결과 전부 심리사회적 결과 연구. 유일한 화용 연구가 **2000년 논문 1건** |
| 연령 검증 불가 | **아니오** | InterAction VR 은 13–16세로 명시. 다만 **9 participant** |
| 모집 불가 | **해당 (심각)** | 한국 DLD 청소년 코호트·모집 선례 NOT FOUND |
| 평가 불가 | **해당** | DLD 특화 13~25 화용 평가도구 없음. CCC-2 의존. 한국어판 없음 |
| 라이선스 불가 | **해당** | 공개 데이터 0개 |
| 추가 블로커 | **해당** | **언어이해 곤란이 설명동의의 유효성 자체를 위협한다** — 취약군 중에서도 동의 설계가 가장 까다롭다 |
| 추가 블로커 | **해당** | **중재 근거 메타분석 0건.** 최신 DLD 대화 중재 BCDLD 는 6 participant / 6;06–8;02세 |

**→ T7 의 FATAL BLOCKER 후보: ① 직접 근거 없음(사실상 26년 전 논문 1건) ② 중재 근거 부재 ③ 모집 불가.**

---

## 6 · 네 후보 공통으로 걸리는 것 (설계 시 반드시 반영)

1. **13~25세 임상군의 다중 턴 자연대화 + 화용 주석 공개 데이터셋은 네 후보 통틀어 0개다.** 어느 쪽을 골라도 **자체 수집이 전제**다.
2. **한국어 표준화 화용 평가도구는 KOPLAC(5–12세) 하나뿐이고, 네 후보 연령대를 전부 벗어난다.** 평가도구를 직접 만들거나, 기존 도구를 번안·타당화하거나, 평가를 포기하고 다른 준거를 쓰거나 — 셋 중 하나를 정해야 한다.
3. **"실제 생활 변화"를 대조군과 함께 잰 연구는 네 후보 전부에서 0건.** 가장 앞선 Noora RCT 조차 "연구실에서 사람과 나눈 대화샘플"까지다. 제품이 far transfer 를 주장하려면 **선행연구가 없는 영역에 들어간다**는 뜻이다.
4. **한국 생명윤리법은 최소위험 연구여도 취약군 대리동의를 의무화한다.** T4·T6·T7 은 정면으로 맞고, T5 만 비켜간다.
5. **가장 가까운 선행 제품 연구가 이미 존재한다.**
   - Koegel et al. 2026 **Noora** (Stanford, LLM 기반 공감 반응 코칭, 11–35세, n=30, JADD, PMC13346298)
   - Yoo et al. 2025 **NDTx-01** (한국, 모바일 게임 SST, 10–18세 ASD 또는 SCD, n=39, 등록번호 KCT0009140)
   **두 편은 경쟁자이자 설계 레퍼런스다. 전문을 읽고 시작할 것.**

---

## 7 · 판정

### 데이터 실현가능성 순위

| 순위 | 후보 | 한 줄 판정 |
|---|---|---|
| **1위 (가장 높음)** | **T4 · ASD 청소년 13~18** | 직접 대화 연구 9건 · 메타분석 1건(2,796 participant) · 영어권 평가도구 3종(YiPP 9–17 등) · 한국 모집 실측 선례(3개 병원 39명) · 선행 제품 RCT 2편. **막히는 곳은 "연구가 없다"가 아니라 "공개 데이터가 없고 한국어 평가도구가 없다" 는 재료 문제** |
| 2위 | T5 · ASD 청년 18~25 | 성인 ASD 연구는 있으나 18~25 를 분리한 표본이 0건이고, 평가도구·한국 모집 경로가 모두 비어 있다. **동의 구조가 가장 단순하다는 점만이 유일한 장점** |
| 3위 | T6 · PLI / 화용언어곤란 | 진단 경계 자체가 학계에서 미해결이고, 13~25 대화자료가 0건이며, 한국에서 이 라벨로 모집한 선례가 없다 |
| **4위 (가장 낮음)** | **T7 · DLD + 사회적화용곤란** | **13~25 화용 대화 연구가 사실상 2000년 논문 1건**, 중재 메타분석 0건, 확인된 직접 중재가 n=9 feasibility 하나, 한국 코호트 없음, 게다가 언어이해 곤란이 설명동의 자체를 위협한다 |

### 가장 높은 것 / 가장 낮은 것

- **가장 높음: T4 (ASD 청소년 13~18).**
- **가장 낮음: T7 (DLD + 사회적화용곤란).**

### 이 순위의 한계

이 순위는 **데이터 실현가능성만** 본 것이다. 제품 가치·시장·차별화는 보지 않았다.
또한 T6·T7 의 낮은 순위 중 **한국어 부분은 RISS·KISS·DBpia 를 조회하지 못한 상태의 판정**이므로, 국내 언어재활 학계에 자료가 있을 가능성은 배제되지 않았다. **이 세 DB 조회는 후속 작업으로 반드시 남겨야 한다.**
