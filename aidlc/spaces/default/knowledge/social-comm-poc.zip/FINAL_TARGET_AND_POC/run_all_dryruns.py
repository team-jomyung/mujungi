# -*- coding: utf-8 -*-
"""배포본을 푼 자리에서 전부 돌려 본다. 일곱 가지.

    python run_all_dryruns.py
    python run_all_dryruns.py --quick     시뮬레이션을 짧게

  1 A1 시뮬레이션
  2 A1 선별 (모의 적격성 → 무작위 추출)
  3 A1 합의 자기시험
  4 A2 dry-run
  5 POC B dry-run
  6 수행 채점 dry-run
  7 C 스키마 시험

왜 있나
  앞 판은 이 폴더만 zip 으로 풀면 `run_a2.py` 가 깨졌다. 옆에 FINAL_CLOSURE 가 있어야 했다.
  POC B 와 채점기는 아예 POINTER 파일만 있었다. **배포본이 스스로 돌지 못했다.**

  사본을 작업 트리에 만들어 푸는 대신 `runtime_deps.py` 가 두 자리를 본다.
  배포본이면 runtime/ · 저장소면 FINAL_CLOSURE. 사본은 sha256 으로 정본과 대조된다.

  **의존이 없으면 조용히 건너뛰지 않는다.** 건너뛴 수를 세어 마지막 줄에 적고 exit != 0 이다.
"""
from __future__ import annotations

import argparse
import io
import os
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
ENV = dict(os.environ, PYTHONIOENCODING='utf-8')


def run(label, args, cwd, must=True):
    t0 = time.time()
    p = subprocess.run([sys.executable] + args, cwd=cwd, capture_output=True,
                       text=True, encoding='utf-8', errors='replace', env=ENV)
    secs = time.time() - t0
    ok = p.returncode == 0
    tail = (p.stdout or '').strip().split(chr(10))
    tail = tail[-1][:64] if tail else ''
    print('  %-30s %-4s %6.1fs  %s' % (label, 'ok' if ok else 'FAIL', secs, tail))
    if not ok:
        for ln in (p.stderr or '').strip().split(chr(10))[-6:]:
            print('        | %s' % ln[:110])
    return ok, must


def make_mock_eligibility(cands, out):
    """모의 적격성 파일. **사람 판정이 아니다.** 이름에 DRYRUN 을 박는다."""
    import csv
    rows = list(csv.DictReader(io.open(cands, encoding='utf-8', newline='')))
    with io.open(out, 'w', encoding='utf-8', newline='') as fh:
        w = csv.writer(fh)
        w.writerow(['pair_id', 'verdict', 'reason'])
        for r in rows:
            w.writerow([r['pair_id'], 'ELIGIBLE', ''])
    return len(rows)


def main(argv):
    ap = argparse.ArgumentParser()
    ap.add_argument('--quick', action='store_true')
    a = ap.parse_args(argv)

    import runtime_deps as RD
    ok_dep, lines = RD.check()
    print('런타임 의존')
    for x in lines:
        print('  ' + x)
    if not ok_dep:
        print('  판정 · **못 푼다.** dry-run 을 돌릴 수 없다.')
        return 2
    print()

    st = os.path.join(HERE, '_dryrun')
    if not os.path.isdir(st):
        os.makedirs(st)
    res = []
    print('dry-run 일곱')

    # 1 A1 시뮬레이션
    # 배포본에 든 전체 판 결과를 덮지 않는다. dry-run 은 따로 쓴다
    args = (['a1_sequential_simulation.py', '--out', os.path.join(st, 'sim')]
            + (['--quick'] if a.quick else []))
    res.append(run('1 A1 시뮬레이션', args, os.path.join(HERE, '01_A1')))

    # 2 A1 선별
    cands = None
    for p in (os.path.join(HERE, 'runtime', 'blind', 'blind_candidates_all.csv'),
              os.path.normpath(os.path.join(HERE, '..', 'poc_validation_v0_1',
                                            '02_POC_A', '_incoming',
                                            'blind_candidates_all.csv'))):
        if os.path.exists(p):
            cands = p
            break
    if cands is None:
        print('  %-30s %-4s  후보 CSV 가 없다' % ('2 A1 선별', 'FAIL'))
        res.append((False, True))
    else:
        elig = os.path.join(st, 'eligibility_DRYRUN.csv')
        n = make_mock_eligibility(cands, elig)
        res.append(run('2 A1 선별 (후보 %d)' % n,
                       ['select_primary.py', '--candidates', cands,
                        '--eligibility', elig, '--out', st],
                       os.path.join(HERE, '01_A1')))

    # 3 A1 합의 자기시험
    res.append(run('3 A1 합의 자기시험', ['selftest_consensus.py', '--out', st],
                   os.path.join(HERE, '02_A2')))

    # 4 A2 dry-run
    gold = os.path.join(st, 'a1_consensus_gold.csv')
    if os.path.exists(gold):
        res.append(run('4 A2 dry-run',
                       ['run_a2.py', '--gold', gold, '--out',
                        os.path.join(st, 'a2_results')],
                       os.path.join(HERE, '02_A2')))
    else:
        print('  %-30s %-4s  3 이 gold 를 못 만들었다' % ('4 A2 dry-run', 'FAIL'))
        res.append((False, True))

    # 5 POC B dry-run
    res.append(run('5 POC B dry-run', ['run_poc_b.py', '--out', st],
                   os.path.join(HERE, '03_B')))

    # 6 수행 채점 dry-run
    res.append(run('6 수행 채점 dry-run', ['run_scoring.py', '--out', st],
                   os.path.join(HERE, '05_PERFORMANCE')))

    # 7 C 스키마 시험
    res.append(run('7 C 스키마 시험', ['test_c_schema.py'],
                   os.path.join(HERE, '04_C')))

    bad = [1 for ok, must in res if not ok and must]
    print()
    print('=' * 62)
    print('  돌린 것 %d · 실패 %d' % (len(res), len(bad)))
    print('  판정 · %s' % ('전부 통과' if not bad else '실패'))
    return 1 if bad else 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
