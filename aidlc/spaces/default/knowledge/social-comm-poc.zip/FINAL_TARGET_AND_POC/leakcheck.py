# -*- coding: utf-8 -*-
"""누출 검사 · 한 곳에만 둔다.

무엇이 누출인가를 정확히 잡는다.

처음에는 본문에서 `정답은` 과 `SAME_CONTEXT` 를 찾았다. 그랬더니
지침의 **"정답은 없다"** 와 판정 앱의 **범주 이름 목록**이 걸렸다. 둘 다 누출이 아니다.
판정자는 범주 이름을 알아야 판정하고, "정답을 주지 않는다" 는 문장은 누출의 반대다.
**부분 문자열 검사는 부정문과 지시문을 구분하지 못한다.**

그래서 누출을 구조로 정의한다.

  1 특정 **쌍 번호 옆에 특정 라벨**이 있는가        → 그것이 "이 쌍의 답은 이것" 이다
  2 **정답 열**이 있는가                          → gold · expected · answer · truth
  3 **상대 판정자의 파일**이 들어 있는가             → 대소문자·구분자 무시하고 본다
  4 **생성기 내부 표시**가 있는가                   → target_grade · _dryrun_truth 등

심어 보고 확인한 것 · 넷 다 터진다. `python leakcheck.py --selftest`
"""
from __future__ import annotations

import csv
import io
import os
import re
import sys

# 정답 열. 판정자가 보면 안 된다
LEAK_COLS = ('gold', 'expected', 'answer', 'truth', 'skill_identity',
             'transfer_distance', 'rater_a', 'rater_b',
             '_dryrun', 'candidate_id', 'target_grade', 'variation_axis')

# 낱말 자체가 생성기 내부 표시라 판정자 꾸러미에 있을 이유가 없다
LEAK_TEXT = ('_dryrun_truth', 'target_grade', 'variation_plan', 'expected_label')

# 쌍 번호와 라벨이 같은 줄에 있으면 누출이다.
# 'B07 은 SAME 이고' 처럼 한국어 조사가 끼어도 잡아야 하므로 \b 를 라벨 앞뒤로만 건다.
LABELS = ('SAME_CONTEXT', 'DIFFERENT', 'UNDETERMINED', 'UNKNOWN', 'SAME', 'NEAR', 'FAR')
PAIR_RX = re.compile(r'[A-Z]{1,2}[0-9]{2,3}')
LABEL_RX = re.compile(r'(?<![A-Z_])(' + '|'.join(LABELS) + r')(?![A-Z_])')


# rater 뒤에 구분자가 있든 없든 A/B 낱자를 잡되, 뒤에 글자가 더 오면 판정자 표시가 아니다.
# 'rater_app' 의 a 뒤에는 'pp' 가 오므로 걸리지 않는다. 'rater_B_result' 의 B 뒤에는 '_' 라 걸린다.
RATER_TOKEN_RX = re.compile(r'rater[^a-z0-9]?([ab])(?![a-z])', re.I)


def norm(s):
    """열 이름 비교용. 대소문자와 구분자를 지운다.
    파일 이름에는 쓰지 않는다. 지우면 rater_app 이 rater_a 와 부딪힌다."""
    return re.sub(r'[^a-z0-9]', '', (s or '').lower())


def line_has_pair_and_label(line):
    """한 줄에 쌍 번호와 라벨이 함께 있는가. 그것만이 답의 누출이다."""
    if not PAIR_RX.search(line):
        return None
    m = LABEL_RX.search(line)
    if not m:
        return None
    return m.group(1)


def scan_file(path, role):
    """파일 하나를 본다. 걸린 것들의 문장 목록을 돌려준다."""
    hits = []
    base = os.path.basename(path)

    # 3 상대 판정자의 파일인가.
    #
    # 구분자를 통째로 지우면 'rater_app.html' 이 'raterapp' 이 되고 거기에 'ratera' 가 들어 있어
    # 판정 앱 자체가 "판정자 A 의 파일" 로 걸렸다. 정규화를 세게 하면 충돌이 생긴다.
    # 그래서 지우지 말고 **토큰 경계로** 본다. rater 뒤의 A/B 가 낱자로 끝나야 판정자 표시다.
    if role and role.lower().startswith('rater'):
        me = (RATER_TOKEN_RX.search(role) or [None, ''])[1].upper() \
            if RATER_TOKEN_RX.search(role) else ''
        m = RATER_TOKEN_RX.search(base)
        if m and me and m.group(1).upper() != me:
            hits.append('%s · **상대 판정자(%s)의 파일**이 들어 있다'
                        % (base, m.group(1).upper()))

    try:
        if path.lower().endswith('.csv'):
            with io.open(path, encoding='utf-8-sig', newline='') as f:
                rows = list(csv.DictReader(f))
            cols = [norm(c) for c in (rows[0].keys() if rows else [])]
            raw = list(rows[0].keys()) if rows else []
            for c, rawc in zip(cols, raw):
                for b in LEAK_COLS:
                    if norm(b) in c:
                        hits.append('%s · 열 "%s" · %s 가 보면 안 된다' % (base, rawc, role))
                        break
            # CSV 본문에도 쌍 번호 옆 라벨이 있을 수 있다
            for i, r in enumerate(rows[:2000], 2):
                line = ','.join((v or '') for v in r.values())
                lab = line_has_pair_and_label(line)
                if lab:
                    hits.append('%s:%d · 쌍 번호 옆에 라벨 "%s"' % (base, i, lab))
                    break
        else:
            t = io.open(path, encoding='utf-8', errors='replace').read()
            for b in LEAK_TEXT:
                if b in t:
                    hits.append('%s · 생성기 내부 표시 "%s"' % (base, b))
            for i, line in enumerate(t.split(chr(10)), 1):
                lab = line_has_pair_and_label(line)
                if lab:
                    hits.append('%s:%d · 쌍 번호 옆에 라벨 "%s" · %s'
                                % (base, i, lab, line.strip()[:50]))
                    break
    except Exception as e:                                     # noqa: BLE001
        hits.append('%s · 읽을 수 없다 · %s' % (base, e))
    return hits


def scan_dir(d, role):
    hits, n = [], 0
    if not os.path.isdir(d):
        return hits, n
    for f in sorted(os.listdir(d)):
        p = os.path.join(d, f)
        if not os.path.isfile(p):
            continue
        n += 1
        hits += scan_file(p, role)
    return hits, n


def scan_packages(base):
    """packages/ 전체. (걸린 것, 파일 수) 를 돌려준다."""
    hits, n = [], 0
    if not os.path.isdir(base):
        return hits, n
    for role in sorted(os.listdir(base)):
        d = os.path.join(base, role)
        if os.path.isdir(d):
            h, c = scan_dir(d, role)
            hits += h
            n += c
    return hits, n


# ───────────────────────── 자기 시험 ─────────────────────────

SELFTEST = [
    ('쌍 번호 옆에 라벨 · 한국어 조사',
     '_t.md', 'B07 은 SAME 이고 B12 는 FAR 다' + chr(10), 'rater_A'),
    ('쌍 번호 옆에 라벨 · 표',
     '_t.md', '| B03 | NEAR |' + chr(10), 'rater_A'),
    ('생성기 내부 표시',
     '_t.md', 'target_grade: NEAR' + chr(10), 'rater_B'),
    ('정답 열이 있는 CSV',
     '_t.csv', 'pair_id,gold' + chr(10) + 'B01,SAME' + chr(10), 'rater_A'),
    ('상대 판정자 파일 · 대소문자 다름',
     'rater_b_result.csv', 'pair_id' + chr(10) + 'B01' + chr(10), 'rater_A'),
    ('상대 판정자 파일 · 구분자 다름',
     'raterB-final.csv', 'pair_id' + chr(10) + 'B01' + chr(10), 'rater_A'),
]

SHOULD_PASS = [
    ('지침의 "정답은 없다"', '_ok.md', '정답은 없다. 규칙대로 읽으면 된다.' + chr(10), 'rater_A'),
    ('앱의 범주 이름 목록', '_ok.js', "var D = ['SAME_CONTEXT','NEAR','FAR'];" + chr(10), 'rater_A'),
    ('쌍 번호만', '_ok.md', 'B07 을 먼저 본다' + chr(10), 'rater_A'),
    # 정규화를 세게 했을 때 rater_app 이 rater_a 로 걸렸다. 그 회귀를 막는다
    ('판정 앱 자체 · rater_app.html', 'rater_app.html',
     'var D = 1;' + chr(10), 'rater_B'),
    ('판정 앱 자체 · A 쪽', 'rater_app.html', 'var D = 1;' + chr(10), 'rater_A'),
]


def selftest():
    import tempfile
    d = tempfile.mkdtemp()
    bad = 0
    print('심어 보고 터지는지 · 터져야 정상')
    for name, fn, body, role in SELFTEST:
        p = os.path.join(d, fn)
        io.open(p, 'w', encoding='utf-8', newline='').write(body)
        h = scan_file(p, role)
        os.remove(p)
        ok = bool(h)
        bad += 0 if ok else 1
        print('  %-34s %s' % (name, 'FIRES' if ok else '>>> 안 터진다'))
        for x in h:
            print('        - %s' % x[:92])
    print('걸리면 안 되는 것 · 조용해야 정상')
    for name, fn, body, role in SHOULD_PASS:
        p = os.path.join(d, fn)
        io.open(p, 'w', encoding='utf-8', newline='').write(body)
        h = scan_file(p, role)
        os.remove(p)
        ok = not h
        bad += 0 if ok else 1
        print('  %-34s %s' % (name, 'quiet' if ok else '>>> 헛되이 걸린다'))
        for x in h:
            print('        - %s' % x[:92])
    os.rmdir(d)
    print('판정 · %s' % ('통과' if bad == 0 else '실패 %d' % bad))
    return 1 if bad else 0


if __name__ == '__main__':
    sys.exit(selftest() if '--selftest' in sys.argv[1:] else 0)
