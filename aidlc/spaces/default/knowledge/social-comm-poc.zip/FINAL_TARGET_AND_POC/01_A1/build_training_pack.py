# -*- coding: utf-8 -*-
"""판정자 훈련 자료를 만든다. **연습이 아니라 훈련이다.**

    python build_training_pack.py

왜 고쳤나
  앞 절차는 "훈련이 일치도를 11%p 올린다(Bayerl & Paul 2011)" 를 근거로 훈련을 필수라고 적어 놓고,
  실제로는 **되먹임 없는 연습 8쌍**을 줬다. 그 문헌의 "trained" 는 되먹임과 보정을 포함한다.
  **근거는 훈련의 것을 빌리고 실제로는 연습만 시키면 주장이 근거를 넘는다.**

  둘 중 하나를 골라야 했다.
    (가) 되먹임 없음 → "orientation · practice" 라고 부르고 trained-rater 주장을 뺀다
    (나) trained-rater 신뢰도를 주장 → **되먹임과 근거를 준다**

  **(나)를 골랐다.** 자료가 이미 있기 때문이다.
  규격 작성자가 합성 20쌍에 대한 기대 라벨과 근거를 `_gold/` 에 적어 두었다.

분리 규칙 · 이것이 핵심이다
  훈련에 쓴 쌍은 **어떤 측정에도 다시 쓰지 않는다.** 답을 본 쌍이기 때문이다.

    합성 20 ── 8 훈련 (답과 근거를 준다)      → **측정에서 완전히 뺀다**
            └─ 12 진단 (답을 주지 않는다)     → H-03 출처별 κ 비교용
    blind 80 ── 60 PRIMARY                   → 주 산출물
             └─ 20 CHALLENGE                 → 진단

  훈련 8쌍이 PRIMARY 나 진단 12쌍과 겹치면 이 스크립트가 멈춘다.
"""
from __future__ import annotations

import argparse
import csv
import io
import os
import random
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(os.path.dirname(HERE))
POC_A = os.path.join(REPO, 'poc_validation_v0_1', '02_POC_A')
PAIRS = os.path.join(POC_A, 'existing_synthetic_20.csv')
GOLD = os.path.join(POC_A, '_gold', 'existing_synthetic_20_SPEC_EXPECTED.csv')
N_TRAIN = 8
SEED = 20260914


def read(p):
    with io.open(p, encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))


def main(argv):
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', default=os.path.join(HERE, 'training'))
    a = ap.parse_args(argv)
    for p in (PAIRS, GOLD):
        if not os.path.exists(p):
            print('없다 · %s' % p)
            return 2
    if not os.path.isdir(a.out):
        os.makedirs(a.out)

    pairs = {r['pair_id']: r for r in read(PAIRS)}
    gold = {r['pair_id']: r for r in read(GOLD)}
    ids = sorted(set(pairs) & set(gold))
    if len(ids) < N_TRAIN + 4:
        print('합성 쌍이 %d개뿐이다. 훈련 %d + 진단 4 를 못 만든다' % (len(ids), N_TRAIN))
        return 2

    rng = random.Random(SEED)
    train = sorted(rng.sample(ids, N_TRAIN))
    diag = [i for i in ids if i not in train]

    # 분리 단언. 훈련에 쓴 쌍이 측정에 들어가면 안 된다
    if set(train) & set(diag):
        print('훈련과 진단이 겹친다')
        return 2
    for name in ('primary_60.csv', 'challenge_rest.csv'):
        p = os.path.join(HERE, name)
        if os.path.exists(p):
            m = {r['pair_id'] for r in read(p)}
            if m & set(train):
                print('훈련 쌍이 %s 에 들어 있다 · %s' % (name, sorted(m & set(train))))
                return 2

    # 훈련 자료 · 답과 근거를 함께 준다
    L = ['# A1 판정자 훈련 자료', '',
         '**이것은 훈련이다. 연습이 아니다.** 답과 근거를 함께 준다.', '',
         '왜 답을 주나 · 우리는 "훈련받은 판정자의 일치도" 를 주장한다',
         '(Bayerl & Paul 2011 · 훈련 81% 대 미훈련 70% · p=.002).',
         '그 문헌의 "훈련" 은 되먹임과 보정을 포함한다.',
         '**되먹임 없이 연습만 시키고 훈련 효과를 주장하면 주장이 근거를 넘는다.**', '',
         '> **여기 나오는 %d쌍은 본 판정에 쓰지 않는다.** 답을 봤기 때문이다.' % N_TRAIN,
         '> 본 판정은 전혀 다른 쌍으로 한다. 겹치는지는 스크립트가 확인한다.', '',
         '---', '', '## 어떻게 쓰나', '',
         '1. 쌍을 읽고 **먼저 혼자 판정한다.** 답을 보기 전에 적는다',
         '2. 그다음 답과 근거를 본다',
         '3. **다르면 왜 다른지 적는다.** 이 적는 일이 훈련의 핵심이다',
         '4. 여덟 쌍을 다 하고 나서 조정자에게 질문한다', '',
         '자기 판정을 먼저 적지 않고 답부터 보면 훈련이 되지 않는다. **순서를 지킨다.**', '',
         '---', '']
    for k, pid in enumerate(train, 1):
        g, pr = gold[pid], pairs[pid]
        L += ['## 훈련 %d · %s' % (k, pid), '',
              '### 상황 A', '', pr.get('event_A', ''), '',
              '### 상황 B', '', pr.get('event_B', ''), '',
              '### 먼저 혼자 판정한다', '',
              '| | 내 판정 |', '|---|---|',
              '| 이해축 (SAME / DIFFERENT / UNKNOWN) | |',
              '| 수행축 | |',
              '| 거리 (이해축이 SAME 일 때만) | |', '',
              '<details><summary>다 적었으면 여기를 연다</summary>', '',
              '| | 규격이 기대하는 답 |', '|---|---|',
              '| 이해축 | **%s** |' % g.get('spec_understand', ''),
              '| 수행축 | **%s** |' % g.get('spec_perform', ''),
              '| 규격 절 | %s |' % g.get('spec_group', ''), '',
              '**왜 그런가** · %s' % g.get('spec_rationale', ''), '',
              '**내 판정과 달랐다면 무엇이 달랐나** ·', '', '</details>', '', '---', '']
    L += ['## 훈련이 끝나면', '',
          '- 다르게 본 쌍이 몇 개였는지 센다',
          '- **어느 필드에서 자주 갈렸는지** 적는다',
          '- 그 필드에 대해 조정자에게 묻는다',
          '- **다른 판정자와 이야기하지 않는다.** 질문은 조정자에게만', '',
          '## 이 자료가 약속하지 않는 것', '',
          '- 규격이 기대하는 답이 **옳다**는 것. A1 이 재는 것은 재현성이지 타당성이 아니다',
          '- 본 판정에서 **같은 답이 나온다**는 것. 쌍이 다르다', '']
    io.open(os.path.join(a.out, 'TRAINING_PACK.md'), 'w',
            encoding='utf-8', newline='\n').write('\n'.join(L))

    # 진단 12 · 답을 주지 않는다
    with io.open(os.path.join(a.out, 'diagnostic_%d.csv' % len(diag)), 'w',
                 encoding='utf-8', newline='') as fh:
        w = csv.DictWriter(fh, fieldnames=['pair_id', 'event_A', 'event_B'])
        w.writeheader()
        for pid in diag:
            w.writerow({k: pairs[pid].get(k, '') for k in
                        ('pair_id', 'event_A', 'event_B')})

    io.open(os.path.join(a.out, 'SEPARATION.md'), 'w', encoding='utf-8',
            newline='\n').write('\n'.join([
                '# 분리 기록', '',
                '| 묶음 | 쌍 | 답을 주나 | 무엇에 쓰나 |', '|---|---|---|---|',
                '| 훈련 | %d · %s | **준다** | 훈련만. **측정에 안 쓴다** |'
                % (len(train), ' '.join(train)),
                '| 진단 | %d · %s | 아니오 | H-03 출처별 κ 비교 |'
                % (len(diag), ' '.join(diag)),
                '| PRIMARY | 60 (blind) | 아니오 | **주 산출물** |',
                '| CHALLENGE | 나머지 blind | 아니오 | 진단 |', '',
                'seed %d · 같은 seed 면 같은 %d쌍이 훈련으로 뽑힌다.' % (SEED, N_TRAIN),
                '', '**훈련 쌍이 어떤 측정 묶음에도 없다는 것을 이 스크립트가 확인한다.**',
                '겹치면 멈추고 그 쌍 번호를 찍는다.', '']))

    print('훈련 %d쌍 · 진단 %d쌍 · 겹침 0' % (len(train), len(diag)))
    print('  훈련 · %s' % ' '.join(train))
    print('  진단 · %s' % ' '.join(diag))
    print('  저장 · %s' % os.path.relpath(a.out, HERE))
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
