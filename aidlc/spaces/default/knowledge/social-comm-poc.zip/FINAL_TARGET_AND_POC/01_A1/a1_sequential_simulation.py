# -*- coding: utf-8 -*-
"""A1 표본 크기를 **순차 설계**로 정한다. 결과를 보고 표본을 늘리는 것이 왜 공짜가 아닌지까지 잰다.

    python a1_sequential_simulation.py            전체 (수 분)
    python a1_sequential_simulation.py --quick    반복 수를 줄여 빠르게 (배선 확인용)
    python a1_sequential_simulation.py --out DIR  다른 자리에 쓴다 (dry-run 용)

앞 판(`FINAL_CLOSURE/03_AUTOMATION/a1_sample_size_simulation.py`)과 무엇이 다른가

  1 **셀마다 독립 난수**를 쓴다. 앞 판은 생성기 하나를 모든 셀에 차례로 넘겨서
    반복 수를 바꾸면 격자 전체가 움직였다(ERR-06). 여기서는 (n, kappa, prevalence, rep)
    로 seed 를 만들어 셀이 서로 의존하지 않는다. 반복 수를 늘려도 기존 값이 안 바뀐다.

  2 **중첩 표본**을 쓴다. 한 번에 120쌍을 뽑아 두고 앞 40 · 60 · 80 · 100 · 120 을
    같은 시행의 부분집합으로 본다. 그래야 "60 을 보고 120 으로 늘린다" 를 시뮬레이션할 수 있다.
    독립 표본으로 재면 순차 설계가 아니라 별개 실험 둘이 된다.

  3 **1단계에서 성공 주장을 하지 않는다.** 앞 판은 60 에서 CI 하한이 문턱을 넘으면
    거기서 멈추고 주장했다. 같은 데이터를 두 번 보면서 일반 부트스트랩 CI 를 그대로 썼고,
    참값이 문턱일 때 명목 5% 가 실제 6.2% 가 됐다. alpha 를 나눠 쓰지도 신뢰수열을 쓰지도
    않았으므로 **그 구조를 없앴다.**
    지금은 1단계가 **무익(futility) 판정만** 한다. 문턱 주장은 120 에서 **한 번만** 하므로
    반복검정 보정이 필요 없다. 고정 n=120 과 나란히 재서 차이가 사라졌는지 확인한다.

무엇을 모형화하나
  두 판정자가 3범주(SAME / DIFFERENT / UNKNOWN)에 라벨을 붙인다.
  참 일치 kappa_true 와 범주 분포에서 결합분포를 만들고 거기서 뽑는다.
  부트스트랩은 개별 쌍이 아니라 **3x3 표의 9칸에서 다항추출**한다. 통계적으로 같고 훨씬 빠르다.

무엇이 아닌가
  통계적 정밀도 계산이다. "이만큼이면 POC 가 성공한다" 가 아니다.
  표준 라이브러리만 쓴다.
"""
from __future__ import annotations

import csv
import io
import json
import os
import random
import sys

BASE_SEED = 20260914
CATS = ('SAME', 'DIFFERENT', 'UNKNOWN')
NS = (40, 60, 80, 100, 120)
KAPPAS = (0.4, 0.5, 0.6, 0.7, 0.8)
PREVS = {
    'balanced':      (0.40, 0.40, 0.20),
    'same_heavy':    (0.60, 0.25, 0.15),
    'unknown_heavy': (0.35, 0.30, 0.35),
}
THRESHOLD = 0.6          # 규격 §11 · PROJECT OPERATING THRESHOLD
FAIL_BELOW = 0.4         # 규격 §11.4 · CI 상한이 이 아래면 실패
STAGE1_N = 60
STAGE2_N = 120

HERE = os.path.dirname(os.path.abspath(__file__))


def build_joint(kappa_true, prev):
    """목표 kappa 를 내는 두 판정자의 결합분포(9칸)를 만든다.

    확률 p 로 둘이 같은 범주에 합의하고(주변분포 prev), 1-p 로 각자 독립으로 prev 에서 뽑는다.
    Po = p + (1-p)*Pe 이므로 kappa = (Po-Pe)/(1-Pe) = p 다. p 를 kappa_true 로 둔다.
    """
    p = kappa_true
    joint = []
    for i in range(3):
        for j in range(3):
            v = (1 - p) * prev[i] * prev[j]
            if i == j:
                v += p * prev[i]
            joint.append(v)
    s = sum(joint)
    return [v / s for v in joint]


def kappa_from_counts(c):
    """9칸 도수에서 비가중 Cohen kappa. 표본이 한 칸에 몰리면 정의되지 않는다(None)."""
    n = sum(c)
    if n == 0:
        return None
    po = (c[0] + c[4] + c[8]) / float(n)
    r = [(c[0] + c[1] + c[2]), (c[3] + c[4] + c[5]), (c[6] + c[7] + c[8])]
    k = [(c[0] + c[3] + c[6]), (c[1] + c[4] + c[7]), (c[2] + c[5] + c[8])]
    pe = sum(r[i] * k[i] for i in range(3)) / float(n * n)
    if abs(1 - pe) < 1e-12:
        return None
    return (po - pe) / (1 - pe)


def draw_counts(rng, joint, n):
    """결합분포에서 n 쌍을 뽑아 9칸 도수로 돌려준다."""
    idx = rng.choices(range(9), weights=joint, k=n)
    c = [0] * 9
    for i in idx:
        c[i] += 1
    return c


def boot_ci(rng, counts, b):
    """9칸에서 다항추출하는 백분위 부트스트랩 95% CI. 개별 쌍을 다시 뽑는 것과 같다."""
    n = sum(counts)
    w = [x / float(n) for x in counts]
    vals = []
    for _ in range(b):
        idx = rng.choices(range(9), weights=w, k=n)
        c = [0] * 9
        for i in idx:
            c[i] += 1
        v = kappa_from_counts(c)
        if v is not None:
            vals.append(v)
    if len(vals) < 10:
        return None, None
    vals.sort()
    lo = vals[int(0.025 * len(vals))]
    hi = vals[min(len(vals) - 1, int(0.975 * len(vals)))]
    return lo, hi


def band(k):
    """Landis & Koch 구간. 저자들이 붙인 이름표이지 실증 문턱이 아니다.
    범주 불안정성을 재려고 쓴다 · 표본을 늘렸을 때 '해석 이름'이 바뀌는 빈도."""
    if k is None:
        return 'UNDEFINED'
    if k < 0.0:
        return 'POOR'
    if k < 0.20:
        return 'SLIGHT'
    if k < 0.40:
        return 'FAIR'
    if k < 0.60:
        return 'MODERATE'
    if k < 0.80:
        return 'SUBSTANTIAL'
    return 'ALMOST_PERFECT'


def cell_seed(kappa, prev_name, rep):
    """셀마다 독립. 반복 수를 늘려도 앞 반복의 값이 바뀌지 않는다."""
    return (BASE_SEED
            + int(round(kappa * 100)) * 1000003
            + (sorted(PREVS).index(prev_name) + 1) * 7919
            + rep * 104729)


def run(reps, boot):
    rows, seq_rows = [], []
    for prev_name in sorted(PREVS):
        prev = PREVS[prev_name]
        for kappa in KAPPAS:
            joint = build_joint(kappa, prev)
            # n 별 누적 통계
            acc = {n: {'width': [], 'lo': [], 'hat': [], 'claim': 0, 'fail': 0,
                       'undef': 0, 'band': []} for n in NS}
            seq = {'stop_claim': 0, 'stop_fail': 0, 'extend': 0,
                   'claim_after_extend': 0, 'fail_after_extend': 0,
                   'inconclusive': 0, 'band_changed': 0, 'extended_and_looked': 0}
            for rep in range(reps):
                rng = random.Random(cell_seed(kappa, prev_name, rep))
                # 한 시행에서 120쌍을 뽑고 앞부분을 부분집합으로 쓴다
                draws = rng.choices(range(9), weights=joint, k=STAGE2_N)
                per_n = {}
                for n in NS:
                    c = [0] * 9
                    for i in draws[:n]:
                        c[i] += 1
                    hat = kappa_from_counts(c)
                    lo, hi = boot_ci(rng, c, boot)
                    per_n[n] = (hat, lo, hi)
                    a = acc[n]
                    if hat is None or lo is None:
                        a['undef'] += 1
                        a['band'].append('UNDEFINED')
                        continue
                    a['hat'].append(hat)
                    a['lo'].append(lo)
                    a['width'].append(hi - lo)
                    a['band'].append(band(hat))
                    if lo > THRESHOLD:
                        a['claim'] += 1
                    if hi < FAIL_BELOW:
                        a['fail'] += 1

                # --- 순차 설계 ---
                #
                # 1단계에서 **성공 주장을 하지 않는다.** 실패만 조기 중단한다.
                #
                # 앞 판은 60 에서 CI 하한이 문턱을 넘으면 거기서 멈추고 주장했다.
                # 같은 데이터를 두 번 보면서 일반 부트스트랩 CI 를 그대로 썼다.
                # 참값이 문턱일 때 명목 5% 가 실제 6.2% 가 됐다(측정값).
                # alpha 를 나눠 쓰지도, 신뢰수열을 쓰지도 않았으므로 **그 구조를 없앤다.**
                #
                # 지금 · 1단계는 futility(무익) 판정만 한다. 문턱 주장은 120 에서 한 번만.
                # 한 번만 보므로 보정이 필요 없다.
                h1, l1, u1 = per_n[STAGE1_N]
                h2, l2, u2 = per_n[STAGE2_N]
                if u1 is not None and u1 < FAIL_BELOW:
                    seq['stop_fail'] += 1          # 명백한 실패만 조기 중단
                else:
                    seq['extend'] += 1
                    seq['extended_and_looked'] += 1
                    if l2 is not None and l2 > THRESHOLD:
                        seq['claim_after_extend'] += 1
                    elif u2 is not None and u2 < FAIL_BELOW:
                        seq['fail_after_extend'] += 1
                    else:
                        seq['inconclusive'] += 1
                    if band(h1) != band(h2):
                        seq['band_changed'] += 1

            for n in NS:
                a = acc[n]
                ok = len(a['width'])
                med = lambda v: (sorted(v)[len(v) // 2] if v else None)
                mean = lambda v: (sum(v) / float(len(v)) if v else None)
                var = None
                if len(a['hat']) > 1:
                    m = mean(a['hat'])
                    var = sum((x - m) ** 2 for x in a['hat']) / float(len(a['hat']) - 1)
                bands = {}
                for b in a['band']:
                    bands[b] = bands.get(b, 0) + 1
                top = max(bands.values()) / float(reps) if bands else 0.0
                # 몬테카를로 오차. 이 숫자를 소수 셋째 자리까지 믿으면 안 된다는 것을 같이 적는다.
                # 앞 판 격자와 이 격자가 n60 κ0.8 에서 0.795 대 0.670 으로 달랐다.
                # 두 구현을 같은 입력으로 맞대어 보니 build_joint · kappa · 부트스트랩이 모두 같았다.
                # 차이는 몬테카를로 변동이었다. 그래서 오차를 열로 낸다.
                pc = a['claim'] / float(reps)
                se = (pc * (1 - pc) / reps) ** 0.5
                rows.append({
                    'prevalence': prev_name, 'kappa_true': kappa, 'n': n, 'reps': reps,
                    'median_kappa_hat': None if not a['hat'] else round(med(a['hat']), 4),
                    'median_ci_width': None if not ok else round(med(a['width']), 4),
                    'median_ci_lower': None if not ok else round(med(a['lo']), 4),
                    'variance_kappa_hat': None if var is None else round(var, 5),
                    'p_claim_threshold': round(pc, 4),
                    'p_claim_mc_se': round(se, 4),
                    'p_claim_ci95_lo': round(max(0.0, pc - 1.96 * se), 4),
                    'p_claim_ci95_hi': round(min(1.0, pc + 1.96 * se), 4),
                    'p_declare_fail': round(a['fail'] / float(reps), 4),
                    'p_undefined': round(a['undef'] / float(reps), 4),
                    'modal_band': (max(bands, key=bands.get) if bands else None),
                    'modal_band_share': round(top, 4),
                })

            tot = float(reps)
            seq_rows.append({
                'prevalence': prev_name, 'kappa_true': kappa, 'reps': reps,
                'stage1_n': STAGE1_N, 'stage2_n': STAGE2_N,
                # 구조상 0 이다. 1단계에서 성공 주장을 하지 않는다. 열을 남겨 그것을 보인다
                'p_stop_stage1_claim': round(seq['stop_claim'] / tot, 4),
                'p_stop_stage1_fail': round(seq['stop_fail'] / tot, 4),
                'p_extend': round(seq['extend'] / tot, 4),
                'p_claim_after_extend': round(seq['claim_after_extend'] / tot, 4),
                'p_fail_after_extend': round(seq['fail_after_extend'] / tot, 4),
                'p_inconclusive_at_120': round(seq['inconclusive'] / tot, 4),
                'p_claim_overall_sequential': round(
                    (seq['stop_claim'] + seq['claim_after_extend']) / tot, 4),
                'p_band_changed_60_to_120': round(
                    seq['band_changed'] / max(1.0, float(seq['extended_and_looked'])), 4),
                'expected_pairs_judged': round(
                    (seq['stop_claim'] + seq['stop_fail']) / tot * STAGE1_N
                    + seq['extend'] / tot * STAGE2_N, 1),
            })
    return rows, seq_rows


def main(argv):
    quick = '--quick' in argv
    # dry-run 이 배포본에 든 전체 판 결과를 덮어쓰면 안 된다.
    # 검사가 검사 대상을 망가뜨리는 것과 같은 문제라 --out 으로 따로 쓰게 한다
    out_dir = HERE
    if '--out' in argv:
        i = argv.index('--out')
        if i + 1 < len(argv):
            out_dir = argv[i + 1]
            if not os.path.isdir(out_dir):
                os.makedirs(out_dir)
    reps = 40 if quick else 600
    boot = 60 if quick else 250
    rows, seq_rows = run(reps, boot)

    # 고정 n=120 과 순차 설계의 문턱 주장 확률을 나란히 놓는다.
    fixed = {(r['prevalence'], r['kappa_true']): r['p_claim_threshold']
             for r in rows if r['n'] == STAGE2_N}
    for sr in seq_rows:
        f = fixed[(sr['prevalence'], sr['kappa_true'])]
        sr['p_claim_fixed_120'] = f
        sr['sequential_minus_fixed'] = round(sr['p_claim_overall_sequential'] - f, 4)

    grid = os.path.join(out_dir, 'A1_SAMPLE_SIZE_SIMULATION.csv')
    with io.open(grid, 'w', encoding='utf-8', newline='') as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        w.writeheader(); w.writerows(rows)
    seqf = os.path.join(out_dir, 'A1_SEQUENTIAL_SIMULATION.csv')
    with io.open(seqf, 'w', encoding='utf-8', newline='') as fh:
        w = csv.DictWriter(fh, fieldnames=list(seq_rows[0].keys()))
        w.writeheader(); w.writerows(seq_rows)
    meta = {'base_seed': BASE_SEED, 'reps': reps, 'bootstrap': boot,
            'threshold': THRESHOLD, 'fail_below': FAIL_BELOW,
            'stage1_n': STAGE1_N, 'stage2_n': STAGE2_N,
            'ns': list(NS), 'kappas': list(KAPPAS),
            'prevalences': {k: list(v) for k, v in PREVS.items()},
            'independent_seed_per_cell': True,
            'nested_samples': True,
            'note': 'ERR-06 의 원인이던 셀 간 난수 공유를 없앴다. 셀 seed 는 (kappa, prevalence, rep) 에서 만든다.'}
    io.open(os.path.join(out_dir, 'A1_SIMULATION_META.json'), 'w',
            encoding='utf-8', newline='\n').write(
        json.dumps(meta, ensure_ascii=False, indent=2) + '\n')

    print('격자 %d행 · 순차 %d행 · 반복 %d · 부트스트랩 %d' % (len(rows), len(seq_rows), reps, boot))
    g = lambda n, k: [r for r in rows if r['prevalence'] == 'balanced'
                      and r['n'] == n and abs(r['kappa_true'] - k) < 1e-9][0]
    print('  balanced · 문턱 주장 확률 (± 는 몬테카를로 95% 구간)')
    for k in KAPPAS:
        print('    κ%.1f · ' % k + ' · '.join(
            'n%d %.2f[%.2f-%.2f]' % (n, g(n, k)['p_claim_threshold'],
                                     g(n, k)['p_claim_ci95_lo'], g(n, k)['p_claim_ci95_hi'])
            for n in NS))
    print('  순차 설계 (60 futility -> 120 판정) · balanced')
    print('    1단계는 무익 판정만 한다. 문턱 주장은 120 에서 한 번뿐이라 보정이 필요 없다')
    for sr in seq_rows:
        if sr['prevalence'] != 'balanced':
            continue
        print('    κ%.1f · 1단계 조기중단(실패) %.3f · 확장 %.3f · 순차 주장 %.3f · 고정120 %.3f · 차이 %+.3f · 기대 %.1f쌍'
              % (sr['kappa_true'], sr['p_stop_stage1_fail'], sr['p_extend'],
                 sr['p_claim_overall_sequential'], sr['p_claim_fixed_120'],
                 sr['sequential_minus_fixed'], sr['expected_pairs_judged']))
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
