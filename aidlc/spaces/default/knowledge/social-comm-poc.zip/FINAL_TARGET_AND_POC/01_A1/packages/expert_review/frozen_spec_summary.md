# Frozen Spec v0.1 · 한 장 요약

> 원본은 `frozen_spec_v0_1.html`. **이 요약은 참조용이고 원본이 기준이다.**
> 어긋나면 원본이 맞다. 어긋난 것을 발견하면 `ISSUES_FOR_V0_2.md` 에 적는다.

## 판정은 두 축의 조합이다

| 축 | 묻는 것 | 입력 | 값 |
|---|---|---|---|
| **Skill Identity** | 같은 기술인가 | **Core 다섯만** | SAME · DIFFERENT · UNDETERMINED |
| **Transfer Distance** | 얼마나 멀리 옮겼나 | **상황 변화만** | SAME_CONTEXT · NEAR · FAR · UNDETERMINED |

Skill Identity 는 **단계별로** 낸다. 이해는 Core 1~4, 수행은 Core 1~5.
Transfer Distance 는 **Skill Identity(이해)가 SAME 일 때만** 계산하고 단계 무관 하나다.

## Core Equivalence Fields · 다섯

1. `target_skill` — RECOGNIZE / PRODUCE / REPAIR
2. `required_inference` — 머리로 메워야 하는 빈칸의 종류
3. `perspective_structure` — 누구의 속을 몇 겹 짐작하는가
4. `decidable_by_evidence` — 단서로 답을 고를 수 있는가
5. `direct_check_allowed` — **수행 전용** · 대놓고 물어봐도 되는 자리인가

**Supporting** (판정에 쓰지 않음) · pragmatic_function · SocialCue 기능 유형 · partner_goal_explicit · interpretation cardinality

## 판정 규칙

```
Skill Identity (단계별)
  Core 중 하나라도 UNKNOWN   → UNDETERMINED   ← DIFFERENT 보다 먼저
  Core 중 하나라도 DIFFERENT → DIFFERENT
  Core 전부 SAME             → SAME

Transfer Distance (이해 SkillIdentity = SAME 일 때만)
  관계·상황유형 중 UNKNOWN               → UNDETERMINED
  관계·상황유형 변경 + 대가·회복 변경     → FAR
  관계·상황유형만 변경                    → NEAR
  관계·상황유형 그대로                    → SAME_CONTEXT
```

## 사용자 표기 = 조합

| 표기 | Identity | Distance |
|---|---|---|
| SAME_SKILL | SAME | SAME_CONTEXT |
| NEAR_TRANSFER | SAME | NEAR |
| FAR_TRANSFER | SAME | FAR |
| SAME_SKILL · 거리 미결 | SAME | UNDETERMINED |
| DIFFERENT_SKILL | DIFFERENT | 계산 안 함 |
| UNDETERMINED | UNDETERMINED | 계산 안 함 |

## 어느 UNKNOWN 이 무엇을 멈추나

| UNKNOWN | 이해 Identity | 수행 Identity | Distance |
|---|---|---|---|
| Core 1~4 | 멈춤 | 멈춤 | 계산 안 함 |
| `direct_check_allowed` | 계산됨 | 멈춤 | 계산됨 |
| Relationship · 상황유형 | 계산됨 | 멈춤 | 멈춤 |
| context_constraints | 계산됨 | 계산됨 | NEAR 까지만 |
| **user_goal** | **계산됨** | **계산됨** | **계산됨** |
| Supporting · Topic · 장소 | 계산됨 | 계산됨 | 계산됨 |

## 최소 수집 계약

**필수 값 셋** · 대화 내용 · 어려웠던 턴 · 관계
**필수 질문 하나** · 당시 원했던 것 · **답은 nullable**

## 통계

| | 범주 | 대상 | 가중 |
|---|---|---|---|
| Skill Identity κ | 3 | 전체 · 이해·수행 각각 | **없음** |
| Transfer Distance κ | 4 | **두 판정자가 모두 이해 SAME** | 없음(주) + 선형(보조) |
| Core field κ | 3 | 전체 · 다섯 필드 | 없음 |

혼동 행렬 · Identity 3×3 두 장 + Distance 4×4 한 장. **사용자 표기 6×6 은 진단용.**

**`SkillIdentity=SAME + Distance=UNDETERMINED` 는 축 1 행렬의 SAME 칸에 들어간다.** 일반 UNDETERMINED 와 합치지 않는다.

## 문턱

| 항목 | 값 | 근거 |
|---|---|---|
| Skill Identity κ | 0.6 | **인접 준거** · AMP κ .712/.715 · SPCD 매핑 κ .69~.76 |
| Core field κ | 0.5 | 운영 기준 |
| UNDETERMINED 비율 | 0.20 · **축 1만** | 운영 기준 |
| Transfer Distance κ | 0.5 · **단독 실패 없음** | 운영 기준 |

**외부 준거가 있는 문턱은 κ 0.6 하나뿐이다.**
