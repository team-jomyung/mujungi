# Blind Selector · 적격성 판정

이 폴더 안의 것만 보면 된다. **다른 자료를 요청하지 않는다.**

| | |
|---|---|
| 역할 | blind_selector |
| 예상 시간 | **2.5~3.5시간** |
| 제출물 | `eligibility.csv` 파일 하나 |

## 무엇을 하나

후보 80쌍이 **판정에 쓸 수 있는 글인지**만 본다. 어느 쌍을 쓸지는 정하지 않는다.

## 순서

1. `blind_candidates_all.csv` 를 연다
2. `eligibility_checklist.md` 로 쌍마다 본다
3. `eligibility_TEMPLATE.csv` 에 `pair_id,verdict,reason` 을 채운다. verdict 는 **ELIGIBLE 또는 REJECT 둘뿐**이다
4. 모든 쌍에 대해 찍는다. 건너뛴 쌍이 있으면 그것도 선별이다

## 제출

`eligibility.csv` 파일 하나

## 지켜야 할 것

- 당신은 **A1 판정자가 될 수 없다**. 후보 본문을 봤기 때문이다
- 유형·정답·범주를 적지 않는다
- 몇 쌍이 뽑히는지 묻지 않는다
