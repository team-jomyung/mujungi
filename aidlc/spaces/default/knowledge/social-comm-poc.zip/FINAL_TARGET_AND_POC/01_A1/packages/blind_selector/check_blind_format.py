"""blind 후보 파일의 **형식만** 기계로 확인한다.

    python check_blind_format.py _incoming/blind_candidates_raw.csv

내용 판단을 하지 않는다. 어느 쌍이 어느 유형인지, 정답이 무엇인지 보지 않는다.
그것은 사람이 blind_set_qc_checklist.md 로 한다.

여기서 보는 것은 다섯뿐이다.
  1. 열이 pair_id · event_A · event_B 셋인가
  2. 빈 칸이 없는가
  3. 정답이 새는 열 이름이 있는가
  4. 명백한 개인정보 형태가 있는가
  5. A 와 B 의 문장이 통째로 같은 쌍이 있는가
"""
import argparse
import csv
import io
import re
import sys

REQUIRED = ['pair_id', 'event_A', 'event_B']

# 정답이 샐 수 있는 열 이름
LEAK_COLS = ['type', 'category', 'answer', 'label', 'grade', 'expected',
             'skill', 'distance', 'intended', 'gold', 'note', '유형', '정답', '분류']

# 형식만 본다. 이름 자체를 판단하지 않는다
PII_PAT = [
    ('전화번호', re.compile(r'01[0-9][-\s]?\d{3,4}[-\s]?\d{4}')),
    ('이메일', re.compile(r'[\w.+-]+@[\w-]+\.[\w.]+')),
    ('URL', re.compile(r'https?://')),
    ('주민번호 형태', re.compile(r'\d{6}[-\s]?[1-4]\d{6}')),
    ('학교명', re.compile(r'[가-힣]{2,6}(대학교|고등학교|중학교)')),
]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('path')
    args = ap.parse_args()

    with io.open(args.path, encoding='utf-8-sig', newline='') as f:
        rows = list(csv.DictReader(f))
    cols = list(rows[0].keys()) if rows else []

    problems, warnings = [], []

    if cols != REQUIRED:
        extra = [c for c in cols if c not in REQUIRED]
        missing = [c for c in REQUIRED if c not in cols]
        if missing:
            problems.append(f'필수 열 없음 · {missing}')
        if extra:
            problems.append(f'열이 더 있다 · {extra}. 세 열만 있어야 한다')

    for c in cols:
        if any(k in c.lower() for k in LEAK_COLS):
            problems.append(f'정답이 샐 수 있는 열 이름 · {c!r}')

    ids = set()
    for i, r in enumerate(rows, 1):
        pid = (r.get('pair_id') or '').strip()
        a = (r.get('event_A') or '').strip()
        b = (r.get('event_B') or '').strip()
        if not pid:
            problems.append(f'{i}행 · pair_id 비어 있음')
        elif pid in ids:
            problems.append(f'{i}행 · pair_id 중복 {pid}')
        ids.add(pid)
        if not a or not b:
            problems.append(f'{pid} · event 비어 있음')
            continue
        if a == b:
            problems.append(f'{pid} · A 와 B 가 완전히 같다')
        for label, pat in PII_PAT:
            if pat.search(a) or pat.search(b):
                problems.append(f'{pid} · {label} 형태가 있다')
        if len(a) < 40 or len(b) < 40:
            warnings.append(f'{pid} · 상황이 짧다 (A {len(a)}자 · B {len(b)}자)')
        if '"' not in a and '“' not in a and "'" not in a:
            warnings.append(f'{pid} · A 에 따옴표 대화가 없어 보인다')
        if '"' not in b and '“' not in b and "'" not in b:
            warnings.append(f'{pid} · B 에 따옴표 대화가 없어 보인다')

    print(f'행 {len(rows)} · 열 {cols}')
    print(f'\n형식 문제 {len(problems)}건')
    for p in problems:
        print('  x', p)
    print(f'\n주의 {len(warnings)}건')
    for w in warnings[:12]:
        print('  !', w)
    if len(warnings) > 12:
        print(f'  ... 외 {len(warnings)-12}건')

    print('\n' + '=' * 56)
    print('  이 스크립트는 형식만 본다.')
    print('  어느 쌍을 고를지는 blind_set_qc_checklist.md 로 사람이 한다.')
    print('  QC 하는 사람은 판정자가 될 수 없다.')
    print('=' * 56)
    return 1 if problems else 0


if __name__ == '__main__':
    sys.exit(main())
