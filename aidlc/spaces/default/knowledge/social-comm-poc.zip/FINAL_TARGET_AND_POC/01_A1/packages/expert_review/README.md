# 전문가 검토

이 폴더 안의 것만 보면 된다. **다른 자료를 요청하지 않는다.**

| | |
|---|---|
| 역할 | expert_review |
| 예상 시간 | **2~3시간** |
| 제출물 | `review_response.csv` |

## 무엇을 하나

규격과 **타겟 결정**을 바깥 시각으로 본다.

## 순서

1. `FINAL_DECISIONS.md` 를 읽는다 · 타겟을 왜 넓혔는지
2. `frozen_spec_summary.md` 를 읽는다
3. `expert_questions.md` 에 답한다
4. `review_response_template.csv` 로 제출한다

## 제출

`review_response.csv`

## 지켜야 할 것

- **조정자를 겸할 수 있다.** 서로 오염시키지 않는다
- 동의하지 않는 자리를 적어 주는 것이 이 검토의 목적이다
