# -*- coding: utf-8 -*-
"""PRIMARY 신뢰도 set 을 **사람이 고르지 않고** 무작위로 뽑는다.

    python select_primary.py --eligibility eligibility.csv
    python select_primary.py --eligibility eligibility.csv --primary-n 60 --seed 20260914

왜 있나
  `A1_SELECTION_BIAS_AUDIT.md` 를 보라. 지금 선별기는 QC 하는 사람에게 쌍마다 **유형**을 태그하게
  하고 유형별 최소 3쌍을 채우게 한다. 그 열 가지 유형은 규격의 판정 라벨을 일상어로 바꿔 적은 것이다.
  그러면 "판정자가 모르는 분포에서 얼마나 일치하는가" 를 재려는 자리에서
  **선별하는 사람이 라벨을 보며 분포를 만들고 있다.**

  그래서 고르는 일을 사람에게서 뗀다. 사람은 **적격 / 탈락**만 찍는다.
  몇 쌍을 고르는지, 어느 쌍이 뽑히는지 모른다. 추출은 고정 seed 로 이 스크립트가 한다.

입력 · eligibility.csv
  pair_id,verdict,reason
  verdict 는 ELIGIBLE 또는 REJECT 둘뿐이다. 그 밖의 값이 있으면 멈춘다.
  유형 열이 있으면 **멈춘다.** 유형을 본 선별은 PRIMARY 가 될 수 없다.

출력
  primary_60.csv       판정자에게 줄 PRIMARY set · pair_id · event_A · event_B 셋뿐
  challenge_rest.csv   남은 적격 후보 · 진단용
  SELECTION_RECORD.md  누가 · 언제 · 몇 개를 탈락시켰나 · seed · 재현 명령

되돌릴 수 있어야 한다. 같은 eligibility.csv 와 같은 seed 면 같은 60쌍이 나온다.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import io
import os
import random
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_CANDIDATES = os.path.normpath(os.path.join(
    HERE, '..', '..', 'poc_validation_v0_1', '02_POC_A', '_incoming', 'blind_candidates_all.csv'))
COLS = ('pair_id', 'event_A', 'event_B')
BANNED_COLS = ('type', 'types', '유형', 'label', 'verdict_guess', 'expected',
               'gold', 'answer', 'distance', 'skill_identity')


def read_csv(path):
    return list(csv.DictReader(io.open(path, encoding='utf-8', newline='')))


def sha16(path):
    return hashlib.sha256(io.open(path, 'rb').read()).hexdigest()[:16]


def main(argv):
    ap = argparse.ArgumentParser()
    ap.add_argument('--candidates', default=DEFAULT_CANDIDATES)
    ap.add_argument('--eligibility', required=True)
    ap.add_argument('--primary-n', type=int, default=60)
    ap.add_argument('--seed', type=int, default=20260914)
    ap.add_argument('--out', default=HERE)
    a = ap.parse_args(argv)

    for p in (a.candidates, a.eligibility):
        if not os.path.exists(p):
            print('없다 · %s' % p)
            return 2

    cands = read_csv(a.candidates)
    if list(cands[0].keys()) != list(COLS):
        print('후보 파일의 열이 %s 여야 한다 · 지금 %s' % (list(COLS), list(cands[0].keys())))
        return 2

    elig = read_csv(a.eligibility)
    cols = [c.strip().lower() for c in elig[0].keys()]
    bad_cols = [c for c in cols if any(b in c for b in BANNED_COLS)]
    if bad_cols:
        # 유형을 본 선별은 PRIMARY 가 될 수 없다. 조용히 넘어가면 감사가 무의미해진다
        print('적격성 파일에 판정·유형을 뜻하는 열이 있다 · %s' % bad_cols)
        print('PRIMARY 는 적격/탈락만 본다. CHALLENGE 로 쓰려면 --out 을 나눠 따로 돌린다.')
        return 2
    if 'pair_id' not in cols or 'verdict' not in cols:
        print('적격성 파일에 pair_id 와 verdict 열이 있어야 한다')
        return 2

    seen, verdicts = set(), {}
    for r in elig:
        pid = (r.get('pair_id') or '').strip()
        v = (r.get('verdict') or '').strip().upper()
        if not pid:
            continue
        if pid in seen:
            print('적격성 파일에 같은 pair_id 가 두 번 · %s' % pid)
            return 2
        seen.add(pid)
        if v not in ('ELIGIBLE', 'REJECT'):
            print('verdict 는 ELIGIBLE 또는 REJECT 여야 한다 · %s = "%s"' % (pid, v))
            return 2
        verdicts[pid] = v

    ids = [c['pair_id'] for c in cands]
    missing = [i for i in ids if i not in verdicts]
    if missing:
        print('적격성 판정이 빠진 쌍 %d개 · %s' % (len(missing), missing[:6]))
        print('모든 후보에 대해 판정해야 한다. 건너뛴 쌍이 있으면 그것도 선별이다.')
        return 2

    eligible = [c for c in cands if verdicts[c['pair_id']] == 'ELIGIBLE']
    rejected = [c for c in cands if verdicts[c['pair_id']] == 'REJECT']
    if len(eligible) < a.primary_n:
        print('적격 후보가 %d 쌍뿐이다. PRIMARY %d 쌍을 뽑을 수 없다.'
              % (len(eligible), a.primary_n))
        print('후보를 더 받거나 --primary-n 을 낮춘다. 낮추면 시뮬레이션의 최소선을 다시 본다.')
        return 2

    # 고정 seed · pair_id 로 정렬한 뒤 뽑는다. 입력 파일의 행 순서에 결과가 의존하지 않게
    pool = sorted(eligible, key=lambda c: c['pair_id'])
    rng = random.Random(a.seed)
    primary = sorted(rng.sample(pool, a.primary_n), key=lambda c: c['pair_id'])
    pset = {c['pair_id'] for c in primary}
    challenge = [c for c in pool if c['pair_id'] not in pset]

    def write(name, rows):
        p = os.path.join(a.out, name)
        with io.open(p, 'w', encoding='utf-8', newline='') as fh:
            w = csv.DictWriter(fh, fieldnames=list(COLS))
            w.writeheader()
            w.writerows([{k: r[k] for k in COLS} for r in rows])
        return p

    p1 = write('primary_%d.csv' % a.primary_n, primary)
    p2 = write('challenge_rest.csv', challenge)

    stamp = time.strftime('%Y-%m-%d %H:%M')
    rec = ['# PRIMARY 선별 기록', '',
           '**사람이 고르지 않았다.** 사람은 적격/탈락만 찍었고 추출은 고정 seed 로 했다.',
           '이유는 `A1_SELECTION_BIAS_AUDIT.md`.', '',
           '| | |', '|---|---|',
           '| 만든 시각 | %s |' % stamp,
           '| 후보 파일 | `%s` · sha256 앞 16 `%s` |'
           % (os.path.basename(a.candidates), sha16(a.candidates)),
           '| 적격성 파일 | `%s` · sha256 앞 16 `%s` |'
           % (os.path.basename(a.eligibility), sha16(a.eligibility)),
           '| 후보 | %d쌍 |' % len(cands),
           '| 적격 | %d쌍 |' % len(eligible),
           '| 탈락 | %d쌍 |' % len(rejected),
           '| PRIMARY | **%d쌍** · `%s` |' % (len(primary), os.path.basename(p1)),
           '| CHALLENGE 후보 | %d쌍 · `%s` |' % (len(challenge), os.path.basename(p2)),
           '| seed | **%d** |' % a.seed, '',
           '## 다시 만드는 법', '', '```',
           'python select_primary.py --eligibility %s --primary-n %d --seed %d'
           % (os.path.basename(a.eligibility), a.primary_n, a.seed),
           '```', '',
           '같은 두 파일과 같은 seed 면 같은 %d쌍이 나온다. **결과를 보고 다시 뽑지 않는다.**' % a.primary_n,
           '다시 뽑으면 그것이 다시 선별 편향이다.', '',
           '## 탈락 사유', '', '| pair_id | 사유 |', '|---|---|']
    by_id = {r.get('pair_id', '').strip(): (r.get('reason') or '').strip() for r in elig}
    for c in rejected:
        rec.append('| %s | %s |' % (c['pair_id'], by_id.get(c['pair_id'], '(사유 없음)')))
    if not rejected:
        rec.append('| — | 탈락 없음 |')
    rec += ['', '## 이 값의 이름', '',
            '주 산출물 κ 를 적을 때 **"A1 κ (유형 균형 풀 · 무작위 %d)"** 로 적는다.' % a.primary_n,
            '무작위 추출이 고친 것은 **선별 단계**이지 **작성 단계**가 아니다.',
            '후보 풀 자체가 열 가지 유형 할당량으로 만들어졌다. 자연 발생 분포가 아니다.', '']
    io.open(os.path.join(a.out, 'SELECTION_RECORD.md'), 'w',
            encoding='utf-8', newline='\n').write('\n'.join(rec))

    print('적격 %d · 탈락 %d · PRIMARY %d · CHALLENGE 후보 %d · seed %d'
          % (len(eligible), len(rejected), len(primary), len(challenge), a.seed))
    print('  %s' % p1)
    print('  %s' % p2)
    print('  SELECTION_RECORD.md')
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
