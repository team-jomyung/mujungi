# PRIMARY 선별 기록

**사람이 고르지 않았다.** 사람은 적격/탈락만 찍었고 추출은 고정 seed 로 했다.
이유는 `A1_SELECTION_BIAS_AUDIT.md`.

| | |
|---|---|
| 만든 시각 | 2026-09-14 13:39 |
| 후보 파일 | `blind_candidates_all.csv` · sha256 앞 16 `7ecef4e13d6e3ab7` |
| 적격성 파일 | `eligibility_DRYRUN.csv` · sha256 앞 16 `2681527f32916585` |
| 후보 | 80쌍 |
| 적격 | 78쌍 |
| 탈락 | 2쌍 |
| PRIMARY | **60쌍** · `primary_60.csv` |
| CHALLENGE 후보 | 18쌍 · `challenge_rest.csv` |
| seed | **20260914** |

## 다시 만드는 법

```
python select_primary.py --eligibility eligibility_DRYRUN.csv --primary-n 60 --seed 20260914
```

같은 두 파일과 같은 seed 면 같은 60쌍이 나온다. **결과를 보고 다시 뽑지 않는다.**
다시 뽑으면 그것이 다시 선별 편향이다.

## 탈락 사유

| pair_id | 사유 |
|---|---|
| B08 | 시험용 모의 탈락 |
| B56 | 시험용 모의 탈락 |

## 이 값의 이름

주 산출물 κ 를 적을 때 **"A1 κ (유형 균형 풀 · 무작위 60)"** 로 적는다.
무작위 추출이 고친 것은 **선별 단계**이지 **작성 단계**가 아니다.
후보 풀 자체가 열 가지 유형 할당량으로 만들어졌다. 자연 발생 분포가 아니다.
