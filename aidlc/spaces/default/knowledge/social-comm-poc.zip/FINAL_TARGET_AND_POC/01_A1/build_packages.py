# -*- coding: utf-8 -*-
"""사람에게 보낼 꾸러미 일곱을 만든다. 만든 뒤 누출 검사를 스스로 돌린다.

    python build_packages.py

만드는 것
    packages/blind_selector/      적격성 판정만. **고르지 않는다**
    packages/rater_A/             A1 판정자 A
    packages/rater_B/             A1 판정자 B
    packages/c_operator/          POC C 진행자
    packages/c_participant/       POC C 참가자
    packages/performance_rater/   수행 평정자
    packages/expert_review/       전문가 검토

각 꾸러미에 README · 지시문 · 앱(있으면) · 제출 형식 · 예상 시간을 넣는다.

누출
    판정자 꾸러미에 **정답 · 상대 판정자 파일 · 유형 태그 · 생성기 메타데이터**가 들어가면 안 된다.
    만든 직후 `verify_pre_human.py` 의 검사 함수를 그대로 불러 확인한다.
    복사본을 따로 만들지 않는다. 검사는 한 곳에만 있어야 한다.
"""
from __future__ import annotations

import io
import os
import shutil
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
NEW = os.path.dirname(HERE)
ROOT = os.path.dirname(NEW)
RC1 = os.path.join(ROOT, 'poc_validation_v0_1')
PK = os.path.join(HERE, 'packages')


def put(role, src, name=None):
    d = os.path.join(PK, role)
    if not os.path.isdir(d):
        os.makedirs(d)
    if not os.path.exists(src):
        return False
    shutil.copy2(src, os.path.join(d, name or os.path.basename(src)))
    return True


def readme(role, title, what, steps, submit, minutes, warn=None):
    L = ['# %s' % title, '',
         '이 폴더 안의 것만 보면 된다. **다른 자료를 요청하지 않는다.**', '',
         '| | |', '|---|---|',
         '| 역할 | %s |' % role,
         '| 예상 시간 | **%s** |' % minutes,
         '| 제출물 | %s |' % submit, '',
         '## 무엇을 하나', '', what, '',
         '## 순서', '']
    for i, s in enumerate(steps, 1):
        L.append('%d. %s' % (i, s))
    L += ['', '## 제출', '', submit, '']
    if warn:
        L += ['## 지켜야 할 것', ''] + ['- %s' % w for w in warn] + ['']
    io.open(os.path.join(PK, role, 'README.md'), 'w',
            encoding='utf-8', newline='\n').write('\n'.join(L))


def main():
    if os.path.isdir(PK):
        shutil.rmtree(PK)
    os.makedirs(PK)
    missing = []

    # ── 1 blind_selector · 적격성만. 고르지 않는다 ──
    role = 'blind_selector'
    os.makedirs(os.path.join(PK, role))
    for s in (os.path.join(RC1, '02_POC_A', '_incoming', 'blind_candidates_all.csv'),
              os.path.join(RC1, '02_POC_A', 'check_blind_format.py')):
        if not put(role, s):
            missing.append(s)
    io.open(os.path.join(PK, role, 'eligibility_TEMPLATE.csv'), 'w',
            encoding='utf-8', newline='').write('pair_id,verdict,reason\n')
    io.open(os.path.join(PK, role, 'eligibility_checklist.md'), 'w',
            encoding='utf-8', newline='\n').write('\n'.join([
        '# 적격성 점검표', '',
        '**고르지 않는다.** 통과(ELIGIBLE) 인지 탈락(REJECT) 인지만 찍는다.',
        '몇 쌍이 뽑히는지 당신은 모른다. 추출은 스크립트가 고정 seed 로 한다.', '',
        '왜 이렇게 바뀌었나 · `A1_SELECTION_BIAS_AUDIT.md`.',
        '앞 절차는 쌍마다 "유형" 을 태그하고 유형별 할당량을 채우게 했다.',
        '그 열 가지 유형이 **판정 라벨을 일상어로 바꾼 것**이어서,',
        '선별이 사실상 정답 분포를 만들고 있었다.', '',
        '## 쌍마다 본다 · 하나라도 걸리면 REJECT', '',
        '- [ ] 상황 A 와 B 가 각각 3~6문장인가',
        '- [ ] 각 상황에 실제 오간 말이 **최소 두 턴** 큰따옴표로 있는가',
        '- [ ] 내가 무엇에 막혔는지가 한 문장으로 있는가',
        '- [ ] **실명·연락처·학교명·회사명**이 없는가',
        '- [ ] 자살·자해·성적 내용·혐오 표현이 없는가',
        '- [ ] **정답이나 해설이 붙어 있지 않은가**',
        '- [ ] 상대의 속마음을 단정하지 않았는가',
        '- [ ] A 와 B 의 표면 문장이 그대로 같지 않은가',
        '- [ ] 1인칭 "나" 로 쓰였는가', '',
        '**걸리면 고치지 말고 버린다.** 고치면 당신의 판단이 섞인다.', '',
        '## 적지 않는 것', '',
        '- 이 쌍의 정답 · 유형 · 범주',
        '- "이건 NEAR 같다" 같은 판단',
        '- 몇 쌍을 고를지에 대한 고민. **고르는 것이 아니다**', '']))
    readme(role, 'Blind Selector · 적격성 판정',
           '후보 80쌍이 **판정에 쓸 수 있는 글인지**만 본다. 어느 쌍을 쓸지는 정하지 않는다.',
           ['`blind_candidates_all.csv` 를 연다',
            '`eligibility_checklist.md` 로 쌍마다 본다',
            '`eligibility_TEMPLATE.csv` 에 `pair_id,verdict,reason` 을 채운다. '
            'verdict 는 **ELIGIBLE 또는 REJECT 둘뿐**이다',
            '모든 쌍에 대해 찍는다. 건너뛴 쌍이 있으면 그것도 선별이다'],
           '`eligibility.csv` 파일 하나', '2.5~3.5시간',
           ['당신은 **A1 판정자가 될 수 없다**. 후보 본문을 봤기 때문이다',
            '유형·정답·범주를 적지 않는다',
            '몇 쌍이 뽑히는지 묻지 않는다'])

    # ── 2·3 rater_A · rater_B ──
    for role, who in (('rater_A', 'A'), ('rater_B', 'B')):
        os.makedirs(os.path.join(PK, role))
        for s in (os.path.join(RC1, '02_POC_A', 'rater_app.html'),
                  os.path.join(RC1, '02_POC_A', 'annotation_guideline_onepage.md')):
            if not put(role, s):
                missing.append(s)
        readme(role, 'A1 판정자 %s' % who,
               '두 상황이 **같은 화용 능력을 요구하는지** 판정한다.\n\n'
               '사용자 향상 평가가 아니다. **규칙이 사람 사이에 재현되는지**를 재는 것이다.',
               ['`annotation_guideline_onepage.md` 를 읽는다 (15분)',
                '연습 쌍 8개를 한다. **정답은 주지 않는다** (25분)',
                '혼자 되돌아본다. 질문은 조정자에게만 (20분)',
                '`rater_app.html` 을 브라우저로 연다. 판정 쌍 파일을 불러온다',
                '**20쌍씩 세 회차**로 나눈다. 회차 사이에 최소 하루를 둔다',
                '끝나면 앱에서 CSV 를 내려받는다'],
               '`rater_%s.csv` 파일 하나' % who, '훈련 1시간 + 판정 4~6시간',
               ['**다른 판정자와 결과를 공유하지 않는다.** 판정 중에는 연락하지 않는다',
                '한 기계에서 두 사람이 번갈아 하지 않는다',
                '**UNKNOWN 이 DIFFERENT 를 이긴다.** 정보가 없으면 억지로 고르지 않는다',
                '거리 축은 **이해축이 SAME 일 때만** 매긴다',
                '한 회차 약 1.5시간. 중간에 10분 쉰다'])

    # ── 4 c_operator ──
    role = 'c_operator'
    os.makedirs(os.path.join(PK, role))
    for s in (os.path.join(NEW, '04_C', 'POC_C_FINAL_PROTOCOL.md'),
              os.path.join(NEW, '04_C', 'personal_event_schema.json')):
        if not put(role, s):
            missing.append(s)
    readme(role, 'POC C 진행자',
           '참가자가 자기 사회적 사건을 **Personal Social Event 로 줄 수 있는지** 본다.\n\n'
           '사용성 시험이 아니다. C1 수집 가능성 · C2 추출 가능성 · C3 확인 안정성 셋을 잰다.',
           ['`POC_C_FINAL_PROTOCOL.md` 를 읽는다',
            '참가자에게 `c_participant` 꾸러미를 준다',
            '흐름을 따라 진행한다. **사건 내용을 판단하지 않는다**',
            '지표를 기록한다 · 소요시간 · 되묻기 횟수 · 정정 · UNKNOWN · 중도포기 · 거부',
            '**24~72시간 뒤 재확인** · relationship · difficult_turn · user_goal 셋만'],
           '참가자별 기록 CSV + 재확인 기록', '회당 1시간 · 참가자 5~10명',
           ['상대의 속마음을 **사실로 저장하지 않는다**. 인식 상태 다섯을 유지한다',
            '제3자 실명·연락처·학교명·회사명을 저장하지 않는다. **관계 유형만**',
            '`third_party_pii_removed` 가 false 면 저장하지 않는다',
            '만족도는 **주요 지표가 아니다**'])

    # ── 5 c_participant ──
    role = 'c_participant'
    os.makedirs(os.path.join(PK, role))
    for s in (os.path.join(RC1, 'dist', 'poc_c_participant', 'consent_draft.md'),
              os.path.join(RC1, 'dist', 'poc_c_participant', 'participant_instruction.md'),
              os.path.join(RC1, 'dist', 'poc_c_participant', 'intake_prototype.html')):
        if not put(role, s):
            missing.append(s)
    readme(role, 'POC C 참가자',
           '최근 겪은 **사회적 상황**을 적고, AI 가 정리한 것을 확인한다.',
           ['동의서를 읽고 동의한다',
            '겪은 일을 자유롭게 적는다. 칸을 채우는 것이 아니다',
            '**어디서 막혔는지**를 고른다',
            'AI 가 정리한 것을 보고 **틀린 것을 고친다**. 모르면 "모름" 을 고른다',
            '이틀 뒤 짧은 재확인에 답한다 (10분)'],
           '없음 · 진행자가 기록한다', '건당 20~40분 · 2~3건 + 재확인 10분',
           ['**적기 싫은 것은 적지 않아도 된다.** 언제든 그만둘 수 있다',
            '상대의 **실명·연락처·학교·회사**는 적지 않는다',
            '"모름" 은 정답이 아닌 것이 아니다. **모르는 것이 맞는 답일 때가 있다**'])

    # ── 6 performance_rater ──
    role = 'performance_rater'
    os.makedirs(os.path.join(PK, role))
    for s in (os.path.join(NEW, '05_PERFORMANCE', 'PERFORMANCE_PROTOCOL.md'),
              os.path.join(NEW, '05_PERFORMANCE', 'TARGET_SPECIFIC_RUBRIC.md')):
        if not put(role, s):
            missing.append(s)
    readme(role, '수행 평정자',
           '사용자 응답을 rubric 으로 채점한다. **먼저 두 평정자가 맞는지**부터 본다.',
           ['`TARGET_SPECIFIC_RUBRIC.md` 를 읽는다',
            '연습 응답 10개를 채점한다',
            '본 채점. **어느 시점의 응답인지 모른 채** 섞여서 온다',
            'CSV 로 제출한다'],
           '`performance_rater_X.csv`', '2~4시간',
           ['**시점을 추측하지 않는다.** 훈련 전후를 알면 그 기대가 점수에 들어간다',
            '다른 평정자와 상의하지 않는다',
            'A1 판정자가 겸하는 경우 **자기가 A1 에서 본 쌍에서 나온 응답은 채점하지 않는다**'])

    # ── 7 expert_review ──
    role = 'expert_review'
    os.makedirs(os.path.join(PK, role))
    for s in (os.path.join(RC1, 'dist', 'expert_review', 'expert_questions.md'),
              os.path.join(RC1, 'dist', 'expert_review', 'frozen_spec_summary.md'),
              os.path.join(RC1, 'dist', 'expert_review', 'review_response_template.csv'),
              os.path.join(NEW, '00_DECISION', 'FINAL_DECISIONS.md')):
        if not put(role, s):
            missing.append(s)
    readme(role, '전문가 검토',
           '규격과 **타겟 결정**을 바깥 시각으로 본다.',
           ['`FINAL_DECISIONS.md` 를 읽는다 · 타겟을 왜 넓혔는지',
            '`frozen_spec_summary.md` 를 읽는다',
            '`expert_questions.md` 에 답한다',
            '`review_response_template.csv` 로 제출한다'],
           '`review_response.csv`', '2~3시간',
           ['**조정자를 겸할 수 있다.** 서로 오염시키지 않는다',
            '동의하지 않는 자리를 적어 주는 것이 이 검토의 목적이다'])

    n = sum(len(os.listdir(os.path.join(PK, d))) for d in os.listdir(PK))
    print('꾸러미 %d개 · 파일 %d개' % (len(os.listdir(PK)), n))
    for d in sorted(os.listdir(PK)):
        print('  %-20s %d개' % (d, len(os.listdir(os.path.join(PK, d)))))
    if missing:
        print('  넣지 못한 원본 %d개' % len(missing))
        for m in missing:
            print('    없다 · %s' % os.path.relpath(m, ROOT))

    # 만든 직후 스스로 누출 검사. 검사 구현은 verify_pre_human.py 한 곳에만 있다
    sys.path.insert(0, NEW)
    import verify_pre_human as V
    r = V.Res()
    V.check_a1_packages(r)
    V.check_role_bundles(r)
    print('  누출 검사')
    bad = False
    for name, ok, msg, det in r.rows:
        print('    %-18s %-4s %s' % (name, 'ok' if ok else 'FAIL', msg))
        for d in det:
            print('          - %s' % d)
        bad = bad or not ok
    return 1 if (bad or missing) else 0


if __name__ == '__main__':
    sys.exit(main())
