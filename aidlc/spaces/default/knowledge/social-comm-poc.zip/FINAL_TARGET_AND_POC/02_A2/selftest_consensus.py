# -*- coding: utf-8 -*-
"""build_consensus.py 의 배선을 모의 판정자 둘로 확인한다.

    python selftest_consensus.py --out _dryrun

**이것은 사람 결과가 아니다.** 합성 입력이고 파일 이름에 DRYRUN 을 박는다.
합성 라벨로 나온 kappa 는 아무 뜻이 없다. 확인하는 것은 **배선**뿐이다.
  두 CSV 를 pair_id 로 맞추는가 · 갈린 칸을 gold 로 만들지 않는가 · 일치도 표를 내는가
"""
from __future__ import annotations

import argparse
import csv
import io
import os
import random
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
JUDGED = ('required_inference', 'perspective_structure',
          'decidable_by_evidence', 'direct_check_allowed')
AXIS = ('skill_identity_understand', 'skill_identity_perform', 'transfer_distance')
CTX = ('topic_changed', 'place_changed', 'participants_changed', 'relationship_changed',
       'situation_type_changed', 'misread_cost_changed', 'recoverability_changed')
LAB = ('SAME', 'DIFFERENT', 'UNKNOWN')


def find_pairs(out):
    for n in ('primary_60.csv', 'primary_40.csv'):
        p = os.path.join(out, n)
        if os.path.exists(p):
            return p
    return None


def main(argv):
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', default=os.path.join(HERE, '_dryrun'))
    a = ap.parse_args(argv)
    out = a.out if os.path.isabs(a.out) else os.path.join(HERE, a.out)
    if not os.path.isdir(out):
        os.makedirs(out)

    pairs_p = find_pairs(out)
    if pairs_p is None:
        print('선별 결과가 없다. select_primary.py 를 먼저 돌린다.')
        return 2
    pairs = list(csv.DictReader(io.open(pairs_p, encoding='utf-8', newline='')))

    cols = ['pair_id'] + list(JUDGED) + list(AXIS) + list(CTX)
    rng = random.Random(20260914)
    # 판정자 A 의 답을 먼저 정하고, B 는 그중 일부만 흔든다.
    # 그래야 "합의된 칸" 과 "갈린 칸" 이 둘 다 생겨 양쪽 경로를 지나간다
    truth = [{f: rng.choice(LAB) for f in JUDGED + AXIS + CTX} for _ in pairs]

    def write(path, flip):
        with io.open(path, 'w', encoding='utf-8', newline='') as fh:
            w = csv.DictWriter(fh, fieldnames=cols)
            w.writeheader()
            for p, t in zip(pairs, truth):
                row = {'pair_id': p['pair_id']}
                for f in JUDGED + AXIS + CTX:
                    row[f] = rng.choice(LAB) if rng.random() < flip else t[f]
                w.writerow(row)

    ra = os.path.join(out, 'rater_A_DRYRUN.csv')
    rb = os.path.join(out, 'rater_B_DRYRUN.csv')
    write(ra, 0.00)
    write(rb, 0.22)

    env = dict(os.environ, PYTHONIOENCODING='utf-8')
    p = subprocess.run([sys.executable, 'build_consensus.py',
                        '--rater-a', ra, '--rater-b', rb,
                        '--pairs', pairs_p, '--out', out],
                       cwd=HERE, capture_output=True, text=True,
                       encoding='utf-8', env=env)
    print((p.stdout or '').strip())
    if p.returncode != 0:
        print((p.stderr or '')[-400:])
        return p.returncode

    gold = os.path.join(out, 'a1_consensus_gold.csv')
    rows = list(csv.DictReader(io.open(gold, encoding='utf-8', newline='')))
    filled = sum(1 for r in rows for f in JUDGED if (r.get(f) or '').strip())
    dis = sum(1 for r in rows for f in JUDGED
              if (r.get(f + '__source') or '') == 'DISAGREE')
    bad = []
    if not rows:
        bad.append('gold 가 비었다')
    if filled == 0:
        bad.append('합의된 칸이 0 이다. 두 판정자가 하나도 안 맞았다')
    if dis == 0:
        bad.append('갈린 칸이 0 이다. DISAGREE 경로를 지나가지 않았다')
    # 갈린 칸이 gold 에 값으로 들어가면 안 된다
    leak = [r['pair_id'] for r in rows for f in JUDGED
            if (r.get(f + '__source') or '') == 'DISAGREE' and (r.get(f) or '').strip()]
    if leak:
        bad.append('갈린 칸에 값이 들어갔다 · %s' % leak[:3])
    print('  자기시험 · 쌍 %d · 합의 칸 %d · 갈린 칸 %d · 갈린 칸에 값 %d'
          % (len(rows), filled, dis, len(leak)))
    if bad:
        for x in bad:
            print('    FAIL · %s' % x)
        return 1
    print('  ok · 합의 경로와 불일치 경로를 둘 다 지나갔다')
    print('  **이 kappa 는 합성 라벨이라 뜻이 없다. 배선만 확인했다.**')
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
