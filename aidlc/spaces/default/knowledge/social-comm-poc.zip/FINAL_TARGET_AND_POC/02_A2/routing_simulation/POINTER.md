# 라우팅 곡선은 판정 결과에서 나온다

별도 스크립트를 두지 않는다. `../run_a2.py` 가 A2 를 돌리면서 같이 만든다.
구현은 `FINAL_CLOSURE/03_AUTOMATION/judge_harness/judge_harness.py` 의 `routing_curve` 와
`FINAL_CLOSURE/03_AUTOMATION/make_routing_report.py` 에 있다.

## 문턱을 미리 고르지 않는다

각 확신도 문턱에서 셋을 함께 낸다.

| | |
|---|---|
| automation coverage | 기계가 처리한 비율 |
| human review rate | 사람에게 넘긴 비율 |
| false confident rate | **확신했는데 틀린 비율** |

**곡선은 기계가 그리고 운영점은 사람이 찍는다.** A2 결과를 보고 팀이 정한다.

참조점 하나 · Jung 2024 는 0.90 일치 목표에서 자동화율 55.7% 였다.
**우리 값이 그보다 나쁠 수 있다.** 그것도 결과다.
