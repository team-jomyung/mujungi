# A1 판정자 일치도

판정자 둘의 CSV 를 합쳐 만든 것이다. **합의한 칸만 gold 가 된다.**
갈린 칸은 비워 두고 `a1_needs_adjudication.csv` 로 뺐다. 기계가 고르지 않는다.

| | |
|---|---|
| 쌍 | 60 |
| 판정자 A 파일 | `rater_A_DRYRUN.csv` |
| 판정자 B 파일 | `rater_B_DRYRUN.csv` |
| 조정 파일 | **없음** |
| 조정이 필요한 칸 | **602** |

## 필드별 일치도

| 필드 | κ | n | 관측일치 |
|---|---|---|---|
| `required_inference` | -0.100 | 60 | 0.267 |
| `perspective_structure` | -0.166 | 60 | 0.200 |
| `decidable_by_evidence` | -0.181 | 60 | 0.233 |
| `direct_check_allowed` | -0.119 | 60 | 0.250 |
| `skill_identity_understand` | -0.007 | 60 | 0.317 |
| `skill_identity_perform` | 0.003 | 60 | 0.333 |
| `transfer_distance` | 0.050 | 60 | 0.367 |
| `topic_changed` | -0.084 | 60 | 0.283 |
| `place_changed` | -0.009 | 60 | 0.317 |
| `participants_changed` | -0.090 | 60 | 0.267 |
| `relationship_changed` | -0.122 | 60 | 0.267 |
| `situation_type_changed` | -0.003 | 60 | 0.333 |
| `misread_cost_changed` | -0.074 | 60 | 0.283 |
| `recoverability_changed` | -0.128 | 60 | 0.250 |

**주 산출물은 문턱 통과가 아니라 점추정·CI·혼동행렬이다.**
κ 0.6 은 우리가 정한 운영 기준이고 외부 준거가 없다
(`FINAL_CLOSURE/01_EVIDENCE/EVIDENCE_LEDGER.csv`).

## 판정 필드 혼동행렬

### `required_inference`

| A \ B | SAME | DIFFERENT | UNKNOWN |
|---|---|---|---|
| **SAME** | 3 | 9 | 8 |
| **DIFFERENT** | 2 | 7 | 11 |
| **UNKNOWN** | 8 | 6 | 6 |

### `perspective_structure`

| A \ B | SAME | DIFFERENT | UNKNOWN |
|---|---|---|---|
| **SAME** | 5 | 6 | 4 |
| **DIFFERENT** | 11 | 5 | 5 |
| **UNKNOWN** | 11 | 11 | 2 |

### `decidable_by_evidence`

| A \ B | SAME | DIFFERENT | UNKNOWN |
|---|---|---|---|
| **SAME** | 2 | 8 | 7 |
| **DIFFERENT** | 8 | 10 | 8 |
| **UNKNOWN** | 6 | 9 | 2 |

### `direct_check_allowed`

| A \ B | SAME | DIFFERENT | UNKNOWN |
|---|---|---|---|
| **SAME** | 3 | 9 | 10 |
| **DIFFERENT** | 2 | 7 | 4 |
| **UNKNOWN** | 15 | 5 | 5 |

## 조정이 필요한 칸

| pair_id | 필드 | A | B |
|---|---|---|---|
| B01 | `transfer_distance` | UNKNOWN | DIFFERENT |
| B01 | `topic_changed` | DIFFERENT | UNKNOWN |
| B01 | `participants_changed` | UNKNOWN | SAME |
| B01 | `relationship_changed` | SAME | UNKNOWN |
| B01 | `misread_cost_changed` | UNKNOWN | DIFFERENT |
| B01 | `recoverability_changed` | DIFFERENT | SAME |
| B02 | `required_inference` | SAME | DIFFERENT |
| B02 | `perspective_structure` | DIFFERENT | SAME |
| B02 | `decidable_by_evidence` | UNKNOWN | SAME |
| B02 | `direct_check_allowed` | SAME | DIFFERENT |
| B02 | `transfer_distance` | DIFFERENT | SAME |
| B02 | `topic_changed` | SAME | DIFFERENT |
| B02 | `place_changed` | DIFFERENT | UNKNOWN |
| B02 | `participants_changed` | UNKNOWN | SAME |
| B02 | `situation_type_changed` | SAME | UNKNOWN |
| B02 | `misread_cost_changed` | UNKNOWN | DIFFERENT |
| B02 | `recoverability_changed` | DIFFERENT | SAME |
| B03 | `required_inference` | SAME | UNKNOWN |
| B03 | `perspective_structure` | UNKNOWN | DIFFERENT |
| B03 | `decidable_by_evidence` | DIFFERENT | UNKNOWN |
| B03 | `direct_check_allowed` | SAME | UNKNOWN |
| B03 | `skill_identity_perform` | SAME | DIFFERENT |
| B03 | `transfer_distance` | DIFFERENT | UNKNOWN |
| B03 | `topic_changed` | UNKNOWN | SAME |
| B03 | `place_changed` | DIFFERENT | SAME |
| B03 | `participants_changed` | UNKNOWN | DIFFERENT |
| B03 | `relationship_changed` | SAME | DIFFERENT |
| B03 | `situation_type_changed` | SAME | DIFFERENT |
| B04 | `required_inference` | DIFFERENT | UNKNOWN |
| B04 | `direct_check_allowed` | SAME | UNKNOWN |
| B04 | `skill_identity_understand` | SAME | UNKNOWN |
| B04 | `skill_identity_perform` | DIFFERENT | UNKNOWN |
| B04 | `transfer_distance` | SAME | UNKNOWN |
| B04 | `topic_changed` | UNKNOWN | SAME |
| B04 | `participants_changed` | UNKNOWN | DIFFERENT |
| B04 | `relationship_changed` | SAME | DIFFERENT |
| B04 | `situation_type_changed` | UNKNOWN | DIFFERENT |
| B04 | `recoverability_changed` | DIFFERENT | UNKNOWN |
| B06 | `required_inference` | DIFFERENT | UNKNOWN |
| B06 | `perspective_structure` | DIFFERENT | UNKNOWN |
| B06 | `decidable_by_evidence` | UNKNOWN | DIFFERENT |
| B06 | `skill_identity_understand` | DIFFERENT | SAME |
| B06 | `skill_identity_perform` | SAME | DIFFERENT |
| B06 | `transfer_distance` | UNKNOWN | DIFFERENT |
| B06 | `topic_changed` | SAME | DIFFERENT |
| B06 | `place_changed` | DIFFERENT | UNKNOWN |
| B06 | `participants_changed` | SAME | UNKNOWN |
| B06 | `relationship_changed` | DIFFERENT | UNKNOWN |
| B07 | `required_inference` | UNKNOWN | DIFFERENT |
| B07 | `perspective_structure` | UNKNOWN | DIFFERENT |
| B07 | `direct_check_allowed` | DIFFERENT | UNKNOWN |
| B07 | `skill_identity_understand` | SAME | DIFFERENT |
| B07 | `transfer_distance` | SAME | UNKNOWN |
| B07 | `topic_changed` | DIFFERENT | UNKNOWN |
| B07 | `misread_cost_changed` | UNKNOWN | SAME |
| B07 | `recoverability_changed` | UNKNOWN | SAME |
| B09 | `required_inference` | DIFFERENT | UNKNOWN |
| B09 | `perspective_structure` | SAME | DIFFERENT |
| B09 | `decidable_by_evidence` | UNKNOWN | DIFFERENT |
| B09 | `skill_identity_perform` | UNKNOWN | SAME |
| … | 542개 더 | | |

**조정하는 사람은 판정자 둘 중 하나가 아니어야 한다.**
조정 결과를 `pair_id,field,final` 로 적어 `--adjudication` 에 넣고 다시 돌린다.
