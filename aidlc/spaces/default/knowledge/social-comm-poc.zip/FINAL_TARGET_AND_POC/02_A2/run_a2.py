# -*- coding: utf-8 -*-
"""A1 결과만 넣으면 A2 를 끝까지 돌린다.

    python run_a2.py --gold a1_consensus_gold.csv                 Echo 더미로 배선 확인
    python run_a2.py --gold a1_consensus_gold.csv --provider http --model ...   실제 판정

파이프라인
    사람 합의 gold
      -> calibration / development / held-out 분할 (누출 검사 포함)
      -> Judge A · Judge B · 앙상블
      -> 순서 교환 (A-B / B-A)
      -> 말 바꾸기 · 문체 · 관계 섭동
      -> 확신도 · 판정단 내 일치
      -> 라우팅 시뮬레이션 (문턱을 미리 고르지 않는다)

내는 것
    정확도 · macro F1 · Cohen κ · 혼동행렬 · 적용범위 · 사람 재검토율 · 거짓 확신율
    필드별 · 기술별 · 관계별 성능
    required_inference · perspective_structure · decidable_by_evidence 는 따로 낸다

구현은 한 곳에만 둔다
    판정 하네스 본체는 `FINAL_CLOSURE/03_AUTOMATION/judge_harness/` 에 있다.
    **작업 트리에 사본을 두지 않는다.** 복사본은 반드시 따로 논다(ERR-04·05·06 이 그 계열).
    경로는 runtime_deps.py 가 푼다. 배포본 사본은 sha256 으로 정본과 대조된다.
    이 파일은 그것을 불러 쓰는 오케스트레이터다. 의존은 `verify_pre_human.py` 가 확인한다.

경고
    A1 이 끝나기 전에는 이 스크립트의 출력이 **검증 결과가 아니다.**
    gold 에 사람 합의가 없으면 결과 파일 머리에 DRY-RUN 을 박고 그렇게 부른다.
"""
from __future__ import annotations

import argparse
import csv
import io
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))   # runtime_deps.py 를 찾으려고
JUDGED = ('required_inference', 'perspective_structure',
          'decidable_by_evidence', 'direct_check_allowed')
LABELS = ('SAME', 'DIFFERENT', 'UNKNOWN')


def load_harness():
    """판정 하네스를 찾는다. 경로를 손으로 적지 않는다.

    배포본을 풀었으면 runtime/ 에서, 저장소에서 돌리면 FINAL_CLOSURE 에서 온다.
    둘 다 없으면 조용히 넘어가지 않고 멈춘다.
    """
    import runtime_deps as RD
    missing = RD.add_paths(['judge_harness'])
    if missing:
        ok, lines = RD.check()
        raise SystemExit('판정 하네스를 못 찾았다.' + chr(10) + '  '
                         + (chr(10) + '  ').join(lines)
                         + chr(10) * 2
                         + '  배포본이면 runtime/ 가 있어야 하고,' + chr(10)
                         + '  저장소면 FINAL_CLOSURE 가 옆에 있어야 한다.')
    import judge_harness as JH
    import gold_split as GS
    return JH, GS


def read(path):
    with io.open(path, encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))


def consensus_stats(rows):
    """gold 가 사람 합의에서 왔는지, 몇 칸이 비어 있는지 본다."""
    total = filled = adjud = disagree = 0
    for r in rows:
        for f in JUDGED:
            total += 1
            src = (r.get(f + '__source') or '').strip().upper()
            if (r.get(f) or '').strip().upper() in LABELS:
                filled += 1
                if src == 'ADJUDICATED':
                    adjud += 1
            elif src == 'DISAGREE':
                disagree += 1
    has_source = any((r.get(f + '__source') or '') for r in rows for f in JUDGED)
    return {'cells': total, 'filled': filled, 'adjudicated': adjud,
            'disagree_unresolved': disagree, 'has_source_column': has_source}


def confusion(pairs, cats):
    m = {a: {b: 0 for b in cats} for a in cats}
    for a, b in pairs:
        if a in m and b in m[a]:
            m[a][b] += 1
    return m


def by_group(recs, keyfn):
    g = {}
    for r in recs:
        g.setdefault(keyfn(r), []).append(r)
    return g


def main(argv):
    ap = argparse.ArgumentParser()
    ap.add_argument('--gold', required=True)
    ap.add_argument('--provider', default='echo', choices=('echo', 'http'))
    ap.add_argument('--model-a', default='echo-A')
    ap.add_argument('--model-b', default='echo-B')
    ap.add_argument('--seed', type=int, default=20260914)
    ap.add_argument('--out', default=os.path.join(HERE, 'results'))
    ap.add_argument('--splits', type=int, default=10, help='반복 홀드아웃 횟수')
    a = ap.parse_args(argv)

    if not os.path.exists(a.gold):
        print('없다 · %s' % a.gold)
        return 2
    if not os.path.isdir(a.out):
        os.makedirs(a.out)

    JH, GS = load_harness()
    rows = read(a.gold)
    cs = consensus_stats(rows)

    # gold 가 사람 합의인가. 아니면 결과를 검증 결과라고 부르지 않는다
    real = cs['has_source_column'] and cs['filled'] > 0 and cs['disagree_unresolved'] == 0
    mode = 'VALIDATION' if real else 'DRY-RUN'
    if not real:
        why = []
        if not cs['has_source_column']:
            why.append('gold 에 __source 열이 없다 (build_consensus.py 가 만든 것이 아니다)')
        if cs['filled'] == 0:
            why.append('채워진 판정 칸이 0 이다')
        if cs['disagree_unresolved']:
            why.append('조정 안 된 불일치 %d칸' % cs['disagree_unresolved'])

    items = JH.load_gold(a.gold)
    usable = [it for it in items if it['gold']]
    if not usable:
        print('gold 에 판정 라벨이 하나도 없다. build_consensus.py 를 먼저 돌린다.')
        return 2

    # --- 분할 · 누출 검사는 gold_split 안에 있다 (_assert_disjoint) ---
    splits = GS.repeated_holdout(usable, k=a.splits, seed=a.seed)
    s0 = splits[0]
    GS.write_manifest(os.path.join(a.out, 'split_manifest.json'), s0, a.seed,
                      'required_inference', gold_path=a.gold)

    # 같은 예제가 calibration 과 held_out 에 동시에 있으면 안 된다. 한 번 더 직접 본다
    # split_once 는 pair_id 목록을 돌려준다. 항목 객체가 아니다
    leak = []
    for sp in splits:
        cal, dev, ho = set(sp['calibration']), set(sp['development']), set(sp['held_out'])
        for n1, s1, n2, s2 in (('calibration', cal, 'held_out', ho),
                               ('calibration', cal, 'development', dev),
                               ('development', dev, 'held_out', ho)):
            if s1 & s2:
                leak.append('%s ∩ %s = %s' % (n1, n2, sorted(s1 & s2)[:5]))
    if leak:
        print('분할 누출 · %s' % leak[:3])
        return 2

    # --- 판정단 ---
    if a.provider == 'echo':
        pa = JH.EchoProvider(a.model_a)
        pb = JH.EchoProvider(a.model_b)
    else:
        pa = JH.HTTPProvider(a.model_a)
        pb = JH.HTTPProvider(a.model_b)
    rubric = getattr(JH, 'RUBRIC', None) or ''

    held = GS.select(usable, s0['held_out'])
    recs = JH.run_panel(held, [pa, pb], rubric, both_orders=True)
    an = JH.analyze(recs)

    # --- 필드별 · 관계별 성능 ---
    rel_of = {}
    for r in rows:
        rel_of[(r.get('pair_id') or '').strip()] = (r.get('relationship_changed') or 'UNKNOWN').strip().upper()
    skill_of = {}
    for r in rows:
        skill_of[(r.get('pair_id') or '').strip()] = (r.get('target_skill') or 'UNSPECIFIED').strip()

    def slice_metrics(sub):
        """기권과 오답을 나눈다.

        판정단 둘이 갈리면 panel_label 이 UNDETERMINED 다. 그것은 **틀린 답이 아니라 기권**이고
        사람에게 넘길 자리다. 기권을 오답으로 세면 잘 보정된 판정기가 쓸모없어 보이고,
        갈려도 우기는 판정기가 점수를 더 받는다. 그래서 셋을 따로 낸다.
          coverage        판정단이 답을 낸 비율
          accuracy_covered 답을 낸 것 중 맞은 비율
          accuracy_all     기권을 오답으로 셀 때. 참고로만 둔다
        """
        out = {}
        for fld in JUDGED:
            rows_ = [x for x in sub if x.get('field') == fld and x.get('gold')]
            if not rows_:
                continue
            n = len(rows_)
            covered = [(x['gold'], x['panel_label']) for x in rows_
                       if x.get('panel_label') in LABELS]
            abstain = n - len(covered)
            acc_cov = (sum(1 for g, p in covered if g == p) / float(len(covered))
                       if covered else None)
            acc_all = sum(1 for x in rows_
                          if x.get('panel_label') == x['gold']) / float(n)
            k = JH.kappa(covered) if covered and callable(getattr(JH, 'kappa', None)) else None
            f1 = (round(JH.macro_f1(covered), 4)
                  if covered and hasattr(JH, 'macro_f1') else None)
            out[fld] = {
                'n': n,
                'coverage': round(len(covered) / float(n), 4),
                'abstained': abstain,
                'accuracy_covered': None if acc_cov is None else round(acc_cov, 4),
                'accuracy_all_abstain_as_error': round(acc_all, 4),
                'kappa_covered': None if k is None else round(k, 4),
                'macro_f1_covered': f1,
                'confusion_covered': confusion(covered, list(LABELS)),
            }
        return out

    per_field = slice_metrics(recs)
    per_rel = {k: slice_metrics(v) for k, v in
               by_group(recs, lambda r: rel_of.get(r.get('pair_id'), 'UNKNOWN')).items()}
    per_skill = {k: slice_metrics(v) for k, v in
                 by_group(recs, lambda r: skill_of.get(r.get('pair_id'), 'UNSPECIFIED')).items()}

    out = {
        'mode': mode,
        'WARNING': None if real else 'NOT A VALIDATION RESULT · ' + ' · '.join(why),
        'gold_file': os.path.basename(a.gold),
        'consensus': cs,
        'provider': a.provider, 'model_a': a.model_a, 'model_b': a.model_b,
        'seed': a.seed, 'splits': a.splits,
        'split_sizes': {k: len(v) for k, v in s0.items()},
        'leakage_checked': True, 'leakage_found': 0,
        'panel': an,
        'per_field': per_field,
        'per_relationship': per_rel,
        'per_skill': per_skill,
    }
    p = os.path.join(a.out, 'a2_results.json')
    io.open(p, 'w', encoding='utf-8', newline='\n').write(
        json.dumps(out, ensure_ascii=False, indent=2, default=str) + '\n')

    print('[%s] 쌍 %d · 라벨 있는 쌍 %d · held-out %d · 판정 기록 %d'
          % (mode, len(items), len(usable), len(held), len(recs)))
    print('  분할 · ' + ' · '.join('%s %d' % (k, len(v)) for k, v in s0.items())
          + ' · 누출 0')
    if not real:
        print('  ** 검증 결과가 아니다 · ' + ' · '.join(why))
    for fld, m in sorted(per_field.items()):
        print('  %-24s n %3d · 적용범위 %.3f (기권 %d) · 답한 것 중 정확도 %s · macro F1 %s'
              % (fld, m['n'], m['coverage'], m['abstained'],
                 '—' if m['accuracy_covered'] is None else '%.3f' % m['accuracy_covered'],
                 '—' if m['macro_f1_covered'] is None else '%.3f' % m['macro_f1_covered']))
    print('  저장 · %s' % p)
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
