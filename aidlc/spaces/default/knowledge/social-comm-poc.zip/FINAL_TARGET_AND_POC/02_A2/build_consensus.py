# -*- coding: utf-8 -*-
"""판정자 둘의 CSV 를 합쳐 A2 의 gold 를 만든다. 일치도도 같이 낸다.

    python build_consensus.py --rater-a rater_A.csv --rater-b rater_B.csv
    python build_consensus.py --rater-a a.csv --rater-b b.csv --adjudication adj.csv

무엇을 하나
  1 두 CSV 를 pair_id 로 맞춘다. 한쪽에만 있는 쌍이 있으면 멈춘다
  2 필드별 일치·불일치를 센다 (Cohen kappa · 혼동행렬)
  3 합의한 칸은 그대로 gold 가 된다
  4 **갈린 칸은 gold 가 되지 않는다.** 조정(adjudication) 파일이 있으면 그것을 쓰고,
    없으면 그 칸을 비워 두고 `NEEDS_ADJUDICATION` 목록으로 내보낸다

왜 갈린 칸을 자동으로 안 채우나
  다수결도 평균도 쓸 수 없다. 판정자가 둘뿐이라 다수가 없고, 범주형이라 평균이 없다.
  기계가 고르면 그 gold 는 **사람 합의가 아니라 우리 규칙**이 된다. A2 는 사람 합의를 재현하는지 보는 것이므로
  그렇게 만든 gold 로 A2 를 하면 자기 규칙을 자기가 재현하는지 보는 것이 된다.

출력
  a1_consensus_gold.csv       합의된 칸만 채운 gold
  a1_agreement_report.md      필드별 kappa · 혼동행렬 · 불일치 목록
  a1_needs_adjudication.csv   사람이 조정해야 할 칸
"""
from __future__ import annotations

import argparse
import csv
import io
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
LABELS = ('SAME', 'DIFFERENT', 'UNKNOWN')

# 판정으로 재는 필드. 관계에서 규칙으로 파생시키던 direct_check_allowed 를 판정 필드로 옮겼다
# (FINAL_CLOSURE/02_SCOPE/RELATIONSHIP_SCOPE.md · 규범적 이분법이라 규칙이 될 수 없었다)
JUDGED_FIELDS = ('required_inference', 'perspective_structure',
                 'decidable_by_evidence', 'direct_check_allowed')
AXIS_FIELDS = ('skill_identity_understand', 'skill_identity_perform', 'transfer_distance')
CONTEXT_FIELDS = ('topic_changed', 'place_changed', 'participants_changed',
                  'relationship_changed', 'situation_type_changed',
                  'misread_cost_changed', 'recoverability_changed')


def read(path):
    with io.open(path, encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))


def norm(v):
    return (v or '').strip().upper()


def kappa(pairs):
    """비가중 Cohen kappa. 범주가 셋인 명목형이라 가중하지 않는다."""
    pairs = [(a, b) for a, b in pairs if a and b]
    n = len(pairs)
    if n == 0:
        return None, 0
    cats = sorted({a for a, _ in pairs} | {b for _, b in pairs})
    po = sum(1 for a, b in pairs if a == b) / float(n)
    ra = {c: sum(1 for a, _ in pairs if a == c) / float(n) for c in cats}
    rb = {c: sum(1 for _, b in pairs if b == c) / float(n) for c in cats}
    pe = sum(ra[c] * rb[c] for c in cats)
    if abs(1 - pe) < 1e-12:
        return None, n
    return (po - pe) / (1 - pe), n


def confusion(pairs, cats):
    m = {a: {b: 0 for b in cats} for a in cats}
    for a, b in pairs:
        if a in m and b in m[a]:
            m[a][b] += 1
    return m


def main(argv):
    ap = argparse.ArgumentParser()
    ap.add_argument('--rater-a', required=True)
    ap.add_argument('--rater-b', required=True)
    ap.add_argument('--adjudication', default=None)
    ap.add_argument('--pairs', default=None,
                    help='pair_id,event_A,event_B · gold 에 본문을 붙이려면')
    ap.add_argument('--out', default=HERE)
    a = ap.parse_args(argv)

    for p in (a.rater_a, a.rater_b):
        if not os.path.exists(p):
            print('없다 · %s' % p)
            return 2
    A, B = read(a.rater_a), read(a.rater_b)
    ia = {norm(r.get('pair_id')): r for r in A if norm(r.get('pair_id'))}
    ib = {norm(r.get('pair_id')): r for r in B if norm(r.get('pair_id'))}
    only_a, only_b = sorted(set(ia) - set(ib)), sorted(set(ib) - set(ia))
    if only_a or only_b:
        print('두 판정자의 쌍이 다르다 · A만 %d %s · B만 %d %s'
              % (len(only_a), only_a[:5], len(only_b), only_b[:5]))
        print('같은 쌍을 봐야 일치도를 잴 수 있다. 빠진 쌍을 채운 뒤 다시 돌린다.')
        return 2
    ids = sorted(ia)
    if not ids:
        print('쌍이 하나도 없다')
        return 2

    # 조정 결과 (있으면)
    adj = {}
    if a.adjudication and os.path.exists(a.adjudication):
        for r in read(a.adjudication):
            pid = norm(r.get('pair_id'))
            fld = (r.get('field') or '').strip()
            val = norm(r.get('final'))
            if pid and fld:
                adj[(pid, fld)] = val

    bodies = {}
    if a.pairs and os.path.exists(a.pairs):
        for r in read(a.pairs):
            bodies[norm(r.get('pair_id'))] = (r.get('event_A', ''), r.get('event_B', ''))

    all_fields = list(JUDGED_FIELDS) + list(AXIS_FIELDS) + list(CONTEXT_FIELDS)
    stats, need = {}, []
    gold_rows = []
    for pid in ids:
        ra, rb = ia[pid], ib[pid]
        row = {'pair_id': pid}
        if pid in bodies:
            row['event_A'], row['event_B'] = bodies[pid]
        for fld in all_fields:
            va, vb = norm(ra.get(fld)), norm(rb.get(fld))
            stats.setdefault(fld, []).append((va, vb))
            if va and va == vb:
                row[fld] = va
                row[fld + '__source'] = 'CONSENSUS'
            elif (pid, fld) in adj and adj[(pid, fld)]:
                row[fld] = adj[(pid, fld)]
                row[fld + '__source'] = 'ADJUDICATED'
            else:
                row[fld] = ''
                row[fld + '__source'] = 'DISAGREE' if (va and vb) else 'MISSING'
                if va and vb:
                    need.append({'pair_id': pid, 'field': fld, 'rater_a': va,
                                 'rater_b': vb, 'final': ''})
        gold_rows.append(row)

    cols = ['pair_id']
    if bodies:
        cols += ['event_A', 'event_B']
    for f in all_fields:
        cols += [f, f + '__source']
    gp = os.path.join(a.out, 'a1_consensus_gold.csv')
    with io.open(gp, 'w', encoding='utf-8', newline='') as fh:
        w = csv.DictWriter(fh, fieldnames=cols)
        w.writeheader()
        w.writerows([{k: r.get(k, '') for k in cols} for r in gold_rows])

    np_ = os.path.join(a.out, 'a1_needs_adjudication.csv')
    with io.open(np_, 'w', encoding='utf-8', newline='') as fh:
        w = csv.DictWriter(fh, fieldnames=['pair_id', 'field', 'rater_a', 'rater_b', 'final'])
        w.writeheader(); w.writerows(need)

    L = ['# A1 판정자 일치도', '',
         '판정자 둘의 CSV 를 합쳐 만든 것이다. **합의한 칸만 gold 가 된다.**',
         '갈린 칸은 비워 두고 `a1_needs_adjudication.csv` 로 뺐다. 기계가 고르지 않는다.', '',
         '| | |', '|---|---|',
         '| 쌍 | %d |' % len(ids),
         '| 판정자 A 파일 | `%s` |' % os.path.basename(a.rater_a),
         '| 판정자 B 파일 | `%s` |' % os.path.basename(a.rater_b),
         '| 조정 파일 | %s |' % ('`%s`' % os.path.basename(a.adjudication) if adj else '**없음**'),
         '| 조정이 필요한 칸 | **%d** |' % len(need), '',
         '## 필드별 일치도', '',
         '| 필드 | κ | n | 관측일치 |', '|---|---|---|---|']
    for fld in all_fields:
        pr = [(x, y) for x, y in stats.get(fld, []) if x and y]
        k, n = kappa(pr)
        po = (sum(1 for x, y in pr if x == y) / float(len(pr))) if pr else None
        L.append('| `%s` | %s | %d | %s |'
                 % (fld, '—' if k is None else '%.3f' % k, n,
                    '—' if po is None else '%.3f' % po))
    L += ['', '**주 산출물은 문턱 통과가 아니라 점추정·CI·혼동행렬이다.**',
          'κ 0.6 은 우리가 정한 운영 기준이고 외부 준거가 없다',
          '(`FINAL_CLOSURE/01_EVIDENCE/EVIDENCE_LEDGER.csv`).', '',
          '## 판정 필드 혼동행렬', '']
    for fld in JUDGED_FIELDS:
        pr = [(x, y) for x, y in stats.get(fld, []) if x and y]
        if not pr:
            continue
        cats = [c for c in LABELS if any(c in (x, y) for x, y in pr)]
        m = confusion(pr, cats)
        L += ['### `%s`' % fld, '',
              '| A \\ B | ' + ' | '.join(cats) + ' |', '|---' * (len(cats) + 1) + '|']
        for x in cats:
            L.append('| **%s** | ' % x + ' | '.join(str(m[x][y]) for y in cats) + ' |')
        L.append('')
    if need:
        L += ['## 조정이 필요한 칸', '', '| pair_id | 필드 | A | B |', '|---|---|---|---|']
        for r in need[:60]:
            L.append('| %s | `%s` | %s | %s |' % (r['pair_id'], r['field'], r['rater_a'], r['rater_b']))
        if len(need) > 60:
            L.append('| … | %d개 더 | | |' % (len(need) - 60))
        L += ['', '**조정하는 사람은 판정자 둘 중 하나가 아니어야 한다.**',
              '조정 결과를 `pair_id,field,final` 로 적어 `--adjudication` 에 넣고 다시 돌린다.', '']
    io.open(os.path.join(a.out, 'a1_agreement_report.md'), 'w',
            encoding='utf-8', newline='\n').write('\n'.join(L))

    filled = sum(1 for r in gold_rows for f in JUDGED_FIELDS if r.get(f))
    print('쌍 %d · 판정 필드 칸 %d 중 채워진 것 %d · 조정 필요 %d'
          % (len(ids), len(ids) * len(JUDGED_FIELDS), filled, len(need)))
    for fld in JUDGED_FIELDS:
        k, n = kappa([(x, y) for x, y in stats.get(fld, []) if x and y])
        print('  %-24s κ %s · n %d' % (fld, '—' if k is None else '%.3f' % k, n))
    if need:
        print('  조정 전에는 gold 가 완성되지 않는다. a1_needs_adjudication.csv 를 사람에게 넘긴다.')
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
