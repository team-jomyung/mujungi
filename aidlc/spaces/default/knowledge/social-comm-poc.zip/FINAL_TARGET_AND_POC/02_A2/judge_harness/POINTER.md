# 여기에 코드를 두지 않는다

판정 하네스 본체는 여기 있다.

```
FINAL_CLOSURE/03_AUTOMATION/judge_harness/
  judge_harness.py    판정단 · 순서 교환 · 지표 · 라우팅 곡선 · 편향
  gold_split.py       calibration / development / held_out 분할 · 누출 단언
  a2_breakdowns.py    필드별 · 관계별 쪼개기
  bias_tests/         섭동 시험
```

## 왜 복사하지 않나

**복사본은 반드시 따로 논다.** 이 저장소에서 그 계열로 세 번 터졌다.

| | 무엇 |
|---|---|
| ERR-04 | 표본 수를 올렸는데 그 수를 만들어 내는 의뢰문이 옛 값으로 남았다 |
| ERR-05 | 그 수정이 네 파일에만 들어갔다. 옛 숫자 48곳 |
| ERR-06 | 스크립트가 바뀌었는데 그 출력을 인용한 문서가 안 따라왔다 |

같은 코드를 두 곳에 두면 한 곳만 고치게 된다. 그래서 **한 곳에만 둔다.**

## 여기서 쓰는 법

`../run_a2.py` 가 경로로 불러 쓴다.

```python
HARNESS_DIR = FINAL_CLOSURE/03_AUTOMATION/judge_harness
sys.path.insert(0, HARNESS_DIR)
import judge_harness as JH
```

의존이 살아 있는지는 `verify_pre_human.py` 가 확인한다.
FINAL_CLOSURE 가 같은 부모 폴더에 없으면 `run_a2.py` 가 멈추고 그 사실을 말한다.
