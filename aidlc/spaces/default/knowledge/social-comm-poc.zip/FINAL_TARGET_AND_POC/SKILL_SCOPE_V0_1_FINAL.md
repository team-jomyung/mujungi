# Skill Scope v0.1 · 최종

2026-09-14 · **D-05 를 닫는다.** HUMAN BLOCKER 로 남기지 않는다.

대상 · **TECHNICAL_POC_TARGET · 18~25 비임상 자기선택**

이 문서와 `03_B/skill_scope_v0_1.json` 은 `00_DECISION/build_skill_scope.py` 가 만든다.
**손으로 고치지 않는다.** 고치면 `verify_pre_human.py` 가 잡는다.

---

## 0 · 결론

| 판정 | 수 | 무엇 |
|---|---|---|
| **CORE** | 3 | S1 · S2 · S3 |
| **CONDITIONAL** | 3 | S4 · S5 · S6 |
| SEED_ONLY | 2 | S7 · S8 |
| **EXCLUDE** | 2 | S9 · S10 |

**채점하는 기술은 CORE 3 + CONDITIONAL 3 = 6 개다.**
생성에는 SEED_ONLY 까지 8 개를 쓴다.

---

## 1 · 판정 규칙 · 한 번 적고 모두에 똑같이 적용한다

```
CORE         구인 근거 있음 AND 비임상 변이 근거 있음
             AND 텍스트로 관찰 가능 AND 생성 가능 AND 채점 가능
CONDITIONAL  위 중 하나가 비었으나 조건을 달면 훈련할 수 있다
SEED_ONLY    구인은 있으나 이 과제 형태의 근거가 없다. 씨앗으로만
EXCLUDE      텍스트로 볼 수 없다. 음성 · 영상이 있어야 한다
```

### 앞 판과 무엇이 다른가

| | 앞 (임상 타겟) | 지금 (비임상 타겟) |
|---|---|---|
| CORE 요건 | A-EMP · **임상 표본의 행동 결과** | 구인 근거 + **비임상 변이 근거** |
| 매체 | 명시 안 함 | **텍스트로 볼 수 없으면 EXCLUDE** |
| 음성 · 영상 | FUTURE_AUDIO 로 미룸 | **EXCLUDE 로 뺀다** |

마지막 줄이 중요하다. 미뤄 두면 **범위에 있는 것처럼 읽힌다.**
제품이 텍스트인 이상 빼는 것이 정직하다. 필요해지면 그때 다시 넣는다.

---

## 2 · 판정표

| # | 기술 | 구인 | 비임상 | 한국어 | 텍스트 | 생성 | 채점 | 자동화 | **판정** |
|---|---|---|---|---|---|---|---|---|---|
| S1 | 청자 맞춤 정보 조절 (상대 지식 · 정보량) | STRONG | MODERATE | PARTIAL | YES | YES | YES | YES | **CORE** |
| S2 | 관계 · 상황 맞춤 조정 | STRONG | STRONG | YES | YES | YES | YES | CONDITIONAL | **CORE** |
| S3 | 대화 속 함축 · 비문자 의미 이해 | STRONG | MODERATE | YES | YES | YES | YES | YES | **CORE** |
| S4 | 응답성 · 상호성 | MODERATE | WEAK | PARTIAL | CONDITIONAL | YES | CONDITIONAL | YES | **CONDITIONAL** |
| S5 | 수리 · 명료화 (오해받았을 때 되돌리기) | MODERATE | MODERATE | PARTIAL | CONDITIONAL | YES | YES | YES | **CONDITIONAL** |
| S6 | 내가 모를 때 묻기 (명료화 요청) | WEAK | MODERATE | PARTIAL | YES | YES | YES | YES | **CONDITIONAL** |
| S7 | 화제 운용 (화제 전환 · 유지) | WEAK | WEAK | PARTIAL | CONDITIONAL | CONDITIONAL | WEAK | YES | **SEED_ONLY** |
| S8 | 반어 · 비꼼 · 간접 거절 (그 자체를 과제로) | WEAK | MODERATE | YES | YES | YES | CONDITIONAL | YES | **SEED_ONLY** |
| S9 | 운율 · 준언어 (말투 · 억양 · 쉼) | MODERATE | MODERATE | PARTIAL | **NO** | NO | NO | NO | **EXCLUDE** |
| S10 | 비언어 (시선 · 거리 · 표정) | STRONG | STRONG | NONE | **NO** | NO | NO | NO | **EXCLUDE** |

자세한 근거는 `00_DECISION/SKILL_SCOPE_V0_1_FINAL.csv` 의 `rationale` 열.

---

## 3 · 조건이 붙은 기술

| # | 기술 | 조건 |
|---|---|---|
| S4 | 응답성 · 상호성 | 사건에 **상대 턴이 둘 이상** 있을 때만 판정한다. 없으면 N/A 로 둔다 |
| S5 | 수리 · 명료화 (오해받았을 때 되돌리기) | 사건에 **오해 턴 + 되돌릴 기회**가 둘 다 있을 때만 |
| S6 | 내가 모를 때 묻기 (명료화 요청) | **인접 근거라는 표시를 붙여** 보고한다. 진단 기준에 없다 |
| S7 | 화제 운용 (화제 전환 · 유지) | 씨앗 생성에만 쓴다. **판정도 채점도 하지 않는다** |
| S8 | 반어 · 비꼼 · 간접 거절 (그 자체를 과제로) | S3(함축 이해)의 **씨앗 소재로만** 쓴다. 독립 기술로 채점하지 않는다 |

**CONDITIONAL 은 "훈련은 하되 근거 기반이라고 부르지 않는다" 는 뜻이다.**
조건이 충족되지 않은 사건에서는 **N/A 로 두고 점수를 만들지 않는다.**

---

## 4 · 뺀 것

| # | 기술 | 왜 |
|---|---|---|
| S9 | 운율 · 준언어 (말투 · 억양 · 쉼) | 앞 판은 FUTURE_AUDIO 로 미뤘다. **텍스트 제품인 이상 미루는 것이 아니라 빼는 것이 맞다.** 미뤄 두면 범위에 있는 것처럼 읽힌다 |
| S10 | 비언어 (시선 · 거리 · 표정) | 진단 기준의 큰 축이지만 우리 매체로 볼 수 없다. **범위 밖이라고 명확히 적는다** |

**비언어(S10)는 진단 기준의 큰 축이다.** 그런데 우리 매체로 볼 수 없다.
"우리가 사회적 의사소통을 다룬다" 고 말할 때 **이 축이 빠져 있다는 것을 함께 적는다.**

---

## 5 · 이 판정이 바꾸는 것

| 어디 | 무엇 |
|---|---|
| `05_PERFORMANCE/TARGET_SPECIFIC_RUBRIC.md` | 채점 기술을 CORE 3 + CONDITIONAL 3 로 확정 · 앵커를 그 기술에만 쓴다 |
| `03_B` POC B prompts | 생성 기술을 8 개로 · EXCLUDE 는 씨앗에서도 뺀다 |
| `03_B/skill_scope_v0_1.json` | 기계가 읽는 정본. 이 스크립트가 만든다 |

---

## 6 · 이 판정이 약속하지 않는 것

- CORE 기술이 **임상적으로 타당하다**는 것. 구인 근거는 임상 문헌에서 왔지만 대상은 비임상이다
- 비임상 변이 근거가 **강하다**는 것. 대부분 MODERATE 이고 일부는 못 찾았다
- 이 일곱 기준이 **완전하다**는 것. 다른 기준을 넣으면 순위가 바뀔 수 있다
- 뺀 기술이 **중요하지 않다**는 것. 볼 수 없을 뿐이다
