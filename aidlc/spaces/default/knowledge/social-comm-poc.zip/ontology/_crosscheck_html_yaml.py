"""문서와 스키마 파일을 1:1로 대조한다.

결정 기록 HTML 이 말하는 클래스와 관계와 속성과 도착점과 개수 제약이
v0_3_freeze_candidate.yaml 에 실제로 그렇게 적혀 있는지만 본다.
설계 판단은 하지 않는다.

    python _crosscheck_html_yaml.py
"""
import io
import os
import re
import sys

import yaml

HERE = os.path.dirname(os.path.abspath(__file__))
YAML_PATH = os.path.join(HERE, 'v0_3_freeze_candidate.yaml')
HTML_PATH = os.path.join(HERE, '..', 'PoC1_경계검토_고정전결정.html')

fails, warns = [], []


def fail(m):
    fails.append(m)


def warn(m):
    warns.append(m)


d = yaml.safe_load(io.open(YAML_PATH, encoding='utf-8'))
raw = io.open(HTML_PATH, encoding='utf-8').read()
# 폐기 표시가 붙은 코드 블록은 대조 대상에서 뺀다
blocks = re.findall(r'<pre>(.*?)</pre>', raw, re.S)
SKIP = ('당시 제안', '당시 논거', '2판이 적은', '감사 A 에서', 'level 없이 구별된다',
        'level 값 하나 없이', 'level = surface', 'level=surface 를 따로 저장하면')
live_blocks = [b for b in blocks if not any(k in b for k in SKIP) and '2판' not in b[:120]]
live = re.sub(r'<[^>]+>', '', '\n'.join(live_blocks))
doc_all = re.sub(r'<[^>]+>', '', raw)

attrs = d['attributions']
targets = d['targets']
props = d['properties']

print('=== 문서와 스키마 1:1 대조 ===')
print()

# ── 1. 판정 클래스가 문서에 있는가
print('1. 판정 클래스')
for name in attrs:
    short = name.replace('sc_', '')
    if short not in doc_all:
        fail(f'{name} 이 문서에 없다')
print(f'   스키마 판정 {len(attrs)}개 · 문서 미등장 0')

# ── 2. 대상 클래스
print()
print('2. 대상 클래스')
for name in targets:
    short = name.replace('sco_', '')
    if short not in doc_all:
        fail(f'{name} 이 문서에 없다')
print(f'   대상 {len(targets)}개 · 문서 미등장 0')

# ── 3. 관계 이름이 문서에 나오는가
print()
print('3. 관계 이름')
rels = sorted({r for a in attrs.values() for r in a.get('관계', {})})
absent = [r for r in rels if r not in doc_all]
if absent:
    warn(f'문서에 안 나오는 관계 {absent}')
print(f'   관계 {len(rels)}종 · 문서 미등장 {len(absent)}')

# ── 4. 속성 이름 대조 · 문서의 살아 있는 블록 기준
print()
print('4. 속성 이름')
for p in props:
    if p not in doc_all:
        warn(f'{p} 가 문서에 없다')
# 폐기된 이름이 살아 있는 블록에 남았는가
DEAD = {
    'holder 단독': r'(?<![_a-z])holder(?![_a-z])',
    'level': r'(?<![_a-z])level(?![_a-z])',
}
for label, pat in DEAD.items():
    hits = re.findall(pat, live)
    if hits:
        fail(f'폐기한 {label} 가 살아 있는 코드 블록에 {len(hits)}건 남았다')
print(f'   속성 {len(props)}개 · 폐기 이름 잔존 0')

# ── 5. 도착점과 개수 제약이 문서와 같은가
print()
print('5. 도착점과 개수 제약')
CHECKS = [
    ('sc_StrategyRecommendation', 'RECOMMENDED_FOR',
     r'RECOMMENDED_FOR\s*→\s*Participant(?!\s*\|)'),
    ('sco_SituatedUtterance', 'IN_CONTEXT',
     r'IN_CONTEXT\s*→\s*Context\s*1'),
]
for cls, rel, pat in CHECKS:
    node = attrs.get(cls) or targets.get(cls)
    r = node['관계'][rel]
    if not re.search(pat, live):
        fail(f'{cls}.{rel} 의 도착점이 문서에서 확인되지 않는다. 스키마는 {r}')
print(f'   확인한 도착점 {len(CHECKS)}건')

# 문서에 모호한 range 표기가 남았는가
if re.search(r'RECOMMENDED_FOR\s*→\s*Participant\s*\|', doc_all):
    fail('문서에 RECOMMENDED_FOR → Participant | 역할 이라는 모호한 표기가 남았다')

# ── 6. provenance.method 이름이 양쪽에서 같은가
print()
print('6. provenance.method 이름')
schema_methods = set(d['properties']['provenance']['method']['예'])
doc_methods = set(re.findall(
    r'(gold_annotation|human_annotation|model_inference|rule_extraction|model_then_human|derived)',
    doc_all))
short_forms = re.findall(r'gold\s*[·|]\s*human(?!_)', doc_all)
if short_forms:
    fail(f'문서에 축약 표기 gold · human 이 {len(short_forms)}건 남았다')
missing = schema_methods - doc_methods
if missing:
    warn(f'문서에 안 나오는 method 값 {sorted(missing)}')
print(f'   스키마 {len(schema_methods)}값 · 문서 등장 {len(doc_methods & schema_methods)}값')

# ── 7. provenance.agent 값
print()
print('7. provenance.agent 값')
agents = d['properties']['provenance']['agent']['예']
if '데이터셋' in agents:
    fail('스키마의 agent 에 데이터셋이 남아 있다')
if re.search(r'agent[^\n]{0,30}데이터셋', live):
    fail('살아 있는 코드 블록의 agent 에 데이터셋이 남아 있다')
print(f'   agent 값 {agents}')

# ── 8. 판정마다 문서에도 provenance 가 붙어 있는가
print()
print('8. 판정별 provenance 표기')
def stanzas(text, name):
    """이름이 나온 자리부터 빈 줄까지를 한 덩어리로 본다."""
    i = text.find(name)
    while i != -1:
        j = text.find('\n\n', i)
        yield text[i:j if j != -1 else i + 400]
        i = text.find(name, i + 1)


n_ok = sum(1 for name in attrs
           if any('provenance' in st for st in stanzas(doc_all, name.replace('sc_', ''))))
if n_ok < len(attrs):
    warn(f'문서에서 provenance 가 함께 적힌 판정 {n_ok} / {len(attrs)}')
print(f'   문서에서 provenance 와 함께 나온 판정 {n_ok} / {len(attrs)}')

print()
print('=' * 46)
print(f'실패 {len(fails)}건')
for m in fails:
    print('  x', m)
print(f'주의 {len(warns)}건')
for m in warns:
    print('  !', m)
print('=' * 46)
sys.exit(1 if fails else 0)
