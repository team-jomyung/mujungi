import yaml, io, collections
d = yaml.safe_load(io.open('ontology_v0_1.yaml', encoding='utf-8'))
C = collections.OrderedDict(); R = []
for ln, lay in d['layers'].items():
    for c in (lay.get('classes') or {}): C[c] = ln
    for r in (lay.get('relations') or []): R.append((r['name'], r['from'], r['to'], ln))
print('YAML OK')
print('layers', len(d['layers']))
print('classes', len(C), '| nikl', sum(1 for c in C if c.startswith('nikl')), '| sc', sum(1 for c in C if c.startswith('sc')), '| judgment', sum(1 for c in C if not c.startswith(('nikl','sc'))))
print('relations', len(R))
bad = [(n,f,t) for n,f,t,_ in R if (f not in C) or (t not in C)]
print('dangling endpoints:', bad if bad else 'none')
core = [c for c in C if C[c] != 'L4_pragmatic_extension']
print('PoC1 판정 대상 클래스', len(core))
for ln in d['layers']:
    cs = list(d['layers'][ln].get('classes') or {}); rs = d['layers'][ln].get('relations') or []
    print(f'  {ln:26s} class {len(cs):2d}  rel {len(rs):2d}')
