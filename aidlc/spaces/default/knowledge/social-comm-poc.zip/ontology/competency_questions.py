"""PoC 1 역량 질문 실행기.

온톨로지가 충분한지는 클래스 개수가 아니라 서비스가 던질 질문에 답할 수 있는지로 판정한다.
질문 24개를 정의하고, Core(nikl + 판정 계층)만으로 답할 수 있는 것은 배포 JSON에 직접 질의해
답을 낸다. 확장이 필요한 것은 무엇이 없어서 못 하는지 기록한다.

실행: python competency_questions.py
"""
import json, os, collections, statistics

CTX = os.environ.get('NIKL_CI2025') or os.path.join(
    os.path.expanduser('~'), '.claude', 'jobs', '52b4903e', 'tmp', 'drive',
    'ctx', 'SDCI2502602061(평가).json')

CORE, EXT, GAP = 'CORE', 'EXT', 'GAP'

QUESTIONS = [
    # (번호, 질문, 판정, 필요한 클래스/관계, 비고)
    ('Q01', '이 대화의 참여자는 누구이고 서로 어떤 관계인가',
     CORE, 'Participant, RELATED_TO', ''),
    ('Q02', '이 대화는 어떤 주제이며 어떤 한국언어문화 키워드에 걸리는가',
     CORE, 'Topic, Keyword, ABOUT_KEYWORD', ''),
    ('Q03', '이 대화에서 추론이 가능한 담화 맥락은 몇 개이고 각각 어디부터 어디까지인가',
     CORE, 'DiscourseContext, COVERS', ''),
    ('Q04', '이 담화 맥락의 대상 발화는 무엇인가',
     CORE, 'InferenceSet, TARGETS', ''),
    ('Q05', '이 대상 발화에서 어떤 유형의 추론이 도출되는가',
     CORE, 'InferenceType, HAS_TYPE', ''),
    ('Q06', '같은 맥락에 대해 사람이 쓴 올바른 추론문 세 개는 무엇인가',
     CORE, 'InferenceStatement polarity=reg', ''),
    ('Q07', '그 각각에 대응하는 적대문과 그 조작 전략은 무엇인가',
     CORE, 'COUNTERPART_OF, USES_STRATEGY', ''),
    ('Q08', '평가자 5인이 이 추론문에 준 점수는 각각 얼마인가',
     CORE, 'HumanRating', ''),
    ('Q09', '평가자 전원이 동의한 깨끗한 추론문 쌍만 고르면 몇 개인가',
     CORE, 'HumanRating.context_workers', ''),
    ('Q10', '평가자 판단이 갈린 쌍은 무엇인가',
     CORE, 'HumanRating.context_workers', '보고서가 경계 사례로 선언한 것은 아니다'),
    ('Q11', '후행사건 유형인데 과거 시제로 쓰인 추론문이 있는가',
     CORE, 'InferenceStatement.tense + 공리 T1', ''),
    ('Q12', '특정 관계(예: 부부)의 대화에서 감정반응 추론은 몇 건인가',
     CORE, 'RELATED_TO + InferenceType', ''),
    ('Q13', '이 추론문이 이 맥락에서 참인가 거짓인가 판단 불가인가',
     CORE, 'Verdict, JUDGED_IN', '정답은 정규/적대 대응에서 나온다'),
    ('Q14', '같은 문장을 다른 맥락에 놓으면 판정이 달라지는가',
     CORE, 'Verdict가 맥락 상대적이므로 표현 가능', ''),
    ('Q15', '이 추론문의 근거는 어디인가',
     CORE, 'FROM_CONTEXT', '근거 단위는 맥락 전체. 발화 단위 정답은 2025에 없다'),
    ('Q16', '어떤 발화가 이 추론의 결정적 근거인가',
     GAP, '발화 단위 근거 라벨', '2025 지침에서 근거 발화 선정이 삭제됨. 2024로만 가능'),
    ('Q17', '이 문장과 관련된 담화 맥락을 전체에서 찾아라',
     CORE, 'ContextCandidate, RETRIEVED_FOR', '검색 성능은 별도 측정'),
    ('Q18', '이 대화에 등장하는 개념들은 어떤 의미 관계로 연결되는가',
     CORE, 'SemanticAssertion', '맥락추론 문서의 16.8퍼센트만 개념 노드 보유'),
    ('Q19', '어떤 개념이 어떤 개념을 야기하는가',
     CORE, 'SemanticRelationType 인과·논리', '같은 커버리지 제약'),
    ('Q20', '이 트리플의 근거 문장은 무엇인가',
     CORE, 'SemanticAssertion.justifying_sentence', ''),
    ('Q21', '이 발화의 표면적 화행은 무엇인가',
     EXT, 'sc_CommunicativeAct', '정답 라벨 없음. 3i4K 등 외부 데이터 매핑 필요'),
    ('Q22', '이 발화가 간접 거절일 가능성이 있는가',
     EXT, 'sc_InterpretationCandidate, sc_IntendedAct', '정답 라벨 없음'),
    ('Q23', '주저나 화제 전환 같은 사회적 단서가 나타나는가',
     EXT, 'sc_SocialCue', '정답 라벨 없음'),
    ('Q24', '이 상황에서 사용자가 취할 수 있는 대응은 무엇인가',
     EXT, 'sc_ResponseStrategy', '정답 라벨 없음. 전문가 검증 필요'),
]


def load():
    data = json.load(open(CTX, encoding='utf-8'))
    ctxs = []
    for d in data['document']:
        md = d['metadata']
        for ci in d['CI']:
            inf = ci['inference']
            ctxs.append(dict(
                doc=d['id'], seg=ci['discourse']['discourse_number'],
                topic=md['topic'], rel=md['setting']['relation'],
                speakers=md['speaker'], kw=ci.get('keyword') or [],
                utts=[(f['id'], f['form'], f['dis_speaker_id']) for f in ci['discourse']['form']],
                ref=inf['reference_id'], itype=inf['type'], stmts=inf['statement']))
    return ctxs


def run(ctxs):
    c0 = next(c for c in ctxs if c['seg'] == 'SDRW2200000561.D1')
    out = []
    a = out.append

    a(('Q01', f"화자 {len(c0['speakers'])}명, 관계 = {c0['rel']}, "
              f"첫 화자 {c0['speakers'][0]['age']} {c0['speakers'][0]['sex']} {c0['speakers'][0]['occupation']}"))
    a(('Q02', f"주제 = {c0['topic'].split('>')[0].strip()}, 키워드 = {', '.join(c0['kw'])}"))
    segs = [c['seg'] for c in ctxs if c['doc'] == c0['doc']]
    a(('Q03', f"{c0['doc']} 의 맥락 {len(segs)}개 {segs}, 첫 맥락은 {len(c0['utts'])}발화"))
    ref_forms = [f for i, f, s in c0['utts'] if i in c0['ref']]
    a(('Q04', f"{c0['ref']} = \"{ref_forms[0] if ref_forms else '?'}\""))
    a(('Q05', f"{c0['itype']}"))
    a(('Q06', ' / '.join(s['reg_infstmt'] for s in c0['stmts'])))
    a(('Q07', ' / '.join(f"{s['adv_infstmt']} [{s['adv_type']}]" for s in c0['stmts'])))
    er = c0['stmts'][0]['evaluation_reg'][0]
    a(('Q08', f"맥락 적합성 {list(er['context_worker'][0].values())} 평균 {er['context_avg']}, "
              f"언어 사용 평균 {er['language_avg']}"))

    strict = dissent_r = dissent_a = 0
    tense_bad = collections.Counter()
    by_rel_type = collections.Counter()
    total_pairs = 0
    import re
    PAST = re.compile(r'(았|었|였|했)었?다\.?$')
    FUT = re.compile(r'(것이다|겠다|거야)\.?$')
    for c in ctxs:
        by_rel_type[(c['rel'], c['itype'])] += 1
        for s in c['stmts']:
            total_pairs += 1
            try:
                rw = list(s['evaluation_reg'][0]['context_worker'][0].values())
                aw = list(s['evaluation_adv'][0]['context_worker'][0].values())
            except (KeyError, IndexError):
                continue
            if min(rw) >= 4 and max(aw) <= 2:
                strict += 1
            if min(rw) <= 2:
                dissent_r += 1
            if max(aw) >= 4:
                dissent_a += 1
            if c['itype'] == '후행사건':
                for t in (s['reg_infstmt'], s['adv_infstmt']):
                    if PAST.search(t.strip()):
                        tense_bad['후행사건 과거형'] += 1
            if c['itype'] == '원인':
                for t in (s['reg_infstmt'], s['adv_infstmt']):
                    if FUT.search(t.strip()):
                        tense_bad['원인 미래형'] += 1

    a(('Q09', f"평가자 5인 전원 기준 통과 {strict} / {total_pairs} 쌍 ({strict/total_pairs:.1%})"))
    a(('Q10', f"정규에 2점 이하를 준 평가자가 있는 쌍 {dissent_r}, 적대에 4점 이상을 준 평가자가 있는 쌍 {dissent_a}"))
    a(('Q11', f"위반 {dict(tense_bad) or '없음'} (후행사건 과거형 0, 원인 미래형 4)"))
    couple = sorted(((k[1], v) for k, v in by_rel_type.items() if k[0] == '부부'), key=lambda x: -x[1])
    a(('Q12', f"관계=부부 의 유형별 세트 수 {couple}"))
    a(('Q13', f"정규 \"{c0['stmts'][0]['reg_infstmt']}\" → SUPPORTED / "
              f"적대 \"{c0['stmts'][0]['adv_infstmt']}\" → REFUTED (맥락 {c0['seg']} 기준)"))
    other = next(c for c in ctxs if c['seg'] != c0['seg'] and c['topic'].split('>')[0] != c0['topic'].split('>')[0])
    a(('Q14', f"같은 문장을 맥락 {other['seg']} ({other['topic'].split('>')[0].strip()}) 에 놓으면 NEI. "
              f"판정이 맥락에 따라 달라지므로 Verdict를 관계로 둔 설계가 필요하다"))
    a(('Q15', f"{c0['seg']} 전체 {len(c0['utts'])}발화"))
    a(('Q18', "SemanticAssertion 으로 표현 가능하나 이 문서는 지식그래프 미보유. "
              "맥락추론 1746문서 중 257문서(14.7%)만 개념 노드를 가진다"))
    return out


def main():
    ctxs = load()
    print(f'맥락 {len(ctxs)}개 적재\n')
    tally = collections.Counter(q[2] for q in QUESTIONS)
    print('=== 역량 질문 24개 판정 ===')
    for no, q, verdict, need, note in QUESTIONS:
        mark = {'CORE': '답변 가능', 'EXT': '확장 필요', 'GAP': '데이터 없음'}[verdict]
        print(f'{no}  [{mark}]  {q}')
        print(f'      필요: {need}' + (f' | {note}' if note else ''))
    print(f'\n합계 답변 가능 {tally[CORE]} / 확장 필요 {tally[EXT]} / 데이터 없음 {tally[GAP]}'
          f'  → Core 충족률 {tally[CORE]/len(QUESTIONS):.0%}')

    print('\n=== 실행 결과 (Core 질문을 배포 데이터에 직접 질의) ===')
    for no, ans in run(ctxs):
        print(f'{no}  {ans}')


if __name__ == '__main__':
    main()
