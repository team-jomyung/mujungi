// Social Communication Ontology v0.1.0 — 자동 생성. 손으로 고치지 말 것.
// 생성: python gen_schema.py > schema.cypher
// 식별자 규칙: {corpus}:{원본 식별자}

// ---- L1_dialogue_context : 실제 대화의 구조. 배포 JSON에서 직접 나온다.

// ---- L2_semantic_knowledge : 개념 사이의 의미 관계. 일상 대화 말뭉치 추출 지식그래프 2025에서 나온다.

// ---- L3_contextual_inference : 맥락 추론. 대화 맥락 추론 말뭉치 2025에서 나온다. PoC의 정답지.

// ---- L_judgment : 판정. 문장의 속성이 아니라 문장과 맥락 쌍의 속성이다.

// ---- L4_pragmatic_extension : 서비스가 필요로 하는 화용 계층. 현재 데이터에 정답 라벨이 없다.

// ===== 유일성 제약
CREATE CONSTRAINT adversarialstrategy_uid IF NOT EXISTS FOR (n:AdversarialStrategy) REQUIRE n.uid IS UNIQUE;  // nikl
CREATE CONSTRAINT communicativeact_uid IF NOT EXISTS FOR (n:CommunicativeAct) REQUIRE n.uid IS UNIQUE;  // sc
CREATE CONSTRAINT concept_uid IF NOT EXISTS FOR (n:Concept) REQUIRE n.uid IS UNIQUE;  // nikl
CREATE CONSTRAINT contextcandidate_uid IF NOT EXISTS FOR (n:ContextCandidate) REQUIRE n.uid IS UNIQUE;  // app
CREATE CONSTRAINT conversation_uid IF NOT EXISTS FOR (n:Conversation) REQUIRE n.uid IS UNIQUE;  // nikl
CREATE CONSTRAINT corpus_uid IF NOT EXISTS FOR (n:Corpus) REQUIRE n.uid IS UNIQUE;  // nikl
CREATE CONSTRAINT discoursecontext_uid IF NOT EXISTS FOR (n:DiscourseContext) REQUIRE n.uid IS UNIQUE;  // nikl
CREATE CONSTRAINT humanrating_uid IF NOT EXISTS FOR (n:HumanRating) REQUIRE n.uid IS UNIQUE;  // nikl
CREATE CONSTRAINT inferenceset_uid IF NOT EXISTS FOR (n:InferenceSet) REQUIRE n.uid IS UNIQUE;  // nikl
CREATE CONSTRAINT inferencestatement_uid IF NOT EXISTS FOR (n:InferenceStatement) REQUIRE n.uid IS UNIQUE;  // nikl
CREATE CONSTRAINT inferencetype_uid IF NOT EXISTS FOR (n:InferenceType) REQUIRE n.uid IS UNIQUE;  // nikl
CREATE CONSTRAINT intendedact_uid IF NOT EXISTS FOR (n:IntendedAct) REQUIRE n.uid IS UNIQUE;  // sc
CREATE CONSTRAINT interpretationcandidate_uid IF NOT EXISTS FOR (n:InterpretationCandidate) REQUIRE n.uid IS UNIQUE;  // sc
CREATE CONSTRAINT keyword_uid IF NOT EXISTS FOR (n:Keyword) REQUIRE n.uid IS UNIQUE;  // nikl
CREATE CONSTRAINT participant_uid IF NOT EXISTS FOR (n:Participant) REQUIRE n.uid IS UNIQUE;  // nikl
CREATE CONSTRAINT responsestrategy_uid IF NOT EXISTS FOR (n:ResponseStrategy) REQUIRE n.uid IS UNIQUE;  // sc
CREATE CONSTRAINT semanticassertion_uid IF NOT EXISTS FOR (n:SemanticAssertion) REQUIRE n.uid IS UNIQUE;  // nikl
CREATE CONSTRAINT semanticattribute_uid IF NOT EXISTS FOR (n:SemanticAttribute) REQUIRE n.uid IS UNIQUE;  // nikl
CREATE CONSTRAINT semanticrelationtype_uid IF NOT EXISTS FOR (n:SemanticRelationType) REQUIRE n.uid IS UNIQUE;  // nikl
CREATE CONSTRAINT socialcue_uid IF NOT EXISTS FOR (n:SocialCue) REQUIRE n.uid IS UNIQUE;  // sc
CREATE CONSTRAINT topic_uid IF NOT EXISTS FOR (n:Topic) REQUIRE n.uid IS UNIQUE;  // nikl
CREATE CONSTRAINT utterance_uid IF NOT EXISTS FOR (n:Utterance) REQUIRE n.uid IS UNIQUE;  // nikl
CREATE CONSTRAINT verdict_uid IF NOT EXISTS FOR (n:Verdict) REQUIRE n.uid IS UNIQUE;  // app

// ===== 인덱스
CREATE INDEX stmt_polarity IF NOT EXISTS FOR (n:InferenceStatement) ON (n.polarity);
CREATE INDEX stmt_tense IF NOT EXISTS FOR (n:InferenceStatement) ON (n.tense);
CREATE INDEX ctx_corpus IF NOT EXISTS FOR (n:DiscourseContext) ON (n.corpus);
CREATE INDEX kw_term IF NOT EXISTS FOR (n:Keyword) ON (n.term);
CREATE INDEX concept_term IF NOT EXISTS FOR (n:Concept) ON (n.term);

// ===== 관계 형태 (참고)
// (:Corpus)-[:CONTAINS]->(:Conversation)
// (:Conversation)-[:HAS_UTTERANCE {seq}]->(:Utterance)
// (:Conversation)-[:HAS_CONTEXT {number}]->(:DiscourseContext)
// (:DiscourseContext)-[:COVERS {order}]->(:Utterance)
// (:Utterance)-[:SPOKEN_BY]->(:Participant)
// (:Participant)-[:PARTICIPATES_IN {local_id}]->(:Conversation)
// (:Participant)-[:RELATED_TO {relation}]->(:Participant)
// (:Conversation)-[:HAS_TOPIC]->(:Topic)
// (:DiscourseContext)-[:ABOUT_KEYWORD]->(:Keyword)
// (:SemanticAssertion)-[:HAS_SOURCE]->(:Concept)
// (:SemanticAssertion)-[:HAS_TARGET]->(:Concept)
// (:SemanticAssertion)-[:HAS_RELATION_TYPE]->(:SemanticRelationType)
// (:SemanticRelationType)-[:IN_ATTRIBUTE]->(:SemanticAttribute)
// (:SemanticAssertion)-[:GROUNDED_IN]->(:Conversation)
// (:Conversation)-[:MENTIONS]->(:Concept)
// (:DiscourseContext)-[:HAS_SET]->(:InferenceSet)
// (:InferenceSet)-[:FROM_CONTEXT]->(:DiscourseContext)
// (:InferenceSet)-[:TARGETS]->(:Utterance)
// (:InferenceSet)-[:HAS_TYPE]->(:InferenceType)
// (:InferenceSet)-[:HAS_STATEMENT {index, polarity}]->(:InferenceStatement)
// (:InferenceStatement)-[:COUNTERPART_OF]->(:InferenceStatement)
// (:InferenceStatement)-[:USES_STRATEGY]->(:AdversarialStrategy)
// (:InferenceStatement)-[:RATED_BY]->(:HumanRating)
// (:InferenceStatement)-[:JUDGED_IN {verdict_uid}]->(:DiscourseContext)
// (:ContextCandidate)-[:RETRIEVED_FOR]->(:InferenceStatement)
// (:ContextCandidate)-[:POINTS_TO]->(:DiscourseContext)
// (:Utterance)-[:HAS_ACT]->(:CommunicativeAct)
// (:Utterance)-[:SHOWS_CUE]->(:SocialCue)
// (:Utterance)-[:INTERPRETED_AS]->(:InterpretationCandidate)
// (:InterpretationCandidate)-[:SUPPORTED_BY]->(:InferenceStatement)
// (:InterpretationCandidate)-[:MAY_REALIZE]->(:IntendedAct)
// (:InterpretationCandidate)-[:SUGGESTS]->(:ResponseStrategy)

// ===== 공리 검사 질의 (적재 후 실행, 모두 0이 나와야 한다)
MATCH (c:DiscourseContext) WHERE c.corpus IS NULL RETURN count(c) AS S1_접두없음;
MATCH (s:InferenceSet) WHERE NOT (s)-[:FROM_CONTEXT]->(:DiscourseContext) RETURN count(s) AS S1_맥락없는세트;
MATCH (s:InferenceSet)-[:TARGETS]->(u:Utterance) WHERE NOT (s)<-[:HAS_SET]-(:DiscourseContext)-[:COVERS]->(u) RETURN count(*) AS S3_대상발화가맥락밖;
MATCH (s:InferenceSet) WITH s, count{(s)-[:HAS_STATEMENT]->()} AS n WHERE n <> 6 RETURN count(s) AS S4_추론문6개아님;
MATCH (a:InferenceStatement {polarity:'adv'}) WHERE NOT (a)-[:COUNTERPART_OF]->(:InferenceStatement {polarity:'reg'}) RETURN count(a) AS S5_대응없는적대문;
MATCH (a:InferenceStatement {polarity:'adv'}) WHERE NOT (a)-[:USES_STRATEGY]->() RETURN count(a) AS S6_전략없는적대문;
MATCH (i:InferenceSet)-[:HAS_TYPE]->(:InferenceType {uid:'subsequent_event'}) MATCH (i)-[:HAS_STATEMENT]->(s) WHERE s.tense='PAST' RETURN count(s) AS T1_후행사건과거형;
MATCH (i:InferenceSet)-[:HAS_TYPE]->(:InferenceType {uid:'cause'}) MATCH (i)-[:HAS_STATEMENT]->(s) WHERE s.tense='FUT' RETURN count(s) AS T2_원인미래형;
MATCH (s:InferenceStatement) WHERE NOT (s)-[:RATED_BY]->() RETURN count(s) AS Q1_평정없음;
