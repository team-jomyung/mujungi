"""온톨로지 YAML에서 Neo4j 스키마를 생성한다. 온톨로지가 기계가 읽을 수 있는 형태인지 확인하는 절차이기도 하다."""
import yaml, io
d = yaml.safe_load(io.open('ontology_v0_2.yaml', encoding='utf-8'))
L = ['// Social Communication Ontology v%s — 자동 생성. 손으로 고치지 말 것.' % d['version'],
     '// 생성: python gen_schema.py > schema.cypher',
     '// 식별자 규칙: %s' % d['identifier_rule']['pattern'], '']
uniq, idx, rels = [], [], []
for ln, lay in d["modules"].items():
    L.append('// ---- %s : %s' % (ln, lay.get('설명', '')))
    for c in (lay.get('classes') or {}):
        label = c.replace('nikl_', '').replace('sc_', '')
        pre = 'nikl' if c.startswith('nikl_') else ('sc' if c.startswith('sc_') else 'app')
        uniq.append('CREATE CONSTRAINT %s_uid IF NOT EXISTS FOR (n:%s) REQUIRE n.uid IS UNIQUE;  // %s' % (label.lower(), label, pre))
    for r in (lay.get('relations') or []):
        f = r['from'].replace('nikl_', '').replace('sc_', '')
        t = r['to'].replace('nikl_', '').replace('sc_', '')
        p = (' {%s}' % ', '.join(r['props'])) if r.get('props') else ''
        rels.append('// (:%s)-[:%s%s]->(:%s)' % (f, r['name'], p, t))
    L.append('')
idx = [
 'CREATE INDEX stmt_polarity IF NOT EXISTS FOR (n:InferenceStatement) ON (n.polarity);',
 'CREATE INDEX stmt_tense IF NOT EXISTS FOR (n:InferenceStatement) ON (n.tense);',
 'CREATE INDEX ctx_corpus IF NOT EXISTS FOR (n:DiscourseContext) ON (n.corpus);',
 'CREATE INDEX kw_term IF NOT EXISTS FOR (n:Keyword) ON (n.term);',
 'CREATE INDEX concept_term IF NOT EXISTS FOR (n:Concept) ON (n.term);',
]
out = ['\n'.join(L), '// ===== 유일성 제약', '\n'.join(sorted(set(uniq))), '',
       '// ===== 인덱스', '\n'.join(idx), '',
       '// ===== 관계 형태 (참고)', '\n'.join(rels), '',
       '// ===== 공리 검사 질의 (적재 후 실행, 모두 0이 나와야 한다)',
       "MATCH (c:DiscourseContext) WHERE c.corpus IS NULL RETURN count(c) AS S1_접두없음;",
       "MATCH (s:InferenceSet) WHERE NOT (s)-[:FROM_CONTEXT]->(:DiscourseContext) RETURN count(s) AS S1_맥락없는세트;",
       "MATCH (s:InferenceSet)-[:TARGETS]->(u:Utterance) WHERE NOT (s)<-[:HAS_SET]-(:DiscourseContext)-[:COVERS]->(u) RETURN count(*) AS S3_대상발화가맥락밖;",
       "MATCH (s:InferenceSet) WITH s, count{(s)-[:HAS_STATEMENT]->()} AS n WHERE n <> 6 RETURN count(s) AS S4_추론문6개아님;",
       "MATCH (a:InferenceStatement {polarity:'adv'}) WHERE NOT (a)-[:COUNTERPART_OF]->(:InferenceStatement {polarity:'reg'}) RETURN count(a) AS S5_대응없는적대문;",
       "MATCH (a:InferenceStatement {polarity:'adv'}) WHERE NOT (a)-[:USES_STRATEGY]->() RETURN count(a) AS S6_전략없는적대문;",
       "MATCH (i:InferenceSet)-[:HAS_TYPE]->(:InferenceType {uid:'subsequent_event'}) MATCH (i)-[:HAS_STATEMENT]->(s) WHERE s.tense='PAST' RETURN count(s) AS T1_후행사건과거형;",
       "MATCH (i:InferenceSet)-[:HAS_TYPE]->(:InferenceType {uid:'cause'}) MATCH (i)-[:HAS_STATEMENT]->(s) WHERE s.tense='FUT' RETURN count(s) AS T2_원인미래형;",
       "MATCH (s:InferenceStatement) WHERE NOT (s)-[:RATED_BY]->() RETURN count(s) AS Q1_평정없음;",
       '']
io.open('schema_v0_2.cypher','w',encoding='utf-8').write('\n'.join(out))
print('schema.cypher 생성 · 제약', len(set(uniq)), '· 인덱스', len(idx), '· 관계', len(rels))
