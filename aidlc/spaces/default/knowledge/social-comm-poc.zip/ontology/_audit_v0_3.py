"""v0.3 고정 후보의 기계적 일관성 감사.

스키마가 앞뒤가 맞는지, 문서와 이름이 어긋나지 않는지 본다.
설계 판단은 하지 않는다. 이름과 개수만 본다.

    python _audit_v0_3.py
"""
import io
import os
import re
import sys

import yaml

HERE = os.path.dirname(os.path.abspath(__file__))
YAML_PATH = os.path.join(HERE, 'v0_3_freeze_candidate.yaml')
PROPOSAL = os.path.join(HERE, 'v0_3_proposal.md')
DOC_PATHS = [
    PROPOSAL,
    os.path.join(HERE, 'annotation_guideline_v0_1.md'),
    os.path.join(HERE, '..', 'PoC1_경계검토_고정전결정.html'),
]

fails = []
warns = []


def fail(msg):
    fails.append(msg)


def warn(msg):
    warns.append(msg)


d = yaml.safe_load(io.open(YAML_PATH, encoding='utf-8'))
targets, attrs = d['targets'], d['attributions']
vocabs, props = d['vocabularies'], d['properties']
derived, removed = d['derived'], d['removed']
rule_derived = d.get('rule_derived', {})

print('=== v0.3 고정 후보 감사 ===')
print()

# ── 1. 관계의 도착점이 정의된 이름인가
print('1. 관계 도착점')
known = set(targets) | set(vocabs) | {'ObservedFeature', 'sco_Participant', 'sco_Context'}
n_rel = 0
for aname, a in attrs.items():
    for rname, r in a.get('관계', {}).items():
        n_rel += 1
        to = r['to']
        for t in (to if isinstance(to, list) else [to]):
            if t not in known:
                fail(f'{aname}.{rname} 의 도착점 {t} 가 정의되지 않았다')
        for t in r.get('allow', []):
            if t not in known:
                fail(f'{aname}.{rname} 의 allow 값 {t} 가 정의되지 않았다')
print(f'   관계 {n_rel}개 · 정의되지 않은 도착점 없음')

# ── 2. 판정마다 출처가 있는가
print()
print('2. 판정별 출처')
for aname, a in attrs.items():
    if 'provenance' not in a.get('속성', []):
        fail(f'{aname} 에 provenance 가 없다')
print(f'   판정 {len(attrs)}개 전부 provenance 보유')

# ── 3. 쓰이는 속성이 정의됐는가
print()
print('3. 속성 정의')
used = set()
for aname, a in attrs.items():
    for p in a.get('속성', []):
        used.add(p)
        if p not in props:
            fail(f'{aname} 이 쓰는 속성 {p} 가 properties 에 없다')
unused = set(props) - used
if unused:
    warn(f'정의만 되고 쓰이지 않는 속성 {sorted(unused)}')
print(f'   쓰이는 속성 {sorted(used)}')

# ── 4. 제거한 것이 살아 있지 않은가
print()
print('4. 제거 항목')
body = io.open(YAML_PATH, encoding='utf-8').read()
live = body.split('# 감사에서 뺀 것')[0]
FORBIDDEN = {
    'level': r'^\s+level:',
    '단독 holder': r'^\s+속성:.*[^_a-z]holder(?![_a-z])',
    'kind 닫힘': r'kind:\s*literal\s*\|',
}
for label, pat in FORBIDDEN.items():
    hits = [ln for ln in live.split('\n') if re.search(pat, ln)]
    if hits:
        fail(f'제거한 {label} 가 살아 있다: {hits[0].strip()[:60]}')
print(f'   제거 목록 {len(removed)}건 · 살아 있는 것 없음')

# ── 5. 값 목록의 열림 표시
print()
print('5. 값 목록의 열림 표시')
closed = []
for vname, v in vocabs.items():
    if not isinstance(v, dict):
        continue
    if 'values' in v or '하위' in v or 'modes' in v or v.get('status') == 'provisional':
        continue
    closed.append(vname)
if closed:
    warn(f'values 표시가 없는 어휘 {closed}')
print(f'   어휘 {len(vocabs)}개 · 표시 없는 것 {len(closed)}')

# ── 6. 도출한다고 한 것이 속성으로도 저장되지 않는가
print()
print('6. 도출과 저장의 중복')
FORBIDDEN_PROPS = ['level', 'actor', 'strategy_actor']
for n in FORBIDDEN_PROPS:
    if n in props:
        fail(f'{n} 는 도출하기로 했는데 속성으로 정의돼 있다')
print(f'   구조적 도출 {len(derived)}건 · 규칙 도출 {len(rule_derived)}건 · 중복 없음')

# ── 7. 문서에 스키마 이름이 나타나는가
print()
print('7. 문서와 이름 대조')
docs = ''
for p in DOC_PATHS:
    if os.path.exists(p):
        docs += io.open(p, encoding='utf-8').read()
    else:
        warn(f'문서를 찾지 못했다: {os.path.basename(p)}')
missing = [n for n in list(attrs) + list(targets)
           if n.replace('sc_', '').replace('sco_', '') not in docs]
if missing:
    warn(f'문서에서 못 찾은 이름 {missing}')
print(f'   클래스 {len(attrs) + len(targets)}개 · 문서 미등장 {len(missing)}')

# ── 8. 구버전 표현이 표시 없이 남아 있는가 · 절 단위로 본다
print()
print('8. 구버전 표현 · 절 단위')

MARKERS = ('에서 수정됐다', '에서 완화', '용어 주의', '철회', '당시 제안', '당시 논거',
           '에서 제거됐다', '판의 잘못', '에서 수정됨', '수정됐다')
AUDIT_SECTIONS = ('13', '17')          # 그 표현을 다루는 절 자체
STALE = {
    'IntendedAct': 'IntendedAct',
    'provenance.agent 의 데이터셋': '규칙 | 데이터셋',
}


def split_sections(md):
    out, cur, buf = [], '0', []
    for line in md.split('\n'):
        m = re.match(r'^#+\s+(\d+)(?:\.\d+)?\.?\s', line)
        if m:
            out.append((cur, '\n'.join(buf)))
            cur, buf = m.group(1), [line]
        else:
            buf.append(line)
    out.append((cur, '\n'.join(buf)))
    return out


md = io.open(PROPOSAL, encoding='utf-8').read()
# 하위 절이 따로 잘리므로 같은 번호끼리 합친다. 절 머리의 표시가 하위 절도 덮는다.
merged = {}
for num, text in split_sections(md):
    merged.setdefault(num, []).append(text)
merged = {k: '\n'.join(v) for k, v in merged.items()}

for label, needle in STALE.items():
    bare = []
    for num, text in merged.items():
        if needle not in text:
            continue
        if num in AUDIT_SECTIONS:
            continue
        if any(mk in text for mk in MARKERS):
            continue
        bare.append(num)
    if bare:
        warn(f'{label} 가 표시 없는 절에 있다: {sorted(set(bare))}절')
    else:
        print(f'   {label} · 표시 없는 절 없음')

# ── 결과
print()
print('=' * 46)
print(f'실패 {len(fails)}건')
for m in fails:
    print('  x', m)
print(f'주의 {len(warns)}건')
for m in warns:
    print('  !', m)
print('=' * 46)
sys.exit(1 if fails else 0)
