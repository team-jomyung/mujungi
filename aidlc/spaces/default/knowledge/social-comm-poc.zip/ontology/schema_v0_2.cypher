// Social Communication Ontology v0.2.0 — 자동 생성. 손으로 고치지 말 것.
// 생성: python gen_schema.py > schema.cypher
// 식별자 규칙: {corpus}:{원본 식별자}

// ---- M1_domain : 세계에 존재하는 개념. 데이터셋이 바뀌어도 의미가 유지되어야 한다.

// ---- M2_dataset_representation : 말뭉치 산출물의 구조. 세계의 개념이 아니라 데이터가 만들어진 방식이다.

// ---- M3_evaluation : 평가와 판정. 도메인 개념이 아니라 데이터에 대한 판단이다.

// ---- M4_runtime : 검색 실행 중에 생기는 산출물. 온톨로지가 아니라 실행 기록이다.

// ---- M5_extension : 서비스가 필요로 하는 화용 계층. 현재 확보한 어떤 말뭉치에도 정답이 없다.

// ===== 유일성 제약
CREATE CONSTRAINT adversarialstrategy_uid IF NOT EXISTS FOR (n:AdversarialStrategy) REQUIRE n.uid IS UNIQUE;  // nikl
CREATE CONSTRAINT communicativeact_uid IF NOT EXISTS FOR (n:CommunicativeAct) REQUIRE n.uid IS UNIQUE;  // sc
CREATE CONSTRAINT inferencetype_uid IF NOT EXISTS FOR (n:InferenceType) REQUIRE n.uid IS UNIQUE;  // nikl
CREATE CONSTRAINT intendedact_uid IF NOT EXISTS FOR (n:IntendedAct) REQUIRE n.uid IS UNIQUE;  // sc
CREATE CONSTRAINT interpretationcandidate_uid IF NOT EXISTS FOR (n:InterpretationCandidate) REQUIRE n.uid IS UNIQUE;  // sc
CREATE CONSTRAINT responsestrategy_uid IF NOT EXISTS FOR (n:ResponseStrategy) REQUIRE n.uid IS UNIQUE;  // sc
CREATE CONSTRAINT sco_concept_uid IF NOT EXISTS FOR (n:sco_Concept) REQUIRE n.uid IS UNIQUE;  // app
CREATE CONSTRAINT sco_contextcandidate_uid IF NOT EXISTS FOR (n:sco_ContextCandidate) REQUIRE n.uid IS UNIQUE;  // app
CREATE CONSTRAINT sco_conversation_uid IF NOT EXISTS FOR (n:sco_Conversation) REQUIRE n.uid IS UNIQUE;  // app
CREATE CONSTRAINT sco_corpus_uid IF NOT EXISTS FOR (n:sco_Corpus) REQUIRE n.uid IS UNIQUE;  // app
CREATE CONSTRAINT sco_discoursecontext_uid IF NOT EXISTS FOR (n:sco_DiscourseContext) REQUIRE n.uid IS UNIQUE;  // app
CREATE CONSTRAINT sco_humanrating_uid IF NOT EXISTS FOR (n:sco_HumanRating) REQUIRE n.uid IS UNIQUE;  // app
CREATE CONSTRAINT sco_inferenceset_uid IF NOT EXISTS FOR (n:sco_InferenceSet) REQUIRE n.uid IS UNIQUE;  // app
CREATE CONSTRAINT sco_inferencestatement_uid IF NOT EXISTS FOR (n:sco_InferenceStatement) REQUIRE n.uid IS UNIQUE;  // app
CREATE CONSTRAINT sco_keyword_uid IF NOT EXISTS FOR (n:sco_Keyword) REQUIRE n.uid IS UNIQUE;  // app
CREATE CONSTRAINT sco_participant_uid IF NOT EXISTS FOR (n:sco_Participant) REQUIRE n.uid IS UNIQUE;  // app
CREATE CONSTRAINT sco_semanticassertion_uid IF NOT EXISTS FOR (n:sco_SemanticAssertion) REQUIRE n.uid IS UNIQUE;  // app
CREATE CONSTRAINT sco_speakerstance_uid IF NOT EXISTS FOR (n:sco_SpeakerStance) REQUIRE n.uid IS UNIQUE;  // app
CREATE CONSTRAINT sco_subtopic_uid IF NOT EXISTS FOR (n:sco_SubTopic) REQUIRE n.uid IS UNIQUE;  // app
CREATE CONSTRAINT sco_summary_uid IF NOT EXISTS FOR (n:sco_Summary) REQUIRE n.uid IS UNIQUE;  // app
CREATE CONSTRAINT sco_topic_uid IF NOT EXISTS FOR (n:sco_Topic) REQUIRE n.uid IS UNIQUE;  // app
CREATE CONSTRAINT sco_utterance_uid IF NOT EXISTS FOR (n:sco_Utterance) REQUIRE n.uid IS UNIQUE;  // app
CREATE CONSTRAINT sco_verdict_uid IF NOT EXISTS FOR (n:sco_Verdict) REQUIRE n.uid IS UNIQUE;  // app
CREATE CONSTRAINT semanticattribute_uid IF NOT EXISTS FOR (n:SemanticAttribute) REQUIRE n.uid IS UNIQUE;  // nikl
CREATE CONSTRAINT semanticrelationtype_uid IF NOT EXISTS FOR (n:SemanticRelationType) REQUIRE n.uid IS UNIQUE;  // nikl
CREATE CONSTRAINT socialcue_uid IF NOT EXISTS FOR (n:SocialCue) REQUIRE n.uid IS UNIQUE;  // sc

// ===== 인덱스
CREATE INDEX stmt_polarity IF NOT EXISTS FOR (n:InferenceStatement) ON (n.polarity);
CREATE INDEX stmt_tense IF NOT EXISTS FOR (n:InferenceStatement) ON (n.tense);
CREATE INDEX ctx_corpus IF NOT EXISTS FOR (n:DiscourseContext) ON (n.corpus);
CREATE INDEX kw_term IF NOT EXISTS FOR (n:Keyword) ON (n.term);
CREATE INDEX concept_term IF NOT EXISTS FOR (n:Concept) ON (n.term);

// ===== 관계 형태 (참고)
// (:sco_Conversation)-[:HAS_UTTERANCE {seq}]->(:sco_Utterance)
// (:sco_Conversation)-[:HAS_CONTEXT {number}]->(:sco_DiscourseContext)
// (:sco_DiscourseContext)-[:COVERS {order}]->(:sco_Utterance)
// (:sco_Utterance)-[:SPOKEN_BY]->(:sco_Participant)
// (:sco_Participant)-[:PARTICIPATES_IN {local_id}]->(:sco_Conversation)
// (:sco_Participant)-[:RELATED_TO {relation}]->(:sco_Participant)
// (:sco_Conversation)-[:HAS_TOPIC]->(:sco_Topic)
// (:sco_DiscourseContext)-[:ABOUT_KEYWORD]->(:sco_Keyword)
// (:sco_Conversation)-[:MENTIONS]->(:sco_Concept)
// (:sco_SemanticAssertion)-[:HAS_SOURCE]->(:sco_Concept)
// (:sco_SemanticAssertion)-[:HAS_TARGET]->(:sco_Concept)
// (:sco_SemanticAssertion)-[:GROUNDED_IN]->(:sco_Conversation)
// (:sco_Summary)-[:SUMMARIZES]->(:sco_Conversation)
// (:sco_Summary)-[:HAS_SUBTOPIC]->(:sco_SubTopic)
// (:sco_SubTopic)-[:HAS_STANCE]->(:sco_SpeakerStance)
// (:sco_SpeakerStance)-[:STANCE_OF]->(:sco_Participant)
// (:sco_Corpus)-[:CONTAINS]->(:sco_Conversation)
// (:sco_DiscourseContext)-[:HAS_SET]->(:sco_InferenceSet)
// (:sco_InferenceSet)-[:FROM_CONTEXT]->(:sco_DiscourseContext)
// (:sco_InferenceSet)-[:TARGETS]->(:sco_Utterance)
// (:sco_InferenceSet)-[:HAS_TYPE]->(:InferenceType)
// (:sco_InferenceSet)-[:HAS_STATEMENT {index, polarity}]->(:sco_InferenceStatement)
// (:sco_InferenceStatement)-[:COUNTERPART_OF]->(:sco_InferenceStatement)
// (:sco_InferenceStatement)-[:USES_STRATEGY]->(:AdversarialStrategy)
// (:sco_SemanticAssertion)-[:HAS_RELATION_TYPE]->(:SemanticRelationType)
// (:SemanticRelationType)-[:IN_ATTRIBUTE]->(:SemanticAttribute)
// (:sco_Utterance)-[:EVIDENCE_FOR {begin, end, role}]->(:sco_InferenceStatement)
// (:sco_InferenceStatement)-[:RATED_BY]->(:sco_HumanRating)
// (:sco_Summary)-[:RATED_BY_SUMMARY]->(:sco_HumanRating)
// (:sco_InferenceStatement)-[:JUDGED_IN {verdict_uid}]->(:sco_DiscourseContext)
// (:sco_ContextCandidate)-[:RETRIEVED_FOR]->(:sco_InferenceStatement)
// (:sco_ContextCandidate)-[:POINTS_TO]->(:sco_DiscourseContext)
// (:sco_Utterance)-[:HAS_ACT]->(:CommunicativeAct)
// (:sco_Utterance)-[:SHOWS_CUE]->(:SocialCue)
// (:sco_Utterance)-[:INTERPRETED_AS]->(:InterpretationCandidate)
// (:InterpretationCandidate)-[:SUPPORTED_BY]->(:sco_InferenceStatement)
// (:InterpretationCandidate)-[:INFORMED_BY]->(:sco_SpeakerStance)
// (:InterpretationCandidate)-[:MAY_REALIZE]->(:IntendedAct)
// (:InterpretationCandidate)-[:SUGGESTS]->(:ResponseStrategy)

// ===== 공리 검사 질의 (적재 후 실행, 모두 0이 나와야 한다)
MATCH (c:DiscourseContext) WHERE c.corpus IS NULL RETURN count(c) AS S1_접두없음;
MATCH (s:InferenceSet) WHERE NOT (s)-[:FROM_CONTEXT]->(:DiscourseContext) RETURN count(s) AS S1_맥락없는세트;
MATCH (s:InferenceSet)-[:TARGETS]->(u:Utterance) WHERE NOT (s)<-[:HAS_SET]-(:DiscourseContext)-[:COVERS]->(u) RETURN count(*) AS S3_대상발화가맥락밖;
MATCH (s:InferenceSet) WITH s, count{(s)-[:HAS_STATEMENT]->()} AS n WHERE n <> 6 RETURN count(s) AS S4_추론문6개아님;
MATCH (a:InferenceStatement {polarity:'adv'}) WHERE NOT (a)-[:COUNTERPART_OF]->(:InferenceStatement {polarity:'reg'}) RETURN count(a) AS S5_대응없는적대문;
MATCH (a:InferenceStatement {polarity:'adv'}) WHERE NOT (a)-[:USES_STRATEGY]->() RETURN count(a) AS S6_전략없는적대문;
MATCH (i:InferenceSet)-[:HAS_TYPE]->(:InferenceType {uid:'subsequent_event'}) MATCH (i)-[:HAS_STATEMENT]->(s) WHERE s.tense='PAST' RETURN count(s) AS T1_후행사건과거형;
MATCH (i:InferenceSet)-[:HAS_TYPE]->(:InferenceType {uid:'cause'}) MATCH (i)-[:HAS_STATEMENT]->(s) WHERE s.tense='FUT' RETURN count(s) AS T2_원인미래형;
MATCH (s:InferenceStatement) WHERE NOT (s)-[:RATED_BY]->() RETURN count(s) AS Q1_평정없음;
