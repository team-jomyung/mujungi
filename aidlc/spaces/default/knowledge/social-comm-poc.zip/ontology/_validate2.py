import yaml, io, collections, sys
def load(p, key):
    d = yaml.safe_load(io.open(p, encoding='utf-8'))
    C = {}; R = []
    for ln, lay in d[key].items():
        for c in (lay.get('classes') or {}): C[c] = ln
        for r in (lay.get('relations') or []): R.append((r['name'], r['from'], r['to'], ln, bool(r.get('신규'))))
    return d, C, R
d1, C1, R1 = load('ontology_v0_1.yaml', 'layers')
d2, C2, R2 = load('ontology_v0_2.yaml', 'modules')

def norm(x): return x.replace('nikl_','').replace('sco_','').replace('sc_','')
print('== v0.2 검증 ==')
print('모듈', len(d2['modules']), '· 클래스', len(C2), '· 관계', len(R2))
ns = collections.Counter('nikl' if c.startswith('nikl_') else ('sc' if c.startswith('sc_') else 'sco') for c in C2)
print('이름공간별 클래스', dict(ns))
bad = [(n,f,t) for n,f,t,_,_ in R2 if f not in C2 or t not in C2]
print('끊긴 끝점:', bad if bad else '없음')
mod = collections.Counter(C2.values())
for m in d2['modules']:
    rs = len(d2['modules'][m].get('relations') or [])
    print(f'  {m:28s} class {mod[m]:2d}  rel {rs:2d}')
core = [c for c in C2 if C2[c] != 'M5_extension']
print('검증 대상 클래스', len(core), '/ 확장', len(C2)-len(core))

print('\n== v0.1 → v0.2 diff ==')
n1 = {norm(c) for c in C1}; n2 = {norm(c) for c in C2}
print('추가 클래스:', sorted(n2 - n1))
print('삭제 클래스:', sorted(n1 - n2) or '없음')
r1 = {r[0] for r in R1}; r2 = {r[0] for r in R2}
print('추가 관계:', sorted(r2 - r1))
print('삭제 관계:', sorted(r1 - r2) or '없음')
print('클래스 수', len(C1), '→', len(C2), ' 관계 수', len(R1), '→', len(R2))
