# -*- coding: utf-8 -*-
"""FINAL_INSTRUCTOR_REPORT.html · 세 질문 순서로. 숫자는 전부 파일에서 읽는다.

    python build_final_report.py
"""
from __future__ import annotations

import collections
import difflib
import csv
import io
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, '..'))
IFE = os.path.join(ROOT, 'INSTRUCTOR_FINAL_EVIDENCE')
OUT = os.path.join(HERE, 'FINAL_INSTRUCTOR_REPORT.html')


def rd(p):
    return list(csv.DictReader(io.open(p, encoding='utf-8-sig', newline=''))) \
        if os.path.exists(p) else []


def jl(p):
    o = []
    if os.path.exists(p):
        for x in io.open(p, encoding='utf-8'):
            x = x.strip()
            if x:
                try:
                    o.append(json.loads(x))
                except ValueError:
                    pass
    return o


def esc(t):
    return (str(t).replace('&', '&amp;').replace('<', '&lt;')
            .replace('>', '&gt;').replace('"', '&quot;'))


def md(t):
    o, b = [], False
    for p in esc(t).split('**'):
        o.append(('<b>%s</b>' % p) if b else p)
        b = not b
    return ''.join(o)


def tbl(head, rows):
    return ('<div class="tw"><table><thead><tr>%s</tr></thead><tbody>%s</tbody></table></div>'
            % (''.join('<th>%s</th>' % md(h) for h in head),
               ''.join('<tr>%s</tr>' % ''.join('<td>%s</td>' % md(c) for c in r)
                       for r in rows)))


def dl(pairs):
    return ('<dl class="qs">' + ''.join('<dt>%s</dt><dd>%s</dd>' % (md(k), md(v))
                                        for k, v in pairs) + '</dl>')


def g():
    d = {}
    au = rd(os.path.join(IFE, '01_DATA', 'DATASET_EXECUTABILITY_AUDIT.csv'))
    d['census'] = [r for r in au if r['scope'] != 'OWN']
    d['tierA'] = [r for r in au if r['tier'] == 'A']
    d['skills'] = rd(os.path.join(HERE, '03_ONTOLOGY', 'SKILL_SCOPE.csv'))
    d['roles'] = rd(os.path.join(HERE, '02_DATA', 'DATASET_ROLE_MATRIX.csv'))
    d['abl'] = rd(os.path.join(IFE, '06_ABLATION', 'results.csv'))
    d['acc'] = {(r['task'], r['arm']): float(r['accuracy']) for r in d['abl']}
    dg = os.path.join(HERE, '08_GRAPHRAG', '_diag.json')
    d['diag'] = json.load(io.open(dg, encoding='utf-8')) if os.path.exists(dg) else {}
    d['l2'] = jl(os.path.join(HERE, '05_Q2_LEVEL2', 'results', 'level2_generated.jsonl'))
    d['l2chk'] = rd(os.path.join(HERE, '05_Q2_LEVEL2', 'results', 'AUTO_CHECK_L2.csv'))
    l3 = os.path.join(HERE, '06_Q2_LEVEL3', 'end_to_end', '_all_cases.json')
    d['l3'] = json.load(io.open(l3, encoding='utf-8')) if os.path.exists(l3) else []
    d['claims'] = rd(os.path.join(HERE, '09_CLAIMS', 'CLAIM_LEDGER.csv'))
    l1 = os.path.join(HERE, '04_Q2_LEVEL1', '_level1.json')
    d['l1'] = json.load(io.open(l1, encoding='utf-8')) if os.path.exists(l1) else {}
    rt = os.path.join(HERE, '10_INSTRUCTOR_QA', 'INSTRUCTOR_RED_TEAM.md')
    d['rt'] = {}
    if os.path.exists(rt):
        s = io.open(rt, encoding='utf-8').read()
        import re
        for k in ('SUPPORTED', 'PARTIAL', 'CANNOT CLAIM'):
            m = re.search(r'\|\s*%s\s*\|\s*(\d+)\s*\|' % re.escape(k), s)
            if m:
                d['rt'][k] = int(m.group(1))
    return d


def sec_q1(d):
    tA = d['tierA'][0]['name'] if d['tierA'] else '없음'
    direct = [s for s in d['skills'] if s['scd_evidence_tier'].startswith('DIRECT_SCD')]
    h = ['<section id="q1"><p class="k">질문 1</p>',
         '<h2>왜 이 대상이고, 어떤 데이터로 Ontology 범위를 정했나</h2>',
         '<div class="grid">',
         '<div class="st"><b>SCD 아동</b><span>문제 타겟</span></div>',
         '<div class="st"><b>일반 한국어</b><span>기술 benchmark</span></div>',
         '<div class="st"><b>%d</b><span>조사한 자료</span></div>' % len(d['census']),
         '<div class="st"><b>0</b><span>SCD 다운로드 가능 gold</span></div>',
         '</div>',
         '<h3>세 가지를 분리한다</h3>',
         tbl(['', '집단', '무엇에 답하나'],
             [['PROBLEM TARGET', '**SCD·SPCD 아동 6~12세**', '무엇을 훈련할 것인가'],
              ['TECHNICAL BENCHMARK', '**일반 한국어**', '핵심 화용 엔진이 도는가'],
              ['TARGET EFFECT', 'SCD 아동', '**이번에 검증하지 않음**']]),
         '<p class="warn">"일반 한국어 benchmark 에서 성능이 나왔으므로 SCD 아동에게 '
         '효과가 검증되었다" 고 말하지 않는다. 검증한 것은 <b>범용 화용 추론 기술의 성능</b>이다.</p>',
         '<h3>왜 아동인가 · 유병률이 아니다</h3>',
         '<p>아동(5~6세) 0~10.5%, 청소년(13~14세) 7~11% 로 유병률은 비슷하다. '
         '차이는 <b>행동을 실제로 잰 연구의 밀도</b>다. 아동에는 화용 과제를 돌린 표본'
         '(Lockton 2016, n=39)과 유병률 기준점(Saul 2023, n=386)이 있고, '
         '12세 위로는 자기보고 설문 한 코호트(Yoshinaga 2023, n=52)가 전부이며 '
         '행동 자료가 <b>0</b>이다.</p>',
         '<h3>Skill 별 SCD 근거 · 불편한 표</h3>',
         tbl(['Skill', '', 'SCD 근거 등급', '기술 검증'],
             [[s['skill_id'], s['skill_ko'], '**%s**' % s['scd_evidence_tier'],
               s['technical_validatability']] for s in d['skills'][:8]]),
         '<p class="warn"><b>어느 Skill 도 DSM-5 임상 진단 표본 근거가 없다.</b> '
         '우리 CORE 인 S1·S2 에는 SCD 표본 근거가 아예 없고 1980~90년대 영어 PLI 초록이 전부다. '
         'SCD 표본 근거가 있는 것은 %s 뿐이고 둘 다 라벨 기준이다.'
         % (' · '.join(s['skill_id'] for s in direct) or '없음'),
         '</p>',
         '<h3>데이터의 네 가지 역할</h3>',
         '<p>하나의 dataset 이 네 역할을 다 하리라 가정하지 않는다.</p>',
         tbl(['자료', '문제 근거', '기술 benchmark', '대화 재료'],
             [[r['dataset'], r['A_target_problem_grounding'],
               r['B_technical_benchmark'], r['C_scenario_dialogue_material']]
              for r in d['roles'][:8]]),
         '<h3>Ontology 는 하나다</h3>',
         '<p>L1 Ontology 위에 L3 생성 규격과 L4 변환 규칙이 얹힌 5층 구조다. '
         'Pragmatic Structure 와 SAME/NEAR/FAR 는 <b>새 Ontology 가 아니다.</b></p>',
         '<p class="warn"><b>Neo4j 는 떠 있지 않고</b> 벤치마크 하네스에 cypher 참조가 0건이다. '
         'E4 의 "Graph" 는 어휘 4마디짜리 메모리 구조다. 통합됐다고 말하지 않는다.</p>',
         dl([('근거', '자료 %d개 재감사 · SCD 연구 64편 등급 분류 · 지금 쓸 수 있는 benchmark 는 %s 하나'
              % (len(d['census']), tA)),
             ('결과', '온톨로지 7필드 중 직접 검증 가능한 것 2개. 문제 근거 집단과 benchmark 집단이 **다르다**'),
             ('한계', '**SCD 표본 benchmark 0건** (연령 불문). CORE S1·S2 에 SCD 근거 없음. 한국 학술DB 미조회'),
             ('지금 판단', '문제 타겟 = SCD 아동. 기술 benchmark = 일반 한국어. **합치지 않는다**')]),
         '</section>']
    return chr(10).join(h)


def sec_q2(d):
    l1 = d.get('l1', {})
    n = l1.get('n', 0)
    sk = l1.get('skill_same', 0)
    fa, fb = l1.get('per_grade_skill_same', {}).get('FAR', [0, 0])
    v02 = jl(os.path.join(HERE, '05_Q2_LEVEL2', 'v0_2_validation', 'v02_generated.jsonl'))
    h = ['<section id="q2"><p class="k">질문 2</p>',
         '<h2>실제 대화를 같은 능력의 다른 훈련상황으로 바꿀 수 있나</h2>',
         '<div class="grid">',
         '<div class="st"><b>%.2f</b><span>자연스러움 / 5</span></div>'
         % l1.get('naturalness_mean', 0),
         '<div class="st"><b>%d / %d</b><span>맥락 충분</span></div>'
         % (l1.get('context_sufficient', 0), n),
         '<div class="st"><b>%d / %d</b><span>같은 능력 유지</span></div>' % (sk, n),
         '<div class="st pend"><b>%d / %d</b><span>의도 FAR 중 같은 능력</span></div>'
         % (fa, fb),
         '</div>',
         '<div class="verd"><b>LEVEL 1 STATUS = REVISION REQUIRED</b><br>'
         '대화 자체의 자연스러움과 맥락 제공은 양호하다. 그러나 v0.1 의 Pragmatic Structure 와 '
         'Transfer Rule 은 Skill Identity 를 충분히 보존하지 못한다. '
         '<b>특히 FAR 변환은 같은 Skill 을 유지하지 못했다.</b></div>',
         '<h3>Skill Identity 와 Transfer Distance 를 섞지 않는다</h3>',
         '<p><code>DIFFERENT</code> 는 FAR 보다 <b>더 먼 것이 아니다.</b> 거리 축 위에 있지 않다. '
         '요구하는 화용 능력이 달라진 <b>질적 단절</b>이다. 그래서 거리 일치는 '
         'Skill=SAME 인 항목에서만 셌다 · <b>%d/%d</b>.</p>'
         % (l1.get('distance_agree_given_same', 0), sk),
         '<h3>의도 등급별 · 여기가 핵심이다</h3>',
         tbl(['의도 등급', 'Skill SAME', ''],
             [[g, '%d / %d' % tuple(l1.get('per_grade_skill_same', {}).get(g, [0, 0])),
               '**전멸**' if not l1.get('per_grade_skill_same', {}).get(g, [1])[0] else '']
              for g in ('SAME_CONTEXT', 'NEAR', 'FAR')]),
         '<p class="warn">멀리 보낼수록 같은 능력을 못 지키고, <b>FAR 에서는 아예 0 이다.</b> '
         '여섯 중 여섯이라 우연이 아니다.</p>',
         '<h3>왜 깨졌나 · 제도적 점프</h3>',
         '<p>FAR 여섯이 <b>전부 같은 이동</b>을 했다. 사적 · 또래 · 낮은 대가에서 '
         '제도적 · 상급자 · 높은 대가로 점프했다. v0.1 의 FAR 규칙이 '
         '"관계 또는 자리를 바꾸고 동시에 대가 또는 회복도 바꿔라" 였고, '
         '그 요구를 가장 쉽게 만족시키는 길이 이 점프다.</p>',
         '<p>그런데 이 점프는 다음 다섯을 <b>전부 같이</b> 끌고 간다.</p>',
         tbl(['바뀐 것', '사례'],
             [['interaction_goal 이 자리의 목적', 'R05 친구에게 근황 → 인턴이 결정 자리에서 보고'],
              ['speech_act 지금 하는 행위', 'R02 호의 부탁 → 근무 조정 요청'],
              ['responsibility_structure 누구 탓', 'R09 도움 청하기 → 내 지연 양해받기'],
              ['role_obligation 역할 의무', 'R11 조원 → 회사 대표'],
              ['request_entitlement 응할 의무', 'R12 친구 단톡 침묵 → 협조 메일 침묵']]),
         '<p class="warn"><b>우연이 아니라 규칙이 시킨 것이다.</b> '
         'v0.1 은 무엇을 추론해야 하는가는 붙들었지만 '
         '<b>어떤 사회적 행위를 하고 있는가</b>는 붙들지 않았다.</p>',
         '<h3>v0.2 에서 바꾼 것</h3>',
         '<p>위 다섯을 <b>CORE_INVARIANT</b> 로 올렸다. 어느 등급에서도 바꾸지 않는다. '
         '하나라도 바뀌면 FAR 가 아니라 <code>DIFFERENT</code> 로 분류하고 훈련 항목에서 뺀다.</p>',
         '<p>FAR 의 정의도 바꿨다. "많이 바꾼 상황" 이 아니라 '
         '<b>"표면 맥락은 크게 달라졌는데 요구하는 화용 능력은 그대로인 상황"</b> 이다. '
         '사적·또래에서 제도적 자리로 건너뛰는 것은 기본 금지다.</p>']
    if v02:
        ok = sum(1 for r in v02 if not r['unresolved'])
        inst = sum(1 for r in v02 for vs in (r['violations_by_attempt'] or [])
                   if vs and any('제도적 점프' in x for x in vs))
        # 사후 감사. 실행 때 판정을 고치지 않고 따로 센다
        sys.path.insert(0, os.path.join(HERE, '05_Q2_LEVEL2', 'v0_2_validation'))
        import posthoc_audit as PA
        dr = [r for r in v02 if PA.hits(PA.WORKPLACE, r['final_output'])]
        ms = [r for r in dr if not PA.hits(PA.RUNTIME, r['final_output'])]
        drift, missed = len(dr), len(ms)
        mgrades = sorted({r['distance'] for r in ms})
        sims = []
        for r in v02:
            raws = [a.get('raw', '') for a in r['all_attempts'] if a.get('raw')]
            if len(raws) >= 2:
                x, y = (''.join(z.split()) for z in raws[:2])
                sims.append(difflib.SequenceMatcher(None, x, y).ratio())
        sim = sum(sims) / len(sims) if sims else 0.0
        h += ['<h3>v0.2 최소 재검증</h3>',
              '<p>같은 모델 · 온도 · seed · 프롬프트 판 · 재시도 한도로 %d장면을 만들었다. '
              '프로토콜을 중간에 바꾸지 않았다.</p>' % len(v02),
              tbl(['', '값'],
                  [['규칙을 다 지킨 장면', '%d / %d' % (ok, len(v02))],
                   ['제도적 점프로 걸러진 시도', '%d회' % inst],
                   ['사람이 고친 문장', '0']]),
              '<p class="warn">이것은 <b>성능 발표가 아니다.</b> v0.1 에서 발견된 failure mode 가 '
              '줄었는지 보는 것이고, 의미 판정은 사람이 해야 한다 · '
              '<b>MANUAL CONFIRMATION PENDING</b>.</p>',
              '<h3>이 %d/%d 를 성과로 쓰지 않는다</h3>' % (ok, len(v02)),
              '<p>생성이 끝난 뒤 낱말을 넓혀 다시 세었다. 실행 때 판정은 고치지 않고 따로 적는다. '
              '실행 때 쓴 규칙은 <code>팀장 · 마감 · 결재</code> 같은 <b>어휘 표지만</b> 본다. '
              '<code>동료 · 회사 · 직장 · 업무 · 공식적</code> 은 목록에 없었다.</p>',
              tbl(['', '값'],
                  [['직장 프레임 낱말이 들어간 장면', '**%d / %d**' % (drift, len(v02))],
                   ['그중 실행 검사가 놓친 것', '**%d**' % missed],
                   ['놓친 등급', ' · '.join(mgrades)]]),
              '<p class="warn"><b>검사가 자기가 집행한다는 규칙보다 약했다.</b> '
              'SAME_CONTEXT 두 장면이 앵커의 친구·사적 모임에서 동료·회사 근처 카페로 갔는데 통과했다. '
              'SAME_CONTEXT 는 화제·장소·등장인물만 바꾸는 등급이다. '
              '검사를 강화해 다시 돌리지 않았다. 프로토콜을 중간에 바꾸지 않기로 했기 때문이다.</p>',
              '<h3>제도적 점프는 FAR 규칙만의 문제가 아니었다</h3>',
              '<p>실행 검사에 걸린 %d회가 전부 <b>NEAR</b> 에서 나왔다. '
              'NEAR 는 관계 또는 자리 중 하나만 바꾸는 등급이라 점프를 요구하지 않는다. '
              % inst +
              '넓힌 낱말로 보면 SAME_CONTEXT 에서도 나온다. '
              '<b>모델은 맥락을 바꾸라는 말을 들으면 직장 프레임으로 가는 것을 기본값으로 삼는다.</b> '
              'v0.1 진단은 "FAR 규칙이 시킨 것" 이었고 그것도 사실이지만 절반이다.</p>',
              '<p>재시도도 프레임을 바꾸지 않았다. 두 시도의 문자 일치율은 %.2f 라 글자는 '
              '절반쯤 달라지는데 <b>두 번 다 마감이 걸린 직장 장면</b>을 냈다.</p>' % sim,
              '<h3>열린 위험 · FAR 가 충분히 멀지 않을 수 있다</h3>',
              '<p>통과한 FAR 세 장면은 친구 → 친척 · 이웃으로 사적인 자리 안에서 움직인다. '
              '불변식은 살아남은 것으로 보이나 표면 거리가 짧다. '
              'v0.1 이 <b>멀지만 다른 과제</b>를 만들었다면 v0.2 는 <b>같은 과제지만 가까운 것</b>을 '
              '만들 수 있다. 문제를 반대편으로 옮긴 것인지 아직 모른다. '
              '거리는 자동 검사로 재지 않는다 · <code>05_Q2_LEVEL2/v0_2_validation/'
              'V02_VALIDATION_RESULT.md</code></p>',
              '<p>첫 실행은 버렸다. 턴 세는 검사기가 <b>따옴표가 있는 줄</b>을 세도록 짜여 있었고, '
              'v0.2 프롬프트에서 모델이 따옴표를 붙이지 않게 되면서 모든 장면이 0턴으로 걸렸다. '
              '검사기가 스펙이 아니라 모델의 우연한 서식 습관에 묶여 있었다. '
              '화자 라벨 기준으로 고쳐 손으로 쓴 픽스처 10개로 시험한 뒤 9장면을 처음부터 다시 돌렸다 · '
              '<code>05_Q2_LEVEL2/v0_2_validation/CHECKER_BUG_NOTE.md</code></p>']
    h += ['<h3>v0.1 의 Level 2 · Level 3 는 내렸다</h3>',
          '<p>규격 자체가 REVISION REQUIRED 를 받았고, 재시도 한도가 도중에 3→2 로 바뀐 '
          '혼합 프로토콜이며, 27항목을 다 돌리지 못했다. '
          '<code>05_Q2_LEVEL2/diagnostic_v0_1/</code> 에 <b>DIAGNOSTIC ONLY</b> 로 보존한다.</p>',
          dl([('근거', '팀 블라인드 검토 18장면 · 리뷰어가 기술 이름과 의도 등급을 모르는 상태'),
              ('결과', '대화는 좋다(자연스러움 %.2f · 맥락 %d/%d). **같은 능력 유지는 %d/%d, '
                     'FAR 는 %d/%d.**'
               % (l1.get('naturalness_mean', 0), l1.get('context_sufficient', 0), n,
                  sk, n, fa, fb)),
              ('한계', 'LEVEL 1 = **REVISION REQUIRED**. 리뷰어 1명 · 18장면. '
                     'v0.2 는 9장면만 만들었고 **사람 확인 전**이다'),
              ('지금 판단', '"맥락을 많이 바꾸면 Far Transfer" 가설이 **틀렸음을 실측으로 확인했다.** '
                        'v0.2 로 고쳤고 **이 수정 자체가 POC 의 결과다**')]),
          '</section>']
    return chr(10).join(h)


def sec_q3(d):
    a, dg = d['acc'], d['diag']
    e0 = a.get(('implicature', 'E0'))
    rows = []
    for arm, ko in (('E0', 'Plain LLM'), ('E1', 'Ontology 정의 (글)'),
                    ('E1F', '**길이 통제 · 무관한 글**'), ('E2', 'Ontology 구조 (JSON)'),
                    ('E3', 'Vector RAG'), ('E4', 'Graph 검색')):
        if ('implicature', arm) in a:
            rows.append([arm, ko, '%.3f' % a[('implicature', arm)],
                         '%.3f' % a.get(('maxim', arm), 0)])
    h = ['<section id="q3"><p class="k">질문 3</p>',
         '<h2>기술이 잘 됐다는 것을 무엇으로 평가하나</h2>',
         '<div class="grid">',
         '<div class="st"><b>0.25</b><span>우연 기준선</span></div>',
         '<div class="st"><b>0</b><span>Holm 보정 후 유의</span></div>',
         '<div class="st"><b>43%</b><span>향상 중 길이로 재현</span></div>',
         '<div class="st"><b>+0.000</b><span>입구를 정답으로 고쳤을 때</span></div>',
         '</div>',
         '<h3>사람이 쓴 한국어 화용 문항 40개 · 우연 25%</h3>',
         tbl(['갈래', '얹은 것', '함축', '격률'], rows),
         '<h3>1 · 온톨로지를 넣으면 좋아지는가</h3>',
         '<p>함축에서 0.475 → 0.650, 원p=0.039. <b>그러나 과제당 비교가 여섯이라 '
         'Holm 보정 후 0.196 이다.</b> 유의하지 않다.</p>',
         '<p class="warn">같은 길이의 <b>무관한 글</b>(문서 편집 규칙)을 넣어도 0.550 이 나왔다. '
         '<b>향상의 43%가 길이만으로 재현된다.</b> 내용 기여와 길이 기여를 지금 설계로 가르지 못한다.</p>',
         '<div class="verd"><b>ONTOLOGY-DEFINED CONTEXT BENEFIT SIGNAL</b> · 신호는 관찰됐다<br>'
         '<b>ONTOLOGY-SPECIFIC CAUSAL CONTRIBUTION = NOT ESTABLISHED</b></div>',
         '<h3>2 · 구조화가 프롬프트 글보다 나은가</h3>',
         '<p><b>반대다.</b> E1(정의를 그냥 씀) 0.650 이 E2(JSON) 0.475 보다 높다. '
         '가장 공들인 형식이 가장 나빴다.</p>']
    if dg:
        acc = dg.get('accuracy', {})
        lk = dg.get('linkers', {})
        h += ['<h3>3 · GraphRAG 는 왜 낮았나 · 단계별로 떼어 봤다</h3>',
              tbl(['링커', '개체 연결 정확도', ''],
                  [['EMB (지금)', '%.0f%%' % (lk.get('EMB', 0) * 100), '어휘 **정의**와 견준다 · 우연 수준'],
                   ['EXF', '%.0f%%' % (lk.get('EXF', 0) * 100), '닮은 **보기**를 먼저 찾는다'],
                   ['LLM', '%.0f%%' % (lk.get('LLM', 0) * 100), '100배 느리다'],
                   ['EMB@3', '%.0f%%' % (lk.get('EMB@3', 0) * 100), '상위 3개 안에 정답']]),
              tbl(['조건', '입구 정답률', '정확도'],
                  [['E4 지금 구현', '%.0f%%' % (dg['entry_correct'].get('E4', 0) * 100),
                    '%.3f' % acc.get('E4', 0)],
                   ['**E4-O 입구를 정답으로 고정**', '**100%**', '**%.3f**' % acc.get('E4-O', 0)],
                   ['E4-K2 상위 2개', '%.0f%%' % (dg['entry_correct'].get('E4-K2', 0) * 100),
                    '%.3f' % acc.get('E4-K2', 0)],
                   ['E5 하이브리드', '%.0f%%' % (dg['entry_correct'].get('E5', 0) * 100),
                    '%.3f' % acc.get('E5', 0)],
                   ['E4-O 1홉 (잘림 0)', '100%', '%.3f' % acc.get('E4-O-h1', 0)],
                   ['E4-O 3홉', '100%', '%.3f' % acc.get('E4-O-h3', 0)]]),
              '<p class="warn"><b>입구를 25%에서 100%로 올려도 정확도가 +0.000 이다.</b> '
              '들어가기 전 세운 가설("연결이 우연이니 그것부터 고치면 된다")을 '
              'oracle 시험이 <b>반증했다.</b> 홉을 늘려도, 잘림을 없애도 그대로다.</p>',
              '<p>문제는 꺼내 오는 <b>내용</b>이다. 그래프가 주는 것은 어휘 정의인데, '
              '그 정의는 E1 처럼 프롬프트에 그냥 쓰면 더 잘 듣는다 (0.650 &gt; %.3f).</p>'
              % acc.get('E4', 0),
              '<div class="verd"><b>MAIN BOTTLENECK = %s</b><br>'
              '<b>GRAPHRAG NECESSITY = NOT ESTABLISHED</b></div>' % dg.get('verdict', '?'),
              '<p>다만 여기서 진 것은 어휘 4마디짜리 얕은 그래프다. '
              '<b>개념 전체의 실패로 일반화하지 않는다.</b> 그래프가 값을 하려면 '
              '정의가 아니라 <b>정의로는 못 담는 것</b>(사례 간 관계 · 다중 홉 · 근거 추적)을 '
              '꺼내 와야 하고, 그것을 이번 구조로는 시험하지 못했다.</p>']
    h += ['<h3>격률 판정은 지금 안 된다</h3>',
          '<p>E0 가 %.3f 로 우연과 같고 가장 나은 갈래도 %.3f 다. '
          '"검증 가능한 필드" 인 것과 "실제로 해낸다" 는 다르다.</p>'
          % (a.get(('maxim', 'E0'), 0),
             max((v for (t, _x), v in a.items() if t == 'maxim'), default=0)),
          dl([('근거', '사람이 쓴 한국어 화용 문항 40개 · 우연 25% · 로컬 모델만 사용'),
              ('결과', '함축은 우연보다 뚜렷이 낫다. 온톨로지 조건에서 더 높은 신호가 보인다'),
              ('한계', '**Holm 보정 후 유의한 비교가 하나도 없다.** 향상의 43%가 길이로 재현된다. '
                     '격률은 우연 수준. GraphRAG 필요성 미확립'),
              ('지금 판단', '**범용 화용 추론 기술의 성능**까지만 말한다. '
                        '사용자 효과와 SCD 검증은 하지 않았다')]),
          '</section>']
    return chr(10).join(h)


def sec_claims(d):
    cl = d['claims']
    can = [c for c in cl if c['level'] in ('VALIDATED', 'SUPPORTED', 'DEMONSTRATED')]
    cant = [c for c in cl if c['level'] not in ('VALIDATED', 'SUPPORTED', 'DEMONSTRATED')]
    h = ['<section id="claims"><p class="k">마지막</p>',
         '<h2>무엇을 주장할 수 있고 무엇은 못 하는가</h2>',
         '<div class="two">',
         '<div><h3>할 수 있는 주장 · %d</h3><ul class="cl ok">' % len(can)]
    for c in can:
        h.append('<li><b>%s</b><span>%s</span><em>%s</em></li>'
                 % (md(c['level']), md(c['claim']), md(c['limitation'])))
    h += ['</ul></div><div><h3>못 하는 주장 · %d</h3><ul class="cl no">' % len(cant)]
    for c in cant:
        h.append('<li><b>%s</b><span>%s</span><em>%s</em></li>'
                 % (md(c['level']), md(c['claim']), md(c['limitation'])))
    h += ['</ul></div></div>']
    if d['rt']:
        r = d['rt']
        h += ['<h3>예상 질문 대비</h3>',
              '<p>질문 %d개에 판정을 붙였다. SUPPORTED %d · PARTIAL %d · CANNOT CLAIM %d. '
              '모르는 것을 억지로 방어하지 않는다. 전문은 <code>10_INSTRUCTOR_QA</code>.</p>'
              % (sum(r.values()), r.get('SUPPORTED', 0), r.get('PARTIAL', 0),
                 r.get('CANNOT CLAIM', 0))]
    h.append('</section>')
    return chr(10).join(h)


TPL = '''<!doctype html>
<html lang="ko"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>강사님 최종 보고</title>
<style>
:root{{--pg:#fbfaf7;--pg2:#f2f0e9;--pg3:#e8e4da;--ink:#1e1c18;--ink2:#575046;--ink3:#8a8276;
--rule:#dcd6c8;--acc:#7b4a2c;--no:#8d3c2e;--ok:#2f6b47;--pend:#8a6216;
--s:system-ui,"Segoe UI","Malgun Gothic",sans-serif;
--f:"Iowan Old Style","Palatino Linotype",Batang,serif;}}
@media(prefers-color-scheme:dark){{:root:not([data-theme=light]){{
--pg:#16150f;--pg2:#1e1c16;--pg3:#28241d;--ink:#ebe6da;--ink2:#b0a996;--ink3:#867e70;
--rule:#332f26;--acc:#d9946a;--no:#d98a78;--ok:#79b592;--pend:#d3a65c;}}}}
:root[data-theme=dark]{{--pg:#16150f;--pg2:#1e1c16;--pg3:#28241d;--ink:#ebe6da;
--ink2:#b0a996;--ink3:#867e70;--rule:#332f26;--acc:#d9946a;--no:#d98a78;--ok:#79b592;--pend:#d3a65c;}}
*{{box-sizing:border-box}}html,body{{overflow-x:clip}}
body{{margin:0;background:var(--pg);color:var(--ink);font-family:var(--s);font-size:15px;line-height:1.68}}
.w{{max-width:58rem;margin:0 auto;padding:0 1.3rem 5rem}}
header{{padding:3.4rem 0 1.8rem;border-bottom:2px solid var(--ink)}}
.k{{font-size:.66rem;letter-spacing:.18em;text-transform:uppercase;color:var(--acc);font-weight:700;margin:0 0 .6rem}}
h1{{font-family:var(--f);font-weight:600;font-style:normal;font-size:clamp(1.7rem,4.5vw,2.5rem);
margin:0 0 .8rem;line-height:1.18;overflow-wrap:anywhere;min-width:0}}
.lede{{color:var(--ink2);max-width:42rem;margin:0}}
section{{padding:2.6rem 0;border-bottom:1px solid var(--rule)}}
h2{{font-family:var(--f);font-weight:600;font-style:normal;font-size:clamp(1.25rem,3vw,1.75rem);
margin:0 0 1.3rem;line-height:1.25;overflow-wrap:anywhere;min-width:0}}
h3{{font-size:1rem;font-weight:650;margin:2rem 0 .6rem;padding-top:.8rem;border-top:1px solid var(--rule)}}
p{{margin:0 0 .85rem;max-width:44rem}}
.warn{{font-size:.88rem;color:var(--ink2);border-left:3px solid var(--no);padding:.6rem 0 .6rem 1rem;background:var(--pg2)}}
.verd{{border:1px solid var(--rule);border-left:3px solid var(--acc);background:var(--pg2);
padding:.8rem 1rem;margin:1rem 0;font-size:.9rem}}
.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,10rem),1fr));
gap:1px;background:var(--rule);border:1px solid var(--rule);margin:0 0 1.6rem}}
.st{{background:var(--pg);padding:.9rem 1rem}}
.st b{{display:block;font-family:var(--f);font-size:1.5rem;line-height:1;margin-bottom:.3rem}}
.st span{{font-size:.7rem;color:var(--ink3)}}
.st.pend b{{color:var(--pend);font-size:1.1rem;padding-top:.3rem}}
.tw{{overflow-x:auto;margin:0 0 1.2rem;border:1px solid var(--rule)}}
table{{border-collapse:collapse;width:100%;font-size:.85rem;min-width:26rem}}
th{{text-align:left;font-weight:650;background:var(--pg2);padding:.5rem .7rem;border-bottom:1px solid var(--rule);white-space:nowrap}}
td{{padding:.45rem .7rem;border-bottom:1px solid var(--rule);vertical-align:top}}
tr:last-child td{{border-bottom:0}}
dl.qs{{display:grid;grid-template-columns:auto 1fr;gap:1px;margin:2rem 0 0;background:var(--rule);border:1px solid var(--rule)}}
dl.qs dt{{background:var(--pg2);padding:.6rem .9rem;font-size:.66rem;font-weight:700;letter-spacing:.09em;color:var(--acc);white-space:nowrap}}
dl.qs dd{{background:var(--pg);padding:.6rem .9rem;margin:0;font-size:.87rem}}
@media(max-width:560px){{dl.qs{{grid-template-columns:1fr}}dl.qs dt{{padding-bottom:.2rem}}}}
.two{{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,19rem),1fr));gap:1.6rem}}
.cl{{list-style:none;padding:0;margin:0}}
.cl li{{padding:.6rem .8rem;background:var(--pg2);border-left:3px solid var(--rule);margin-bottom:.45rem}}
.cl.ok li{{border-left-color:var(--ok)}}.cl.no li{{border-left-color:var(--no)}}
.cl b{{display:block;font-size:.62rem;letter-spacing:.09em;color:var(--ink3);margin-bottom:.2rem}}
.cl span{{display:block;font-size:.86rem;margin-bottom:.25rem}}
.cl em{{display:block;font-style:normal;font-size:.75rem;color:var(--ink3)}}
code{{font-family:ui-monospace,Consolas,monospace;font-size:.85em;background:var(--pg3);padding:.1em .3em}}
footer{{padding:2.4rem 0 0;font-size:.78rem;color:var(--ink3)}}
</style></head><body><div class="w">
<header>
<p class="k">강사님 보고 · 2026-09-15</p>
<h1>내가 겪은 상황이, 다음 연습이 된다</h1>
<p class="lede">사회적 의사소통 개선을 위한 AI 대화 훈련. 세 질문 순서로 답한다.
답하지 못하는 것은 답하지 못한다고 적었다.</p>
</header>
{body}
<footer>
<p>숫자는 전부 같은 꾸러미의 CSV·JSONL 에서 읽어 만든다. 손으로 적은 숫자는 없다.
<code>python build_final_report.py</code> 로 다시 만든다.</p>
<p>KMI 예시 출처 · Kim, Hyunjong et al. NAACL 2025. CC BY 4.0.<br>
한국어 화용 평가셋 · Park, Dojun et al. PACLIC 38 (2024). 라이선스 없음 ·
집계 숫자만 싣고 원문 예시는 싣지 않는다.</p>
</footer>
</div></body></html>
'''


def main():
    d = g()
    body = chr(10).join([sec_q1(d), sec_q2(d), sec_q3(d), sec_claims(d)])
    io.open(OUT, 'w', encoding='utf-8', newline=chr(10)).write(TPL.format(body=body))
    print('보고서 · %s (%s bytes)' % (os.path.basename(OUT),
                                   format(os.path.getsize(OUT), ',')))
    print('  census %d · L2 %d · L3 %d · 주장 %d · 그래프 진단 %s'
          % (len(d['census']), len(d['l2']), len(d['l3']), len(d['claims']),
             d['diag'].get('verdict', '없음')))
    return 0


if __name__ == '__main__':
    sys.exit(main())
