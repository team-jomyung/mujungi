# Skill Scope · Level 1 결과 반영

외부 근거(SCD census)와 내부 결과(팀 블라인드 검토)를 **함께** 본다.

| Skill | | POC 역할 | 기술 검증 | SCD 근거 |
|---|---|---|---|---|
| S3 | 함축 · 비문자 의미 이해 | **PRIMARY_POC_CORE** | DIRECT_BENCHMARK | DIRECT_SCD_ALGORITHMIC |
| S1 | 청자 맞춤 정보 조절 | **SECONDARY** | PARTIAL_BENCHMARK | PLI_HISTORICAL_ONLY |
| S2 | 관계 · 상황 맞춤 조정 | **EXPLORATORY** | MANUAL_DEMO | PLI_HISTORICAL_ONLY |
| S4 | 응답성 · 상호성 | **FUTURE_CANDIDATE** | FUTURE_VALIDATION | DIRECT_SCD_ALGORITHMIC |

## 왜 이렇게 나눴나

### S3 함축 · 비문자 의미 이해 → PRIMARY_POC_CORE

- Level1 Skill SAME 4/6 로 가장 잘 버틴다 · 한국어 화용 문항이 직접 잰다

### S1 청자 맞춤 정보 조절 → SECONDARY

- Level1 2/6 · 양의 격률이 정보량 성분만 잰다

### S2 관계 · 상황 맞춤 조정 → EXPLORATORY

- Level1 2/6 · 외부 benchmark 없음 · 임상 근거도 가장 얇다

### S4 응답성 · 상호성 → FUTURE_CANDIDATE

- census 전체 중 유일한 한국어 SCD 근거(Jin & Pae 2014 n=15) · 아직 생성 대상 아님

## 근거 이상으로 확정하지 않는다

- S4 는 한국어 SCD 근거가 있는 유일한 기술이지만 **n=15 한 편 · 체크리스트 기준**이다.
  이것으로 CORE 를 바꾸지 않는다. FUTURE_CANDIDATE 로만 둔다.
- S3 를 PRIMARY 로 올린 것은 Level 1 결과(4/6)와 직접 benchmark 존재가 겹쳤기 때문이다.
- S2 는 Level 1 에서도 2/6 이고 외부 benchmark 도 없다. **제품에서 중요하지만 지금 잴 방법이 없다.**
  중요하지 않다는 뜻이 아니라 **아직 아무도 못 쟀다는 뜻이다.**
