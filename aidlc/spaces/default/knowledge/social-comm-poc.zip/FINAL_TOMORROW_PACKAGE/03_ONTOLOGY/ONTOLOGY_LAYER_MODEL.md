# Ontology 가 실제로 무엇인가

**"사회적 맥락 Ontology" 와 "문제 생성 Ontology" 두 개가 있는 것이 아니다.**
하나의 Ontology 위에 생성 규격과 변환 규칙이 얹혀 있다.

---

## 다섯 층

| 층 | 무엇 | 지금 실제 구현 | 형태 |
|---|---|---|---|
| L1 | Social Communication Ontology | `ontology/v0_3_freeze_candidate.yaml` | **YAML 규격** |
| L2 | Social Event Instance | `07_SOCIAL_EVENT/examples/*.json` | **JSON · 규칙으로 생성** |
| L3 | Pragmatic Structure Signature | Core 다섯 칸 (`target_skill` 외) | **JSON 필드** |
| L4 | Equivalence / Transfer Rule | SAME_CONTEXT · NEAR · FAR 정의 | **코드 + 문서** |
| L5 | Scenario Generator | `generate_l2.py` | **프롬프트 + LLM** |

L3 와 L4 는 **새로운 Ontology 가 아니다.** L1 위에서 쓰는
생성 규격(generation specification)과 변환 규칙(transfer rule)이다.

---

## 실제로 무엇이 그래프인가

**지금 살아 있는 그래프 데이터베이스는 없다.** 이것을 분명히 적는다.

| | 상태 |
|---|---|
| Neo4j 서버 | **안 떠 있다** (localhost:7474 응답 없음, 2026-09-15 확인) |
| `graph_out.zip` | 있다 (`~/Downloads/`). 팀원이 만든 CSV 31개 + Cypher |
| 벤치마크 하네스의 neo4j/cypher 참조 | **0건** (`grep` 실측) |
| E4 의 "Graph" | `kb.py` 의 파이썬 클래스. 메모리 위 인접 구조 |

즉 E4 실험에서 쓴 "GraphRAG" 는 **지식그래프 DB 질의가 아니다.**
어휘 4마디 · 온톨로지 조각 18 · 보기 40개 위의 얕은 인접 탐색이다.

**따라서 "온톨로지와 그래프가 하나로 통합되어 있다" 고 말하지 않는다.**
통합은 아직 안 됐다. E4 결과를 "지식그래프의 성능" 으로 일반화해서도 안 된다.

---

## 층마다 누가 만드나

| 층 | 사람이 정한 것 | 규칙이 만드는 것 | LLM 이 만드는 것 |
|---|---|---|---|
| L1 | 개념 · 관계 · 속성 (규격 동결) | — | — |
| L2 | 어느 필드를 채울지 | 참여자 · 역할 · 턴 · 언어 단서 | 해석 칸 (gold 없음) |
| L3 | 다섯 칸의 정의 | — | 값 자체는 사람/규격이 정함 |
| L4 | 등급 정의 | 바뀐 축 판정 | — |
| L5 | 프롬프트 · 규칙 | 규칙 위반 검사 | **장면 전체** |

L5 에서 나오는 문장은 전부 LLM 이 쓴 것이다.
Level 2 실험에서는 **사람이 그 문장에 손대지 않는다.**

---

## L1 이 담는 것 · 판정 일곱

`sc_ActAttribution` · `sc_InterpretationAttribution` · `sc_PhenomenonAttribution` ·
`sc_CueObservation` · `sc_GoalAttribution` · `sc_StrategyRecommendation` ·
`sc_StrategyAttribution`

이 중 **지금 공개 benchmark 로 직접 잴 수 있는 것은 둘**이다
(`VALIDATABLE_FIELDS.md` 참조).

---

## L3 Pragmatic Structure Signature · 다섯 칸

| 칸 | 무엇을 정하나 |
|---|---|
| `target_skill` | 알아채는 과제인가(RECOGNIZE) 말하는 과제인가(PRODUCT) |
| `required_inference` | 잘 해내려면 무엇을 짐작해야 하는가 |
| `perspective_structure` | 누구의 관점을 몇 층까지 따라가야 하는가 |
| `decidable_by_evidence` | 오간 말만으로 판정이 서는가 |
| `direct_check_allowed` | 대놓고 물어봐도 되는 자리인가 |

**이 다섯이 같으면 같은 능력을 요구한다고 본다.** 그것이 우리의 주장이고,
그 주장이 맞는지를 사람이 확인하는 것이 Level 1 이다.

---

## L4 변환 규칙

| 등급 | 바꾸는 것 | 그대로 두는 것 |
|---|---|---|
| SAME_CONTEXT | 화제 · 장소 · 등장인물 | 관계 · 자리 성격 · 대가 · 회복 가능성 |
| NEAR | 관계 **또는** 자리 성격 | 대가 · 회복 가능성 |
| FAR | 관계/자리 성격 **그리고** 대가/회복 | — |

어느 등급에서도 L3 다섯 칸은 **그대로 유지한다.**
그것이 "같은 능력을 요구하는 다른 상황" 의 정의다.

---

## 강사님이 물으실 만한 것

**"Pragmatic Structure 도 Ontology 인가?"**
아니다. L1 Ontology 의 값들을 조합해 만든 **생성 규격**이다.
새 개념을 도입하지 않는다.

**"SAME/NEAR/FAR 는 Ontology 인가?"**
아니다. L1 의 맥락 속성(관계 · 자리 · 대가 · 회복) 중 무엇을 바꾸느냐로 정의한
**변환 규칙**이다.

**"그럼 Ontology 가 두 개인가?"**
하나다. 위 표가 그 하나의 층 구조다.
