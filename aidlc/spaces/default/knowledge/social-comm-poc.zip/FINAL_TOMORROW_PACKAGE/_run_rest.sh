cd 05_Q2_LEVEL2/automatic_generation
python -u generate_l2.py --start 2 --append
cd ../../06_Q2_LEVEL3/end_to_end
python -u run_l3.py --n 3
