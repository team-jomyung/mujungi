# -*- coding: utf-8 -*-
"""내일 낼 물건을 검사한다.

    python verify_tomorrow.py

필수 항목 목록은 **강사에게 답해야 하는 세 질문에서 뽑는다.**
빌더가 실제로 찍은 heading 에서 뽑으면 검사가 자기가 감사할 물건을 기준으로 삼는 꼴이 된다.
이번 작업에서 그 실수를 여러 번 냈다.
"""
from __future__ import annotations

import io
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
REPORT = os.path.join(HERE, 'FINAL_INSTRUCTOR_REPORT.html')
ONEPAGE = os.path.join(HERE, '00_EXECUTIVE', 'TOMORROW_ONE_PAGE.html')

# 스펙에서 온 목록. 세 질문 각각에 이 네 가지가 있어야 한다.
PER_QUESTION = ('근거', '결과', '한계', '지금 판단')
QUESTIONS = ('q1', 'q2', 'q3')

# 이 낱말이 본문에 있으면 안 된다
FORBIDDEN = (
    ('{{', '치환 안 된 자리표시자'),
    ('TEAM REVIEW PENDING', '팀 검토 대기 문구가 남아 있다'),
    ('TODO', '할 일 표시가 남아 있다'),
    ('mock', 'mock 결과 언급'),
)
# 남아도 되는 PENDING 은 사람 확인 대기 하나뿐이다.
# 밑줄판과 공백판이 둘 다 쓰이므로 앞 스물다섯 자 안에 MANUAL 이 있으면 통과시킨다.
# 앞선 판은 \S*PENDING 으로 잡아서 공백판을 홑낱말 PENDING 으로 오인했다.
ALLOWED_PENDING = re.compile(r'MANUAL[\s_]?CONFIRMATION[\s_]?PENDING')


def strip_tags(h):
    h = re.sub(r'(?is)<(script|style)[^>]*>.*?</\1>', ' ', h)
    return re.sub(r'(?s)<[^>]+>', ' ', h)


def check_sections(html, bad):
    for q in QUESTIONS:
        m = re.search(r'(?s)<section id="%s".*?</section>' % q, html)
        if not m:
            bad.append('%s 절이 없다' % q.upper())
            continue
        body = strip_tags(m.group(0))
        for k in PER_QUESTION:
            if k not in body:
                bad.append('%s 에 "%s" 가 없다' % (q.upper(), k))


def check_words(html, bad):
    text = strip_tags(html)
    for w, why in FORBIDDEN:
        if w.lower() in text.lower():
            bad.append('%s · %s' % (why, w))
    for m in re.finditer(r'PENDING', text):
        around = text[max(0, m.start() - 30):m.end()]
        if not ALLOWED_PENDING.search(around):
            bad.append('허용되지 않은 PENDING · %s' % around[-40:].strip())
    # 치환 안 된 서식 지정자. 리스트 원소에 % 를 안 붙이면 그대로 찍혀 나온다
    for m in re.finditer(r'%[sdfr]|%\.\d+f', text):
        bad.append('치환 안 된 서식 · %s' % text[max(0, m.start() - 25):m.end() + 10].strip())


def check_tags(html, bad):
    for t in ('section', 'table', 'div'):
        o = len(re.findall(r'<%s[\s>]' % t, html))
        c = len(re.findall(r'</%s>' % t, html))
        if o != c:
            bad.append('<%s> 짝이 안 맞는다 · 연 %d · 닫은 %d' % (t, o, c))


def check_numbers(html, bad):
    """Q2 수치가 _level1.json 과 같은지 본다. 보고서 안에서 다시 계산하지 않는다."""
    p = os.path.join(HERE, '04_Q2_LEVEL1', '_level1.json')
    if not os.path.exists(p):
        bad.append('_level1.json 이 없다')
        return
    d = json.load(io.open(p, encoding='utf-8'))
    text = re.sub(r'\s+', ' ', strip_tags(html))
    want = [('%.2f' % d['naturalness_mean'], '자연스러움 평균'),
            ('%d / %d' % (d['context_sufficient'], d['n']), '맥락 충분'),
            ('%d / %d' % (d['skill_same'], d['n']), '같은 능력 유지'),
            ('%d / %d' % tuple(d['per_grade_skill_same']['FAR']), 'FAR 중 같은 능력')]
    for s, why in want:
        if s not in text:
            bad.append('%s 수치 %s 가 보고서에 없다' % (why, s))


def check_v02(bad):
    p = os.path.join(HERE, '05_Q2_LEVEL2', 'v0_2_validation', 'v02_generated.jsonl')
    if not os.path.exists(p):
        bad.append('v02_generated.jsonl 이 없다')
        return
    rows = [json.loads(x) for x in io.open(p, encoding='utf-8') if x.strip()]
    if len(rows) != 9:
        bad.append('v0.2 장면이 9가 아니라 %d' % len(rows))
    keys = ('prompt_version', 'checker_version', 'max_attempts', 'model', 'seed')
    for k in keys:
        vals = {r.get(k) for r in rows}
        if len(vals) > 1:
            bad.append('v0.2 프로토콜이 섞였다 · %s = %s' % (k, vals))
    if any(r.get('SEMANTIC_STATUS') != 'MANUAL_CONFIRMATION_PENDING' for r in rows):
        bad.append('v0.2 에 사람 확인 전 표시가 빠진 행이 있다')
    if any(r.get('human_edited') for r in rows):
        bad.append('v0.2 에 사람이 고친 행이 있다')


def check_markdown(bad):
    """md 산출물에도 낡은 대기 문구가 남아 있으면 안 된다.

    HTML 만 보다가 레드팀 문서에 "팀 검토 대기" 가 남아 있는 것을 놓친 적이 있다.
    """
    stale = ('TEAM_REVIEW_PENDING', 'TEAM MANUAL RESULT PENDING', '팀 검토 대기',
             '팀 검토가 진행 중')
    for root, dirs, files in os.walk(HERE):
        dirs[:] = [x for x in dirs if x not in ('__pycache__', 'diagnostic_v0_1')]
        for f in files:
            if not f.endswith('.md'):
                continue
            fp = os.path.join(root, f)
            body = io.open(fp, encoding='utf-8', errors='replace').read()
            for w in stale:
                if w in body:
                    bad.append('%s 에 낡은 대기 문구 · %s'
                               % (os.path.relpath(fp, HERE), w))
    # 있어야 할 파일
    for rel in ('04_Q2_LEVEL1/TEAM_MANUAL_RESULT.md',
                '04_Q2_LEVEL1/FAILURE_MODE_ANALYSIS.md',
                '03_ONTOLOGY/PRAGMATIC_STRUCTURE_v0_2.md',
                '03_ONTOLOGY/TRANSFER_RULE_v0_2.md',
                '09_CLAIMS/CLAIM_LEDGER_DELTA.md',
                '05_Q2_LEVEL2/v0_2_validation/CHECKER_BUG_NOTE.md'):
        if not os.path.exists(os.path.join(HERE, rel)):
            bad.append('없다 · %s' % rel)


def main():
    bad = []
    for p, label in ((REPORT, '보고서'), (ONEPAGE, '한 장')):
        if not os.path.exists(p):
            bad.append('%s 파일이 없다 · %s' % (label, p))
            continue
        html = io.open(p, encoding='utf-8').read()
        check_words(html, bad)
        check_tags(html, bad)
        if p == REPORT:
            check_sections(html, bad)
            check_numbers(html, bad)
    check_v02(bad)
    check_markdown(bad)

    if bad:
        print('막힌 것 %d' % len(bad))
        for b in bad:
            print('  X  %s' % b)
        return 1
    print('통과 · 세 질문 각각에 근거 · 결과 · 한계 · 지금 판단이 있다')
    print('     Q2 수치가 _level1.json 과 같다')
    print('     v0.2 9장면 · 프로토콜 단일 · 사람 확인 전 표시 있음')
    print('     md 산출물에 낡은 대기 문구 없음')
    return 0


if __name__ == '__main__':
    sys.exit(main())
