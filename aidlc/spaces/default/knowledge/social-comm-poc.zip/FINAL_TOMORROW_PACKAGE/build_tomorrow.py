# -*- coding: utf-8 -*-
"""내일 보여 줄 한 장과 세 질문 문서를 만든다. 숫자는 전부 파일에서 읽는다.

    python build_tomorrow.py

  00_EXECUTIVE/TOMORROW_ONE_PAGE.html
  00_EXECUTIVE/INSTRUCTOR_3_QUESTIONS.md

한 장에는 세 질문만 넣는다. 기술 스택 나열로 시작하지 않는다.
질문마다 EVIDENCE · RESULT · LIMITATION · CURRENT DECISION 넷만.
"""
from __future__ import annotations

import collections
import csv
import io
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, '..'))
IFE = os.path.join(ROOT, 'INSTRUCTOR_FINAL_EVIDENCE')


def rd(p):
    return list(csv.DictReader(io.open(p, encoding='utf-8-sig', newline=''))) \
        if os.path.exists(p) else []


def jl(p):
    out = []
    if os.path.exists(p):
        for x in io.open(p, encoding='utf-8'):
            x = x.strip()
            if x:
                try:
                    out.append(json.loads(x))
                except ValueError:
                    pass
    return out


def esc(t):
    return (str(t).replace('&', '&amp;').replace('<', '&lt;')
            .replace('>', '&gt;').replace('"', '&quot;'))


def md(t):
    out, b = [], False
    for part in esc(t).split('**'):
        out.append(('<b>%s</b>' % part) if b else part)
        b = not b
    return ''.join(out)


def gather():
    g = {}
    au = rd(os.path.join(IFE, '01_DATA', 'DATASET_EXECUTABILITY_AUDIT.csv'))
    g['census'] = [r for r in au if r['scope'] != 'OWN']
    g['tierA'] = [r for r in au if r['tier'] == 'A']
    g['skills'] = rd(os.path.join(HERE, '03_ONTOLOGY', 'SKILL_SCOPE.csv'))
    g['abl'] = rd(os.path.join(IFE, '06_ABLATION', 'results.csv'))
    g['acc'] = {(r['task'], r['arm']): float(r['accuracy']) for r in g['abl']}
    g['link'] = jl(os.path.join(IFE, '05_BENCHMARK', 'results', 'graph_link.jsonl'))
    g['garms'] = jl(os.path.join(IFE, '05_BENCHMARK', 'results', 'graph_arms.jsonl'))
    g['l2'] = jl(os.path.join(HERE, '05_Q2_LEVEL2', 'results', 'level2_generated.jsonl'))
    l3 = os.path.join(HERE, '06_Q2_LEVEL3', 'end_to_end', '_all_cases.json')
    g['l3'] = json.load(io.open(l3, encoding='utf-8')) if os.path.exists(l3) else []
    g['claims'] = rd(os.path.join(HERE, '09_CLAIMS', 'CLAIM_LEDGER.csv'))
    l1 = os.path.join(HERE, '04_Q2_LEVEL1', '_level1.json')
    g['l1'] = json.load(io.open(l1, encoding='utf-8')) if os.path.exists(l1) else {}

    # 링커 정확도
    lk = collections.defaultdict(lambda: [0, 0])
    for r in g['link']:
        lk[r['linker']][0] += bool(r['hit'])
        lk[r['linker']][1] += 1
    g['linkers'] = {k: (v[0], v[1], v[0] / v[1] if v[1] else 0) for k, v in lk.items()}

    # 그래프 팔 정확도 (다 돌린 것만)
    ga = collections.defaultdict(list)
    for r in g['garms']:
        ga[r['arm']].append(r)
    g['garm_acc'] = {k: (sum(1 for r in v if r['pred'] == r['gold']) / len(v), len(v))
                     for k, v in ga.items() if len(v) == 40}
    g['garm_entry'] = {k: sum(1 for r in v if r['entry_correct']) / len(v)
                       for k, v in ga.items() if len(v) == 40}
    g['garm_trunc'] = {k: sum(len(r['truncated_nodes']) for r in v) / len(v)
                       for k, v in ga.items() if len(v) == 40}
    return g


def q1(g):
    tA = g['tierA'][0]['name'] if g['tierA'] else '없음'
    direct = [s for s in g['skills'] if s['scd_evidence_tier'].startswith('DIRECT_SCD')]
    return dict(
        evidence=('SCD 관련 연구 64편을 등급별로 갈랐다. DSM-5 임상 진단 표본은 **5편**, '
                  '라벨 기준 12편, 과거 PLI 10편. 아동과 청소년의 **유병률은 비슷하다**'
                  '(5~6세 0~10.5%% · 13~14세 7~11%%).'),
        result=('차이는 유병률이 아니라 **누가 행동을 실제로 재 봤는가**다. '
                '아동에는 화용 과제를 실제로 돌린 표본(Lockton 2016, n=39)과 '
                '유병률 기준점(Saul 2023, n=386)이 있다. 12세 위로는 자기보고 설문 '
                '한 코호트(Yoshinaga 2023, n=52)가 전부이고 행동 자료가 **0**이다.'),
        limitation=('**SCD 표본에서 내려받을 수 있는 benchmark 는 0건**이다. 연령 불문. '
                    'S1·S2 에는 SCD 표본 근거가 아예 없고 1980~90년대 영어 PLI 초록이 전부다. '
                    '한국 학술DB 를 조회하지 못해 "한국 SCD 연구 0건" 은 조회 범위 안의 0건이다.'),
        decision=('문제 타겟 = **SCD 아동 6~12세**. 기술 benchmark = **일반 한국어**. '
                  '둘을 합치지 않는다. 지금 쓸 수 있는 benchmark 는 %s 하나뿐이고, '
                  'SCD 표본 근거가 있는 기술은 %s 뿐이다.'
                  % (tA, ' · '.join(s['skill_id'] for s in direct) or '없음')))


def q2(g):
    l1 = g.get('l1', {})
    sk, n = l1.get('skill_same', 0), l1.get('n', 0)
    far_a, far_b = l1.get('per_grade_skill_same', {}).get('FAR', [0, 0])
    return dict(
        evidence=('팀이 블라인드로 18장면을 검토했다. 세 단계로 나눈다 · '
                  '**Level 1** 규격이 쓸 만한가 · Level 2 자동 생성 · Level 3 공개 대화 End-to-End.'),
        result=('대화 자체는 좋다 · 자연스러움 **%.2f/5** · 맥락 충분 %d/%d · 정답 미노출 %d/%d. '
                '그런데 **같은 능력을 유지한 것은 %d/%d** 이고, '
                '**의도 FAR 는 %d/%d 로 하나도 살아남지 못했다.**'
                % (l1.get('naturalness_mean', 0), l1.get('context_sufficient', 0), n,
                   l1.get('no_answer_leak', 0), n, sk, n, far_a, far_b)),
        limitation=('LEVEL 1 STATUS = **REVISION REQUIRED**. '
                    'v0.1 의 Level 2 · Level 3 결과는 규격이 바뀌었으므로 **DIAGNOSTIC ONLY** 로 내렸다. '
                    'v0.2 최소 검증 9장면은 생성했고 자동 통과 8/9 지만 '
                    '**그 검사가 규칙 위반을 5장면 놓쳤다.** 사람 확인 전이다.'),
        decision=('"맥락을 많이 바꾸면 Far Transfer" 라는 가정이 **틀렸다.** '
                  'FAR 여섯이 전부 사적·또래에서 제도적·상급자로 점프하면서 '
                  '목적 · 화행 · 책임 · 의무 · 자격을 같이 바꿨다. '
                  'v0.2 에서 그 다섯을 **불변식으로 올렸다. 이 수정 자체가 결과다.** '
                  '다만 v0.2 실행에서 그 점프가 **NEAR 에서도 나왔다.** '
                  '규칙 탓만이 아니라 생성기의 기본 이동이다.'))


def q3(g):
    a = g['acc']
    ga = g['garm_acc']
    lk = g['linkers']
    e0 = a.get(('implicature', 'E0'))
    e1 = a.get(('implicature', 'E1'))
    ef = a.get(('implicature', 'E1F'))
    parts = []
    if e0 is not None:
        parts.append('E0 %.3f → E1(온톨로지) %.3f' % (e0, e1))
        if ef is not None:
            share = (ef - e0) / (e1 - e0) if e1 != e0 else 0
            parts.append('**길이만 맞춘 무관한 글도 %.3f** · 향상의 %.0f%%가 길이로 재현'
                         % (ef, share * 100))
    res = ' · '.join(parts) if parts else '실행 대기'
    lkline = ''
    if lk:
        lkline = (' 개체 연결 · 지금 링커 %.0f%% (우연 25%%) · 보기-우선 링커 %.0f%%'
                  % (lk.get('EMB', (0, 0, 0))[2] * 100, lk.get('EXF', (0, 0, 0))[2] * 100))
    gline = ''
    if ga:
        base = ga.get('E4', (0, 0))[0]
        best = max(ga.items(), key=lambda kv: kv[1][0])
        gline = ' 그래프 · 지금 %.3f · 가장 나은 조건 %s %.3f' % (base, best[0], best[1][0])
    return dict(
        evidence=('사람이 쓴 한국어 화용 문항(Park et al. PACLIC 38) 40문항. '
                  '우연 기준선 25%%. 로컬 모델만 써서 자료가 밖으로 나가지 않는다.'),
        result=res + '.' + lkline + gline,
        limitation=('**Holm 보정 뒤 유의한 비교가 하나도 없다.** 과제당 비교가 여섯이라 '
                    '원p 0.039 가 조정 후 0.196 이 된다. 40문항으로는 못 가른다. '
                    '격률 판정은 우연 수준이라 지금 안 된다.'),
        decision=('**ONTOLOGY-DEFINED CONTEXT BENEFIT SIGNAL** 까지만 말한다. '
                  '"온톨로지가 성능 향상을 증명했다" 고 하지 않는다. '
                  'GraphRAG 는 필요성이 서지 않았고, 원인은 개체 연결 단계다.'))


TPL = '''<!doctype html>
<html lang="ko"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>내일 한 장</title>
<style>
:root{{--pg:#fbfaf7;--pg2:#f2f0e9;--ink:#1e1c18;--ink2:#575046;--ink3:#8a8276;
 --rule:#dcd6c8;--acc:#7b4a2c;--no:#8d3c2e;--ok:#2f6b47;
 --s:system-ui,"Segoe UI","Malgun Gothic",sans-serif;
 --f:"Iowan Old Style","Palatino Linotype",Batang,serif;}}
@media(prefers-color-scheme:dark){{:root:not([data-theme=light]){{
 --pg:#16150f;--pg2:#1e1c16;--ink:#ebe6da;--ink2:#b0a996;--ink3:#867e70;
 --rule:#332f26;--acc:#d9946a;--no:#d98a78;--ok:#79b592;}}}}
:root[data-theme=dark]{{--pg:#16150f;--pg2:#1e1c16;--ink:#ebe6da;--ink2:#b0a996;
 --ink3:#867e70;--rule:#332f26;--acc:#d9946a;--no:#d98a78;--ok:#79b592;}}
*{{box-sizing:border-box}}html,body{{overflow-x:clip}}
body{{margin:0;background:var(--pg);color:var(--ink);font-family:var(--s);
 font-size:14.5px;line-height:1.6}}
.w{{max-width:54rem;margin:0 auto;padding:0 1.25rem 3rem}}
header{{padding:2.6rem 0 1.2rem;border-bottom:2px solid var(--ink)}}
.k{{font-size:.66rem;letter-spacing:.18em;text-transform:uppercase;color:var(--acc);
 font-weight:700;margin:0 0 .6rem}}
h1{{font-family:var(--f);font-weight:600;font-style:normal;font-size:clamp(1.5rem,4vw,2.1rem);
 margin:0 0 .5rem;line-height:1.2;overflow-wrap:anywhere;min-width:0}}
.sub{{color:var(--ink2);margin:0;font-size:.92rem}}
.sep{{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,15rem),1fr));
 gap:1px;background:var(--rule);border:1px solid var(--rule);margin:1.2rem 0 0}}
.sep>div{{background:var(--pg);padding:.8rem .9rem}}
.sep span{{display:block;font-size:.62rem;letter-spacing:.11em;text-transform:uppercase;
 color:var(--ink3);margin-bottom:.3rem}}
.sep b{{display:block;font-family:var(--f);font-size:1.02rem}}
.sep em{{font-style:normal;font-size:.74rem;color:var(--ink3)}}
section{{padding:1.8rem 0;border-bottom:1px solid var(--rule)}}
h2{{font-family:var(--f);font-weight:600;font-style:normal;font-size:1.18rem;
 margin:0 0 1rem;line-height:1.3;overflow-wrap:anywhere;min-width:0}}
h2 small{{display:block;font-family:var(--s);font-size:.64rem;letter-spacing:.16em;
 text-transform:uppercase;color:var(--acc);font-weight:700;margin-bottom:.35rem}}
dl{{display:grid;grid-template-columns:auto 1fr;gap:1px;margin:0;
 background:var(--rule);border:1px solid var(--rule)}}
dt{{background:var(--pg2);padding:.55rem .8rem;font-size:.63rem;font-weight:700;
 letter-spacing:.09em;color:var(--acc);white-space:nowrap}}
dd{{background:var(--pg);padding:.55rem .8rem;margin:0;font-size:.86rem}}
@media(max-width:560px){{dl{{grid-template-columns:1fr}}dt{{padding-bottom:.15rem}}}}
footer{{padding:1.6rem 0 0;font-size:.76rem;color:var(--ink3)}}
.no{{color:var(--no);font-weight:600}}
</style></head><body><div class="w">
<header>
<p class="k">내일 · 한 장</p>
<h1>내가 겪은 상황이, 다음 연습이 된다</h1>
<p class="sub">사회적 의사소통 개선을 위한 AI 대화 훈련. 세 질문에만 답한다.</p>
<div class="sep">
<div><span>Problem target</span><b>SCD 아동 6~12세</b><em>무엇을 훈련할 것인가</em></div>
<div><span>Technical benchmark</span><b>일반 한국어 화용</b><em>기술이 도는가</em></div>
<div><span>Target effect</span><b class="no">NOT TESTED</b><em>후속 사용자 연구</em></div>
</div>
</header>
{body}
<footer>
<p>숫자는 전부 같은 꾸러미의 CSV·JSONL 에서 읽어 만든다. 손으로 적은 숫자는 없다.
다시 만들려면 <code>python build_tomorrow.py</code>.</p>
<p>일반 한국어 benchmark 결과를 SCD 아동 효과로 말하지 않는다.
검증한 것은 <b>범용 화용 추론 기술의 성능</b>이다.</p>
</footer>
</div></body></html>
'''


def section(num, title, d):
    return ('<section><h2><small>질문 %s</small>%s</h2><dl>'
            '<dt>EVIDENCE</dt><dd>%s</dd>'
            '<dt>RESULT</dt><dd>%s</dd>'
            '<dt>LIMITATION</dt><dd>%s</dd>'
            '<dt>CURRENT DECISION</dt><dd>%s</dd>'
            '</dl></section>'
            % (num, esc(title), md(d['evidence']), md(d['result']),
               md(d['limitation']), md(d['decision'])))


def main():
    g = gather()
    qs = [('1', '왜 이 대상이고, 어떤 데이터로 Ontology 범위를 정했나', q1(g)),
          ('2', '실제 대화를 같은 능력의 다른 훈련상황으로 바꿀 수 있나', q2(g)),
          ('3', '기술이 잘 됐다는 것을 무엇으로 평가하나', q3(g))]
    body = chr(10).join(section(n, t, d) for n, t, d in qs)
    p = os.path.join(HERE, '00_EXECUTIVE', 'TOMORROW_ONE_PAGE.html')
    if not os.path.isdir(os.path.dirname(p)):
        os.makedirs(os.path.dirname(p))
    io.open(p, 'w', encoding='utf-8', newline=chr(10)).write(TPL.format(body=body))

    m = ['# 세 질문과 답', '']
    for n, t, d in qs:
        m += ['## Q%s · %s' % (n, t), '',
              '- **EVIDENCE** · %s' % d['evidence'],
              '- **RESULT** · %s' % d['result'],
              '- **LIMITATION** · %s' % d['limitation'],
              '- **CURRENT DECISION** · %s' % d['decision'], '']
    io.open(os.path.join(HERE, '00_EXECUTIVE', 'INSTRUCTOR_3_QUESTIONS.md'), 'w',
            encoding='utf-8', newline=chr(10)).write(chr(10).join(m))

    print('한 장 · %s (%s bytes)' % (os.path.basename(p),
                                   format(os.path.getsize(p), ',')))
    print('  census %d · TIER A %d · 링커 %d종 · 그래프 팔 %d · L2 %d · L3 %d'
          % (len(g['census']), len(g['tierA']), len(g['linkers']),
             len(g['garm_acc']), len(g['l2']), len(g['l3'])))
    return 0


if __name__ == '__main__':
    sys.exit(main())
