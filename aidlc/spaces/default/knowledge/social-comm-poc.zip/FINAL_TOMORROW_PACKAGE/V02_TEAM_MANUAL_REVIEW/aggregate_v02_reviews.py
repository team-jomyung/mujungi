# -*- coding: utf-8 -*-
"""리뷰어 CSV 를 모아 집계한다.

    python aggregate_v02_reviews.py

읽는 곳   review_results/*.csv   (리뷰어가 내려받은 파일을 그대로 넣는다)
쓰는 곳   V02_TEAM_REVIEW_SUMMARY.csv
          V02_TEAM_REVIEW_REPORT.md

집계 순서를 뒤집지 않는다
  1 같은 기술인가          SAME / DIFFERENT / UNSURE
  2 SAME 인 것만 골라 거리  SAME_CONTEXT / NEAR / FAR

DIFFERENT 를 FAR 로 바꾸지 않는다. 다른 과제가 된 것은 먼 과제가 아니라 다른 과제다.
"""
from __future__ import annotations

import collections
import csv
import glob
import io
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
INBOX = os.path.join(HERE, 'review_results')
KEY = os.path.join(HERE, 'V02_REVIEW_KEY.csv')
SUMMARY = os.path.join(HERE, 'V02_TEAM_REVIEW_SUMMARY.csv')
REPORT = os.path.join(HERE, 'V02_TEAM_REVIEW_REPORT.md')

GRADES = ('SAME_CONTEXT', 'NEAR', 'FAR')
SKILL_OPTS = ('SAME', 'DIFFERENT', 'UNSURE')
DIST_OPTS = ('SAME_CONTEXT', 'NEAR', 'FAR', 'UNSURE')

# 비교 대상. v0.1 팀 검토 결과다
V01 = dict(skill_same=8, n=18, far_same=0, far_n=6)

NL = chr(10)


def frac(a, b):
    return '%d/%d' % (a, b) + ('' if not b else ' (%.0f%%)' % (100.0 * a / b))


def load_key():
    if not os.path.exists(KEY):
        raise SystemExit('KEY 파일이 없다 · %s' % KEY)
    return {r['item_id']: r for r in csv.DictReader(io.open(KEY, encoding='utf-8-sig'))}


def load_reviews():
    rows = []
    for p in sorted(glob.glob(os.path.join(INBOX, '*.csv'))):
        with io.open(p, encoding='utf-8-sig', newline='') as fh:
            for r in csv.DictReader(fh):
                if not (r.get('item_id') or '').strip():
                    continue
                r['_file'] = os.path.basename(p)
                rows.append(r)
    return rows


def check(rows, key):
    bad = []
    seen = collections.defaultdict(set)
    for r in rows:
        iid = r['item_id'].strip()
        who = (r.get('reviewer_id') or '').strip()
        if iid not in key:
            bad.append('%s · 모르는 항목 %s' % (r['_file'], iid))
        if not who:
            bad.append('%s · 이름이 빈 줄이 있다' % r['_file'])
        if r.get('skill_identity') not in SKILL_OPTS:
            bad.append('%s · %s 의 Q1 값이 이상하다 · %r'
                       % (r['_file'], iid, r.get('skill_identity')))
        d = (r.get('transfer_distance') or '').strip()
        if r.get('skill_identity') == 'SAME':
            if d not in DIST_OPTS:
                bad.append('%s · %s 는 SAME 인데 Q2 가 비었다' % (r['_file'], iid))
        elif d:
            bad.append('%s · %s 는 SAME 이 아닌데 Q2 가 채워져 있다' % (r['_file'], iid))
        if iid in seen[who]:
            bad.append('%s · %s 가 %s 를 두 번 답했다' % (r['_file'], who, iid))
        seen[who].add(iid)
    for who, ids in seen.items():
        miss = sorted(set(key) - ids)
        if miss:
            bad.append('%s 가 답하지 않은 항목 %d개 · %s' % (who, len(miss), ', '.join(miss)))
    return bad


def fleiss(table):
    """table · 항목별 [범주 수] 리스트. 평가자 수가 항목마다 같아야 한다."""
    if not table:
        return None
    n = sum(table[0])
    if n < 2 or any(sum(r) != n for r in table):
        return None
    N, k = len(table), len(table[0])
    p_j = [sum(r[j] for r in table) / float(N * n) for j in range(k)]
    P_i = [(sum(c * c for c in r) - n) / float(n * (n - 1)) for r in table]
    Pbar = sum(P_i) / N
    Pe = sum(p * p for p in p_j)
    if abs(1 - Pe) < 1e-12:
        return None
    return (Pbar - Pe) / (1 - Pe)


def majority(vals, opts):
    """가장 많이 나온 값. 동률이면 None."""
    c = collections.Counter(v for v in vals if v in opts)
    if not c:
        return None
    top = c.most_common()
    if len(top) > 1 and top[0][1] == top[1][1]:
        return None
    return top[0][0]


def build_summary(rows, key):
    """항목별 한 줄. 여러 리뷰어면 분포와 다수 의견을 함께 적는다."""
    by_item = collections.defaultdict(list)
    for r in rows:
        by_item[r['item_id'].strip()].append(r)
    out = []
    for iid in sorted(key):
        k = key[iid]
        rs = by_item.get(iid, [])
        sk = [r.get('skill_identity', '') for r in rs]
        ds = [r.get('transfer_distance', '') for r in rs
              if r.get('skill_identity') == 'SAME']
        row = collections.OrderedDict()
        row['item_id'] = iid
        row['source_anchor_id'] = k['source_anchor_id']
        row['intended_skill'] = k['intended_skill']
        row['intended_distance'] = k['intended_distance']
        row['n_reviewers'] = len(rs)
        for o in SKILL_OPTS:
            row['skill_' + o] = sk.count(o)
        row['skill_majority'] = majority(sk, SKILL_OPTS) or ''
        for o in DIST_OPTS:
            row['dist_' + o] = ds.count(o)
        row['dist_majority'] = majority(ds, DIST_OPTS) or ''
        row['distance_matches_intent'] = (
            'YES' if row['dist_majority'] == k['intended_distance']
            else ('' if not row['dist_majority'] else 'NO'))
        row['issues'] = '|'.join(sorted({x for r in rs
                                         for x in (r.get('scene_issue') or '').split('|')
                                         if x and x != 'NONE'}))
        out.append(row)
    return out


def rates(rows, key):
    """사람-항목 응답 하나하나를 센다. 리뷰어가 여럿이면 응답 수가 늘어난다."""
    st = dict(n=0, same=0,
              per_grade=collections.defaultdict(lambda: [0, 0]),
              per_skill=collections.defaultdict(lambda: [0, 0]),
              per_anchor=collections.defaultdict(lambda: [0, 0]),
              agree=[0, 0],
              agree_by_grade=collections.defaultdict(lambda: [0, 0]),
              far_same=[0, 0], far_far=[0, 0],
              per_reviewer=collections.defaultdict(lambda: [0, 0]))
    for r in rows:
        k = key.get(r['item_id'].strip())
        if not k:
            continue
        g, s, a = k['intended_distance'], k['intended_skill'], k['source_anchor_id']
        who = (r.get('reviewer_id') or '').strip()
        same = r.get('skill_identity') == 'SAME'
        st['n'] += 1
        st['same'] += 1 if same else 0
        for bucket, kk in ((st['per_grade'], g), (st['per_skill'], s),
                           (st['per_anchor'], a), (st['per_reviewer'], who)):
            bucket[kk][1] += 1
            bucket[kk][0] += 1 if same else 0
        if g == 'FAR':
            st['far_same'][1] += 1
            st['far_same'][0] += 1 if same else 0
            st['far_far'][1] += 1
            if same and r.get('transfer_distance') == 'FAR':
                st['far_far'][0] += 1
        # 거리는 같은 기술이라고 본 응답에서만 센다
        if same:
            st['agree'][1] += 1
            st['agree_by_grade'][g][1] += 1
            if r.get('transfer_distance') == g:
                st['agree'][0] += 1
                st['agree_by_grade'][g][0] += 1
    return st


def report(rows, key, st, summary, bad):
    reviewers = sorted({(r.get('reviewer_id') or '').strip() for r in rows})
    nrev = len(reviewers)
    h = ['# v0.2 팀 블라인드 검토 결과', '',
         '읽는 곳 · `review_results/*.csv` · 리뷰어 %d명 · 응답 %d건'
         % (nrev, st['n']), '',
         '리뷰어는 기술 이름도 의도한 등급도 모르는 상태로 답했다.', '']
    if bad:
        h += ['## 먼저 볼 것 · 자료에 문제가 있다', '']
        h += ['- %s' % b for b in bad]
        h += ['', '아래 수치는 이 문제를 안은 채로 센 것이다.', '']

    h += ['## 한눈에', '',
          '| | v0.1 | v0.2 |', '|---|---|---|',
          '| Skill Preservation | %s | **%s** |'
          % (frac(V01['skill_same'], V01['n']), frac(st['same'], st['n'])),
          '| FAR Skill Preservation | %s | **%s** |'
          % (frac(V01['far_same'], V01['far_n']), frac(*st['far_same'])),
          '| FAR Distance Success | 잰 적 없음 | **%s** |' % frac(*st['far_far']),
          '',
          '`FAR Distance Success` 는 의도 FAR 중 **같은 기술로 읽히면서 거리도 FAR 로 읽힌** 비율이다.',
          '']

    h += ['## STEP 1 · 같은 기술인가', '',
          '전체 %s' % frac(st['same'], st['n']), '',
          '| 의도 등급 | Skill SAME |', '|---|---|']
    for g in GRADES:
        h.append('| %s | %s |' % (g, frac(*st['per_grade'][g])))
    h += ['', '| 기술 | Skill SAME |', '|---|---|']
    for s in sorted(st['per_skill']):
        h.append('| %s | %s |' % (s, frac(*st['per_skill'][s])))
    h += ['', '| 원본 | Skill SAME |', '|---|---|']
    for a in sorted(st['per_anchor']):
        h.append('| %s | %s |' % (a, frac(*st['per_anchor'][a])))
    h += ['']

    h += ['## STEP 2 · 같다고 본 것만 놓고 거리', '',
          'DIFFERENT 는 여기 들어오지 않는다. **먼 과제가 아니라 다른 과제**이기 때문이다.', '',
          '의도한 등급과 읽힌 등급이 맞은 비율 · %s' % frac(*st['agree']), '',
          '| 의도 등급 | 읽힌 등급이 같음 |', '|---|---|']
    for g in GRADES:
        h.append('| %s | %s |' % (g, frac(*st['agree_by_grade'][g])))
    h += ['']

    h += ['## 항목별', '',
          '| 항목 | 원본 | 의도 | Skill 분포 | 거리 분포 | 의도와 맞나 |',
          '|---|---|---|---|---|---|']
    for r in summary:
        sk = ' · '.join('%s %d' % (o[:4], r['skill_' + o]) for o in SKILL_OPTS
                        if r['skill_' + o])
        ds = ' · '.join('%s %d' % (o[:4], r['dist_' + o]) for o in DIST_OPTS
                        if r['dist_' + o])
        h.append('| %s | %s | %s | %s | %s | %s |'
                 % (r['item_id'], r['source_anchor_id'], r['intended_distance'],
                    sk or '-', ds or '-', r['distance_matches_intent'] or '-'))
    h += ['']

    if nrev >= 2:
        h += ['## 리뷰어별', '', '| 리뷰어 | Skill SAME |', '|---|---|']
        for w in reviewers:
            h.append('| %s | %s |' % (w or '(이름 없음)', frac(*st['per_reviewer'][w])))
        h += ['']
        tab = [[r['skill_' + o] for o in SKILL_OPTS] for r in summary]
        k1 = fleiss(tab)
        ds_tab = [[r['dist_' + o] for o in DIST_OPTS] for r in summary
                  if sum(r['dist_' + o] for o in DIST_OPTS) == nrev]
        k2 = fleiss(ds_tab) if ds_tab else None
        h += ['### 평가자 간 일치', '',
              '| | 값 | 표본 |', '|---|---|---|',
              '| Skill Identity · Fleiss κ | %s | 항목 %d · 리뷰어 %d |'
              % ('%.3f' % k1 if k1 is not None else '못 구함', len(tab), nrev),
              '| Transfer Distance · Fleiss κ | %s | 항목 %d (모두가 SAME 으로 본 것만) |'
              % ('%.3f' % k2 if k2 is not None else '못 구함', len(ds_tab)),
              '',
              '항목이 9개이고 리뷰어가 %d명이다. **이 κ 로 무엇을 확정하지 않는다.**' % nrev,
              '']
    else:
        h += ['## 평가자 간 일치', '',
              '리뷰어가 1명이라 계산하지 않는다. 한 사람의 판정이다.', '']

    fs, fsn = st['far_same']
    ff, ffn = st['far_far']
    h += ['## 읽는 법', '']
    if fsn == 0:
        h += ['의도 FAR 응답이 없다. 판단할 것이 없다.', '']
    else:
        h += ['의도 FAR %d건 중 같은 기술로 읽힌 것 %d건, 그중 거리도 FAR 로 읽힌 것 %d건이다.'
              % (fsn, fs, ff), '']
        if fs > 0 and ff * 2 < fs:
            h += ['**같은 기술은 지켰는데 FAR 만큼 멀어지지는 않았다.**',
                  'v0.1 은 멀리 보내느라 다른 과제를 만들었다. '
                  'v0.2 가 같은 과제를 지키느라 가까운 것을 만들었다면 '
                  '문제를 반대편으로 옮긴 것이다. 규칙이 과하게 보수적으로 바뀌었는지 본다.', '']
        elif fs == 0:
            h += ['**FAR 에서 같은 기술이 하나도 유지되지 않았다.** v0.1 과 같은 자리다.', '']
        else:
            h += ['같은 기술을 지키면서 FAR 로도 읽힌 항목이 있다. '
                  '다만 표본이 %d건이라 여기서 성공을 선언하지 않는다.' % fsn, '']

    h += ['## 이 표로 말하지 않는 것', '',
          '- 리뷰어 %d명 · 항목 9개다. 통계적 확정이 아니다.' % nrev,
          '- 같은 앵커에서 나온 항목이 서로 독립이 아니다.',
          '- v0.1 은 18항목 · v0.2 는 9항목이라 두 비율을 바로 견주기 어렵다.',
          '- 장면을 만든 모델과 규격이 같으므로 규격의 효과와 모델의 습관이 섞여 있다.',
          '']
    return NL.join(h)


def main():
    key = load_key()
    if not os.path.isdir(INBOX):
        os.makedirs(INBOX)
        print('%s 를 만들었다. 리뷰어 CSV 를 여기에 넣고 다시 돌려라.' % INBOX)
        return 2
    rows = load_reviews()
    if not rows:
        print('%s 안에 CSV 가 없다.' % INBOX)
        return 2

    bad = check(rows, key)
    summary = build_summary(rows, key)
    st = rates(rows, key)

    with io.open(SUMMARY, 'w', encoding='utf-8-sig', newline='') as fh:
        w = csv.DictWriter(fh, fieldnames=list(summary[0].keys()))
        w.writeheader()
        w.writerows(summary)
    io.open(REPORT, 'w', encoding='utf-8', newline=NL).write(report(rows, key, st,
                                                                   summary, bad))

    nrev = len({(r.get('reviewer_id') or '').strip() for r in rows})
    print('리뷰어 %d · 응답 %d' % (nrev, st['n']))
    print('SKILL_PRESERVATION      %s' % frac(st['same'], st['n']))
    print('FAR_SKILL_PRESERVATION  %s' % frac(*st['far_same']))
    print('FAR_DISTANCE_SUCCESS    %s' % frac(*st['far_far']))
    if bad:
        print()
        print('자료 문제 %d건 · 보고서 첫머리에 적었다' % len(bad))
        for b in bad[:5]:
            print('  !  %s' % b)
    print()
    print('  %s' % os.path.basename(SUMMARY))
    print('  %s' % os.path.basename(REPORT))
    return 0


if __name__ == '__main__':
    sys.exit(main())
