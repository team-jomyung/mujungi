# -*- coding: utf-8 -*-
"""검토 페이지가 블라인드인지, 장면이 제대로 붙었는지 본다.

    python verify_review_page.py

기준은 원본 jsonl 과 KEY 파일에서 가져온다. HTML 이 찍어 낸 것에서 기대값을 뽑지 않는다.
"""
from __future__ import annotations

import csv
import io
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
PAGE = os.path.join(HERE, 'V02_MANUAL_REVIEW.html')
KEY = os.path.join(HERE, 'V02_REVIEW_KEY.csv')
SRC = os.path.join(HERE, '..', '05_Q2_LEVEL2', 'v0_2_validation', 'v02_generated.jsonl')

# 이 낱말이 리뷰어 화면에 있으면 안 된다. ASCII 는 한글이 붙어도 잡히게 전후방탐색을 쓴다
FORBID_ASCII = re.compile(
    r'(?<![A-Za-z0-9_])(V2-S[0-9]|S1|S2|S3|S4|intended_skill|intended_distance|'
    r'spec_version|prompt_version|checker_version|core_invariants|violations|'
    r'unresolved|anchor_id|SEMANTIC_STATUS|exaone|bge-m3)(?![A-Za-z0-9_])')
FORBID_KO = re.compile(
    r'(제도적 점프|불변식|앵커|의도한 (거리|등급)|자동 검사|규칙 위반|'
    r'화용 구조|전이 규칙|Pragmatic Structure|Transfer Rule|failure mode)')
# 등급 이름은 Q2 보기에만 있어야 한다
GRADE = re.compile(r'(?<![A-Za-z0-9_])(SAME_CONTEXT|NEAR|FAR|DIFFERENT|SAME|UNSURE)'
                   r'(?![A-Za-z0-9_])')
# 장면 칸 안에서 무언가를 안 보이게 만드는 표시
HIDDEN = re.compile(r'(?i)(\shidden[\s>=]|display\s*:\s*none|visibility\s*:\s*hidden|'
                    r'opacity\s*:\s*0(?![.\d]))')


def strip_tags(h):
    h = re.sub(r'(?is)<(script|style)[^>]*>.*?</\1>', ' ', h)
    h = re.sub(r'(?s)<[^>]+>', ' ', h)
    # 엔티티를 풀지 않고 비교하면 따옴표가 든 장면이 전부 다르다고 나온다
    for a, b in (('&quot;', '"'), ('&lt;', '<'), ('&gt;', '>'), ('&amp;', '&')):
        h = h.replace(a, b)
    return h


def norm(t):
    """견줄 수 있게 고른다.

    구분선만 있는 줄과 굵게 표시는 화면에 안 올라가므로 양쪽에서 똑같이 뺀다.
    이 규칙을 빌더에서 가져오지 않고 여기 따로 적는다.
    빌더의 렌더러를 기준으로 삼으면 렌더러가 문장을 빠뜨려도 통과한다.
    """
    keep = [ln for ln in (t or '').split(chr(10))
            if ln.strip() and not set(ln.strip()) <= set('-—_= ')]
    return re.sub(r'\s+', '', chr(10).join(keep)).replace('*', '')


def scene_text(block):
    """장면 칸에서 제목을 떼고 본문만 꺼낸다."""
    return strip_tags(re.sub(r'(?s)<h3>.*?</h3>', ' ', block))


def items_of(html):
    return re.findall(r'(?s)<section class="item" data-id="([^"]+)">(.*?)</section>', html)


def scenes_of(chunk):
    """장면 칸을 (반, 속) 으로 돌려준다. 반은 원본 · 새것 어느 쪽인지 가른다."""
    return re.findall(r'(?s)<article class="(scene[^"]*)">(.*?)</article>', chunk)


def main():
    bad = []
    html = io.open(PAGE, encoding='utf-8').read()
    key = list(csv.DictReader(io.open(KEY, encoding='utf-8-sig')))
    src = {r['item_id']: r for r in
           (json.loads(x) for x in io.open(SRC, encoding='utf-8') if x.strip())}

    its = items_of(html)
    if len(its) != 9:
        bad.append('항목이 9가 아니라 %d' % len(its))
    if [i for i, _ in its] != ['V2-R%02d' % n for n in range(1, len(its) + 1)]:
        bad.append('항목 이름이 V2-R01..09 가 아니다 · %s' % [i for i, _ in its])
    if len(key) != len(its):
        bad.append('KEY 행 %d · 항목 %d' % (len(key), len(its)))

    # 장면이 제대로 붙었나. 기준은 jsonl 이다
    kmap = {r['item_id']: r for r in key}
    for iid, chunk in its:
        sc = scenes_of(chunk)
        if len(sc) != 2:
            bad.append('%s 장면 칸이 2가 아니라 %d' % (iid, len(sc)))
            continue
        k = kmap.get(iid)
        if not k:
            bad.append('%s 가 KEY 에 없다' % iid)
            continue
        s = src.get(k['generation_id'])
        if not s:
            bad.append('%s 의 생성 원본 %s 을 못 찾겠다' % (iid, k['generation_id']))
            continue
        # 어느 칸이 원본인지. 반과 제목이 둘 다 맞아야 한다
        for (cls, blk), want_cls, want_h in ((sc[0], 'scene', '원본 상황'),
                                             (sc[1], 'scene new', '새로운 상황')):
            if cls.strip() != want_cls:
                bad.append('%s 장면 칸 반이 %r 여야 하는데 %r' % (iid, want_cls, cls))
            h = re.search(r'<h3>(.*?)</h3>', blk)
            if not h or h.group(1).strip() != want_h:
                bad.append('%s 장면 제목이 %r 가 아니다 · %s'
                           % (iid, want_h, h.group(1) if h else '없음'))
        if norm(scene_text(sc[0][1])) != norm(s['anchor_scene']):
            bad.append('%s 원본 장면이 jsonl 과 다르다' % iid)
        if norm(scene_text(sc[1][1])) != norm(s['final_output']):
            bad.append('%s 새 장면이 jsonl 과 다르다' % iid)
        # 글자가 남아 있어도 안 보이면 못 읽는다. 장면 칸에는 숨긴 것이 없어야 한다
        for _cls, blk in sc:
            if HIDDEN.search(blk):
                bad.append('%s 장면 안에 숨겨진 줄이 있다' % iid)
                break

    # 한 앵커의 셋이 등급 순서대로 놓이지 않았나
    rank = {'SAME_CONTEXT': 0, 'NEAR': 1, 'FAR': 2}
    for a in sorted({r['source_anchor_id'] for r in key}):
        seq = [rank[r['intended_distance']] for r in key if r['source_anchor_id'] == a]
        if seq == sorted(seq) or seq == sorted(seq, reverse=True):
            bad.append('%s 의 셋이 등급 순서대로 놓였다' % a)
    for i in range(len(key) - 1):
        if key[i]['source_anchor_id'] == key[i + 1]['source_anchor_id']:
            bad.append('%s 와 %s 가 같은 앵커로 붙어 있다'
                       % (key[i]['item_id'], key[i + 1]['item_id']))

    # 블라인드. 화면에 남는 글자만 본다
    text = strip_tags(html)
    for m in FORBID_ASCII.finditer(text):
        bad.append('화면에 규격 낱말 · %s' % m.group(0))
    for m in FORBID_KO.finditer(text):
        bad.append('화면에 연구자 용어 · %s' % m.group(0))

    # 등급 이름이 장면 글 안에 있으면 안 된다.
    # Q1 · Q2 보기와 Q3 안내문에는 있어야 하므로 장면 칸만 본다.
    for iid, chunk in its:
        for _cls, blk in scenes_of(chunk):
            for m in GRADE.finditer(strip_tags(blk)):
                bad.append('%s 장면 안에 등급 이름 · %s' % (iid, m.group(0)))
        head = re.search(r'(?s)<header class="ih">.*?</header>', chunk)
        if head and GRADE.search(strip_tags(head.group(0))):
            bad.append('%s 머리에 등급 이름' % iid)

    # 원본 장면 자체에 규격 enum 이 남아 있나 (있으면 고치지 않고 알린다)
    warn = []
    enum = re.compile(r'(?<![A-Za-z0-9_])(FRIEND_CASUAL|FRIEND_PRIVATE|CLUB_SENIOR|'
                      r'TEAMMATE|SCHOOL_GROUP|DORM_SENIOR|PROFESSOR|INTERN_SUPERVISOR|'
                      r'CROSS_TEAM|CLIENT|SCHOOL_OFFICIAL|CLUB|DORM|WORK)'
                      r'(?![A-Za-z0-9_])')
    for iid, chunk in its:
        for m in enum.finditer(strip_tags(chunk)):
            warn.append('%s 장면 본문에 규격 값 · %s' % (iid, m.group(0)))

    # Q2 는 처음에 잠겨 있어야 한다
    if len(re.findall(r'<fieldset class="q q2" disabled>', html)) != len(its):
        bad.append('Q2 가 처음부터 잠겨 있지 않은 항목이 있다')

    # 혼자 도는가
    for m in re.finditer(r'(?i)(src|href)\s*=\s*"(https?:)?//', html):
        bad.append('바깥을 부른다 · %s' % m.group(0))
    if re.search(r'(?i)\b(fetch|XMLHttpRequest|importScripts)\s*\(', html):
        bad.append('네트워크 호출이 들어 있다')

    for w in warn:
        print('  !  %s' % w)
    if bad:
        print('막힌 것 %d' % len(bad))
        for b in bad:
            print('  X  %s' % b)
        return 1
    print('통과 · 항목 %d · 장면이 jsonl 과 글자까지 같다' % len(its))
    print('     기술 이름 · 의도 등급 · 규격 필드가 화면에 없다')
    print('     등급 이름은 Q1 · Q2 보기 안에만 있다')
    print('     Q2 는 처음에 잠겨 있고, 바깥을 부르지 않는다')
    return 0


if __name__ == '__main__':
    sys.exit(main())
