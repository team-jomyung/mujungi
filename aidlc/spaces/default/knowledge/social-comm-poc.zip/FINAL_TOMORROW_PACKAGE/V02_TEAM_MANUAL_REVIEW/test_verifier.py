# -*- coding: utf-8 -*-
"""검증기가 실제로 잡는지 본다.

    python test_verifier.py

페이지를 일부러 망가뜨려 보고 `verify_review_page.py` 가 걸러 내는지 확인한다.
한 번도 실패하지 않는 검사는 검사가 아니다.
망가뜨린 뒤에는 원본으로 되돌린다.
"""
from __future__ import annotations

import io
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
PAGE = os.path.join(HERE, 'V02_MANUAL_REVIEW.html')


def swap(s, a, b):
    s = s.replace(a, '@@TMP@@', 1)
    s = s.replace(b, a, 1)
    return s.replace('@@TMP@@', b, 1)


CASES = [
    ('장면 글자 변조',
     lambda s: s.replace('오늘 저녁 같이 먹으면서', '오늘 점심 같이 먹으면서', 1)),
    ('장면 문장 삭제',
     lambda s: s.replace('<p class="turn">', '<p class="turn" hidden>', 1)),
    ('원본 · 새것 반 뒤집기',
     lambda s: swap(s, '<article class="scene">', '<article class="scene new">')),
    ('원본 · 새것 제목 뒤집기',
     lambda s: swap(s, '<h3>원본 상황</h3>', '<h3>새로운 상황</h3>')),
    ('장면에 등급 이름 주입',
     lambda s: s.replace('<h3>원본 상황</h3>', '<h3>원본 상황</h3><p>FAR</p>', 1)),
    ('머리에 기술 이름 주입',
     lambda s: s.replace('<span class="iid">V2-R01</span>',
                         '<span class="iid">V2-R01 S3</span>', 1)),
    ('Q2 잠금 해제',
     lambda s: s.replace('<fieldset class="q q2" disabled>',
                         '<fieldset class="q q2">', 1)),
    ('바깥 스크립트 추가',
     lambda s: s.replace('</head>',
                         '<script src="https://cdn.example.com/x.js"></script></head>', 1)),
    ('연구자 용어 주입',
     lambda s: s.replace('<h1>장면 비교 평가</h1>',
                         '<h1>장면 비교 평가</h1><p>제도적 점프 여부를 봐 주세요</p>', 1)),
]


def run():
    r = subprocess.run([sys.executable, os.path.join(HERE, 'verify_review_page.py')],
                       capture_output=True, cwd=HERE,
                       env=dict(os.environ, PYTHONIOENCODING='utf-8'))
    out = r.stdout.decode('utf-8', 'replace')
    first = [ln.strip()[3:] for ln in out.split(chr(10)) if ln.startswith('  X')]
    return r.returncode != 0, (first[0] if first else '')


def main():
    orig = io.open(PAGE, encoding='utf-8').read()
    ok, _ = run()
    if ok:
        print('원본이 이미 검증에 걸린다. 먼저 그것부터 고쳐야 한다.')
        return 2
    print('  OK  원본 통과')
    miss = 0
    try:
        for name, f in CASES:
            io.open(PAGE, 'w', encoding='utf-8', newline=chr(10)).write(f(orig))
            caught, why = run()
            miss += 0 if caught else 1
            print('  %s %-22s %s' % ('OK ' if caught else 'X  ', name, why))
    finally:
        io.open(PAGE, 'w', encoding='utf-8', newline=chr(10)).write(orig)
    same = io.open(PAGE, encoding='utf-8').read() == orig
    print()
    print('원본 복원 · %s' % ('같다' if same else '다르다. 다시 빌드할 것'))
    print('못 잡은 것 %d' % miss)
    return 1 if (miss or not same) else 0


if __name__ == '__main__':
    sys.exit(main())
