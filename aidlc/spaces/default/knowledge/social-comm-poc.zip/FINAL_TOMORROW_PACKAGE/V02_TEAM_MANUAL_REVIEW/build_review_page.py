# -*- coding: utf-8 -*-
"""v0.2 팀 블라인드 검토 페이지를 만든다.

    python build_review_page.py

장면을 새로 만들지 않는다. `v02_generated.jsonl` 의 아홉을 그대로 읽어 쓴다.

리뷰어에게 감추는 것
  기술 이름 · 의도한 거리 · 규격 필드 · 생성 프롬프트 · 자동검사 결과.
  화면에 남는 것은 원본 장면과 새 장면 둘뿐이고 항목 이름은 V2-R01 부터다.

앵커 이름도 감춘다
  `V2-S1` 같은 이름은 기술 번호를 그대로 드러낸다.
  내보내는 CSV 에는 A1 · A2 · A3 로 바꿔 넣고 대응표는 KEY 파일에만 둔다.
"""
from __future__ import annotations

import csv
import io
import json
import os
import random
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, '..', '05_Q2_LEVEL2', 'v0_2_validation', 'v02_generated.jsonl')
SEED = 20260915

SPEAKER = re.compile(r'^[\s*_\-•>#]*([가-힣A-Za-z][가-힣A-Za-z0-9 \'"]{0,9}?)[\s*_]*[:：]')
HEADINGS = ('상황', '상황 설명', '상황설명', '대화', '장면', '배경', '설명')


def esc(t):
    return (str(t).replace('&', '&amp;').replace('<', '&lt;')
            .replace('>', '&gt;').replace('"', '&quot;'))


def bold(t):
    out, on = [], False
    for part in t.split('**'):
        out.append(('<b>%s</b>' % part) if on else part)
        on = not on
    return ''.join(out)


def render(scene):
    """장면 원문을 그대로 화면에 올린다. 글자를 고치지 않고 줄만 나눈다."""
    html = []
    for raw in (scene or '').split(chr(10)):
        line = raw.strip()
        if not line or set(line) <= set('-—_= '):
            continue
        safe = esc(line)
        m = SPEAKER.match(line)
        label = m.group(1).strip().strip('*_ ') if m else ''
        if label and label in HEADINGS:
            html.append('<p class="lead">%s</p>' % bold(safe))
        elif label:
            html.append('<p class="turn">%s</p>' % bold(safe))
        else:
            html.append('<p class="narr">%s</p>' % bold(safe))
    return chr(10).join(html)


def load():
    rows = [json.loads(x) for x in io.open(SRC, encoding='utf-8') if x.strip()]
    if len(rows) != 9:
        raise SystemExit('장면이 9가 아니라 %d 다' % len(rows))
    return rows


GRADE_RANK = {'SAME_CONTEXT': 0, 'NEAR': 1, 'FAR': 2}


def acceptable(order):
    """리뷰어가 규칙을 눈치채지 못할 배열인가.

    같은 원본이 세 번 나오는 구조라 그냥 섞으면 한 앵커의 셋이
    SAME -> NEAR -> FAR 순서 그대로 놓이는 일이 생긴다. 그러면 뒤로 갈수록
    멀어진다는 것이 읽힌다. 그 배열을 버린다.
    """
    for i in range(len(order) - 1):
        if order[i]['anchor_id'] == order[i + 1]['anchor_id']:
            return False
    for a in {r['anchor_id'] for r in order}:
        ranks = [GRADE_RANK[r['distance']] for r in order if r['anchor_id'] == a]
        if ranks == sorted(ranks) or ranks == sorted(ranks, reverse=True):
            return False
    return True


def build():
    rows = load()
    rnd = random.Random(SEED)

    anchors = sorted({r['anchor_id'] for r in rows})
    alias_order = anchors[:]
    rnd.shuffle(alias_order)
    alias = {a: 'A%d' % (i + 1) for i, a in enumerate(alias_order)}

    order, draws = rows[:], 0
    while True:
        draws += 1
        rnd.shuffle(order)
        if acceptable(order) or draws >= 2000:
            break
    if not acceptable(order):
        raise SystemExit('조건을 만족하는 배열을 못 찾았다')
    build.draws = draws

    items = []
    for i, r in enumerate(order, 1):
        items.append(dict(
            display_id='V2-R%02d' % i,
            source_anchor_id=alias[r['anchor_id']],
            anchor_html=render(r['anchor_scene']),
            variant_html=render(r['final_output']),
            _generation_id=r['item_id'],
            _anchor_id=r['anchor_id'],
            _skill=r['skill'],
            _distance=r['distance']))

    write_key(items)
    write_html(items)
    return items


def write_key(items):
    p = os.path.join(HERE, 'V02_REVIEW_KEY.csv')
    with io.open(p, 'w', encoding='utf-8-sig', newline='') as fh:
        w = csv.writer(fh)
        w.writerow(['item_id', 'source_anchor_id', 'intended_skill',
                    'intended_distance', 'generation_id', 'original_anchor_id'])
        for it in items:
            w.writerow([it['display_id'], it['source_anchor_id'], it['_skill'],
                        it['_distance'], it['_generation_id'], it['_anchor_id']])
    return p


def card(it):
    """리뷰어에게 나가는 조각. 의도한 값은 여기에 넣지 않는다."""
    return TPL_ITEM.replace('@@ID@@', it['display_id']) \
                   .replace('@@ANCHOR@@', it['anchor_html']) \
                   .replace('@@VARIANT@@', it['variant_html'])


def write_html(items):
    body = chr(10).join(card(it) for it in items)
    ids = json.dumps([it['display_id'] for it in items], ensure_ascii=False)
    src = json.dumps({it['display_id']: it['source_anchor_id'] for it in items},
                     ensure_ascii=False)
    html = (TPL_PAGE.replace('@@ITEMS@@', body)
            .replace('@@IDS@@', ids)
            .replace('@@SRC@@', src)
            .replace('@@N@@', str(len(items))))
    p = os.path.join(HERE, 'V02_MANUAL_REVIEW.html')
    io.open(p, 'w', encoding='utf-8', newline=chr(10)).write(html)
    return p


TPL_ITEM = '''
<section class="item" data-id="@@ID@@">
  <header class="ih"><span class="iid">@@ID@@</span></header>
  <div class="scenes">
    <article class="scene">
      <h3>원본 상황</h3>
      @@ANCHOR@@
    </article>
    <article class="scene new">
      <h3>새로운 상황</h3>
      @@VARIANT@@
    </article>
  </div>

  <div class="qs">
    <fieldset class="q q1">
      <legend>Q1. 같은 핵심 능력인가?</legend>
      <p class="qt">두 상황에서 적절하게 이해하고 대응하려면 같은 핵심 사회적 · 화용 능력이
        필요하다고 생각하나요?</p>
      <label class="opt"><input type="radio" name="@@ID@@-q1" value="SAME">
        <span><b>SAME</b><em>상황은 달라도 결국 같은 종류의 의미를 읽거나
          같은 종류의 판단을 해야 함</em></span></label>
      <label class="opt"><input type="radio" name="@@ID@@-q1" value="DIFFERENT">
        <span><b>DIFFERENT</b><em>두 상황을 잘 처리하기 위해 필요한 판단이나 능력이
          본질적으로 다름</em></span></label>
      <label class="opt"><input type="radio" name="@@ID@@-q1" value="UNSURE">
        <span><b>UNSURE</b><em>상황 정보만으로 판단하기 어려움</em></span></label>
    </fieldset>

    <fieldset class="q q2" disabled>
      <legend>Q2. 얼마나 다른 상황인가?</legend>
      <p class="qt">같은 능력을 요구한다고 보았을 때, 두 사회적 상황의 맥락은
        얼마나 멀리 떨어져 있다고 느껴지나요?</p>
      <p class="lock">Q1 에서 SAME 을 고르면 열립니다.</p>
      <label class="opt"><input type="radio" name="@@ID@@-q2" value="SAME_CONTEXT">
        <span><b>SAME_CONTEXT</b><em>사람 · 장소 · 소재 일부만 바뀐 수준.
          사실상 비슷한 장면</em></span></label>
      <label class="opt"><input type="radio" name="@@ID@@-q2" value="NEAR">
        <span><b>NEAR</b><em>관계나 상황이 어느 정도 달라졌지만
          비슷한 경험으로 느껴짐</em></span></label>
      <label class="opt"><input type="radio" name="@@ID@@-q2" value="FAR">
        <span><b>FAR</b><em>등장인물 · 관계 · 장소 · 상황 등이 상당히 달라 겉으로 보면
          다른 종류의 경험처럼 느껴지지만, 해결에 필요한 핵심 능력은 같음</em></span></label>
      <label class="opt"><input type="radio" name="@@ID@@-q2" value="UNSURE">
        <span><b>UNSURE</b><em>거리 판단이 어려움</em></span></label>
    </fieldset>

    <div class="q q3">
      <label class="legend" for="@@ID@@-q3">Q3. 왜 그렇게 판단했나요?</label>
      <textarea id="@@ID@@-q3" name="@@ID@@-q3" rows="3"
        placeholder="같다고/다르다고 판단한 이유나, 거리 판단에 영향을 준 차이를 짧게 적어주세요."></textarea>
      <p class="hint" hidden>DIFFERENT 나 UNSURE 를 고르셨다면 되도록 한 줄 적어 주세요.</p>
    </div>

    <fieldset class="q q4">
      <legend>Q4. 장면 자체에 문제가 있나요?</legend>
      <p class="qt">해당하는 것을 모두 고르세요.</p>
      <label class="chk"><input type="checkbox" name="@@ID@@-q4" value="NONE">없음</label>
      <label class="chk"><input type="checkbox" name="@@ID@@-q4" value="UNNATURAL">상황이 부자연스러움</label>
      <label class="chk"><input type="checkbox" name="@@ID@@-q4" value="INSUFFICIENT">정보가 부족함</label>
      <label class="chk"><input type="checkbox" name="@@ID@@-q4" value="TELLS_ANSWER">상황 설명이 너무 정답을 알려줌</label>
      <label class="chk"><input type="checkbox" name="@@ID@@-q4" value="WEIGHT_MISMATCH">원본과 생성본의 무게감 / 책임이 너무 다름</label>
      <label class="chk"><input type="checkbox" name="@@ID@@-q4" value="CONFUSING">무슨 상황인지 이해하기 어려움</label>
      <label class="chk"><input type="checkbox" name="@@ID@@-q4" value="OTHER">기타</label>
      <input class="other" type="text" name="@@ID@@-q4other" placeholder="기타 내용" hidden>
    </fieldset>
  </div>
</section>
'''


TPL_PAGE = '''<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>v0.2 장면 비교 평가</title>
<style>
:root{
  --pg:#faf9f7; --pg2:#fff; --ink:#1c1b19; --mut:#6c6862; --rule:#dcd8d1;
  --acc:#2f5d50; --acc2:#eef3f1; --warn:#8a5a2b; --bad:#a33;
  --mono:ui-monospace,"SFMono-Regular",Menlo,Consolas,monospace;
}
*{box-sizing:border-box}
body{margin:0;background:var(--pg);color:var(--ink);
  font:15px/1.65 -apple-system,"Segoe UI","Malgun Gothic",system-ui,sans-serif;}
.wrap{max-width:1180px;margin:0 auto;padding:0 24px 120px}
header.top{padding:44px 0 26px;border-bottom:1px solid var(--rule);margin-bottom:34px}
h1{font-size:25px;margin:0 0 8px;letter-spacing:-.01em}
.sub{color:var(--mut);margin:0 0 22px;max-width:62ch}
.who{display:flex;gap:10px;align-items:center;flex-wrap:wrap}
.who label{font-weight:600}
.who input{font:inherit;padding:8px 11px;border:1px solid var(--rule);border-radius:6px;
  background:var(--pg2);min-width:240px}
.who input:focus{outline:2px solid var(--acc);outline-offset:1px}
.bar{position:sticky;top:0;z-index:20;background:rgba(250,249,247,.94);
  backdrop-filter:blur(6px);border-bottom:1px solid var(--rule);
  padding:11px 0;margin-bottom:26px;font-size:13px;color:var(--mut)}
.bar b{color:var(--ink)}
.bar .track{height:4px;background:var(--rule);border-radius:2px;margin-top:8px;overflow:hidden}
.bar .fill{height:100%;width:0;background:var(--acc);transition:width .25s}

.item{background:var(--pg2);border:1px solid var(--rule);border-radius:10px;
  padding:24px 26px 20px;margin:0 0 30px}
.ih{margin:0 0 16px}
.iid{font:600 12px/1 var(--mono);letter-spacing:.09em;color:var(--mut);
  border:1px solid var(--rule);border-radius:4px;padding:5px 8px}
.scenes{display:grid;grid-template-columns:1fr 1fr;gap:22px;margin-bottom:22px}
.scene{border:1px solid var(--rule);border-radius:8px;padding:16px 18px;background:var(--pg)}
.scene.new{background:var(--acc2);border-color:#cfe0da}
.scene h3{margin:0 0 12px;font-size:12px;letter-spacing:.08em;color:var(--mut);
  text-transform:none;font-weight:700}
.scene p{margin:0 0 9px}
.scene .lead{color:var(--mut);padding-bottom:10px;border-bottom:1px dashed var(--rule);
  margin-bottom:13px}
.scene .turn{padding-left:2px}
.scene .narr{color:var(--mut)}

.qs{display:grid;grid-template-columns:1fr 1fr;gap:18px 26px;
  border-top:1px solid var(--rule);padding-top:20px}
fieldset.q{border:0;margin:0;padding:0;min-width:0}
.q3{grid-column:1/-1}
legend,.legend{font-weight:700;font-size:14px;padding:0;display:block;margin-bottom:4px}
.qt{color:var(--mut);font-size:13px;margin:0 0 10px}
.lock{color:var(--warn);font-size:12.5px;margin:0 0 10px}
.opt{display:flex;gap:9px;align-items:flex-start;padding:7px 9px;border-radius:6px;
  cursor:pointer;border:1px solid transparent}
.opt:hover{background:var(--pg)}
.opt input{margin-top:4px;flex:none}
.opt b{display:block;font:600 12.5px/1.5 var(--mono);letter-spacing:.04em}
.opt em{display:block;font-style:normal;color:var(--mut);font-size:12.5px;line-height:1.5}
fieldset[disabled]{opacity:.42}
fieldset[disabled] .opt{cursor:not-allowed}
.q3 textarea{width:100%;font:inherit;padding:10px 12px;border:1px solid var(--rule);
  border-radius:6px;background:var(--pg2);resize:vertical}
.q3 textarea:focus{outline:2px solid var(--acc);outline-offset:1px}
.hint{color:var(--warn);font-size:12.5px;margin:6px 0 0}
.chk{display:block;padding:4px 2px;cursor:pointer;font-size:13.5px}
.chk input{margin-right:8px}
.other{display:block;margin-top:8px;width:100%;font:inherit;padding:8px 11px;
  border:1px solid var(--rule);border-radius:6px;background:var(--pg2)}
.item.done{border-color:#bcd2ca}
.item.miss{border-color:#e3c4c4}

.foot{border-top:1px solid var(--rule);padding-top:26px;margin-top:10px}
button{font:600 14px/1 inherit;padding:13px 22px;border-radius:7px;border:1px solid var(--acc);
  background:var(--acc);color:#fff;cursor:pointer}
button.ghost{background:transparent;color:var(--acc)}
button:disabled{opacity:.5;cursor:not-allowed}
.btns{display:flex;gap:10px;flex-wrap:wrap;align-items:center}
.msg{margin-top:14px;font-size:13.5px;white-space:pre-line}
.msg.err{color:var(--bad)}
.msg.ok{color:var(--acc)}
#fallback{width:100%;margin-top:14px;font:12px/1.5 var(--mono);padding:10px;
  border:1px solid var(--rule);border-radius:6px}
.done-screen{background:var(--pg2);border:1px solid var(--rule);border-radius:10px;
  padding:34px;text-align:center}
.done-screen p{font-size:16px;margin:0}
@media (max-width:900px){
  .scenes,.qs{grid-template-columns:1fr}
}
</style>
</head>
<body>
<div class="wrap">

<header class="top">
  <h1>장면 비교 평가</h1>
  <p class="sub">원본 상황과 새로 만든 상황 @@N@@쌍을 비교합니다.
    정답은 없습니다. 각 쌍에서 같은 능력이 필요한 상황인지, 같다면 얼마나 다른 상황인지
    직관적으로 판단해 주세요. 10~15분쯤 걸립니다.</p>
  <div class="who">
    <label for="reviewer">이름 또는 닉네임</label>
    <input id="reviewer" type="text" placeholder="예 · 백준하" autocomplete="off">
  </div>
</header>

<div class="bar">
  <span><b id="prog">0</b> / @@N@@ 항목 응답</span>
  <div class="track"><div class="fill" id="fill"></div></div>
</div>

<main id="main">
@@ITEMS@@
</main>

<div class="foot" id="foot">
  <div class="btns">
    <button id="save">평가 결과 저장</button>
    <button id="saveJson" class="ghost">JSON 내려받기</button>
    <button id="reset" class="ghost">작성 내용 지우기</button>
  </div>
  <div class="msg" id="msg"></div>
  <textarea id="fallback" rows="6" hidden></textarea>
</div>

</div>

<script>
(function(){
  "use strict";
  var IDS = @@IDS@@;
  var SRC = @@SRC@@;
  var KEY = "v02_review_v1";
  var main = document.getElementById("main");
  var msg  = document.getElementById("msg");

  function $(s, r){ return (r||document).querySelector(s); }
  function all(s, r){ return Array.prototype.slice.call((r||document).querySelectorAll(s)); }
  function sec(id){ return $('.item[data-id="'+id+'"]'); }

  function readItem(id){
    var s = sec(id);
    var q1 = $('input[name="'+id+'-q1"]:checked', s);
    var q2 = $('input[name="'+id+'-q2"]:checked', s);
    var q4 = all('input[name="'+id+'-q4"]:checked', s).map(function(x){ return x.value; });
    return {
      item_id: id,
      source_anchor_id: SRC[id] || "",
      skill_identity: q1 ? q1.value : "",
      transfer_distance: q2 ? q2.value : "",
      comment: $('#'+id+'-q3', s).value.trim(),
      scene_issue: q4.join("|"),
      scene_issue_other: $('.other', s).value.trim()
    };
  }

  function state(){
    return { reviewer_id: $("#reviewer").value.trim(),
             items: IDS.map(readItem) };
  }

  function applyGate(id){
    var s = sec(id);
    var q1 = $('input[name="'+id+'-q1"]:checked', s);
    var v  = q1 ? q1.value : "";
    var f2 = $('.q2', s);
    f2.disabled = (v !== "SAME");
    if (f2.disabled) {
      all('input[name="'+id+'-q2"]', s).forEach(function(r){ r.checked = false; });
    }
    $('.q3 .hint', s).hidden = !(v === "DIFFERENT" || v === "UNSURE");
    var other = $('.other', s);
    var otherOn = !!$('input[name="'+id+'-q4"][value="OTHER"]:checked', s);
    other.hidden = !otherOn;
    if (!otherOn) { other.value = ""; }
  }

  function complete(it){
    if (!it.skill_identity) return false;
    if (it.skill_identity === "SAME" && !it.transfer_distance) return false;
    return true;
  }

  function paint(){
    var n = 0;
    IDS.forEach(function(id){
      var it = readItem(id), ok = complete(it);
      if (ok) n++;
      var s = sec(id);
      s.classList.toggle("done", ok);
      s.classList.remove("miss");
    });
    $("#prog").textContent = n;
    $("#fill").style.width = (n / IDS.length * 100) + "%";
    return n;
  }

  function save(){
    try { localStorage.setItem(KEY, JSON.stringify(state())); } catch (e) {}
  }

  function restore(){
    var raw = null;
    try { raw = localStorage.getItem(KEY); } catch (e) { return; }
    if (!raw) return;
    var d;
    try { d = JSON.parse(raw); } catch (e) { return; }
    $("#reviewer").value = d.reviewer_id || "";
    (d.items || []).forEach(function(it){
      var s = sec(it.item_id);
      if (!s) return;
      if (it.skill_identity) {
        var a = $('input[name="'+it.item_id+'-q1"][value="'+it.skill_identity+'"]', s);
        if (a) a.checked = true;
      }
      if (it.transfer_distance) {
        var b = $('input[name="'+it.item_id+'-q2"][value="'+it.transfer_distance+'"]', s);
        if (b) b.checked = true;
      }
      $('#'+it.item_id+'-q3', s).value = it.comment || "";
      (it.scene_issue ? it.scene_issue.split("|") : []).forEach(function(v){
        var c = $('input[name="'+it.item_id+'-q4"][value="'+v+'"]', s);
        if (c) c.checked = true;
      });
      $('.other', s).value = it.scene_issue_other || "";
    });
    IDS.forEach(applyGate);
  }

  function esc(v){
    v = (v === null || v === undefined) ? "" : String(v);
    return /[",\\n\\r]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v;
  }

  function toCsv(st, when){
    var cols = ["reviewer_id","item_id","source_anchor_id","skill_identity",
                "transfer_distance","comment","scene_issue","submitted_at"];
    var lines = [cols.join(",")];
    st.items.forEach(function(it){
      var issue = it.scene_issue;
      if (it.scene_issue_other) {
        issue = (issue ? issue + "|" : "") + "OTHER_TEXT:" + it.scene_issue_other;
      }
      lines.push([st.reviewer_id, it.item_id, it.source_anchor_id, it.skill_identity,
                  it.transfer_distance, it.comment, issue, when].map(esc).join(","));
    });
    return lines.join("\\n");
  }

  function slug(s){
    return (s || "reviewer").replace(/[^0-9A-Za-z가-힣_-]+/g, "_").slice(0, 24);
  }

  function download(name, text, mime){
    try {
      var blob = new Blob(["\\ufeff" + text], {type: mime + ";charset=utf-8"});
      var url  = URL.createObjectURL(blob);
      var a = document.createElement("a");
      a.href = url; a.download = name;
      document.body.appendChild(a); a.click();
      document.body.removeChild(a);
      setTimeout(function(){ URL.revokeObjectURL(url); }, 2000);
      return true;
    } catch (e) { return false; }
  }

  function problems(st){
    var bad = [];
    if (!st.reviewer_id) bad.push("이름 또는 닉네임을 입력해 주세요.");
    var miss = st.items.filter(function(it){ return !it.skill_identity; });
    var miss2 = st.items.filter(function(it){
      return it.skill_identity === "SAME" && !it.transfer_distance; });
    if (miss.length)  bad.push("Q1 미응답 " + miss.length + "개 · " +
                               miss.map(function(x){ return x.item_id; }).join(", "));
    if (miss2.length) bad.push("Q2 미응답 " + miss2.length + "개 · " +
                               miss2.map(function(x){ return x.item_id; }).join(", "));
    return bad;
  }

  function flag(st){
    st.items.forEach(function(it){
      if (!complete(it)) sec(it.item_id).classList.add("miss");
    });
    var first = $(".item.miss");
    if (first) first.scrollIntoView({behavior: "smooth", block: "center"});
  }

  function finish(){
    document.getElementById("main").hidden = true;
    document.querySelector(".bar").hidden = true;
    document.getElementById("foot").hidden = true;
    var d = document.createElement("div");
    d.className = "done-screen";
    d.innerHTML = "<p>평가가 저장되었습니다.<br>CSV 파일을 전달해주세요.</p>";
    document.querySelector(".wrap").appendChild(d);
    window.scrollTo(0, 0);
  }

  function submit(kind){
    var st = state();
    var bad = problems(st);
    if (bad.length) {
      msg.className = "msg err";
      msg.textContent = bad.join("\\n");
      flag(st);
      return;
    }
    var when = new Date().toISOString();
    var base = "V02_REVIEW_" + slug(st.reviewer_id);
    var text, name, mime;
    if (kind === "json") {
      text = JSON.stringify({reviewer_id: st.reviewer_id, submitted_at: when,
                             items: st.items}, null, 2);
      name = base + ".json"; mime = "application/json";
    } else {
      text = toCsv(st, when);
      name = base + ".csv"; mime = "text/csv";
    }
    var ok = download(name, text, mime);
    if (!ok) {
      var fb = $("#fallback");
      fb.hidden = false; fb.value = text; fb.focus(); fb.select();
      msg.className = "msg err";
      msg.textContent = "내려받기가 막혔습니다. 아래 상자의 내용을 복사해 " + name + " 로 저장해 주세요.";
      return;
    }
    msg.className = "msg ok";
    msg.textContent = name + " 를 내려받았습니다.";
    if (kind !== "json") { setTimeout(finish, 600); }
  }

  main.addEventListener("change", function(e){
    var s = e.target.closest(".item");
    if (!s) return;
    var id = s.getAttribute("data-id");
    if (e.target.name === id + "-q4" && e.target.value === "NONE" && e.target.checked) {
      all('input[name="'+id+'-q4"]', s).forEach(function(c){
        if (c.value !== "NONE") c.checked = false; });
    } else if (e.target.name === id + "-q4" && e.target.value !== "NONE" && e.target.checked) {
      var none = $('input[name="'+id+'-q4"][value="NONE"]', s);
      if (none) none.checked = false;
    }
    applyGate(id); paint(); save();
  });
  main.addEventListener("input", function(){ save(); });
  $("#reviewer").addEventListener("input", save);

  $("#save").addEventListener("click", function(){ submit("csv"); });
  $("#saveJson").addEventListener("click", function(){ submit("json"); });
  $("#reset").addEventListener("click", function(){
    if (!window.confirm("작성한 내용을 모두 지웁니다. 계속할까요?")) return;
    try { localStorage.removeItem(KEY); } catch (e) {}
    location.reload();
  });

  restore();
  IDS.forEach(applyGate);
  paint();
})();
</script>
</body>
</html>
'''


def main():
    items = build()
    print('검토 페이지 · 항목 %d · seed %d · 배열 뽑기 %d회째'
          % (len(items), SEED, getattr(build, 'draws', 0)))
    print('  같은 앵커가 연달아 오지 않고, 한 앵커의 셋이 등급 순서대로 놓이지 않는다')
    for it in items:
        print('  %s  <- %s' % (it['display_id'], it['source_anchor_id']))
    print()
    print('  V02_MANUAL_REVIEW.html · V02_REVIEW_KEY.csv')
    return 0


if __name__ == '__main__':
    sys.exit(main())
