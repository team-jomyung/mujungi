# -*- coding: utf-8 -*-
"""페이지가 만드는 CSV 를 집계기가 읽는지 본다.

    python test_export.py

브라우저를 띄우지 않고 페이지 안의 CSV 만드는 함수만 꺼내 node 로 돌린다.
그 출력을 집계기에 그대로 먹여 왕복이 맞는지 확인한다.

함수를 새로 옮겨 적지 않고 **HTML 에 실제로 들어간 글자를 꺼내 쓴다.**
옮겨 적으면 페이지가 바뀌어도 시험은 계속 통과한다.

여기서 만드는 응답은 가짜다. 임시 폴더에서만 돌리고 지운다.
"""
from __future__ import annotations

import csv
import io
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
PAGE = os.path.join(HERE, 'V02_MANUAL_REVIEW.html')

WANTED = ('esc', 'toCsv', 'slug', 'complete', 'problems')

HARNESS = '''
%s

var st = {
  reviewer_id: "가짜 리뷰어, \\"따옴표\\" 포함",
  items: [
    {item_id:"V2-R01", source_anchor_id:"A3", skill_identity:"SAME",
     transfer_distance:"NEAR", comment:"쉼표, 그리고 줄\\n바꿈", scene_issue:"NONE",
     scene_issue_other:""},
    {item_id:"V2-R02", source_anchor_id:"A2", skill_identity:"DIFFERENT",
     transfer_distance:"", comment:"", scene_issue:"UNNATURAL|OTHER",
     scene_issue_other:"기타 내용"},
    {item_id:"V2-R03", source_anchor_id:"A1", skill_identity:"UNSURE",
     transfer_distance:"", comment:"", scene_issue:"", scene_issue_other:""}
  ]
};

var out = {
  csv: toCsv(st, "2026-09-15T13:00:00Z"),
  slug: [slug(st.reviewer_id), slug(""), slug("백준하 Kim/2")],
  complete: st.items.map(complete),
  complete_same_without_distance: complete({skill_identity:"SAME", transfer_distance:""}),
  problems_when_ok: problems({reviewer_id:"ㄱ", items:[
      {item_id:"X", skill_identity:"DIFFERENT", transfer_distance:""}]}),
  problems_when_no_name: problems({reviewer_id:"", items:[
      {item_id:"X", skill_identity:"SAME", transfer_distance:"NEAR"}]}),
  problems_when_same_no_distance: problems({reviewer_id:"ㄱ", items:[
      {item_id:"X", skill_identity:"SAME", transfer_distance:""}]})
};
process.stdout.write(JSON.stringify(out));
'''


def grab(js, name):
    """이름이 같은 함수 하나를 중괄호 짝을 세어 통째로 떼어 온다."""
    m = re.search(r'\bfunction\s+%s\s*\(' % re.escape(name), js)
    if not m:
        raise SystemExit('%s 를 못 찾겠다' % name)
    i = js.index('{', m.end() - 1)
    depth, j = 0, i
    while j < len(js):
        if js[j] == '{':
            depth += 1
        elif js[j] == '}':
            depth -= 1
            if depth == 0:
                return js[m.start():j + 1]
        j += 1
    raise SystemExit('%s 의 괄호가 안 닫힌다' % name)


def main():
    html = io.open(PAGE, encoding='utf-8').read()
    js = re.search(r'(?s)<script>(.*)</script>', html).group(1)
    src = (chr(10) * 2).join(grab(js, n) for n in WANTED)

    tmp = tempfile.mkdtemp(prefix='v02exp_')
    fails = 0
    try:
        hp = os.path.join(tmp, 'h.js')
        io.open(hp, 'w', encoding='utf-8', newline=chr(10)).write(HARNESS % src)
        r = subprocess.run(['node', hp], capture_output=True)
        if r.returncode != 0:
            print('node 가 실패했다')
            print(r.stderr.decode('utf-8', 'replace')[:800])
            return 1
        got = json.loads(r.stdout.decode('utf-8'))

        rows = list(csv.DictReader(io.StringIO(got['csv'])))
        cols = ['reviewer_id', 'item_id', 'source_anchor_id', 'skill_identity',
                'transfer_distance', 'comment', 'scene_issue', 'submitted_at']

        def ck(name, ok, extra=''):
            nonlocal fails
            fails += 0 if ok else 1
            print('  %s %s %s' % ('OK ' if ok else 'X  ', name, extra))

        ck('CSV 열 이름', list(rows[0].keys()) == cols, list(rows[0].keys()))
        ck('CSV 줄 수 3', len(rows) == 3, len(rows))
        ck('따옴표 든 이름이 살아남는다',
           rows[0]['reviewer_id'] == '가짜 리뷰어, "따옴표" 포함', rows[0]['reviewer_id'])
        ck('쉼표와 줄바꿈이 든 자유서술이 살아남는다',
           rows[0]['comment'] == '쉼표, 그리고 줄' + chr(10) + '바꿈', repr(rows[0]['comment']))
        ck('DIFFERENT 줄의 거리가 비어 있다', rows[1]['transfer_distance'] == '')
        ck('기타 내용이 scene_issue 에 붙는다',
           rows[1]['scene_issue'] == 'UNNATURAL|OTHER|OTHER_TEXT:기타 내용',
           rows[1]['scene_issue'])
        ck('파일 이름이 안전하게 깎인다',
           got['slug'][0].isascii() is False and '/' not in got['slug'][2]
           and got['slug'][1] == 'reviewer', got['slug'])
        ck('DIFFERENT 는 거리 없이도 완성', got['complete'][1] is True)
        ck('UNSURE 는 거리 없이도 완성', got['complete'][2] is True)
        ck('SAME 인데 거리가 없으면 미완성',
           got['complete_same_without_distance'] is False)
        ck('다 채우면 경고 없음', got['problems_when_ok'] == [])
        ck('이름이 없으면 경고', len(got['problems_when_no_name']) == 1)
        ck('SAME 인데 Q2 비면 경고', len(got['problems_when_same_no_distance']) == 1)

        # 왕복 · 이 CSV 를 집계기가 읽는가
        for f in ('aggregate_v02_reviews.py', 'V02_REVIEW_KEY.csv'):
            shutil.copy(os.path.join(HERE, f), os.path.join(tmp, f))
        inbox = os.path.join(tmp, 'review_results')
        os.makedirs(inbox)
        io.open(os.path.join(inbox, 'from_page.csv'), 'w',
                encoding='utf-8-sig', newline='').write(got['csv'])
        r2 = subprocess.run([sys.executable, os.path.join(tmp, 'aggregate_v02_reviews.py')],
                            capture_output=True, cwd=tmp,
                            env=dict(os.environ, PYTHONIOENCODING='utf-8'))
        out2 = r2.stdout.decode('utf-8', 'replace')
        ck('집계기가 페이지 CSV 를 읽는다', 'SKILL_PRESERVATION' in out2)
        ck('세 줄만 넣었으니 미응답을 잡는다', '답하지 않은 항목' in out2)
        ck('SKILL_PRESERVATION 1/3',
           'SKILL_PRESERVATION      1/3' in out2,
           [l for l in out2.split(chr(10)) if 'SKILL_PRESERVATION' in l])
    finally:
        shutil.rmtree(tmp, ignore_errors=True)

    print()
    print('실패 %d' % fails)
    return 1 if fails else 0


if __name__ == '__main__':
    sys.exit(main())
