리뷰어가 내려받은 CSV 를 이 폴더에 넣는다.

그 다음
    python ../aggregate_v02_reviews.py

가짜로 채운 응답을 여기에 두지 않는다.
