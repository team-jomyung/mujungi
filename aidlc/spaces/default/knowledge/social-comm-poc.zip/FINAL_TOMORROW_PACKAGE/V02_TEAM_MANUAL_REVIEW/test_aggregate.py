# -*- coding: utf-8 -*-
"""집계기 시험. 손으로 만든 응답으로 셈이 맞는지 본다.

    python test_aggregate.py

**여기서 만드는 응답은 전부 가짜다.** 사람이 답한 것이 아니다.
그래서 진짜 `review_results/` 에 쓰지 않고 임시 폴더에 복사본을 만들어 돌린다.
시험이 끝나면 임시 폴더를 지운다.

기대값은 KEY 파일을 보고 손으로 적었다. 집계기가 낸 값을 베끼지 않았다.
"""
from __future__ import annotations

import csv
import io
import os
import shutil
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))

# 가짜 응답 · (항목, Q1, Q2)
R1 = [('V2-R01', 'SAME', 'NEAR'),
      ('V2-R02', 'SAME', 'NEAR'),
      ('V2-R03', 'DIFFERENT', ''),
      ('V2-R04', 'SAME', 'SAME_CONTEXT'),
      ('V2-R05', 'SAME', 'FAR'),
      ('V2-R06', 'DIFFERENT', ''),
      ('V2-R07', 'SAME', 'NEAR'),
      ('V2-R08', 'SAME', 'SAME_CONTEXT'),
      ('V2-R09', 'UNSURE', '')]
R2 = [('V2-R01', 'SAME', 'NEAR'),
      ('V2-R02', 'SAME', 'FAR'),
      ('V2-R03', 'SAME', 'NEAR'),
      ('V2-R04', 'SAME', 'SAME_CONTEXT'),
      ('V2-R05', 'SAME', 'NEAR'),
      ('V2-R06', 'SAME', 'FAR'),
      ('V2-R07', 'SAME', 'NEAR'),
      ('V2-R08', 'SAME', 'SAME_CONTEXT'),
      ('V2-R09', 'SAME', 'SAME_CONTEXT')]

# KEY 를 보고 손으로 센 기대값
WANT_ONE = {'SKILL_PRESERVATION': '6/9', 'FAR_SKILL_PRESERVATION': '2/3',
            'FAR_DISTANCE_SUCCESS': '1/3'}
WANT_TWO = {'SKILL_PRESERVATION': '15/18', 'FAR_SKILL_PRESERVATION': '5/6',
            'FAR_DISTANCE_SUCCESS': '3/6'}


def write_csv(path, who, answers, src):
    with io.open(path, 'w', encoding='utf-8-sig', newline='') as fh:
        w = csv.writer(fh)
        w.writerow(['reviewer_id', 'item_id', 'source_anchor_id', 'skill_identity',
                    'transfer_distance', 'comment', 'scene_issue', 'submitted_at'])
        for iid, q1, q2 in answers:
            w.writerow([who, iid, src[iid], q1, q2, '', 'NONE', '2026-09-15T13:00:00Z'])


def run(tmp):
    r = subprocess.run([sys.executable, os.path.join(tmp, 'aggregate_v02_reviews.py')],
                       capture_output=True, cwd=tmp,
                       env=dict(os.environ, PYTHONIOENCODING='utf-8'))
    return r.stdout.decode('utf-8', 'replace'), r.returncode


def picked(out):
    got = {}
    for ln in out.split(chr(10)):
        for k in ('SKILL_PRESERVATION', 'FAR_SKILL_PRESERVATION', 'FAR_DISTANCE_SUCCESS'):
            if ln.startswith(k):
                got[k] = ln.split()[1]
    return got


def main():
    key = {r['item_id']: r['source_anchor_id'] for r in
           csv.DictReader(io.open(os.path.join(HERE, 'V02_REVIEW_KEY.csv'),
                                  encoding='utf-8-sig'))}
    tmp = tempfile.mkdtemp(prefix='v02agg_')
    fails = 0
    try:
        for f in ('aggregate_v02_reviews.py', 'V02_REVIEW_KEY.csv'):
            shutil.copy(os.path.join(HERE, f), os.path.join(tmp, f))
        inbox = os.path.join(tmp, 'review_results')
        os.makedirs(inbox)

        write_csv(os.path.join(inbox, 'a.csv'), '가짜리뷰어1', R1, key)
        out, rc = run(tmp)
        got = picked(out)
        for k, v in WANT_ONE.items():
            ok = got.get(k) == v
            fails += 0 if ok else 1
            print('  %s 리뷰어1 %-24s 기대 %-6s 실제 %s'
                  % ('OK ' if ok else 'X  ', k, v, got.get(k)))

        write_csv(os.path.join(inbox, 'b.csv'), '가짜리뷰어2', R2, key)
        out, rc = run(tmp)
        got = picked(out)
        for k, v in WANT_TWO.items():
            ok = got.get(k) == v
            fails += 0 if ok else 1
            print('  %s 둘 합쳐 %-25s 기대 %-6s 실제 %s'
                  % ('OK ' if ok else 'X  ', k, v, got.get(k)))

        rep = io.open(os.path.join(tmp, 'V02_TEAM_REVIEW_REPORT.md'),
                      encoding='utf-8').read()
        for k in ('Fleiss', 'DIFFERENT 는 여기 들어오지 않는다', '통계적 확정이 아니다'):
            ok = k in rep
            fails += 0 if ok else 1
            print('  %s 보고서에 "%s"' % ('OK ' if ok else 'X  ', k))

        # 빠뜨린 응답을 잡는가
        write_csv(os.path.join(inbox, 'c.csv'), '가짜리뷰어3', R1[:5], key)
        out, _ = run(tmp)
        ok = '답하지 않은 항목' in out
        fails += 0 if ok else 1
        print('  %s 미응답 리뷰어를 잡는다' % ('OK ' if ok else 'X  '))

        # SAME 이 아닌데 거리를 채운 줄을 잡는가
        write_csv(os.path.join(inbox, 'd.csv'), '가짜리뷰어4',
                  [(i, 'DIFFERENT', 'FAR') for i, _, _ in R1], key)
        out, _ = run(tmp)
        ok = 'SAME 이 아닌데' in out or 'SAME 이 아닌데' in io.open(
            os.path.join(tmp, 'V02_TEAM_REVIEW_REPORT.md'), encoding='utf-8').read()
        fails += 0 if ok else 1
        print('  %s DIFFERENT 인데 거리가 채워진 줄을 잡는다' % ('OK ' if ok else 'X  '))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)

    print()
    print('임시 폴더 지움 · 진짜 review_results 는 건드리지 않았다')
    print('실패 %d' % fails)
    return 1 if fails else 0


if __name__ == '__main__':
    sys.exit(main())
