# 문제 타겟과 기술 benchmark 를 분리한다

가장 중요한 원칙이다. 이것이 흔들리면 나머지 주장이 전부 흔들린다.

## 세 가지는 서로 다른 것이다

| | 집단 | 무엇에 답하나 | 근거 |
|---|---|---|---|
| PROBLEM / PRODUCT TARGET | **SCD · SPCD 아동 (약 6~12세)** | 무엇을 훈련할 것인가 (WHY / WHAT) | 임상 문헌 · 평가도구 문헌 |
| TECHNICAL BENCHMARK POPULATION | **일반 한국어** (+필요시 ASD/DLD) | 핵심 화용 엔진이 도는가 (HOW WELL) | 공개 Human-authored benchmark |
| TARGET EFFECT | SCD 아동 | 실제로 나아지는가 | **이번에 검증하지 않음** |

## 왜 benchmark 가 없다고 타겟을 바꾸지 않는가

"SCD 전용 공개 benchmark 가 부족하다" 는 것은
"SCD 를 문제 타겟으로 삼을 수 없다" 는 뜻이 아니다.

이 둘은 다른 질문에 답한다.

- **무엇을 훈련해야 하는가** · SCD 아동 연구가 답한다
- **그 기술이 도는가** · 일반 한국어 benchmark 가 답한다

데이터가 많은 집단을 제품 타겟으로 삼는 것은 순서가 거꾸로다.
그러면 "고칠 수 있는 문제" 가 아니라 "잴 수 있는 문제" 를 푸는 것이 된다.

## 우리가 검증하는 공통 기반 기술

- 대화 맥락 이해
- 함축 의미 해석
- 화용 현상 판단
- 정보량 적절성 판단
- Social Event 구조화
- Ontology 기반 추론
- retrieval / RAG

이것들은 SCD 아동에게만 필요한 기술이 아니다.
**그래서 일반 한국어 자료로 잴 수 있다.**
그리고 그래서 여기서 나온 숫자가 SCD 효과를 말해 주지도 않는다.

## 이번에 검증하지 않는 것

- SCD 아동의 실제 수행 향상
- Near / Far Transfer 효과
- 장기 유지
- 임상적 치료 효과
- 진단 정확도

전부 후속 사용자 연구다. `09_CLAIMS/CLAIM_LEDGER.csv` 에 NOT TESTED 로 적혀 있다.

## 한 문장

> SCD 아동 연구는 **무엇을 훈련해야 하는지** 정하는 근거로 쓰고,
> 그 공통 기반인 화용 추론 기술은 기존 한국어 Human-authored benchmark 에서 먼저 검증한다.
