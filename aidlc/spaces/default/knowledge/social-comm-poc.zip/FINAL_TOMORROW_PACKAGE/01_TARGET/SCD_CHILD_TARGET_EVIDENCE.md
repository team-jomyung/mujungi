# SCD/SPCD Children (6-12) as Product/Problem Target — Evidence Case

2026-09-15. Built entirely from local files already gathered by other agents in this project. **No new web search was run for this document** (team WebSearch budget exhausted; instruction was to reuse local material). Every claim below is traced to a specific local file. Where a local file itself says a search was not run, or ran and found nothing, that is reported as `NOT_FOUND_IN_LOCAL` / `NOT FOUND AFTER DEFINED SEARCH` — never read as proof of worldwide non-existence.

Files read in full: `FINAL_CLOSURE/01_EVIDENCE/SCD_STUDY_CENSUS.csv`, `SCD_STUDY_COUNTS.md`, `AGE_EVIDENCE.md`, `AGE_EVIDENCE_MATRIX.csv`, `ASSESSMENT_TOOL_MATRIX.csv`, `DATA_GAP_MATRIX.csv`, `EVIDENCE_LEDGER.csv` + `_NOTE.md`, `DATASET_CENSUS_NOTE.md`; `FINAL_CLOSURE/02_SCOPE/_agent_pragmatics_review.md`, `ONTOLOGY_SCOPE_FINAL.md`; `research/agent_scd_census.md`, `SCD_문헌.md`, `국내_화용평가도구.md`; `INSTRUCTOR_FINAL_EVIDENCE/02_TARGET/TARGET_EVIDENCE_MATRIX.csv` + `TARGET_DECISION.md`; `INSTRUCTOR_FINAL_EVIDENCE/04_SKILLS/SKILL_EVIDENCE_MATRIX.csv` + `FINAL_SKILL_SCOPE.md`. Also pulled in (outside the directories named in the task brief, but directly on-point and already gathered locally): `FINAL_TARGET_AND_POC/00_DECISION/_agent_target_korea.md` and `_tools_ko_draft.md`, which carry the fullest Korean-tool inventory found anywhere in the repo and are the only local source for LSSC, K-CCC, and the SCQ-Korean-version question raised in Q4.

---

## 0. Summary table — evidence items by tier

The source census (`SCD_STUDY_CENSUS.csv`, indexed in `SCD_STUDY_COUNTS.md`) holds **64 studies**, bucketed by the original agent into 8 categories. The task's 5 requested tiers do not map onto those 8 buckets one-to-one without blurring distinctions the census itself was careful to keep separate — in particular, a "DIRECT_SCD" tier restricted to DSM-5-diagnosed samples (per the task's own definition) is **not the same population** as the census's "SCD/SPCD-labeled but algorithmic/checklist-defined, or diagnostic procedure not stated" bucket, and folding the two together would be exactly the kind of blur the task prohibits. So three extra tiers are added, each directly derived from a distinction the census already draws. They are marked `[ADDED]` below.

| Tier | Studies | Distinct cohorts | Census bucket(s) | IDs |
|---|---|---|---|---|
| **DIRECT_SCD** (DSM-5 SPCD clinician-diagnosed) | 5 | 5 | STRICT_DIRECT_SCD_PARTICIPANT_STUDIES | D01-D05 |
| **DIRECT_SCD_ALGORITHMIC** `[ADDED]` (SCD/SPCD-labeled, but checklist/algorithm-defined or diagnostic procedure not stated in abstract — not clinician DSM-5) | 12 | 9 | DIRECT_BUT_ALGORITHMIC_OR_PUTATIVE | P01-P12 |
| **MIXED_SCD_ASD** `[ADDED]` (SPCD-or-ASD combined sample, not separable in the reported result) | 7 | 6 | MIXED_SPCD_ASD | M01-M05, M07-M08 |
| **PLI_HISTORICAL** | 10 | 8 | HISTORICAL_PLI | H01-H10 |
| **ASD_ADJACENT** | 5 | 5 | (split out of) ADJACENT_ASD_DLD | A01,A02,A03,A06,A09 |
| **DLD_ADJACENT** | 3 | 3 | (split out of) ADJACENT_ASD_DLD | A07,A08,A11 |
| **OTHER_ADJACENT** `[ADDED]` (deaf/hard-of-hearing, genetic syndrome, undiagnosed special-needs — fits neither ASD nor DLD) | 4 | 4 | (split out of) ADJACENT_ASD_DLD | A04,A05,A10,A12 |
| **GENERAL_PRAGMATICS** | 1 | 1 | GENERAL_PRAGMATICS | G01 |
| TOOL/INSTRUMENT (not population evidence — psychometric or item-mapping studies with no group-difference finding) | 9 | — | ITEM_MAPPING_OR_TOOL_STUDIES | M06, T01-T08 |
| REVIEW (secondary; not primary evidence) | 8 | — | REVIEW_STUDIES | R01-R08 |
| **Total** | **64** | — | — | matches `SCD_STUDY_COUNTS.md` TOTAL_RELATED_STUDIES |

A10 (Barstein et al. 2018) spans ASD, FXS+ASD, FXS-only and Down-syndrome subgroups in one study and cannot be cleanly assigned to a single adjacent tier; it is placed in OTHER_ADJACENT rather than forced into ASD_ADJACENT. This table counts **studies**, not participants — per the project's own hard rule (`SCD_STUDY_COUNTS.md`: "참가자는 합산하지 않는다"), several rows share a cohort (see the overlap table in §3 below) and must not be summed as if independent samples.

This table is the full census. §2 (Q2) and §4 (Q4) use only the subset of it that bears on the four questions asked; nothing here is a new count invented for this document.

---

## 1. Q-1: Why is SCD child a stronger PROBLEM target than the previous 13-25 band?

### 1.1 The composite score this is asked about

`INSTRUCTOR_FINAL_EVIDENCE/02_TARGET/TARGET_DECISION.md`, table "두 축을 따로 센다":

| Population | benchmark-possibility (/21) | **problem-grounding (/6)** | tech-fit (/3) | Human Gold |
|---|---|---|---|---|
| SCD child | 9 | **6** | 1 | WEAK |
| SCD adolescent (13-17) | 2 | 3 | 0 | NONE |
| SCD young adult (18-25) | 1 | **2** | 0 | NONE |

No local file contains an itemized rubric that decomposes "6 points" into six named criteria — this document does not invent one. What follows is the underlying evidence that this score is standing on, pulled from the two files that actually carry per-criterion citations.

### 1.2 What is NOT the asymmetry: prevalence

Do not read this as "SCD is more common in children." The two best population-based prevalence figures in the census are not obviously different in size:

- **Child (5-6):** Saul, Griffiths & Norbury 2023 (PMC10087005, CC BY, N=386): isolated SPCD 0-1.3%; co-occurring social-pragmatic-plus-structural-or-autistic profile 6.1-10.5% (`TARGET_EVIDENCE_MATRIX.csv` row `SCD child,1_direct_problem_evidence`; `AGE_EVIDENCE.md` §2.7).
- **Adolescent (13-14):** Ellis Weismer, Tomblin, Durkin, Bolt & Palta 2021 (PMID 34383380, N=393): SCD prevalence 7-11% depending on case definition (`AGE_EVIDENCE.md` §2.2; `SCD_STUDY_CENSUS.csv` row P05).

These are comparable ranges. The real asymmetry is not "how many people have it" but **how much anyone has ever directly measured what it looks like in behavior**, and that is heavily concentrated at child age.

### 1.3 What IS the asymmetry: behavioral/conversational evidence density

**`TARGET_EVIDENCE_MATRIX.csv`, criterion 1 (`1_direct_problem_evidence`) and criterion 2 (`2_our_age_band_evidence`), verbatim:**

| Population | Criterion 1 (direct problem evidence) | Criterion 2 (our age-band evidence) |
|---|---|---|
| SCD child | **STRONG** — Saul et al. 2023 population sample, N=386. "Strongest population-based prevalence anchor in the whole census; open access." | **STRONG** — Lockton, Adams & Collins 2016 (PMID 26916221): N=39 CwSCD age 6;1-10;7, TOPICC+AMP tasks; expressive language (not metapragmatic awareness) predicted conversational pragmatic score. "Field's center of mass is 5-12 per AGE_EVIDENCE.md §0; this is the richest behavioral study at that age." |
| SCD young adult | **WEAK** — Yoshinaga et al. 2023 (PMC10644653, N=52, mean age 28.1, range 16-52). "Only adult-majority SCD sample found worldwide; band only partially overlaps 18-25 (skews older)." | **WEAK** — Güler et al. 2026 (N=68 ages 15-21; SPCD case count itself not reported in the abstract). "Yoshinaga's cohort supplies zero behavioral data even where its age range overlaps 18-25." |

The Yoshinaga cohort is the entire worldwide adult-SCD evidence base and it is a **self-report AQ-J screening questionnaire study** — no conversation, no task, no behavior of any kind was collected (`AGE_EVIDENCE.md` §2.1, verbatim: "supplies zero behavioural/pragmatic/conversational data"). The Lockton child cohort, by contrast, ran two actual pragmatic tasks (TOPICC semi-structured conversation elicitation + AMP metapragmatic-explicitation task) on a same-age SCD-labeled sample.

**Inside the STRICT (clinician-DSM-5-diagnosed) bucket itself, the same pattern repeats at finer grain.** `SCD_STUDY_COUNTS.md`: "STRICT는 5건이다... 13세 위를 포함하는 것은 D01·D04·D05이고 **대화 자료를 모은 것은 0건이다**" (of the 5 strict studies, three include ages above 12, and zero of those three collected any conversational data). Breaking down what each of the 5 strict studies actually measured (`SCD_STUDY_CENSUS.csv` rows D01-D05):

| ID | Age | What was measured |
|---|---|---|
| D01 Yoshinaga 2023 | adult (16-52) | AQ-J self-report only, ROC analysis. Zero behavior. |
| D02 Dame 2024 | child (6-12, inferred) | Vineland, ADOS, CCC, a pragmatics evaluation, WISC-IV administered — but only the Vineland socialization subscale result is retrievable from the abstract; the pragmatics-evaluation outcome is not stated. |
| D03 Jain 2025 | child (age range not in abstract) | Vineland-III adaptive behavior only — not a pragmatic-skill measure. |
| D04 Tsai & Lin 2020 | adolescent | Diagnostic-migration case series, brief report, no behavioral data. |
| D05 Tsai, Lin & Lee 2022 | adolescent | Single case report (medication), no behavioral data. |

Even granting the loosest reading, **D02 (child) is the only one of the five strict studies that even nominally administered a pragmatics evaluation** — and its result is not retrievable. No strict adolescent or adult study measured anything about how SCD manifests in interaction.

**One field-wide corroborating fact, verified full-text** (`AGE_EVIDENCE.md` §4.1, Parsons, Cordier, Munro, Joosten & Speyer 2017, PMC5398499): a systematic review of 21 pragmatic-language-intervention studies for ASD, 925 participants aged 21 months-14 years, whose age search was explicitly **not capped below 18** — verbatim, "None of the included studies targeted children aged 13-18 years," and the maximum mean age across all 21 included studies was 11.27 years. This is not SCD-specific, but it shows the same age-concentration pattern holds across the wider adjacent pragmatic-intervention literature, not just the narrow SCD census.

**Bottom line, verbatim from `AGE_EVIDENCE.md` §0:** "The field's centre of mass is ages 5–12. Above 12 the literature thins to a small, non-overlapping set of roughly a dozen studies." And from §6.5, after checking all four (now six, per the later `ONTOLOGY_SCOPE_FINAL.md` revision) MVP pragmatic targets individually by age band: **"All four MVP pragmatic targets are CHILD_ONLY or NONE within DIRECT SCD populations. Every adolescent or adult data point above comes from an adjacent population."**

### 1.4 Answer, in three sentences

SCD prevalence itself is not obviously higher in children than adolescents (5-6yo: 0-10.5% depending on definition; 13-14yo: 7-11%) — the asymmetry is not about how many people have the problem. It is about how much anyone has ever directly measured the problem in behavior: at child age there is at least one SCD-labeled sample with two real pragmatic tasks (Lockton et al. 2016, n=39, TOPICC+AMP) and a population prevalence anchor (Saul et al. 2023, n=386); above age 12, the entire direct-SCD evidence base is one Japanese adult cohort that collected a screening questionnaire and nothing else (Yoshinaga et al. 2023), plus case reports and a transition-clinic paper that doesn't even report its own SPCD case count. Every one of the project's core pragmatic-skill targets has zero direct-SCD evidence above age 12 and at least some (thin, abstract-level, but present) evidence at child age.

---

## 2. Q-2: Which skill candidates have DIRECT evidence in SCD children?

Source: `FINAL_CLOSURE/02_SCOPE/ONTOLOGY_SCOPE_FINAL.md` §3-1 (the scoring table applying one rule to all skill candidates), cross-checked against `SCD_STUDY_CENSUS.csv` and `_agent_pragmatics_review.md`. "DIRECT" is read here the way the task brief poses it: an SCD- or SPCD-labeled sample (STRICT or algorithmic — **the two are kept separate below, per §0's tier split**), not the general pragmatics literature.

| Skill | DSM-5 textual anchor (A-DEF) | SCD/SPCD-labeled sample evidence (A-EMP) | Historical PLI evidence | Verdict |
|---|---|---|---|---|
| **S1** 청자 맞춤 정보 조절 (listener-adapted informativeness) | A2 | **NONE.** No SCD/SPCD sample of either tier measured this. | Bishop & Adams 1989 II (H02, SPD n=14): "too much or too little information." Single-case M03 (n=1, MIXED_SCD_ASD) showed post-therapy "appreciation of listener knowledge" gain, uncontrolled. | **NO DIRECT_SCD child evidence.** PLI_HISTORICAL only. |
| **S2** 관계·상황 맞춤 조정 (relationship/situation adaptation) | A2 (explicit examples given) | **NONE.** | Bishop, Hartley & Weir 1994 (H03, SPD n=6): no adjustment to interlocutor familiarity across four situations. | **NO DIRECT_SCD child evidence.** PLI_HISTORICAL only. Flagged in `FINAL_SKILL_SCOPE.md` as the one CORE skill with **no benchmark gold of any kind** — "제품에서 가장 중요한 축인데 gold가 없다." |
| **S3** 함축·비문자 의미 이해 (implicature/non-literal comprehension) | A4 | **YES — DIRECT_SCD_ALGORITHMIC.** Svindt & Surányi 2021 (P01, Hungarian, SPCD n=13, ASD n=19, TD n=39; diagnostic procedure NOT stated in the abstract, so labeled/putative, not STRICT): implicature/presupposition/entailment comprehension differed significantly from TD; performance correlated with **receptive grammar**, not theory of mind — a note against reading this as purely social-pragmatic. | Bishop & Adams 1989 II (H02): "frequently misunderstood the literal or implicit meaning of adult utterances." Bishop & Adams 1992 (H07): SPD comprehension task, lower scores, no disproportionate inferential-question difficulty. | **YES — one of only two skills with any SCD/SPCD-labeled sample result**, plus PLI_HISTORICAL corroboration. Not STRICT-tier. |
| **S4** 응답성·상호성 (responsiveness) | A1, A3 (partial) | **YES — DIRECT_SCD_ALGORITHMIC.** Jin & Pae 2014 (P09, **Korean**, SCD n=15 of 45, checklist-operationalized: SCQ<15 + CCC-2 GCC<55 + pragmatic composite<17 — explicitly **not** a clinician DSM-5 diagnosis): classroom-observed lower social-communication frequency, fewer verbal / more nonverbal means. | Bishop, Chan, Adams, Hartley & Weir 2000 (H04, PLI n=9): more no-response to adult solicitations, less nonverbal response. Bishop, Hartley & Weir 1994 (H03): initiating more than responding. | **YES — the other skill with SCD/SPCD-labeled sample evidence, and the only Korean-language one in the entire census**, plus PLI_HISTORICAL. Not STRICT-tier. |
| **S5** 수리 (respond to being misunderstood) | A3 ("rephrasing when misunderstood") | **NONE.** `_agent_pragmatics_review.md` §1.2 verdict, verbatim: "DIRECT SCD evidence: NO... NOT FOUND AFTER DEFINED SEARCH" (4 new Europe PMC queries, 65 titles fully screened, plus a 20-hit Korean CSD-journal query). | Adams & Bishop 1989 I (H01) **coded** repair reliably but "the abstract does not report a repair-specific group result" — coded, direction unknown. | **NO DIRECT_SCD evidence at any tier.** DSM-5 names it (A-DEF yes) but no SCD/SPCD sample has ever measured it; PLI evidence is coding-only. |
| **S6** 모를 때 묻기 (request clarification) | **Not named in DSM-5 A3** (S5's "rephrasing when misunderstood" covers only the responding-to-misunderstanding role, not the asking-when-uncertain role) | **NONE.** | Same H01 coding-only result; adjacent evidence only (Brinton 1986/1988, Volden 2004, Barstein 2018, Lee & Yim 2026 Korean-SLI, Sadati 2024 DHH — all ASD_ADJACENT/DLD_ADJACENT/OTHER_ADJACENT, not SCD). | **NO DIRECT_SCD evidence, and no DSM-5 textual anchor either.** Weakest-grounded of the four "response to trouble" skills. |
| **S7** 화제 운용 (topic management) | A3 ("rules for conversation") only loosely; "topic" itself is not named | **NONE.** Lockton 2016's TOPICC coded topic as 1 of 12 aspects, but **which aspects were impaired is not reported in the abstract** — "TOPICC 12측면 중 어느 것이 손상됐는지 초록에 없음." | Adams & Bishop 1989 I: over-initiation / exchange-structure violations — **not a topic-specific result** per `ONTOLOGY_SCOPE_FINAL.md` §3-1 ("화제 행동 결과는 아니다"). | **NO DIRECT_SCD evidence.** Weakest of all eight; this is why it was downgraded CORE→CONDITIONAL→**FUTURE_ONLY** across the two most recent scope revisions (`ONTOLOGY_SCOPE_FINAL.md` §6, `FINAL_SKILL_SCOPE.md`). Best available coding scheme (Ábalos et al. 2026, ASD_ADJACENT) was normed on 8-year-olds, not SCD children. |
| **S8** 반어·비꼼·간접 거절 (irony/sarcasm/indirect refusal) | A4 (cites humor/ambiguity as examples of the broader construct, not irony by name) | **NONE.** No SCD/SPCD sample of any tier has measured this as a task. | **NONE.** No historical-PLI result either. | **NO evidence at any clinical tier — the only skill with zero clinical-population behavioral evidence of any kind.** Carried only by the DSM-5 text's own examples plus nonclinical Korean proxy corpora (KoCoSa sarcasm labels, rights-reserved; quality-maxim items) — both general-population, not SCD. |

**Direct answer:** Of S1-S8, only **S3 (함축·비문자 의미 이해)** and **S4 (응답성·상호성)** have any SCD/SPCD-labeled sample evidence at all, and in both cases it is a single small abstract-only study (Svindt & Surányi 2021, n=13, Hungarian; Jin & Pae 2014, n=15, Korean) at the **algorithmic/labeled tier, not the STRICT clinician-DSM-5-diagnosed tier**. **No skill, including S3 and S4, has evidence from a STRICT DIRECT_SCD (DSM-5-diagnosed) sample** — none of the five STRICT studies (D01-D05, see §1.3 table) reports a usable S1-S8-level behavioral result. S1, S2, S5, S6 rely at best on 1980s-2000s English historical-PLI abstracts (n=6-15, pre-DSM-5, one of them coding-only with no reported direction). S7 has the weakest grounding of the six CORE/CONDITIONAL skills and has been downgraded twice. S8 has no clinical-population evidence of any kind, at any tier — it survives in the design only as a DSM-5-text-adjacent hypothesis.

---

## 3. Q-3: Evidence tiering

Covered structurally in §0's summary table. Two supporting points that the tally alone doesn't show:

**Cohort-overlap warnings that must not be summed as independent evidence** (`SCD_STUDY_COUNTS.md` "겹치는 코호트" table): C-EPISLI (P05/P06, same database), C-AZI (P07/P08, same authors/n=120/same year — "almost certainly the same sample reported twice," `AGE_EVIDENCE.md` §2.5), C-MAN (P10/P11, Manchester AMP programme, plausibly the same children — **this is the pair carrying S3's and the general metapragmatic-recognition literature's strongest single-cohort weight**, so its n=39/n=82 must not be added to n=121), C-SCIP (P12/M01/M02, likely-overlapping SCIP feasibility cohort), C-AB89 (H01/H02, same sample, two papers — **this is the pair underlying both S1 and S3's PLI_HISTORICAL evidence**), C-SCIP-RCT (H08/H09, same RCT, two reports).

**Reading-depth caveat that applies to nearly every DIRECT_SCD_ALGORITHMIC and PLI_HISTORICAL row above:** almost all of it is **ABSTRACT ONLY**. `AGE_EVIDENCE.md` §8's reading-depth ledger lists only two full-text reads in the entire age-evidence investigation (Parsons 2017, Yoshinaga 2023); `_agent_pragmatics_review.md` §7 lists a longer full-text set but still marks the core Bishop/Adams PLI papers (H01, H02, H03, H04) and Svindt & Surányi 2021 (P01) and Jin & Pae 2014 (P09) — i.e. every piece of evidence cited for S1, S3 and S4 above — as **ABSTRACT ONLY**, several behind a confirmed 403/paywall (`agent_scd_census.md` §5, item 1: Lockton 2016 CAPTCHA-blocked at every route tried). This is a reading-depth ceiling on the whole SCD-child case, not just a gap in one corner of it.

---

## 4. Q-4: Korean assessment tools for SCD children

### 4.1 Tool-by-tool

| Tool | Exists? | Age | Population normed | Pragmatic construct(s) scored | Item-level / dataset available? |
|---|---|---|---|---|---|
| **KOPLAC** (한국 아동 메타-화용언어검사) | **YES**, commercial. Kim, Song, Kim & Kim 2018, `doi:10.12963/csd.18467`. Publisher: 파라다이스복지재단, sold via 아이소리몰, SET 160,000 KRW. | **5;0-12;11.** Verified against the paper's own text: "5- to 12-year-old children" (`_agent_target_clinical_LOG.md` row `KOPLAC 원문`). | 270 **typically developing** children (not SCD-normed). | 3 subtests / 6 subdomains: communication regulation (partner/situation), discourse & story inference, metalinguistic awareness (indirect expressions, reference, irony/metaphor). Judgment + correction tasks — **recognition only**, not spontaneous production (`_agent_pragmatics_review.md` §3.1). Borrows 2 of AMP's 5 item-types (rule-violation judgment, metapragmatic-rule recognition) via picture+audio-script, not AMP's video format — and **does not** reproduce AMP's core explicitation-depth scoring; KOPLAC scores correct/incorrect only (`국내_화용평가도구.md`). | **ZERO.** `DATASET_CENSUS_KO.csv`: "검사 도구(데이터셋 아님)... 공개 데이터는 NOT FOUND AFTER DEFINED SEARCH" (GitHub/HuggingFace checked 2026-09-14; Zenodo 403'd, OSF unresponsive — explicitly excluded from the negative claim, not confirmed clean). |
| **CPLC** (아동화용언어체크리스트) | **YES as a research instrument, NOT a standardized/commercially published product.** Oh, Lee & Kim 2012 (item dev.); Oh 2018 (validation + conversation-observation correlation study). | 5-13, parent-report, 10-20 min. | Not standardized (as of the 2018 source: "현재 표준화 작업 중"; publication status as of 2026-09-14 still unconfirmed — RISS shows only academic-paper/thesis citations, zero commercial product listing). | 44 items / 4 subdomains (discourse mgmt 9, situational regulation 15, communicative intent 12, nonverbal 8), 4-point scale. Subdomain sensitivity/specificity ~80-90%, but **total-score specificity only ~50%** — author warns against using the total score alone. | **ZERO published.** A 2018 companion study DID collect ~10-15 min conversation transcripts from 28 children, but "논문 미수록, 공개 저장소 없음" (not published, no repository) — only the operational definition of the outcome measure is public, not the transcripts. |
| **CCC-2 한국어판** | **NOT_FOUND_IN_LOCAL.** No confirmed official Korean standardization. The one Korean CCC/CCC-2 item found — Song, Yang, Kim & Yim 2016 (`doi:10.12963/csd.16302`) — is a **meta-analysis of the CCC literature**, not a Korean standardization study. RISS queries for "아동용의사소통체크리스트 한국판" / "CCC-2 한국판 화용언어 표준화" returned only special-education-textbook mentions. "K-CCC" does not resolve to this instrument in Korean databases at all (returns unrelated cardiovascular/chemistry/electronics hits). | N/A | N/A | N/A | Files checked: `_tools_ko_draft.md` §1-①, `_agent_target_korea.md` line 514. This is explicitly flagged in the source as a **search-limited absence** (WebSearch unavailable for this sub-search; RISS + Crossref API only) — "존재하지 않는다"가 아니라 "이 경로로는 찾지 못했다"로 읽어야 한다. |
| **K-SCQ** (Korean SCQ) | **YES, but off-target and internally ambiguous.** Kim Ju-hyun et al. 2015, 소아청소년정신의학 26(3), "한국어판 사회적 의사소통 설문지 타당화 연구." **Separately**, `_agent_target_nonclinical.md` line 79 lists "**K-SCQ(10~60개월)**" among a short list of Korean-validated instruments — a **toddler** age range, apparently a different validation from the 2015 child/adolescent-psychiatry-journal one. **These two references were not reconciled in the local files; flagged as an unresolved internal tension, not silently merged.** | 2015 version: journal placement suggests child/adolescent norming (inferred, not stated in abstract). Other reference: 10-60 months. Neither reaches 18-25. | Not SCD-specific — a general ASD-screening instrument. | **It is a screening checklist for autism-spectrum symptoms, not a pragmatic-construct assessment.** It does not score any of the S1-S8 skills directly. | Not checked — out of scope, since it is not a pragmatic-construct instrument. |
| **LSSC** (학령기 아동 언어검사) | **YES**, commercial. Lee Yoon-kyoung et al., 인싸이트, 2015. ~200,000 KRW (SET) + manual/recording-sheet add-ons. | "아동" (children) — specific range **unconfirmed** in local files; commonly assumed school-age but this is explicitly a guess, not a verified figure ("구체 범위 미기재, 통상 학령기 7-12세 추정"). | Unconfirmed. | **Internally inconsistent across two local files.** `_agent_target_korea.md` line 494 lists LSSC alongside PRES/REVT/K-SIB-R as tools that **"화용을 재지 않는다"** (do not measure pragmatics). `_tools_ko_draft.md`'s tool table instead lists LSSC's pragmatic-measurement status as **"미확인"** (unconfirmed) rather than "no." Official product description only says "학령기 아동의 언어능력 평가 및 언어지체/언어장애 판별" — no pragmatics subtest is named there either way. **Both readings are reported here rather than one being silently picked.** | Not checked — blocked on the prior column being unresolved. |

### 4.2 Verifying KoreanTools' four claims against the local files

| Claim | Verdict | Basis, with the one caveat each carries |
|---|---|---|
| No Korean standardized pragmatic tool above age 13 | **HOLDS.** | Convergent across two independently-run local investigations six days apart (`국내_화용평가도구.md`, 2026-09-11; `_tools_ko_draft.md`/`_agent_target_korea.md`, 2026-09-14). Explicit zero-hit RISS queries: "화용언어 표준화 성인" (0), "청소년 화용언어... 국내 도구 개발" (0 of 12). The one 2024-vintage candidate found this session, **C-SLT** (아동 사회적 언어 검사, 천근아, ages 6-12), is also child-only and doesn't change the verdict. |
| KOPLAC child version stops at 12;11 | **HOLDS,** verbatim-confirmed against the original paper's own text ("5- to 12-year-old children"), not just a secondary citation. | — |
| Zero published datasets from KOPLAC/CPLC | **HOLDS**, with one nuance: CPLC's 2018 companion study did **collect** 28 children's conversation transcripts once — they were simply never published or deposited. "Zero **published**" is correct; "zero data ever collected" would not be. | `DATASET_CENSUS_KO.csv` (KOPLAC), `국내_화용평가도구.md` "③ 데이터 공개 · 0건" table (CPLC). |
| Zero Korean studies with SCD-only samples | **HOLDS**, with one nuance: Jin & Pae 2014 (P09) **does contain** a Korean SCD subgroup (n=15) — but it is a 3-group comparison (SCD/HFA/TD), not an SCD-**only** sample, and its SCD label is checklist-algorithmic, not clinician-DSM-5. So "SCD-only" and "clinician-diagnosed" both still fail; "any Korean study with any SCD group at all" would not (P09 and M08/Yoo 2025 both exist, but neither isolates SCD-only results). | `SEARCH_LOG.md` §3 lists "한국 SCD 코호트 연구" as a defined-search absence; `AGE_EVIDENCE.md` §7 item 8 ran a Korea/Japan/China query (435 hits screened) and found none. |

All four claims hold. Nothing was found that contradicts them outright; the two nuances above (CPLC's uncollected-but-unpublished 28-transcript dataset; Jin & Pae's non-isolable SCD subgroup) refine rather than overturn them.

---

## 5. What is genuinely absent

Stated plainly, each with the files checked:

1. **No STRICT (clinician-DSM-5-diagnosed) SCD sample of any age has ever had any of the S1-S8 skills measured behaviorally.** Checked: `SCD_STUDY_CENSUS.csv` rows D01-D05, `SCD_STUDY_COUNTS.md`. Even S3 and S4 — the two skills with any SCD/SPCD-labeled evidence — rest on the algorithmic/labeled tier (Svindt & Surányi 2021, Jin & Pae 2014), not the strict tier.
2. **No Korean SCD-only clinical sample exists at any age.** Checked: `SEARCH_LOG.md` §3, `AGE_EVIDENCE.md` §7 item 8, `TARGET_EVIDENCE_MATRIX.csv` row `SCD child,8_korean_language` (WEAK — Jin & Pae 2014 is "real... but algorithmic, not diagnostic"). The only Korean SCD-adjacent behavioral data point in the entire census is Jin & Pae 2014, n=15, checklist-defined, classroom observation, no repair/clarification measurement.
3. **No downloadable, item-level, human-annotated conversational gold exists for SCD children — or for any clinical population in this census — in any language.** Checked: `TARGET_DECISION.md` §2 table ("임상군 전체가 그렇다... Human Gold 가 MODERATE 이상인 것은 ASD 아동뿐이고 그것도 한국어가 NONE"); `DATA_GAP_MATRIX.csv` row L4 ("없음... 0건"); `TARGET_EVIDENCE_MATRIX.csv` row `SCD child,4_human_gold` = WEAK (SCIP-GAS is a parent/practitioner goal-attainment rating, not annotated-corpus gold).
4. **No natural-conversation corpus from a DSM-5-diagnosed SCD sample, any age, has ever been collected and released.** Checked verbatim in two independent censuses — `AGE_EVIDENCE.md` §6.5 / §9 note 5 ("Natural conversation data is scarce at every age and absent in SCD... None is a DIRECT SCD sample") and `agent_scd_census.md` §4 ("No study was found that recruited a DSM-5 SPCD-diagnosed sample... and collected and released a natural conversation corpus").
5. **No Korean standardized pragmatic assessment tool covers age 13 and up**, confirmed independently twice (§4.2 above) — this blocks any pre/post standardized-instrument claim for an adolescent-or-older Korean target, not just a child one.
6. **The TOPICC instrument's item list and reliability figures are unrecoverable from any source tried.** Checked: `agent_scd_census.md` §3 (only primary citation is a non-indexed 2011 trade-magazine article; distributor domain is DNS-dead with no Wayback snapshot) — relevant because TOPICC underlies part of the S3/S4/S7 evidence above and its per-aspect results (which specific pragmatic behaviors were impaired) cannot be checked against the original instrument.
7. **A literal breakdown of the "problem-grounding /6" score cited in §1.1 was not found as a named rubric anywhere in the local files** — only the final per-population numbers (`TARGET_DECISION.md`) and the underlying per-criterion citations this document reconstructed from (`TARGET_EVIDENCE_MATRIX.csv`). Flagged rather than invented.
8. **KCI, RISS (beyond the 2026-09-11/09-14 partial passes already logged) and DBpia were not queried** for this document or for any of the source files it draws on above 2026-09-11 (`SEARCH_LOG.md` §2: "KCI·RISS·DBpia... 조회하지 않음"). A Korean SCD study, a Korean pragmatic tool above age 13, or a KOPLAC/CPLC dataset could in principle exist in those databases specifically. This is the single limitation that most directly threatens the "zero Korean SCD study" and "no Korean tool above 13" findings this whole case leans on.

---

## Appendix: file-to-claim traceability

Every numeric or verbatim claim above is drawn from one of these 21 local files: `SCD_STUDY_CENSUS.csv`, `SCD_STUDY_COUNTS.md`, `AGE_EVIDENCE.md`, `AGE_EVIDENCE_MATRIX.csv`, `ASSESSMENT_TOOL_MATRIX.csv`, `DATA_GAP_MATRIX.csv`, `EVIDENCE_LEDGER.csv`, `EVIDENCE_LEDGER_NOTE.md`, `DATASET_CENSUS_NOTE.md`, `DATASET_CENSUS_KO.csv`, `SEARCH_LOG.md`, `_agent_pragmatics_review.md`, `ONTOLOGY_SCOPE_FINAL.md`, `agent_scd_census.md`, `SCD_문헌.md`, `국내_화용평가도구.md`, `TARGET_EVIDENCE_MATRIX.csv`, `TARGET_DECISION.md`, `SKILL_EVIDENCE_MATRIX.csv`, `FINAL_SKILL_SCOPE.md`, `_agent_target_korea.md` + `_tools_ko_draft.md` + `_agent_target_clinical_LOG.md`. No claim in this document rests on a file not in this list.
