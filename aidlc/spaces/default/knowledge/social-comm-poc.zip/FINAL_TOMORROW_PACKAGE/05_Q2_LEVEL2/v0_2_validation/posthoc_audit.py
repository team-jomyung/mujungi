# -*- coding: utf-8 -*-
"""v0.2 생성물 사후 감사.

    python posthoc_audit.py

**실행 중에 쓴 검사가 아니다.** 9장면을 다 만든 뒤에 따로 돌린다.
실행 때의 합격·불합격 판정을 바꿔 적지 않는다. 두 숫자를 나란히 둔다.

왜 하는가
  실행 때 쓴 `INSTITUTIONAL` 은 팀장 · 마감 · 결재 같은 어휘 표지만 본다.
  동료 · 회사 · 직장은 목록에 없다. 그래서 친구에서 동료로 간 장면이 통과했다.
  검사가 자기가 집행한다고 주장하는 규칙보다 약했다.
"""
from __future__ import annotations

import io
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))

# 실행 때 쓴 것
RUNTIME = re.compile(r'(팀장|부장|과장|대표|고객사|거래처|인턴|정규직|마감|결재|'
                     r'교수님|계약|평가|승진|면접)')
# 사후에 넓힌 것. 직장 프레임을 가리키는 낱말을 더 넣는다
WORKPLACE = re.compile(r'(동료|직장|회사|사내|업무|프로젝트|부서|상사|사수|점장|'
                       r'출근|퇴근|회의|보고|결재|팀원|팀장|부장|과장|대표|고객사|'
                       r'거래처|인턴|정규직|마감|계약|승진|면접|공식적)')
# 규격 enum 이 장면 본문에 샜는가.
# 뒤에 \b 를 쓰면 안 된다. 한글도 \w 라서 "CLUB_SENIOR의" 에는 경계가 안 생긴다.
ENUM = re.compile(r'(?<![A-Za-z0-9_])'
                  r'(FRIEND_CASUAL|FRIEND_PRIVATE|CLUB_SENIOR|TEAMMATE|SCHOOL_GROUP|'
                  r'DORM_SENIOR|PROFESSOR|INTERN_SUPERVISOR|CROSS_TEAM|CLIENT|'
                  r'SCHOOL_OFFICIAL|FRIEND|CLUB|DORM|WORK)'
                  r'(?![A-Za-z0-9_])')


def hits(rx, t):
    return sorted(set(m.group(0) for m in rx.finditer(t or '')))


def main():
    p = os.path.join(HERE, 'v02_generated.jsonl')
    rows = [json.loads(x) for x in io.open(p, encoding='utf-8') if x.strip()]
    print('v0.2 사후 감사 · 장면 %d' % len(rows))
    print('실행 때 판정을 바꾸지 않는다. 아래는 따로 센 것이다.')
    print()

    drift = []
    leak = []
    seen_anchor = set()
    for r in rows:
        t = r['final_output'] or ''
        w = hits(WORKPLACE, t)
        if w:
            drift.append((r['item_id'], r['distance'], w,
                          bool(hits(RUNTIME, t))))
        for tag, txt in (('변형', t),
                         ('앵커', r['anchor_scene'] if r['anchor_id'] not in seen_anchor else '')):
            e = hits(ENUM, txt)
            if e:
                leak.append(('%s %s' % (r['anchor_id'] if tag == '앵커' else r['item_id'], tag), e))
        seen_anchor.add(r['anchor_id'])

    print('직장 프레임 낱말이 들어간 장면 %d / %d' % (len(drift), len(rows)))
    for iid, g, w, caught in drift:
        print('  %-16s %-13s %s  %s' % (iid, g, ','.join(w),
                                        '실행 때도 걸림' if caught else '<- 실행 때는 통과'))
    missed = [x for x in drift if not x[3]]
    print()
    print('실행 검사가 놓친 장면 %d' % len(missed))
    if missed:
        print('  등급 ·', ', '.join(sorted(set(x[1] for x in missed))))

    print()
    print('규격 enum 이 본문에 샌 곳 %d' % len(leak))
    for where, e in leak:
        print('  %-20s %s' % (where, ','.join(e)))

    print()
    print('읽는 법')
    print('  실행 때의 8/9 는 **어휘 표지 검사**를 통과했다는 뜻이다.')
    print('  관계와 자리가 실제로 유지됐는지는 이 감사로도 판정되지 않는다.')
    print('  사람이 봐야 한다 · MANUAL_CONFIRMATION_PENDING')
    return 0


if __name__ == '__main__':
    sys.exit(main())
