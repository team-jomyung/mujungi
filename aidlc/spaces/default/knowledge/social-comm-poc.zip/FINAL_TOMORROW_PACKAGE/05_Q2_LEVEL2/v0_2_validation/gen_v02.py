# -*- coding: utf-8 -*-
"""v0.2 규칙으로 최소 9장면. **성능 발표가 아니라 failure mode 가 줄었는지 확인.**

    python gen_v02.py

v0.1 과 다른 점 하나
  프롬프트에 **CORE_INVARIANT 다섯을 명시하고 바꾸지 말라고 적는다.**
  v0.1 은 등급 규칙만 줬다. 그래서 FAR 여섯이 전부 목적·화행·책임을 같이 바꿨다.

프로토콜을 중간에 바꾸지 않는다
  9장면 전부 같은 모델 · 온도 · seed · 프롬프트 판 · 재시도 한도 2회.
  v0.1 실행에서 한도를 3→2 로 바꿔 섞인 프로토콜이 나온 적이 있다. 되풀이하지 않는다.
"""
from __future__ import annotations

import collections
import io
import json
import os
import re
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, '..', '..', '..'))
sys.path.insert(0, os.path.join(ROOT, 'INSTRUCTOR_FINAL_EVIDENCE', '05_BENCHMARK', 'harness'))
import llm as L  # noqa: E402

sys.path.insert(0, HERE)
from turncount import turns  # noqa: E402

PROMPT_VERSION = 'v0.2-a'
# 턴 세기 방식. 따옴표 기준 -> 화자 라벨 기준으로 고친 판
CHECKER_VERSION = 'turncount-2'
MAX_ATTEMPTS = 2

# 앵커 셋. v0.1 에서 KEEP 판정을 받은 것에서 Core 를 가져오되 장면은 새로 만든다.
ANCHORS = [
    dict(aid='V2-S3', skill='S3', invariant='상대가 껄끄러운 말을 돌려서 했다',
         core=dict(required_inference='돌려 말한 속뜻 알아채기',
                   interaction_goal='관계를 상하지 않게 상황을 정리한다',
                   speech_act='상대의 완곡한 거절을 읽고 대응한다',
                   responsibility_structure='누구의 잘못도 아니다',
                   role_obligation='없다. 사적인 사이다',
                   request_entitlement='상대는 응할 의무가 없다'),
         base=dict(relationship_type='FRIEND_CASUAL', situation_type='FRIEND_PRIVATE',
                   misread_cost='LOW', recoverable=True)),
    dict(aid='V2-S1', skill='S1', invariant='상대가 모르는 걸 안다고 치고 말했다',
         core=dict(required_inference='상대가 무엇을 아는지 짐작하기',
                   interaction_goal='상대가 알아듣게 설명한다',
                   speech_act='설명한다',
                   responsibility_structure='설명하는 내 몫이다',
                   role_obligation='없다. 동등한 사이다',
                   request_entitlement='해당 없음'),
         base=dict(relationship_type='FRIEND_CASUAL', situation_type='FRIEND_PRIVATE',
                   misread_cost='LOW', recoverable=True)),
    dict(aid='V2-S2', skill='S2', invariant='부담 주지 않으면서 부탁해야 했다',
         core=dict(required_inference='부담의 크기를 가늠해 표현 수위 정하기',
                   interaction_goal='관계를 유지하면서 도움을 얻는다',
                   speech_act='부탁한다',
                   responsibility_structure='내 사정이고 상대 탓이 아니다',
                   role_obligation='없다. 호의를 구하는 자리다',
                   request_entitlement='상대는 거절해도 된다'),
         base=dict(relationship_type='CLUB_SENIOR', situation_type='CLUB',
                   misread_cost='LOW', recoverable=True)),
]

# v0.2 등급 규칙. 불변식은 어느 등급에서도 그대로.
RULES = {
    'SAME_CONTEXT': '화제 · 장소 · 등장인물만 바꾼다. 관계와 자리의 성격은 그대로 둔다.',
    'NEAR': '관계 **또는** 자리의 성격 중 하나만 바꾼다. 걸린 것의 크기는 그대로 둔다.',
    'FAR': ('관계와 자리를 **둘 다** 멀리 바꾼다. 다만 사적·또래에서 '
            '회사·상급자·마감 같은 제도적 자리로 건너뛰지 않는다. '
            '여전히 사적인 자리 안에서 멀리 간다. 예 · 친구 → 친척, 동아리 → 이웃.'),
}

BANNED = ('required_inference', 'interaction_goal', 'speech_act', 'role_obligation',
          'request_entitlement', 'responsibility_structure', 'SAME_CONTEXT', 'NEAR',
          'FAR', 'misread_cost', 'recoverable', 'relationship_type', 'situation_type')
TAG = re.compile(r'\[(관계|대가|회복|상황|스킬|목적|행위)\s*[:：]')
LEAK = re.compile(r'(사실은?\s*거절|속으로는|진심은|라는 뜻이[다었]|의미였다|정답은|올바른 (반응|대답))')
# v0.2 에서 새로 막는 것 · 제도적 점프
INSTITUTIONAL = re.compile(r'(팀장|부장|과장|대표|고객사|거래처|인턴|정규직|마감|결재|'
                           r'교수님|계약|평가|승진|면접)')



def violations(t, prev, grade):
    bad = []
    t = (t or '').strip()
    if not t:
        return ['빈 출력']
    if len(t) < 60:
        bad.append('너무 짧다')
    n = turns(t)
    if not (3 <= n <= 7):
        bad.append('턴 %d' % n)
    for w in BANNED:
        if w in t:
            bad.append('기술 낱말 · %s' % w)
            break
    if TAG.search(t):
        bad.append('태그 노출')
    if LEAK.search(t):
        bad.append('정답 노출')
    m = INSTITUTIONAL.search(t)
    if m:
        bad.append('제도적 점프 · %s' % m.group(0))   # v0.2 의 새 규칙
    for p in prev:
        if p and re.sub(r'\s+', '', p) == re.sub(r'\s+', '', t):
            bad.append('앞과 같다')
            break
    return bad


def anchor_prompt(a):
    c = a['core']
    NL = chr(10)
    return ('아래 상황이 실제로 벌어지는 장면을 한국어 대화로 쓰시오.' + NL * 2
            + '무슨 일이었나 · %s' % a['invariant'] + NL
            + '이 자리의 목적 · %s' % c['interaction_goal'] + NL
            + '지금 하는 행위 · %s' % c['speech_act'] + NL
            + '관계 · %s / 자리 · %s' % (a['base']['relationship_type'],
                                      a['base']['situation_type']) + NL * 2
            + '한 줄 상황 설명 뒤에 대화 3~6턴. 화자는 "나" 와 상대 한 사람.' + NL
            + '상대의 속마음을 단정하지 말 것. 어떻게 답해야 하는지 알려 주지 말 것.' + NL
            + '영어 용어나 대괄호 표를 쓰지 말 것.' + NL * 2 + '장면:')


def variant_prompt(a, anchor, grade):
    c = a['core']
    NL = chr(10)
    keep = NL.join([
        '- 이 자리의 목적 · %s' % c['interaction_goal'],
        '- 지금 하는 행위 · %s' % c['speech_act'],
        '- 누구 탓인가 · %s' % c['responsibility_structure'],
        '- 내 역할의 의무 · %s' % c['role_obligation'],
        '- 상대가 응할 의무 · %s' % c['request_entitlement'],
        '- 잘 해내려면 짐작해야 하는 것 · %s' % c['required_inference'],
    ])
    return ('아래는 어떤 사회적 상황이다.' + NL * 2 + anchor + NL * 2
            + '**아래 여섯은 그대로 두어야 한다. 하나라도 달라지면 실패다.**' + NL
            + keep + NL * 2
            + '그대로 둔 채로 아래 규칙만큼 다른 상황을 새로 쓰시오.' + NL
            + '규칙 · %s' % RULES[grade] + NL * 2
            + '한 줄 상황 설명 뒤에 대화 3~6턴. 화자는 "나" 와 상대 한 사람.' + NL
            + '원본과 같은 소재 · 같은 사람으로 쓰지 말 것.' + NL
            + '상대의 속마음을 단정하지 말 것. 어떻게 답해야 하는지 알려 주지 말 것.' + NL
            + '영어 용어나 대괄호 표를 쓰지 말 것.' + NL * 2 + '장면:')


def produce(prompt, prev, grade):
    att = []
    for i in range(1, MAX_ATTEMPTS + 1):
        try:
            r = L.generate(prompt, max_tokens=320, stop=['\n\n\n'])
        except L.LLMError as e:
            att.append({'attempt': i, 'error': str(e)})
            continue
        raw = (r['text'] or '').strip()
        bad = violations(raw, prev + [x.get('raw', '') for x in att], grade)
        att.append({'attempt': i, 'raw': raw, 'violations': bad,
                    'seconds': r['seconds']})
        if not bad:
            return raw, att, ''
    last = next((x for x in reversed(att) if 'raw' in x), None)
    return (last['raw'] if last else ''), att, '%d번 다 규칙을 어겼다' % MAX_ATTEMPTS


def main():
    if not L.alive():
        print('ollama 가 없다')
        return 2
    print('v0.2 최소 검증 · 앵커 %d × 등급 3 = %d장면' % (len(ANCHORS), len(ANCHORS) * 3))
    print('  모델 %s · seed %s · temp 0 · prompt %s · 검사기 %s · 재시도 %d회 (전부 동일)'
          % (L.GEN_MODEL, L.SEED, PROMPT_VERSION, CHECKER_VERSION, MAX_ATTEMPTS))
    print()
    t0 = time.time()
    rows = []
    with io.open(os.path.join(HERE, 'v02_generated.jsonl'), 'w',
                 encoding='utf-8', newline=chr(10)) as fh:
        for a in ANCHORS:
            ascene, aatt, anote = produce(anchor_prompt(a), [], 'anchor')
            print('  %-7s 앵커 · 시도 %d %s' % (a['aid'], len(aatt),
                                             ('· ' + anote) if anote else ''))
            prev = [ascene]
            for grade in ('SAME_CONTEXT', 'NEAR', 'FAR'):
                sc, att, note = produce(variant_prompt(a, ascene, grade), prev, grade)
                prev.append(sc)
                row = {'item_id': '%s-%s' % (a['aid'], grade[:4]), 'anchor_id': a['aid'],
                       'skill': a['skill'], 'distance': grade,
                       'spec_version': 'v0.2', 'prompt_version': PROMPT_VERSION,
                       'checker_version': CHECKER_VERSION,
                       'anchor_scene': ascene, 'final_output': sc,
                       'core_invariants': a['core'],
                       'attempt_count': len(att), 'regenerated': len(att) > 1,
                       'violations_by_attempt': [x.get('violations') for x in att],
                       'unresolved': note, 'all_attempts': att,
                       'model': L.GEN_MODEL, 'seed': L.SEED, 'temperature': 0,
                       'max_attempts': MAX_ATTEMPTS, 'human_edited': False,
                       'SEMANTIC_STATUS': 'MANUAL_CONFIRMATION_PENDING'}
                rows.append(row)
                fh.write(json.dumps(row, ensure_ascii=False) + chr(10))
                fh.flush()
                print('    %-14s 시도 %d %s' % (grade, len(att),
                                              ('· ' + note) if note else ''))
    inst = sum(1 for r in rows
               for v in (r['violations_by_attempt'] or [])
               if v and any('제도적 점프' in x for x in v))
    print()
    print('장면 %d · %.1f분' % (len(rows), (time.time() - t0) / 60))
    print('  규칙 다 지킨 것 %d · 끝내 못 고친 것 %d'
          % (sum(1 for r in rows if not r['unresolved']),
             sum(1 for r in rows if r['unresolved'])))
    print('  제도적 점프로 걸린 시도 %d회  <- v0.1 에서 FAR 을 다 깨뜨린 그 패턴' % inst)
    print('  기술 ·', dict(collections.Counter(r['skill'] for r in rows)))
    print('  **의미 판정은 사람 몫** · MANUAL_CONFIRMATION_PENDING')
    return 0


if __name__ == '__main__':
    sys.exit(main())
