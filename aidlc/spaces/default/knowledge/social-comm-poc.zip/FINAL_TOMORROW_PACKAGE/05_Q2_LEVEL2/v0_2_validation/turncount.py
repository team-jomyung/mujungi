# -*- coding: utf-8 -*-
"""대화 턴 세기. 화자 라벨이 붙은 줄을 턴으로 본다.

이전 판은 따옴표가 있는 줄을 셌다. v0.1 프롬프트에서는 모델이 따옴표를 붙여서
우연히 맞았고, v0.2 프롬프트에서는 따옴표를 붙이지 않아 전부 0턴이 됐다.
형식이 아니라 구조로 센다.
"""
from __future__ import annotations

import re

# 화자가 아니라 머리말인 것. 이 라벨은 턴으로 세지 않는다.
HEADINGS = ('상황', '상황 설명', '상황설명', '대화', '장면', '배경', '설명',
            '예시', '참고', '규칙', '주의', '해설', '정답')

LABEL = re.compile(r'^[\s*_\-•>#]*([가-힣A-Za-z][가-힣A-Za-z0-9 ]{0,7}?)[\s*_]*[:：]')


def is_turn(line):
    s = line.strip()
    if not s or s.startswith('('):
        return False
    m = LABEL.match(s)
    if not m:
        return False
    label = m.group(1).strip()
    if label in HEADINGS:
        return False
    # 라벨 뒤에 실제 발화가 있어야 한다. 굵게 표시는 발화가 아니다
    return bool(s[m.end():].strip(' 	*_"“”'))


def turns(text):
    return sum(1 for ln in (text or '').split(chr(10)) if is_turn(ln))


def speakers(text):
    out = []
    for ln in (text or '').split(chr(10)):
        if is_turn(ln):
            lab = LABEL.match(ln.strip()).group(1).strip()
            if lab not in out:
                out.append(lab)
    return out
