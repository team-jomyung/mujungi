# -*- coding: utf-8 -*-
"""v0.2 최소 검증 집계.

    python summarize_v02.py

자동 규칙 검사 결과만 센다. **같은 능력을 요구하는가는 세지 않는다.**
그것은 사람이 봐야 하고, 아직 안 봤다.
"""
from __future__ import annotations

import collections
import difflib
import io
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))


def load():
    p = os.path.join(HERE, 'v02_generated.jsonl')
    return [json.loads(x) for x in io.open(p, encoding='utf-8') if x.strip()]


def kind(v):
    """위반 문자열을 종류로 줄인다."""
    if v.startswith('턴 '):
        return '턴 수'
    for k in ('제도적 점프', '기술 낱말', '태그 노출', '정답 노출', '앞과 같다',
              '너무 짧다', '빈 출력'):
        if v.startswith(k):
            return k
    return v


def retry_similarity(rows):
    """시도 1과 시도 2가 얼마나 같은가. temp=0 에서 재시도가 뜻이 있는지 본다."""
    out = []
    for r in rows:
        raws = [a.get('raw', '') for a in r['all_attempts'] if a.get('raw')]
        if len(raws) >= 2:
            a = re.sub(r'\s+', '', raws[0])
            b = re.sub(r'\s+', '', raws[1])
            out.append(difflib.SequenceMatcher(None, a, b).ratio())
    return out


def main():
    rows = load()
    n = len(rows)
    print('v0.2 최소 검증 · 장면 %d' % n)
    proto = {k: sorted({str(r.get(k)) for r in rows})
             for k in ('model', 'seed', 'prompt_version', 'checker_version', 'max_attempts')}
    print('  프로토콜 ·', ' / '.join('%s=%s' % (k, ','.join(v)) for k, v in proto.items()))
    if any(len(v) > 1 for v in proto.values()):
        print('  ** 프로토콜이 섞였다. 집계하지 않는다 **')
        return 1
    print()

    ok = [r for r in rows if not r['unresolved']]
    print('규칙을 다 지킨 장면 %d / %d' % (len(ok), n))
    by_grade = collections.Counter(r['distance'] for r in ok)
    for g in ('SAME_CONTEXT', 'NEAR', 'FAR'):
        tot = sum(1 for r in rows if r['distance'] == g)
        print('  %-14s %d / %d' % (g, by_grade.get(g, 0), tot))
    print()

    cnt = collections.Counter()
    inst_by_grade = collections.Counter()
    for r in rows:
        for vs in (r['violations_by_attempt'] or []):
            for v in (vs or []):
                cnt[kind(v)] += 1
                if kind(v) == '제도적 점프':
                    inst_by_grade[r['distance']] += 1
    print('위반 종류별 시도 수')
    for k, c in cnt.most_common():
        print('  %-10s %d' % (k, c))
    print()
    print('제도적 점프가 걸린 시도 · 등급별')
    for g in ('SAME_CONTEXT', 'NEAR', 'FAR'):
        print('  %-14s %d' % (g, inst_by_grade.get(g, 0)))
    words = collections.Counter()
    for r in rows:
        for vs in (r['violations_by_attempt'] or []):
            for v in (vs or []):
                if v.startswith('제도적 점프'):
                    words[v.split('·')[-1].strip()] += 1
    if words:
        print('  걸린 낱말 ·', dict(words.most_common()))
    print()

    sims = retry_similarity(rows)
    if sims:
        print('재시도가 뜻이 있었나 · 시도1 대 시도2 문자 일치율')
        print('  평균 %.2f · 최소 %.2f · 최대 %.2f · 표본 %d'
              % (sum(sims) / len(sims), min(sims), max(sims), len(sims)))
        print('  temp=0 · seed 고정이라 두 시도가 거의 같은 글이다.')
        print('  재시도는 확률적 다양성을 전제하는데 이 설정에는 그 전제가 없다.')
    print()
    print('사람이 고친 문장 %d' % sum(1 for r in rows if r.get('human_edited')))
    print('의미 판정 ·', sorted({r.get('SEMANTIC_STATUS') for r in rows}))
    print()
    print('** 위 수치는 자동 규칙 검사 결과다. 같은 능력을 요구하는가는 여기 없다. **')
    return 0


if __name__ == '__main__':
    sys.exit(main())
