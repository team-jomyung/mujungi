# -*- coding: utf-8 -*-
"""Level 2 결과를 기계로만 잰다. 의미 판정은 하지 않는다.

    python check_l2.py

재는 것 · format validity · duplicate · lexical overlap · length · turn count ·
          forbidden metadata · answer leakage · core 유지

**안 재는 것** · "정말 같은 화용 능력을 요구하는가".
그것은 사람이 읽어야 안다. 자동 검사만으로 VALIDATED 처리하지 않는다.
상태는 `AUTOMATICALLY CHECKED · NEEDS HUMAN SEMANTIC CONFIRMATION` 이다.
"""
from __future__ import annotations

import collections
import csv
import io
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, 'results', 'level2_generated.jsonl')
BANNED = ('required_inference', 'perspective_structure', 'decidable_by_evidence',
          'direct_check_allowed', 'target_skill', 'SAME_CONTEXT', 'NEAR', 'FAR',
          'misread_cost', 'recoverable', 'relationship_type', 'situation_type')
TAG = re.compile(r'\[(관계|대가|회복|상황|스킬|skill)\s*[:：]')
LEAK = re.compile(r'(사실은?\s*거절|속으로는|진심은|라는 뜻이[다었]|의미였다|정답은|올바른 (반응|대답))')


def toks(t):
    return set(re.findall(r'[가-힣]{2,}', t or ''))


def jac(a, b):
    return round(len(a & b) / len(a | b), 4) if (a | b) else 0.0


def turns(s):
    return sum(1 for ln in (s or '').split(chr(10))
               if ln.strip() and not ln.strip().startswith('(')
               and ('"' in ln or '“' in ln))


def main():
    if not os.path.exists(SRC):
        print('결과가 없다 · generate_l2.py 를 먼저 돌린다')
        return 2
    rows = [json.loads(x) for x in io.open(SRC, encoding='utf-8') if x.strip()]
    out, seen = [], {}
    for r in rows:
        s = r['final_output'] or ''
        a = r['anchor_scene'] or ''
        n = turns(s)
        dup = ''
        key = re.sub(r'\s+', '', s)
        if key and key in seen:
            dup = seen[key]
        elif key:
            seen[key] = r['item_id']
        out.append({
            'item_id': r['item_id'], 'anchor_id': r['anchor_id'], 'skill': r['skill'],
            'distance': r['distance'], 'anchor_origin': r['anchor_origin'],
            'format_ok': 'PASS' if (s and 3 <= n <= 7 and len(s) >= 60) else 'FAIL',
            'turns': n, 'chars': len(s),
            'duplicate_of': dup or '-',
            'lexical_overlap_with_anchor': jac(toks(a), toks(s)),
            'meta_leak': 'FAIL' if (any(w in s for w in BANNED) or TAG.search(s)) else 'PASS',
            'answer_leak': 'FAIL' if LEAK.search(s) else 'PASS',
            'attempt_count': r['attempt_count'],
            'regenerated': 'YES' if r['regenerated'] else 'NO',
            'unresolved': r['unresolved'] or '-',
            'human_edited': 'NO',
            'SEMANTIC_STATUS': 'NEEDS_HUMAN_SEMANTIC_CONFIRMATION',
        })
    p = os.path.join(HERE, 'results', 'AUTO_CHECK_L2.csv')
    with io.open(p, 'w', encoding='utf-8-sig', newline='') as fh:
        w = csv.DictWriter(fh, fieldnames=list(out[0].keys()))
        w.writeheader()
        w.writerows(out)

    print('Level 2 자동 검사 · %d항목' % len(out))
    for col in ('format_ok', 'meta_leak', 'answer_leak'):
        c = collections.Counter(x[col] for x in out)
        print('  %-12s PASS %2d · FAIL %d' % (col, c['PASS'], c['FAIL']))
    print('  중복 · %d' % sum(1 for x in out if x['duplicate_of'] != '-'))
    print('  다시 만든 것 · %d · 끝내 못 고친 것 · %d'
          % (sum(1 for x in out if x['regenerated'] == 'YES'),
             sum(1 for x in out if x['unresolved'] != '-')))
    print()
    print('  등급별 어휘 겹침 (원본 대 변형)')
    for g in ('SAME_CONTEXT', 'NEAR', 'FAR'):
        v = sorted(x['lexical_overlap_with_anchor'] for x in out if x['distance'] == g)
        if v:
            print('    %-14s 중앙 %.3f · n=%d' % (g, v[len(v) // 2], len(v)))
    print()
    print('  **의미 판정은 여기서 하지 않는다** · NEEDS_HUMAN_SEMANTIC_CONFIRMATION')
    print('  저장 · results/AUTO_CHECK_L2.csv')
    return 0


if __name__ == '__main__':
    sys.exit(main())
