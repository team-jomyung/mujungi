# -*- coding: utf-8 -*-
"""Level 2 · 새 앵커에서 SAME/NEAR/FAR 를 **자동으로** 만든다.

    python generate_l2.py
    python generate_l2.py --limit 2      짧게 시험

Level 1 과 무엇이 다른가
  Level 1 · 규격을 읽고 사람(모델)이 장면을 직접 써서, 규격이 쓸 만한지 본다
  Level 2 · 앵커와 규칙만 주고 **사람이 문장에 손대지 않고** 모델이 만든다

  그래서 Level 1 은 규격의 성능이고 Level 2 는 **생성기의 성능**이다.
  둘을 한 숫자로 합치지 않는다.

사람이 문장을 고치지 않는다
  다시 만드는 것은 **객관적으로 어긴 때만** 허용한다.
    형식 불량 · 빈 출력 · 중복 · 메타정보 노출 · 정답 노출 · 구조 제약 위반
  "그냥 어색해 보여서" 다시 만들지 않는다. 그건 사람이 고치는 것과 같다.

무엇을 남기나
  raw_model_output 을 그대로 남긴다. 고친 것이 있으면 무엇을 왜 고쳤는지 남긴다.
  실패한 시도도 남긴다. 실패를 지우면 생성기 성능을 부풀리는 것이다.
"""
from __future__ import annotations

import argparse
import collections
import io
import json
import os
import re
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.abspath(os.path.join(
    HERE, '..', '..', '..', 'INSTRUCTOR_FINAL_EVIDENCE', '05_BENCHMARK', 'harness')))
import anchors_l2 as AN  # noqa: E402
import llm as L  # noqa: E402

OUT = os.path.abspath(os.path.join(HERE, '..', 'results'))
PROMPT_VERSION = 'L2-v1'
MAX_ATTEMPTS = 2   # 3회는 시간만 먹는다. 2회로 줄이고 실패를 그대로 남긴다

RULES = {
    'SAME_CONTEXT': ('화제 · 장소 · 등장인물만 바꾼다. '
                     '관계 · 자리의 성격 · 잘못됐을 때 치를 것 · 되돌릴 수 있는지는 **그대로 둔다**.'),
    'NEAR': ('관계 **또는** 자리의 성격 중 하나를 바꾼다. '
             '잘못됐을 때 치를 것과 되돌릴 수 있는지는 **그대로 둔다**.'),
    'FAR': ('관계 또는 자리의 성격을 바꾸고, **동시에** 잘못됐을 때 치를 것 또는 '
            '되돌릴 수 있는지도 바꾼다.'),
}

BANNED = ('required_inference', 'perspective_structure', 'decidable_by_evidence',
          'direct_check_allowed', 'target_skill', 'SAME_CONTEXT', 'NEAR', 'FAR',
          'misread_cost', 'recoverable', 'relationship_type', 'situation_type',
          'RECOGNIZE', 'PRODUCT')
TAG_RX = re.compile(r'\[(관계|대가|회복|상황|스킬|skill)\s*[:：]')
LEAK_RX = re.compile(r'(사실은?\s*거절|속으로는|진심은|라는 뜻이[다었]|의미였다|'
                     r'정답은|올바른 (반응|대답)|이때는 .{0,12}해야)')


def turns(sc):
    return sum(1 for ln in sc.split(chr(10))
               if ln.strip() and not ln.strip().startswith('(')
               and ('"' in ln or '“' in ln))


def violations(text, prev_texts):
    """**객관적으로** 어긴 것만 센다. 어색함은 여기 안 들어간다."""
    bad = []
    t = (text or '').strip()
    if not t:
        return ['빈 출력']
    if len(t) < 60:
        bad.append('너무 짧다 (%d자)' % len(t))
    n = turns(t)
    if not (3 <= n <= 7):
        bad.append('턴 %d (3~7 밖)' % n)
    for w in BANNED:
        if w in t:
            bad.append('기술 낱말 노출 · %s' % w)
            break
    if TAG_RX.search(t):
        bad.append('태그 노출')
    if LEAK_RX.search(t):
        bad.append('정답·속마음 노출')
    for p in prev_texts:
        if p and _norm(p) == _norm(t):
            bad.append('앞 출력과 같다')
            break
    return bad


def _norm(t):
    return re.sub(r'\s+', '', t or '')


def anchor_prompt(a):
    return (
        '아래 구조를 읽고 **그 상황이 실제로 벌어지는 장면**을 한국어 대화로 쓰시오.%s%s'
        '한 줄 상황 설명 뒤에 대화 3~6턴.%s'
        '화자는 "나" 와 상대 한 사람.%s%s'
        '무슨 일이었나 · %s%s'
        '관계 · %s / 자리 · %s%s%s'
        '지켜야 할 것%s'
        '- 상대의 속마음을 단정하지 말 것. "사실은 거절이었다" 같은 해설 금지%s'
        '- 어떻게 답해야 하는지 알려 주지 말 것%s'
        '- 대괄호 표나 영어 용어를 쓰지 말 것%s'
        '- 실제 학교 · 회사 이름을 쓰지 말 것%s%s'
        '장면:'
        % (chr(10), chr(10), chr(10), chr(10), chr(10),
           a['invariant'], chr(10),
           a['base']['relationship_type'], a['base']['situation_type'],
           chr(10), chr(10), chr(10), chr(10), chr(10), chr(10), chr(10), chr(10)))


def variant_prompt(a, anchor_scene, grade):
    return (
        '아래는 어떤 사회적 상황이다.%s%s%s%s'
        '이 상황이 요구하는 핵심은 이것이다 · %s%s%s'
        '같은 핵심을 그대로 요구하면서, 아래 규칙대로 **다른 상황**을 새로 쓰시오.%s'
        '규칙 · %s%s%s'
        '한 줄 상황 설명 뒤에 대화 3~6턴. 화자는 "나" 와 상대 한 사람.%s%s'
        '지켜야 할 것%s'
        '- 원본과 같은 소재 · 같은 사람으로 쓰지 말 것%s'
        '- 상대의 속마음을 단정하지 말 것%s'
        '- 어떻게 답해야 하는지 알려 주지 말 것%s'
        '- 대괄호 표나 영어 용어를 쓰지 말 것%s%s'
        '장면:'
        % (chr(10), chr(10), anchor_scene, chr(10) * 2,
           a['core']['required_inference'], chr(10), chr(10), chr(10),
           RULES[grade], chr(10), chr(10), chr(10), chr(10), chr(10),
           chr(10), chr(10), chr(10), chr(10), chr(10)))


def gen(prompt, max_tokens=320):
    r = L.generate(prompt, max_tokens=max_tokens, stop=['\n\n\n'])
    return r


def produce(prompt, prev, label, fh, meta):
    """규칙을 어기면 다시. **어색함으로는 다시 안 한다.**"""
    attempts = []
    for i in range(1, MAX_ATTEMPTS + 1):
        try:
            r = gen(prompt)
        except L.LLMError as e:
            attempts.append({'attempt': i, 'error': str(e)})
            continue
        raw = (r['text'] or '').strip()
        bad = violations(raw, prev + [a['raw'] for a in attempts if 'raw' in a])
        attempts.append({'attempt': i, 'raw': raw, 'violations': bad,
                         'seconds': r['seconds'], 'output_tokens': r['output_tokens']})
        if not bad:
            return raw, attempts, ''
    # 세 번 다 어겼다. **고르지 않고 마지막 것을 그대로 남긴다.**
    last = next((x for x in reversed(attempts) if 'raw' in x), None)
    return (last['raw'] if last else ''), attempts, '세 번 다 규칙을 어겼다'


def main(argv):
    ap = argparse.ArgumentParser()
    ap.add_argument('--limit', type=int, default=0)
    ap.add_argument('--start', type=int, default=0)
    ap.add_argument('--append', action='store_true')
    a_ = ap.parse_args(argv)
    if not L.alive():
        print('ollama 가 없다')
        return 2
    if AN.check_disjoint():
        print('**Level 1 앵커와 겹친다** · %s' % AN.check_disjoint())
        return 2
    if not os.path.isdir(OUT):
        os.makedirs(OUT)

    anchors = AN.ANCHORS[a_.start:]
    if a_.limit: anchors = anchors[:a_.limit]
    print('Level 2 자동 생성 · 앵커 %d · 등급 3 = %d항목'
          % (len(anchors), len(anchors) * 3))
    print('  모델 %s · seed %s · temp 0 · prompt %s'
          % (L.GEN_MODEL, L.SEED, PROMPT_VERSION))
    print()
    t0 = time.time()
    rows = []
    with io.open(os.path.join(OUT, 'level2_generated.jsonl'),
                 'a' if a_.append else 'w',
                 encoding='utf-8', newline=chr(10)) as fh:
        for a in anchors:
            global_meta = {'anchor_id': a['anchor_id'], 'skill': a['skill']}
            ascene, aatt, anote = produce(anchor_prompt(a), [], 'anchor', fh, global_meta)
            print('  %-8s 앵커 · 시도 %d %s' % (a['anchor_id'], len(aatt),
                                            ('· ' + anote) if anote else ''))
            prev = [ascene]
            for grade in ('SAME_CONTEXT', 'NEAR', 'FAR'):
                scene, att, note = produce(variant_prompt(a, ascene, grade), prev,
                                           grade, fh, global_meta)
                prev.append(scene)
                row = {
                    'item_id': '%s-%s' % (a['anchor_id'], grade[:4]),
                    'anchor_id': a['anchor_id'], 'skill': a['skill'],
                    'anchor_origin': a['origin'], 'anchor_seed': a['seed'],
                    'distance': grade,
                    'anchor_scene': ascene, 'anchor_attempts': len(aatt),
                    'final_output': scene,
                    'raw_model_output': att[0].get('raw', '') if att else '',
                    'attempt_count': len(att),
                    'regenerated': len(att) > 1,
                    'regeneration_reason': [x.get('violations') for x in att[:-1]],
                    'unresolved': note,
                    'all_attempts': att,
                    'model_name': L.GEN_MODEL, 'prompt_version': PROMPT_VERSION,
                    'temperature': 0, 'seed': L.SEED, 'num_ctx': L.NUM_CTX,
                    'human_edited': False,
                    'PROVENANCE': 'LLM_GENERATED_NO_HUMAN_EDIT',
                }
                rows.append(row)
                fh.write(json.dumps(row, ensure_ascii=False) + chr(10))
                fh.flush()
                print('    %-14s 시도 %d %s' % (grade, len(att),
                                              ('· ' + note) if note else ''))
    print()
    print('항목 %d · %.1f분' % (len(rows), (time.time() - t0) / 60))
    print('  다시 만든 것 %d · 끝내 규칙을 어긴 것 %d'
          % (sum(1 for r in rows if r['regenerated']),
             sum(1 for r in rows if r['unresolved'])))
    print('  기술 ·', dict(collections.Counter(r['skill'] for r in rows)))
    print('  저장 · level2_generated.jsonl')
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
