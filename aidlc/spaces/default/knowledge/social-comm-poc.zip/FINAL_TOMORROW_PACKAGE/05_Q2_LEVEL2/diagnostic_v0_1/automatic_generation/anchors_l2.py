# -*- coding: utf-8 -*-
"""Level 2 용 앵커 아홉. **Level 1 의 여섯과 겹치지 않는다.**

출처를 셋으로 나눠 적는다. 섞으면 나중에 무엇을 시험한 것인지 모르게 된다.

  SEED_UNUSED     씨앗 파일에 있으나 Level 1 에서 안 쓴 것 (S2 · S7 · S9 · X3)
  SEED_AUTHORED   이번에 구조만 새로 적은 것. S2 기술에 남은 씨앗이 없었다

씨앗 자체도 사람이 쓴 것이 아니다. 씨앗 파일의 origin 이
`SPEC_SESSION_AUTHORED_2026-09-14` 다. 즉 규격을 읽고 모델이 구조를 적었다.
그래서 어느 앵커도 **HUMAN_AUTHORED 라고 부르지 않는다.**

앵커 장면 글 자체는 여기 없다. 모델이 이 구조에서 렌더한다.
사람이 문장을 쓰지 않는 것이 Level 2 의 요점이다.
"""
from __future__ import annotations

ANCHORS = [
    # ── S1 청자 맞춤 정보 조절 ──────────────────────────────
    dict(anchor_id='L2-S1a', skill='S1', origin='SEED_UNUSED', seed='X3',
         invariant='상대가 내 말을 못 따라오는 걸 알아채지 못했다',
         core=dict(target_skill='RECOGNIZE',
                   required_inference='상대가 무엇을 아는지 짐작하기',
                   perspective_structure='상대의 지식 상태 1층',
                   decidable_by_evidence='YES', direct_check_allowed='YES'),
         base=dict(relationship_type='FAMILY', situation_type='FAMILY',
                   misread_cost='LOW', recoverable=True)),
    dict(anchor_id='L2-S1b', skill='S1', origin='SEED_AUTHORED', seed=None,
         invariant='내가 아는 줄임말로만 말해서 상대가 못 알아들었다',
         core=dict(target_skill='RECOGNIZE',
                   required_inference='상대가 무엇을 아는지 짐작하기',
                   perspective_structure='상대의 지식 상태 1층',
                   decidable_by_evidence='YES', direct_check_allowed='YES'),
         base=dict(relationship_type='PEER_SCHOOL', situation_type='SCHOOL',
                   misread_cost='LOW', recoverable=True)),
    dict(anchor_id='L2-S1c', skill='S1', origin='SEED_AUTHORED', seed=None,
         invariant='이미 설명한 것을 상대가 또 물어서 처음부터 다시 말했다',
         core=dict(target_skill='PRODUCT',
                   required_inference='필요한 만큼만 말하기',
                   perspective_structure='상대가 이미 받은 정보 1층',
                   decidable_by_evidence='YES', direct_check_allowed='YES'),
         base=dict(relationship_type='PEER_SCHOOL', situation_type='SCHOOL',
                   misread_cost='LOW', recoverable=True)),

    # ── S2 관계 · 상황 맞춤 조정 ────────────────────────────
    # 씨앗 파일에 이 기술의 미사용 씨앗이 하나도 없다. 구조를 새로 적었다.
    dict(anchor_id='L2-S2a', skill='S2', origin='SEED_AUTHORED', seed=None,
         invariant='같은 부탁을 누구에게 하느냐에 따라 말을 달리해야 했다',
         core=dict(target_skill='PRODUCT',
                   required_inference='부담의 크기를 가늠해 표현 수위 정하기',
                   perspective_structure='상대가 나를 어떻게 봤을지 2층',
                   decidable_by_evidence='YES', direct_check_allowed='NO'),
         base=dict(relationship_type='TEACHER', situation_type='SCHOOL_OFFICIAL',
                   misread_cost='MEDIUM', recoverable=True)),
    dict(anchor_id='L2-S2b', skill='S2', origin='SEED_AUTHORED', seed=None,
         invariant='친한 사이에 쓰던 말투를 처음 보는 자리에서 그대로 썼다',
         core=dict(target_skill='PRODUCT',
                   required_inference='자리에 맞는 거리 잡기',
                   perspective_structure='상대가 나를 어떻게 봤을지 2층',
                   decidable_by_evidence='YES', direct_check_allowed='NO'),
         base=dict(relationship_type='STRANGER', situation_type='PUBLIC',
                   misread_cost='MEDIUM', recoverable=True)),
    dict(anchor_id='L2-S2c', skill='S2', origin='SEED_AUTHORED', seed=None,
         invariant='거절해야 하는데 관계를 생각해 돌려 말하다 뜻이 흐려졌다',
         core=dict(target_skill='PRODUCT',
                   required_inference='거절의 수위를 관계에 맞춰 정하기',
                   perspective_structure='상대가 나를 어떻게 봤을지 2층',
                   decidable_by_evidence='YES', direct_check_allowed='NO'),
         base=dict(relationship_type='PEER_CLUB', situation_type='CLUB',
                   misread_cost='MEDIUM', recoverable=True)),

    # ── S3 함축 이해 ───────────────────────────────────────
    dict(anchor_id='L2-S3a', skill='S3', origin='SEED_UNUSED', seed='S2',
         invariant='불편을 말했지만 원한 건 행동이었다',
         core=dict(target_skill='RECOGNIZE',
                   required_inference='말하지 않은 요청 알아채기',
                   perspective_structure='상대의 의도 2층',
                   decidable_by_evidence='YES', direct_check_allowed='NO'),
         base=dict(relationship_type='FAMILY', situation_type='FAMILY',
                   misread_cost='LOW', recoverable=True)),
    dict(anchor_id='L2-S3b', skill='S3', origin='SEED_UNUSED', seed='S7',
         invariant='도와주겠다는 건지 불만인지 몰랐다',
         core=dict(target_skill='RECOGNIZE',
                   required_inference='같은 말의 두 읽기 중 고르기',
                   perspective_structure='상대의 의도 2층',
                   decidable_by_evidence='YES', direct_check_allowed='NO'),
         base=dict(relationship_type='PEER_SCHOOL', situation_type='SCHOOL',
                   misread_cost='LOW', recoverable=True)),
    dict(anchor_id='L2-S3c', skill='S3', origin='SEED_UNUSED', seed='S9',
         invariant='말은 괜찮다는데 다른 게 아니라고 했다',
         core=dict(target_skill='RECOGNIZE',
                   required_inference='말과 태도가 어긋날 때 무엇을 믿을지 정하기',
                   perspective_structure='상대의 의도 2층',
                   decidable_by_evidence='YES', direct_check_allowed='NO'),
         base=dict(relationship_type='FRIEND_CASUAL', situation_type='FRIEND_PRIVATE',
                   misread_cost='LOW', recoverable=True)),
]

SKILL_KO = {'S1': '청자 맞춤 정보 조절', 'S2': '관계 · 상황 맞춤 조정', 'S3': '함축 이해'}

# Level 1 이 쓴 앵커. 겹치면 안 된다
LEVEL1_SEEDS = {'S1', 'S3', 'S4', 'S5', 'S10'}


def check_disjoint():
    bad = [a['anchor_id'] for a in ANCHORS if a['seed'] in LEVEL1_SEEDS]
    return bad


if __name__ == '__main__':
    import collections
    print('앵커 %d' % len(ANCHORS))
    print('  기술 ·', dict(collections.Counter(a['skill'] for a in ANCHORS)))
    print('  출처 ·', dict(collections.Counter(a['origin'] for a in ANCHORS)))
    bad = check_disjoint()
    print('  Level 1 과 겹침 ·', bad or '없음')
    print()
    print('**어느 앵커도 사람이 쓴 것이 아니다.** 씨앗 origin 이 SPEC_SESSION_AUTHORED 다.')
