# -*- coding: utf-8 -*-
"""오늘 v0.2 실행에서 나온 질문을 레드팀 문서에 붙인다.

    python add_v02_questions.py

수치는 손으로 적지 않고 `v02_generated.jsonl` 에서 읽는다.
"""
from __future__ import annotations

import collections
import difflib
import io
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
DOC = os.path.join(HERE, 'INSTRUCTOR_RED_TEAM.md')
JL = os.path.join(ROOT, '05_Q2_LEVEL2', 'v0_2_validation', 'v02_generated.jsonl')

MARK = '### 41. v0.2 최소 검증'


def stats():
    rows = [json.loads(x) for x in io.open(JL, encoding='utf-8') if x.strip()]
    ok = [r for r in rows if not r['unresolved']]
    inst = collections.Counter()
    words = collections.Counter()
    for r in rows:
        for vs in (r['violations_by_attempt'] or []):
            for v in (vs or []):
                if v.startswith('제도적 점프'):
                    inst[r['distance']] += 1
                    words[v.split('·')[-1].strip()] += 1
    sims = []
    for r in rows:
        raws = [a.get('raw', '') for a in r['all_attempts'] if a.get('raw')]
        if len(raws) >= 2:
            a, b = (re.sub(r'\s+', '', x) for x in raws[:2])
            sims.append(difflib.SequenceMatcher(None, a, b).ratio())
    per_grade_ok = collections.Counter(r['distance'] for r in ok)
    tot_grade = collections.Counter(r['distance'] for r in rows)
    # 사후 감사 수치도 같은 자료에서 다시 뽑는다
    sys.path.insert(0, os.path.dirname(JL))
    import posthoc_audit as PA
    drift = [r for r in rows if PA.hits(PA.WORKPLACE, r['final_output'])]
    missed = [r for r in drift if not PA.hits(PA.RUNTIME, r['final_output'])]
    return dict(n=len(rows), ok=len(ok), inst=inst, words=words,
                sim=(sum(sims) / len(sims)) if sims else None, nsim=len(sims),
                per_grade_ok=per_grade_ok, tot_grade=tot_grade,
                drift=len(drift), missed=len(missed),
                missed_grades=sorted({r['distance'] for r in missed}))


def block(s):
    g = lambda k: '%d/%d' % (s['per_grade_ok'].get(k, 0), s['tot_grade'].get(k, 0))
    inst_tot = sum(s['inst'].values())
    sim = ('평균 %.2f (표본 %d)' % (s['sim'], s['nsim'])) if s['sim'] is not None else '표본 없음'
    return chr(10).join([
        '### 41. v0.2 최소 검증 첫 실행을 왜 버렸나',
        '**판정** · SUPPORTED',
        '',
        '턴 세는 검사기가 **따옴표가 있는 줄**을 세도록 짜여 있었다.',
        'v0.1 프롬프트에서는 모델이 따옴표를 붙여서 우연히 맞았고,',
        'v0.2 프롬프트로 바꾸자 모델이 따옴표를 버려 모든 장면이 0턴으로 걸렸다.',
        '',
        '검사기가 스펙이 아니라 **모델의 우연한 서식 습관**에 묶여 있었다.',
        '화자 라벨 기준으로 고치고 손으로 쓴 픽스처 10개로 시험한 뒤 9장면을 처음부터 다시 돌렸다.',
        '프롬프트 · 모델 · seed · 온도 · 재시도 한도는 그대로다.',
        '',
        '근거 · `05_Q2_LEVEL2/v0_2_validation/CHECKER_BUG_NOTE.md`',
        '',
        '### 42. 제도적 점프는 v0.1 의 FAR 규칙 탓이라 했는데 맞나',
        '**판정** · PARTIAL',
        '',
        '절반만 맞다. v0.2 실행에서 제도적 점프가 **NEAR 에서도 걸렸다.**',
        '',
        '```',
        'SAME_CONTEXT  %d회' % s['inst'].get('SAME_CONTEXT', 0),
        'NEAR          %d회' % s['inst'].get('NEAR', 0),
        'FAR           %d회' % s['inst'].get('FAR', 0),
        '```',
        '',
        'NEAR 규칙은 "관계 **또는** 자리 중 하나만" 이라 점프를 요구하지 않는다.',
        '그런데도 모델은 맥락을 바꾸라는 말을 들으면 **직장 프레임으로 가는 것을 기본값으로** 삼는다.',
        '',
        'v0.1 진단은 "FAR 규칙이 시킨 것" 이었다. 그것도 사실이지만 범위가 더 넓다.',
        '규칙을 고쳐도 생성기의 기본 이동은 남는다.',
        '',
        '근거 · `05_Q2_LEVEL2/v0_2_validation/v02_generated.jsonl`',
        '',
        '### 43. v0.2 자동 통과가 %d/%d 면 고쳐진 것 아닌가' % (s['ok'], s['n']),
        '**판정** · CANNOT CLAIM · **이 숫자를 성과로 쓰지 않는다**',
        '',
        '실행 때 쓴 검사가 자기가 집행한다는 규칙보다 약했다.',
        '`INSTITUTIONAL` 정규식이 팀장 · 마감 · 결재 같은 **어휘 표지만** 본다.',
        '동료 · 회사 · 직장 · 업무 · 공식적 은 목록에 없었다.',
        '',
        '생성이 끝난 뒤 넓힌 낱말로 다시 세어 보면',
        '',
        '```',
        '직장 프레임 낱말이 들어간 장면   %d / %d' % (s['drift'], s['n']),
        '그중 실행 검사가 놓친 것          %d' % s['missed'],
        '놓친 등급                        %s' % ', '.join(s['missed_grades']),
        '```',
        '',
        'SAME_CONTEXT 두 장면이 친구·사적에서 **동료·회사 근처 카페**로 갔는데 통과했다.',
        'SAME_CONTEXT 는 화제 · 장소 · 등장인물만 바꾸는 등급이다. 관계가 바뀌면 안 된다.',
        '',
        '재시도도 뜻대로 작동하지 않는다. 다시 쓴 글은 문자 일치율 %s 로 달라지지만' % sim,
        '**프레임은 그대로다.** 두 번 다 마감이 걸린 직장 장면을 냈다.',
        '표현을 바꾸지 프레임을 바꾸지 않는다.',
        '',
        '등급별 자동 통과 · SAME_CONTEXT %s · NEAR %s · FAR %s' % (g('SAME_CONTEXT'), g('NEAR'), g('FAR')),
        '',
        '**%d/%d 는 어휘 표지 검사를 통과했다는 뜻이지 규칙을 지켰다는 뜻이 아니다.**' % (s['ok'], s['n']),
        '검사를 강화해 다시 돌리지 않았다. 프로토콜을 중간에 바꾸지 않기로 했기 때문이고,',
        '사후 감사는 실행 때 판정을 고쳐 쓰지 않고 따로 적었다.',
        '',
        '근거 · `05_Q2_LEVEL2/v0_2_validation/POSTHOC_AUDIT.txt`',
        '',
        '### 44. 제도적 점프를 막으면 FAR 가 충분히 멀지 않게 되는 것 아닌가',
        '**판정** · CANNOT CLAIM · **열린 위험이다**',
        '',
        '그럴 수 있다. v0.2 의 FAR 은 친구 → 친척처럼 사적인 자리 안에서 움직인다.',
        '표면 거리가 줄어든 대신 불변식이 살아남는 거래다.',
        '',
        '거리는 자동 검사로 재지 않는다. 검사기는 규칙 위반만 본다.',
        '**충분히 먼가는 사람이 판정해야 하고 아직 안 했다.**',
        '',
        'v0.1 은 "멀지만 다른 과제" 를 만들었다. v0.2 가 "같은 과제지만 가까운 것" 을 만든다면',
        '문제를 반대편으로 옮긴 것뿐이다. 다음 검토에서 이것부터 본다.',
        '',
        '근거 · `03_ONTOLOGY/TRANSFER_RULE_v0_2.md` · 사람 판정 전',
        '',
        '### 45. 생성된 장면에 규격 용어가 섞이지 않았나',
        '**판정** · PARTIAL',
        '',
        '한 곳 샜다. `V2-S2` 앵커 본문이 `CLUB_SENIOR의 멤버인 나` 로 시작한다.',
        '프롬프트에 관계 유형을 enum 값 그대로 넣었고 모델이 받아 적었다.',
        '',
        '금지 낱말 목록에는 필드 **이름**(`relationship_type`)만 있고 **값**(`CLUB_SENIOR`)이 없었다.',
        '다음 판에서는 값도 막고, 프롬프트에 enum 대신 우리말 설명을 넣는다.',
        '',
        '사후 감사에서도 처음에는 0건으로 나왔다. 정규식 뒤에 붙인 `\\b` 때문이다.',
        '한글도 `\\w` 라서 `CLUB_SENIOR의` 에는 경계가 생기지 않는다.',
        '경계를 ASCII 기준 전후방탐색으로 바꿔 다시 세었다.',
        '',
        '근거 · `05_Q2_LEVEL2/v0_2_validation/POSTHOC_AUDIT.txt`',
        ''])


def main():
    if not os.path.exists(JL):
        print('v02_generated.jsonl 이 없다')
        return 2
    s = stats()
    if s['n'] != 9:
        print('장면이 9가 아니라 %d · 아직 안 끝났다' % s['n'])
        return 2
    doc = io.open(DOC, encoding='utf-8').read()
    if MARK in doc:
        doc = doc[:doc.index(MARK)].rstrip() + chr(10) * 2
    doc = doc.rstrip() + chr(10) * 2 + block(s)
    # 머리말 표도 고친다. 손으로 세지 않고 본문의 판정 줄을 다시 센다
    tally = collections.Counter(
        m.group(1).strip() for m in re.finditer(r'^\*\*판정\*\* · (.+)$', doc, re.M))
    for k in ('SUPPORTED', 'PARTIAL', 'CANNOT CLAIM'):
        n = sum(v for kk, v in tally.items() if kk.split(' ·')[0].strip() == k)
        doc = re.sub(r'\| %s \| \d+ \|' % k, '| %s | %d |' % (k, n), doc)
    doc = re.sub(r'\| 합계 \| \d+ \|', '| 합계 | %d |' % sum(tally.values()), doc)
    io.open(DOC, 'w', encoding='utf-8', newline=chr(10)).write(doc)
    print('문답 41~44 추가 · 통과 %d/%d · 제도적 점프 %d회'
          % (s['ok'], s['n'], sum(s['inst'].values())))
    return 0


if __name__ == '__main__':
    sys.exit(main())
