# 강사님 예상 질문 대비

| 판정 | 개수 |
|---|---|
| SUPPORTED | 20 |
| PARTIAL | 13 |
| CANNOT CLAIM | 12 |
| 합계 | 45 |

개수는 본문의 판정 줄을 다시 세어 적는다 (`add_v02_questions.py`).
앞선 판은 손으로 적어 본문과 두 칸이 어긋나 있었다.

**모르는 것을 억지로 방어하지 않는다.** CANNOT CLAIM 은 실패가 아니라
지금 정직하게 모른다고 말할 수 있는 항목이다.

## 가장 위험한 다섯

1. **11 · 우리 CORE 인 S1·S2 에 SCD 표본 근거가 없다** — 정체성 질문이고 한 문장으로 안 끝난다
2. **26 · 온톨로지 향상의 43%가 무관한 글로도 재현된다** — 핵심 기술 주장이 통제에서 흔들린다
3. **28/30 · entity linking 가설이 반증됐다** — 우리가 세운 진단이 틀렸다는 것을 먼저 말해야 한다
4. **17 · Ontology 와 Graph 가 통합되지 않았다** — Neo4j 가 떠 있지 않다
5. **23 · 팀이 판정했고 8/18 이 나왔다** — 우리 규격이 REVISION REQUIRED 를 받았다

---

## A 타겟

### 1. 왜 13~25세에서 SCD 아동으로 바꿨나
**판정** · SUPPORTED

유병률 차이가 아니다. 아동(5~6세) 0~10.5%, 청소년(13~14세) 7~11% 로 비슷하다.
차이는 **행동을 실제로 잰 연구의 밀도**다. 아동에는 화용 과제를 돌린 표본
(Lockton 2016, n=39, TOPICC+AMP)과 유병률 기준점(Saul 2023, n=386)이 있다.
12세 위로는 자기보고 설문 한 코호트(Yoshinaga 2023, n=52)가 전부이고 행동 자료가 0이다.

근거 · `01_TARGET/SCD_CHILD_TARGET_EVIDENCE.md` §1

### 2. SCD 아동 근거가 실제로 더 강한가
**판정** · PARTIAL

문제 근거로는 그렇다. 다만 **DSM-5 임상 진단 표본에서 S1~S8 수준의 행동 결과를 낸
연구는 전 세계에 0편**이다. 강한 것이 아니라 덜 얇은 것이다.

근거 · 같은 문서 §0 · DIRECT_SCD 5편 / 라벨기준 12편 / PLI 10편

### 3. SCD 공개 dataset 이 없는데 왜 SCD 인가
**판정** · SUPPORTED

benchmark 가 없다는 것과 문제 타겟이 틀렸다는 것은 다른 이야기다.
**무엇을 훈련할지**는 임상 문헌이 정하고, **기술이 도는지**는 일반 한국어 benchmark 가 정한다.
데이터가 많은 집단을 타겟으로 삼으면 고칠 문제가 아니라 잴 문제를 푸는 것이 된다.

근거 · `01_TARGET/TARGET_BENCHMARK_SEPARATION.md`

### 4. 일반 한국어 데이터로 SCD 를 검증하는 것 아닌가
**판정** · SUPPORTED

아니다. 그렇게 말하지 않는다. 검증한 것은 **범용 화용 추론 기술의 성능**이고,
SCD 효과는 NOT TESTED 로 적혀 있다.

근거 · `09_CLAIMS/CLAIM_LEDGER.csv`

### 5. 일반 benchmark 가 검증하는 것은 정확히 무엇인가
**판정** · SUPPORTED

넷이다. 맥락에서 함축을 읽어내는가 · 격률 위반을 분류하는가 ·
온톨로지나 검색을 넣으면 달라지는가 · 문자 그대로 읽어 틀리는 비율이 얼마인가.

근거 · `02_DATA/TECHNICAL_BENCHMARK_STATUS.md`

### 6. SCD 아동에게 효과가 있다는 증거가 있나
**판정** · CANNOT CLAIM

없다. 사람 대상 연구를 하지 않았다.
필요한 것 · SCD 아동 참여자 · IRB · 사전사후 설계 · transfer 측정.

근거 · 없음

---

## B Skill

### 7. S1 은 왜 Quantity Maxim 과 연결되나
**판정** · PARTIAL

양의 격률이 "필요한 정도의 정보를 제공하는가" 를 보고, Bishop & Adams 1989 가
화용 손상을 "too much or too little information" 으로 적었다. 같은 것을 가리킨다고 본다.
**이 연결은 우리 해석이고 자료가 준 것이 아니다.**

근거 · `03_ONTOLOGY/SKILL_SCOPE.md`

### 8. S1 전체를 검증하는 것은 아닌가
**판정** · SUPPORTED

아니다. `PARTIAL_BENCHMARK` 로 적었다. 상대가 무엇을 아는지 추론하는 것과
상대에 맞춰 설명 방식을 바꾸는 것은 **안 잰다.**

근거 · 같은 문서

### 9. S3 는 왜 직접 benchmark 라고 부를 수 있나
**판정** · SUPPORTED

문항이 묻는 것이 "이 발화가 이 맥락에서 갖는 뜻" 이고, 우리 `InterpretationAttribution`
이 하는 일과 같다. 오답 구실에 literal 이 표시돼 **문자적 오독률**을 따로 낼 수 있다.

근거 · `INSTRUCTOR_FINAL_EVIDENCE/03_ONTOLOGY/VALIDATABLE_FIELDS.md`

### 10. S2 는 무엇으로 평가하나
**판정** · CANNOT CLAIM

평가하지 못한다. 관계·상황 조정을 라벨로 준 한국어 공개 자료가 없다.
생성하고 사람이 보되 **정확도는 말하지 않는다.**
제품에서 가장 중요한 축인데 임상 근거도 benchmark 도 가장 얇다.

근거 · 없음

### 11. 우리 CORE 인 S1·S2 에 SCD 근거가 있나
**판정** · CANNOT CLAIM

**없다.** 1980~90년대 영어 PLI 초록(n=6~14)이 전부다.
SCD 표본 근거가 있는 것은 S3(헝가리어 n=13)와 S4(한국어 n=15)뿐이고 둘 다 라벨 기준이다.
어느 Skill 도 DSM-5 임상 진단 표본 근거를 갖지 못한다.

근거 · `01_TARGET/SCD_CHILD_TARGET_EVIDENCE.md` §2

### 12. 한국어 SCD 근거가 있는 S4 는 왜 CORE 가 아닌가
**판정** · PARTIAL

불일치가 맞다. census 전체에서 유일한 한국어 SCD 연구(Jin & Pae 2014)가 가리키는 것이
S4 응답성인데 우리는 CONDITIONAL 로 두었다.
**n=15 한 편으로 범위를 바꾸는 것은 앞서 저지른 실수의 반복**이라 이번에 바꾸지 않았다.
다음 범위 개정의 첫 안건이다.

근거 · `03_ONTOLOGY/SKILL_SCOPE.md`

---

## C Ontology

### 13. Ontology 가 두 개인가
**판정** · SUPPORTED

하나다. L1 Ontology 위에 L3 생성 규격과 L4 변환 규칙이 얹힌 5층 구조다.

근거 · `03_ONTOLOGY/ONTOLOGY_LAYER_MODEL.md`

### 14. Pragmatic Structure 도 Ontology 인가
**판정** · SUPPORTED

아니다. L1 의 값들을 조합한 **생성 규격**이다. 새 개념을 도입하지 않는다.

근거 · 같은 문서

### 15. SAME/NEAR/FAR 는 Ontology 인가
**판정** · SUPPORTED

아니다. L1 의 맥락 속성(관계·자리·대가·회복) 중 무엇을 바꾸느냐로 정의한 **변환 규칙**이다.

근거 · 같은 문서

### 16. Ontology 중 실제 검증 가능한 field 는
**판정** · SUPPORTED

7개 중 2개다. `InterpretationAttribution` · `PhenomenonAttribution`.
`GoalAttribution` 과 `StrategyRecommendation` 은 규격 자체가 gold 없음을 적고 있다.

근거 · `INSTRUCTOR_FINAL_EVIDENCE/03_ONTOLOGY/VALIDATABLE_FIELDS.md`

### 17. Ontology 와 Graph 가 통합돼 있나
**판정** · CANNOT CLAIM

**안 됐다.** Neo4j 가 떠 있지 않고(localhost:7474 무응답) 벤치마크 하네스에
cypher 참조가 0건이다. E4 의 "Graph" 는 어휘 4마디짜리 메모리 구조다.
통합됐다고 말하지 않는다.

근거 · `08_GRAPHRAG/current_implementation/E4_IMPLEMENTATION_AUDIT.md`

---

## D 생성

### 18. 현재 Manual Review 는 무엇을 검증하나
**판정** · SUPPORTED

규격이 쓸 만한가(Level 1)다. 생성기 성능이 아니다.

근거 · `04_Q2_LEVEL1/TEAM_MANUAL_RESULT.md`

### 19. 18개 장면은 누가 만들었나
**판정** · SUPPORTED

**LLM 이 만들었다.** 규격을 읽고 모델이 썼고 규칙 위반이 보이면 다시 썼다.
메타데이터의 `HUMAN_AUTHORED_BY_SPEC_SESSION` 표기는 부정확하다.
정확한 이름은 **SPEC-AWARE CURATED LLM GENERATION** 이다.
사람이 한 것은 규격 작성과 재생성 판단이지 문장 작성이 아니다.

근거 · 같은 문서

### 20. 그게 자동 생성기 성능인가
**판정** · SUPPORTED

아니다. 그래서 Level 2 를 따로 돌린다. 처음 보는 앵커 9개에
**사람이 문장에 손대지 않고** 생성한다.

근거 · `05_Q2_LEVEL2/`

### 21. 새 unseen Anchor 에서도 되나
**판정** · PARTIAL

Level 2 결과로 답한다. 앵커는 Level 1 과 겹치지 않고(씨앗 id 대조 확인),
재생성은 **객관적 위반 때만** 허용한다. "어색해 보여서" 다시 쓰지 않는다.

근거 · `05_Q2_LEVEL2/results/level2_generated.jsonl`

### 22. 실제 공개대화에서 End-to-End 가 되나
**판정** · PARTIAL

Level 3 결과로 답한다. 8단계 중간 결과를 전부 남긴다.

근거 · `06_Q2_LEVEL3/`

### 23. 정말 같은 능력을 요구하는지는 누가 정했나
**판정** · SUPPORTED

팀이 블라인드로 판정했다. 리뷰어는 기술 이름도 의도 등급도 모르는 상태였다.
결과는 **같은 능력 8/18**, 의도 FAR 은 **0/6** 이다.

기계는 여전히 어휘 겹침과 바뀐 축까지만 센다. 그 자동 검사를 다 통과한 장면들이
사람 판정에서 10/18 깨졌다. **자동 통과는 같은 능력의 근거가 아니다.**

한계 · 리뷰어 1명 · 18장면.

근거 · `04_Q2_LEVEL1/TEAM_MANUAL_RESULT.csv`

---

## E Ontology / GraphRAG

### 24. Ontology Prompt 가 Plain 보다 나은가
**판정** · PARTIAL

함축에서 0.475 → 0.650 이고 원p=0.039 다.
다만 과제당 비교가 여섯이라 **Holm 보정 후 0.196** 으로 유의하지 않다.
`ONTOLOGY-DEFINED CONTEXT BENEFIT SIGNAL` 까지만 말한다.

근거 · `07_ONTOLOGY_BENCHMARK/`

### 25. 그냥 prompt 에 설명 넣으면 안 되나
**판정** · PARTIAL

실제로 그것이 가장 나았다. E1(정의를 프롬프트에 씀) 0.650 이
E2(JSON 구조) 0.475 · E3(벡터) 0.575 · E4(그래프) 0.525 를 다 이겼다.

근거 · 같은 문서

### 26. 그 향상이 Ontology 내용 때문인가
**판정** · CANNOT CLAIM

가르지 못한다. 같은 길이의 **무관한 글**(문서 편집 규칙)을 넣어도 0.550 이 나왔다.
**향상의 43%가 길이만으로 재현된다.**
`ONTOLOGY-SPECIFIC CAUSAL CONTRIBUTION = NOT ESTABLISHED`

근거 · E1F 길이통제 갈래

### 27. GraphRAG 가 왜 낮았나
**판정** · SUPPORTED

꺼내 오는 **내용**이 안 듣는다. 그래프가 주는 것은 어휘 정의인데,
그 정의는 E1 처럼 프롬프트에 그냥 쓰면 더 잘 듣는다.
`RETRIEVAL DESIGN BOTTLENECK`

근거 · `08_GRAPHRAG/GRAPHRAG_DIAGNOSTIC_REPORT.md`

### 28. Entity linking 이 문제라는 근거는
**판정** · CANNOT CLAIM

**그 가설은 반증됐다.** 입구를 정답으로 고정(25% → 100%)해도 정확도가 **+0.000** 이다.
연결이 우연 수준인 것은 맞지만 병목이 아니다.
우리가 세운 진단이 틀렸다는 것을 먼저 말한다.

근거 · E4-O oracle 시험

### 29. 1홉이라서 문제인 것 아닌가
**판정** · CANNOT CLAIM

아니다. 입구를 정답으로 고정한 상태에서 1홉 0.500 · 2홉 0.525 · 3홉 0.525 다.

근거 · E4-O-h1 / E4-O-h3

### 30. Oracle Entity 를 넣으면 어떻게 되나
**판정** · SUPPORTED

0.525 → 0.525. 변화 없음. 이것이 이번 진단의 핵심이다.

근거 · 같은 문서

### 31. Top-k 에서는 어떻게 되나
**판정** · PARTIAL

K2 가 0.575 로 가장 낫지만 p=0.688 이라 유의하지 않다.
K3 는 입구 정답률이 80% 인데 오히려 0.475 로 떨어진다.
입구를 더 맞힌다고 성적이 오르지 않는다는 증거가 하나 더 붙는다.

근거 · E4-K2 / E4-K3

### 32. Vector→Graph Hybrid 는
**판정** · SUPPORTED

0.525 로 baseline 과 같다. 연결은 25% → 45% 로 나아졌는데 성능은 그대로다.

근거 · E5

### 33. GraphRAG 가 실제로 필요한가
**판정** · CANNOT CLAIM

`GRAPHRAG NECESSITY = NOT ESTABLISHED`.
다만 여기서 진 것은 어휘 4마디짜리 얕은 그래프다. 개념 전체의 실패로 일반화하지 않는다.

근거 · 같은 문서

### 34. Vector RAG 와 차이가 있나
**판정** · PARTIAL

E3 0.575 vs E4 0.525 로 벡터가 앞서지만 Holm p=0.875 라 못 가른다.

근거 · `INSTRUCTOR_FINAL_EVIDENCE/06_ABLATION/`

### 35. KG 없이도 똑같으면 왜 쓰나
**판정** · CANNOT CLAIM

지금 증거로는 쓸 이유를 대지 못한다. 쓰려면 **정의로는 못 담는 것**
(사례 간 관계 · 다중 홉 경로 · 근거 추적)을 꺼내 오도록 다시 설계하고 다시 재야 한다.

근거 · 없음

---

## F 제품 · 범위

### 36. 개인화라고 부를 근거가 있나
**판정** · CANNOT CLAIM

없다. 실제 사용자 사건을 하나도 받지 않았다. 설계만 있다.

근거 · 없음

### 37. 실사용자 데이터가 없는데 Personal Social Event 가 의미 있나
**판정** · PARTIAL

구조가 공개 대화에서 실제로 채워지는 것은 Level 3 가 보인다.
다만 그것은 일반인 상담 대화이지 **SCD 아동 대화가 아니다.**

근거 · `06_Q2_LEVEL3/`

### 38. 사용자가 좋아진다는 것은 어떻게 검증할 계획인가
**판정** · PARTIAL

SCD 아동 참여자 모집 · IRB · 사전사후 · near/far transfer 측정이 필요하다.
이번 범위 밖이고 설계도 아직 없다.

근거 · 없음

### 39. 격률 판정은 왜 안 되나
**판정** · SUPPORTED

E0 가 0.250 으로 우연과 정확히 같고 가장 나은 갈래도 0.375 다.
이 모델로는 안 된다고 적는다. "검증 가능한 필드" 인 것과 "실제로 해낸다" 는 다르다.

근거 · `INSTRUCTOR_FINAL_EVIDENCE/06_ABLATION/results.csv`

### 40. 왜 로컬 모델을 썼나
**판정** · SUPPORTED

시험 자료가 권리 유보(라이선스 파일 없음)라 외부 API 로 보낼 수 없다.
`exaone3.5:7.8b` 와 `bge-m3` 은 이 컴퓨터를 떠나지 않는다.

근거 · `02_DATA/TECHNICAL_BENCHMARK_STATUS.md`

### 41. v0.2 최소 검증 첫 실행을 왜 버렸나
**판정** · SUPPORTED

턴 세는 검사기가 **따옴표가 있는 줄**을 세도록 짜여 있었다.
v0.1 프롬프트에서는 모델이 따옴표를 붙여서 우연히 맞았고,
v0.2 프롬프트로 바꾸자 모델이 따옴표를 버려 모든 장면이 0턴으로 걸렸다.

검사기가 스펙이 아니라 **모델의 우연한 서식 습관**에 묶여 있었다.
화자 라벨 기준으로 고치고 손으로 쓴 픽스처 10개로 시험한 뒤 9장면을 처음부터 다시 돌렸다.
프롬프트 · 모델 · seed · 온도 · 재시도 한도는 그대로다.

근거 · `05_Q2_LEVEL2/v0_2_validation/CHECKER_BUG_NOTE.md`

### 42. 제도적 점프는 v0.1 의 FAR 규칙 탓이라 했는데 맞나
**판정** · PARTIAL

절반만 맞다. v0.2 실행에서 제도적 점프가 **NEAR 에서도 걸렸다.**

```
SAME_CONTEXT  0회
NEAR          2회
FAR           0회
```

NEAR 규칙은 "관계 **또는** 자리 중 하나만" 이라 점프를 요구하지 않는다.
그런데도 모델은 맥락을 바꾸라는 말을 들으면 **직장 프레임으로 가는 것을 기본값으로** 삼는다.

v0.1 진단은 "FAR 규칙이 시킨 것" 이었다. 그것도 사실이지만 범위가 더 넓다.
규칙을 고쳐도 생성기의 기본 이동은 남는다.

근거 · `05_Q2_LEVEL2/v0_2_validation/v02_generated.jsonl`

### 43. v0.2 자동 통과가 8/9 면 고쳐진 것 아닌가
**판정** · CANNOT CLAIM · **이 숫자를 성과로 쓰지 않는다**

실행 때 쓴 검사가 자기가 집행한다는 규칙보다 약했다.
`INSTITUTIONAL` 정규식이 팀장 · 마감 · 결재 같은 **어휘 표지만** 본다.
동료 · 회사 · 직장 · 업무 · 공식적 은 목록에 없었다.

생성이 끝난 뒤 넓힌 낱말로 다시 세어 보면

```
직장 프레임 낱말이 들어간 장면   6 / 9
그중 실행 검사가 놓친 것          5
놓친 등급                        FAR, NEAR, SAME_CONTEXT
```

SAME_CONTEXT 두 장면이 친구·사적에서 **동료·회사 근처 카페**로 갔는데 통과했다.
SAME_CONTEXT 는 화제 · 장소 · 등장인물만 바꾸는 등급이다. 관계가 바뀌면 안 된다.

재시도도 뜻대로 작동하지 않는다. 다시 쓴 글은 문자 일치율 평균 0.55 (표본 1) 로 달라지지만
**프레임은 그대로다.** 두 번 다 마감이 걸린 직장 장면을 냈다.
표현을 바꾸지 프레임을 바꾸지 않는다.

등급별 자동 통과 · SAME_CONTEXT 3/3 · NEAR 2/3 · FAR 3/3

**8/9 는 어휘 표지 검사를 통과했다는 뜻이지 규칙을 지켰다는 뜻이 아니다.**
검사를 강화해 다시 돌리지 않았다. 프로토콜을 중간에 바꾸지 않기로 했기 때문이고,
사후 감사는 실행 때 판정을 고쳐 쓰지 않고 따로 적었다.

근거 · `05_Q2_LEVEL2/v0_2_validation/POSTHOC_AUDIT.txt`

### 44. 제도적 점프를 막으면 FAR 가 충분히 멀지 않게 되는 것 아닌가
**판정** · CANNOT CLAIM · **열린 위험이다**

그럴 수 있다. v0.2 의 FAR 은 친구 → 친척처럼 사적인 자리 안에서 움직인다.
표면 거리가 줄어든 대신 불변식이 살아남는 거래다.

거리는 자동 검사로 재지 않는다. 검사기는 규칙 위반만 본다.
**충분히 먼가는 사람이 판정해야 하고 아직 안 했다.**

v0.1 은 "멀지만 다른 과제" 를 만들었다. v0.2 가 "같은 과제지만 가까운 것" 을 만든다면
문제를 반대편으로 옮긴 것뿐이다. 다음 검토에서 이것부터 본다.

근거 · `03_ONTOLOGY/TRANSFER_RULE_v0_2.md` · 사람 판정 전

### 45. 생성된 장면에 규격 용어가 섞이지 않았나
**판정** · PARTIAL

한 곳 샜다. `V2-S2` 앵커 본문이 `CLUB_SENIOR의 멤버인 나` 로 시작한다.
프롬프트에 관계 유형을 enum 값 그대로 넣었고 모델이 받아 적었다.

금지 낱말 목록에는 필드 **이름**(`relationship_type`)만 있고 **값**(`CLUB_SENIOR`)이 없었다.
다음 판에서는 값도 막고, 프롬프트에 enum 대신 우리말 설명을 넣는다.

사후 감사에서도 처음에는 0건으로 나왔다. 정규식 뒤에 붙인 `\b` 때문이다.
한글도 `\w` 라서 `CLUB_SENIOR의` 에는 경계가 생기지 않는다.
경계를 ASCII 기준 전후방탐색으로 바꿔 다시 세었다.

근거 · `05_Q2_LEVEL2/v0_2_validation/POSTHOC_AUDIT.txt`
