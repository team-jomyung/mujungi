# -*- coding: utf-8 -*-
"""Level 3 · 공개된 진짜 대화에서 훈련 상황까지 한 줄로 이어 본다.

    python run_l3.py --n 5

흐름
  1 raw dialogue          공개 자료 그대로
  2 cue extraction        규칙으로 언어·담화 단서
  3 interpretation        모델이 해석 (gold 없음 · DEMONSTRATION ONLY)
  4 Social Event          L2 구조
  5 Pragmatic Structure   모델이 Core 다섯 칸을 제안
  6 SAME_CONTEXT          자동 생성
  7 NEAR                  자동 생성
  8 FAR                   자동 생성

  **여덟 단계의 중간 결과를 전부 남긴다.** 하나라도 지우면 어디서 끊겼는지 모른다.

왜 KMI 인가
  발표에 원문을 실을 수 있는 **유일한** 한국어 다중턴 대화다 (CC BY 4.0).
  나머지 한국어 자료는 라이선스가 없어 예시를 못 싣는다.

  다만 KMI 는 상담 대화이고 GPT-4 가 생성한 것이다.
  **"SCD 실제 대화" 라고 부르지 않는다.** 일반인 공개 대화다.

gold 가 없는 칸
  3 해석 · 5 Pragmatic Structure · 6~8 생성 장면 — 전부 gold 가 없다.
  **정확도를 말하지 않는다.** DEMONSTRATION ONLY 로 표시한다.
"""
from __future__ import annotations

import argparse
import io
import json
import os
import re
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, '..', '..', '..'))
sys.path.insert(0, os.path.join(ROOT, 'INSTRUCTOR_FINAL_EVIDENCE', '05_BENCHMARK', 'harness'))
sys.path.insert(0, os.path.join(ROOT, 'FINAL_TOMORROW_PACKAGE', '05_Q2_LEVEL2',
                                'automatic_generation'))
import data as D  # noqa: E402
import generate_l2 as G2  # noqa: E402
import llm as L  # noqa: E402

OUT = HERE
ATTRIB = ('Kim, Hyunjong et al. "KMI: A Dataset of Korean Motivational Interviewing '
          'Dialogues for Psychotherapy." NAACL 2025. CC BY 4.0.')

CUE_RULES = [
    ('주저 표지', re.compile(r'(음\.\.\.|어\.\.\.|그\.\.\.|글쎄|뭐랄까|아무래도)')),
    ('완화 표현', re.compile(r'(좀|조금|약간|살짝|것 같|듯|아마|혹시)')),
    ('강화 표현', re.compile(r'(정말|진짜|너무|엄청|매우|항상|절대|전혀)')),
    ('자기수정', re.compile(r'(아니|그게 아니라|말고)')),
]


def cues(text):
    out = []
    for name, rx in CUE_RULES:
        m = rx.search(text)
        if m:
            out.append({'cue': name, 'evidence': m.group(0)[:14]})
    return out


def render(turns):
    return chr(10).join(
        '%s "%s"' % ('내담자' if t['role'] == 'Client' else '상담자', t['utterance_ko'])
        for t in turns)


def ask(prompt, n=220):
    try:
        r = L.generate(prompt, max_tokens=n, stop=['\n\n\n'])
        return (r['text'] or '').strip(), r['seconds']
    except L.LLMError as e:
        return '', 0.0


def step_interpretation(scene):
    p = ('다음은 상담 대화의 한 대목이다.%s%s%s%s'
         '내담자가 한 말들이 이 자리에서 **무엇을 하려는 말인지** 두 문장으로 쓰시오.%s'
         '속마음을 단정하지 말고, 오간 말에서 보이는 것만 쓰시오.%s답:'
         % (chr(10), chr(10), scene, chr(10) * 2, chr(10), chr(10)))
    return ask(p, 160)


def step_signature(scene, interp):
    p = ('다음 대화와 해석을 읽고, 이 상황을 잘 다루려면 무엇이 필요한지 네 줄로 쓰시오.%s%s'
         '%s%s해석 · %s%s%s'
         '형식 (각 줄 한 문장, 설명 없이)%s'
         '필요한 짐작:%s'
         '따라가야 할 관점:%s'
         '오간 말만으로 판정이 서는가(예/아니오):%s'
         '대놓고 물어봐도 되는 자리인가(예/아니오):%s답:'
         % (chr(10), chr(10), scene, chr(10) * 2, interp, chr(10) * 2, chr(10),
            chr(10), chr(10), chr(10), chr(10), chr(10)))
    return ask(p, 200)


def parse_sig(text):
    out = {}
    for key, label in (('required_inference', '필요한 짐작'),
                       ('perspective_structure', '따라가야 할 관점'),
                       ('decidable_by_evidence', '오간 말만으로'),
                       ('direct_check_allowed', '대놓고')):
        m = re.search(re.escape(label) + r'[^:：]*[:：]\s*(.+)', text)
        out[key] = m.group(1).strip()[:80] if m else ''
    return out


def step_variant(scene, sig, grade, prev):
    a = {'core': {'required_inference': sig.get('required_inference') or '상대의 뜻 짐작하기'}}
    return G2.produce(G2.variant_prompt(a, scene, grade), prev, grade, None, {})


def main(argv):
    ap = argparse.ArgumentParser()
    ap.add_argument('--n', type=int, default=5)
    ap.add_argument('--turns', type=int, default=6)
    a_ = ap.parse_args(argv)
    if not L.alive():
        print('ollama 가 없다')
        return 2
    dl = D.load_kmi()
    if not dl:
        print('KMI 가 없다')
        return 2

    # 주제를 골고루 · 결정적으로 고른다
    by = {}
    for d in dl:
        by.setdefault(d['category_ko'], []).append(d)
    picked = []
    i = 0
    while len(picked) < a_.n and i < 50:
        for cat in sorted(by):
            if i < len(by[cat]) and len(picked) < a_.n:
                picked.append(by[cat][i])
        i += 1

    print('Level 3 · 공개 대화 %d개를 끝까지 이어 본다' % len(picked))
    print('  출처 · KMI (CC BY 4.0)')
    print()
    t0 = time.time()
    cases = []
    for d in picked:
        turns = d['dialogue'][:a_.turns]
        scene = render(turns)
        cue = [{'turn': i + 1, 'role': t['role'], **c}
               for i, t in enumerate(turns) for c in cues(t['utterance_ko'])]
        interp, s1 = step_interpretation(scene)
        sig_raw, s2 = step_signature(scene, interp)
        sig = parse_sig(sig_raw)

        variants, prev = {}, [scene]
        for grade in ('SAME_CONTEXT', 'NEAR', 'FAR'):
            txt, att, note = step_variant(scene, sig, grade, prev)
            prev.append(txt)
            variants[grade] = {'scene': txt, 'attempts': len(att), 'unresolved': note,
                               'all_attempts': att}

        case = {
            'case_id': 'L3-KMI-%04d' % d['id'],
            'source': {'dataset': 'KMI', 'dialogue_id': d['id'],
                       'category': d['category_ko'], 'license': 'CC BY 4.0',
                       'attribution': ATTRIB},
            'step1_raw_dialogue': scene,
            'step2_cues': cue,
            'step3_interpretation': {'text': interp, 'status': 'DEMONSTRATION_ONLY',
                                     'why': 'gold 가 없다. 정확도를 말하지 않는다'},
            'step4_social_event': {
                'context': {'situation_type': 'COUNSELING',
                            'relationship_type': 'COUNSELOR_CLIENT',
                            'topic': d['category_ko'], 'status': 'GOLD_VALIDATED',
                            'why': '자료가 직접 준다'},
                'participants': [{'id': 'P1', 'role': 'client'},
                                 {'id': 'P2', 'role': 'counselor'}],
                'n_turns': len(turns),
            },
            'step5_pragmatic_structure': {'parsed': sig, 'raw': sig_raw,
                                          'status': 'DEMONSTRATION_ONLY'},
            'step6_same_context': variants['SAME_CONTEXT'],
            'step7_near': variants['NEAR'],
            'step8_far': variants['FAR'],
            'NOT_A_SCD_DIALOGUE': ('일반인 공개 상담 대화다. SCD 실제 대화가 아니다'),
            'model': L.GEN_MODEL, 'seed': L.SEED,
        }
        cases.append(case)
        io.open(os.path.join(OUT, case['case_id'] + '.json'), 'w',
                encoding='utf-8', newline=chr(10)).write(
            json.dumps(case, ensure_ascii=False, indent=2) + chr(10))
        ok = sum(1 for g in ('step6_same_context', 'step7_near', 'step8_far')
                 if case[g]['scene'] and not case[g]['unresolved'])
        print('  %-14s %s · 단서 %d · 변형 %d/3 성공'
              % (case['case_id'], d['category_ko'], len(cue), ok))

    io.open(os.path.join(OUT, '_all_cases.json'), 'w', encoding='utf-8',
            newline=chr(10)).write(json.dumps(cases, ensure_ascii=False, indent=2) + chr(10))
    done = sum(1 for c in cases
               if all(c[g]['scene'] for g in ('step6_same_context', 'step7_near', 'step8_far')))
    print()
    print('사례 %d · 여덟 단계 끝까지 간 것 %d · %.1f분'
          % (len(cases), done, (time.time() - t0) / 60))
    print('  gold 없는 칸 · 3 해석 · 5 구조 · 6~8 생성 → 전부 DEMONSTRATION ONLY')
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
