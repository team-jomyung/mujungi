# -*- coding: utf-8 -*-
"""한 화면에서 전체 흐름을 보는 데모. raw → 구조 → 생성.

    python build_demo.py
"""
from __future__ import annotations

import io
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, 'end_to_end', '_all_cases.json')
OUT = os.path.join(HERE, 'Q2_END_TO_END_DEMO.html')


def esc(t):
    return (str(t).replace('&', '&amp;').replace('<', '&lt;')
            .replace('>', '&gt;').replace('"', '&quot;'))


def scene(t):
    return ''.join('<p>%s</p>' % esc(ln.strip())
                   for ln in (t or '').split(chr(10)) if ln.strip())


def case_html(c, i):
    s5 = c['step5_pragmatic_structure']['parsed']
    cues = c['step2_cues'][:6]
    return ('<article class="c"><header><span class="id">%s</span>'
            '<span class="cat">%s</span></header>'
            '<div class="flow">'
            '<div class="s"><h4>1 · 공개 대화 그대로</h4><div class="sc gold">%s</div>'
            '<p class="tag ok">GOLD · 자료가 준다</p></div>'
            '<div class="s"><h4>2 · 단서 (규칙)</h4><ul class="cue">%s</ul>'
            '<p class="tag dem">DEMONSTRATION</p></div>'
            '<div class="s"><h4>3 · 해석 (모델)</h4><div class="sc">%s</div>'
            '<p class="tag dem">DEMONSTRATION · gold 없음</p></div>'
            '<div class="s"><h4>5 · 핵심 화용 구조</h4><dl>%s</dl>'
            '<p class="tag dem">DEMONSTRATION</p></div>'
            '</div>'
            '<h4 class="gen">6~8 · 같은 핵심을 요구하는 새 상황 (모델이 자동 생성)</h4>'
            '<div class="vars">%s</div>'
            '<p class="note">%s</p></article>'
            % (esc(c['case_id']), esc(c['source']['category']),
               scene(c['step1_raw_dialogue']),
               ''.join('<li><b>%s</b> %s</li>' % (esc(x['cue']), esc(x['evidence']))
                       for x in cues) or '<li>없음</li>',
               scene(c['step3_interpretation']['text']) or '<p>-</p>',
               ''.join('<dt>%s</dt><dd>%s</dd>' % (esc(k), esc(v or '-'))
                       for k, v in s5.items()),
               ''.join('<div class="v"><span>%s</span>%s</div>'
                       % (g, scene(c[k]['scene']) or '<p>생성 실패</p>')
                       for g, k in (('SAME_CONTEXT', 'step6_same_context'),
                                    ('NEAR', 'step7_near'), ('FAR', 'step8_far'))),
               esc(c['NOT_A_SCD_DIALOGUE'])))


TPL = '''<!doctype html>
<html lang="ko"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>공개 대화에서 훈련 상황까지</title>
<style>
:root{{--pg:#fbfaf7;--pg2:#f2f0e9;--ink:#1e1c18;--ink2:#575046;--ink3:#8a8276;
--rule:#dcd6c8;--acc:#7b4a2c;--ok:#2f6b47;--dem:#8a6216;
--s:system-ui,"Segoe UI","Malgun Gothic",sans-serif;
--f:"Iowan Old Style","Palatino Linotype",Batang,serif;}}
@media(prefers-color-scheme:dark){{:root:not([data-theme=light]){{
--pg:#16150f;--pg2:#1e1c16;--ink:#ebe6da;--ink2:#b0a996;--ink3:#867e70;
--rule:#332f26;--acc:#d9946a;--ok:#79b592;--dem:#d3a65c;}}}}
:root[data-theme=dark]{{--pg:#16150f;--pg2:#1e1c16;--ink:#ebe6da;--ink2:#b0a996;
--ink3:#867e70;--rule:#332f26;--acc:#d9946a;--ok:#79b592;--dem:#d3a65c;}}
*{{box-sizing:border-box}}html,body{{overflow-x:clip}}
body{{margin:0;background:var(--pg);color:var(--ink);font-family:var(--s);font-size:14px;line-height:1.6}}
.w{{max-width:72rem;margin:0 auto;padding:0 1.2rem 4rem}}
header.top{{padding:2.6rem 0 1.4rem;border-bottom:2px solid var(--ink)}}
.k{{font-size:.64rem;letter-spacing:.17em;text-transform:uppercase;color:var(--acc);font-weight:700;margin:0 0 .5rem}}
h1{{font-family:var(--f);font-weight:600;font-style:normal;font-size:clamp(1.4rem,3.6vw,2rem);
margin:0 0 .6rem;line-height:1.2;overflow-wrap:anywhere;min-width:0}}
.lede{{color:var(--ink2);margin:0 0 .8rem;max-width:44rem}}
.warn{{font-size:.84rem;color:var(--ink2);border-left:3px solid var(--acc);
padding:.5rem 0 .5rem .9rem;background:var(--pg2);margin:0}}
.c{{padding:1.8rem 0;border-bottom:1px solid var(--rule)}}
.c>header{{display:flex;gap:.8rem;align-items:baseline;margin-bottom:1rem}}
.id{{font-family:var(--f);font-size:1rem}}
.cat{{font-size:.72rem;color:var(--ink3)}}
.flow{{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,15rem),1fr));
gap:1px;background:var(--rule);border:1px solid var(--rule)}}
.s{{background:var(--pg);padding:.8rem .9rem}}
.s h4{{font-size:.68rem;letter-spacing:.09em;text-transform:uppercase;color:var(--acc);
margin:0 0 .5rem;font-weight:700}}
.sc p{{margin:0 0 .28rem;font-size:.82rem}}
.sc.gold p{{font-size:.8rem}}
.cue{{margin:0;padding-left:1rem;font-size:.78rem}}
.cue b{{color:var(--acc)}}
dl{{margin:0;font-size:.78rem}}
dt{{font-weight:650;color:var(--ink3);font-size:.68rem;margin-top:.35rem}}
dd{{margin:0}}
.tag{{margin:.6rem 0 0;font-size:.62rem;letter-spacing:.08em;text-transform:uppercase}}
.tag.ok{{color:var(--ok)}}.tag.dem{{color:var(--dem)}}
.gen{{font-size:.68rem;letter-spacing:.09em;text-transform:uppercase;color:var(--acc);
margin:1.2rem 0 .5rem;font-weight:700}}
.vars{{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,17rem),1fr));
gap:1px;background:var(--rule);border:1px solid var(--rule)}}
.v{{background:var(--pg2);padding:.8rem .9rem}}
.v span{{display:block;font-size:.62rem;letter-spacing:.1em;color:var(--acc);
font-weight:700;margin-bottom:.4rem}}
.v p{{margin:0 0 .28rem;font-size:.81rem}}
.note{{font-size:.74rem;color:var(--ink3);margin:.7rem 0 0}}
footer{{padding:2rem 0 0;font-size:.76rem;color:var(--ink3)}}
</style></head><body><div class="w">
<header class="top">
<p class="k">Q2 · Level 3 · End-to-End</p>
<h1>공개된 진짜 대화에서 훈련 상황까지</h1>
<p class="lede">사람이 문장에 손대지 않았다. 여덟 단계를 모델이 이어서 돌린다.</p>
<p class="warn">일반인 상담 대화다. <b>SCD 실제 대화가 아니다.</b>
gold 가 없는 칸(해석 · 화용 구조 · 생성 장면)은 전부 DEMONSTRATION ONLY 이고
정확도를 말하지 않는다.</p>
</header>
{body}
<footer>
<p>출처 · Kim, Hyunjong et al. "KMI: A Dataset of Korean Motivational Interviewing
Dialogues for Psychotherapy." NAACL 2025. CC BY 4.0.</p>
<p>모델 {model} · temperature 0 · seed {seed} · 이 컴퓨터를 떠나지 않는다.</p>
</footer>
</div></body></html>
'''


def main():
    if not os.path.exists(SRC):
        print('사례가 없다 · end_to_end/run_l3.py 를 먼저 돌린다')
        return 2
    cases = json.load(io.open(SRC, encoding='utf-8'))
    body = chr(10).join(case_html(c, i) for i, c in enumerate(cases))
    io.open(OUT, 'w', encoding='utf-8', newline=chr(10)).write(
        TPL.format(body=body, model=esc(cases[0].get('model', '')),
                   seed=esc(cases[0].get('seed', ''))))
    ok = sum(1 for c in cases if all(c[k]['scene'] for k in
                                     ('step6_same_context', 'step7_near', 'step8_far')))
    print('데모 · %s (%s bytes) · 사례 %d · 끝까지 간 것 %d'
          % (os.path.basename(OUT), format(os.path.getsize(OUT), ','), len(cases), ok))
    return 0


if __name__ == '__main__':
    sys.exit(main())
