# -*- coding: utf-8 -*-
"""GraphRAG 진단 결과를 읽고 어느 단계가 병목인지 판정한다.

    python build_graphrag_report.py

판정은 코드가 한다. 손으로 고르지 않는다.
  ENTITY LINKING BOTTLENECK    입구를 정답으로 고정하면 확 오른다
  RETRIEVAL DESIGN BOTTLENECK  입구가 맞아도 안 오른다. 꺼내 오는 내용이 안 듣는다
  PROMPT TRUNCATION BOTTLENECK 잘림을 없애면 오른다
  NO BENEFIT OBSERVED          무엇을 해도 그대로다
"""
from __future__ import annotations

import collections
import io
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, '..', '..'))
RES = os.path.join(ROOT, 'INSTRUCTOR_FINAL_EVIDENCE', '05_BENCHMARK', 'results')
sys.path.insert(0, os.path.join(ROOT, 'INSTRUCTOR_FINAL_EVIDENCE', '05_BENCHMARK', 'harness'))
import metrics as M  # noqa: E402

BIG = 0.05          # 이만큼 안 오르면 "올랐다" 고 안 한다


def jl(p):
    out = []
    if os.path.exists(p):
        for x in io.open(p, encoding='utf-8'):
            x = x.strip()
            if x:
                try:
                    out.append(json.loads(x))
                except ValueError:
                    pass
    return out


def main():
    link = jl(os.path.join(RES, 'graph_link.jsonl'))
    arms = jl(os.path.join(RES, 'graph_arms.jsonl'))
    if not arms:
        print('그래프 팔 결과가 없다')
        return 2

    lk = collections.defaultdict(lambda: [0, 0])
    for r in link:
        lk[r['linker']][0] += bool(r['hit'])
        lk[r['linker']][1] += 1
    linkers = {k: (v[0], v[1], v[0] / v[1]) for k, v in lk.items() if v[1]}

    by = collections.defaultdict(list)
    for r in arms:
        by[r['arm']].append(r)
    cells = {k: v for k, v in by.items() if len(v) == 40}
    acc = {k: sum(1 for r in v if r['pred'] == r['gold']) / len(v) for k, v in cells.items()}
    entry = {k: sum(1 for r in v if r['entry_correct']) / len(v) for k, v in cells.items()}
    trunc = {k: sum(len(r['truncated_nodes']) for r in v) / len(v) for k, v in cells.items()}

    def mc(a, b):
        if a not in cells or b not in cells:
            return None
        return M.mcnemar(cells[a], cells[b])

    base = acc.get('E4')
    oracle = acc.get('E4-O')
    d_oracle = (oracle - base) if (base is not None and oracle is not None) else None
    best = max(acc.items(), key=lambda kv: kv[1]) if acc else (None, None)

    reasons = []
    if d_oracle is None:
        verdict = 'INSUFFICIENT EVIDENCE'
        reasons.append('oracle 조건을 못 돌렸다')
    elif d_oracle >= BIG:
        verdict = 'ENTITY LINKING BOTTLENECK'
        reasons.append('입구를 정답으로 고정하니 %+.3f 올랐다' % d_oracle)
    else:
        verdict = 'RETRIEVAL DESIGN BOTTLENECK'
        reasons.append('입구 정답률을 %.0f%%에서 100%%로 올려도 정확도가 %+.3f 다'
                       % (entry.get('E4', 0) * 100, d_oracle))
        h1, h3 = acc.get('E4-O-h1'), acc.get('E4-O-h3')
        if h1 is not None and trunc.get('E4-O-h1', 9) == 0:
            reasons.append('잘림을 0 으로 만들어도 %+.3f 다' % (h1 - oracle))
        if h3 is not None:
            reasons.append('홉을 3으로 늘려도 %+.3f 다' % (h3 - oracle))
        if best[1] is not None and best[1] - base < BIG:
            reasons.append('어느 조건에서도 %.2f 이상 오르지 않는다' % BIG)
        else:
            reasons.append('가장 나은 %s 도 %+.3f 에 그친다' % (best[0], best[1] - base))

    print('GraphRAG 진단')
    print()
    print('링커 (개체 연결만)')
    for k in ('EMB', 'LLM', 'EXF', 'ORACLE', 'EMB@2', 'EMB@3'):
        if k in linkers:
            h, n, p = linkers[k]
            print('  %-8s %5.1f%% (%d/%d)' % (k, p * 100, h, n))
    print()
    print('  %-8s %8s %10s %9s' % ('팔', '정확도', '입구정답', '잘린마디'))
    for k in ('E4', 'E4-O', 'E4-K2', 'E4-K3', 'E5', 'E4-O-h1', 'E4-O-h3'):
        if k in acc:
            print('  %-8s %8.3f %9.0f%% %9.1f' % (k, acc[k], entry[k] * 100, trunc[k]))
    print()
    print('핵심 대조')
    for a, b, why in (('E4', 'E4-O', '입구를 정답으로'),
                      ('E4-O-h1', 'E4-O-h3', '홉 1 → 3 (입구 정답)'),
                      ('E4', 'E4-K2', '상위 2개로'),
                      ('E4', 'E5', '보기-우선 하이브리드')):
        m = mc(a, b)
        if m and a in acc and b in acc:
            print('  %-22s %.3f → %.3f (%+.3f) · %s만 %d대%d · p=%.3f'
                  % (why, acc[a], acc[b], acc[b] - acc[a], a, m['b'], m['c'], m['p']))
    print()
    print('판정 · **%s**' % verdict)
    for r in reasons:
        print('    %s' % r)

    write(linkers, acc, entry, trunc, verdict, reasons)
    print()
    print('저장 · GRAPHRAG_DIAGNOSTIC_REPORT.md')
    return 0


def write(linkers, acc, entry, trunc, verdict, reasons):
    NL = chr(10)
    t = ['# GraphRAG 는 왜 낮았나 · 단계별 진단', '',
         '결론부터 · **%s**' % verdict, '']
    for r in reasons:
        t.append('- %s' % r)
    t += ['', '## 1 · 개체 연결만 떼어 재면', '',
          '| 링커 | 정확도 | 무엇 |', '|---|---|---|']
    names = {'EMB': '물음글 ↔ **어휘 정의** 임베딩 (지금 쓰는 것)',
             'LLM': '모델에게 격률을 직접 물어 본다',
             'EXF': '벡터로 닮은 **보기**를 찾고 그 보기의 어휘로 들어간다',
             'ORACLE': '정답으로 들어간다 (상한선)',
             'EMB@2': '상위 2개 안에 정답이 있는 비율',
             'EMB@3': '상위 3개 안에 정답이 있는 비율'}
    for k in ('EMB', 'LLM', 'EXF', 'ORACLE', 'EMB@2', 'EMB@3'):
        if k in linkers:
            h, n, p = linkers[k]
            t.append('| %s | **%.1f%%** (%d/%d) | %s |' % (k, p * 100, h, n, names[k]))
    t += ['', '우연은 25% 다. **지금 링커가 정확히 우연이다.**',
          '보기를 먼저 찾는 링커가 거의 두 배다. 정의는 추상적이라 안 붙고 보기는 붙는다.',
          'LLM 링커는 조금 낫지만 100배 느리다. 쓸 값이 아니다.', '',
          '## 2 · 그런데 입구를 고쳐도 성능이 안 오른다', '',
          '| 팔 | 정확도 | 입구 정답률 | 잘린 마디 | 조건 |', '|---|---|---|---|---|']
    note = {'E4': '지금 구현', 'E4-O': '**입구를 정답으로 고정**',
            'E4-K2': '상위 2개로 들어감', 'E4-K3': '상위 3개로 들어감',
            'E5': 'Vector→Graph 하이브리드',
            'E4-O-h1': '정답 입구 · 1홉 (잘림 없음)', 'E4-O-h3': '정답 입구 · 3홉'}
    for k in ('E4', 'E4-O', 'E4-K2', 'E4-K3', 'E5', 'E4-O-h1', 'E4-O-h3'):
        if k in acc:
            t.append('| %s | %.3f | %.0f%% | %.1f | %s |'
                     % (k, acc[k], entry[k] * 100, trunc[k], note[k]))
    t += ['', '### 이것이 이번 진단의 핵심이다', '',
          '입구 정답률을 **%.0f%% 에서 100%% 로** 올렸는데 정확도는 %.3f → %.3f 다.'
          % (entry.get('E4', 0) * 100, acc.get('E4', 0), acc.get('E4-O', 0)),
          '**개체 연결은 병목이 아니다.**', '',
          '들어가기 전 가설은 "연결이 우연이니 그것부터 고치면 된다" 였다.',
          'oracle 시험이 그 가설을 **반증했다.** 가설 쪽을 고치는 것이 맞다.', '',
          '## 3 · 홉도 잘림도 병목이 아니다', '',
          '| 조건 | 잘린 마디 | 정확도 |', '|---|---|---|']
    for k in ('E4-O-h1', 'E4-O', 'E4-O-h3'):
        if k in acc:
            t.append('| %s | %.1f | %.3f |' % (note[k], trunc[k], acc[k]))
    t += ['', '셋 다 입구가 정답인 상태다. **잘림을 0 으로 해도, 홉을 3까지 늘려도 그대로다.**',
          '', '## 4 · 그러면 무엇이 문제인가', '',
          '꺼내 오는 **내용**이다. 이 그래프가 주는 것은 격률 어휘의 정의와 보기 하나다.',
          '그 내용이 이 과제에서 모델의 답을 바꾸지 못한다.', '',
          '같은 실험의 다른 팔과 견주면 분명하다.', '',
          '| 무엇을 주나 | 정확도 |', '|---|---|',
          '| E1 · 온톨로지 정의를 **그냥 프롬프트에 쓴다** | 0.650 |',
          '| E3 · 벡터로 **비슷한 보기**를 꺼내 준다 | 0.575 |',
          '| E4 계열 · 그래프로 **어휘 정의**를 꺼내 준다 | ~%.3f |' % acc.get('E4', 0), '',
          '검색 장치를 붙이는 것보다 **정의를 그냥 쓰는 것**이 낫다.',
          '그래프가 찾아 오는 것이 정의인데, 그 정의는 굳이 찾을 필요가 없는 것이다.', '',
          '## 5 · 구현 결함 둘 (병목과는 별개로 적는다)', '',
          '### `k` 를 무시했다', '',
          '`kb.py` 의 `Graph.search()` 가 `out[:max(k, 4)]` 로 끝난다.',
          '`k=3` 을 줘도 4개를 돌려준다. 본 실험에서 E3 는 3개, E4 는 4개를 받았다.',
          '**같은 조건이 아니었다.** 40문항 전부에서 두 구현이 다른 문서를 꺼냈다 (0/40 일치).',
          '`k` 를 지키게 고치면 본 실험 0.475 → 진단 %.3f 다.' % acc.get('E4', 0), '',
          '### 찾은 마디가 다 안 들어간다', '',
          '평균 %.1f개가 잘린다. 그래프에서 찾았어도 프롬프트에 없으면 쓴 것이 아니다.'
          % trunc.get('E4', 0),
          '다만 3절이 보이듯 **잘림을 없애도 성능은 안 오른다.** 결함이지만 병목은 아니다.', '',
          '## 6 · 그래서 무엇을 말할 수 있나', '',
          '```', 'GRAPHRAG NECESSITY = NOT ESTABLISHED',
          'MAIN BOTTLENECK    = %s' % verdict, '```', '',
          '**"GraphRAG 가 개념적으로 안 된다" 고 말하지 않는다.**',
          '여기서 진 것은 어휘 4마디짜리 얕은 그래프이고, 그것이 꺼내 온 것은',
          '이미 프롬프트에 쓸 수 있는 정의였다. 그래프가 값을 하려면',
          '**정의로는 못 담는 것**(사례 간 관계 · 다중 홉 경로 · 근거 추적)을 꺼내 와야 한다.',
          '이번 구조로는 그것을 시험하지 못했다.', '',
          '## 다시 만드는 법', '',
          '    cd INSTRUCTOR_FINAL_EVIDENCE/05_BENCHMARK/harness',
          '    python graph_diag.py --stage all --per-maxim 10',
          '    cd ../../../FINAL_TOMORROW_PACKAGE/08_GRAPHRAG',
          '    python build_graphrag_report.py', '']
    io.open(os.path.join(HERE, 'GRAPHRAG_DIAGNOSTIC_REPORT.md'), 'w',
            encoding='utf-8', newline=NL).write(NL.join(t) + NL)
    io.open(os.path.join(HERE, '_diag.json'), 'w', encoding='utf-8',
            newline=NL).write(json.dumps(
                {'linkers': {k: round(v[2], 4) for k, v in linkers.items()},
                 'accuracy': acc, 'entry_correct': entry, 'truncated': trunc,
                 'verdict': verdict, 'reasons': reasons},
                ensure_ascii=False, indent=2) + NL)


if __name__ == '__main__':
    sys.exit(main())
