# 실패 원인 분석

Skill=SAME 이 아닌 항목과 누출 · 맥락 부족 항목을 전부 코딩했다.
사용자 가설을 그대로 받지 않고 **실제 장면과 Core 필드를 대조해** 붙였다.

## 원인별 빈도

| 원인 | 건수 |
|---|---|
| `stakes` | 3 |
| `interaction_goal` | 2 |
| `speech_act` | 2 |
| `role_obligation` | 2 |
| `request_entitlement` | 2 |
| `imposition_size` | 1 |
| `responsibility_structure` | 1 |
| `required_inference_trivialized` | 1 |
| `insufficient_context` | 1 |
| `power_direction` | 1 |
| `recoverability` | 1 |
| `face_threat` | 1 |

## 항목별

| id | 의도 | 원인 | 무엇이 달라졌나 |
|---|---|---|---|
| R01 | SAME_CONTEXT | `interaction_goal · imposition_size` | 앵커는 "이번 주에 도움이 필요하다" 로 부탁이 걸려 있는데, 변형은 "선배가 인쇄 쪽을 잘 안다" 로 끝나 부탁이 사라졌다. 부탁하기가 정보 묻기로 바뀌었다 |
| R02 | NEAR | `speech_act · role_obligation` | 선배에게 호의를 부탁하는 일에서 점장에게 근무 조정을 요청하는 일로 바뀌었다. 상대가 응할 의무의 성격이 다르다 |
| R05 | FAR | `interaction_goal · speech_act · stakes` | 친구에게 근황을 나누는 일에서 인턴이 결정 자리에서 보고하는 일로 바뀌었다. 목적이 관계 유지에서 평가 통과로 옮겨 갔다 |
| R09 | FAR | `responsibility_structure` | 선배에게 도움을 청하는 일에서 내 지연에 대해 팀장에게 양해를 구하는 일로 바뀌었다. 누구 책임인가가 달라졌다 |
| R10 | NEAR | `required_inference_trivialized` | 앵커는 조원이 자료를 정리해 와 지식 상태가 불확실한데, 변형은 오늘 새로 온 사람이라 모른다는 것이 자명하다. 짐작할 것이 없어졌다 |
| R11 | FAR | `role_obligation · stakes` | 조원으로 설명하는 일에서 회사를 대표해 고객사에 설명하는 일로 바뀌었다. 역할 의무가 생겼다. 자연스러움도 1점으로 가장 낮다 |
| R12 | FAR | `request_entitlement` | 친구 단톡의 무응답과 업무 협조 메일의 무응답은 다르다. 친구는 답할 의무가 없고 협조 요청은 있다. 침묵의 뜻이 달라진다 |
| R13 | SAME_CONTEXT | `insufficient_context` | 앵커의 "오랜만에 만난" 이라는 전제가 빠져 상대가 무엇을 아는지 물을 근거가 약해졌다. 맥락 충분 NO 이고 정답 노출도 걸렸다 |
| R16 | FAR | `power_direction · stakes · recoverability` | 룸메에게 소음을 말하는 일에서 교수에게 마감 당일 서류를 청하는 일로 바뀌었다. 권력 방향 · 걸린 것 · 되돌릴 수 있는지가 동시에 바뀌었다 |
| R17 | FAR | `face_threat · request_entitlement` | 친구에게 여행을 제안하는 일에서 사수에게 정규직 전환을 꺼내는 일로 바뀌었다. 체면 위협의 크기가 다른 종류다 |

## 공통 기제 · 제도적 점프

FAR 여섯이 **전부 같은 이동**을 했다.

| id | 앵커 | 변형 |
|---|---|---|
| R05 | FRIEND_CASUAL/FRIEND_PRIVATE cost=LOW recov=True | INTERN_SUPERVISOR/WORK cost=HIGH recov=False |
| R09 | CLUB_SENIOR/CLUB cost=LOW recov=True | TEAM_LEAD/WORK cost=HIGH recov=True |
| R11 | TEAMMATE/SCHOOL_GROUP cost=LOW recov=True | CLIENT/WORK cost=HIGH recov=True |
| R12 | FRIEND_CASUAL/FRIEND_PRIVATE cost=LOW recov=True | CROSS_TEAM/WORK cost=HIGH recov=True |
| R16 | DORM_SENIOR/DORM cost=LOW recov=True | PROFESSOR/SCHOOL_OFFICIAL cost=HIGH recov=False |
| R17 | FRIEND_CASUAL/FRIEND_PRIVATE cost=LOW recov=True | INTERN_SUPERVISOR/WORK cost=HIGH recov=True |

사적 · 또래 · 낮은 대가 에서 **제도적 · 상급자 · 높은 대가** 로 점프했다.

v0.1 의 FAR 규칙이 "관계 또는 자리를 바꾸고 동시에 대가 또는 회복도 바꿔라" 였고,
그 요구를 가장 쉽게 만족시키는 길이 이 점프다.
그런데 이 점프는 목적 · 화행 · 책임 · 의무 · 자격을 **전부 같이** 끌고 간다.

**우연이 아니라 규칙이 시킨 것이다.** 그래서 규칙을 고쳤다.
자세한 것은 `03_ONTOLOGY/TRANSFER_RULE_v0_2.md`.
