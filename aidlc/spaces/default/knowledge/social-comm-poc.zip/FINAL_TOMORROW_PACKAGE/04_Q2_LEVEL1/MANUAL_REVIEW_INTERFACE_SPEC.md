# 팀 수동 리뷰 결과를 받을 자리 · **규격만**

> **실제 팀 CSV 를 아직 받지 못했다.** 그래서 importer 를 완성하지 않는다.
> 아래는 논리적으로 필요한 필드이지, "팀 CSV 의 칼럼 이름이 이것이다" 라는 주장이 아니다.

## 논리 필드

| 논리 필드 | 값 | 무엇 |
|---|---|---|
| `reviewer_id` | 문자열 | 누가 봤는가 |
| `item_id` | 문자열 | 어느 항목인가 |
| `naturalness` | 1~5 | 실제 있을 법한 이야기인가 |
| `context_sufficient` | YES / NO | 무슨 일인지 알 만큼 설명이 있는가 |
| `skill_preservation` | SAME / DIFFERENT / UNSURE | 변형 후에도 같은 핵심 능력을 요구하는가 |
| `distance_judgment` | SAME_CONTEXT / NEAR / FAR / UNSURE | 원본과 얼마나 멀어졌는가 |
| `answer_leakage` | YES / NO | 의도나 적절한 대응을 글이 미리 알려 주는가 |
| `optional_comment` | 자유 | 메모 |

## 실제 CSV 가 오면 하는 순서

1. **실제 schema 를 먼저 읽는다.** 칼럼 이름을 가정하지 않는다
2. 실제 칼럼 → 위 논리 필드로 가는 mapping 을 만든다
3. 그 mapping 으로 importer 를 구현한다
4. 집계한다

순서를 바꾸지 않는다. 임의 schema 로 importer 를 먼저 만들면
실제 파일이 왔을 때 조용히 잘못 읽을 수 있다.

## 나중에 계산할 것

- naturalness 평균
- context sufficiency 비율
- same-skill 비율
- distance agreement (의도 등급 대 읽힌 등급)
- answer leakage 비율
- Skill 별 · distance 별
- 리뷰어가 둘 이상이면 inter-reviewer agreement

## 이름을 고정한다

```
TEAM BLIND MANUAL SANITY RESULT
```

**MODEL ACCURACY 라고 부르지 않는다.**
사람 몇이 장면 열여덟 개를 눈으로 본 결과이고, 표본이 작아 신뢰구간도 안 붙인다.

## 덜 채운 칸

0 으로 세지 않는다. 분모에서 빼고 몇 개였는지 따로 적는다.
없는 판단을 있는 판단으로 바꾸는 것이기 때문이다.
