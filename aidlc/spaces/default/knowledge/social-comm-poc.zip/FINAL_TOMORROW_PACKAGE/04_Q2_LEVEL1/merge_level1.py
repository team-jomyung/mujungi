# -*- coding: utf-8 -*-
"""팀 블라인드 검토 결과를 실제로 병합한다. TEAM REVIEW PENDING 을 없앤다.

    python merge_level1.py

Skill Identity 와 Transfer Distance 를 섞지 않는다
  DIFFERENT 는 FAR 보다 더 먼 것이 **아니다.**
  DIFFERENT 는 요구하는 화용 능력이 달라진 **질적 단절**이다.
  그래서 거리 일치는 **Skill=SAME 인 항목에서만** 센다.
  Skill 이 달라진 항목의 거리를 세는 것은 다른 과제끼리 거리를 재는 것이다.
"""
from __future__ import annotations

import collections
import csv
import io
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, '..', '..'))
RESP = os.path.join(os.path.expanduser('~'), 'Downloads', 'manual_review_responses.csv')
KEY = os.path.join(ROOT, 'POC_B_MANUAL_SANITY', 'MANUAL_REVIEW_KEY.csv')
SCENES = os.path.join(ROOT, 'POC_B_MANUAL_SANITY', 'generated_scenes.jsonl')

# 실패 원인 코딩. 실제 장면과 Core 필드를 대조해 붙였다.
# 사용자가 제시한 가설을 그대로 받지 않고 장면을 읽어 확인한 것만 적는다.
FAILURE = {
    'R01': (['interaction_goal', 'imposition_size'],
            '앵커는 "이번 주에 도움이 필요하다" 로 부탁이 걸려 있는데, 변형은 '
            '"선배가 인쇄 쪽을 잘 안다" 로 끝나 부탁이 사라졌다. 부탁하기가 정보 묻기로 바뀌었다'),
    'R02': (['speech_act', 'role_obligation'],
            '선배에게 호의를 부탁하는 일에서 점장에게 근무 조정을 요청하는 일로 바뀌었다. '
            '상대가 응할 의무의 성격이 다르다'),
    'R05': (['interaction_goal', 'speech_act', 'stakes'],
            '친구에게 근황을 나누는 일에서 인턴이 결정 자리에서 보고하는 일로 바뀌었다. '
            '목적이 관계 유지에서 평가 통과로 옮겨 갔다'),
    'R09': (['responsibility_structure'],
            '선배에게 도움을 청하는 일에서 내 지연에 대해 팀장에게 양해를 구하는 일로 바뀌었다. '
            '누구 책임인가가 달라졌다'),
    'R10': (['required_inference_trivialized'],
            '앵커는 조원이 자료를 정리해 와 지식 상태가 불확실한데, 변형은 오늘 새로 온 사람이라 '
            '모른다는 것이 자명하다. 짐작할 것이 없어졌다'),
    'R11': (['role_obligation', 'stakes'],
            '조원으로 설명하는 일에서 회사를 대표해 고객사에 설명하는 일로 바뀌었다. '
            '역할 의무가 생겼다. 자연스러움도 1점으로 가장 낮다'),
    'R12': (['request_entitlement'],
            '친구 단톡의 무응답과 업무 협조 메일의 무응답은 다르다. '
            '친구는 답할 의무가 없고 협조 요청은 있다. 침묵의 뜻이 달라진다'),
    'R13': (['insufficient_context'],
            '앵커의 "오랜만에 만난" 이라는 전제가 빠져 상대가 무엇을 아는지 물을 근거가 약해졌다. '
            '맥락 충분 NO 이고 정답 노출도 걸렸다'),
    'R16': (['power_direction', 'stakes', 'recoverability'],
            '룸메에게 소음을 말하는 일에서 교수에게 마감 당일 서류를 청하는 일로 바뀌었다. '
            '권력 방향 · 걸린 것 · 되돌릴 수 있는지가 동시에 바뀌었다'),
    'R17': (['face_threat', 'request_entitlement'],
            '친구에게 여행을 제안하는 일에서 사수에게 정규직 전환을 꺼내는 일로 바뀌었다. '
            '체면 위협의 크기가 다른 종류다'),
}


def main():
    if not os.path.exists(RESP):
        print('응답 CSV 가 없다 · %s' % RESP)
        return 2
    R = list(csv.DictReader(io.open(RESP, encoding='utf-8-sig', newline='')))
    K = {k['display_id']: k for k in
         csv.DictReader(io.open(KEY, encoding='utf-8-sig', newline=''))}
    S = {r['item_id']: r for r in
         (json.loads(x) for x in io.open(SCENES, encoding='utf-8') if x.strip())}
    rows = [dict(r, **K[r['display_id']]) for r in R if r['display_id'] in K]

    nat = [float(r['q1_naturalness']) for r in rows if r['q1_naturalness']]
    n = len(rows)
    ctx = sum(1 for r in rows if r['q2_context_sufficient'] == 'YES')
    same = [r for r in rows if r['q3_same_ability'] == 'SAME']
    leak = sum(1 for r in rows if r['q5_answer_leak'] == 'YES')
    agree = sum(1 for r in same if r['q4_distance'] == r['intended_distance'])

    per_g = {}
    for g in ('SAME_CONTEXT', 'NEAR', 'FAR'):
        sub = [r for r in rows if r['intended_distance'] == g]
        per_g[g] = (sum(1 for r in sub if r['q3_same_ability'] == 'SAME'), len(sub))
    per_s = {}
    for sk in ('S1', 'S2', 'S3'):
        sub = [r for r in rows if r['scope_skill'] == sk]
        per_s[sk] = (sum(1 for r in sub if r['q3_same_ability'] == 'SAME'), len(sub))

    # 항목표
    out = []
    for r in sorted(rows, key=lambda x: x['display_id']):
        d = r['display_id']
        fail, why = FAILURE.get(d, ([], ''))
        ok = (r['q3_same_ability'] == 'SAME' and r['q5_answer_leak'] == 'NO'
              and r['q2_context_sufficient'] == 'YES' and float(r['q1_naturalness']) >= 4)
        verdict = 'KEEP' if ok else ('DROP' if 'required_inference_trivialized' in fail
                                     or 'insufficient_context' in fail else 'REWRITE')
        out.append({
            'display_id': d, 'item_id': r['item_id'], 'skill': r['scope_skill'],
            'intended_distance': r['intended_distance'],
            'naturalness': r['q1_naturalness'],
            'context_sufficient': r['q2_context_sufficient'],
            'skill_preservation': r['q3_same_ability'],
            'perceived_distance': r['q4_distance'],
            'answer_leak': r['q5_answer_leak'],
            'distance_counted': ('YES' if r['q3_same_ability'] == 'SAME' else
                                 'NO · Skill 이 달라 거리 비교 대상이 아니다'),
            'failure_modes': ' · '.join(fail) or '-',
            'failure_why': why or '-',
            'verdict': verdict,
            'core_required_inference': r['core_required_inference'],
            'anchor_context': '%s/%s cost=%s recov=%s' % (
                r['anchor_relationship_type'], r['anchor_situation_type'],
                r['anchor_misread_cost'], r['anchor_recoverable']),
            'variant_context': '%s/%s cost=%s recov=%s' % (
                r['variant_relationship_type'], r['variant_situation_type'],
                r['variant_misread_cost'], r['variant_recoverable']),
        })
    p = os.path.join(HERE, 'TEAM_MANUAL_RESULT.csv')
    with io.open(p, 'w', encoding='utf-8-sig', newline='') as fh:
        w = csv.DictWriter(fh, fieldnames=list(out[0].keys()))
        w.writeheader()
        w.writerows(out)

    vc = collections.Counter(x['verdict'] for x in out)
    fm = collections.Counter(f for x in out for f in x['failure_modes'].split(' · ')
                             if f != '-')

    print('Level 1 병합 · 응답 %d · 열쇠 %d · join %d' % (len(R), len(K), n))
    print('  Naturalness 평균 %.2f · 4점이상 %d/%d' %
          (sum(nat) / len(nat), sum(1 for x in nat if x >= 4), len(nat)))
    print('  Context sufficient %d/%d · 정답 미노출 %d/%d' % (ctx, n, n - leak, n))
    print('  **Skill SAME %d/%d**' % (len(same), n))
    print('  Skill=SAME 안에서 거리 일치 %d/%d' % (agree, len(same)))
    print()
    for g, (a, b) in per_g.items():
        print('  의도 %-13s Skill SAME %d/%d' % (g, a, b))
    print()
    for sk, (a, b) in per_s.items():
        print('  %s Skill SAME %d/%d' % (sk, a, b))
    print()
    print('  실패 원인 ·', dict(fm.most_common()))
    print('  판정 ·', dict(vc))
    print('  저장 · TEAM_MANUAL_RESULT.csv')

    json.dump({'n': n, 'naturalness_mean': round(sum(nat) / len(nat), 4),
               'naturalness_ge4': sum(1 for x in nat if x >= 4),
               'context_sufficient': ctx, 'no_answer_leak': n - leak,
               'skill_same': len(same),
               'distance_agree_given_same': agree,
               'per_grade_skill_same': per_g, 'per_skill_skill_same': per_s,
               'failure_modes': dict(fm), 'verdicts': dict(vc),
               'status': 'REVISION_REQUIRED'},
              io.open(os.path.join(HERE, '_level1.json'), 'w', encoding='utf-8'),
              ensure_ascii=False, indent=2)
    return 0


if __name__ == '__main__':
    sys.exit(main())
