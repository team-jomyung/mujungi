# Level 1 · 팀 블라인드 검토 결과

```
LEVEL 1 STATUS = REVISION REQUIRED
```

대화 자체의 자연스러움과 맥락 제공은 대체로 양호하다.
그러나 v0.1 의 Pragmatic Structure / Transfer Rule 은 **Skill Identity 를 충분히 보존하지 못한다.**
특히 **FAR 변환은 여섯 중 하나도 같은 Skill 을 유지하지 못했다.**

## 수치

| 항목 | 값 |
|---|---|
| Naturalness 평균 | **4.61** / 5 |
| 4점 이상 | 16/18 |
| Context Sufficiency | 17/18 |
| 정답 미노출 | 15/18 |
| **Skill Preservation (SAME)** | **8/18** |
| Skill=SAME 안에서 거리 일치 | 6/8 |

## 왜 거리를 SAME 에서만 세는가

`DIFFERENT` 는 FAR 보다 **더 먼 것이 아니다.** 거리 축 위에 있지 않다.
요구하는 화용 능력이 달라진 **질적 단절**이다.
Skill 이 달라진 항목의 거리를 재는 것은 서로 다른 과제끼리 거리를 재는 것이다.
그래서 Skill Identity 와 Transfer Distance 를 섞지 않는다.

## 의도 등급별 · 여기가 핵심이다

| 의도 등급 | Skill SAME | |
|---|---|---|
| SAME_CONTEXT | 4/6 | |
| NEAR | 4/6 | |
| FAR | 0/6 | ← **전멸** |

**멀리 보낼수록 같은 능력을 못 지킨다.** 그리고 FAR 에서는 아예 0 이다.
여섯 중 여섯이므로 우연이 아니다.

## 기술별

| Skill | Skill SAME |
|---|---|
| S1 | 2/6 |
| S2 | 2/6 |
| S3 | 4/6 |

S3 함축 이해가 가장 잘 버틴다. S1 · S2 는 절반도 못 지킨다.

## 항목별

| id | 기술 | 의도 | Skill | 읽힌 거리 | 누출 | 자연 | 판정 |
|---|---|---|---|---|---|---|---|
| R01 | S2 | SAME_CONTEXT | **DIFFERENT** | NEAR | YES | 5 | REWRITE |
| R02 | S2 | NEAR | **DIFFERENT** | FAR | NO | 4 | REWRITE |
| R03 | S1 | NEAR | **SAME** | NEAR | NO | 5 | KEEP |
| R04 | S3 | SAME_CONTEXT | **SAME** | SAME_CONTEXT | NO | 5 | KEEP |
| R05 | S1 | FAR | **DIFFERENT** | FAR | NO | 5 | REWRITE |
| R06 | S2 | NEAR | **SAME** | SAME_CONTEXT | YES | 5 | REWRITE |
| R07 | S3 | NEAR | **SAME** | NEAR | NO | 5 | KEEP |
| R08 | S1 | SAME_CONTEXT | **SAME** | SAME_CONTEXT | NO | 5 | KEEP |
| R09 | S2 | FAR | **UNSURE** | FAR | NO | 5 | REWRITE |
| R10 | S1 | NEAR | **DIFFERENT** | SAME_CONTEXT | NO | 5 | DROP |
| R11 | S1 | FAR | **DIFFERENT** | FAR | NO | 1 | REWRITE |
| R12 | S3 | FAR | **DIFFERENT** | FAR | NO | 5 | REWRITE |
| R13 | S1 | SAME_CONTEXT | **DIFFERENT** | FAR | YES | 3 | DROP |
| R14 | S3 | SAME_CONTEXT | **SAME** | SAME_CONTEXT | NO | 5 | KEEP |
| R15 | S2 | SAME_CONTEXT | **SAME** | SAME_CONTEXT | NO | 5 | KEEP |
| R16 | S2 | FAR | **DIFFERENT** | UNSURE | NO | 5 | REWRITE |
| R17 | S3 | FAR | **DIFFERENT** | NEAR | NO | 5 | REWRITE |
| R18 | S3 | NEAR | **SAME** | SAME_CONTEXT | NO | 5 | KEEP |

판정 · KEEP 7 · REWRITE 9 · DROP 2

## 이 결과를 성과로 제시한다

"맥락을 많이 바꾸는 것 = Far Transfer" 라는 가정이 **틀렸다는 것을 실측으로 확인했다.**
그래서 v0.2 에서 interaction goal · 책임 구조 · 역할 의무 등을 불변식으로 올렸다.
**이 수정 자체가 POC 의 결과다.**
