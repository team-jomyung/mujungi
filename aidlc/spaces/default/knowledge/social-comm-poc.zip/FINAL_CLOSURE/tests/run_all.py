# -*- coding: utf-8 -*-
"""FINAL_CLOSURE 의 계산물을 전부 다시 만들고 문서와 맞는지 본다.

    python tests/run_all.py            느린 것 하나(시뮬레이션)는 건너뛴다
    python tests/run_all.py --all      시뮬레이션까지 전부 돌린다. 수 분 걸린다
    python tests/run_all.py --list     무엇을 돌리는지만 보여 준다

왜 있나
  전에 이 나무의 스크립트들을 셸 반복문으로 돌렸다. 열셋 전부 ok 를 찍었는데
  반복문의 마지막 줄 때문에 종료 코드가 1 로 나왔다. 그래서 "안 돌았다" 고 잘못 적었다.
  검사 결과를 셸 문법에 맡기지 않는다. 여기서 하나하나 종료 코드를 받아 세고 찍는다.

  건너뛴 것을 통과라고 부르지 않는다. 마지막 줄에 돌린 수 · 건너뛴 수를 함께 적는다.
  (RC1 의 ERR-01 이 그 실수였다. 세 검사 중 하나가 안 돌았는데 "전체 통과" 였다.)

무엇을 돌리나
  묶음 1 · 근거표      01_EVIDENCE
  묶음 2 · 자동화      03_AUTOMATION · 판정기 · 편향 · 라우팅 · A1 보고서
  묶음 3 · 생성        04_GENERATION
  묶음 4 · 수행 · 개인화 · 기술  05 · 06 · 07
  묶음 5 · 일치 검사    tests/check_numbers.py

  순서가 중요하다. 앞 묶음이 만든 파일을 뒤 묶음이 읽는다.
  일치 검사는 맨 끝이다. 다시 만든 결과와 문서를 견주는 것이 그 일이기 때문이다.

여기서 일부러 안 돌리는 것
  10_RC/refresh_corrected_release.py · 배포본 사본을 다시 뜬다. 4번 검사가 보는 대상이다.
  tests/stamp_report_counts.py      · 보고서 머리말의 파일 수를 다시 찍는다. 5번 검사가 보는 대상이다.

  둘 다 여기서 돌리면 검사 직전에 고쳐 놓고 검사하는 꼴이라 신호가 사라진다.
  4번이나 5번이 실패하면 그 메시지가 어느 스크립트를 돌리라고 알려 준다. 사람이 돌린다.

이 나무만 본다
  poc_validation_v0_1/ 쪽은 `python poc.py verify-release` 가 따로 본다. 둘 다 돌려야 한다.
"""
from __future__ import annotations

import os
import subprocess
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# (묶음, 상대경로, 느린가, 인자)
# 인자가 필요한 자리가 하나 있다. run_generation.py 는 --dry-run 없이 부르면
# 'POC A 가 통과하지 않았다' 며 막는다. 그것은 고장이 아니라 설계다.
# 사람 판정자가 없는 지금 돌릴 수 있는 것은 배선 확인뿐이라 --dry-run 으로 부른다.
STEPS = [
    ('1 근거표', '01_EVIDENCE/build_evidence_tables.py', False, ()),
    ('1 근거표', '01_EVIDENCE/build_source_table.py', False, ()),
    ('2 자동화', '03_AUTOMATION/a1_sample_size_simulation.py', True, ()),
    ('2 자동화', '03_AUTOMATION/make_a1_report.py', False, ()),
    ('2 자동화', '03_AUTOMATION/judge_harness/gold_split.py', False, ()),
    ('2 자동화', '03_AUTOMATION/judge_harness/judge_harness.py', False, ()),
    ('2 자동화', '03_AUTOMATION/bias_tests/run_bias_tests.py', False, ()),
    ('2 자동화', '03_AUTOMATION/make_routing_report.py', False, ()),
    ('3 생성', '04_GENERATION/generator/variation_plan.py', False, ()),
    ('3 생성', '04_GENERATION/generator/run_generation.py', False, ('--dry-run',)),
    ('3 생성', '04_GENERATION/preservation_evaluation/evaluate_preservation.py', False, ()),
    ('4 수행·개인화·기술', '05_PERFORMANCE/automatic_scoring/score_harness.py', False, ()),
    ('4 수행·개인화·기술', '06_PERSONALIZATION/kg_ablation/run_ablation.py', False, ()),
    ('4 수행·개인화·기술', '07_TECH_ABLATION/scoring/run_ablation.py', False, ()),
    ('5 일치 검사', 'tests/check_numbers.py', False, ()),
]

# 불려 쓰이기만 하는 모듈. 혼자 돌리는 것이 아니라 여기 적어 둔다
LIBS = ('03_AUTOMATION/bias_tests/perturbations.py',
        '03_AUTOMATION/judge_harness/a2_breakdowns.py',
        '04_GENERATION/generator/isolation.py',
        '04_GENERATION/generator/prompts.py',
        '07_TECH_ABLATION/scoring/arms.py')


def run_one(rel, args=()):
    """스크립트가 있는 자리에서 돌린다. 대부분 자기 폴더의 파일을 상대경로로 읽는다."""
    full = os.path.join(ROOT, rel.replace('/', os.sep))
    if not os.path.exists(full):
        return None, 0.0, '파일이 없다'
    env = dict(os.environ, PYTHONIOENCODING='utf-8')
    t0 = time.time()
    p = subprocess.run([sys.executable, os.path.basename(full)] + list(args),
                       cwd=os.path.dirname(full), capture_output=True,
                       text=True, encoding='utf-8', errors='replace', env=env)
    return p, time.time() - t0, (p.stdout or '').strip().split('\n')[-1][:70]


def main(argv):
    want_all = '--all' in argv
    if '--list' in argv:
        for grp, rel, slow, args in STEPS:
            print('  %-18s %s%s%s' % (grp, rel, ' ' + ' '.join(args) if args else '',
                                      '   (느림)' if slow else ''))
        print('  불려 쓰이는 모듈 %d개는 따로 돌리지 않는다' % len(LIBS))
        return 0

    ran, skipped, failed, missing = [], [], [], []
    grp_now = None
    for grp, rel, slow, args in STEPS:
        if grp != grp_now:
            grp_now = grp
            print('\n[%s]' % grp)
        if slow and not want_all:
            skipped.append(rel)
            print('  %-58s 건너뜀 (--all 로 돌린다)' % rel)
            continue
        p, secs, tail = run_one(rel, args)
        if p is None:
            missing.append(rel)
            print('  %-58s 없음' % rel)
            continue
        ok = p.returncode == 0
        (ran if ok else failed).append(rel)
        label = rel + (' ' + ' '.join(args) if args else '')
        print('  %-58s %-4s %5.1fs  %s' % (label, 'ok' if ok else 'FAIL', secs, tail))
        if not ok:
            for ln in (p.stderr or '').strip().split('\n')[-6:]:
                print('        | %s' % ln)

    print('\n' + '=' * 62)
    print('  돌린 것 %d · 실패 %d · 건너뛴 것 %d · 없는 것 %d'
          % (len(ran), len(failed), len(skipped), len(missing)))
    for rel in skipped:
        print('    건너뜀 · %s' % rel)
    for rel in missing:
        print('    없음 · %s' % rel)
    bad = failed or missing
    if bad:
        print('  판정 · 실패')
    elif skipped:
        # 건너뛴 것이 있으면 "전부 통과" 라고 쓰지 않는다. ERR-01 이 그 실수였다
        print('  판정 · 돌린 것은 전부 통과. 건너뛴 것 %d 개는 확인하지 않았다' % len(skipped))
    else:
        print('  판정 · 전부 통과')
    return 1 if bad else 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
