# -*- coding: utf-8 -*-
"""보고서 머리말의 파일 수·크기를 실측으로 다시 찍는다.

    python tests/stamp_report_counts.py

왜 있나
  이 값을 손으로 세 번 고쳤고 세 번 다 뒤에 또 틀렸다. 파일을 하나 더하면 조용히 어긋난다.
  ERR-04 · 05 · 06 과 같은 계열이다. 그래서 세어서 찍고, check_numbers.py 5번이 매번 확인한다.

  배포 문서 쪽에도 같은 일이 있었다(템플릿에 91 · 94 가 박혀 있었다). 거기는 make_release.py 가 이미 잰다.
"""
from __future__ import annotations

import io
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
REPORT = os.path.join(ROOT, 'FINAL_CLOSURE_REPORT.html')
SKIP_DIRS = {'__pycache__', '.git'}
RX = re.compile(r'(산출물 · <code>FINAL_CLOSURE/</code> · <b>파일 )(\d+)(개 · )(\d+)(KB</b>)')
# Q 항목의 '86 파일 · 11 디렉터리' 도 같은 계열이라 함께 찍는다
RX_Q = re.compile(r'(<td>)(\d+)( 파일 · )(\d+)( 디렉터리 · 이 보고서</td>)')


def measure():
    """보고서 자신은 세지 않는다. 자기 크기를 자기가 적으면 값이 수렴하지 않는다."""
    n = nb = nd = 0
    for dp, dn, fn in os.walk(ROOT):
        dn[:] = [d for d in dn if d not in SKIP_DIRS]
        nd += len(dn)
        for f in fn:
            full = os.path.join(dp, f)
            if os.path.abspath(full) == os.path.abspath(REPORT):
                continue
            n += 1
            nb += os.path.getsize(full)
    return n, nb // 1024, nd


def main(check_only=False):
    n, kb, nd = measure()
    s = io.open(REPORT, encoding='utf-8').read()
    m = RX.search(s)
    if m is None:
        print('보고서에서 산출물 줄을 못 찾았다. 문구가 바뀌었으면 RX 를 고친다')
        return 1
    have_n, have_kb = int(m.group(2)), int(m.group(4))
    mq = RX_Q.search(s)
    q_ok = mq is not None and (int(mq.group(2)), int(mq.group(4))) == (n, nd)
    if (have_n, have_kb) == (n, kb) and q_ok:
        print('그대로다 · 파일 %d개 · %dKB · 디렉터리 %d' % (n, kb, nd))
        return 0
    if check_only:
        print('어긋났다 · 적힘 %d개 %dKB · 실제 %d개 %dKB' % (have_n, have_kb, n, kb))
        return 1
    s2 = RX.sub(lambda x: '%s%d%s%d%s' % (x.group(1), n, x.group(3), kb, x.group(5)), s, count=1)
    s2 = RX_Q.sub(lambda x: '%s%d%s%d%s' % (x.group(1), n, x.group(3), nd, x.group(5)), s2, count=1)
    io.open(REPORT, 'w', encoding='utf-8', newline='\n').write(s2)
    print('다시 찍었다 · 산출물 %d개 %dKB → %d개 %dKB · Q 항목 파일 %d · 디렉터리 %d'
          % (have_n, have_kb, n, kb, n, nd))
    return 0


if __name__ == '__main__':
    sys.exit(main('--check' in sys.argv[1:]))
