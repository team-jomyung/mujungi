# -*- coding: utf-8 -*-
"""문서에 적힌 시뮬레이션 수치가 지금 코드의 출력과 같은가 본다.

    python tests/check_numbers.py

왜 있나
  ERR-06 · 문서 여덟 곳이 인용한 값(0.13 · 0.81 · 0.58 · 0.90 · 0.63)이 지금 스크립트의
  출력과 달랐다. 스크립트는 결정적이었다(두 번 돌려 해시가 같다). 틀린 쪽은 문서였다.
  옛 판의 출력을 손으로 옮겨 적어 둔 것이 코드가 바뀐 뒤에도 남아 있었다.

  RC1 꾸러미에는 같은 계열을 잡는 tests/consistency.py 가 있다. 그것은 poc_validation_v0_1/
  안만 본다. 이 파일은 FINAL_CLOSURE/ 쪽을 본다. 두 나무가 서로를 모른다.

무엇을 보나
  1 생성물   A1_SAMPLE_SIZE_REPORT.md 가 지금 JSON 으로 다시 만든 것과 같은가
  2 등록 숫자 문서에 적힌 값이 JSON 의 값과 같은가. 문장이 사라져 정규식이 안 맞아도 실패다
  3 옛 수치   알려진 옛 값이 남아 있으면 실패
  4 배포본 사본 10_RC/corrected_release 의 zip 이 원본과 같은 바이트인가
             README 에 적힌 해시·크기가 그 파일을 잰 값과 같은가

  2번이 문장이 없어도 실패인 것이 핵심이다. 문장을 지워서 통과하는 길을 막는다.

면제
  옛 값을 일부러 인용하는 줄(에라타의 재현 표 등)은 줄 끝에 numcheck-ok 를 붙인다.
  파일 단위 면제는 EXEMPT 에 적는다. 이 파일 자신도 옛 값 목록을 들고 있으므로 면제한다.
  경로가 아니라 이름으로 알아본다. 면제 수는 항상 화면에 찍는다.
"""
from __future__ import annotations

import io
import json
import os
import re
import sys
import tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SELF_NAME = os.path.basename(__file__)
RESULTS_REL = '03_AUTOMATION/A1_SAMPLE_SIZE_RESULTS.json'
REPORT_REL = '03_AUTOMATION/A1_SAMPLE_SIZE_REPORT.md'
LINE_MARK = 'numcheck' + '-ok'

SKIP_DIRS = {'__pycache__', '.git', 'corrected_release'}
TEXT_EXT = ('.md', '.html')

EXEMPT = {
    '10_RC/RC1_ENGINEERING_ERRATA.md': '에라타는 고치기 전 값을 재현 기록으로 인용한다',
    REPORT_REL: 'JSON 에서 생성된다. 1번 검사가 따로 본다',
    '10_RC/VERIFY_RELEASE_RESULT.md': '실행 로그다. 도구가 찍은 글자를 고치면 기록이 아니다',
}


def read(rel):
    return io.open(os.path.join(ROOT, rel.replace('/', os.sep)), encoding='utf-8').read()


def load_grid():
    d = json.load(io.open(os.path.join(ROOT, RESULTS_REL.replace('/', os.sep)), encoding='utf-8'))
    grid = {}
    for r in d['results']:
        grid[(r['prevalence'], r['n'], round(r['kappa_true'], 2))] = r
    return d, grid


D, GRID = load_grid()


def P(n, k, prev='balanced'):
    """문턱 초과 주장 확률. 격자에 없는 칸을 물으면 바로 터뜨린다."""
    r = GRID.get((prev, n, round(k, 2)))
    if r is None:
        raise KeyError('격자에 없는 칸 · n=%s κ=%s · 있는 n %s'
                       % (n, k, sorted({x[1] for x in GRID})))
    return r['p_lower_ci_above_threshold']


# (파일, 정규식, 기대값 목록, 배율, 설명)
# 배율 100 은 문서가 퍼센트로 적은 자리다.
def claims():
    kappa_row = lambda a, b, c, d: [a, b, c, d]
    return [
        ('00_EXECUTIVE/FINAL_VERDICT.md',
         r'\| κ 0\.7 \| \*\*([\d.]+)\*\* \| ([\d.]+) \| ([\d.]+) \| ([\d.]+) \|',
         kappa_row(P(40, .7), P(60, .7), P(100, .7), P(150, .7)), 1, 'κ0.7 표'),
        ('00_EXECUTIVE/FINAL_VERDICT.md',
         r'\| κ 0\.8 \| ([\d.]+) \| \*\*([\d.]+)\*\* \| ([\d.]+) \| \*\*([\d.]+)\*\* \|',
         kappa_row(P(40, .8), P(60, .8), P(100, .8), P(150, .8)), 1, 'κ0.8 표'),
        ('00_EXECUTIVE/FINAL_VERDICT.md',
         r'40쌍으로는 결론이 안 난다\.\*\* 확률 ([\d.]+) 다\.',
         [P(40, .7)], 1, '40쌍 본문'),
        ('00_EXECUTIVE/REMAINING_HUMAN_BLOCKERS.md',
         r'\| κ 0\.7 \| \*\*([\d.]+)\*\* \| ([\d.]+) \| ([\d.]+) \| ([\d.]+) \|',
         kappa_row(P(40, .7), P(60, .7), P(100, .7), P(150, .7)), 1, 'κ0.7 표'),
        ('00_EXECUTIVE/REMAINING_HUMAN_BLOCKERS.md',
         r'\| κ 0\.8 \| ([\d.]+) \| \*\*([\d.]+)\*\* \| ([\d.]+) \| \*\*([\d.]+)\*\* \|',
         kappa_row(P(40, .8), P(60, .8), P(100, .8), P(150, .8)), 1, 'κ0.8 표'),
        ('00_EXECUTIVE/REMAINING_HUMAN_BLOCKERS.md',
         r'seed (\d+) · 반복 (\d+) · 부트스트랩 (\d+)',
         [D['seed'], D['reps'], D['bootstrap']], 1, '실행 조건'),
        ('00_EXECUTIVE/REMAINING_HUMAN_BLOCKERS.md',
         r'양옆\(100쌍 ([\d.]+) · 150쌍 ([\d.]+)\)',
         [P(100, .8), P(150, .8)], 1, '격자 양옆'),
        ('00_EXECUTIVE/INSTRUCTOR_QA_50.md',
         r'40쌍에서 문턱 초과 주장 확률 \*\*([\d.]+)\*\*\. 60쌍 κ 0\.8 이면 ([\d.]+)\.',
         [P(40, .7), P(60, .8)], 1, 'Q 답변'),
        ('00_EXECUTIVE/ONE_PAGE_INSTRUCTOR_RESPONSE.md',
         r'문턱 초과를 주장할 확률이 \*\*([\d.]+)%\*\* 입니다\. 60쌍에서 κ 0\.8 이면 ([\d.]+)% 입니다\.',
         [P(40, .7), P(60, .8)], 100, '한 장 답변 · 퍼센트'),
        ('02_SCOPE/SPEC_V0_2_CANDIDATES.md',
         r'참 일치 0\.7 에서 40쌍의 문턱 주장 확률 ([\d.]+)\.',
         [P(40, .7)], 1, 'v0.2 후보 근거'),
        ('03_AUTOMATION/A1_PROTOCOL.md',
         r'κ참값 0\.8 에서 문턱 주장 확률 ([\d.]+)\.',
         [P(60, .8)], 1, '최소 표본 근거'),
        ('03_AUTOMATION/A1_PROTOCOL.md',
         r'격자 양옆\(100쌍 ([\d.]+) · 150쌍 ([\d.]+)\)',
         [P(100, .8), P(150, .8)], 1, '권장 표본 근거'),
        ('03_AUTOMATION/A1_PROTOCOL.md',
         r'40쌍으로 문턱 주장 \| κ 0\.7 이어도 확률 ([\d.]+)',
         [P(40, .7)], 1, '하지 않는 것'),
        ('STATISTICAL_DESIGN.md',
         r'κ참값 0\.8 에서 P\(하한>0\.6\)=([\d.]+)\)',
         [P(60, .8)], 1, '설계 표'),
        ('FINAL_CLOSURE_REPORT.html',
         r'문턱 주장 확률 <b>([\d.]+)</b>',
         [P(60, .8)], 1, '표본 표 · 최소'),
        ('FINAL_CLOSURE_REPORT.html',
         r'양옆\(100쌍 ([\d.]+) · 150쌍 ([\d.]+)\)',
         [P(100, .8), P(150, .8)], 1, '표본 표 · 권장'),
        ('FINAL_CLOSURE_REPORT.html',
         r'40쌍 κ0\.7 → ([\d.]+) · 60쌍 κ0\.8 → ([\d.]+)',
         [P(40, .7), P(60, .8)], 1, '요약 표'),
    ]


# 옛 값. 문맥까지 넣는다. 0.81 은 판정자 훈련 81% 와 겹치므로 앞말을 함께 걸고,
# 0.812 같은 앞부분 일치를 피하려고 뒤에 오는 글자(마침표·닫는 괄호)까지 건다.
STALE = [
    ('문턱 초과 주장 확률 **0.13**', 'ERR-06 · 지금 값은 0.175'),
    ('문턱 주장 확률 0.13.', 'ERR-06 · 지금 값은 0.175'),
    ('문턱 주장 확률 0.81.', 'ERR-06 · 지금 값은 0.795'),
    ('P(하한>0.6)=0.81)', 'ERR-06 · 지금 값은 0.795'),
    ('κ 0.8 이면 0.81', 'ERR-06 · 지금 값은 0.795'),
    ('κ 0.8 이면 81%', 'ERR-06 · 지금 값은 79.5%'),
    ('확률이 **13%**', 'ERR-06 · 지금 값은 17.5%'),
    ('| κ 0.7 | **0.13**', 'ERR-06 · 옛 격자 줄'),
    ('| κ 0.8 | 0.58 |', 'ERR-06 · 옛 격자 줄'),
    ('κ 0.8 에서 0.90', 'ERR-06 · 격자에 120 이 없다'),
    ('n=120 |', 'ERR-06 · 격자에 120 이 없다. 100 과 150 으로 적는다'),
    ('거리 축이 54쌍으로', 'ERR-06 · 유지율이 두 값이라 54~72쌍이다'),
    ('유지율 0.45 라 40쌍 → 18쌍', 'ERR-06 · 0.45~0.60 이라 18~24쌍이다'),
    ('40쌍이 18쌍으로 줄어', 'ERR-06 · 18~24쌍이다'),
    ('모든 n 에서 확률 0.02)', 'ERR-06 · n 에 따라 0.02~0.07 이다'),
    ('blind 20쌍', 'ERR-04 · 선별은 40쌍이다'),
    ('일곱 항목', 'ERR-05 · verify-release 는 여덟 항목이다'),
]


# 문장 목록에는 구멍이 있다. 실제로 세 번째 자리를 놓쳤다
# (EVIDENCE_LEDGER_NOTE.md 의 "A1 시뮬레이션 (0.13 · 0.81)" 은 등록된 어느 표현에도 안 걸렸다).
# 그래서 문장이 아니라 **값과 맥락**으로도 본다. 옛 값 일곱은 지금 balanced 격자에 하나도 없다.
# 문서는 balanced 만 인용하므로, 시뮬레이션 얘기를 하는 줄에 이 값이 있으면 옛것이다.
# 0.13 과 0.28 은 다른 prevalence 격자에는 있다. 그래서 맥락 낱말을 함께 건다.
OLD_VALUES = (0.13, 0.81, 0.58, 0.90, 0.63, 0.28, 0.37)
CONTEXT = ('시뮬레이션', '문턱 주장', '문턱 초과', 'κ참값', '참 일치', 'A1_SAMPLE_SIZE', 'P(하한')
NUM = re.compile(r'(?<![\d.])(\d\.\d+)(?![\d])')


def stale_by_value(line):
    """옛 값이 시뮬레이션 얘기를 하는 줄에 있으면 잡는다.
    훈련 81% 같은 것은 소수가 아니라 안 걸리고, AUC 0.58 은 맥락 낱말이 없어 안 걸린다."""
    if not any(w in line for w in CONTEXT):
        return []
    return [t for t in NUM.findall(line)
            if any(abs(float(t) - o) < 1e-9 for o in OLD_VALUES)]


def walk():
    for dirpath, dirnames, filenames in os.walk(ROOT):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
        for fn in filenames:
            if not fn.endswith(TEXT_EXT):
                continue
            full = os.path.join(dirpath, fn)
            yield os.path.relpath(full, ROOT).replace(os.sep, '/'), full


def check_generated(out):
    """보고서가 지금 JSON 으로 만든 것과 같은가. 파일을 건드리지 않고 임시 자리에 만들어 견준다."""
    sys.path.insert(0, os.path.join(ROOT, '03_AUTOMATION'))
    try:
        import make_a1_report as M
    except Exception as e:                                     # noqa: BLE001
        out.append(('1 생성물', False, '생성기를 못 불렀다 · %s' % e))
        return
    keep = M.OUT
    tmp = os.path.join(tempfile.mkdtemp(), 'A1_SAMPLE_SIZE_REPORT.md')
    try:
        M.OUT = tmp
        M.main()
    except Exception as e:                                     # noqa: BLE001
        out.append(('1 생성물', False, '생성기가 터졌다 · %s' % e))
        return
    finally:
        M.OUT = keep
    fresh = io.open(tmp, encoding='utf-8').read()
    try:
        have = read(REPORT_REL)
    except IOError:
        out.append(('1 생성물', False, '%s 가 없다. make_a1_report.py 를 돌린다' % REPORT_REL))
        return
    ok = fresh == have
    out.append(('1 생성물', ok,
                '보고서가 JSON 과 같다' if ok else
                '%s 가 옛것이다. python 03_AUTOMATION/make_a1_report.py 를 돌린다' % REPORT_REL))


def check_claims(out):
    bad, n = [], 0
    for rel, pat, want, scale, why in claims():
        try:
            text = read(rel)
        except IOError:
            bad.append('%s · 파일이 없다' % rel)
            continue
        m = re.search(pat, text)
        if m is None:
            # 문장이 사라진 것도 실패다. 지워서 통과하는 길을 막는다
            bad.append('%s · %s · 문장을 못 찾았다 · %s' % (rel, why, pat[:46]))
            continue
        for got_s, w in zip(m.groups(), want):
            n += 1
            try:
                got = float(got_s)
            except ValueError:
                bad.append('%s · %s · 숫자가 아니다 · %s' % (rel, why, got_s))
                continue
            if abs(got - float(w) * scale) > 1e-6:
                bad.append('%s · %s · 적힌 값 %s · JSON 값 %s'
                           % (rel, why, got_s, float(w) * scale))
    out.append(('2 등록 숫자', not bad, '%d개 값 · 어긋남 %d' % (n, len(bad))))
    return bad


def check_stale(out):
    """줄 단위로 본다. 옛 값을 일부러 인용하는 줄은 numcheck-ok 표시로 넘긴다."""
    hits, ex_files, ex_lines = [], [], []
    for rel, full in walk():
        base = os.path.basename(full)
        if rel in EXEMPT or base == SELF_NAME:
            ex_files.append(rel)
            continue
        text = io.open(full, encoding='utf-8', errors='replace').read()
        for i, line in enumerate(text.split('\n'), 1):
            marked = LINE_MARK in line
            for p, why in STALE:
                if p not in line:
                    continue
                if marked:
                    ex_lines.append('%s:%d' % (rel, i))
                else:
                    hits.append('%s:%d · "%s" · %s' % (rel, i, p, why))
            vals = stale_by_value(line)
            if vals:
                if marked:
                    ex_lines.append('%s:%d (값)' % (rel, i))
                else:
                    hits.append('%s:%d · 값 %s · 시뮬레이션 맥락인데 지금 balanced 격자에 없는 수다'
                                % (rel, i, ' · '.join(vals)))
    out.append(('3 옛 수치', not hits,
                '남은 것 %d · 면제 파일 %d · 면제 줄 %d' % (len(hits), len(ex_files), len(ex_lines))))
    return hits


def check_release_copy(out):
    """10_RC/corrected_release 의 사본이 원본 배포본과 같은 바이트인가.
    README 에 적힌 해시·크기도 그 파일을 잰 값과 같아야 한다. 손으로 적어 두면 조용히 틀린다."""
    import hashlib
    cop = os.path.join(ROOT, '10_RC', 'corrected_release', 'poc_validation_v0_1_RC1.zip')
    src = os.path.normpath(os.path.join(ROOT, '..', 'poc_validation_v0_1_RC1.zip'))
    for path, what in ((src, '원본'), (cop, '사본')):
        if not os.path.exists(path):
            out.append(('4 배포본 사본', False, '%s 이 없다 · %s' % (what, path)))
            return []
    dig = lambda q: hashlib.sha256(open(q, 'rb').read()).hexdigest()
    d_src, d_cop = dig(src), dig(cop)
    bad = []
    if d_src != d_cop:
        bad.append('사본이 원본과 다르다 · 원본 %s · 사본 %s · '
                   'python 10_RC/refresh_corrected_release.py 를 돌린다'
                   % (d_src[:16], d_cop[:16]))
    try:
        readme = read('10_RC/corrected_release/README.md')
    except IOError:
        bad.append('corrected_release/README.md 가 없다')
        readme = ''
    if readme:
        m = re.search(r'\| SHA256 \| `([0-9a-f]{64})` \|', readme)
        if m is None:
            bad.append('README 에 SHA256 줄이 없다')
        elif m.group(1) != d_cop:
            bad.append('README 의 해시가 파일과 다르다 · 적힘 %s · 실제 %s'
                       % (m.group(1)[:16], d_cop[:16]))
        m = re.search(r'\| 크기 \| ([\d,]+) bytes \|', readme)
        real = os.path.getsize(cop)
        if m is None:
            bad.append('README 에 크기 줄이 없다')
        elif int(m.group(1).replace(',', '')) != real:
            bad.append('README 의 크기가 파일과 다르다 · 적힘 %s · 실제 %d' % (m.group(1), real))
    out.append(('4 배포본 사본', not bad,
                '원본 = 사본 %s · README 실측 일치' % d_cop[:12] if not bad
                else '어긋남 %d' % len(bad)))
    return bad


def scope_changes():
    """ONTOLOGY_SCOPE_FINAL 의 판정표를 세어 (뒤집힘, 합침) 을 낸다.
    '유지' 가 붙은 줄은 바뀌지 않은 것이다. 문장에 적힌 수를 믿지 않고 표를 센다."""
    s = read('02_SCOPE/ONTOLOGY_SCOPE_FINAL.md')
    i = s.find('| 후보 | CLOSURE_RESEARCH')
    if i < 0:
        return (-1, -1)
    flip = merge = 0
    for line in s[i:].split('\n'):
        if not line.startswith('|'):
            break
        if line.startswith('|---') or 'CLOSURE_RESEARCH' in line:
            continue
        cells = [c.strip() for c in line.strip('|').split('|')]
        if len(cells) < 3:
            continue
        now = cells[2].replace('*', '')
        if '합침' in now:
            merge += 1
        elif '유지' in now:
            pass
        else:
            flip += 1
    return flip, merge


def check_report_counts(out):
    """보고서 머리말의 파일 수·크기가 실측과 같은가. 손으로 세 번 고쳤고 세 번 다 또 틀렸다."""
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    try:
        import stamp_report_counts as S
    except Exception as e:                                     # noqa: BLE001
        out.append(('5 보고서 실측', False, '재는 스크립트를 못 불렀다 · %s' % e))
        return []
    n, kb, nd = S.measure()
    try:
        s = read('FINAL_CLOSURE_REPORT.html')
    except IOError:
        out.append(('5 보고서 실측', False, 'FINAL_CLOSURE_REPORT.html 이 없다'))
        return []
    m = S.RX.search(s)
    if m is None:
        out.append(('5 보고서 실측', False, '보고서에서 산출물 줄을 못 찾았다'))
        return ['산출물 줄의 문구가 바뀌었으면 stamp_report_counts.py 의 RX 를 고친다']
    have_n, have_kb = int(m.group(2)), int(m.group(4))
    # 파일 수는 엄격히 본다. 그것이 실제 주장이다.
    # KB 는 글자 몇 줄만 고쳐도 움직인다. 편집마다 빨개지는 검사는 일주일이면 꺼진다.
    # 그래서 크기는 2% 넘게 벌어질 때만 잡는다. 어느 쪽이든 다시 찍으면 둘 다 맞춰진다.
    drift = abs(have_kb - kb) / float(max(kb, 1))
    bad = []
    if have_n != n:
        bad.append('파일 수가 다르다 · 적힘 %d · 실제 %d' % (have_n, n))
    if drift > 0.02:
        bad.append('크기가 %.1f%% 벌어졌다 · 적힘 %dKB · 실제 %dKB' % (drift * 100, have_kb, kb))
    # Q 항목의 '파일 · 디렉터리' 도 같은 자리다. 여기도 손으로 적혀 있었다
    mq = S.RX_Q.search(s)
    if mq is None:
        bad.append('Q 항목의 파일·디렉터리 줄을 못 찾았다')
    elif (int(mq.group(2)), int(mq.group(4))) != (n, nd):
        bad.append('Q 항목 · 적힘 %s파일 %s디렉터리 · 실제 %d파일 %d디렉터리'
                   % (mq.group(2), mq.group(4), n, nd))
    # 공학 오류 건수는 세 곳에 적혀 있다. 에라타의 절 수가 정본이다.
    n_err = len(re.findall(r'(?m)^## ERR-\d+', read('10_RC/RC1_ENGINEERING_ERRATA.md')))
    m2 = re.search(r'RC1 공학 오류 <b>(\d+)건</b>', s)
    if m2 is None:
        bad.append('보고서에 공학 오류 건수 줄이 없다')
    elif int(m2.group(1)) != n_err:
        bad.append('공학 오류 건수 · 보고서 %s건 · 에라타 절 %d개' % (m2.group(1), n_err))
    fv = read('00_EXECUTIVE/FINAL_VERDICT.md')
    n_row = len(re.findall(r'(?m)^\| \*?\*?ERR-\d+', fv))
    if n_row != n_err:
        bad.append('공학 오류 표 행 · FINAL_VERDICT %d행 · 에라타 절 %d개' % (n_row, n_err))

    # 범위 판정이 몇 군데 뒤집혔는가. 표를 세고 두 문서의 문장과 견준다.
    # 표는 다섯 뒤집힘 + 하나 합침인데 문서 둘이 서로 다른 수를 적고 있었다.
    n_flip, n_merge = scope_changes()
    KO = {4: '네', 5: '다섯', 6: '여섯', 7: '일곱'}
    want = KO.get(n_flip)
    onto = read('02_SCOPE/ONTOLOGY_SCOPE_FINAL.md')
    m3 = re.search(r'판정이 (\S+) 군데서 뒤집히', onto)
    if m3 is None:
        bad.append('ONTOLOGY_SCOPE_FINAL 에 뒤집힌 군데 수 문장이 없다')
    elif m3.group(1) != want:
        bad.append('범위 뒤집힘 · 문장 "%s 군데" · 표 실측 %d군데' % (m3.group(1), n_flip))
    m4 = re.search(r'범위 판정이 (\S+) 군데 뒤집힌', s)
    if m4 is None:
        bad.append('보고서에 범위 뒤집힘 문장이 없다')
    elif m4.group(1) != want:
        bad.append('범위 뒤집힘 · 보고서 "%s 군데" · 표 실측 %d군데' % (m4.group(1), n_flip))
    out.append(('5 보고서 실측', not bad,
                '파일 %d개 · %dKB (적힌 크기 %dKB · 차이 %.1f%%) · 공학 오류 %d건 세 곳 일치'
                % (n, kb, have_kb, drift * 100, n_err)
                if not bad else ' · '.join(bad)))
    return [] if not bad else ['python tests/stamp_report_counts.py 를 돌려 다시 찍는다 '
                               '(오류 건수가 어긋났으면 그것은 손으로 맞춘다)']


def check_census(out):
    """census NOTE 에 적힌 수가 CSV 와 같은가.

    여기 걸린 적이 있다. "어느 데이터셋도 학습 허용이 아니다" 라고 적었는데 다섯 행이 ALLOWED 였다.
    확인 스크립트가 '가능' 과 'YES' 를 찾았고 표는 'ALLOWED' 를 쓴다. 검사가 통과해서 믿었다.
    **표가 쓰는 낱말로 세지 않으면 검사는 없는 것만 못하다.** 그래서 값을 표에서 직접 센다."""
    import csv as _csv
    bad, got = [], {}
    try:
        rows = {}
        for key, f in (('ko', 'DATASET_CENSUS_KO.csv'), ('gl', 'DATASET_CENSUS_GLOBAL.csv')):
            p = os.path.join(ROOT, '01_EVIDENCE', f)
            rows[key] = list(_csv.DictReader(io.open(p, encoding='utf-8', newline='')))
        note = read('01_EVIDENCE/DATASET_CENSUS_NOTE.md')
    except (IOError, OSError) as e:
        out.append(('6 census 대조', False, 'census 파일을 못 읽었다 · %s' % e))
        return []
    allr = rows['ko'] + rows['gl']
    got['ko'], got['gl'] = len(rows['ko']), len(rows['gl'])

    # 개수를 세기 전에 **어휘부터 잠근다.**
    # 개수만 세면 누가 한 칸을 '가능' 으로 고쳐도 세는 낱말에 안 걸려 조용히 통과한다.
    # 그것이 이 검사를 만들게 한 오류 그대로다. 그래서 집합에 없는 값이 나오면 실패시킨다.
    PERMIT = ('ALLOWED', 'FORBIDDEN', 'CONDITIONAL', 'RESERVED', 'UNDETERMINED')
    VOCAB = {
        'redistribution': PERMIT,
        'commercial_use': PERMIT,
        'model_training': PERMIT,
        'relevance_to_scd': ('SEED_SURFACE', 'INTERPRETIVE_FRAME', 'UNRELATED', 'UNDETERMINED'),
        'retrieval': ('FULL', 'ABSTRACT', 'NOT RETRIEVED'),
    }
    head = lambda v: re.split(r'\s*[(（]', v.strip(), maxsplit=1)[0].strip().upper()
    off = []
    for r in allr:
        for col, allowed in VOCAB.items():
            h = head(r.get(col, ''))
            if h not in allowed:
                off.append('%s · %s = "%s"' % (r['name'][:22], col, r.get(col, '')[:28]))
        # license 는 이름이 제각각이라 통째로 잠글 수 없다.
        # 다만 '모른다' 를 뜻하는 두 표기만은 정확해야 한다. NOT SURE 같은 새 표기가 들어오면 잡는다
        lic = r.get('license', '').strip().upper()
        if lic.startswith('NOT') and not (lic.startswith('NOT STATED') or lic.startswith('NOT CHECKED')):
            off.append('%s · license = "%s" · NOT STATED 또는 NOT CHECKED 여야 한다'
                       % (r['name'][:22], r['license'][:28]))
    if off:
        bad.append('어휘 밖의 값 %d · %s' % (len(off), off[:3]))

    got['allowed'] = sum(1 for r in allr if head(r['model_training']) == 'ALLOWED')
    got['not_stated'] = sum(1 for r in allr if 'NOT STATED' in r['license'])
    got['not_checked'] = sum(1 for r in allr if 'NOT CHECKED' in r['license'] or not r['license'].strip())

    # 라이선스를 모르는 줄은 **세 권한 열이 전부** 막혀 있어야 한다. 재배포만 보면 모자란다
    SAFE = ('FORBIDDEN', 'CONDITIONAL', 'RESERVED')
    unknown = [r for r in allr if 'NOT STATED' in r['license'] or 'NOT CHECKED' in r['license']
               or not r['license'].strip()]
    for col in ('redistribution', 'commercial_use', 'model_training'):
        opened = [r['name'] for r in unknown if head(r[col]) not in SAFE]
        if opened:
            bad.append('라이선스 미상인데 %s 가 안 막힌 줄 %d · %s' % (col, len(opened), opened[:3]))

    for label, rx, want in (
            ('항목 KO', r'\| 항목 \| \*\*(\d+)\*\* \| \*\*(\d+)\*\* \|', (got['ko'], got['gl'])),
            ('ALLOWED', r'\*\*(\d+)행이 `ALLOWED`\*\*', (got['allowed'],)),
            ('NOT STATED', r'\*\*`NOT STATED` (\d+)행\*\*', (got['not_stated'],)),
            ('NOT CHECKED', r'\*\*`NOT CHECKED` (\d+)행\*\*', (got['not_checked'],))):
        m = re.search(rx, note)
        if m is None:
            bad.append('NOTE 에 %s 문장이 없다' % label)
        elif tuple(int(x) for x in m.groups()) != want:
            bad.append('%s · NOTE %s · CSV %s' % (label, m.groups(), want))
    out.append(('6 census 대조', not bad,
                'KO %d · GLOBAL %d · ALLOWED %d · 미상 %d(표기없음 %d · 미확인 %d) · 열린 줄 0'
                % (got['ko'], got['gl'], got['allowed'],
                   got['not_stated'] + got['not_checked'], got['not_stated'], got['not_checked'])
                if not bad else '어긋남 %d' % len(bad)))
    return bad


def main():
    out, detail = [], []
    check_generated(out)
    detail += check_claims(out)
    detail += check_stale(out)
    detail += check_release_copy(out)
    detail += check_report_counts(out)
    detail += check_census(out)
    for name, ok, msg in out:
        print('  %-12s %s %s' % (name, 'ok' if ok else 'FAIL', msg))
    for d in detail:
        print('     - %s' % d)
    passed = all(ok for _, ok, _ in out)
    print('  판정 · %s' % ('통과' if passed else '실패'))
    return 0 if passed else 1


if __name__ == '__main__':
    sys.exit(main())
