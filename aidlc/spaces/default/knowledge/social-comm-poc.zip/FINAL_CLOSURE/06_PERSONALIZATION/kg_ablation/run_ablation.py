# -*- coding: utf-8 -*-
"""Personal KG necessity ablation. 합성 사건으로 저장 구조 넷을 같은 질의로 비교한다.

    python run_ablation.py            seed 고정. 결과 results/kg_ablation.json

비교하는 저장 구조
  FLAT      사건 리스트. 매 질의마다 전체를 훑는다
  SQL       sqlite 관계형. signature, relationship, timestamp 에 인덱스
  VECTOR    bag-of-words 코사인. 불변항 문장의 유사도로 찾는다. 라벨을 쓰지 않는다
  KG        dict 기반 그래프. event -HAS_SIG-> signature, event -WITH-> relationship

질의 넷 (P 워크스트림의 질문에 대응)
  Q1 반복 패턴 탐지     같은 Signature 3회 이상인 Signature 를 찾는다
  Q2 근거 추적         한 집계 값에서 그것을 만든 사건 id 를 전부 되돌린다
  Q3 시간 질의         최근 8건과 그 이전 8건의 CueConsiderationRate
  Q4 개인화 질의       같은 Signature, 다른 관계 유형의 사건 쌍 (전이 관측 단위)

재는 것
  정확도   주입한 정답 대비 precision / recall (Q1, Q4), 추적 완전성 (Q2), 값 일치 (Q3)
  비용     질의 시간, 구현 줄 수

합성 사건이다. 사용자에 대한 어떤 주장도 아니다.
결론은 "어느 구조가 이 네 질의에 필요한가"에 한정된다.
"""
from __future__ import annotations

import inspect
import io
import json
import math
import os
import random
import sqlite3
import time
from collections import Counter, defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
SEED = 20260913
N_EVENTS = 200
RELS = ['FRIEND_CLOSE', 'CLASSMATE', 'CLUB_SENIOR', 'SUPERVISOR', 'STRANGER', 'UNKNOWN']
SIG_WORDS = {
    'sig-A': '상대가 껄끄러운 말을 돌려서 했고 그걸 알아채야 하는 자리',
    'sig-B': '상대가 모르는 정보를 내가 이미 안다고 여기고 빠뜨린 자리',
    'sig-C': '상대가 화제를 바꾸는 신호를 놓치고 내 화제를 이어간 자리',
    'sig-D': '내 말이 다르게 전달됐는데 되돌리지 못한 자리',
    'sig-E': '요청인지 확인인지 갈리는 말을 들은 자리',
}
NOISE = ['동아리', '조별과제', '카톡', '점심', '회의', '알바', '수업', '단체방', '발표', '약속']


def make_events(rng):
    """정답을 알고 있는 합성 사건. 반복 패턴은 sig-A 와 sig-C 에 주입한다."""
    # 반복 패턴은 A 와 C 둘에만 주입한다. B, D, E 는 3회 미만이어야 Q1 정답이 {A, C} 가 된다.
    # 나머지는 한 번씩만 나오는 고유 Signature 로 채운다 (표면 문장만 있고 라벨은 고유).
    plan = ['sig-A'] * 60 + ['sig-C'] * 40 + ['sig-B'] * 2 + ['sig-D'] * 2 + ['sig-E'] * 1
    for k in range(N_EVENTS - len(plan)):
        uid = 'sig-U%03d' % k
        SIG_WORDS[uid] = rng.choice(list(SIG_WORDS.values())[:5]) + ' ' + rng.choice(NOISE)
        plan.append(uid)
    rng.shuffle(plan)
    t0 = 1757000000
    events = []
    for i, sig in enumerate(plan):
        surf = SIG_WORDS[sig].split()
        surf.insert(rng.randrange(len(surf)), rng.choice(NOISE))
        surf.insert(rng.randrange(len(surf)), rng.choice(NOISE))
        if len(surf) > 4:
            surf.pop(rng.randrange(len(surf)))
        events.append({
            'event_id': 'E%03d' % i,
            'timestamp': t0 + i * 86400 * rng.choice([1, 1, 2, 3]),
            'signature': sig,
            'invariant_sentence': ' '.join(surf),
            'relationship_type': rng.choice(RELS),
            'cue_considered': rng.random() < (0.3 if sig == 'sig-A' else 0.6),
        })
    events.sort(key=lambda e: e['timestamp'])
    return events


def _rate(sub):
    return round(sum(1 for e in sub if e['cue_considered']) / len(sub), 4)


def _pairs_by_rel(groups):
    out = set()
    for key, rels in groups.items():
        k = sorted(rels)
        for i in range(len(k)):
            for j in range(i + 1, len(k)):
                out.add((key, k[i], k[j]))
    return out


def truth(events):
    by_sig = defaultdict(list)
    for e in events:
        by_sig[e['signature']].append(e)
    groups = {s: {e['relationship_type'] for e in v} for s, v in by_sig.items()}
    ordered = sorted(events, key=lambda e: e['timestamp'])
    return {
        'q1': {s for s, v in by_sig.items() if len(v) >= 3},
        'q2': {s: sorted(e['event_id'] for e in v) for s, v in by_sig.items()},
        'q3': (_rate(ordered[-8:]), _rate(ordered[-16:-8])),
        'q4': _pairs_by_rel(groups),
    }


class Flat(object):
    name = 'FLAT'

    def __init__(self, events):
        self.ev = list(events)

    def q1(self):
        c = Counter(e['signature'] for e in self.ev)
        return {s for s, n in c.items() if n >= 3}

    def q2(self, sig):
        return sorted(e['event_id'] for e in self.ev if e['signature'] == sig)

    def q3(self):
        o = sorted(self.ev, key=lambda e: e['timestamp'])
        return (_rate(o[-8:]), _rate(o[-16:-8]))

    def q4(self):
        groups = defaultdict(set)
        for e in self.ev:
            groups[e['signature']].add(e['relationship_type'])
        return _pairs_by_rel(groups)


class Sql(object):
    name = 'SQL'

    def __init__(self, events):
        self.db = sqlite3.connect(':memory:')
        c = self.db.cursor()
        c.execute('create table ev(id text, ts int, sig text, rel text, cue int)')
        c.executemany('insert into ev values(?,?,?,?,?)',
                      [(e['event_id'], e['timestamp'], e['signature'],
                        e['relationship_type'], 1 if e['cue_considered'] else 0) for e in events])
        c.execute('create index i_sig on ev(sig)')
        c.execute('create index i_ts on ev(ts)')
        self.db.commit()

    def q1(self):
        return {r[0] for r in self.db.execute(
            'select sig from ev group by sig having count(*)>=3')}

    def q2(self, sig):
        return sorted(r[0] for r in self.db.execute('select id from ev where sig=?', (sig,)))

    def q3(self):
        rows = [r[0] for r in self.db.execute('select cue from ev order by ts desc limit 16')]
        rec, pri = rows[:8], rows[8:16]
        return (round(sum(rec) / len(rec), 4), round(sum(pri) / len(pri), 4))

    def q4(self):
        return {(r[0], r[1], r[2]) for r in self.db.execute(
            'select a.sig, a.rel, b.rel from (select distinct sig, rel from ev) a '
            'join (select distinct sig, rel from ev) b on a.sig=b.sig and a.rel<b.rel')}


class Vector(object):
    """불변항 문장의 bag-of-words 코사인. Signature 라벨을 쓰지 않고 문장만 쓴다.

    라벨이 저장돼 있으면 그것은 이미 그래프다. 벡터 메모리의 현실적 조건은 라벨 없음이다."""
    name = 'VECTOR'

    def __init__(self, events, sim_threshold=0.5):
        self.ev = list(events)
        self.th = sim_threshold
        self.vec = [Counter(e['invariant_sentence'].split()) for e in self.ev]
        self.cluster = self._cluster()

    @staticmethod
    def _cos(a, b):
        num = sum(a[k] * b.get(k, 0) for k in a)
        den = math.sqrt(sum(v * v for v in a.values())) * math.sqrt(sum(v * v for v in b.values()))
        return num / den if den else 0.0

    def _cluster(self):
        n = len(self.ev)
        parent = list(range(n))

        def find(x):
            while parent[x] != x:
                parent[x] = parent[parent[x]]
                x = parent[x]
            return x
        for i in range(n):
            for j in range(i + 1, n):
                if self._cos(self.vec[i], self.vec[j]) >= self.th:
                    parent[find(i)] = find(j)
        return [find(i) for i in range(n)]

    def _label(self, cid):
        # 평가용으로만 군집에 다수 Signature 이름을 붙인다. 시스템 자체는 이 라벨을 모른다
        members = [self.ev[i] for i in range(len(self.ev)) if self.cluster[i] == cid]
        return Counter(e['signature'] for e in members).most_common(1)[0][0]

    def q1(self):
        c = Counter(self.cluster)
        return {self._label(cid) for cid, n in c.items() if n >= 3}

    def q2(self, sig):
        q = Counter(SIG_WORDS[sig].split())
        return sorted(self.ev[i]['event_id'] for i in range(len(self.ev))
                      if self._cos(q, self.vec[i]) >= self.th)

    def q3(self):
        return Flat(self.ev).q3()

    def q4(self):
        groups = defaultdict(set)
        for i, e in enumerate(self.ev):
            groups[self._label(self.cluster[i])].add(e['relationship_type'])
        return _pairs_by_rel(groups)


class Graph(object):
    """dict 기반 개인 KG. 노드는 event / signature / relationship. 간선은 HAS_SIG / WITH."""
    name = 'KG'

    def __init__(self, events):
        self.ev = {e['event_id']: e for e in events}
        self.out = defaultdict(set)
        self.inn = defaultdict(set)
        for e in events:
            self._add(e['event_id'], 'HAS_SIG', 'sig:' + e['signature'])
            self._add(e['event_id'], 'WITH', 'rel:' + e['relationship_type'])

    def _add(self, a, edge, b):
        self.out[a].add((edge, b))
        self.inn[b].add((edge, a))

    def _events_of(self, node):
        return [a for _, a in self.inn[node]]

    def q1(self):
        return {n[4:] for n in self.inn if n.startswith('sig:') and len(self.inn[n]) >= 3}

    def q2(self, sig):
        return sorted(self._events_of('sig:' + sig))

    def q3(self):
        return Flat(list(self.ev.values())).q3()

    def q4(self):
        groups = defaultdict(set)
        for n in [x for x in self.inn if x.startswith('sig:')]:
            for eid in self._events_of(n):
                for edge, b in self.out[eid]:
                    if edge == 'WITH':
                        groups[n[4:]].add(b[4:])
        return _pairs_by_rel(groups)


def pr(pred, gold):
    pred, gold = set(pred), set(gold)
    tp = len(pred & gold)
    p = tp / len(pred) if pred else (1.0 if not gold else 0.0)
    r = tp / len(gold) if gold else 1.0
    return round(p, 3), round(r, 3)


def timed(fn, *a):
    t = time.perf_counter()
    out = fn(*a)
    return out, round((time.perf_counter() - t) * 1000, 3)


def loc(cls):
    src = inspect.getsource(cls)
    return sum(1 for ln in src.split(chr(10)) if ln.strip() and not ln.strip().startswith('#'))


def run():
    rng = random.Random(SEED)
    events = make_events(rng)
    gold = truth(events)
    report = {'seed': SEED, 'n_events': len(events),
              'gold': {'q1': sorted(gold['q1']), 'q3': list(gold['q3']), 'q4_n': len(gold['q4'])},
              'backends': {}}
    for cls in (Flat, Sql, Vector, Graph):
        t_build = time.perf_counter()
        be = cls(events)
        r = {'build_ms': round((time.perf_counter() - t_build) * 1000, 3), 'lines_of_code': loc(cls)}
        q1, ms = timed(be.q1)
        r['q1_repeated_pattern'] = {'precision_recall': list(pr(q1, gold['q1'])), 'ms': ms}
        comp, ms_total = [], 0.0
        for sig, ids in gold['q2'].items():
            got, ms = timed(be.q2, sig)
            ms_total += ms
            comp.append(pr(got, ids))
        r['q2_trace'] = {'mean_precision': round(sum(c[0] for c in comp) / len(comp), 3),
                         'mean_recall': round(sum(c[1] for c in comp) / len(comp), 3),
                         'ms': round(ms_total, 3)}
        q3, ms = timed(be.q3)
        r['q3_temporal'] = {'match': tuple(q3) == tuple(gold['q3']), 'value': list(q3), 'ms': ms}
        q4, ms = timed(be.q4)
        r['q4_personalization'] = {'precision_recall': list(pr(q4, gold['q4'])), 'n': len(q4), 'ms': ms}
        report['backends'][cls.name] = r
    report['reading'] = [
        'FLAT, SQL, KG 는 Signature 라벨을 저장하므로 네 질의를 전부 정확히 낸다. 차이는 비용과 코드 양이다',
        'VECTOR 는 라벨 없이 문장 유사도로 군집하므로 Q1, Q2, Q4 정확도가 유사도 문턱에 좌우된다. '
        '이것이 "라벨을 저장하지 않는 벡터 메모리"의 현실적 조건이다',
        'KG 가 이기는 질의는 없다. 이 네 질의에서 SQL 과 같은 답을 같은 자릿수 시간에 낸다',
        'POC 수준에서 개인 KG 의 필요성은 이 네 질의로는 정당화되지 않는다. '
        '정당화되려면 다중 홉 질의(사건 - 해석 - 전략 - outcome 경로 추적)가 실제로 필요해야 한다',
        '합성 사건이다. 사용자 데이터에 대한 어떤 주장도 아니다',
    ]
    outdir = os.path.join(HERE, 'results')
    os.makedirs(outdir, exist_ok=True)
    io.open(os.path.join(outdir, 'kg_ablation.json'), 'w', encoding='utf-8').write(
        json.dumps(report, ensure_ascii=False, indent=2))
    return report


if __name__ == '__main__':
    rep = run()
    print('사건', rep['n_events'], '/ 정답 반복 패턴', rep['gold']['q1'], '/ Q4 정답 쌍', rep['gold']['q4_n'])
    print('%-8s %-5s %-12s %-16s %-9s %-12s %s' % (
        'backend', 'LOC', 'Q1 P/R', 'Q2 P/R(mean)', 'Q3', 'Q4 P/R', 'ms total'))
    for name, r in rep['backends'].items():
        ms = (r['q1_repeated_pattern']['ms'] + r['q2_trace']['ms']
              + r['q3_temporal']['ms'] + r['q4_personalization']['ms'])
        print('%-8s %-5d %-12s %-16s %-9s %-12s %.2f' % (
            name, r['lines_of_code'],
            '%s/%s' % tuple(r['q1_repeated_pattern']['precision_recall']),
            '%s/%s' % (r['q2_trace']['mean_precision'], r['q2_trace']['mean_recall']),
            'ok' if r['q3_temporal']['match'] else 'MISMATCH',
            '%s/%s' % tuple(r['q4_personalization']['precision_recall']), ms))
    print()
    for line in rep['reading']:
        print('-', line)
