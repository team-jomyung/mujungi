# PERSONAL EVENT PIPELINE

2026-09-13 · 실제 대화가 Personal Social Event 가 되어 개인 패턴까지 가는 경로를 **단계별로 분해**한다.
각 단계에 **누가 값을 만드는가**(RULE / USER / LLM / HYBRID / HUMAN)와
**그 값이 어떤 상태인가**(Observed / Inferred / User-confirmed / Validated)를 붙인다.

기계가 읽는 표는 `../03_AUTOMATION/PIPELINE_AUTOMATION_MATRIX.csv`. 이 문서는 그 표의 해설이다.

---

## 0 · 네 가지 상태 · 모델 추론을 사실로 저장하지 않는다

| 상태 | 뜻 | 누가 만드나 | 예 |
|---|---|---|---|
| **Observed** | 사용자가 직접 쓴 것. 해석 없음 | USER | 붙여넣은 대화 원문, 고른 턴 |
| **Inferred** | 규칙이나 모델이 추정한 것. **사실이 아니다** | RULE · LLM | situation_type 추정, required_inference 추출 |
| **User-confirmed** | 추정을 사용자가 되돌려 확인한 것 | USER (확인) | 관계 유형, 하려던 일, 불변항 한 문장 |
| **Validated** | 외부 검증을 거친 것 | HUMAN · 후속 outcome | A1 gold 와 대조된 판정, outcome 이 들어온 해석 |

**규칙 셋.**

1. Inferred 는 화면에 **"이렇게 읽힐 수도"** 로만 나간다. "상대는 ~라는 뜻이었다"는 금지 (clarification_rules.json `partner_intent: NEVER_ASK`)
2. **상대의 의도는 어떤 상태로도 사실이 되지 않는다.** `attribution.is_fact` 가 스키마에서 `const: false` 다. outcome 이 들어와도 "어느 해석이 맞았는지의 증거"일 뿐이다
3. **해석은 복수로 유지한다.** `ontology_attributions.interpretation` 이 배열이고 하나로 승격하는 코드 경로가 없다

---

## 1 · 단계 분해

| # | 단계 | 값을 만드는 주체 | 상태 | 기대 오류 | ground truth | 보류(abstention) | 확신 | provenance |
|---|---|---|---|---|---|---|---|---|
| 1 | raw text | USER | Observed | 오타 · 요약해서 씀 · 순서 뒤섞임 | 없음. 원문이 기준 | 해당 없음 | 해당 없음 | `created_by: USER` |
| 2 | PII 치환 | RULE (10규칙) + USER (화면 7 확인) | Observed → sanitized | **호칭 없는 이름 · 영문 이름은 못 잡는다**(LIMIT 4건). 소속어 과잉 삭제(ACCEPT 6건) | 시험 87건의 기대 분류 | 규칙이 못 잡으면 사용자가 지운다 | 없음 | `redaction_log` · 원문 조각은 남기지 않음 |
| 3 | speaker separation | RULE (`extractTurns`) + USER 수정 | Observed | 한 줄에 두 화자 · 인용문을 발화로 오인 | 사용자 수정값 | 자동 분리 실패 시 전체를 한 턴으로 | 없음 | `rule_extraction` |
| 4 | difficult turn selection | **USER** | Observed | 사용자가 "딱 집기 어려움" 선택 | 없음. 사용자 선택이 정의 | **"딱 집기 어려움" → 대화 전체.** 다시 묻지 않음 | 없음 | `user_input` |
| 5 | relationship_type | USER (되돌려 확인 1) · 시스템 추론값 미리 선택 | **User-confirmed** | 추론 오선택을 그대로 승인 | 24~72h 재질문 일치 여부 | UNKNOWN 정당. 수행축·거리 미결 | 없음 | `confirmed_fields: [relationship_type]` |
| 6 | context (preceding · situation_type · place) | LLM/RULE 추론 → USER 확인 | Inferred → User-confirmed (situation_type) | 장소 오추정 | 없음 | preceding 은 한 번만 묻고 null 허용 | 없음 | `model_inference` 또는 `model_then_human` |
| 7 | user_goal_claim | USER (되돌려 확인 2 · 필수 질문 · nullable) | **User-confirmed (주장)** | 회상 오류 · 사후 합리화 | 24~72h 재질문 일치 | **UNKNOWN 정당. 어느 축도 막지 않음** | 없음 | `goal_bearer: USER` |
| 8 | blocked_at → target_skill | USER 선택 → RULE 매핑 | User-confirmed → 결정적 | 사용자가 막힌 지점을 잘못 고름 | A1 gold 의 target_skill | UNKNOWN → Skill Identity UNDETERMINED | 없음 | `rule_extraction` |
| 9 | SpeechAct · Cue · PragmaticPhenomenon | **LLM** | **Inferred** | 비꼼·간접성으로 쏠림(한국어 자료 편향). 단서 과잉 지목 | A1 에서는 직접 채점하지 않음. **Supporting 필드** | 근거 구간 없으면 빈 배열 | 모델 확신 · 사용자에게 안 보임 | `model_inference` · `evidence_turn_ids` 필수 |
| 10 | Interpretation candidates | **LLM** | **Inferred · 복수 · 영구히 사실 아님** | 하나로 수렴 · 상대 의도 확정 문장 | outcome 이 증거가 되지만 사실은 아님 | 후보 0개 허용 | 없음 | `is_fact: false` |
| 11 | required_inference | **LLM** → HUMAN 검수 | Inferred → Validated (A1 대조) | **가장 어려운 필드.** 판정기 성능 미측정 | **A1 gold** | UNKNOWN → UNDETERMINED | A2 라우팅 입력 | `model_then_human` |
| 12 | perspective_structure | **LLM** → HUMAN 검수 | Inferred → Validated | 겹 수 과대 추정 | **A1 gold** | UNKNOWN → UNDETERMINED | A2 라우팅 입력 | `model_then_human` |
| 13 | decidable_by_evidence | **LLM** → HUMAN 검수 | Inferred → Validated | **어느 자료로도 안 덮이는 필드.** 규격이 정의했고 데이터가 없다 | **A1 gold** | UNKNOWN → UNDETERMINED | A2 라우팅 입력 | `model_then_human` |
| 14 | direct_check_allowed | **USER** (그 자리에서 물어볼 수 있었나) + LLM 제안 · **관계에서 자동으로 채우지 않는다** | User-confirmed 또는 Inferred | 관계만으로 정하면 규범적 이분법 (`02_SCOPE/RELATIONSHIP_SCOPE.md`) | A1 gold | UNKNOWN → 수행축 미결 | A2 라우팅 입력 | `user_input` 또는 `model_inference` |
| 15 | Strategy | LLM 제안 → USER 선택 | Inferred → User-confirmed | 관계에 안 맞는 전략 제안 | 없음 | 제안 0개 허용 | 없음 | `recommended_for_role` |
| 16 | Outcome | USER (후속 · 한 번 · 거절 가능) | Observed (자기보고) | 자기보고 편향 | 없음. **상대 의도의 진실로 해석하지 않음** | DECLINED → 다시 묻지 않음 | 없음 | `outcome.followup` |
| 17 | Signature (불변항 한 문장) | LLM → **USER 확인** (화면 6) | Inferred → **User-confirmed** | 전문용어 누출 · 사용자가 못 알아듣는 문장 | 사용자 "맞아요" | "좀 달라요" → 사용자가 고쳐 씀 | 없음 | `model_then_human` |
| 18 | Skill Identity | **RULE** (순수 함수 · Core 4/5 비교) | 결정적 | 입력 필드 오류가 전파됨 | A1 gold 라벨 | Core 중 UNKNOWN → UNDETERMINED | 없음 | `derived` |
| 19 | Transfer Distance | **RULE** (순수 함수 · 변화 7종) | 결정적 | 같음 | A1 gold 라벨 | 관계·상황유형 UNKNOWN → UNDETERMINED | 없음 | `derived` |
| 20 | Personal pattern update | **RULE** (`personal_pattern.aggregate`) | 파생 집계 · 사건 참조 | 분모 부족을 무시하면 우연이 패턴이 됨 | 없음 | `reportable=false` 면 화면에 안 냄 | 없음 | 모든 값에 `event_ids` |

---

## 2 · 이 표에서 읽어야 하는 것

**LLM 이 값을 만드는 단계는 20개 중 8개**(9 · 10 · 11 · 12 · 13 · 14 · 15 · 17)이고,
그중 **판정에 들어가는 것은 넷**(11 · 12 · 13 · 14)이다. 14 는 사용자가 답하면 사용자 값이 우선한다. 나머지 넷은 Supporting 이거나 사용자가 확인한다.

**사용자가 직접 만드는 값이 셋**(1 · 4 · 7)이고 **확인하는 값이 넷**(5 · 6 · 8 · 17)이다.
이 일곱을 빼면 개인 사건이 성립하지 않는다. **그래서 개인 사건은 자동으로 만들 수 없다.**

**규칙이 결정적으로 만드는 값이 넷**(2 · 8 · 18 · 19)이고 **집계가 하나**(20)다. 14 는 예전에 여기 있었다가 빠졌다.
이것들은 LLM 정확도 숫자에 섞으면 안 된다.

**Validated 상태에 도달하는 필드는 넷뿐**(11 · 12 · 13 · 14)이고 **그것도 A1 gold 가 있을 때만**이다.
지금은 A1 gold 가 0건이므로 **이 파이프라인에서 Validated 인 값은 하나도 없다.**

---

## 3 · 어디서 사람이 필요한가

| 시점 | 사람 | 왜 |
|---|---|---|
| 초기 보정 | A1 판정자 2명 | 11 · 12 · 13 의 gold. 이것이 없으면 A2 판정기의 기준이 없다 |
| 초기 보정 | blind 선별자 1명 | 후보 적격성. 규격 작성자는 못 한다 |
| 운영 | **사용자 본인** | 1 · 4 · 5 · 7 · 8 · 17. 이건 "사람이 필요하다"가 아니라 **사용자의 일이 곧 데이터**다 |
| 운영 | 검토자 (라우팅) | A2 확신 낮은 건과 주기 표본. **비율은 A2 를 돌려야 안다** |
| 운영 | 아무도 아님 | 2(치환) · 18 · 19 · 20 |

**"사람은 초기 보정에만 필요한가"** · 아니다. 셋으로 갈린다.
① gold 만드는 사람은 초기에만 ② 라우팅 검토자는 운영에도 ③ 사용자 본인은 항상.
그리고 ②의 비율은 지금 숫자로 말할 수 없다.

---

## 4 · 자동 탐지가 사용자 선택을 대체하지 않는 곳

`difficult_turn_ids` 는 스키마에 "자동 탐지는 보조일 뿐 대체하지 않는다"고 적혀 있다.
이유 · **어려웠던 자리를 정하는 것이 곧 무엇을 연습할지 정하는 것**이고, 그것을 모델이 정하면
사용자가 겪지 않은 어려움을 연습시키게 된다.

같은 이유로 `user_goal_claim` 도 묻는다. 추론하면 목표를 모델이 정하게 된다.
D2 (goal 을 묻지 않으면 무엇이 손실되는가)는 `PERSONAL_PATTERN_SPEC.md` §4 에 적었다.
