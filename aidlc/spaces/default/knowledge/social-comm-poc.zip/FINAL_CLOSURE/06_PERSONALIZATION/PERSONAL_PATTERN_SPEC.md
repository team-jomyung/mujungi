# PERSONAL PATTERN SPEC

2026-09-13 · `03_POC_C/personal_pattern.py` (frozen spec §8.2 구현)를 **계산식과 최소 분모까지** 문서로 옮기고,
temporal 모델(Q 워크스트림)과 goal 검토(D2)를 붙인다.

**Trait 라벨을 만들지 않는다.** 모든 값은 사건 참조 집계고, 사건을 지우면 값이 줄어든다.

```
금지   UserA → cannot_understand → indirect_refusal
허용   최근 8개 관련 사건에서 단서 노출 5회 · 고려 2회 · 명료화 1회
```

---

## 1 · 지표 아홉 · 계산식 · 최소 분모

| 지표 | 계산식 | 분모 | 최소 분모 | 사용자에게 보임 | 추천에 씀 | 근거 상태 |
|---|---|---|---|---|---|---|
| **ExposureCount** | 같은 Signature 를 가진 사건 수 · `len(events[sig])` | 해당 없음 | 1 | 예 | 예 | 정의 |
| **CueConsiderationRate** | 단서를 언급한 사건 ÷ 그 단서가 있던 사건 · `considered / has_cue` | `cue_considered is not None` 인 사건 | **3** | 예 | 예 | 운영 값 §8.2 |
| **InterpretationDiversity** | 사건당 해석 후보 수의 **중앙값** | `interpretations is not None` 인 사건 | **3** | 예 | 예 | 운영 값 |
| **ClarificationRate** | 명료화를 시도한 사건 ÷ 명료화가 필요했던 사건 · `did / needed` | `clarification is not None` 인 사건 | **3** | 예 | 예 | 운영 값 |
| **StrategyDistribution** | 전략별 사건 수 `Counter(strategy)` | 전략이 기록된 사건 | **3** | 예 | 예 | 운영 값 |
| **RepeatedPatternCount** | 같은 Signature 가 **3회 이상** 나온 Signature 의 수 | 해당 없음 | Signature 당 3 | 예 | 예 | 운영 값 |
| **RecentTrend** | 최근 8건의 CueConsiderationRate − 그 이전 8건의 값 | 두 구간 각각 | **각 8 · 합 16** | **조건부.** 두 구간 다 8건 이상일 때만 | 예 | 운영 값 |
| **ConfidenceCalibration** | 확신 HIGH 였는데 outcome 이 어긋난 사건 ÷ 확신 HIGH + outcome 있는 사건 | `confidence==HIGH and outcome_match is not None` | **5** | **아니오.** "당신은 확신할 때 자주 틀린다"로 읽힘 | 예 | 운영 값 |
| **LastPracticed** | Signature 별 `max(last_practiced or timestamp)` | 해당 없음 | 1 | 예 | 예 | 정의 |

**분모를 항상 함께 돌려준다.** `_rate()` 가 `numerator · denominator · value · reportable · min_sample · event_ids` 를 한 묶음으로 낸다.
3건 중 2건과 30건 중 20건은 같은 0.67 이지만 다른 정보다.

**`reportable=false` 면 화면에 값을 내지 않는다.** 숫자 대신 "아직 사건이 적어요"를 낸다.

### 최소 분모의 근거

전부 **PROJECT OPERATING VALUE** 다. 문헌에서 가져온 숫자가 아니다.

| 값 | 왜 그 값인가 | 검증 |
|---|---|---|
| 3 | 2건이면 우연 일치와 구분이 안 된다는 판단 | **미검증.** POC C 파일럿에서 3건 이상 쌓이는 참가자가 있는지부터 봐야 한다 |
| 8 (구간) | 8 미만이면 비율 한 칸이 12.5%p 이상 움직인다 | **미검증** |
| 5 | 보정은 outcome 이 있어야 하므로 표본이 더 귀하다. 3 보다 높게 잡았다 | **미검증** |

---

## 2 · Temporal 모델 · 한 번의 실패를 고정 결손으로 만들지 않는다

### 2-1 · 사건 하나에 붙는 시간 정보

```
event
  timestamp            사건이 일어난(또는 입력된) 시각 · USER 또는 RULE
  signature            불변항 · User-confirmed
  skill (target_skill) · relationship_type · interpretation[] · strategy · outcome
  confidence           모델 추출 확신 · 사용자에게 안 보임
  provenance           누가 어떻게 만들었나 · 필드별
  last_practiced       이 Signature 를 마지막으로 연습한 시각 · RULE
```

**연결 규칙** · 사건은 Signature 로 묶인다. 관계 유형으로도 묶인다. 두 축이 교차한다.
"같은 Signature · 다른 관계"가 곧 전이 관측의 단위다.

### 2-2 · 넷을 분리한다

| 개념 | 계산 | 무엇을 말하나 | 무엇을 말하지 않나 |
|---|---|---|---|
| **최근성** | `now - last_practiced[sig]` | 언제 마지막으로 다뤘나 | 잘하나 못하나 |
| **빈도** | `ExposureCount[sig]` 를 기간으로 나눈 값 | 얼마나 자주 겪나 | 어려움의 크기 |
| **반복성** | `RepeatedPatternCount` · 같은 Signature 3회 이상 | **같은 구조가 되풀이되는가** | 그 사람의 성격 |
| **추세** | `RecentTrend` · 최근 8 대 이전 8 | 방향 | 원인 |

**빈도와 반복성을 섞지 않는다.** 자주 겪는 것(빈도)은 그 사람의 환경이고,
같은 구조가 되풀이되는 것(반복성)이 연습 대상이다. 회사 다니는 사람은 SUPERVISOR 사건 빈도가 높을 뿐이다.

### 2-3 · 옛 기록이 현재를 고정하지 않게 하는 장치

| 장치 | 구현 | 상태 |
|---|---|---|
| **창(window)** | RecentTrend 는 최근 8건만 본다. 전체 평균을 내지 않는다 | 구현됨 |
| **사건 삭제 → 재계산** | `delete_event()` 가 남은 사건으로 `aggregate()` 를 다시 돌린다. 캐시 없음 | 구현됨 · 데모 확인 |
| **Trait 부재** | 저장 스키마에 사람 단위 라벨 필드가 없다. 집계는 매번 사건에서 계산된다 | 스키마 확인 |
| **가중 감쇠** | 오래된 사건에 낮은 가중을 두는 방식 | **넣지 않았다.** 감쇠율을 정할 근거가 없다. 창 방식이 더 설명하기 쉽다 |
| **행동 변화 후 리셋** | 사용자가 "요즘은 달라졌어요"를 표시하면 구간을 새로 시작 | **설계만.** 화면 없음. v0.2 후보 |

**감쇠를 넣지 않은 이유** · 감쇠율 λ 를 정하면 그 값이 곧 "얼마나 오래 기억하나"인데,
그걸 정할 근거가 없다. 창 방식은 "최근 8건"이라고 사용자에게 그대로 말할 수 있다.

---

## 3 · 사용자에게 보여 주는 문장의 형식

```
허용   "최근 여덟 번 중 상대가 돌려 말한 자리가 다섯 번 있었고, 그중 두 번 알아채셨어요."
허용   "이 종류의 상황을 세 번 겹쳐 적으셨어요."
금지   "간접 거절을 잘 못 알아채는 편이에요."
금지   "당신은 확신할 때 자주 틀려요."     ← ConfidenceCalibration 은 화면에 안 냄
금지   확신도 숫자
```

---

## 4 · D2 · user_goal 을 묻지 않으면 무엇이 손실되는가

현재 규격 · **필수 질문이지만 답은 nullable**. UNKNOWN 이 정당하고 어느 축도 막지 않는다.
"그렇다면 왜 묻나"에 답해야 한다.

### 4-1 · goal 이 없을 때 무너지는 것

| 지표 · 기능 | goal 필요? | 없으면 |
|---|---|---|
| Skill Identity · Transfer Distance | **아니오** | 영향 없음. 규격 §4.3 |
| ExposureCount · RepeatedPatternCount · LastPracticed | 아니오 | 영향 없음 |
| CueConsiderationRate · ClarificationRate | 아니오 | 영향 없음 |
| **Strategy 추천** | **부분** | "이 자리에서 뭘 하려 했나"를 모르면 전략 후보를 좁힐 수 없다. 전부 낸다 |
| **Outcome 해석** | **예** | "목표가 달성됐나"를 물을 수 없다. outcome 이 "어떻게 됐나"로만 남는다 |
| **PERFORM 지표 P1 응답성** | 부분 | 상대 요청에 대한 반응은 goal 없이도 채점되지만 **사용자 goal 대비 성공은** 못 잰다 |
| **개인별 목표척도(GAS 계열)** | **예** | 목표가 없으면 척도 자체가 성립하지 않는다 |

**손실은 판정이 아니라 개인화 쪽에 몰려 있다.** 그래서 필수 질문이면서 nullable 인 현재 설계가 맞다.
판정을 막지 않고 개인화만 줄어든다.

### 4-2 · goal 이 흔들리면

24~72h 재질문에서 goal 이 바뀌는 비율이 높으면 · **goal 기반 outcome 해석과 GAS 계열 지표를 쓸 수 없다.**
그 비율이 얼마인지는 POC C 가 잰다. **지금은 모른다.**

### 4-3 · 자유서술 / 범주 / 혼합

| 방식 | 장점 | 단점 | 우리 선택 |
|---|---|---|---|
| 범주만 | 24~72h 일치를 정량 비교 가능 | 사용자 목표가 보기에 없을 수 있다 | |
| 자유서술만 | 손실 없음 | 일치 비교가 안 된다. 억지 일치율을 내지 않는다는 규칙과 충돌 | |
| **혼합** | 범주로 비교하고 자유서술로 보존 | 화면이 한 단계 길어진다 | **현재 구현.** `value` (enum 7 + UNKNOWN) + `free_text` + `asked` |

**문헌 근거는 `02_SCOPE/_agent_pragmatics_review.md` §4 (Q-D2)** 에 정리된다.
GAS 계열이 목표를 어떻게 받는지가 참조점이다. 그 결과가 혼합을 뒤집으면 여기를 고친다.

---

## 5 · 종단 · 무엇을 아직 안 정했나

| 항목 | 상태 |
|---|---|
| 재측정 간격 | **NOT ESTABLISHED.** Adams 2015 가 6개월을 썼으나 N=1 |
| 사건 몇 건이 "종단"인가 | **NOT ESTABLISHED** |
| 추세가 "향상"인가 | **아니다.** RecentTrend 는 CueConsiderationRate 의 차이일 뿐이고 과제 수준 지표다. 임상 호전과 무관 |

측정 설계는 `../05_PERFORMANCE/LONGITUDINAL_PROTOCOL.md`.
