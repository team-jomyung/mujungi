# POC C AUDIT

2026-09-13 · L 워크스트림. `03_POC_C/` 를 실제 파일 기준으로 감사한다. 무엇이 있고 무엇이 없는지.

---

## 0 · 감사 대상

```
03_POC_C/
  intake_prototype.html          9화면 입력 시험판 · PII 규칙 10개 · 저장 경로 8곳
  intake_questions.md            화면 문구 · 온톨로지 용어 미노출
  clarification_rules.json       무엇을 묻고 무엇을 UNKNOWN 으로 두나 · §7
  personal_social_event.schema.json   Event Wrapper · x-source · x-nullable
  personal_pattern.py            §8.2 집계 · MIN_SAMPLE · delete_event
  followup_24_72h.md             재질문 화면 · 비교 방법
  pilot_protocol.md · consent_draft.md · participant_instruction.md
  privacy_test.html · privacy_test_cases.json · PRIVACY_TEST_RESULT.md   87건
  make_synthetic_events.py · synthetic_events.* · synthetic_followups.csv · analyze_pilot.py
  retention_deletion_policy_draft.md
```

---

## 1 · L1 · Intake burden 지표

| 지표 | 정의 | 어디서 재나 | 지금 상태 |
|---|---|---|---|
| **completion_time** | 화면 1 진입부터 화면 7 저장까지 | 클라이언트 타임스탬프 두 개 | **미구현.** 시험판에 타이머 없음. 추가할 자리 · 화면 1 진입 시각과 저장 시각을 이벤트에 기록 |
| **clarification_count** | 시스템이 되물은 횟수 (화면 3 · 4 · 6 의 "좀 달라요" 포함) | 클릭 로그 | **미구현.** `clarification_rules.json` 이 `max_asks` 를 정하지만 실제 횟수를 세는 코드 없음 |
| **correction_rate** | 추론값을 사용자가 바꾼 비율 (화면 3 관계 · 화면 6 불변항) | 미리 선택값 ≠ 최종값 | **미구현.** `confirmed_fields` 만 저장되고 원 추론값이 안 남는다 |
| **UNKNOWN_rate** | 관계 · 목표 · 막힌 지점에서 UNKNOWN 을 고른 비율 | 저장된 이벤트 | **계산 가능.** `analyze_pilot.py` 가 합성 이벤트에서 낸다. 실측 0 |
| **dropout** | 화면 N 에서 멈춘 비율 | 화면별 진입 로그 | **미구현** |
| **privacy_warning_rate** | 화면 7 에서 규칙 치환이 1건 이상 있었던 비율 · 사용자가 추가로 지운 비율 | `redaction_log` · 화면 7 편집 diff | **부분.** `redaction_log` 는 저장됨. 사용자 편집 diff 는 저장 안 됨(원문 미보관 원칙과 충돌 없이 "편집 있었음" 불리언만 남기면 된다) |

**여섯 중 실측 가능한 것은 하나(UNKNOWN_rate)뿐이다.** 나머지 다섯은 기록 필드가 없다.
이건 설계 결함이라기보다 **시험판이 저장 최소화 원칙에 맞춰 만들어져서** 로그를 안 남기는 것이다.

### 고쳐야 할 것 · 파일럿 전에

`personal_social_event.schema.json` 에 **개인정보가 아닌 운영 메타** 블록을 하나 추가하면 된다.
새 온톨로지 클래스가 아니라 wrapper 필드다.

```
intake_meta (신설 · wrapper · x-source RULE)
  started_at · saved_at                    → completion_time
  asks: {relationship: n, goal: n, invariant: n}   → clarification_count
  changed: {relationship: bool, invariant: bool}   → correction_rate (원 추론값은 저장하지 않음)
  last_screen_reached                      → dropout
  redaction_count · user_edited_at_screen7: bool   → privacy_warning_rate
```

**원 추론값을 저장하지 않는 이유** · 추론값은 상대에 대한 모델의 추정이고 그것을 남기면
"모델은 SUPERVISOR 로 봤는데 사용자가 FRIEND 로 고쳤다"가 기록으로 남는다. 바뀌었다는 불리언만 남긴다.

이 변경은 **frozen spec 을 건드리지 않는다.** wrapper 의 운영 메타이고 §6 의 최소 수집 계약(필수 값 셋 · 필수 질문 하나)에 더하는 것이 없다.
다만 RC1 을 다시 빌드해야 하므로 **SPEC_V0_2_CANDIDATES.md 의 C-05** 로 적고, 파일럿 직전에 넣는다.

---

## 2 · L2 · 24~72h 일관성

| 항목 | 규격 | 구현 | 판정 |
|---|---|---|---|
| 시점 | 24~72시간 | `followup_24_72h.md` 명시 | 문서 있음 · **자동 발송 없음.** 운영자가 수동으로 보낸다 |
| 횟수 | 사건당 1회 | 문서 명시 | 코드 강제 없음 |
| 원 답 비노출 | 처음 답을 보여주지 않음 | 화면 문구에 명시 · 미리 선택 없음 | **맞다** |
| 묻는 것 | 관계 · 목표 둘만 | 화면 2문항 | **맞다** |
| 비교 | 선택지 기반 일치/불일치 · UNKNOWN→UNKNOWN 은 일치 | 문서 명시 · `analyze_pilot.py` 구현 | **맞다** |
| 자유서술 비교 | 정량 비교 안 함 | 문서 명시 | **맞다.** 억지 일치율을 내지 않는다는 원칙 |

**빠진 것 하나** · 재질문 **시각**이 사건에 기록되는 자리가 `outcome.followup.asked_at` 에는 있는데
**일관성 재질문용 필드가 따로 없다.** outcome 후속과 일관성 재질문은 다른 화면이고 다른 목적이므로
`consistency_recheck: {asked_at, relationship_type, user_goal_claim}` 을 wrapper 에 둬야 한다. **C-06.**

---

## 3 · L3 · Outcome follow-up

| 항목 | 규격 | 구현 |
|---|---|---|
| 묻는 것 | what happened next · did you clarify · did partner respond · was goal achieved | 화면 보기 5개 (일정 어려웠다 · 거절이었다 · 다른 이유 · 아직 모름 · 기록 안 함) |
| 저장 | event evidence 로. 상대 의도의 진실로 해석 안 함 | `outcome.status` enum + `followup.answer` · `attribution.is_fact=false` |
| 거절 | DECLINED → 재질문 없음 | enum 에 DECLINED 있음 · 재질문 차단 코드 없음 |

**어긋남 하나** · 규격의 네 질문(clarify · partner respond · goal achieved)이 화면 보기 5개에 **다 들어 있지 않다.**
현재 보기는 "어느 해석이 맞았나" 쪽으로만 짜여 있다. `did you clarify` 와 `did the partner respond` 가 없다.
이 둘은 **ClarificationRate 의 분자**이므로 없으면 그 지표의 outcome 연결이 끊긴다.

→ 보기를 두 단계로. ① 어떻게 됐나(현재 5개) ② 그 뒤에 확인해 봤나 (예 / 아니오 / 기록 안 함). **C-07.**

---

## 4 · L4 · Personalization pattern

`PERSONAL_PATTERN_SPEC.md` 에 계산식 · 최소 분모 · 근거 상태를 적었다. 여기서는 감사 결과만.

| 항목 | 판정 |
|---|---|
| Trait 라벨 금지 | **지킴.** 스키마에 사람 단위 라벨 필드 없음 · 집계는 매번 사건에서 계산 |
| event-referenced aggregate | **지킴.** 모든 값에 `event_ids` |
| 최소 분모 | **있음.** 3 / 8 / 5. 전부 운영 값 |
| 사건 삭제 → 재계산 | **동작 확인.** `delete_event` 데모 |
| 계산식 문서화 | 이번에 `PERSONAL_PATTERN_SPEC.md` §1 |
| 근거 없으면 exploratory 표시 | **부분.** 코드의 `caution` 문구는 RecentTrend 에만 있다. 나머지 지표에도 `basis: PROJECT_OPERATING_VALUE` 를 출력에 넣어야 한다. **C-08** |

---

## 5 · 개인정보 시험 · 재확인

`PRIVACY_TEST_RESULT.md` · 87건 · PASS 74 · DEFECT 3 · ACCEPT 6 · LIMIT 4 · STALE 0.
**"87건이 각자 기대한 분류와 맞았다"** 이상으로 말하지 않는다.

DEFECT 3건(I-06 날짜/학번 · I-07 유선전화 · I-08 외국인등록번호)은 **정책 결정**이라 여기서 고치지 않는다.
LIMIT 4건(호칭 없는 이름 · 영문 이름)은 정규식으로 못 하고 **화면 7 이 유일한 방어**다.

---

## 6 · 이 감사에서 나온 v0.2 후보

| ID | 무엇 | 왜 | 종류 |
|---|---|---|---|
| C-05 | `intake_meta` wrapper 블록 (시각 · 되물음 수 · 변경 불리언 · 마지막 화면 · 치환 수) | L1 지표 여섯 중 다섯이 측정 불가 | wrapper 운영 메타 |
| C-06 | `consistency_recheck` 필드 | 일관성 재질문 시각과 답이 저장될 자리가 없다 | wrapper |
| C-07 | outcome 보기 2단계 (어떻게 됐나 → 확인해 봤나) | ClarificationRate 의 outcome 연결이 끊겨 있다 | 화면 |
| C-08 | 집계 출력에 `basis` 필드 | 운영 값을 근거 있는 값처럼 읽지 않게 | 출력 |

넷 다 **frozen spec 본문(§1~§11 판정 규칙)을 건드리지 않는다.** wrapper 와 화면이다.
전체 목록은 `../02_SCOPE/SPEC_V0_2_CANDIDATES.md`.

---

## 7 · 참가자 0명에서 지금 할 수 있는 것과 없는 것

| 할 수 있다 | 할 수 없다 |
|---|---|
| 합성 이벤트로 `analyze_pilot.py` 배선 확인 (했다) | intake burden 실측 |
| 화면 문구에서 온톨로지 용어 누출 검사 (했다 · 0건) | UNKNOWN 비율의 의미 해석 |
| 개인정보 규칙 87건 (했다) | 24~72h 일치율 |
| C-05~C-08 설계 (했다) | 3건 이상 쌓이는 참가자 비율 |
