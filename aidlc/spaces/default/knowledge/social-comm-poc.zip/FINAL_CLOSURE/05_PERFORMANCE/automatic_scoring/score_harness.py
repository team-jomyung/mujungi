# -*- coding: utf-8 -*-
"""I5 자동 채점 harness. 사람 rubric 점수를 gold 로 두고 세 방식을 비교한다.

    python score_harness.py --demo
    python score_harness.py --human <human_scores.csv> --responses <responses.csv>

세 방식
  RULE     어휘 표지 · 길이 · 구간 지목 유무 같은 규칙만
  LLM      rubric 을 프롬프트에 넣고 0/1/2/NA/UNKNOWN 을 받는다 (provider 자리)
  HYBRID   규칙이 확정할 수 있는 항목은 규칙 · 나머지는 LLM

지표 (서열 0/1/2 이므로 명목 κ 만 쓰지 않는다)
  exact agreement · adjacent agreement (|차| <= 1) · 선형 가중 κ · Spearman ρ · NA/UNKNOWN 일치

사람 점수 gold 는 평정자 2명의 합의다. 합의 전 점수로 자동 채점을 맞추지 않는다.
Echo 출력으로는 어떤 성능도 주장하지 않는다.
"""
from __future__ import annotations

import argparse
import csv
import io
import json
import os
import random
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
CODES = ('U1', 'U2', 'U3', 'U4', 'U5', 'P1', 'P2', 'P3', 'P4', 'P5')
ORDINAL = ('0', '1', '2')
SPECIAL = ('NA', 'UNKNOWN')


def load_rubric():
    rows = {}
    for name in ('UNDERSTAND_RUBRIC.csv', 'PERFORM_RUBRIC.csv'):
        p = os.path.join(HERE, '..', name)
        if os.path.exists(p):
            for r in csv.DictReader(io.open(p, encoding='utf-8-sig', newline='')):
                rows[r['code']] = r
    return rows


# ───────────────── 규칙 채점 · 확정할 수 있는 것만 ─────────────────

CLARIFY = re.compile(r'(무슨 뜻|다시 말|그러니까|~?라는 (거|말)(야|이야|인가|이에요)|확인|맞아\?|맞나요|이야\?|인가요)')
CERTAIN = re.compile(r'(확실히|분명히|틀림없이|사실은|진짜로 .*(거다|것이다))')
HEDGE = re.compile(r'(아마|같다|일 수도|~?듯|모르겠|어쩌면)')
QUOTE = re.compile(r'["“”\'‘’]')


def rule_score(code, response, task):
    """규칙이 확정할 수 있으면 값을, 아니면 None. None 은 LLM 으로 넘긴다."""
    text = response or ''
    if code == 'U1':
        # 근거 구간 지목 · 인용부호가 있고 그 안이 과제 원문에 있으면 2, 인용 없으면 규칙은 판단 안 함
        quoted = QUOTE.findall(text)
        if not quoted:
            return None
        spans = re.findall(r'["“‘\']([^"”’\']{3,})["”’\']', text)
        if spans and any(s in (task.get('source_text') or '') for s in spans):
            return '2'
        if spans:
            return '0'   # 원문에 없는 것을 근거로 댐
        return None
    if code == 'U3':
        if CERTAIN.search(text) and not HEDGE.search(text):
            return '0'
        return None
    if code == 'U4':
        if task.get('decidable_by_evidence') == 'YES':
            return 'NA'
        return None
    if code == 'P4':
        if task.get('breakdown_present') == 'NO':
            return 'NA'
        if not CLARIFY.search(text):
            return '0'
        return None
    if code == 'P5':
        if task.get('n_relationships', 1) < 2:
            return 'NA'
        return None
    return None


class EchoLLM(object):
    name = 'echo'

    def score(self, code, response, task, rubric_row):
        h = (sum(ord(c) for c in (response or '')) + sum(ord(c) for c in code)) % 100
        if h < 8:
            return 'UNKNOWN'
        return ORDINAL[h % 3]


def hybrid_score(code, response, task, rubric_row, llm):
    r = rule_score(code, response, task)
    return r if r is not None else llm.score(code, response, task, rubric_row)


# ───────────────── 지표 ─────────────────

def _ord(v):
    return int(v) if v in ORDINAL else None


def weighted_kappa(pairs):
    """선형 가중 κ · 서열 0/1/2 만. NA/UNKNOWN 은 뺀다."""
    p = [(_ord(a), _ord(b)) for a, b in pairs if _ord(a) is not None and _ord(b) is not None]
    n = len(p)
    if n < 2:
        return None
    k = 3
    obs = [[0] * k for _ in range(k)]
    for a, b in p:
        obs[a][b] += 1
    ra = [sum(obs[i]) / n for i in range(k)]
    rb = [sum(obs[i][j] for i in range(k)) / n for j in range(k)]
    w = lambda i, j: abs(i - j) / (k - 1)
    po = sum(w(i, j) * obs[i][j] / n for i in range(k) for j in range(k))
    pe = sum(w(i, j) * ra[i] * rb[j] for i in range(k) for j in range(k))
    return None if pe == 0 else round(1 - po / pe, 3)


def spearman(pairs):
    p = [(_ord(a), _ord(b)) for a, b in pairs if _ord(a) is not None and _ord(b) is not None]
    n = len(p)
    if n < 3:
        return None

    def rank(xs):
        order = sorted(range(len(xs)), key=lambda i: xs[i])
        r = [0.0] * len(xs)
        i = 0
        while i < len(xs):
            j = i
            while j + 1 < len(xs) and xs[order[j + 1]] == xs[order[i]]:
                j += 1
            avg = (i + j) / 2 + 1
            for t in range(i, j + 1):
                r[order[t]] = avg
            i = j + 1
        return r
    ra, rb = rank([a for a, _ in p]), rank([b for _, b in p])
    ma, mb = sum(ra) / n, sum(rb) / n
    num = sum((x - ma) * (y - mb) for x, y in zip(ra, rb))
    den = (sum((x - ma) ** 2 for x in ra) * sum((y - mb) ** 2 for y in rb)) ** 0.5
    return round(num / den, 3) if den else None


def metrics(pairs):
    n = len(pairs)
    ordinal = [(a, b) for a, b in pairs if a in ORDINAL and b in ORDINAL]
    special_gold = [(a, b) for a, b in pairs if a in SPECIAL]
    return {
        'n': n,
        'n_ordinal_both': len(ordinal),
        'exact_agreement': round(sum(1 for a, b in ordinal if a == b) / len(ordinal), 3) if ordinal else None,
        'adjacent_agreement': round(sum(1 for a, b in ordinal if abs(int(a) - int(b)) <= 1) / len(ordinal), 3) if ordinal else None,
        'weighted_kappa_linear': weighted_kappa(pairs),
        'spearman': spearman(pairs),
        'special_agreement': round(sum(1 for a, b in special_gold if a == b) / len(special_gold), 3) if special_gold else None,
        'special_n_gold': len(special_gold),
        'coverage_rule': None,
    }


def run(rows, llm):
    rubric = load_rubric()
    out = {'methods': {}, 'per_code': {}}
    by_method = {'RULE': [], 'LLM': [], 'HYBRID': []}
    rule_cov = 0
    per_code = {c: {'RULE': [], 'LLM': [], 'HYBRID': []} for c in CODES}
    for r in rows:
        code, gold = r['code'], r['human_score']
        task = {'source_text': r.get('source_text', ''), 'decidable_by_evidence': r.get('decidable_by_evidence', ''),
                'breakdown_present': r.get('breakdown_present', ''), 'n_relationships': int(r.get('n_relationships') or 1)}
        rs = rule_score(code, r['response'], task)
        if rs is not None:
            rule_cov += 1
        ls = llm.score(code, r['response'], task, rubric.get(code, {}))
        hs = hybrid_score(code, r['response'], task, rubric.get(code, {}), llm)
        by_method['RULE'].append((gold, rs if rs is not None else 'UNKNOWN'))
        by_method['LLM'].append((gold, ls))
        by_method['HYBRID'].append((gold, hs))
        if code in per_code:
            per_code[code]['RULE'].append((gold, rs if rs is not None else 'UNKNOWN'))
            per_code[code]['LLM'].append((gold, ls))
            per_code[code]['HYBRID'].append((gold, hs))
    for m, pairs in by_method.items():
        out['methods'][m] = metrics(pairs)
    out['methods']['RULE']['coverage_rule'] = round(rule_cov / len(rows), 3) if rows else None
    for c, d in per_code.items():
        if d['LLM']:
            out['per_code'][c] = {m: metrics(p) for m, p in d.items()}
    out['reading'] = [
        'RULE 의 coverage 가 곧 "규칙만으로 확정되는 비율"이다. 나머지는 LLM 이 필요하다',
        '서열 점수라 exact 보다 adjacent 와 선형 가중 κ 를 본다',
        'NA/UNKNOWN 일치는 따로 본다. 이것을 맞히는 것이 U4 와 P4/P5 의 핵심이다',
        'Echo 출력은 배선 확인이다. 사람 합의 gold 가 있어야 어떤 수치도 의미가 있다',
    ]
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--human', default=None, help='code,response,human_score,source_text,decidable_by_evidence,breakdown_present,n_relationships')
    ap.add_argument('--demo', action='store_true')
    ap.add_argument('--out', default='results')
    a = ap.parse_args()
    if a.demo or not a.human:
        rng = random.Random(5)
        rows = []
        resp = ['"그날 좀 봐야 할 게 있어서"라고 한 부분이 거절을 돌려 말한 것 같다.',
                '확실히 화난 거다.', '아마 그럴 수도 있고 아닐 수도 있다. 더 물어봐야 알 것 같다.',
                '무슨 뜻이야? 다시 말해 줄 수 있어?', '알겠어.']
        for i in range(60):
            code = rng.choice(CODES)
            rows.append({'code': code, 'response': rng.choice(resp),
                         'human_score': rng.choice(ORDINAL + ('NA',) if code in ('U4', 'P4', 'P5') else ORDINAL),
                         'source_text': '그날 좀 봐야 할 게 있어서 라고 말했다',
                         'decidable_by_evidence': rng.choice(['YES', 'NO']),
                         'breakdown_present': rng.choice(['YES', 'NO']), 'n_relationships': rng.choice([1, 2])})
        print('=' * 60)
        print('  DEMO · Echo · 배선 확인. 채점 성능이 아니다')
        print('=' * 60)
    else:
        rows = list(csv.DictReader(io.open(a.human, encoding='utf-8-sig', newline='')))
    rep = run(rows, EchoLLM())
    outdir = os.path.join(HERE, a.out)
    os.makedirs(outdir, exist_ok=True)
    io.open(os.path.join(outdir, 'scoring_report.json'), 'w', encoding='utf-8').write(
        json.dumps(rep, ensure_ascii=False, indent=2))
    print('%-7s %-5s %-8s %-9s %-8s %-9s %-9s %s' % ('method', 'n', 'exact', 'adjacent', 'wkappa', 'spearman', 'special', 'rule_cov'))
    for m, s in rep['methods'].items():
        print('%-7s %-5s %-8s %-9s %-8s %-9s %-9s %s' % (m, s['n'], s['exact_agreement'], s['adjacent_agreement'],
                                                          s['weighted_kappa_linear'], s['spearman'], s['special_agreement'], s['coverage_rule']))
    print('저장 ·', os.path.join(outdir, 'scoring_report.json'))
    return 0


if __name__ == '__main__':
    sys.exit(main())
