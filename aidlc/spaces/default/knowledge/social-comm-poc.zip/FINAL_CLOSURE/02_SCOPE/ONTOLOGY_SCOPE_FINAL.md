# ONTOLOGY SCOPE · FINAL

2026-09-14 · B2 · B3 · B4. CLOSURE_RESEARCH C 절의 범위 판정을 **그대로 믿지 않고** 다시 판정한다.
근거 원자료 · `_agent_pragmatics_review.md` (Q-B3 · Q-B1) · `../01_EVIDENCE/AGE_EVIDENCE.md` §6 · `research/agent_scd_census.md` Row 9.
**frozen spec v0.1 은 고치지 않는다.** 범위 판정은 규격 밖의 문서다. 규격을 바꿔야 하는 것은 `SPEC_V0_2_CANDIDATES.md` 로 보낸다.

---

## 0 · 결론 먼저

같은 잣대를 모든 후보에 대니 **CLOSURE_RESEARCH 의 판정이 다섯 군데서 뒤집히고 한 군데는 합쳐진다.**
후보 일곱 중 그대로인 것은 하나뿐이다(반어·비꼼).
방향도 한쪽이 아니다. **CORE 에서 둘이 내려가고 아래에서 셋이 올라왔다.**

| 후보 | CLOSURE_RESEARCH | 이번 | 이유 한 줄 |
|---|---|---|---|
| 상대 지식 고려 · 정보량 조절 | CORE 둘 | **CORE 하나로 합침** | 규격 Core 다섯이 둘을 구분하지 못한다(S4 = S5). 근거도 한 논문이 둘을 같이 보고한다 |
| 화제 운용 | CORE | **CONDITIONAL** | DSM-5 에 이름이 직접 없고, SCD/PLI 에서 **화제 행동 자체**를 보고한 결과를 찾지 못했다 |
| 수리 · 명료화 | CORE | **CONDITIONAL** | DSM-5 A3 에 이름이 있다. 그러나 SCD/PLI 에서 **수리 행동 결과**가 보고되지 않았다(부호화만 됐다) |
| 응답성 · 상호성 | CONDITIONAL | **CORE** | PLI 행동 결과 둘(Bishop 2000 · Bishop 1994) + 한국 SCD 관찰(Jin & Pae 2014) |
| 관계 · 상황 맞춤 조정 | CONDITIONAL | **CORE** | DSM-5 A2 에 예시까지 적혀 있다 + PLI 행동 결과(Bishop 1994) + 관계는 우리 스키마 필수값 |
| 대화 속 함축 · 비문자 의미 이해 | SEED_ONLY | **CORE** | DSM-5 A4 명시 + PLI 행동 결과(Bishop & Adams 1989 II) + **SPCD 표시 표본 1건**(Svindt & Surányi 2021 · 진단 절차는 초록에 없음) |
| 반어 · 비꼼 · 간접 거절 (그 자체) | SEED_ONLY | **SEED_ONLY 유지** | A4 가 유머·중의성을 예시로 들지만 SCD 표본에서 이 과제 형태를 잰 결과는 찾지 못했다 |

**그리고 이 전체 순위는 얇다.** 근거는 전부 **초록 수준**이고 표본은 **n = 6 ~ 13**, 연령은 **5 ~ 12세**다.
**13 ~ 25세 DIRECT SCD 근거는 모든 후보에서 NONE** 이다(AGE_EVIDENCE §6). 규칙을 한 칸만 바꿔도 순위가 흔들린다(§5).

---

## 1 · B3 · 여섯 필수 기준 감사

CLOSURE_RESEARCH C-3 의 기준 여섯을 그대로 쓸 수 없는 이유와 고친 형태.

| 기준 | 원래 문장 | 문제 | 고친 형태 |
|---|---|---|---|
| **A** 근거 | SCD 또는 역사적 PLI 표본에서 확인된 난점 | **"확인"의 수준이 정의돼 있지 않다.** 진단 기준 문장에 이름이 있는 것, 표본에서 부호화만 된 것, 표본에서 결과가 보고된 것이 모두 "확인"으로 통과했다. 그래서 수리·명료화는 "간접"인데 INCLUDE 가 됐고, 다른 셋은 도구 이름만으로 "확인됨"이 됐다 | **A-DEF** DSM-5 SPCD 기준 A1~A4 문장에 행동이 나오는가 · **A-EMP** DSM-5 SCD 또는 역사적 PLI 표본에서 **그 행동 자체의 집단 결과**가 보고됐는가. 둘을 따로 적는다 |
| **B** 텍스트 관찰 | 텍스트만으로 관찰 가능 | 두 맥락을 섞는다. 우리가 만든 **훈련 과제**는 대사를 우리가 쓰므로 텍스트 행동은 전부 보인다. **사용자 사건**은 사용자가 쓴 만큼만 보인다 | **B-TASK** 훈련 과제에서 관찰 가능 · **B-EVENT** 사용자 사건에서 관찰 가능(조건 명시) |
| **C** L4 표현 | 기존 L4 필드로 표현 가능 | 통과는 하는데 **구분이 안 되는** 경우를 못 잡는다. 상대 지식(S4)과 정보량(S5)이 Core 다섯에서 같은 값이다 | 표현 가능 **그리고** 다른 후보와 Core 서명이 구별되는가를 같이 적는다 |
| **D** 주석 가능 | 사람 주석 지침을 쓸 수 있다 | **아무 구인이나 지침은 쓸 수 있다.** 기준이 걸러 내는 것이 없다 | **A1 에서 κ 로 판정된다.** 지금은 모든 후보가 **가설** |
| **E** 변형 가능 | 상황 변형이 가능 | 합리적. 다만 문헌이 아니라 POC B 가 판정한다 | **POC B 에서 판정된다.** 지금은 모든 후보가 **가설** |
| **F** 측정 가능 | 수행 지표를 정의할 수 있다 | 정의는 누구나 할 수 있다. 평정자가 같게 쓸 수 있는가가 기준이어야 한다 | **rubric 신뢰도(H-03)에서 판정된다.** 지금은 모든 후보가 **가설** |
| (없음) | — | **연령이 기준에 없다.** 우리 대상은 13~25 인데 기준 여섯 어디에도 연령이 없다 | **G 연령 적합** 을 보고 항목으로 추가. 필터로 쓰면 전 후보가 탈락하므로 필터가 아니라 표시로 쓴다 |

**감사 결과 한 줄** · 여섯 기준 중 **셋(D · E · F)은 문헌이 판정하지 못하고 우리 POC 가 판정한다.**
그러므로 지금 내릴 수 있는 범위 판정은 **A · B · C 기준의 잠정 판정**이고, D · E · F 는 전 후보에서 가설이다.

---

## 2 · B3 · 수리·명료화 모순 해결

**모순** · CLOSURE_RESEARCH 는 수리·명료화의 SCD 근거를 "간접"으로 적고도 MVP INCLUDE 로 넣었다.
**지시** · DIRECT 근거를 찾으면 유지, 없으면 CONDITIONAL.

| 수준 | 찾은 것 | 판정 |
|---|---|---|
| A-DEF | **DSM-5 A3 "rephrasing when misunderstood"** (Swineford 2014 재수록 · 전문 확인) | **있다.** 다만 "오해받았을 때 다시 말하기"만 명시. **명료화 요청(내가 모를 때 묻기)** 은 문장에 없다 |
| A-EMP DIRECT SCD | 4개 새 질의 · 65건 제목 전수 선별 · **NOT FOUND AFTER DEFINED SEARCH** | **없다** |
| A-EMP 역사적 PLI | Adams & Bishop 1989 I · 수리를 **신뢰도 있게 부호화**했으나 초록에 수리 집단 차이가 없다. 전문은 403 | **부호화만.** 결과 방향 미상 |
| 인접 PLI 결과 | Bishop 2000 · PLI 가 어른의 요청에 **무응답이 더 많다** | 응답성의 근거지 수리의 근거가 아니다 |
| 인접 ASD/DLD | Brinton 1986 · 1988 · Volden 2004 · Barstein 2018 · Lee & Yim 2026(한국 SLI) · Sadati 2024 | 측정 틀은 여기 있다 |

**판정 · MVP_CONDITIONAL.** 지시 규칙대로다.
**단 역할을 둘로 나눈다.** 문헌이 수리를 모드가 아니라 **역할**로 나눈다(Q-B1 판정).

| 역할 | DSM-5 | 판정 | 조건 |
|---|---|---|---|
| **오해받았을 때 되돌리기** (respond to misunderstanding) | A3 에 명시 | CONDITIONAL · **A-DEF 있음** | 대화에 상대의 오해 턴과 되돌릴 턴이 둘 다 있을 때 |
| **내가 모를 때 묻기** (request clarification) | 명시 없음 | CONDITIONAL · **A-DEF 없음 · 인접 근거만** | 같음 + 인접 근거라는 표시를 붙인다 |

"그런데 왜 빼지 않나" · CONDITIONAL 은 **훈련은 하되 근거 기반이라고 부르지 않는다**는 뜻이다.
빼지 않는 이유는 둘이다. ① 진단 기준 문장에 들어 있다 ② 우리 PERFORM 지표 P4 가 이미 이것을 잰다.

---

## 3 · B2 · 같은 잣대로 모든 후보

**판정 규칙 · 한 번 적고 모두에 똑같이 적용한다.**

```
MVP_CORE          A-DEF 있음  AND  A-EMP 있음 (DIRECT SCD 또는 역사적 PLI 의 행동 결과)
                  AND  B-TASK 관찰 가능  AND  C 표현 가능
MVP_CONDITIONAL   A-DEF 있음  AND  A-EMP 없음 (부호화만 · 단일 사례 · 인접만)
                  또는  사건 관찰에 조건이 붙는 CORE 후보
SEED_ONLY         구인은 A-DEF 가 있으나 이 과제 형태의 SCD/PLI 행동 결과가 없음 · 한국어 씨앗 자료가 풍부
FUTURE_AUDIO      A-EMP 가 있으나 운율 · 시간 정보가 있어야 보임
EXCLUDE           영상이 있어야 보임
D · E · F         전 후보 가설 (A1 · POC B · rubric 신뢰도가 판정)
```

### 3-1 · 채점표

| 후보 | A-DEF (DSM-5) | A-EMP SCD 표본 (STRICT 또는 표시) | A-EMP 역사적 PLI | 혼합 · 단일 사례 | 인접 | 13~25 DIRECT | B-TASK | B-EVENT 조건 | C (Core 서명) | 한국어 씨앗 | 판정 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| **청자 맞춤 정보 조절** (상대 지식 + 정보량) | **A2** 청자 필요에 맞춰 바꾸기 | 없음 | **Bishop & Adams 1989 II** "too much or too little information" | Adams 2015 n=1 "appreciation of listener knowledge" 개선 | Karin 2026 ASD · Arvidsson 2022 전형 청소년 · Diez-Itza 2022 성인 | NONE | 예 | 사용자가 무엇을 말했고 상대가 무엇을 알았는지 적었을 때 | S4 = S5 · **둘은 한 서명** | 화용 평가셋 양 격률 30 · ToM-Diary | **MVP_CORE** |
| **응답성 · 상호성** | A1 · A3 일부 (사회적 목적 · 상호작용 조절) | **Jin & Pae 2014** 한국 · 체크리스트로 조작화한 SCD 15 · 응답 유형 관찰 | **Bishop 2000** PLI 무응답 더 많음 · **Bishop 1994** SPD 응답보다 개시 | Adams 2015 "marked improvement in responsiveness" | — | NONE | 예 | 턴 경계가 있는 원문을 붙였을 때 | 구별 가능 | 3i4K 화행 | **MVP_CORE** |
| **관계 · 상황 맞춤 조정** | **A2** 교실과 운동장 · 아이와 어른 · 지나친 격식 | 없음 | **Bishop 1994** SPD 는 상대 친숙도에 따라 조절하지 않음 | Adams 2015 "adaptation of discourse style" | — | NONE | 예 · **NEAR 전이가 곧 이 검사** | 관계는 스키마 필수값 · 조건 충족 | 구별 가능 (direct_check_allowed · 관계) | 국어원 관계 메타 | **MVP_CORE** |
| **대화 속 함축 · 비문자 의미 이해** (RECOGNIZE) | **A4** 명시되지 않은 것 이해 · 추론 | **Svindt & Surányi 2021** SPCD 13 · 함축·전제·함의 이해가 전형과 다름 · 문장-그림 과제 · 초록 | **Bishop & Adams 1989 II** "frequently misunderstood the literal or implicit meaning of adult utterances" · Bishop & Adams 1992 이해 과제 | Adams & Gaile 2020 SLDT Making Inferences 상승 | — | NONE | 예 | 사용자가 상대 말을 원문으로 적었을 때 | 구별 가능 | **가장 풍부** · 간접화행 240 · 화용 평가셋 120 · KoCoSa(권리 유보) | **MVP_CORE** |
| **수리 · 명료화** | **A3** "rephrasing when misunderstood" (역할 하나만) | 없음 | **부호화만** · Adams & Bishop 1989 I | — | Brinton · Volden · Barstein · Lee & Yim 2026 · Sadati 2024 | NONE | 예 | 어긋남 턴과 되돌릴 턴이 둘 다 있을 때 | 구별 가능 · 역할 속성 없음 | KMI 반영 전략 | **MVP_CONDITIONAL** |
| **화제 운용** | A3 "rules for conversation" 일부 · **화제라는 말은 없다** | 없음 · TOPICC 12 측면 중 어느 것이 손상됐는지 초록에 없음 | 교환 구조 · 개시 과다(1989 I) · **화제 행동 결과는 아니다** | TOPICC · SCIP RCT 대화 역량(PLI 75% ASD 겹침) | Ábalos 2026 · Ayvazo 2026 · Diez-Itza 2022 · Gerber 2012 | NONE | 예 | 턴 경계 원문 | 구별 가능 | 관계 격률 | **MVP_CONDITIONAL** |
| 장황함 | A2 "지나친 격식" 일부 | 없음 | **Adams & Lloyd 2005** 장황함 지표가 집단을 가름 | — | — | NONE | 예 | 원문을 붙였을 때만 | 정보량과 겹침 | 양 격률 | MVP_CONDITIONAL (정보량 방향의 하위로) |
| 반어 · 비꼼 · 간접 거절 (과제 형태 그 자체) | A4 가 유머 · 중의성을 예시로 듦 | 없음 | 없음 | — | — | NONE | 예 | 원문 | 구별 가능 | KoCoSa 12,824 (합성 · 권리 유보) · 간접화행 240 | **SEED_ONLY** |
| 말순서 · 겹침 · 끼어들기 | A3 "taking turns" | 없음 | 1989 I "interrupted unusually" | — | — | NONE | **아니오 · 시간 필요** | — | — | 국어원 start/end | **FUTURE_AUDIO** |
| 준언어 · 운율 | A3 "verbal and nonverbal signals" 일부 | 없음 | — | PRS-SA 운율 항목 | — | NONE | 아니오 | — | — | 없음 | **FUTURE_AUDIO** |
| 비언어 · 시선 · 거리 | A3 nonverbal | — | — | — | — | NONE | 아니오 · 영상 | — | — | 없음 | **EXCLUDE** |

### 3-2 · CLOSURE_RESEARCH 와 달라진 이유 · 한 칸씩

**화제 운용이 내려간 이유** · CLOSURE_RESEARCH 는 "SCD 표본 확인 6난점의 첫 항목"을 근거로 댔다.
그런데 그 6난점 목록(`research/SCD_문헌.md` §2)에는 **출처가 적혀 있지 않다.** 추적할 수 없는 목록은 근거로 쓰지 않는다.
나머지 근거(TOPICC · SCIP RCT)는 어느 측면이 손상됐는지 초록에 없거나 ASD 겹침이 75% 다.

**함축 이해가 올라간 이유** · CLOSURE_RESEARCH 는 "SCD 표본 근거가 없는 것들" 목록에 **함축**을 넣었다. 두 가지가 그 문장과 부딪힌다.
① DSM-5 A4 가 "명시되지 않은 것의 이해(추론)"를 기준으로 적는다.
② 우리 census 가 이미 찾아 둔 **Svindt & Surányi 2021** 이 SPCD 표시 13명(진단 절차는 초록에 없어 STRICT 가 아니다 · `01_EVIDENCE/SCD_STUDY_COUNTS.md`)에서 함축 · 전제 · 함의 이해가 전형 발달과 다르다고 보고한다.
그러므로 "데이터가 있는 곳에 SCD 근거가 없다"는 CLOSURE_RESEARCH 의 대표 문장은 **과장**이다. 정확한 문장은 이렇다.

> 데이터가 가장 많은 영역(간접 화행 · 함축)은 DSM-5 A4 에 이름이 있고, SPCD 표시 표본 한 건과 역사적 PLI 한 건이 이해 곤란을 보고했다.
> 비어 있는 것은 **대화 속 간접 거절 · 반어 · 비꼼을 SCD 표본에서 잰 결과**다.

**주의 · Svindt 2021 은 우리 과제와 같지 않다.** 문장-그림 검증 과제이고 **문법으로 촉발되는** 함축이다.
그리고 SPCD 집단 수행이 마음이론이 아니라 **수용 문법**과 상관했다. 사회적 화용 곤란이 아니라 언어 구조 곤란일 수 있다는 뜻이다.
그래서 이것 하나로 CORE 가 된 것이 아니라 **Bishop & Adams 1989 II 의 대화 속 오해 결과**와 함께 CORE 가 됐다.

**응답성 · 관계 조정이 올라간 이유** · CLOSURE_RESEARCH 는 두 항목을 **사건 관찰 조건** 때문에 CONDITIONAL 로 뒀다.
그런데 조건 B 를 B-TASK 와 B-EVENT 로 나누면 훈련 과제에서는 조건 없이 보인다.
관계 조정의 사건 조건("관계를 입력했을 때만")은 **관계가 스키마 필수값이라 항상 충족된다.** CLOSURE_RESEARCH 자신이 그렇게 적었다.

---

## 4 · B4 · 최종 범위표

| 층 | 항목 | 근거 강도 | 연령 적합 | 한국어 자료 | 온톨로지 대응 (v0.1 필드) | 훈련 과제 | 수행 지표 | 자동화 | 남는 위험 |
|---|---|---|---|---|---|---|---|---|---|
| **MVP_CORE** | 청자 맞춤 정보 조절 | A-DEF A2 + PLI 결과 1 (초록) + 단일 사례 1 | DIRECT 13~25 NONE · 전형 청소년 1 (Arvidsson 2022) | 양 격률 30문항 · ToM-Diary 조망 | perspective_structure · required_inference | 같은 내용을 아는 것이 다른 상대에게 다시 전달 | P2 정보 충분성 · S1 누락 수 · S2 잉여 수 | 누락·잉여는 규칙(참조 과제) · 판단은 LLM | 두 방향(과소 · 과다)을 한 서명으로 묶었다. 사용자가 둘을 다른 문제로 느낄 수 있다 |
| **MVP_CORE** | 응답성 · 상호성 | PLI 결과 2 + 한국 체크리스트 SCD 관찰 1 + 단일 사례 1 | NONE | 3i4K 화행 | target_skill · required_inference | 상대의 요청·질문에 반응하는 턴 만들기 | P1 응답성 | 질문 표지 ↔ 응답 유무는 규칙 · 적절성은 LLM | Jin & Pae 2014 의 SCD 는 임상 진단이 아니라 체크리스트 조작화다 |
| **MVP_CORE** | 관계 · 상황 맞춤 조정 | A-DEF A2 (예시까지) + PLI 결과 1 + 단일 사례 1 | NONE | 국어원 화자 관계 메타 (약정 필요) | direct_check_allowed · relationship_type | **NEAR 전이 과제 그 자체** · 관계만 바꾼 같은 구조 | P5 관계 적응 (두 관계 이상) | LLM | "맞춤"의 정답이 규범이 되기 쉽다. `RELATIONSHIP_SCOPE.md` 의 분해를 따라야 한다 |
| **MVP_CORE** | 대화 속 함축 · 비문자 의미 이해 | A-DEF A4 + SPCD 표시 표본 1 (진단 절차 미확인 · 문장-그림 · 초록) + PLI 결과 1 | NONE | **가장 풍부** · 간접화행 240 · 화용 평가셋 120 · KoCoSa 12,824(권리 유보 · 내부 분석만) | required_inference · decidable_by_evidence | 같은 함축 구조를 다른 관계에서 다시 읽기 | U1 단서 · U2 해석 다양성 · U3 근거 없는 단정 · U4 정당한 보류 | LLM | Svindt 는 문법 촉발 함축이고 수용 문법과 상관. 우리 과제(사회적 함축)로 옮겨지는지 모른다 |
| **MVP_CONDITIONAL** | 수리 · 명료화 (역할 둘) | A-DEF A3 (한 역할) · PLI 부호화만 · 인접 측정 틀 | NONE · 인접 청소년 DHH 1 (Sadati 2024) | KMI | target_skill=REPAIR | 어긋남 뒤 되돌리기 · 모를 때 묻기 | P4 · S6 명료화 시도 수 · S7 성공률 | 표지 탐지 규칙 + 결과 판정 LLM | 역할 속성이 규격에 없다(C-02) |
| **MVP_CONDITIONAL** | 화제 운용 | A3 일부 · PLI 교환 구조 · 도구 측면 미공개 | NONE · 인접 ASD n=3 (16~18) | 관계 격률 | target_skill · required_inference | 화제 전환 신호 읽기 · 상대 화제 닫고 넘어가기 | P3 · S5 주제유지 비율 | LLM · 라벨 코퍼스 있으면 규칙 | 근거가 가장 약하다. 가장 좋은 부호화 틀(Ábalos 2026)은 8세 ASD 에서 만들어졌다 |
| **MVP_CONDITIONAL** | 장황함 | PLI 결과 1 (Adams & Lloyd 2005) | NONE | 양 격률 | 정보량의 과다 방향 | 정보량과 같이 | P2 · S3 목표까지 단어 수 | 규칙 | 사용자가 원문을 다듬어 쓰면 원래 길이를 잃는다 |
| **SEED_ONLY** | 반어 · 비꼼 · 간접 거절 (과제 형태) | A-DEF A4 예시 · 행동 결과 없음 | NONE | KoCoSa · 간접화행 | PragmaticPhenomenon 확정값 둘 | 씨앗으로만 · 함축 이해 과제의 표면 재료 | — | — | **PragmaticPhenomenon 확정값 둘(비꼼 · 간접성)** 중 간접성은 함축 이해로 올라갔고 비꼼은 여전히 가설 |
| **FUTURE_AUDIO** | 말순서 · 겹침 · 운율 | PLI "interrupted unusually" 등 | NONE | 국어원 start/end | — | 음성 단계 | — | — | 텍스트로는 영영 안 보인다 |
| **EXCLUDE** | 비언어 · 시선 · 거리 | — | — | 없음 | — | — | — | — | — |

### 4-1 · POC 에 주는 영향

| 산출물 | 영향 | 조치 |
|---|---|---|
| frozen spec v0.1 | **없다.** 범위는 규격 밖 | — |
| A1 | **없다.** 판정 대상은 쌍이고 범위가 아니다 | — |
| POC B 씨앗 | **좋은 소식.** §5.3 씨앗 10개 중 다섯(S1·S2·S3·S7·S9)이 함축·간접 의미라 CLOSURE_RESEARCH 기준으로는 SEED_ONLY 에 몰려 있었다. 이번 판정으로 그 다섯이 CORE 영역(함축 이해)에 들어온다 | `04_GENERATION/generator/skill_family_seeds.json` 의 scope_tier 를 이 표로 갱신 (§6) |
| rubric | **없다.** U1~U5 · P1~P5 가 이미 여섯 영역을 다 덮는다 | — |
| intake | `blocked_at → target_skill` 매핑이 명료화 요청을 RECOGNIZE 로 보낸다 | C-13 |
| 발표 | "네 표적이 근거 기반"이라는 문장을 쓰면 안 된다 | §7 의 문장을 쓴다 |

---

## 5 · 민감도 · 규칙을 바꾸면 무엇이 바뀌나

| 규칙 변형 | 결과 |
|---|---|
| **A-EMP 에서 역사적 PLI 를 빼고 DIRECT SCD 만 인정** | CORE 는 **함축 이해 하나**(Svindt 2021) · 한국 체크리스트 SCD 를 인정하면 응답성 추가. 나머지 전부 CONDITIONAL |
| **A-DEF 를 요구하지 않고 A-EMP 만** | 장황함이 CORE 로 올라간다. 수리 · 화제는 여전히 CONDITIONAL |
| **단일 사례(Adams 2015)를 A-EMP 로 인정** | 화제 운용은 여전히 CONDITIONAL (그 사례에 화제가 없다). 나머지 불변 |
| **연령(G)을 필터로 사용** | **전 후보 탈락.** 13~25 DIRECT SCD 근거가 어디에도 없다 |

**어떤 규칙에서도 변하지 않는 것 둘.**
① 화제 운용과 수리 · 명료화는 **CORE 가 되지 않는다.** CLOSURE_RESEARCH 의 INCLUDE 넷 중 둘이다.
② 연령 근거는 **어떤 후보에도 없다.** 이것은 범위 문제가 아니라 대상 결정 문제다(D-01).

---

## 6 · 씨앗 파일 갱신

`04_GENERATION/generator/skill_family_seeds.json` 의 `scope_tier` 를 이 문서 §4 에 맞춘다.

| 씨앗 | 이전 | 이번 |
|---|---|---|
| S1 · S2 · S3 · S7 · S9 (함축 · 간접 의미) | SEED_ONLY | **MVP (함축 이해)** · 표면 재료로서의 비꼼 · 간접 거절은 SEED_ONLY 로 남는다 |
| S4 · S5 (청자 지식 과소 · 과다) | MVP (둘로 셈) | **MVP (청자 맞춤 정보 조절 하나)** |
| S6 · X2 (수리 · 명료화) | MVP_CONDITIONAL | 그대로 |
| S8 · X1 (화제) | MVP | **MVP_CONDITIONAL** |
| S10 (완화 표지) · 관계 조정 | MVP_CONDITIONAL | **MVP (관계 맞춤 조정)** |
| X3 (못 따라오는 신호) | MVP | 그대로 (청자 맞춤 정보 조절 · RECOGNIZE) |

---

## 7 · 강사에게 쓰는 문장

**써도 되는 것**
> 범위 후보 열한 개에 같은 판정 규칙을 적용했습니다. 진단 기준 문장에 이름이 있고, SCD 나 과거 PLI 표본에서 그 행동 자체의 결과가 보고된 것만 핵심으로 뒀습니다.
> 그 결과 네 개입니다. 청자 맞춤 정보 조절, 응답성, 관계 맞춤 조정, 대화 속 함축 이해입니다.
> 처음에 넣었던 화제 운용과 수리·명료화는 조건부로 내렸습니다. 진단 기준에는 있지만 표본 결과가 없었습니다.
> 다만 근거가 전부 초록 수준이고 5~12세 아동이며 표본이 6~13명입니다. 13~25세 SCD 근거는 네 개 모두 없습니다.

**쓰면 안 되는 것**
- "네 표적 모두 근거 기반입니다"
- "SCD 연구에서 확인된 여섯 난점" (출처 추적 불가)
- "함축 · 간접 의미는 SCD 근거가 없습니다" (이제 틀린 문장)
