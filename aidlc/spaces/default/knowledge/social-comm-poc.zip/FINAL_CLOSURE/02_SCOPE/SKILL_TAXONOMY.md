# SKILL TAXONOMY · task_mode 와 skill_family

2026-09-14 · B1 · D. frozen spec v0.1 의 `target_skill = RECOGNIZE | PRODUCE | REPAIR` 가 **두 축을 한 칸에 섞고 있는가**를 문헌과 우리 산출물로 확인한다.
문헌 원자료 · `_agent_pragmatics_review.md` §3 (Q-B1). **v0.1 은 고치지 않는다.** 제안은 `SPEC_V0_2_CANDIDATES.md` C-01 · C-02 · C-11 · C-13.

---

## 0 · 결론

**섞고 있다.** RECOGNIZE 와 PRODUCE 는 **과제 방식**(이해하느냐 산출하느냐)이고, REPAIR 는 **기술 영역**이다.
문헌에서 수리를 과제 방식으로 둔 분류는 **하나도 없다.** 전부 영역이나 하위 항목으로 둔다.

그리고 이 섞임이 **우리 산출물에서 이미 세 번 문제를 만들었다.** §3.

---

## 1 · 문헌은 어떻게 나누나

| 분류 | 과제 방식 축 | 기술 영역 축 | 수리는 어디에 |
|---|---|---|---|
| Adams 2002 (실무 검토) | **명시** · 형식 검사는 "화용 의도의 이해"를, 자연 표본은 "상호작용 속 사용"을 본다 | 화행 · 대화 · 서사 · 함축 · 맥락 단서 | 대화 능력 안 |
| DSM-5 SCD 기준 A | **암묵** · A4 는 이해, A1~A3 는 사용 | 사회적 목적 · 청자·맥락 맞춤 · 대화 규칙 · 추론·비문자 | **A3 "rephrasing when misunderstood"** · 대화 규칙 안 |
| Pragmatic Protocol (Prutting & Kirchner 1987) | 없음 · 산출 관찰만 | 30 매개변수 | 말순서 아래 "repair/revision" |
| CCC-2 | 없음 · 보고자 평정 | 10 하위척도 | 명시 항목 없음 |
| ASHA 사회적 의사소통 구성요소 | 없음 | 사회 상호작용 · 사회 인지 · 화용 · 언어 처리 | 담화 아래 **"communication breakdown and repair"** |
| TOPICC · PRS-SA | 없음 · 산출 관찰 | 12 측면 · 19 행동 | 목록 비공개 |
| AMP · KOPLAC · PleaseApp | **이해 전용** | 각자의 영역 하위축 | — |
| **ABaCo** (Angeleri 2012 · Gabbatore 2025) | **있다** · 다섯 척도 중 넷을 이해와 산출 **둘 다**로 채점 | 언어 · 언어외 · 준언어 · 맥락 · 대화 | 대화 척도 (산출 전용) |

**두 축을 공식으로 교차시킨 도구는 ABaCo 하나다.** 나머지는 한 축이다.
그러나 **축이 둘이라는 것 자체**는 실증으로도 보인다. Lockton, Adams & Collins 2016 에서 SCD 표시 아동 39명의 **인식(AMP)이 산출(TOPICC)을 예측하지 못했다**(표현 언어를 통제한 뒤).

### 수리 연구는 모드가 아니라 역할로 나눈다

| 역할 | 무엇 | 연구 |
|---|---|---|
| 상대의 명료화 요청에 **응답**하기 | 상대가 "뭐?"라고 하면 다시 말하기 | Brinton 1986 · 1988 · Volden 2004 · Barstein 2018 |
| 명료화 요청을 **산출**하기 | 내가 모르면 묻기 | Lee & Yim 2026 (한국 SLI) · Sadati 2024 |
| (DSM-5 A3) | 오해받았을 때 다시 말하기 | 첫 역할과 같은 쪽 |

---

## 2 · v0.1 은 어떻게 나누고 있나

```
target_skill   RECOGNIZE    과제 방식 · 이해
               PRODUCE      과제 방식 · 산출
               REPAIR       ← 기술 영역. 한 칸에 두 축이 있다
```

intake 에서 이 값을 만드는 매핑 (`03_POC_C/intake_questions.md` 화면 5)

```
MEANING_UNCLEAR (상대 말이 무슨 뜻인지 몰라서)          → RECOGNIZE
HOW_TO_SAY      (어떻게 말해야 할지 몰라서)             → PRODUCE
MOOD_TURNED     (말하고 나서 분위기가 이상해져서)        → REPAIR
MISUNDERSTOOD   (상대가 내 말을 다르게 알아들어서)       → REPAIR
```

---

## 3 · 섞임이 우리 산출물에서 만든 문제 셋

### 3-1 · 명료화 요청이 RECOGNIZE 로 간다

사용자가 "상대 말이 무슨 뜻인지 몰랐는데 **물어보지 못했다**"를 겪었다고 하자.
화면 5 에서 `MEANING_UNCLEAR` 를 고른다 → `RECOGNIZE` 가 된다.
그런데 이 사용자가 연습해야 할 것은 **명료화 요청 산출**, 문헌이 수리 영역으로 분류하는 것이다.
**v0.1 매핑으로는 이 사용자를 수리 연습으로 보낼 길이 없다.** → C-13

### 3-2 · 범위의 두 표적이 규격에서 한 기술이 된다

씨앗 S4(상대가 모르는 걸 안다고 치고 말함)와 S5(이미 아는 걸 길게 설명함)는 **Core 다섯이 전부 같다.**

| Core | S4 | S5 |
|---|---|---|
| target_skill | PRODUCE | PRODUCE |
| required_inference | 상대가 무엇을 아는지 짐작하기 | 같음 |
| perspective_structure | 상대의 지식 상태 1층 | 같음 |
| decidable_by_evidence | YES | YES |
| direct_check_allowed | YES | YES |

규칙 엔진으로 넣으면 **Skill Identity SAME** 이다. CLOSURE_RESEARCH 는 이 둘을 서로 다른 MVP 표적(상대 지식 · 정보량)으로 셌다.
**범위 문서의 "네 표적"과 규격의 "같은 기술"이 어긋나 있었다.** 이번 범위 판정은 둘을 **청자 맞춤 정보 조절 하나**로 합쳤다(`ONTOLOGY_SCOPE_FINAL.md`).
v0.2 에서 둘을 다시 가르고 싶으면 과소 · 과다 방향을 적는 칸이 필요하다. → C-11

### 3-3 · 같은 REPAIR 두 개가 역할이 반대다

씨앗 S6(상대가 내 말을 다르게 알아들음 · 내가 되돌린다)과 X2(무슨 뜻인지 몰랐는데 묻지 못함 · 내가 물어야 한다)는 둘 다 `target_skill = REPAIR` 다.
문헌에서 둘은 **역할이 반대인 다른 과제**다(§1). v0.1 은 required_inference 자유 서술로만 둘을 가른다. → C-02

---

## 4 · 제안 · 두 축 분리

```
task_mode      RECOGNIZE | PRODUCE
skill_family   listener_adapted_informativeness | reciprocity_responsiveness |
               relationship_adaptation | implicit_meaning_comprehension |
               repair_clarification | topic_management
repair_role    RESPOND_TO_MISUNDERSTANDING | REQUEST_CLARIFICATION | SELF_REPAIR | NA
               (skill_family = repair_clarification 일 때만)
```

v0.1 값과의 대응

| v0.1 target_skill | v0.2 task_mode | v0.2 skill_family |
|---|---|---|
| RECOGNIZE | RECOGNIZE | 사건에서 판정 (대개 implicit_meaning 또는 listener_adapted) |
| PRODUCE | PRODUCE | 사건에서 판정 |
| REPAIR | **PRODUCE** | repair_clarification + repair_role |

**REPAIR 는 산출이다.** 되돌리는 말도, 묻는 말도 사용자가 만들어 내는 발화다.

### Core 에 넣을 것인가

v0.1 의 금지 조항은 "Core 필드를 다섯에서 늘리거나 줄이지 않는다"이다. v0.2 에서 정할 선택지는 둘이다.

| 선택 | 무엇 | 장점 | 단점 |
|---|---|---|---|
| **A · Core 로** | target_skill 을 task_mode + skill_family 두 칸으로. Core 여섯 | 영역이 다르면 DIFFERENT 가 된다. 3-2 · 3-3 이 규칙으로 갈린다 | 판정 칸이 늘면 일치도가 떨어진다(Bayerl & Paul · 범주 수 β = −0.28) |
| **B · Supporting 으로 먼저** | task_mode 만 Core, skill_family 는 Supporting | Core 판정 부담이 그대로다 | 3-2 · 3-3 이 여전히 규칙으로 안 갈린다 |

**어느 쪽인지 지금 정하지 않는다. A1 결과가 정한다.** 결정 규칙을 미리 적어 둔다.

```
A1 에서 target_skill 의 필드 κ 가 다른 Core 넷보다 낮고
혼동행렬에서 REPAIR 가 RECOGNIZE 나 PRODUCE 와 섞이면     → 선택 A
target_skill κ 가 다른 필드와 같은 수준이면                 → 선택 B
```

이 규칙은 A1 이 **이미 모으는 자료**(Core 필드별 κ · 혼동행렬)만 쓴다. 추가 주석이 필요 없다.

---

## 5 · 이 문서가 주장하지 않는 것

- 두 축 분리가 **판정 일치도를 올린다**는 것. 오히려 칸이 늘면 내려갈 수 있다. A1 이 판정한다
- 여섯 skill_family 가 **완전하다**는 것. 범위 판정의 CORE · CONDITIONAL 여섯을 옮긴 것일 뿐이다
- 한국어 자료로 skill_family 를 **자동 분류할 수 있다**는 것. 측정한 적 없다
