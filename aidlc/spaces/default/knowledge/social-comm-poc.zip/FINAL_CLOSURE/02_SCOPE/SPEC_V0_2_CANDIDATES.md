# SPEC v0.2 CANDIDATES

2026-09-14 · **frozen spec v0.1 은 하나도 고치지 않았다.** 이 스프린트에서 발견한 규격 문제를 여기 모은다.
RC1 안의 `00_README/ISSUES_FOR_V0_2.md` (I-01 ~ I-09) 는 실행 패키지가 발견한 것이고, 이 문서는 리서치 · 자동화 · 감사가 발견한 것이다. 겹치는 것은 번호를 함께 적는다.

각 후보에 넷을 적는다 · **무엇 · 근거 · v0.1 에서 지금 어떻게 우회하나 · v0.2 에서 무엇으로 정하나(데이터로 정하는 법).**
**결정 방법이 "POC 결과를 보고"인 것은 그 POC 가 이미 모으는 자료로 정할 수 있게 적었다.** 추가 수집이 필요한 것은 따로 표시한다.

---

## 요약

| ID | 이름 | 종류 | 결정 자료 | 추가 수집 |
|---|---|---|---|---|
| **C-01** | TASK_MODE_SKILL_FAMILY_SEPARATION | Core 구조 | A1 target_skill κ · 혼동행렬 | 없음 |
| **C-02** | REPAIR_ROLE | 속성 추가 | A1 불일치 군집 · POC C 사건 | 없음 |
| **C-03** | DIRECT_CHECK_DECOMPOSITION | Core 필드 분해 | A1 direct_check_allowed κ · 판정자 메모 | 선택 |
| **C-04** | INCLUSION_CRITERIA_EVIDENCE_LEVELS | 범위 규칙 | 문헌 (완료) | 없음 |
| C-05 | intake_meta | wrapper | POC C 파일럿 전 | 없음 |
| C-06 | consistency_recheck | wrapper | POC C | 없음 |
| C-07 | outcome 2단계 화면 | 화면 | POC C | 없음 |
| C-08 | 집계 basis 표시 | 출력 | — | 없음 |
| **C-09** | A1 양식에 evidence_span | 양식 | E0~E4 에 필요 | **판정자 부담 증가** |
| **C-10** | A1 표본 60/120 · 1차 산출물 변경 | 통계 · I-09 | 시뮬레이션 (완료) | 없음 |
| **C-11** | 청자 지식 · 정보량 방향 표시 | 속성 | A1 · POC C | 없음 |
| **C-12** | 목표 범주를 자유 서술에서 도출 | intake | POC C 자유 서술 | 없음 |
| **C-13** | blocked_at → target_skill 매핑 | intake | POC C · A1 | 없음 |
| **C-14** | POC B 수락 기준에 계획 준수 | §11.2 | POC B dry-run (완료) | 없음 |
| **C-15** | POC B 앵커 장면 단계 | §11.2 | — | 앵커 14개 사람 확인 |

---

## C-01 · TASK_MODE_SKILL_FAMILY_SEPARATION

**무엇** · `target_skill = RECOGNIZE | PRODUCE | REPAIR` 가 과제 방식 둘과 기술 영역 하나를 한 칸에 섞는다.
**근거** · 문헌에서 수리를 과제 방식으로 둔 분류가 없다(Pragmatic Protocol · ASHA · DSM-5 A3 모두 영역). 이해와 산출의 분리는 Adams 2002 · DSM-5 A4 대 A1~A3 · Lockton 2016 에서 보인다. 우리 산출물에서 세 번 문제를 만들었다(`SKILL_TAXONOMY.md` §3).
**v0.1 우회** · 그대로 쓴다. 생성 씨앗에 `task_mode_v02` · `skill_family` 를 **판정에 쓰지 않는 칸**으로 붙여 두었다.
**v0.2 결정** · A1 에서 target_skill κ 가 다른 Core 넷보다 낮고 REPAIR 가 RECOGNIZE/PRODUCE 와 섞이면 Core 로 분리(선택 A), 아니면 skill_family 를 Supporting 으로(선택 B).

## C-02 · REPAIR_ROLE

**무엇** · 같은 REPAIR 가 "오해받아 되돌리기"와 "몰라서 묻기"를 모두 담는다. 역할이 반대다.
**근거** · 수리 연구가 역할로 나눈다(Brinton 1986 · Volden 2004 대 Lee & Yim 2026 · Sadati 2024). DSM-5 A3 는 한 역할만 명시한다.
**v0.1 우회** · required_inference 자유 서술로 구분. 씨앗 S6 · X2 에 `repair_role` 을 판정 외 칸으로.
**v0.2 결정** · `repair_role ∈ {RESPOND_TO_MISUNDERSTANDING, REQUEST_CLARIFICATION, SELF_REPAIR, NA}`. A1 불일치 중 REPAIR 쌍끼리의 불일치가 역할 차이에서 오는지 판정자 메모로 본다.

## C-03 · DIRECT_CHECK_DECOMPOSITION

**무엇** · `direct_check_allowed YES/NO` 는 관계만 보고 정하면 규범적 이분법이 된다.
**근거** · Holtgraves & Yang 1992(한국 표본 · 권력·거리·부담 상호작용) · Linde 1988(윗사람에게 완화하면 사회 비용은 줄고 과업 위험은 오른다) · Dingemanse 2015(수리 형식은 등급 선호) · McHoul 1990(자리가 수리 구조를 바꾼다). `RELATIONSHIP_SCOPE.md`.
**v0.1 우회** · A1 판정자는 쌍마다 판정(규격 그대로). **운영 파이프라인에서 관계로 자동 채우던 설계를 없앴다** (judge_harness · PIPELINE_MATRIX 수정).
**v0.2 결정** · 다섯 칸(feasibility · appropriateness · social_cost · task_risk · preferred_repair_strategy). A1 에서 direct_check_allowed κ 가 낮고 판정자 메모에 "상황에 따라"류가 많으면 분해를 채택. 한국 특유 전략(DEFERRED · THIRD_PARTY)은 **근거 NOT FOUND** 라 가설로 둔다.

## C-04 · INCLUSION_CRITERIA_EVIDENCE_LEVELS

**무엇** · 범위 기준 A 가 "확인"의 수준을 정하지 않아 수리(간접)와 다른 셋(도구 이름)이 모두 통과했다.
**근거 · 결정** · 완료. `ONTOLOGY_SCOPE_FINAL.md` §1 · A-DEF / A-EMP 분리, B-TASK / B-EVENT 분리, D · E · F 는 POC 가 판정, G 연령은 표시.

## C-05 ~ C-08 · POC C wrapper · 화면 · 출력

`06_PERSONALIZATION/POC_C_AUDIT.md` §6. 넷 다 판정 규칙을 건드리지 않는다.
- **C-05** `intake_meta` · burden 지표 여섯 중 다섯이 측정 불가였다
- **C-06** `consistency_recheck` · 24~72h 재질문 저장 자리
- **C-07** outcome 보기 2단계 · "확인해 봤나"가 없어 ClarificationRate 가 outcome 과 끊겼다
- **C-08** 집계 출력에 `basis: PROJECT_OPERATING_VALUE`

## C-09 · A1 양식에 evidence_span

**무엇** · 판정자가 근거로 삼은 원문 구간을 적는 칸이 없다.
**근거** · E0~E4 의 evidence precision/recall 과 A2 의 근거 대조에 필요하다(`07_TECH_ABLATION/DATASET.md` §2).
**v0.1 우회** · 없음. E0~E4 는 evidence 지표 없이도 돌지만 그 두 지표가 빈다.
**v0.2 결정** · **판정자 부담이 늘어난다**(쌍마다 구간 복사 두 번). A1 첫 회차 소요 시간을 보고 넣을지 정한다.

## C-10 · A1 표본 · I-09

**무엇** · 규격 §11 은 40쌍. 시뮬레이션은 60 최소 · 120 권장.
**근거** · `03_AUTOMATION/A1_SAMPLE_SIZE_REPORT.md` · 참 일치 0.7 에서 40쌍의 문턱 주장 확률 0.175.
**v0.1 우회** · 실행 패키지가 blind 40쌍(합계 60)으로 돈다. 판정 규칙 · 범주 · 문턱은 그대로. `a1_counts.json` 한 곳에서 되돌릴 수 있다.
**v0.2 결정** · §11 표본을 60 또는 120 으로 적는다. **1차 산출물을 문턱 통과가 아니라 점추정 · CI · 혼동행렬로.**

## C-11 · 청자 지식 · 정보량 방향

**무엇** · S4(과소)와 S5(과다)가 Core 다섯이 같다. 규격상 같은 기술이다.
**근거** · `SKILL_TAXONOMY.md` §3-2. Bishop & Adams 1989 II 가 "too much or too little" 을 한 결과로 보고한다.
**v0.1 우회** · 범위 판정에서 둘을 **청자 맞춤 정보 조절 하나**로 합쳤다.
**v0.2 결정** · Supporting 에 `informativeness_direction ∈ {UNDER, OVER, NA}`. Core 에는 넣지 않는다(같은 기술이라는 판정은 유지). POC C 에서 사용자가 둘을 다른 문제로 느끼는지(24~72h 재질문 자유 서술) 본다.

## C-12 · 목표 범주를 자유 서술에서

**무엇** · `user_goal_claim` 의 범주 일곱은 DSM-5 기준에서 연역했다. 사용자 목표에서 귀납한 것이 아니다.
**근거** · 치매 이인조가 자유롭게 정한 목표의 **31%** 가 미리 정한 다섯 영역 밖이었다(Budgett 2024). 이 분야 범주는 자유 서술을 먼저 받고 나중에 만든다(Angeli 2019b · Maddocks 2025). 혼합형이 가장 근거가 많다(SCIP-GAS · Staunton 2025).
**v0.1 우회** · 이미 혼합형이다(범주 일곱 + 자유 서술). 그대로 둔다.
**v0.2 결정** · POC C 자유 서술을 범주로 부호화해 **범주 밖 비율**을 잰다. 20% 를 넘으면 범주를 다시 만든다. **20% 는 PROJECT OPERATING THRESHOLD.**

## C-13 · blocked_at → target_skill 매핑

**무엇** · `MEANING_UNCLEAR → RECOGNIZE` 가 "몰랐는데 묻지 못함"을 수리 연습으로 보내지 못한다.
**근거** · `SKILL_TAXONOMY.md` §3-1.
**v0.1 우회** · 매핑 그대로.
**v0.2 결정** · 화면 5 에 보기 하나 추가 · "뜻을 몰랐는데 물어보지 못해서" → REPAIR (repair_role = REQUEST_CLARIFICATION). POC C 에서 MEANING_UNCLEAR 를 고른 사건의 자유 서술 중 "물어보지 못함"류 비율을 본다.

## C-14 · POC B 수락 기준에 계획 준수

**무엇** · 규격 §11.2 는 등급 일치로 수락한다. 등급이 맞아도 계획에 없는 축이 바뀔 수 있다.
**근거** · POC B dry-run 첫 실행 · 계획 준수 0.92 인데 수락 100%. 준수를 수락 조건에 넣자 준수 1.00 · 평균 시도 1.5 → 1.8 (`04_GENERATION/POC_B_FINAL_PROTOCOL.md`).
**v0.1 우회** · 생성 파이프라인이 준수를 수락 조건으로 쓴다(규격보다 엄격).
**v0.2 결정** · §11.2 에 "계획한 축만 바뀌었다"를 수락 조건으로 적는다.

## C-15 · POC B 앵커 장면

**무엇** · 씨앗은 구조만 있고 장면 글이 없다. 판정자가 변형을 무엇과 비교하는지 규격에 없다.
**근거** · 보존 판정을 A1 · A2 와 **같은 과제**(두 장면 비교)로 만들어야 A2 에서 검증한 판정자를 B 에 쓸 수 있다.
**v0.1 우회** · 생성 파이프라인이 씨앗마다 앵커를 먼저 만든다.
**v0.2 결정** · §11.2 에 앵커 단계를 적는다. **앵커 14개는 사람이 한 번 확인한다**(씨앗 core 와 맞는지). 사람 작업이 하나 는다.

## C-16 · 문턱 0.6 의 인접 준거 문구

**무엇** · 동결 규격 §(요약 84행)이 `Skill Identity κ 0.6` 의 근거로 **AMP κ .712/.715** 를 적는다.
이번에 1차 출처를 뒤졌더니 **그 두 값을 어디서도 찾지 못했다.**

**근거** · `01_EVIDENCE/EVIDENCE_LEDGER.csv` T1 · `EVIDENCE_LEDGER_SEARCH_LOG.md`

| | |
|---|---|
| 1차 출처 후보 | Collins, Lockton & Adams 2014 · J Commun Disord 52:31-43 · doi 10.1016/j.jcomdis.2014.07.001 |
| 전문 접근 | **불가.** Unpaywall `is_oa:false` · OpenAlex `closed` · Semantic Scholar `CLOSED` · CORE 전문 URL 없음 · ScienceDirect 403 |
| 초록에 있는 것 | "the AMP task had satisfactory internal consistency and inter-rater reliability" · **계수 없음** |
| 우리가 적어 둔 출처 | `research/AMP_TOPICC_검증.md` 는 Collins 2013 맨체스터 학위논문을 전문으로 읽었다고 적는다 |
| 그 논문 | **찾지 못했다.** CORE 학위논문 검색 11건 중 Collins 없음 · 맨체스터 학위논문 검색 403. **Adams 2018 참고문헌에도 없다** |
| 같은 표의 이웃 값 | Cronbach α .915 · Spearman ρ .595~.669 는 **Adams 2018 전문에 그대로 나온다.** 표 전체의 출처가 섞여 있다 |
| 전문 확인된 AMP 계수 | **κ .783** (Adams, Lockton & Collins 2018 · 비가중 Cohen κ · 응답 412건 · 전사 8건 · 평정자 2명) |

**v0.1 우회** · 규격 파일은 고치지 않는다. 대신 **운영 문서 쪽에서 .712/.715 인용을 뺐다.**
`STATISTICAL_DESIGN.md` · `A1_PROTOCOL.md` · `INSTRUCTOR_QA_50.md` · 보고서 모두 대조 결과로 바꿨다.

**v0.2 결정** · 두 가지를 정해야 한다.

1. **.712/.715 를 지운다.** 1차 출처가 없다. 남기려면 Collins 2014 전문을 구해 확인한 뒤여야 한다.
2. **무엇으로 대체할지 정한다.** 셋 다 모양이 다르다.
   - Adams 2018 **κ .783** · 비가중 Cohen κ 라 통계 종류는 맞다. **과제가 채점 지침 대조라 우리와 다르다**
   - Dillon 2021 PRS-SA **가중 κ .831** · 값은 확인됐다. **7점 척도 가중 · 1점 허용 · 평균이고 하한 .4917** 이라 직접 비교 불가
   - McHugh 2012 · "below 0.60 indicates inadequate agreement" · **규범 문헌이고 계수가 아니다**

**권고** · 3번만 남기고 0.6 을 **PROJECT OPERATING THRESHOLD** 로 명시한다.
숫자 준거를 붙이면 모양이 다른 것을 같은 것처럼 보이게 만든다. 그것이 이번에 우리가 한 실수다.


---

## 하지 않은 것

- **v0.1 파일 수정 · 없음.** `01_SPEC/` 세 파일의 해시가 RC1 매니페스트와 같다(verify-release 1번)
- Core 필드 수 변경 · 없음. C-01 은 v0.2 결정 규칙만 적었다
- 새 온톨로지 클래스 · 없음. 전부 속성 · wrapper · 화면이다
