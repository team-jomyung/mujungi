# 선행 시스템 / 경쟁 제품 매트릭스 — 사회적 의사소통 훈련

작성일: 2026-09-12
방법: 공식 제품 페이지, Apple App Store 검색 API, arXiv API, Europe PMC / PubMed API, 한국 임상연구정보서비스(CRIS)를 직접 조회. 2차 기사·블로그는 근거로 쓰지 않았다.

표기:
- **[확인]** — 1차 출처를 직접 조회해 확인
- **[미확인]** — 조회했으나 해당 항목이 출처에 없음. 없다는 뜻이 아니라 **확인하지 못했다**는 뜻
- **[NOT FOUND AFTER DEFINED SEARCH]** — 정해진 경로를 실제로 조회했으나 존재를 확인하지 못함. 시도 URL 명시

---

## 0. 요청받은 이름들의 확인 결과 — 먼저 정리

의뢰 목록 중 **네 개는 실체가 확인되지 않았다.** 이것부터 정리하고 간다.

| 이름 | 결과 | 근거 |
|---|---|---|
| **Social Ace** | **NOT FOUND AFTER DEFINED SEARCH** | `socialace.com` → GoDaddy 매물 페이지(307 리다이렉트). `socialace.ai` → DNS 미해석. App Store 검색 "Social Ace" → Bluesky·Truth Social·카지노 앱 등 무관 결과만. Europe PMC `"Social Ace" autism` → 0건 |
| **Noora (사회기술 훈련)** | **NOT FOUND AFTER DEFINED SEARCH** | `noora.ai` → Spaceship 도메인 매물. `noora.io` → 비밀번호 보호 페이지. `getnoora.com` → DNS 미해석. App Store "Noora" → 육아 트래커·성경 앱·상품 스캐너·Noora Health의 Care Companion. arXiv `abs:"Noora" AND abs:"social"` → 0건 |
| **Noora Health** | **[확인] — 완전히 다른 회사·다른 영역** | `noorahealth.org`. 인도·방글라데시·인도네시아·네팔에서 **병원 내 가족 간병인 교육**. "71% decrease in cardiac complications", "18% reduction in newborn mortality" 제시. 사회기술 훈련과 무관 |
| **SocialWise** | **[확인] — 다만 의뢰가 가리킨 대상과 다를 수 있음** | App Store에 동명이인 두 개. ① *Social App – SocialWise* (Burak Oztopuz, 2026-03-30 출시) — **채팅 스크린샷을 올리면 답장 문구를 추천**. ② *SocialWise: AI Social Content* (WEBOMAX BILISIM, 튀르키예) — **SNS 마케팅 카피 생성기**. Europe PMC `SocialWise social skills` → 0건. **임상/치료용 시스템은 확인되지 않음** |
| **Elemy** | **[확인] 서비스 도달 불가** | `elemy.com` HTTP 000 (연결 실패), `www.elemy.com` DNS 미해석(ENOTFOUND). 운영 중단으로 보이나 **공식 폐업 공지는 확인하지 못함** |

> 의뢰서에 "Noora Health는 다른 회사다 — 사회기술 Noora가 따로 있는지 확인하라"는 지시가 있었다. **확인한 범위에서는 따로 존재하지 않는다.** `noora.io`가 비밀번호로 잠겨 있어 완전 배제는 못 한다. 스텔스 단계 제품이거나, 이름이 잘못 전해졌을 가능성이 있다.

---

## 1. 매트릭스 A — 정체성 / 대상 / 상태

| 시스템 | 유형 | 대상 집단 | 국가 | 현재 상태 | 1차 출처 |
|---|---|---|---|---|---|
| **NDTx-01** | 모바일 게임형 SST, 치료기기 지향 | **ASD 또는 SCD 진단 10–18세** | 🇰🇷 한국 | 파일럿 RCT 완료 (2024-01 종료) | PMID 40214154 / doi 10.1111/pcn.13824 / CRIS KCT0009140 |
| **AACessTalk** | 태블릿 AI 중재 커뮤니케이션 | **최소발화 자폐(MVA) 아동 + 부모 쌍** | 🇰🇷 한국 | 연구 프로토타입 (ACM CHI 2025) | arXiv 2409.09641v4 |
| **SocialCoach** | LLM 에이전트 튜터링 플랫폼 | **직장인** (협상·리더십) | 🇺🇸/🇨🇳 (MSRA 계열 저자) | 연구 + 배포 플랫폼 | arXiv 2606.04155v2 |
| **Yoodli** | AI 커뮤니케이션 코칭 SaaS | **기업 임직원** (영업·L&D·임원) | 🇺🇸 미국 | 상용 운영, Series B $40M | yoodli.ai |
| **Floreo** | VR 사회기술 훈련 | **신경다양성 학습자** (자폐 중심) | 🇺🇸 미국 | 상용 운영, FDA Breakthrough + TAP | floreovr.com |
| **EndeavorRx** | 처방형 디지털 치료기기 (게임) | **ADHD 8–17세** | 🇺🇸 미국 | 상용 판매 ($99/30일), FDA 승인 | endeavorrx.com |
| **Bearwith** | AI 롤플레이 소셜 코치 앱 | **내향적 성인** | 🇺🇸 (개발자 ilya libin) | App Store 등재. **2025-03-12 이후 미갱신** | App Store id6741406576 |
| **Goally** | 전용 태블릿 + 루틴 관리 앱 | **신경다양성 아동** | 🇺🇸 미국 | 상용 운영 (2026-06 갱신) | App Store id1262461227 |
| **Joon** | 게임형 루틴·과제 트래커 | **ADHD 등 신경다양성 6–12세** | 🇺🇸 미국 | 상용 운영 (2026-08 갱신) | App Store id1482225056 |
| **ChatAR** | AR HMD + LLM 실시간 대화 지원 | **일반 성인** (지식 격차 상황) | 🇯🇵 일본 | 연구 프로토타입 | arXiv 2506.16008 |
| **Social App – SocialWise** | 스크린샷 → 답장 추천 | **일반 소비자** | 🇹🇷 추정 | 상용 (2026-04 갱신) | App Store id6760758574 |
| **Social Wizard** | 스크린샷 → 답장 추천 | **일반 소비자** | 🇺🇸 (Kelechi Onyeama) | 상용 (2025-04 갱신) | App Store id6474789329 |
| **Gleam** | 사회지능 마이크로러닝 | **일반 소비자** (데이트·면접) | 🇺🇸 (C137 LLC) | 상용 (2026-09 갱신) | App Store id6745815058 |
| **NeuroCypher ASD** | 지식그래프 기반 ASD 선별 ML | **영유아** | [미확인] | 학술 (2026) | doi 10.1007/s41666-026-00243-x |
| Noora Health | 병원 가족 간병 교육 | 환자 가족 | 🇮🇳 외 3개국 | 운영 중 | noorahealth.org |
| Elemy | 자폐 케어(ABA) 플랫폼 | 자폐 아동 | 🇺🇸 미국 | **도달 불가** | elemy.com (HTTP 000) |

---

## 2. 매트릭스 B — 기술적 능력

핵심 질문: **사용자가 실제로 나눈 대화를 입력으로 받는가.** 이 프로젝트의 정체성이 걸린 칸이다.

| 시스템 | 본인의 **실제 대화**를 입력으로 받음 | 종단 기억 | 온톨로지/KG | RAG | 시뮬레이션·롤플레이 | 피드백 형태 |
|---|---|---|---|---|---|---|
| **NDTx-01** | ❌ 게임 내 시나리오 | [미확인] | [미확인] | [미확인] | ✅ 게임형 SST 시나리오 | 게임 내 수행 피드백 |
| **AACessTalk** | ✅ **실시간 실제 부모–아동 대화** | ❌ 세션 단위 | ❌ 맥락 어휘 카드 | [미확인] | ❌ 실제 대화 중재 | 부모에겐 실시간 대화 가이드, 아동에겐 어휘 카드 추천 |
| **SocialCoach** | ❌ 학습자 프로필 + **모의** 숙련도 상태 + 연습 이력 | ✅ 숙련도 상태 + 연습 이력 추적 | ✅ **추적 가능한 전략·사례 코퍼스** | ✅ **retrieval-constrained scheduling** | ✅ 목표 기반 연습 | 성찰형 튜터링(knowledge-grounded reflective tutoring) |
| **Yoodli** | ❌ (홈페이지 기준) 커스텀 AI 상대와 연습 | ✅ "tracks progress over time" | [미확인] | ❌ 조직이 자체 콘텐츠·방법론 업로드 | ✅ 멀티 페르소나 롤플레이 | 내용·전달·진행에 대한 실시간 인사이트, 정량 지표(pacing, conciseness) |
| **Floreo** | ❌ 스크립트 시나리오·비네트 | [미확인] | [미확인] | [미확인] | ✅ VR 몰입 시나리오 | 임상가·교사 매개 |
| **EndeavorRx** | ❌ 게임 수행 데이터 | ✅ Insight 앱으로 보호자에게 경과 제공 | ❌ | ❌ | ✅ 적응형 게임 | 수행 적응(난이도), 보호자 리포트 |
| **Bearwith** | ❌ AI 롤플레이 | ✅ "Track your progress" (자기 기술) | [미확인] | [미확인] | ✅ 일상 상황 롤플레이 | "gentle feedback and suggestions" |
| **Goally / Joon** | ❌ (대화 분석 아님) | ✅ 루틴 수행 이력 | ❌ | ❌ | ❌ | 루틴·과제 완수 강화 |
| **ChatAR** | ✅ **실시간 실제 대화** (키워드 인식) | ❌ | ❌ | ❌ LLM 생성 | ❌ | 대화 중 HMD로 정보 제시 (시선 노출 고려) |
| **SocialWise / Social Wizard** | ✅ **채팅 스크린샷 = 실제 대화** | ❌ 일회성 | ❌ | ❌ | ❌ | 톤 선택 기반 답장 문구 3개 이상 생성 |
| **Gleam** | ❌ | [미확인] | ❌ | ❌ | ❌ 마이크로 레슨 | 레슨형 |
| **NeuroCypher ASD** | ❌ | ❌ | ✅ **KG 기반 표현 학습** | ❌ | ❌ | 선별 분류 결과 |

---

## 3. 매트릭스 C — 검증 수준

여기가 가장 불편한 표다.

| 시스템 | 객관 평가 지표 | 전이(transfer) 검증 | 사람 검증 | RCT | 구현 공개 |
|---|---|---|---|---|---|
| **NDTx-01** | ✅ **K-Vineland-II ABC**(주), **SRS-2**, 불안, 양육스트레스(부) | ✅ **적응행동(Vineland ABC)** = 실생활 기능 대리지표 | ✅ 평가자 맹검, 다기관 | ✅ **평가자 맹검 무작위 대조 파일럿** (n=39 배정 / 38 분석) | ❌ 상용 비공개 |
| **AACessTalk** | ❌ 정량 1차 지표 없음. 대화 빈도·턴테이킹 증가 관찰 | ❌ | ✅ **2주 실사용 배포, 11 부모–아동 쌍** | ❌ | ✅ 논문 + 프로젝트 페이지 `naver-ai.github.io/aacesstalk` |
| **SocialCoach** | ✅ rubric-judge 기반 pairwise 선호, pathway-quality rating | ❌ **cold-start는 합성(synthetic) 설정** | ✅ human studies | ❌ | ✅ 논문 (arXiv) |
| **Yoodli** | ✅ 발화 분석 지표 (pacing 등) | ❌ | [미확인] | ❌ | ❌ |
| **Floreo** | [미확인] | [미확인] | [미확인] — "clinicians and therapists" 개발 참여 주장 | [미확인] — 홈페이지에 구체 시험 데이터 없음 | ❌ |
| **EndeavorRx** | ✅ **TOVA** (주의력 컴퓨터 검사) | 부분 — 보호자 보고 기반 일상 개선 (68%/73%) | ✅ | ✅ **RCT 근거로 FDA 승인** | ❌ |
| **Bearwith** | ❌ | ❌ | ❌ | ❌ | ❌ |
| **NeuroCypher ASD** | ✅ 분류 성능 | ❌ | [미확인] | ❌ | [미확인] |
| **SocialWise / Social Wizard / Gleam** | ❌ | ❌ | ❌ | ❌ | ❌ |

---

## 4. 개별 시스템 상세

### 4.1 NDTx-01 — 가장 직접적인 국내 경쟁 상대

**[확인] 출처:** Yoo JH, Lee EY, … Joung YS. *Effectiveness of a mobile application game (NDTx-01) in enhancing social communication skills in adolescents with autism spectrum disorder or social communication disorder: A randomized controlled pilot trial.* Psychiatry Clin Neurosci. 2025. PMID 40214154, doi 10.1111/pcn.13824. 등록번호 KCT0009140.

- **개발사: Neudive Inc, 대구** (논문 소속기관 목록에서 확인)
- 수행기관: 삼성서울병원(책임연구자 정유숙 교수), 대구가톨릭대 의대 정신과, 서울성모병원, 가톨릭대 대학원. 보건복지부 재원.
- 설계: multicenter, parallel, **open-label, assessor-blinded**, RCT pilot
- 개입: TAU 대비 **TAU + NDTx-01, 1회 10분 × 주 5회 × 6주** (총 30세션, Android)
- 결과 [원문 인용]: *"the INT + TAU group (n = 19, 16 males; age, 13.42 ± 2.36 years) exhibited significant improvements (INT + TAU 5.89 ± 5.61 vs TAU 1.21 ± 5.99) in the ABC (P = 0.037)"*, SRS-2 제한적 관심·반복행동 영역에서 *(-9.11 ± 10.26 vs -2.89 ± 7.13, P = 0.037)*. 이상반응 없음.
- 저자 본인들의 한계 진술 [원문 인용]: *"A further confirmatory study with power estimate is required to validate the effects of NDTx-01."*

**의미:** 한국에서 ASD/SCD 청소년 대상 사회적 의사소통 개입이 **이미 무작위 대조 시험을 통과했다.** 우리가 "한국 최초"류의 표현을 쓸 수 있는 공간은 없다. 다만 NDTx-01은 **게임 시나리오** 기반이고 사용자의 실제 대화를 입력으로 받지 않는다. 그 축은 비어 있다.

**주의:** 별도 문서(`08_ETHICS/KOREA_PRIVACY_IRB_REVIEW.md` 9절)에 적었듯, NDTx-01은 치료기기 궤도에 있는 제품이다. 우리 제품을 "NDTx-01 같은 것"으로 소개하면 의료기기법 제2조제1항제2호·제26조제7항 사정권으로 스스로 들어간다.

### 4.2 AACessTalk — 실제 대화를 다루는 국내 연구

**[확인] 출처:** arXiv 2409.09641v4, ACM CHI 2025. 저자: Dasom Choi, SoHyun Park, Kyungah Lee, Hwajung Hong, **Young-Ho Kim** (KAIST + NAVER AI Lab). 프로젝트 페이지 `naver-ai.github.io/aacesstalk`.

[원문 인용] *"AACessTalk provides real-time guides to the parent to engage the child in conversation and, in turn, recommends contextual vocabulary cards to the child. Through a two-week deployment study with 11 MVA child-parent dyads…"*

- 결과: 모든 쌍에서 높은 참여, **대화 빈도와 턴테이킹 증가**, 부모의 상호작용 전략 탐색 촉진, 아동의 발화 주도성 증가.
- **실제 대화를 다룬다는 점에서 우리와 가장 가깝다.** 다만 (a) 실시간 **중재**이지 사후 **코칭**이 아니고, (b) 최소발화 자폐 아동–부모 쌍이라는 매우 좁은 대상이며, (c) 종단 기억 구조가 시스템 특징으로 기술돼 있지 않다.

### 4.3 SocialCoach — 기술 스택이 가장 많이 겹친다

**[확인] 출처:** arXiv 2606.04155v2 (2026-06). 저자 12인 (Jianxun Lian, Nicholas Jing Yuan, Qi Zhang 등 — MSRA 계열 저자 구성).

[원문 인용] *"SocialCoach constructs a theory-to-practice corpus of traceable strategies, cases, and practice scenarios, and uses this corpus for both scheduling and reflective tutoring. We formulate social practice personalization as cold-start, retrieval-constrained sequential practice scheduling. … we optimize complete pathways with trajectory-level GRPO using rubric-judge based pairwise preferences. Additionally, we instantiate the scheduling approach in a deployed platform with goal-driven practice and knowledge-grounded reflective tutoring."*

**우리 설계와 겹치는 것:** 이론→실천 코퍼스(온톨로지 역할), 검색 제약 기반 개인화(RAG), 성찰형 튜터링, LLM 심판 기반 평가(rubric-judge), 배포 플랫폼.

**겹치지 않는 것:** 대상이 **직장인 협상·리더십**이고, 입력이 **모의 숙련도 상태**다. 실제 대화를 읽지 않는다. 그리고 cold-start 실험은 **합성 설정**이다.

[해석] 이 논문은 "우리 아키텍처가 새롭다"는 주장을 가장 강하게 무력화한다. 아키텍처가 아니라 **입력(실제 대화)과 도메인(사회적 의사소통 곤란)**에서 차별화를 찾아야 한다.

### 4.4 Yoodli / Floreo / EndeavorRx — 인접 상용 3종

- **Yoodli** [확인]: *"private, real-time, and judgment-free roleplay coaching"*. 멀티 페르소나 롤플레이, 시간에 따른 진행 추적, pacing·conciseness 등 정량 지표. SOC 2 Type 2, GDPR. Series B $40M, 밸류 $300M. **홈페이지 기준으로는 사용자 본인 녹음을 올리는 방식이 아니라 시뮬레이션 연습 방식이다.** (과거 버전의 기능 범위는 이번에 확인하지 않았다 — 홈페이지 한 페이지만 조회한 결과다.)
- **Floreo** [확인]: `floreotech.com` → `floreovr.com`으로 301 이전. Meta Quest 2/3/Pro, PICO 시리즈, iPhone+Cardboard. **FDA Breakthrough Device 지정 + TAP 프로그램 편입.** 홈페이지에 구체적 임상시험 수치는 없다.
- **EndeavorRx** [확인]: Akili Interactive Labs. ADHD 8–17세, **처방형**. TOVA로 측정한 주의 기능 개선. 보호자 68%·아동 73% 개선 보고. $99/30일. **대상 질환이 ADHD 주의력이라 사회적 의사소통과는 다르다.** 디지털 치료기기의 규제·상업 경로 참고용.
  - [미확인] Akili의 현재 기업 상태(합병·사업 축소 여부)는 이번 세션에서 확인하지 않았다. 사이트는 살아 있고 저작권 표기는 2025년이다.

### 4.5 소비자 앱 계층 — 과소평가하면 안 되는 쪽

**[확인]** App Store에 **채팅 스크린샷을 올리면 답장을 추천해 주는 앱**이 여럿 상용화돼 있다.

- *Social App – SocialWise* [원문 인용]: *"Take a screenshot of any chat or social media post / Choose your intent: Reply, Start a Conversation, or Apologize / Pick your tone: Confident, Friendly, Witty, Charming, Casual, Formal, Flirty, or Sarcastic / Get 3+ personalized message suggestions instantly"*
- *Social Wizard* [원문 인용]: *"Upload a chat screenshot or type in manually, select one of 10 tonalities… Help with awkward situations: Provide us with the situation details and we'll offer the best advice!"*
- *Bearwith – social skills coach* [원문 인용]: *"Engage in realistic role-play scenarios that simulate everyday social interactions / Receive gentle feedback and suggestions from our AI communication coach"*
- *Gleam: Social Intelligence*, *Make Me Social*, *Social Skills Builder – Convo*, *Volo* 등 다수.

[해석] **"사용자의 실제 대화를 입력으로 받는다"는 축은 이미 상용화되어 있다.** 다만 이들은 전부 **일회성 답장 생성기**다. 이력을 쌓지 않고, 근거 코퍼스가 없고, 패턴을 말해 주지 않는다. 우리가 지킬 수 있는 차별점은 "실제 대화를 받는다"가 아니라 **"받은 다음에 무엇을 하는가"**다.

### 4.6 비판적 선행 연구 — 프레이밍 리스크

**[확인]** Naba Rizvi, *Data-Driven and Participatory Approaches toward Neuro-Inclusive AI*, arXiv 2507.21077 (UC San Diego 박사학위논문, 2025-06).

[원문 인용] *"Biased data representation in AI marginalizes up to 75 million autistic people worldwide through medical applications viewing autism as a **deficit of neurotypical social skills** rather than an aspect of human diversity… Our work finds that **90% of human-like AI agents exclude autistic perspectives**, and AI creators continue to believe ethical considerations are beyond the scope of their work."*

[해석] 이 논문은 경쟁자가 아니라 **우리 제품 서사에 대한 사전 반론**이다. "사회적 의사소통을 교정한다"는 프레이밍 자체가 결함 모델(deficit model)로 읽힐 수 있다. 발표·논문·제품 카피에서 이 지적에 대한 입장을 미리 준비해 두는 편이 낫다. 실제로 심사자·리뷰어가 이 지점을 찌를 확률이 높다.

---

## 5. 차별화 — 정직한 판정

우리가 내세우려 했던 차별점을 하나씩 위 증거와 대조한다. **"세계 최초"·"유일한 시스템" 같은 표현은 쓰지 않는다.** 아래 판정은 확인한 범위에서의 결론이며, 확인하지 못한 시스템이 존재할 수 있다.

| 주장하려던 차별점 | 판정 | 근거 |
|---|---|---|
| **사용자의 실제 대화를 입력으로 받는다** | ❌ **살아남지 못함** | SocialWise·Social Wizard가 채팅 스크린샷으로 이미 한다. ChatAR은 실시간 실제 대화를 처리한다. AACessTalk은 실제 부모–아동 대화를 중재한다 |
| **롤플레이 / 시뮬레이션 연습** | ❌ **살아남지 못함** | Yoodli(멀티 페르소나), Bearwith, SocialCoach, Floreo(VR), NDTx-01(게임) 전부 한다 |
| **RAG 기반 근거 있는 피드백** | ❌ **살아남지 못함** | SocialCoach가 명시적으로 *retrieval-constrained* 스케줄링 + *knowledge-grounded* 튜터링을 한다 |
| **온톨로지 / 지식그래프 활용** | ⚠️ **약함** | SocialCoach의 *traceable strategies·cases* 코퍼스가 사실상 같은 역할. NeuroCypher ASD는 ASD 도메인에서 KG 표현학습을 쓴다. 단독으로는 차별점이 아니다 |
| **한국어 / 한국 문화 맥락** | ❌ **살아남지 못함** | NDTx-01(Neudive, 대구)과 AACessTalk(KAIST·NAVER) 둘 다 한국 팀·한국 대상이다 |
| **종단 기억(longitudinal memory)** | ⚠️ **범위를 좁히면 살아남음** | Yoodli는 진행 추적, SocialCoach는 숙련도 상태 + 연습 이력을 유지한다. 다만 **"사용자 본인의 실제 대화 이력 위에" 종단 기억을 쌓는 시스템은 확인되지 않았다.** 이 형태로 좁혀야 성립 |
| **국립국어원 맥락추론 말뭉치 grounding** | ✅ **살아남음 (가장 강함)** | 한국어 화용·맥락추론 코퍼스에 피드백을 접지하는 시스템을 확인하지 못했다. SocialCoach의 코퍼스는 자체 구축 전략·사례이고 한국어 화용 자원이 아니다. **단, "존재하지 않는다"가 아니라 "찾지 못했다"로 서술할 것** |
| **객관적 평가 / 전이 검증** | ❌ **오히려 뒤처짐. 강점으로 쓸 수 없음** | NDTx-01은 평가자 맹검 RCT에서 **K-Vineland-II 적응행동**과 SRS-2로 검증했다(p=0.037). 우리 유사도 판정기는 AUC 약 0.58로 **우연 수준에 가깝다.** 이 상태에서 "객관적 평가 체계를 갖췄다"고 말하면 대조 즉시 무너진다 |

### 5.1 그래서 남는 것 — 한 문장으로

[해석] 방어 가능한 위치는 이것 하나로 좁혀진다.

> **사용자가 실제로 겪은 대화를 사후에 받아, 한국어 맥락추론 자원에 접지해 해석하고, 그 이력을 종단으로 누적해 반복 패턴을 돌려주는 것.**

각 요소는 개별적으로 새롭지 않다. 새로운 것은 **결합**이고, 특히 **"실제 대화 × 한국어 화용 자원 × 종단 누적"** 세 개가 동시에 걸린 시스템을 확인하지 못했다는 점이다. 요소 하나를 떼어내 자랑하면 반드시 대조당한다.

### 5.2 쓰면 안 되는 표현 / 쓸 수 있는 표현

| ❌ 쓰지 말 것 | ✅ 대신 이렇게 |
|---|---|
| "세계 최초의 사회적 의사소통 AI 코치" | "확인한 범위에서, 실제 대화 이력을 한국어 맥락추론 자원에 접지해 종단 분석하는 시스템은 찾지 못했다" |
| "실제 대화를 입력으로 받는 유일한 시스템" | "기존 앱들이 일회성 답장 생성에 그치는 데 비해, 이력을 누적해 패턴을 돌려준다" |
| "국내 최초 한국어 사회성 훈련 AI" | "NDTx-01(Neudive, RCT 완료)과 AACessTalk(KAIST·NAVER)에 이어, 실제 대화 입력이라는 다른 축을 다룬다" |
| "객관적으로 검증된 평가 체계" | "유사도 판정기 AUC 0.58 — 관련성 판정(0.86+)과 달리 아직 우연 수준에 가깝다. 현재 한계로 명시한다" |
| "임상적 효과" | "n명 참여 사용성 테스트 결과" (RCT가 없으므로 효과 주장 금지) |

### 5.3 가장 위협적인 세 곳

[해석] 심사·투자·리뷰에서 우리를 무너뜨릴 순서.

1. **NDTx-01** — 같은 나라, 같은 문제, **RCT 통과**. "그쪽은 무작위 대조 시험을 했는데 당신들은?"이 첫 질문일 것이다. 대답은 "우리는 다른 입력(실제 대화)을 다루며 현 단계는 PoC"여야 하고, 효과 주장을 하지 않는 것이다.
2. **SocialCoach** — 우리 아키텍처 설명과 문장 단위로 겹친다. 아키텍처 신규성을 주장하는 슬라이드가 있다면 지금 고쳐야 한다.
3. **소비자 앱 계층(SocialWise·Social Wizard 등)** — "실제 대화를 받는다"는 한 줄짜리 차별화를 App Store 검색 30초로 무력화한다.

---

## 6. 확인하지 못한 것 / 다음 작업

| 항목 | 이유 | 다음 경로 |
|---|---|---|
| `noora.io` 실체 | 비밀번호 보호 | 직접 문의하거나 회사명으로 재검색 |
| Elemy 폐업 공식 확인 | 도메인 도달 불가, 공지 없음 | 미국 법인 등록부 / 언론 |
| Akili(EndeavorRx) 기업 현황 | 이번 세션 미조회 | SEC 공시 |
| Floreo 임상 근거 | 홈페이지에 수치 없음 | PubMed에서 Floreo 저자 검색 |
| Yoodli의 실제 녹음 업로드 기능 유무 | 홈페이지 1페이지만 조회 | 제품 문서 / 요금제 페이지 |
| 국립국어원 맥락추론 말뭉치를 쓴 타 시스템 | 한국어 학술 DB 미조회 | KCI, RISS, DBpia |
| Google Play 전용 앱 | Apple App Store API만 사용 | Play Console 검색 |

> **한계 고지:** Apple App Store 검색 API는 미국 스토어 기준이며 키워드당 상위 6–8건만 확인했다. arXiv·Europe PMC는 영문 위주다. **한국어 학술 DB(KCI/RISS/DBpia)와 Google Play는 이번 조사 범위에 들어가지 않았다.** 위 "살아남음" 판정은 이 범위 안에서의 결론이다.

---

## 부록 — 재현 방법

```
# 논문
https://www.ebi.ac.uk/europepmc/webservices/rest/search?query=DOI:"<doi>"&format=json&resultType=core
https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&id=<pmid>&retmode=xml   # 소속기관
http://export.arxiv.org/api/query?id_list=<arxiv_id>
http://export.arxiv.org/api/query?search_query=abs:"<term>"&max_results=12&sortBy=submittedDate&sortOrder=descending

# 앱 실체 확인 (인증 불필요)
https://itunes.apple.com/search?term=<term>&entity=software&limit=8&country=US

# 도메인 생존 확인
curl -sL --max-time 20 -o /dev/null -w "%{http_code}" https://<domain>/
```
