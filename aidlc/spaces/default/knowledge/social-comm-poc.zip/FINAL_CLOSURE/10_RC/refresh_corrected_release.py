# -*- coding: utf-8 -*-
"""배포본 사본을 원본에서 다시 뜨고 README 를 실측으로 만든다.

    python 10_RC/refresh_corrected_release.py

왜 있나
  README 에 크기 · 파일 수 · SHA256 을 손으로 적어 두었다. 배포본을 다시 만들면
  그 셋이 조용히 틀린다. ERR-04 · ERR-05 · ERR-06 이 전부 같은 계열이다.
  값을 적지 않고 잰다.
"""
from __future__ import annotations

import hashlib
import io
import os
import shutil
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, 'corrected_release')
SRC = os.path.normpath(os.path.join(HERE, '..', '..', 'poc_validation_v0_1_RC1.zip'))
NAME = 'poc_validation_v0_1_RC1.zip'


def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def main():
    if not os.path.exists(SRC):
        raise SystemExit('원본 배포본이 없다 · %s\n  poc_validation_v0_1 에서 tests/make_release.py 를 먼저 돌린다' % SRC)
    if not os.path.isdir(OUT):
        os.makedirs(OUT)
    dst = os.path.join(OUT, NAME)
    shutil.copy2(SRC, dst)

    size = os.path.getsize(dst)
    digest = sha256(dst)
    with zipfile.ZipFile(dst) as z:
        n_files = sum(1 for i in z.infolist() if not i.is_dir())
    mtime = __import__('time').strftime('%Y-%m-%d %H:%M', __import__('time').localtime(os.path.getmtime(dst)))

    io.open(os.path.join(OUT, 'SHA256SUMS.txt'), 'w', encoding='utf-8', newline='\n').write(
        '%s  %s\n' % (digest, NAME))

    L = ['# corrected_release', '',
         'ERR-01 ~ ERR-06 을 고친 뒤 다시 만든 RC1 배포본이다. `tests/make_release.py` 가 만들었고',
         '`python poc.py verify-release --zip ../poc_validation_v0_1_RC1.zip` **여덟 항목**을 통과했다.',
         '실행 기록은 `../VERIFY_RELEASE_RESULT.md`.', '',
         '**이 표의 값은 손으로 적지 않는다.** `refresh_corrected_release.py` 가 파일을 재서 쓴다.', '',
         '| | 값 |', '|---|---|',
         '| 파일 | `%s` |' % NAME,
         '| 크기 | %s bytes |' % format(size, ','),
         '| archive 안 파일 수 | %d |' % n_files,
         '| SHA256 | `%s` |' % digest,
         '| 만든 시각 | %s |' % mtime, '',
         '```',
         'sha256sum -c SHA256SUMS.txt',
         '```', '',
         '이 zip 은 원본 `../../../%s` 와 **같은 바이트**다. 두 곳에 두는 이유는' % NAME,
         'FINAL_CLOSURE 만 넘겨도 배포본이 함께 가게 하려는 것이다.',
         '`tests/check_numbers.py` 4번이 두 파일의 해시가 같은지 매번 본다.', '',
         '## 이 판에서 달라진 것', '',
         '| | |', '|---|---|',
         '| 8번 검사 추가 | `tests/consistency.py` · 숫자와 파일 이름이 문서·코드끼리 맞는가. 체크섬이 못 잡는 계열 |',
         '| 숫자의 출처 하나 | `02_POC_A/a1_counts.json` · 규격 v0.1 값과 RC1 실행 값을 나란히 |',
         '| 파일 이름 통일 | 선별기가 내려 주는 `blind_selected_for_raters.csv` 를 정본으로 |',
         '| blind 후보 도구 | `merge_blind_batches.py` · `check_blind_overlap.py` (본문을 찍지 않는다) |',
         '| 배포 문서의 파일 수 | 템플릿에 박힌 91 · 94 를 실측으로 |',
         '| **ERR-06** | 옛 시뮬레이션 수치 두 곳 수정 · **파일 단위 면제를 줄 단위로 좁힘** |',
         '']
    io.open(os.path.join(OUT, 'README.md'), 'w', encoding='utf-8', newline='\n').write('\n'.join(L))
    print('corrected_release · %s · %s bytes · 파일 %d · %s'
          % (NAME, format(size, ','), n_files, digest[:16]))


if __name__ == '__main__':
    main()
