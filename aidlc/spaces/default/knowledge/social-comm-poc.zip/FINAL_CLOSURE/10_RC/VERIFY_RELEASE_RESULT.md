# VERIFY-RELEASE 실행 기록

2026-09-14 · **ERR-06 수정 뒤 재빌드한 배포본**으로 다시 돌린 결과다. 실제 출력 그대로다.

ERR-06 은 FINAL_CLOSURE 쪽 문서가 옛 시뮬레이션 수치를 인용하던 문제였는데,
훑어 보니 **이 꾸러미 안에도 두 곳**이 있었다.

| 파일 | 무엇 | 왜 안 걸렸나 |
|---|---|---|
| `00_README/ISSUES_FOR_V0_2.md` | 확률 0.13 · 0.81 | **파일 단위로 면제돼 있었다.** 규격 값 인용 한 줄 때문에 파일 전체가 검사 밖에 있었다 |
| `02_POC_A/blind_set_generator_prompt.md` | 확률 0.13 | 옛 문장 목록에 없던 표현이었다 |

둘 다 고치고, 면제를 **파일 단위에서 줄 단위로 좁혔다.** 면제 파일이 5개에서 4개로 줄었다.
옛 문장 3종을 `tests/consistency.py` 에 더했다.

## 실행한 명령

```
cd poc_validation_v0_1
python tests/make_release.py                 # 재빌드
python poc.py verify-release --zip ../poc_validation_v0_1_RC1.zip
```

종료 코드 **0**.

```
  1 체크섬                    ok 100줄 · 맞음 100 · 다름 0 · 없음 0
  2 단위 시험                  ok 
  3 문서 감사                  ok 
  4 꾸러미 빌드                 ok 
  5 누출 검사                  ok 
  6 역할 ZIP                 ok 역할 7 · ZIP 6 · admin 제외
  7 매니페스트 = archive        ok 매니페스트 97 · archive 100 · 매니페스트에만 0 · archive에만 0
  8 숫자 · 인터페이스             ok 
============================================================
  여덟 항목 전부 통과

  통과해도 POC 는 아무것도 검증하지 않았다. 도구가 온전하다는 뜻뿐이다.
```

## 8번 항목의 상세

```
============================================================
  숫자 · 인터페이스 일치 검사
============================================================
  1 인터페이스      ok 선별기 = a1_counts · blind_selected_for_raters.csv
  1 인터페이스      ok 읽는 쪽 3개가 a1_counts.json 을 읽는다
  2 등록 숫자      ok 11개 문장 · 어긋남 0
  3 옛 문장       ok 남은 것 0 · 면제 파일 4 · 면제 줄 3
  4 산술         ok 5개 규칙 · 어긋남 0

  면제 파일 4 · 옛 숫자를 가져도 되는 파일
    01_SPEC/frozen_spec_v0_1.html · 동결 규격. 고치지 않는다
    02_POC_A/a1_counts.json · 옛 파일 이름을 호환 목록으로 가진다
    tests/consistency.py · 옛 문장 목록을 들고 있는 이 검사 자신
    tests/PHASE1_AUDIT_REPORT.md · 1단계 감사 당시 기록
  면제 줄 3 · 규격 v0.1 값을 일부러 인용한 줄
    00_README/HUMAN_ACTIONS.md:38
    00_README/ISSUES_FOR_V0_2.md:139
    02_POC_A/blind_set_authoring_protocol.md:9

  규격 v0.1 blind 20쌍 · RC1 실행 blind 40쌍 · 차이는 a1_counts.json deviation_from_spec
  판정 · 통과
```

면제 파일이 하나 줄고 면제 줄이 하나 늘었다. **줄 단위가 더 좁다.**
그 파일의 나머지 줄은 이제 검사를 받는다.

---

## 앞선 기록 · ERR-05 수정 직후

2026-09-12 · **실제로 돌린 출력 그대로다.** 요약해서 옮기지 않았다.

**ERR-05 수정 뒤 재빌드한 배포본**으로 다시 돌린 결과다. 8번 항목(숫자 · 인터페이스)이 이번에 추가됐다.

## 실행한 명령

```
cd poc_validation_v0_1
python poc.py verify-release --zip ../poc_validation_v0_1_RC1.zip
```

종료 코드 **0**.

## 대상 배포본

| | 값 |
|---|---|
| 파일 | `poc_validation_v0_1_RC1.zip` |
| 크기 | 321,117 bytes |
| 수정 시각 | 2026-09-14 11:06 |
| SHA256 | `09fab520fea92df7a3600b46494921843f8d2819e0da194a050935df3d770898` |

## 출력 전문

```
test_delete_reduces_aggregate (__main__.TestAggregation.test_delete_reduces_aggregate) ... ok
test_min_sample_guard (__main__.TestAggregation.test_min_sample_guard) ... ok
test_no_trait_nodes (__main__.TestAggregation.test_no_trait_nodes)
사람을 규정하는 노드를 만들지 않는다. ... ok
test_traceability (__main__.TestAggregation.test_traceability) ... ok
test_bad_change_flag_raises (__main__.TestInputValidation.test_bad_change_flag_raises) ... ok
test_bad_value_raises (__main__.TestInputValidation.test_bad_value_raises) ... ok
test_missing_core_raises (__main__.TestInputValidation.test_missing_core_raises) ... ok
test_all_ten_rules_present (__main__.TestPIIRedaction.test_all_ten_rules_present) ... ok
test_no_mind_reading_phrases (__main__.TestPIIRedaction.test_no_mind_reading_phrases) ... ok
test_raw_input_not_retained_by_default (__main__.TestPIIRedaction.test_raw_input_not_retained_by_default) ... ok
test_save_gated_by_checkbox (__main__.TestPIIRedaction.test_save_gated_by_checkbox) ... ok
test_stoplist_exists (__main__.TestPIIRedaction.test_stoplist_exists) ... ok
test_all_same_is_same (__main__.TestSkillIdentity.test_all_same_is_same) ... ok
test_invariant_perform_same_implies_understand_same (__main__.TestSkillIdentity.test_invariant_perform_same_implies_understand_same)
§11.1 불변식. 무작위 조합으로 확인한다. ... ok
test_one_different_is_different (__main__.TestSkillIdentity.test_one_different_is_different) ... ok
test_perform_only_field_splits_stages (__main__.TestSkillIdentity.test_perform_only_field_splits_stages)
Core 5 만 다르면 이해는 SAME, 수행은 DIFFERENT. ... ok
test_perform_only_unknown_splits_stages (__main__.TestSkillIdentity.test_perform_only_unknown_splits_stages) ... ok
test_unknown_beats_different (__main__.TestSkillIdentity.test_unknown_beats_different)
모르면 다르다고 말하지 않는다. UNDETERMINED 가 우선이다. ... ok
test_core_count_is_five (__main__.TestSpecConsistency.test_core_count_is_five) ... ok
test_engine_matches_json_rules (__main__.TestSpecConsistency.test_engine_matches_json_rules) ... ok
test_form_has_all_core_fields (__main__.TestSpecConsistency.test_form_has_all_core_fields) ... ok
test_guideline_asks_exactly_core_five (__main__.TestSpecConsistency.test_guideline_asks_exactly_core_five) ... ok
test_only_one_threshold_claims_external_reference (__main__.TestSpecConsistency.test_only_one_threshold_claims_external_reference) ... ok
test_thresholds_mark_evidence_basis (__main__.TestSpecConsistency.test_thresholds_mark_evidence_basis) ... ok
test_constraint_change_alone_is_not_far (__main__.TestTransferDistance.test_constraint_change_alone_is_not_far)
관계가 그대로면 대가만 바뀌어도 FAR 가 아니다. ... ok
test_constraint_unknown_stops_at_near (__main__.TestTransferDistance.test_constraint_unknown_stops_at_near)
I-02 · context_constraints 만 모르면 NEAR 에서 멈춘다. ... ok
test_far_needs_both (__main__.TestTransferDistance.test_far_needs_both) ... ok
test_near_on_relationship_change (__main__.TestTransferDistance.test_near_on_relationship_change) ... ok
test_near_on_situation_change (__main__.TestTransferDistance.test_near_on_situation_change) ... ok
test_not_computed_when_identity_not_same (__main__.TestTransferDistance.test_not_computed_when_identity_not_same) ... ok
test_relationship_unknown_makes_distance_undetermined (__main__.TestTransferDistance.test_relationship_unknown_makes_distance_undetermined) ... ok
test_same_context (__main__.TestTransferDistance.test_same_context) ... ok
test_supporting_fields_do_not_block (__main__.TestUserGoalDoesNotBlock.test_supporting_fields_do_not_block) ... ok
test_user_goal_is_not_an_input (__main__.TestUserGoalDoesNotBlock.test_user_goal_is_not_an_input)
user_goal 은 어느 축의 입력도 아니다(§4.3). ... ok

----------------------------------------------------------------------
Ran 34 tests in 0.021s

OK
감사 대상 파일 83개

  ok frozen spec 와 다른 규칙을 새로 넣었나
  ok Core 가 다섯보다 늘거나 줄었나
  ok Skill Identity 와 Transfer Distance 를 한 통계로 섞었나
  ok LLM 판정을 gold 라고 불렀나
  ok synthetic data 를 validation data 라고 불렀나
  ok SCD 임상 효과를 암시했나
  ok ASD 근거를 SCD 직접 근거처럼 썼나
  ok user_goal UNKNOWN 을 오류로 취급했나
  ok 상대 의도를 단정하는 문구가 있나
  ok 제3자 PII 를 저장하게 했나
  ok 운영 기준 문턱을 문헌 근거처럼 썼나
  ok DEMO 산출물이 검증 결과처럼 보이나
  ok API 키가 코드에 박혀 있나

========================================================
  지적 0건
========================================================
dist/ 를 만들었다 · C:\Users\baikj\Desktop\social-comm-poc\poc_validation_v0_1\dist

   admin                넣음 1   
   blind_selector       넣음 8   
 ! rater_A              넣음 2   · 못 넣음 1
                        · 판정할 쌍 파일이 아직 없다.
 ! rater_B              넣음 2   · 못 넣음 1
                        · 판정할 쌍 파일이 아직 없다.
   poc_c_operator       넣음 16  
   poc_c_participant    넣음 3   
   expert_review        넣음 6   

  역할별 ZIP
    dist/blind_selector_RC1.zip         파일 9   28,372 bytes
    dist/expert_review_RC1.zip          파일 7   40,680 bytes
    dist/poc_c_operator_RC1.zip         파일 17  51,360 bytes
    dist/poc_c_participant_RC1.zip      파일 4   12,846 bytes
    dist/rater_A_RC1.zip                파일 3   14,094 bytes
    dist/rater_B_RC1.zip                파일 3   14,090 bytes
    admin 은 본 묶음과 같아 따로 압축하지 않는다

========================================================
  누출 검사 · 지적 0건
========================================================
  역할별로 가면 안 되는 것이 가지 않았다.

  면제 7건 · leakcheck-ok 표시가 있는 줄은 넘어갔다.
  도구가 금칙어 목록을 들고 있어서다. 면제 수가 늘면 이유를 확인한다.

============================================================
  숫자 · 인터페이스 일치 검사
============================================================
  1 인터페이스      ok 선별기 = a1_counts · blind_selected_for_raters.csv
  1 인터페이스      ok 읽는 쪽 3개가 a1_counts.json 을 읽는다
  2 등록 숫자      ok 11개 문장 · 어긋남 0
  3 옛 문장       ok 남은 것 0 · 면제 파일 5 · 면제 줄 2
  4 산술         ok 5개 규칙 · 어긋남 0

  면제 파일 5 · 옛 숫자를 가져도 되는 파일
    00_README/ISSUES_FOR_V0_2.md · 규격 문장을 그대로 인용한다
    01_SPEC/frozen_spec_v0_1.html · 동결 규격. 고치지 않는다
    02_POC_A/a1_counts.json · 옛 파일 이름을 호환 목록으로 가진다
    tests/consistency.py · 옛 문장 목록을 들고 있는 이 검사 자신
    tests/PHASE1_AUDIT_REPORT.md · 1단계 감사 당시 기록
  면제 줄 2 · 규격 v0.1 값을 일부러 인용한 줄
    00_README/HUMAN_ACTIONS.md:38
    02_POC_A/blind_set_authoring_protocol.md:9

  규격 v0.1 blind 20쌍 · RC1 실행 blind 40쌍 · 차이는 a1_counts.json deviation_from_spec
  판정 · 통과

============================================================
  RELEASE 검증 · 여덟 항목
============================================================

── 2 단위 시험
   python -W ignore tests\test_all.py   (.)


── 3 문서 감사
   python tests\audit.py   (.)


── 4 꾸러미 · 5 누출 검사
   python tests\bundles.py build   (.)


── 8 숫자 · 인터페이스 일치
   python tests\consistency.py   (.)


============================================================
  1 체크섬                    ok 100줄 · 맞음 100 · 다름 0 · 없음 0
  2 단위 시험                  ok 
  3 문서 감사                  ok 
  4 꾸러미 빌드                 ok 
  5 누출 검사                  ok 
  6 역할 ZIP                 ok 역할 7 · ZIP 6 · admin 제외
  7 매니페스트 = archive        ok 매니페스트 97 · archive 100 · 매니페스트에만 0 · archive에만 0
  8 숫자 · 인터페이스             ok 
============================================================
  여덟 항목 전부 통과

  통과해도 POC 는 아무것도 검증하지 않았다. 도구가 온전하다는 뜻뿐이다.

```

## 읽는 법

여덟 항목 중 **7번과 8번이 이번에 추가된 것**이다.
매니페스트가 적은 파일 집합과 archive 안의 파일 집합이 **정확히 같은지** 본다.
ERR-03 이 다시 생기면 7번에서, ERR-04 · ERR-05 는 8번에서 잡힌다.

숫자 세 개가 서로 다른데 전부 맞다.

| 숫자 | 무엇 | 왜 다른가 |
|---|---|---|
| **97** | 매니페스트 `files` 배열 | 일반 산출물. `__pycache__` 는 `cache_excluded` 로 분리 |
| **100** | 체크섬 줄 수 · archive 파일 수 | 97 + 매니페스트 2 + `RC1_HANDOFF_FINAL.html` |
| **7 / 6** | 역할 폴더 / 역할 ZIP | `admin` 은 본 묶음과 같아 압축하지 않는다 |

**면제 7건**은 누출 검사 도구 자신이 금칙어 목록을 들고 있기 때문이다.
`leakcheck-ok` 표시가 있는 줄만 넘어간다. **면제 수가 늘면 이유를 확인해야 한다.**
이 프로젝트에서 자기참조 버그가 세 번 터졌기 때문에 수를 항상 화면에 찍는다.

## 이 통과가 말하지 않는 것

마지막 줄을 그대로 옮긴다.

> 통과해도 POC 는 아무것도 검증하지 않았다. 도구가 온전하다는 뜻뿐이다.

**판정자 0명 · 참가자 0명 · POC B 미시작.**
이 여덟 항목은 **도구가 깨지지 않았다**는 것만 보증한다.
