# corrected_release

ERR-01 ~ ERR-06 을 고친 뒤 다시 만든 RC1 배포본이다. `tests/make_release.py` 가 만들었고
`python poc.py verify-release --zip ../poc_validation_v0_1_RC1.zip` **여덟 항목**을 통과했다.
실행 기록은 `../VERIFY_RELEASE_RESULT.md`.

**이 표의 값은 손으로 적지 않는다.** `refresh_corrected_release.py` 가 파일을 재서 쓴다.

| | 값 |
|---|---|
| 파일 | `poc_validation_v0_1_RC1.zip` |
| 크기 | 345,090 bytes |
| archive 안 파일 수 | 103 |
| SHA256 | `6bf9bc90ebb90c4c0ed05dbb796bb2c99fa66dc8985bc97354a63e3b8e0deee9` |
| 만든 시각 | 2026-09-14 12:45 |

```
sha256sum -c SHA256SUMS.txt
```

이 zip 은 원본 `../../../poc_validation_v0_1_RC1.zip` 와 **같은 바이트**다. 두 곳에 두는 이유는
FINAL_CLOSURE 만 넘겨도 배포본이 함께 가게 하려는 것이다.
`tests/check_numbers.py` 4번이 두 파일의 해시가 같은지 매번 본다.

## 이 판에서 달라진 것

| | |
|---|---|
| 8번 검사 추가 | `tests/consistency.py` · 숫자와 파일 이름이 문서·코드끼리 맞는가. 체크섬이 못 잡는 계열 |
| 숫자의 출처 하나 | `02_POC_A/a1_counts.json` · 규격 v0.1 값과 RC1 실행 값을 나란히 |
| 파일 이름 통일 | 선별기가 내려 주는 `blind_selected_for_raters.csv` 를 정본으로 |
| blind 후보 도구 | `merge_blind_batches.py` · `check_blind_overlap.py` (본문을 찍지 않는다) |
| 배포 문서의 파일 수 | 템플릿에 박힌 91 · 94 를 실측으로 |
| **ERR-06** | 옛 시뮬레이션 수치 두 곳 수정 · **파일 단위 면제를 줄 단위로 좁힘** |
