# EVIDENCE LEDGER · 검색 로그

날짜 **2026-09-14** · 대상 **T1 (AMP κ .712/.715) · T2 (PRS-SA 가중 κ .831 · 4영역 23+5문항)**
산출물 `EVIDENCE_LEDGER.csv` (5행 × 11열)

이 세션은 **WebSearch 예산이 이미 소진된 상태**(200/200)로 시작했다. 그래서 키워드 검색 대신
**식별자 기반 직접 조회**만 썼다. 즉 PMID·DOI·PMCID를 알고 있는 대상에 대해 공개 API와 리포지토리를
직접 두드렸다. 아래가 실제로 두드린 전부다.

---

## 1 · 시작점

`ASSESSMENT_TOOL_MATRIX.csv` 에 두 도구의 PMID 가 이미 적혀 있었다. 이것을 진입점으로 썼다.

| 도구 | 기록된 식별자 | 결과 |
|---|---|---|
| AMP | PMID 25173072 | 맞았다. Collins, Lockton & Adams 2014 |
| PRS-SA | PMID 34388006 | 맞았다. Dillon, Holingue, Herman & Landa 2021 |

---

## 2 · 조회한 DB · 엔드포인트 · 질의

| # | DB / 엔드포인트 | 질의 | 결과 |
|---|---|---|---|
| 1 | PubMed HTML (`pubmed.ncbi.nlm.nih.gov`) | PMID 25173072, 34388006 | **실패.** 쿠키 월. WebFetch 가 본문 대신 쿠키 안내문만 받음 |
| 2 | **NCBI E-utilities** `efetch.fcgi` | `db=pubmed&id=25173072,34388006&rettype=abstract` | **성공.** 두 편 초록 전문 확보. 이 경로가 쿠키 월을 우회한다 |
| 3 | **PMC** `pmc.ncbi.nlm.nih.gov/articles/PMC8642082/` | PRS-SA 전문 | **성공.** HTTP 200, 232,655 bytes. 오픈액세스 |
| 4 | **PMC** `pmc.ncbi.nlm.nih.gov/articles/PMC4258293/` | Swineford 2014 전문 | **성공.** HTTP 200, 194,252 bytes |
| 5 | Semantic Scholar Graph API | `DOI:10.1016/j.jcomdis.2014.07.001` | `isOpenAccess: false`, `openAccessPdf.status: "CLOSED"` |
| 6 | **OpenAlex** | `works/doi:10.1016/j.jcomdis.2014.07.001` | `oa_status: closed`, `any_repository_has_fulltext: false`. 3개 location 전부 `is_oa: false` |
| 7 | **Unpaywall** | `10.1016/j.jcomdis.2014.07.001` | `is_oa: false`. OA location 0건 |
| 8 | OpenAlex | `works/doi:10.1044/2017_JSLHR-L-17-0026` | `oa_status: green`. 맨체스터 리포지토리에 전문 있음 |
| 9 | OpenAlex | `works/doi:10.1111/1460-6984.12227` | `oa_status: bronze`. Wiley pdfdirect 링크 제시 |
| 10 | Wiley `onlinelibrary.wiley.com/doi/pdfdirect/10.1111/1460-6984.12227` | Lockton 2016 전문 | **실패.** HTTP 403. (기존 기록과 동일 — Wiley 차단 지속) |
| 11 | 맨체스터 Research Explorer `/en/publications/e15cc158-...` | Adams 2018 레코드 | HTTP 200. 첨부 PDF 경로 노출: `/files/60743891/AMP_2_full_version_...pdf` |
| 12 | 맨체스터 `/files/60743891/...pdf` | Adams 2018 전문 | **실패.** HTTP 403. Referer 헤더 추가 후 재시도도 403. WebFetch 도 403 |
| 13 | **CORE v3 search API** | `q=metapragmatic explicitation&limit=5` | 4,864 hits. 1위가 Adams 2018, `downloadUrl: core.ac.uk/download/131344920.pdf` |
| 14 | **CORE `core.ac.uk/download/131344920.pdf`** | Adams 2018 전문 | **성공.** HTTP 200, 410,285 bytes, PDF 43쪽. 맨체스터 403 을 CORE 미러로 우회 |
| 15 | CORE v3 search API | `q=title:(metapragmatic) AND documentType:"thesis"&limit=10` | 11 hits. **Collins 저자 논문 0건.** Collins 2013 맨체스터 박사논문 없음 |
| 16 | CORE v3 outputs API | outputs 74060548 · 368450002 · 670666141 (2014년 논문) | 3건 전부 `downloadUrl` 빈 값. 전문 없음 |
| 17 | 맨체스터 Research Explorer `/en/publications/b4468f81-...` | Collins 2014 레코드 | HTTP 200. **첨부 PDF 없음** (`.pdf` href 0건) |
| 18 | 맨체스터 `/en/studentTheses/?search=metapragmatic` | Collins 2013 학위논문 | **실패.** curl 403, WebFetch 403 |
| 19 | fatcat / scholar.archive.org API | `release/lookup?doi=10.1016/j.jcomdis.2014.07.001` | 응답 없음 (JSON 아님) |
| 20 | ScienceDirect `/science/article/abs/pii/S0021992414000550` | Collins 2014 전문 | **실패.** HTTP 403 |
| 21 | NCBI ID Converter | `PMC4258293` | PMID 25484991 · doi 10.1186/1866-1955-6-41 확정 |

---

## 3 · 전문을 실제로 읽은 것

| 문헌 | 경로 | 확인 방식 |
|---|---|---|
| Dillon 외 2021 (PRS-SA) | PMC8642082 | HTML → 텍스트 변환 후 정규식으로 `.831` · `23 primary items` 구절 직접 추출 |
| Adams 외 2018 (AMP 2차) | CORE 131344920 PDF | pypdf 로 43쪽 추출 (102,878자) 후 `kappa` · `alpha` 구절 전수 확인 |
| Swineford 외 2014 | PMC4258293 | HTML → 텍스트 변환 후 `19 pragmatic behaviors` 구절과 참고문헌 [30] 대조 |

## 4 · 초록만 본 것

| 문헌 | 사유 |
|---|---|
| Collins, Lockton & Adams 2014 (AMP 개발 논문) | **전문 폐쇄.** 위 표 #5·6·7·16·17·20 이 전부 닫힘을 가리킨다 |

---

## 5 · T1 이 NOT FOUND 인 이유

`.712` 와 `.715` 는 **AMP 개발 논문(Collins 2014) 본문에만 있을 수 있다.** 그리고 그 본문은
Elsevier 폐쇄형이며 리포지토리 사본이 존재하지 않는다. 위 21건 중 2014년 논문 전문에 닿을 수 있는
경로는 #5·#6·#7·#16·#17·#20 여섯이었고 **여섯 다 닫혀 있다.**

초록에는 계수가 **없다.** 원문은 이렇게만 적는다.

> "the AMP task had satisfactory internal consistency and inter-rater reliability"

기존 기록(`AMP_TOPICC_검증.md`)은 이 수치의 1차 출처를 "Collins 2013 맨체스터 박사논문 전문"이라고
적어 두었다. 이번에 그 학위논문을 **찾지 못했다** (#15 CORE 논문 검색 0건, #18 맨체스터 학위논문 검색 403).
Adams 2018 참고문헌에도 Collins 2013 학위논문은 **인용되어 있지 않다.** 2014년 학술지 논문만 인용된다.

주의해서 볼 지점이 하나 더 있다. 기존 기록이 같은 표에 함께 적어 둔 **Cronbach α .915** 와
**Spearman ρ .595~.669** 는 **Adams 2018 전문에 그대로 있다.** 즉 그 두 값은 학위논문이 아니라
2018년 논문에서 온 것일 가능성이 있다. 그렇다면 같은 표의 `.712/.715` 출처도 재확인이 필요하다.
다만 **Adams 2018 에는 `.712` 도 `.715` 도 없다.** 그 논문이 보고하는 평정자간 계수는
MP·SU 코딩 **합산 κ = 0.783** 하나뿐이고, 전사 신뢰도 κ = 0.926 이 따로 있다.

**결론: `.712/.715` 는 1차 출처에서 확인되지 않았다. HUMAN BLOCKER 가 아니라 유료 장벽이다.**
확인하려면 Collins 2014 논문 전문에 기관 구독으로 접근하거나 저자에게 직접 요청해야 한다.

---

## 6 · 문턱 0.6 에 남는 외부 근거

| 근거 | 상태 | 쓸 수 있나 |
|---|---|---|
| AMP κ .712/.715 | **미확인** | **아니오.** 1차 출처에서 못 찾았다 |
| PRS-SA 가중 κ .831 | **전문 확인** | 예. 단 가중 κ · 7점 척도 · 1점 허용 · 평균값(하한 .4917)이라는 조건을 함께 적어야 한다 |
| AMP κ .783 (Adams 2018) | **전문 확인** (이번에 새로 확보) | 예. 비가중 Cohen κ · 화용 평정 과제 · 2인 평정 |
| McHugh 2012 "below 0.60 indicates inadequate agreement" | 기존 스프린트에서 전문 확인 | 예. **문턱 0.6 자체에 대한 가장 직접적인 근거는 이쪽이다** |

문턱 0.6 은 **근거를 잃지 않는다.** 다만 근거의 무게중심이 옮겨간다.
AMP 를 빼고 **PRS-SA .831 + Adams 2018 .783 + McHugh 0.60 기준** 셋으로 지탱한다.

---

## 7 · 재현 방법

이 로그의 #2 · #3 · #4 · #13 · #14 는 인증 없이 그대로 재실행된다.

```bash
# 초록 (쿠키 월 우회)
curl -s "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&id=25173072,34388006&rettype=abstract&retmode=text"

# PRS-SA 전문
curl -s "https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8642082/" -L -o prssa.html

# Adams 2018 전문 (맨체스터 403 우회)
curl -s "https://core.ac.uk/download/131344920.pdf" -L -o adams2018.pdf
```
