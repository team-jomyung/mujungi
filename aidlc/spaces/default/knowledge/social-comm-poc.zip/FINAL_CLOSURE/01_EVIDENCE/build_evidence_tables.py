# -*- coding: utf-8 -*-
"""01_EVIDENCE 표를 원자료에서 만든다. 손으로 옮긴 숫자를 여기 한 곳에만 둔다.

    python build_evidence_tables.py

만드는 것
  SCD_STUDY_CENSUS.csv       A1 · 연구 한 줄 · 버킷 · 코호트
  SCD_STUDY_COUNTS.md        A2 · 여덟 버킷의 수와 포함 ID · 참가자 합산 없음
  AGE_EVIDENCE_MATRIX.csv    A3 · 표적 x 연령 구간
  ASSESSMENT_TOOL_MATRIX.csv A4 · 평가도구
  DATA_GAP_MATRIX.csv        A7 · 네 층

원자료 (값은 여기서 가져왔다. 모르는 칸은 NOT RETRIEVED 로 둔다)
  research/agent_scd_census.md · research/agent_outcome_measures.md · research/AMP_TOPICC_검증.md
  research/국내_화용평가도구.md · 01_EVIDENCE/AGE_EVIDENCE.md · 02_SCOPE/_agent_pragmatics_review.md
  CLOSURE_RESEARCH.html · 09_PRIOR_ART/COMPETITOR_MATRIX.md
"""
import csv
import io
import os
from collections import OrderedDict, defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
NR = 'NOT RETRIEVED'

# ───────────────────────── A1 · 연구 ─────────────────────────
# bucket 은 여덟 중 하나. cohort 가 같으면 참가자를 합치지 않는다.
BUCKETS = ['STRICT_DIRECT_SCD_PARTICIPANT_STUDIES', 'DIRECT_BUT_ALGORITHMIC_OR_PUTATIVE', 'MIXED_SPCD_ASD',
           'HISTORICAL_PLI', 'ADJACENT_ASD_DLD', 'ITEM_MAPPING_OR_TOOL_STUDIES', 'REVIEW_STUDIES', 'GENERAL_PRAGMATICS']

S = []


def st(sid, authors, year, title, ident, depth, population, dx, bucket, n, age, bins, lang, task,
       conv, annot, longi, outcome, irr, public, license_, use, limits, cohort='', src=''):
    S.append(OrderedDict([
        ('source_id', sid), ('authors', authors), ('year', year), ('title', title), ('identifier', ident),
        ('url', ('https://doi.org/' + ident.split('doi ')[1].split(' ')[0]) if 'doi ' in ident else
         ('https://europepmc.org/article/MED/' + ident.split('PMID ')[1].split(' ')[0]) if 'PMID ' in ident else ''),
        ('fulltext_or_abstract', depth), ('population', population), ('diagnostic_method', dx),
        ('bucket', bucket), ('n_with_unit', n), ('age', age), ('age_bins', bins), ('language', lang),
        ('task', task), ('natural_conversation', conv), ('annotation', annot), ('longitudinal', longi),
        ('outcome', outcome), ('inter_rater_reliability', irr), ('public_data', public), ('license', license_),
        ('our_use', use), ('limitations', limits), ('cohort_id', cohort or sid), ('source_file', src)]))


C = 'research/agent_scd_census.md'
AG = '01_EVIDENCE/AGE_EVIDENCE.md'
PR = '02_SCOPE/_agent_pragmatics_review.md'
OM = 'research/agent_outcome_measures.md'

st('D01', 'Yoshinaga, Egawa, Watanabe, Kasahara, Sugimoto, Someya', 2023, 'Usefulness of the AQ in screening for ASD and SCD',
   'doi 10.1186/s12888-023-05362-y PMID 37957611 PMC10644653', 'FULL', 'SCD 52 · ASD 127 · NT 49 · 일본', '정신과 의사 임상 진단 · 구조화 도구 없음 (저자: "no structured interview tool is available for SCD")',
   'STRICT_DIRECT_SCD_PARTICIPANT_STUDIES', 'participant 52 (SCD)', '16-52 (평균 28.1)', '13-17|18-25|26+', 'Japanese',
   'AQ-J 자기보고 · ROC', 'NO', 'NO', 'NO', 'SCD 대 NT AUC 0.89 · SCD 대 ASD AUC 0.75', 'N/A', 'NO', 'CC BY (논문)',
   '성인 SCD 가 진단된다는 확인 · 대화 자료 없음', '대화·화용 자료 0 · 자기보고', '', AG)
st('D02', 'Dame et al.', 2024, 'Developmental profile of ASD versus SCD: a pilot study', 'doi 10.3390/children11101241 PMID 39457206',
   'ABSTRACT', 'SCD 9 · ASD 10', 'DSM-5 임상 구분(제한·반복 행동 없음) · 세부 NR', 'STRICT_DIRECT_SCD_PARTICIPANT_STUDIES',
   'participant 9 (SCD)', NR, '6-12 (추정)', 'French (inferred)', 'Vineland · ADOS · CCC · 화용 평가 · WISC-IV', 'NO', 'NO', 'NO',
   'Vineland 사회화 SCD 80 대 ASD 51', NR, 'NO', 'CC BY', 'SCD 와 ASD 적응 차이', '표본 9 · 연령 미보고', '', C)
st('D03', 'Jain, Multani, Dodiya, Benani, Iyer', 2025, 'Adaptive behaviour in ASD vs SCD (India)', 'doi 10.1177/13623613251317787 PMID 39943881',
   'ABSTRACT', 'ASD 232 · SCD 90', 'DSM-5 + AIIMS-modified INCLEN', 'STRICT_DIRECT_SCD_PARTICIPANT_STUDIES', 'participant 90 (SCD)',
   'children · 범위 NR', '6-12 (추정)', NR, 'Vineland-III', 'NO', 'NO', 'NO', 'SCD 가 모든 적응 영역에서 ASD 보다 나음', NR, 'NO', NR,
   '진단 표본 규모 참고', '연령 범위 미보고', '', AG)
st('D04', 'Tsai & Lin', 2020, 'Diagnostic migration ASD to SCD in adolescents with ADHD (brief report)', 'doi 10.1007/s10803-019-04265-w PMID 31650372',
   'ABSTRACT', 'ADHD 청소년 · 소수', '임상 재진단', 'STRICT_DIRECT_SCD_PARTICIPANT_STUDIES', 'participant small (NR)', 'adolescents', '13-17',
   NR, '진단 이동 기술', 'NO', 'NO', 'NO', NR, NR, 'NO', NR, '청소년 SCD 가 진단된다는 기록', '소수 · 단보', '', AG)
st('D05', 'Tsai, Lin & Lee', 2022, 'SCD + ADHD + Tourette case report', 'doi 10.24869/psyd.2022.96 PMID 35467619', 'ABSTRACT',
   '청소년 1', '임상', 'STRICT_DIRECT_SCD_PARTICIPANT_STUDIES', 'participant 1', 'adolescent', '13-17', NR, '약물 사례',
   'NO', 'NO', 'NO', NR, 'N/A', 'NO', NR, '없음', '단일 사례', '', AG)

st('P01', 'Svindt & Suranyi', 2021, 'Comprehension of grammaticalized implicit meanings in SPCD and ASD', 'doi 10.1111/1460-6984.12657 PMID 34453388',
   'ABSTRACT', 'SPCD 13 · ASD 19 · TD 39 · 헝가리', 'SPCD 표시 · 진단 절차 NR', 'DIRECT_BUT_ALGORITHMIC_OR_PUTATIVE', 'participant 13 (SPCD)',
   NR, '6-12 (추정)', 'Hungarian', '문장-그림 검증 · 함축 · 전제 · 함의', 'NO', 'NO', 'NO',
   'SPCD 이해 양상이 TD 와 유의하게 다름 · SPCD 는 수용 문법과 상관', NR, 'NO', NR,
   '함축 이해의 DIRECT SPCD 근거 (ONTOLOGY_SCOPE_FINAL)', '진단 절차 미확인 · 문법 촉발 함축 · 대화 아님', '', C)
st('P02', 'Yuan & Dollaghan', 2020, 'IRT modeling to identify SPCD', 'doi 10.1044/2020_JSLHR-19-00284 PMID 32539641', 'ABSTRACT',
   'NDAR · putative SPCD 54 · ASD 278 · TC 274', 'NDAR 분류 + ADI-R 로 소급 · 저자 표현 "putative"', 'DIRECT_BUT_ALGORITHMIC_OR_PUTATIVE',
   'participant 54 (putative SPCD)', NR, NR, 'English', 'SCQ 문항 IRT', 'NO', 'NO', 'NO', 'SC 7문항이 SPCD 대 TC 를 민감도·특이도 80% 넘게 가름',
   'N/A', 'NO', NR, '구인 참고', '진단 아님', '', C)
st('P03', 'Mandy, Wang, Lee, Skuse', 2017, 'Evaluating social (pragmatic) communication disorder', 'doi 10.1111/jcpp.12785 PMID 28741680',
   'ABSTRACT', '특수 클리닉 1,081 · SPCD 88 · ASD 801 · 비교 192', '3Di + CCC 알고리즘', 'DIRECT_BUT_ALGORITHMIC_OR_PUTATIVE',
   'participant 88 (SPCD by algorithm)', '4-18 · SPCD 연령 분포 미보고', '0-5|6-12|13-17', 'English', '부모 보고', 'NO', 'NO', 'NO',
   'SPCD 가 ASD 와 질적으로 구별되지 않음 · 문항간 r .22', 'N/A', '승인 원고 UCL 공개', NR, '구성 타당도 반론', '청소년 비중 모름 · 청소년 근거로 인용 금지', '', C)
st('P04', 'Saul, Griffiths, Norbury', 2023, 'Prevalence and functional impact of SPCD', 'doi 10.1111/jcpp.13705 PMID 36114685 PMC10087005',
   'ABSTRACT', '지역사회 386', 'CCC-2 알고리즘으로 포함·배제 근사', 'DIRECT_BUT_ALGORITHMIC_OR_PUTATIVE', 'participant 386', '5-6', '0-5|6-12',
   'English', '체크리스트 알고리즘', 'NO', 'NO', 'NO', '고립 SPCD 0-1.3% · 동반형 6.1-10.5%', 'N/A', 'NO', 'CC BY',
   '유병률 인용', '5-6세 · 우리 연령과 불일치', '', C)
st('P05', 'Ellis Weismer, Tomblin, Durkin, Bolt, Palta', 2021, 'Preliminary epidemiologic study of SPCD in the context of DLD',
   'doi 10.1111/1460-6984.12664 PMID 34383380 PMC8890438', 'ABSTRACT', 'EpiSLI 393', 'CCC-2 사례 정의 둘', 'DIRECT_BUT_ALGORITHMIC_OR_PUTATIVE',
   'participant 393', '13-14', '13-17', 'English', '체크리스트 · 2차 자료', 'NO', 'NO', 'NO', 'SCD 7-11%', 'N/A', 'NO', NR,
   '13-17 유병률 유일 추정', '아동용 도구 상단에서 잰 청소년', 'C-EPISLI', AG)
st('P06', 'Ellis Weismer et al.', 2021, 'Companion paper (J Autism Dev Disord 51:2686)', 'doi 10.1007/s10803-020-04737-4', 'ABSTRACT',
   'EpiSLI', '같음', 'DIRECT_BUT_ALGORITHMIC_OR_PUTATIVE', 'participant NR (P05 와 겹칠 가능성)', NR, '13-17', 'English', NR,
   'NO', 'NO', 'NO', NR, 'N/A', 'NO', NR, '합산 금지', '같은 연구 프로그램', 'C-EPISLI', C)
st('P07', 'Azizpour, Hemati Alamdarloo, Shojaei, Moradi', 2026, 'Social camouflage in adolescents with SCD', 'doi 10.3389/fpsyg.2026.1839647 PMID 42325324',
   'ABSTRACT', 'SCD 60 · 비SCD 60 · 이란', '"diagnosed with SCD" · 도구 NR', 'DIRECT_BUT_ALGORITHMIC_OR_PUTATIVE', 'participant 60 (SCD)',
   '14-18', '13-17|18-25', 'Persian (inferred)', 'CAT-Q 자기보고', 'NO', 'NO', 'NO', 'SCD 가 위장 점수 높음', 'N/A', 'NO', 'CC BY',
   '청소년 SCD 표본 존재 확인', 'P08 과 같은 표본 · 240 으로 합산 금지', 'C-AZI', AG)
st('P08', 'Azizpour, Alamdarloo, Shojaei, Moradi', 2026, 'Intolerance of uncertainty in adolescents with and without SCD',
   'doi 10.3389/fpsyt.2026.1803782 PMID 42064161', 'ABSTRACT', 'SCD 60 · TD 60', '같음', 'DIRECT_BUT_ALGORITHMIC_OR_PUTATIVE',
   'participant 60 (P07 과 같은 표본으로 추정)', '14-18', '13-17|18-25', 'Persian (inferred)', 'IUS 자기보고', 'NO', 'NO', 'NO',
   'SCD 가 불확실성 불내성 높음', 'N/A', 'NO', 'CC BY', '같음', '같은 표본 · 합산 금지', 'C-AZI', AG)
st('P09', 'Jin & Pae', 2014, 'Communication profiles of school-aged children with SCD and HFA (Korean)', 'doi 10.12963/csd.14102',
   'ABSTRACT', 'SCD 15 · HFA 15 · TD 15 · 한국', 'SCQ<15 + CCC-2 GCC<55 + 화용 복합<17 · 임상 진단 아님', 'DIRECT_BUT_ALGORITHMIC_OR_PUTATIVE',
   'participant 15 (SCD)', '초 1-6', '6-12', 'Korean', '교실 구조화 관찰 · 개시·응답 유형', 'YES (교실 관찰)', 'YES', 'NO',
   'SCD 사회적 의사소통 빈도 낮음 · 언어적 수단 적음', NR, 'NO', NR, '응답성 CORE 의 근거 하나 · 한국 유일', '체크리스트 조작화 · 수리 미측정', '', PR)
st('P10', 'Lockton, Adams, Collins', 2016, 'Do children with SCD have explicit knowledge of pragmatic rules they break?', 'doi 10.1111/1460-6984.12227 PMID 26916221',
   'ABSTRACT', 'CwSCD 39 · NHS SLT', 'SCD 표시 · 기준 NR (맨체스터 용법)', 'DIRECT_BUT_ALGORITHMIC_OR_PUTATIVE', 'participant 39',
   '6;1-10;7', '6-12', 'English', 'AMP 영상 + TOPICC 반구조화 대화', 'YES (반구조화 · 유도)', 'YES (TOPICC 12 측면)', 'NO',
   '표현언어가 TOPICC 예측 · AMP 고유 분산 없음', NR, 'NO', 'Bronze OA · license null', '인식과 산출이 다른 축이라는 근거', 'TOPICC 측면별 결과 NR', 'C-MAN', C)
st('P11', 'Adams, Lockton, Collins', 2018, 'Metapragmatic explicitation in SCD and DLD', 'doi 10.1044/2017_JSLHR-L-17-0026 PMID 29471463',
   'ABSTRACT', 'SCD · DLD · TD 합 82', '기준 NR', 'DIRECT_BUT_ALGORITHMIC_OR_PUTATIVE', 'participant 82 (3집단 합 · 집단별 NR)', '6-11', '6-12',
   'English', 'AMP 영상', 'NO', 'NO', 'NO', 'SCD 가 DLD 보다 사회적 귀인 낮음', NR, 'NO', NR, '상위화용 참고', 'P10 과 같은 아동일 가능성', 'C-MAN', C)
st('P12', 'Gaile & Adams', 2018, 'Metacognition in SLT for children with SPCD', 'doi 10.1111/1460-6984.12326 PMID 28621083', 'ABSTRACT',
   'SPCD 표시 5 · 치료 회기 8', '기준 NR', 'DIRECT_BUT_ALGORITHMIC_OR_PUTATIVE', 'participant 5 · session 8', '5;11-10;3', '6-12',
   'English', '치료 영상 질적 분석', '치료 회기', 'YES (질적)', 'NO', '메타인지 네 주제', NR, 'NO', NR, '치료 이론 참고', 'SCIP 코호트와 겹칠 가능성', 'C-SCIP', C)

st('M01', 'Adams, Gaile, Roddam, Baxendale, Clitheroe, Emsley', 2020, 'SCIP feasibility study', 'doi 10.1186/s40814-020-00658-2 PMID 32983554 PMC7510260',
   'FULL', '24 선별 · 22 시작 · 20 완료', 'CCC-2 GCC<55 + SCIP-SCCheck 5중 2 + 실무자 관찰 · 20 중 11 이 ADOS-2 자폐 기준', 'MIXED_SPCD_ASD',
   'participant 20 (완료)', '5;0-10;11', '0-5|6-12', 'English', '단일군 중재 · SCIP-GAS', 'NO', 'NO', 'YES (전후)',
   '부모 평정 1명 빼고 전원 진전', '보고 없음', 'YES', 'CC BY', '목표 설정 방식(자유 서술 → 구조화) 근거', '대조군 없음 · 자폐 기준 11/20', 'C-SCIP', C)
st('M02', 'Adams & Gaile', 2020, 'Parent preference-based outcome after intensive communication intervention', 'doi 10.1016/j.ridd.2020.103752 PMID 32771922',
   'ABSTRACT', 'SPCD 또는 HFASD 20', 'M01 과 같은 코호트', 'MIXED_SPCD_ASD', 'participant 20 (M01 과 같음)', '5-11', '6-12', 'English',
   '중재 + TOPICC-2 + SLDT', 'TOPICC-2 대화 평정', 'YES', 'YES (전후)', '이차 지표 중 SLDT Making Inferences 와 TOPICC-2 만 상승', NR, 'NO', 'closed',
   '표준 종합 체크리스트는 안 움직였다는 근거', '단일군 · 합산 금지', 'C-SCIP', C)
st('M03', 'Adams, Gaile, Lockton, Freed', 2015, 'Single-subject SCIP case', 'PMID 26252361', 'ABSTRACT', '발달성 SCD 표시 1', NR,
   'MIXED_SPCD_ASD', 'participant 1', '8', '6-12', 'English', '20회기 전후 대화', 'YES', 'YES', 'YES (6개월 추적)',
   '응답성 · 청자 지식 고려 · 말순서 · 담화 방식 개선', NR, 'NO', NR, '단일 사례 · CORE 판정에 보조로만', 'n=1', '', PR)
st('M04', 'Teruya et al.', 2025, 'DISC-12 prescreen in ASD/SCD', 'doi 10.1002/pcn5.70084 PMID 40104129', 'ABSTRACT', 'ASD/SCD 94 · SAD 17 · 일본',
   NR, 'MIXED_SPCD_ASD', 'participant 94 (ASD/SCD 합)', 'NR (성인 추정 · 미확인)', NR, 'Japanese', 'DISC-12 자기보고', 'NO', 'NO', 'NO', '요인 셋',
   'N/A', 'NO', NR, '두 번째 일본 표본 후보', '연령 미확인 · 성인 코호트로 보고 금지', '', AG)
st('M05', 'Guler et al.', 2026, 'Transition clinic for NDD (15-21)', 'doi 10.3389/fpsyt.2026.1882420 PMID 42592153', 'ABSTRACT', '68 · 튀르키예',
   '다학제 진단 · SPCD 수 NR', 'MIXED_SPCD_ASD', 'participant 68 (SPCD 수 NR)', '15-21', '13-17|18-25', 'Turkish', '임상 평가', 'NO', 'NO', 'NO',
   'SPCD 가 새로 식별되는 진단 중 하나', 'N/A', 'NO', NR, '전환기 과소 식별 근거', 'SPCD 수 미보고', '', AG)
st('M06', 'Dillon, Holingue, Herman, Landa', 2021, 'PRS-SA psychometrics', 'PMID 34388006', 'ABSTRACT', '130 (SCI-only 22)', 'SCI-only 정의 NR',
   'ITEM_MAPPING_OR_TOOL_STUDIES', 'participant 130', '7-12', '6-12', 'English', 'ADOS 영상 평정', 'ADOS 표본', 'YES', 'NO', 'SCI-only 가 TD 보다 비전형',
   NR, 'NO', NR, 'PRS-SA 구인', '문항 목록 NR', '', PR)
st('M07', 'Flax et al.', 2019, 'SPCD in language-impaired families (BAP)', 'doi 10.1177/1362361318822503 PMID 30931583', 'ABSTRACT', '가족 유전 연구',
   NR, 'MIXED_SPCD_ASD', 'participant NR', '아동 · 형제 · 부모(성인)', '6-12|26+', 'English', NR, 'NO', 'NO', 'NO',
   'SPCD 가 SCI+RRB 아동을 포착하지 못함', NR, 'NO', NR, '성인 가족 자료', 'BAP 표본', '', AG)
st('M08', 'Yoo et al. (NDTx-01)', 2025, 'Mobile game NDTx-01 in adolescents with ASD or SCD · RCT pilot', 'doi 10.1111/pcn.13824 PMID 40214154',
   'ABSTRACT', 'ASD 또는 SCD 10-18 · 배정 39 · 분석 38', 'ASD 또는 SCD · 분리 보고 없음', 'MIXED_SPCD_ASD', 'participant 38 (분석)', '10-18',
   '6-12|13-17', 'Korean', '게임형 SST 6주', 'NO', 'NO', 'NO', 'K-Vineland-II ABC p=0.037', '평가자 맹검', 'NO', NR,
   '국내 경쟁 · SCD 를 등록한 유일한 청소년 중재', 'SCD 분리 결과 없음', '', AG)

st('H01', 'Adams & Bishop', 1989, 'Conversational characteristics of children with SPD I: exchange structure, turntaking, repairs, cohesion',
   'doi 10.3109/13682828909019889 PMID 2627544', 'ABSTRACT', 'SLI 57 (SPD 14) + 대조 67', 'SPD 하위집단', 'HISTORICAL_PLI',
   'participant 14 (SPD)', 'SLI 8-12 · 대조 4-12', '0-5|6-12', 'English', '반구조화 대화 부호화', 'YES', 'YES (교환 구조 · 말순서 · 수리 · 결속)', 'NO',
   'SPD 개시 많음 · 일부 특이하게 끼어듦 · 수리 집단 차이 초록에 없음', '적정 (계수 없음)', 'NO', NR, '수리 부호화 선례', '수리 결과 방향 미상 · 전문 403', 'C-AB89', PR)
st('H02', 'Bishop & Adams', 1989, 'II: what features lead to a judgement of inappropriacy?', 'doi 10.3109/13682828909019890 PMID 2627545', 'ABSTRACT',
   'H01 과 같은 표본', 'SPD', 'HISTORICAL_PLI', 'participant 14 (H01 과 같음)', '8-12', '6-12', 'English', '부적절 판정 특징', 'YES', 'YES', 'NO',
   '"too much or too little information" · "misunderstood the literal or implicit meaning"', '적정 (계수 없음)', 'NO', NR,
   '청자 맞춤 정보 조절 · 함축 이해 CORE 근거', '같은 표본 · 합산 금지', 'C-AB89', PR)
st('H03', 'Bishop, Hartley, Weir', 1994, 'Initiation in conversations of children with SPD', 'PMID 8040160', 'ABSTRACT', 'SPD 6 + 대조', 'SPD',
   'HISTORICAL_PLI', 'participant 6 (SPD)', '평균 11', '6-12', 'English', '네 상황 · 상대 친숙도 조작', 'YES', 'YES', 'NO',
   '응답보다 개시 · 친숙도에 따른 조절 없음', NR, 'NO', NR, '응답성 · 관계 맞춤 조정 CORE 근거', 'n=6', '', PR)
st('H04', 'Bishop, Chan, Adams, Hartley, Weir', 2000, 'Conversational responsiveness in SLI', 'PMID 10847623', 'ABSTRACT',
   'SLI 18 (PLI 9) + 대조 18', 'PLI 하위집단', 'HISTORICAL_PLI', 'participant 9 (PLI)', '6-8', '6-12', 'English', '어른 요청에 대한 반응 부호화',
   'YES', 'YES', 'NO', 'PLI 무응답 많음 · 비언어 반응 적음', NR, 'NO', NR, '응답성 CORE 근거', 'n=9', '', PR)
st('H05', 'Adams & Lloyd', 2005, 'Elicited and spontaneous communicative functions in PLI', 'PMID 16195192', 'ABSTRACT', 'PLI 15 + 대조', 'PLI',
   'HISTORICAL_PLI', 'participant 15', '평균 9;5', '6-12', 'English', '유도 과제 대 대화 · 두 시점', 'YES', 'YES', 'YES (두 시점)',
   '대화 지표(장황함 등)가 집단을 가르고 안정적', NR, 'NO', NR, '장황함 · 대화 지표 안정성', '수리 미언급', '', PR)
st('H06', 'Adams, Lloyd, Aldred, Baxendale', 2006, 'Signal-generation intervention in PLI', 'PMID 16272002', 'ABSTRACT', 'PLI 6 (자폐 아님)', 'PLI',
   'HISTORICAL_PLI', 'participant 6', 'school age', '6-12', 'English', '8주 치료 · 7시점 대화 측정 · 맹검 부호화', 'YES', 'YES', 'YES',
   '모든 아동이 일부 대화 지표에서 변화', NR, 'NO', NR, '대화 지표가 변화를 잡는다는 근거', 'n=6 · 대조 없음', '', PR)
st('H07', 'Bishop & Adams', 1992, 'Comprehension problems in SLI: literal and inferential meaning', 'PMID 1735960', 'ABSTRACT', 'SLI 안 SPD', 'SPD',
   'HISTORICAL_PLI', 'participant NR', NR, '6-12', 'English', '이야기 이해 · 문자 대 추론 질문', 'NO', 'NO', 'NO',
   'SPD 점수 낮음 · 추론 질문에 불균형한 곤란은 없음', NR, 'NO', NR, '함축 이해의 반례 겸 보조', '대화 아님', '', PR)
st('H08', 'Adams et al. (SCIP RCT)', 2012, 'SCIP randomized controlled trial', 'doi 10.1111/j.1460-6984.2011.00146.x PMID 22512510', 'ABSTRACT',
   'PLI 또는 SCD · 전체 75% ASD 겹침 · 무작위 88', 'SLT 서비스 의뢰 · 세부 NR', 'HISTORICAL_PLI', 'participant 88', '5;11-10;8', '0-5|6-12',
   'English', 'RCT · 맹검 대화 역량 평정', 'YES (맹검 평정)', 'YES', 'YES (6개월)', '대화 역량 · 부모 화용 · 교사 평정 개선 · 구조 언어(1차) 무효', NR,
   'NO', 'Bronze OA', '중재가 대화 평정을 움직인다는 근거', 'SPCD 아님 · ASD 75%', 'C-SCIP-RCT', C)
st('H09', 'Adams et al. (SCIP implementation)', 2012, 'Implementation of a manualized intervention', 'doi 10.1111/j.1460-6984.2012.00147.x PMID 22512511',
   'ABSTRACT', '같은 시험 57', '같음', 'HISTORICAL_PLI', 'participant 57 (H08 과 같은 시험)', 'school age', '6-12', 'English', '충실도', 'NO', 'NO', 'NO',
   '중재 요소 · "comprehension monitoring" 포함', 'N/A', 'NO', NR, '명료화 관련 중재 요소 존재', '합산 금지', 'C-SCIP-RCT', C)
st('H10', 'Whitehouse et al.', 2009, 'PLI adult follow-up (AGE_EVIDENCE 표에만 등장)', NR, NR, 'PLI 성인 추적', 'PLI', 'HISTORICAL_PLI', NR,
   '평균 22;3', '18-25', 'English', NR, NR, NR, 'YES', NR, NR, NR, NR, '18-25 PLI 존재 표시', '세부 미확인 · 인용 전 전문 확인 필요', '', AG)

for sid, a, y, t, ident, pop, n, age, bins, lang, task, conv, out, use in [
    ('A01', 'Karin, Geva, Bar-Yehuda, Estrugo, Bauminger-Zviely', 2026, 'Common ground tangram task', 'doi 10.1007/s10803-024-06642-6 PMID 39570556',
     'TD 64 · 자폐 84 · 이스라엘', 'participant 148', '6-16', '6-12|13-17', 'Hebrew (inferred)', '탱그램 공통 기반 과제', 'NO (과제)', '자폐 효율 낮음 · 10세 미만에서 운동-공통기반 연결 강함', '청자 지식 과제 조작화'),
    ('A02', 'Abalos, Kissine, Vicente, Castroviejo', 2026, 'Topic shifts in autistic children', 'doi 10.1002/aur.70204 PMID 41708108',
     '자폐 43 · NT 46', 'participant 89', 'M 8.55', '6-12', 'Spanish', '반자발 대화 · 화제 전환 부호화', 'YES', '자폐 화제 전환 많고 덜 자연스러움', '화제 부호화 틀'),
    ('A03', 'Ayvazo et al.', 2026, 'Topic intervention (AGE_EVIDENCE §4.2)', NR, 'ASD 3', 'participant 3', '16-18', '13-17|18-25', NR, '10분 대화 · 주제 유지 발화', 'YES', '단일대상 설계', '청소년 화제 인접 근거'),
    ('A04', 'Sadati & Mohamadi', 2024, 'Communication breakdown repair in DHH adolescents', 'doi 10.1080/14670100.2024.2379122 PMID 39028756',
     'DHH 16 · NH 16 · 이란', 'participant 32', '11-16', '6-12|13-17', 'Persian (inferred)', '낯선 어른과 10분 대화 · 명료화 요청과 응답', 'YES', 'DHH 비언어 명료화 요청 많음', '수리 측정 틀'),
    ('A05', 'Diez-Itza, Viejo, Fernandez-Urquiza', 2022, 'Pragmatic profiles of adults with FXS and WS', 'doi 10.3390/brainsci12030385 PMID 35326341',
     'FXS 6 · WS 6 · ASD 없음', 'participant 12 · word 71,859', 'adults', '18-25|26+', 'Spanish', '자연 대화 · 그라이스 격률 위반', 'YES', 'FXS 화제 고착 · WS 이탈', '성인 격률 부호화 선례'),
    ('A06', 'Arturi et al.', 2025, 'tDCS + CBT in young autistic adults (AGE_EVIDENCE §4)', NR, 'ASD 10', 'participant 10', '18-25', '18-25', NR, 'tDCS + CBT', 'NO', NR, '연령대 존재 근거로만'),
    ('A07', 'Brinton, Fujiki, Winkler, Loeb', 1986, 'Stacked clarification requests', 'PMID 3773493', 'LI 30 · 전형 30', 'participant 60', '4;10-9;10', '0-5|6-12', 'English',
     '연속 명료화 요청', 'NO (과제)', 'LI 가 연속 요청에 적절 응답 어려움', '수리 과제 틀'),
    ('A08', 'Brinton, Fujiki, Sonnenberg', 1988, 'Stacked CR in conversation', 'PMID 3184899', 'LI 8 + 대조', 'participant 8 (LI)', '평균 9;2', '6-12', 'English',
     '대화 속 연속 요청 열 번', 'YES', '응답 의무 인식은 같음', '수리 과제 틀'),
    ('A09', 'Volden', 2004, 'Conversational repair in ASD', 'PMID 15204450', 'HFA 9 + 언어연령 대조 9', 'participant 9 (ASD)', 'school age', '6-12', 'English',
     '연속 명료화 요청', 'NO', '수리 전략은 비슷 · 부적절 응답 많음', '수리 과제 틀'),
    ('A10', 'Barstein, Martin, Lee, Losh', 2018, 'Repair across ASD, FXS, DS', 'PMID 29800075', 'ASD 40 · FXS+ASD 62 · FXS 38 · DS 43 · TD 42', 'participant 225', NR, NR,
     'English', '반복 명료화 요청', 'NO', '연속 요청에 반응 줄어듦', '반복 요청이 이탈을 부를 수 있음'),
    ('A11', 'Lee & Yim', 2026, 'Eye-tracking of repair requests in Korean children with SLI', 'doi 10.12963/csd.260184', 'TD 14 · SLI 10 · 한국', 'participant 24',
     '초 1-2', '6-12', 'Korean', '의사소통 단절 18항목 · 명료화 요청 산출', 'NO', 'SLI 요청 적고 덜 구체적 · 시선은 비슷', '한국어 명료화 요청 측정 선례'),
    ('A12', 'Gabbatore, Marchetti Guerrini, Bosco', 2025, 'Looking for SPCD in Italian special needs', 'doi 10.1038/s41598-024-83280-z PMID 39747328',
     'BES-NOS 14 · TD 16', 'participant 14', '7-15', '6-12|13-17', 'Italian', 'ABaCo 172문항', 'PARTIAL', '군집 8명을 미진단 SPCD 후보로', '이해·산출 교차 도구'),
]:
    st(sid, a, y, t, ident, 'ABSTRACT' if sid != 'A12' else 'FULL', pop, '진단 SCD 아님', 'ADJACENT_ASD_DLD', n, age, bins, lang, task, conv, 'YES' if conv == 'YES' else NR,
       'NO', out, NR, 'NO', 'CC BY-NC-ND' if sid == 'A12' else NR, use, '인접 집단', '', AG if sid in ('A01', 'A02', 'A03', 'A04', 'A05', 'A06') else PR)

st('G01', 'Arvidsson, Pagmar, Udden', 2022, 'Adolescents world-knowledge-based audience design', 'doi 10.1098/rsos.220305 PMID 36465686', 'ABSTRACT',
   '전형 58 · 스웨덴', '없음', 'GENERAL_PRAGMATICS', 'participant 58', '11-12 · 15-16', '6-12|13-17', 'Swedish', '온라인 참조 산출', 'NO', 'NO', 'NO',
   '청자 설계가 청소년기에도 발달 · 실행기능이 설명 못함', 'N/A', 'NO', 'CC BY', '청소년 청자 지식 기준선', '전형 발달', '', AG)

for sid, a, y, t, ident, depth, n, use in [
    ('T01', 'Yuan & Dollaghan', 2018, 'Measuring the diagnostic features of SPCD (item mapping)', 'doi 10.1044/2018_AJSLP-16-0219 PMID 29587307', 'ABSTRACT',
     'item 594 → 206 (합의) · 평정자 1 + 5', 'DSM-5 네 특성 매핑 · κ .69-.76 · Gabbatore 2023 은 220 으로 적음 (EVIDENCE_LEDGER)'),
    ('T02', 'Collins, Lockton, Adams', 2014, 'AMP development', 'doi 10.1016/j.jcomdis.2014.07.001 PMID 25173072', 'ABSTRACT',
     'participant 88 (TD 40 + 의사소통장애 48)', '상위화용 인식 과제 · 수치 계수 초록에 없음'),
    ('T03', 'Norbury, Nash, Baird, Bishop', 2004, 'CCC-2 validation · SIDC', 'doi 10.1080/13682820410001654883 PMID 15204445', 'ABSTRACT',
     'participant 138 (87 + 24 + 27)', 'SIDC 부모-교사 r .79'),
    ('T04', 'Adams, Gaile, Lockton, Freed', 2011, 'TOPICCAL applications (trade journal)', 'Speech & Language Therapy in Practice 2011 · DOI 없음', 'SECONDARY',
     'item 17 · 범주 7', 'TOPICC 양식 원출처 · 12 측면은 Lockton 2016 이 부호화한 부분'),
    ('T05', 'Kim, Song, Kim, Kim', 2018, 'KOPLAC', 'doi 10.12963/csd.18467', 'ABSTRACT', 'participant 270 (규준) · item 53 / 67', '한국 상위화용 · 5;0-12;11'),
    ('T06', 'Oh, Lee, Kim', 2012, 'CPLC item development', '언어치료연구 21(2) 111-135', 'SECONDARY', 'item 44', '한국 부모 보고 · 5-13'),
    ('T07', 'Poll et al.', 0, 'Transition Pragmatics Interview (5 papers · AGE_EVIDENCE §5)', 'see AGE_EVIDENCE.md §5', 'SECONDARY', NR, '14-22 전용 도구 · 구인 참조 1순위'),
    ('T08', 'Angeleri et al.; Bosco et al.', 2012, 'ABaCo', 'PMID 22180102 · PMID 22483360', 'ABSTRACT', 'item 172', '이해·산출 교차 채점 유일'),
]:
    st(sid, a, y, t, ident, depth, NR, NR, 'ITEM_MAPPING_OR_TOOL_STUDIES', n, NR, NR, NR, '도구', NR, NR, NR, NR, NR, NR, NR, use, '도구 연구',
       '', C if sid in ('T01',) else OM)

for sid, a, y, t, ident, depth, n, use in [
    ('R01', 'Gabbatore, Marchetti Guerrini, Bosco', 2023, 'Fuzzy boundaries of SPCD', 'doi 10.1016/j.heliyon.2023.e19062 PMID 37664706', 'FULL',
     'study 18', '18 중 12 가 기존 자료 재분석 · 6 만 전용 연구'),
    ('R02', 'Swineford, Thurm, Baird, Wetherby, Swedo', 2014, 'DSM-5 SCD research review', 'PMC4258293', 'FULL', 'review', 'DSM-5 기준 A 원문 (A3 rephrasing when misunderstood)'),
    ('R03', 'Norbury', 2014, 'Practitioner review: SPCD', 'PMID 24117874', 'ABSTRACT', 'review', '차원적 증상 프로파일로 보라'),
    ('R04', 'Parsons, Cordier, Munro, Joosten, Speyer', 2017, 'Pragmatic language interventions for ASD · meta-analysis', 'doi 10.1371/journal.pone.0172242', 'FULL',
     'study 21 · participant 925', '13-18 대상 연구 0 · 전이 결론 불가'),
    ('R05', 'Gates, Kang, Lerner', 2017, 'Social skills group intervention ASD · meta-analysis', 'doi 10.1016/j.cpr.2017.01.006', 'SECONDARY',
     'RCT 19', '지식 g 1.15 대 수행 g 0.28 n.s.'),
    ('R06', 'Pereira, Lopes, Ramalho, Lousada', 2025, 'Psychometrics of instruments for pragmatic intervention effects in autism', 'doi 10.1177/23969415251341251', 'FULL',
     'instrument 19 · study 49', '반응성 보고 0'),
    ('R07', 'Gerber, Brice, Capone, Fujiki, Timler', 2012, 'ASHA EBSR · language use in social interactions', 'PMID 22052968', 'ABSTRACT', 'review',
     '화제 · 서사 · 수리 개선 보고 · 권고 근거 불충분'),
    ('R08', 'Adams', 2002, 'Practitioner review: assessment of language pragmatics', 'doi 10.1111/1469-7610.00226 PMID 12455920', 'ABSTRACT', 'review',
     '형식 검사의 한계 · 이해 대 사용'),
]:
    st(sid, a, y, t, ident, depth, NR, NR, 'REVIEW_STUDIES', n, NR, NR, NR, '문헌 고찰', NR, NR, NR, NR, NR, NR, NR, use, '고찰', '', C)


def write_census():
    p = os.path.join(HERE, 'SCD_STUDY_CENSUS.csv')
    with io.open(p, 'w', encoding='utf-8', newline='') as f:
        w = csv.DictWriter(f, list(S[0].keys()))
        w.writeheader()
        w.writerows(S)
    return p


def write_counts():
    by = defaultdict(list)
    for s in S:
        by[s['bucket']].append(s)
    cohorts = defaultdict(set)
    for s in S:
        cohorts[s['bucket']].add(s['cohort_id'])
    L = ['# SCD STUDY COUNTS · A2', '',
         '`build_evidence_tables.py` 가 `SCD_STUDY_CENSUS.csv` 에서 센다. 손으로 세지 않는다.', '',
         '**참가자는 합산하지 않는다.** 같은 코호트가 여러 논문에 나오면 연구는 따로 세고 코호트는 하나로 센다.', '',
         '| 버킷 | 연구 수 | 코호트 수 | 포함 ID |', '|---|---|---|---|']
    total = 0
    for b in BUCKETS:
        rows = by.get(b, [])
        total += len(rows)
        L.append('| %s | %d | %d | %s |' % (b, len(rows), len(cohorts.get(b, set())), ' '.join(r['source_id'] for r in rows)))
    L.append('| **TOTAL_RELATED_STUDIES** | **%d** | | 이 표의 전부 · 망라가 아니다 |' % total)
    L += ['', '## 겹치는 코호트 · 합산 금지', '', '| 코호트 | 연구 | 이유 |', '|---|---|---|']
    groups = defaultdict(list)
    for s in S:
        groups[s['cohort_id']].append(s['source_id'])
    reasons = {
        'C-AZI': '같은 저자 · n 120 · 60/60 · 14~18 · 같은 해',
        'C-SCIP': 'M01 (feasibility) 과 M02 가 같은 20명 · P12 겹칠 가능성',
        'C-SCIP-RCT': '같은 무작위 시험의 두 보고',
        'C-MAN': '맨체스터 AMP 프로그램 · 같은 아동일 가능성 (미확인)',
        'C-EPISLI': 'EpiSLI 같은 데이터베이스',
        'C-AB89': '같은 표본의 두 논문 (Part I · II)',
    }
    for cid, ids in groups.items():
        if len(ids) > 1:
            L.append('| %s | %s | %s |' % (cid, ' '.join(ids), reasons.get(cid, '')))
    strict = by.get('STRICT_DIRECT_SCD_PARTICIPANT_STUDIES', [])
    L += ['', '## 읽는 법', '',
          '- **STRICT 는 %d건이다.** 진단 절차가 임상 DSM-5 로 확인된 것만 넣었다. 13세 위를 포함하는 것은 %s 이고 **대화 자료를 모은 것은 0건**이다'
          % (len(strict), ' · '.join(s['source_id'] for s in strict if '13-17' in s['age_bins'] or '18-25' in s['age_bins'])),
          '- **Svindt 2021 (P01) 은 STRICT 가 아니다.** SPCD 표시는 있으나 진단 절차가 초록에 없다. 범위 판정에서 "DIRECT SPCD 표시 표본"이라고 적는 이유다',
          '- CLOSURE_RESEARCH 의 "direct 9건"은 기준이 적혀 있지 않아 이 표로 재현할 수 없다. 이 표가 대체한다',
          '- 이 census 는 **망라 검색이 아니다.** KCI · RISS · DBpia 는 이번에 조회하지 않았고 WebSearch 예산이 한 차례 소진됐다(`SEARCH_LOG.md`)']
    p = os.path.join(HERE, 'SCD_STUDY_COUNTS.md')
    io.open(p, 'w', encoding='utf-8', newline='\n').write('\n'.join(L) + '\n')
    return p, total, len(strict)


# ───────────────────────── A3 · 연령 ─────────────────────────
AGE = [
    # target, bin, direct_scd_ids, any_population_ids, class_direct, class_any, note
    ('listener_adapted_informativeness', '6-12', 'H02 M03 P10', 'A01 G01', 'CHILD_EVIDENCE (PLI · 혼합 단일 사례)', 'CHILD_EVIDENCE', 'H02 는 PLI · M03 은 n=1'),
    ('listener_adapted_informativeness', '13-17', '', 'G01 A01', 'NONE', 'ADOLESCENT_EVIDENCE (전형 · ASD)', 'Arvidsson 2022 전형 15-16'),
    ('listener_adapted_informativeness', '18-25', '', 'A05', 'NONE', 'YOUNG_ADULT_EVIDENCE (FXS/WS · n=12 · 26+ 걸침)', ''),
    ('reciprocity_responsiveness', '6-12', 'P09 H04 H03 M03', '', 'CHILD_EVIDENCE (한국 체크리스트 SCD · PLI)', 'CHILD_EVIDENCE', ''),
    ('reciprocity_responsiveness', '13-17', '', '', 'NONE', 'NONE', 'NOT FOUND AFTER DEFINED SEARCH'),
    ('reciprocity_responsiveness', '18-25', '', '', 'NONE', 'NONE', ''),
    ('relationship_adaptation', '6-12', 'H03 M03', '', 'CHILD_EVIDENCE (PLI n=6 · 단일 사례)', 'CHILD_EVIDENCE', ''),
    ('relationship_adaptation', '13-17', '', '', 'NONE', 'NONE', ''),
    ('relationship_adaptation', '18-25', '', '', 'NONE', 'NONE', ''),
    ('implicit_meaning_comprehension', '6-12', 'P01 H02 H07 M02', '', 'CHILD_EVIDENCE (SPCD 표시 · PLI)', 'CHILD_EVIDENCE', 'P01 연령 미보고 · 추정'),
    ('implicit_meaning_comprehension', '13-17', '', '', 'NONE', 'NONE', ''),
    ('implicit_meaning_comprehension', '18-25', '', '', 'NONE', 'NONE', ''),
    ('repair_clarification', '6-12', 'H01 (부호화만)', 'A07 A08 A09 A11', 'NONE (부호화만)', 'CHILD_EVIDENCE (LI · ASD · 한국 SLI)', ''),
    ('repair_clarification', '13-17', '', 'A04', 'NONE', 'ADOLESCENT_EVIDENCE (DHH n=32 · 11-16)', ''),
    ('repair_clarification', '18-25', '', '', 'NONE', 'NONE', ''),
    ('topic_management', '6-12', 'P10 (측면별 NR) H08', 'A02', 'NONE (측면별 결과 없음)', 'CHILD_EVIDENCE (ASD)', ''),
    ('topic_management', '13-17', '', 'A03', 'NONE', 'ADOLESCENT_EVIDENCE (ASD n=3)', ''),
    ('topic_management', '18-25', '', 'A05', 'NONE', 'YOUNG_ADULT_EVIDENCE (FXS/WS)', ''),
]


def write_age():
    p = os.path.join(HERE, 'AGE_EVIDENCE_MATRIX.csv')
    with io.open(p, 'w', encoding='utf-8', newline='') as f:
        w = csv.writer(f)
        w.writerow(['scope_family', 'age_bin', 'direct_scd_or_pli_ids', 'any_population_ids', 'class_direct', 'class_any_population', 'note'])
        w.writerows(AGE)
        w.writerow(['ALL', '0-5', 'M01 H08 P04', '', 'CHILD_EVIDENCE (일부)', 'CHILD_EVIDENCE', '대부분 5세 이상'])
        w.writerow(['ALL', '26+', 'D01 (상단 꼬리)', 'A05', 'NONE (행동 자료)', 'SPARSE · 후천성 뇌손상 문헌으로 바뀜', 'Yoshinaga 는 자기보고만'])
    return p


# ───────────────────────── A4 · 도구 ─────────────────────────
TOOLS = [
    # name, construct, subscale, item_count, age, language, population, scd_direct, standardized, normed, responsiveness, reliability, validity, natural_conv, license, public, reproduce, borrow, measures, source
    ('DSM-5 / DSM-5-TR SPCD criteria', '사회적 화용 의사소통', 'A1 사회적 목적 · A2 청자·맥락 맞춤 · A3 대화 규칙(수리 포함) · A4 추론·비문자', '기준 4 (A) + B·C·D', '발달기 시작', 'English', '진단', 'YES (정의)', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'APA 저작권', '인용 가능', '짧은 인용만', 'YES', 'UNDERSTAND(A4) · PERFORM(A1-A3)', 'Swineford 2014 PMC4258293'),
    ('Yuan & Dollaghan item mapping', 'DSM-5 네 특성', '4 특성 + 복수 + 해당 없음', 'item 594 → 206', 'N/A', 'English', '도구 문항', 'YES (문항)', 'N/A', 'N/A', 'N/A', 'κ .69-.76 · 일치 76-82%', 'N/A', 'N/A', 'ASHA 유료', 'NO', 'NO', 'YES', '범위 정의', 'PMID 29587307'),
    ('TOPICC', '대화 화용 행동', '7 범주: 상호성 · 청자 지식(과다·과소) · 말순서 · 장황함 · 화제 · 담화 방식 · 반응 문제', 'item 17 (2011 양식) · Lockton 2016 은 12 측면 부호화', '6-11 (SCIP)', 'English', 'PLI · SCD · HFA', 'MIXED', 'NO', 'NO (저자: 앞으로도 없을 것)', 'SCIP-GAS 연구에서 TOPICC-2 상승 (단일군)', '관찰·부호화 신뢰도 미수행 · PLI 50명 전반 인상 일치 80%', 'CCC-2 대응 88.3%', 'YES (반구조화)', '저작권 Adams 외 2010 · 배포 경로 404', 'NO', 'NO', 'YES', 'PERFORM', 'research/AMP_TOPICC_검증.md'),
    ('TOPICC-2', '대화 상호작용 관찰 평정', 'NOT FOUND AFTER DEFINED SEARCH', NR, '5-11 (Adams & Gaile 2020)', 'English', 'SPCD + HFASD', 'MIXED', 'NO', 'NO', '단일군에서 상승', NR, NR, 'YES', NR, 'NO', 'NO', 'YES', 'PERFORM', 'PMID 32771922'),
    ('AMP (Assessment of Metapragmatics)', '상위화용 명시화', '영상 13 상황 · 5 문항 유형', 'situation 13', '6-11', 'English', 'TD + 의사소통장애', 'MIXED', 'NO', '발달 참조만', NR, '"satisfactory" 계수 초록에 없음 · CLOSURE 의 .712/.715 는 EVIDENCE_LEDGER 대조', '공인타당도 미확립', 'NO (영상)', '비공개 연구도구', 'NO', 'NO', 'YES', 'UNDERSTAND (지식)', 'PMID 25173072'),
    ('PRS-SA (Pragmatic Rating Scale School Age)', 'ADOS 영상 화용 평정', '4 영역 (CLOSURE 기록) · 19 행동 (Swineford)', 'item 23+5 (CLOSURE 기록 · 대조 필요)', '7-12', 'English', 'ASD · SCI', 'MIXED', 'NO', 'NO', NR, '가중 κ .831 (CLOSURE 기록 · 대조 필요)', NR, 'ADOS 표본', NR, 'NO', 'NO', 'YES', 'PERFORM', 'PMID 34388006'),
    ('SCIP-SCCheck', '다섯 영역 선별', '맥락 이해 · 비언어 · 대화 · 부적절 말 · 비문자', '영역 5', '5-11', 'English', 'SPCD 선별', 'MIXED', 'NO', 'NO', '변화 지표 아님', '보고 없음', NR, 'NO', '맨체스터', 'NO', 'NO', 'YES', '선별', 'PMC7510260'),
    ('SCIP-GAS', '개인 목표 달성', '부모 우선순위 3 → 목표 3', 'goal 3', '5-11', 'English', 'SPCD', 'MIXED', 'NO (개별화)', 'NO', '부모 1명 빼고 전원 진전 · 대조 없음', '보고 없음', NR, 'NO', '맨체스터', 'NO', 'N/A', 'YES', 'TRANSFER (가정 목표)', 'PMC7510260'),
    ('CCC / CCC-2', '일상 의사소통 보고', '10 하위척도 · GCC · SIDC', 'item 약 70', '4-16', 'English (다수 번역)', 'SLI · PLI · ASD', 'MIXED', 'YES', 'YES', 'NOT REPORTED (Pereira 2025)', '내적 .66-.80 · 재검사 .86-.96 · 평정자간 하위 .157-.559', '있음', 'NO', 'Pearson', 'NO', 'NO', 'YES', 'TRANSFER 대리', 'PMC12078967'),
    ('CELF-5 Pragmatics Profile', '화용 행동', '프로파일 + 활동 체크리스트', NR, '5-21', 'English', '일반', 'NO', 'YES', 'YES (척도 점수)', NR, '출판사 페이지에 계수 없음', NR, 'NO', 'Pearson', 'NO', 'NO', 'YES', 'TRANSFER 대리', 'research/agent_outcome_measures.md'),
    ('SLDT-E / SLDT-A', '사회 언어 추론', '조망 · 추론 · 협상 · 다중 해석', NR, '초등 · 청소년판', 'English', '일반', 'NO', 'YES', 'YES', 'Making Inferences 가 SCIP 에서 상승 (단일군)', 'NOT FOUND AFTER DEFINED SEARCH', NR, 'NO', 'PRO-ED', 'NO', 'NO', 'YES', 'UNDERSTAND', 'PMID 32771922'),
    ('KOPLAC', '한국 메타-화용', '3 하위검사 · 6 하위영역 · AMP 문항 유형 둘 차용', 'item 53 (학령전) · 67 (학령)', '5;0-12;11', 'Korean', '일반 아동 270 규준', 'NO', 'YES', 'YES', NR, '논문 참조', '언어장애 아동 추가 타당화 필요 (저자)', 'NO', '파라다이스복지재단 판매', 'NO', 'NO', 'YES', 'UNDERSTAND', 'doi 10.12963/csd.18467'),
    ('CPLC (아동화용언어체크리스트)', '한국 부모 보고 화용', '담화관리 9 · 상황 조절 15 · 의도 12 · 비언어 8', 'item 44 · 0-3', '5-13', 'Korean', '아동', 'NO', '표준화 작업 중 (2018)', 'NO', NR, '하위영역 민감·특이 80-90% · 총점 특이도 약 50%', '대화 관찰 상관 연구 있음', 'NO', '출판 여부 미확인', 'NO', 'NO', 'YES', 'TRANSFER 대리', 'research/국내_화용평가도구.md'),
    ('Pragmatics Profile (Dewart & Summers)', '일상 기능 의사소통', '구조화 부모 면담 · 개정판 64 질문', 'question 64 (개정)', '영유아 · 학령 · 성인판', 'English · Dutch', '일반', 'NO', 'NO', '네덜란드 파생판 규준', NR, '"high" 계수 없음', NR, 'NO', '절판 · 개정판', 'PARTIAL', 'NO', 'YES', 'TRANSFER', 'PMID 37431989'),
    ('La Trobe Communication Questionnaire', '성인 의사소통 자기·타인 보고', NR, 'NOT VERIFIED (project source 없음)', '성인', 'English', '후천성 뇌손상 전통', 'NO', NR, NR, NR, NR, NR, 'NO', NR, NR, 'NO', 'YES', 'TRANSFER', 'AGE_EVIDENCE.md §1 (이름만)'),
    ('Pragmatic Protocol (Prutting & Kirchner)', '대화 화용 매개변수', '언어 · 준언어 · 비언어 · 30 매개변수', 'parameter 30', '전 연령', 'English', '일반', 'NO', 'NO', 'NO', NR, NR, NR, 'YES', '논문 공개', 'YES (논문)', '매개변수 이름 수준', 'YES', 'PERFORM', 'PMID 3573742'),
    ('Conversation analysis measures (Adams & Bishop 1989 체계)', '교환 구조 · 말순서 · 수리 · 결속', '4 영역', NR, '4-12', 'English', 'SPD', 'HISTORICAL_PLI', 'NO', 'NO', 'Adams 2006 에서 치료 후 변화', '"adequate" 계수 없음', NR, 'YES', '논문', 'NO', 'NO', 'YES', 'PERFORM', 'PMID 2627544'),
    ('ABaCo', '다섯 척도 의사소통', '언어 · 언어외 · 준언어 · 맥락 · 대화 · 이해와 산출 교차', 'item 172', '규준 15-75', 'Italian', '일반 + 임상', 'NO', 'YES', 'YES', NR, 'Gabbatore 2025 평정자간 미보고', NR, 'PARTIAL', 'CC BY-NC-ND (2025 논문)', 'NO', 'NO', 'YES', 'UNDERSTAND + PERFORM', 'PMC11696771'),
    ('BOSCC', '사회적 의사소통 변화 관찰', '사회 의사소통 · 반복 행동', NR, '아동', 'English', 'ASD', 'NO', 'NO', 'NO', 'NOT REPORTED', '평정자간 ICC .97-.98 · 재검사 .89', NR, 'YES', NR, 'NO', 'NO', 'YES', 'PERFORM 변화', 'PMC12078967'),
    ('Transition Pragmatics Interview (TPI)', '청소년·청년 화용', 'see AGE_EVIDENCE.md §5', NR, '14-21/22', 'English', '전환기', 'NO', NR, NR, NR, NR, 'COSMIN 검토 (Poll 2021)', 'YES (면담)', NR, NR, 'NO', 'YES', 'PERFORM', 'AGE_EVIDENCE.md §5'),
]


def write_tools():
    p = os.path.join(HERE, 'ASSESSMENT_TOOL_MATRIX.csv')
    with io.open(p, 'w', encoding='utf-8', newline='') as f:
        w = csv.writer(f)
        w.writerow(['tool', 'construct', 'subscale_category', 'item_count', 'age', 'language', 'population', 'scd_direct', 'standardized',
                    'normed', 'responsiveness', 'reliability', 'validity', 'natural_conversation', 'copyright_license', 'publicly_available',
                    'can_reproduce_items', 'can_borrow_construct_only', 'measures_UNDERSTAND_PERFORM_TRANSFER_MAINTENANCE', 'source'])
        w.writerows(TOOLS)
    return p


# ───────────────────────── A7 · 네 층 ─────────────────────────
GAP = [
    ('L1 SCD target grounding', 'DSM-5 기준 A 문장 · Yuan & Dollaghan 206문항(비공개) · TOPICC 17문항 구조', 'PARTIALLY_EXISTING',
     '행동 수준 결과는 PLI 초록 몇 건 · 13-25 NONE', 'NO', '범위 판정은 이것으로 한다 (ONTOLOGY_SCOPE_FINAL)', 'T01 T04 R02 H02 H03 H04 P01'),
    ('L2 semantic / pragmatic grounding', '3i4K · ToM-Diary · 간접화행 240 · 화용 평가셋 120 · KoCoSa · 국어원 맥락추론', 'PARTIALLY_EXISTING',
     '임상군 아님 · 다수가 권리 유보 · 대화가 아닌 것 섞임 (DATASET_CENSUS_KO)', 'NO', '해석 틀과 씨앗 표면으로만', 'DATASET_CENSUS_KO.csv'),
    ('L3 scenario seed', '규격 §5.3 씨앗 10 + 개발용 4 · blind 후보 40 (+40 의뢰)', 'EXISTING (합성)',
     '품질 미검증 · A1 이 판정', 'YES (blind 선별 · 앵커 확인)', 'POC B 는 A PASS 뒤', 'skill_family_seeds.json'),
    ('L4 personal event + longitudinal', '없음', 'MISSING', '0 건', 'YES (POC C 5-10명 x 2-3건)', '대체 불가 · 서비스가 모은다', 'POC C'),
    ('A1 gold (동등성 판정)', '없음', 'MISSING', '0 쌍', 'YES (판정자 2 · 60/120쌍)', 'A2 · E0~E4 의 기준', 'A1_PROTOCOL.md'),
    ('rubric 신뢰도', '없음', 'MISSING', '0 시행', 'YES (평정자 2)', '향상 주장의 전제', 'H-03'),
]


def write_gap():
    p = os.path.join(HERE, 'DATA_GAP_MATRIX.csv')
    with io.open(p, 'w', encoding='utf-8', newline='') as f:
        w = csv.writer(f)
        w.writerow(['layer', 'what_exists', 'status', 'gap', 'must_collect', 'role', 'refs'])
        w.writerows(GAP)
    return p


if __name__ == '__main__':
    p1 = write_census()
    p2, total, strict = write_counts()
    p3 = write_age()
    p4 = write_tools()
    p5 = write_gap()
    from collections import Counter
    c = Counter(s['bucket'] for s in S)
    print('census 연구 %d · STRICT %d' % (total, strict))
    for b in BUCKETS:
        print('  %-40s %d' % (b, c.get(b, 0)))
    print('age rows %d · tools %d · gap layers %d' % (len(AGE) + 2, len(TOOLS), len(GAP)))
