# SCD STUDY COUNTS · A2

`build_evidence_tables.py` 가 `SCD_STUDY_CENSUS.csv` 에서 센다. 손으로 세지 않는다.

**참가자는 합산하지 않는다.** 같은 코호트가 여러 논문에 나오면 연구는 따로 세고 코호트는 하나로 센다.

| 버킷 | 연구 수 | 코호트 수 | 포함 ID |
|---|---|---|---|
| STRICT_DIRECT_SCD_PARTICIPANT_STUDIES | 5 | 5 | D01 D02 D03 D04 D05 |
| DIRECT_BUT_ALGORITHMIC_OR_PUTATIVE | 12 | 9 | P01 P02 P03 P04 P05 P06 P07 P08 P09 P10 P11 P12 |
| MIXED_SPCD_ASD | 7 | 6 | M01 M02 M03 M04 M05 M07 M08 |
| HISTORICAL_PLI | 10 | 8 | H01 H02 H03 H04 H05 H06 H07 H08 H09 H10 |
| ADJACENT_ASD_DLD | 12 | 12 | A01 A02 A03 A04 A05 A06 A07 A08 A09 A10 A11 A12 |
| ITEM_MAPPING_OR_TOOL_STUDIES | 9 | 9 | M06 T01 T02 T03 T04 T05 T06 T07 T08 |
| REVIEW_STUDIES | 8 | 8 | R01 R02 R03 R04 R05 R06 R07 R08 |
| GENERAL_PRAGMATICS | 1 | 1 | G01 |
| **TOTAL_RELATED_STUDIES** | **64** | | 이 표의 전부 · 망라가 아니다 |

## 겹치는 코호트 · 합산 금지

| 코호트 | 연구 | 이유 |
|---|---|---|
| C-EPISLI | P05 P06 | EpiSLI 같은 데이터베이스 |
| C-AZI | P07 P08 | 같은 저자 · n 120 · 60/60 · 14~18 · 같은 해 |
| C-MAN | P10 P11 | 맨체스터 AMP 프로그램 · 같은 아동일 가능성 (미확인) |
| C-SCIP | P12 M01 M02 | M01 (feasibility) 과 M02 가 같은 20명 · P12 겹칠 가능성 |
| C-AB89 | H01 H02 | 같은 표본의 두 논문 (Part I · II) |
| C-SCIP-RCT | H08 H09 | 같은 무작위 시험의 두 보고 |

## 읽는 법

- **STRICT 는 5건이다.** 진단 절차가 임상 DSM-5 로 확인된 것만 넣었다. 13세 위를 포함하는 것은 D01 · D04 · D05 이고 **대화 자료를 모은 것은 0건**이다
- **Svindt 2021 (P01) 은 STRICT 가 아니다.** SPCD 표시는 있으나 진단 절차가 초록에 없다. 범위 판정에서 "DIRECT SPCD 표시 표본"이라고 적는 이유다
- CLOSURE_RESEARCH 의 "direct 9건"은 기준이 적혀 있지 않아 이 표로 재현할 수 없다. 이 표가 대체한다
- 이 census 는 **망라 검색이 아니다.** KCI · RISS · DBpia 는 이번에 조회하지 않았고 WebSearch 예산이 한 차례 소진됐다(`SEARCH_LOG.md`)
