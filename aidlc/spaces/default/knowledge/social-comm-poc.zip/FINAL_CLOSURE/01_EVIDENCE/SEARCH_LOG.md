# SEARCH LOG · 색인

2026-09-14 · 이 프로젝트의 검색 기록은 조사마다 그 문서 안에 있다. 여기는 **어디에 무엇이 있는지와, 무엇을 찾지 않았는지**를 한 장에 모은다.
"전 세계에 없다"는 문장을 쓰지 않는다. 부재 진술은 전부 **NOT FOUND AFTER DEFINED SEARCH** 이고 그 정의(데이터베이스 · 질의 · 날짜)가 아래 문서에 있다.

---

## 1 · 조사별 검색 기록의 위치

| 조사 | 날짜 | 기록 위치 | 데이터베이스 · 엔드포인트 |
|---|---|---|---|
| SCD / SPCD 직접 근거 census | 2026-09-12 | `research/agent_scd_census.md` §4 · §6 | Europe PMC REST · PubMed · Crossref · OpenAlex · Unpaywall · Semantic Scholar · Manchester Research Explorer · Wayback |
| 연령 근거 (13~25) | 2026-09-12 | `01_EVIDENCE/AGE_EVIDENCE.md` §7 · §8 | Europe PMC REST · fullTextXML |
| 결과 측정 도구 · 전이 · 지식-수행 | 2026-09-12 | `research/agent_outcome_measures.md` (TOOL STATUS · 각 절) | Europe PMC · Semantic Scholar · CORE · 출판사 페이지 |
| LLM 판정 · 보정 · gold 크기 | 2026-09-12 | `research/agent_llm_judge.md` (Explicit non-findings · Resources used) | arXiv API · ACL Anthology PDF · Semantic Scholar |
| Dorner 정리 · 실제 경험 → 훈련 선례 · E0~E4 | 2026-09-12 | `01_EVIDENCE/THEOREM_AND_PRECEDENT.md` §1.9 · §2.10 · 부록 | ar5iv 전문 · arXiv API · Europe PMC fullTextXML |
| 한국 개인정보 · IRB · 의료기기 | 2026-09-12 | `08_ETHICS/KOREA_PRIVACY_IRB_REVIEW.md` 부록 A | 국가법령정보센터 공개 API · PIPC |
| 경쟁 · 선행 서비스 | 2026-09-12 | `09_PRIOR_ART/COMPETITOR_MATRIX.md` §0 · 부록 | App Store 검색 API (미국 스토어) · arXiv · Europe PMC · CRIS · 제품 페이지 |
| 수리 · 공손성 · 분류 · 목표 | 2026-09-13 | `02_SCOPE/_agent_pragmatics_review.md` §6 | Europe PMC REST · Crossref · Semantic Scholar (429) · e-csd.org |
| 한국어 · 국제 데이터셋 | 2026-09-14 | `01_EVIDENCE/SEARCH_LOG_DATASETS.md` (데이터셋 감사 결과가 오면) | 에이전트 기록 |
| 수치 대조 | 2026-09-14 | `01_EVIDENCE/EVIDENCE_LEDGER_NOTES.md` §3 (검증 결과가 오면) | 에이전트 기록 |
| 이전 조사 (2026-09-11) | 2026-09-11 | `research/데이터셋_실사.md` · `research/국내_화용평가도구.md` · `research/AMP_TOPICC_검증.md` · `research/SCD_문헌.md` | RISS · KCI(일부) · GitHub · AI Hub |

---

## 2 · 찾지 않은 곳 · 모든 부재 진술에 붙는 한계

| 어디 | 상태 | 영향 |
|---|---|---|
| **KCI · RISS · DBpia** | 2026-09-12 이후 조사에서 **조회하지 않음** (2026-09-11 조사에서 RISS 일부만) | 국내 SCD · 화용 선행연구가 빠져 있을 수 있다 |
| **Google Play** | 조회하지 않음 | 안드로이드 전용 앱이 경쟁표에서 빠져 있다 |
| Apple App Store | **미국 스토어만 · 키워드당 상위 6~8개** | 한국 스토어 전용 앱 누락 가능 |
| Scopus · Web of Science | 접근 없음 | 인용 추적 불가 |
| 유료 전문 (Wiley · T&F · ASHA) | 다수 403 · CAPTCHA | Lockton 2016 · Adams & Bishop 1989 전문 · Yuan & Dollaghan 2018 원문 도구 목록 미확인 |
| WebSearch | 2026-09-12 세션에서 **200/200 소진** · 이후 API 직접 호출 | 검색 엔진 기반 탐색이 약하다 |

---

## 3 · 이번에 확정된 NOT FOUND AFTER DEFINED SEARCH 목록

| 무엇 | 정의된 검색 | 문서 |
|---|---|---|
| DSM-5 SCD 진단 표본에서 수리 · 명료화 요청을 잰 연구 (전 연령) | Europe PMC 질의 4 · 65건 제목 전수 · Korean CSD 20건 | `_agent_pragmatics_review.md` §5-1 |
| 한국 윗사람 대상 명료화 · 수리 선호 전략 | 질의 8종 · KCI 미접근 | 같음 §5-4 · 5-5 |
| 목표를 묻는 것과 묻지 않는 것을 비교한 사회 의사소통 중재 연구 | 질의 5종 | 같음 §5-14 |
| TOPICC · TOPICC-2 항목 목록 · 신뢰도 | 질의 6종 · 사이트 404 · Wayback 없음 | `agent_scd_census.md` §3 · `_agent_pragmatics_review.md` §5-3 |
| 13~18세를 대상으로 한 SCD 전용 중재 (SCD 만 등록) | Europe PMC | `AGE_EVIDENCE.md` §7-7 |
| 일본 밖 두 번째 성인 SCD 코호트 | 같음 | 같음 §7-6 |
| 한국 SCD 코호트 연구 | 같음 | 같음 §7-8 |
| 대화 속 간접 거절 · 반어 · 비꼼을 SCD 표본에서 잰 연구 | census + 연령 + 수리 조사 질의의 합집합 | `02_SCOPE/ONTOLOGY_SCOPE_FINAL.md` §3-2 |
| 사회 · 화용 추론 과제에서 E1 대 E2 독립 비교 | arXiv 질의 2종 | `THEOREM_AND_PRECEDENT.md` §3.2 |
| 전형적 효과 크기 (prompt-only 대 external structure) | 같음 | 같음 §3.4 |
| 능동학습의 단일 절감 백분율 | Settles 2009 전문 | `agent_llm_judge.md` C4 · **NOT ESTABLISHED** |
| 이중 주석 + 조정의 표준 표본 크기 | 같음 | `agent_llm_judge.md` D4 |
| 공용 IRB 신청 절차 · 서식 | nibp.kr 본문 확보 실패 | `KOREA_PRIVACY_IRB_REVIEW.md` §8 |
| 사회기술 앱 Social Ace · Noora(사회기술) | 도메인 · App Store · Europe PMC · arXiv | `COMPETITOR_MATRIX.md` §0 |
| 15~30세 한국어 표준화 화용 평가도구 | RISS 화용언어 표준화 성인 0건 | `research/국내_화용평가도구.md` ① |

---

## 4 · 이 색인이 약속하지 않는 것

**체계적 문헌고찰이 아니다.** PRISMA 흐름도가 없고 두 번째 선별자가 없다.
그래서 이 프로젝트의 어떤 부재 진술도 "없다"가 아니라 **"이 정의로 찾았을 때 없었다"**로 읽어야 한다.
