# AGE EVIDENCE MATRIX — Social (Pragmatic) Communication Disorder and Pragmatic Communication Difficulty

**Search date:** 2026-09-12
**Question:** What evidence exists above age 12, given that the project targets adolescents and young adults (~13–25)?
**Method:** Direct REST queries against Europe PMC, NCBI E-utilities (esearch/efetch), and Europe PMC full-text XML. `WebSearch` was exhausted (200/200) in this session and was not used.

---

## 0. Bottom line

The field's centre of mass is ages 5–12. Above 12 the literature thins to a **small, non-overlapping set of roughly a dozen studies**, and the shape of that set matters more than its size:

1. **There is exactly one substantial adult SCD cohort found in this search** — Yoshinaga et al. 2023 (Japan, n = 52 SCD, ages 16–52). It is a *screening-instrument* study. It collected no conversation data and no pragmatic task data.
2. **There is exactly one assessment instrument built from scratch for this age band** — the Transition Pragmatics Interview (TPI, Poll et al.), developed across five papers on 14–22-year-olds. This is the single most directly transferable asset found.
3. **The four MVP pragmatic targets have essentially no direct SCD evidence above age 12.** Where adolescent/adult evidence exists it comes from *adjacent* populations (ASD, deaf/hard-of-hearing, Fragile X/Williams, typical development). This is stated per-target in §6.
4. **The Parsons et al. 2017 intervention gap is real and I verified it in full text** (§4.1). It has since been *partially* filled — but by ASD-population studies, and only three of them.

---

## 1. Age evidence matrix (bins)

Counts are **studies**, not participants. A study spanning two bins is counted in both and marked. **Participants are never summed across studies** — several pairs are known or suspected to share a sample (flagged inline).

| Bin | Direct SCD/SPCD | Adjacent (ASD/DLD/DHH/genetic) | Tools | Interventions | Density |
|---|---|---|---|---|---|
| **0–5** | Saul 2023 (5–6) | many | CCC-2, ABaCo | many | Dense |
| **6–12** | Saul 2023; Mandy 2017 (part); Jain 2025; Adams 2020 (5–11); Gabbatore 2025 (part) | many | CCC-2, PRS-School Age, Pragmatics Observational Measure-2 | Parsons 2017 pool (21 studies, 21 mo–14 yr) | **Dense — field centre of mass** |
| **13–17** | Ellis Weismer 2021 (13–14); Azizpour 2026a/b (14–18, same sample); Mandy 2017 (part, count unreported); Güler 2026 (part); Tsai 2020; Tsai 2022 (n=1) | Ayvazo 2026 (16–18); Sadati 2024 (11–16); Karin 2026 (6–16); Arvidsson 2022 (15–16); Almehmadi 2020; Richardson 2026 (9–16) | **TPI (14–21/22)**; Poll 2021 COSMIN review (13 tools, 14–21) | Yoo 2025 (10–18, incl. SCD); Ayvazo 2026 (16–18) | **Sparse** |
| **18–25** | Yoshinaga 2023 (16–52, majority band); Güler 2026 (15–21 part); Teruya 2025 (age unreported) | Arturi 2025 (18–25); Algahtani 2026 (15–28); Whitehouse 2009 (PLI M=22;3) | TPI upper bound (21/22); LCQ (adult, acquired-injury tradition) | Arturi 2025 (n=10) | **Very sparse** |
| **26+** | Yoshinaga 2023 (upper tail to 52) | Diez-Itza 2022 (adults FXS/WS); LCQ/MEC acquired-injury literature | LCQ, Protocole MEC, PRS-adult (BAP studies) | — | Sparse, and almost entirely **acquired** rather than developmental |

**The structural finding:** above age 12, developmental pragmatic disorder evidence does not simply thin out — it **changes character**. It is replaced by (a) acquired-injury adult literature (TBI, stroke, right-hemisphere damage) which uses different instruments and a different disorder model, and (b) autism-adult literature. Developmental SCD as such nearly disappears after 18 except for the single Japanese cohort.

---

## 2. DIRECT SCD / SPCD studies

Population flags: **DIRECT SCD** = DSM-5 SCD/SPCD diagnosis or explicit DSM-5 criteria operationalised.

### 2.1 Yoshinaga, Egawa, Watanabe, Kasahara, Sugimoto & Someya (2023) — THE JAPANESE ADULT COHORT
- **Title:** Usefulness of the autism spectrum quotient (AQ) in screening for autism spectrum disorder and social communication disorder
- **Journal:** BMC Psychiatry 23(1):831 · **DOI:** 10.1186/s12888-023-05362-y · **PMID:** 37957611 · **PMC:** PMC10644653
- **N:** **52 SCD** (20 F / 32 M), plus 127 ASD and 49 neurotypical
- **Exact age:** SCD mean **28.1 ± 9.06**, **range 16–52**. (ASD 28.0 ± 9.69, range 16–59; NT 30.3 ± 10.11, range 16–59)
- **Population flag:** **DIRECT SCD**
- **Diagnostic method:** Clinical diagnosis by psychiatrists using all available information — unstructured interviews with participants and families, clinical observation, medical records. **No structured diagnostic instrument.** The authors state plainly in their limitations: *"no structured interview tool is available for SCD."* IQ > 70 confirmed for all (WAIS-III/IV, WISC-III/IV, or JART).
- **Language/country:** Japanese, Niigata (Niigata University Graduate School + Niigata Psychiatric Center + Uonuma Kikan Hospital)
- **Task type:** Self-report questionnaire only — AQ-J (50 items), ROC analysis
- **Natural conversation collected:** **NO**
- **Read:** **FULL TEXT** (Europe PMC fullTextXML)
- **Key numbers:** SCD vs NT AUC 0.89, cutoff 22 (sens 84.6%, spec 85.7%). ASD vs SCD AUC **0.75**, cutoff 32 (sens 67.7%, spec 71.2%) — i.e. the AQ **separates SCD from neurotypical well but separates SCD from ASD poorly**. AQ total: ASD 33.80 ± 7.00 (range 15–57), SCD 27.65 ± 6.15 (range 13–38), NT 14.51 ± 7.75 (range 1–34).
- **Why it matters here:** This is the **only adult-majority SCD sample found**. It confirms adult SCD exists as a clinical population and is diagnosable, but it supplies **zero** behavioural/pragmatic/conversational data. Any adult-facing claim about *what* adult SCD looks like in interaction cannot be grounded in this paper.

### 2.2 Ellis Weismer, Tomblin, Durkin, Bolt & Palta (2021)
- **Title:** A preliminary epidemiologic study of social (pragmatic) communication disorder in the context of developmental language disorder
- **Journal:** Int J Lang Commun Disord 56(6):1235–1248 · **DOI:** 10.1111/1460-6984.12664 · **PMID:** 34383380 · **PMC:** PMC8890438
- **N:** 393 · **Exact age:** **8th grade, 13–14 years**
- **Population flag:** **DIRECT SCD** (two DSM-5-reflecting case definitions operationalised on CCC-2, 1.5 SD cut-point; second definition via principal component analysis requiring pragmatic/social to be disproportionately below structural language)
- **Diagnostic method:** CCC-2 (Children's Communication Checklist-2), parent report. Secondary analysis of the **EpiSLI** database.
- **Language/country:** English, USA (Wisconsin/Iowa)
- **Task type:** Checklist only · **Natural conversation:** **NO**
- **Read:** ABSTRACT ONLY (the structured abstract is unusually detailed; Methods/Results sections not read in full)
- **Key numbers:** Prevalence **7% (SE 1.5%) to 11% (SE 1.7%)** depending on cut-point. Definition 1: SCD far more common with DLD history; kindergarten language disorder a significant risk factor. Definition 2: SCD equally distributed across DLD/non-DLD; **male sex** a significant risk factor.
- **Why it matters:** The **single best population-based estimate in the 13–17 band**. Note it is an adolescent sample measured with a *child* instrument at the top of its range.

### 2.3 Mandy, Wang, Lee & Skuse (2017)
- **Title:** Evaluating social (pragmatic) communication disorder
- **Journal:** J Child Psychol Psychiatry 58(10):1166–1175 · **DOI:** 10.1111/jcpp.12785 · **PMID:** 28741680
- **N:** **1,081 total; 88 met SPCD criteria** (801 ASD, 192 clinical comparison)
- **Exact age:** **4–18 years** — **the age distribution of the 88 SPCD cases is NOT reported in the abstract.** Do not assume adolescent representation.
- **Population flag:** **MIXED SPCD+ASD** (specialist social-communication clinic; fluent language, normal-range IQ)
- **Diagnostic method:** Algorithm built from 3Di (Developmental, Dimensional and Diagnostic Interview) + CCC items implementing DSM-5 SPCD criteria; SDQ for psychopathology
- **Language/country:** English, UK (UCL / Great Ormond Street Hospital)
- **Task type:** Parent-report interview + checklists · **Natural conversation:** **NO**
- **Read:** ABSTRACT ONLY
- **Key numbers:** Core SPCD symptoms cohered only moderately (mean inter-item r = **.22**). SPCD social difficulty **intermediate** between ASD and clinical comparison. **63.5%** of SPCD cases in the abnormal range on SDQ Total Problems.
- **Conclusion as stated by authors:** SPCD was **not** qualitatively distinct from ASD; it "lies on the borderlands of the autism spectrum."

### 2.4 Azizpour, Hemati Alamdarloo, Shojaei & Moradi (2026a)
- **Title:** The hidden cost of fitting in: social camouflage in adolescents with social communication disorder
- **Journal:** Front Psychol 17:1839647 · **DOI:** 10.3389/fpsyg.2026.1839647 · **PMID:** 42325324 · **PMC:** PMC13279079
- **N:** **120** (60 SCD, 60 non-SCD matched on age, gender, educational level) · **Exact age:** **14–18 years**
- **Population flag:** **DIRECT SCD**
- **Diagnostic method:** Stated as "diagnosed with SCD" — **diagnostic instrument not specified in abstract**
- **Language/country:** Persian, Iran (Mashhad-Marghab region, Fars province; Shiraz University)
- **Task type:** Self-report questionnaire — CAT-Q (Camouflaging Autistic Traits Questionnaire) · **Natural conversation:** **NO**
- **Read:** ABSTRACT ONLY
- **Findings:** SCD adolescents reported significantly higher overall camouflaging and higher compensation, masking, and assimilation subscales. Males > females on all three.

### 2.5 Azizpour, Alamdarloo, Shojaei & Moradi (2026b)
- **Title:** Intolerance of uncertainty in adolescents with and without social communication disorder: group and gender differences
- **Journal:** Front Psychiatry 17:1803782 · **DOI:** 10.3389/fpsyt.2026.1803782 · **PMID:** 42064161 · **PMC:** PMC13125014
- **N:** **120** (60 SCD, 60 TD) · **Exact age:** **14–18 years** · **Population flag:** **DIRECT SCD**
- **Task type:** Intolerance of Uncertainty Scale (IUS), self-report · **Natural conversation:** **NO** · **Read:** ABSTRACT ONLY
- **Findings:** SCD > non-SCD on overall IU and all four subscales; males > females; no interaction.
- **⚠ OVERLAP WARNING:** Same authors, same institution, same n = 120, same 60/60 split, same age range 14–18, same matching variables, both published 2026. **These are almost certainly the same sample reported twice.** Do **not** treat as 240 adolescents. Treat as **one** adolescent SCD sample of n = 120 (60 cases) measured on two self-report instruments.

### 2.6 Güler, Güngör, Özdemir, Çelik, Akbulut, Nakipoğlu & Kandeğer (2026)
- **Title:** Transition clinic for neurodevelopmental disorders: preliminary findings from an interdisciplinary model for adolescence to adulthood
- **Journal:** Front Psychiatry 17:1882420 · **DOI:** 10.3389/fpsyt.2026.1882420 · **PMID:** 42592153 · **PMC:** PMC13463183
- **N:** **68** · **Exact age:** **15–21 years**, mean **17.90 ± 1.90**, 54.4% male
- **Population flag:** **MIXED** — neurodevelopmental transition clinic; **SPCD explicitly among the diagnoses newly identified**, but **the SPCD case count is not reported in the abstract**
- **Diagnostic method:** Three-stage interdisciplinary model — referral/pre-assessment, interdisciplinary diagnostic evaluation (child + adult psychiatrists, consultant neurologist), genetic evaluation where indicated
- **Language/country:** Turkish, Türkiye (Selçuk University, Konya)
- **Task type:** Clinical diagnostic evaluation · **Natural conversation:** **NO** · **Read:** ABSTRACT ONLY
- **Key numbers:** Median diagnoses rose from 1 (range 0–4) pre-clinic to **3 (range 1–11)** post-evaluation. ADHD most frequent NDD (66.2%). **80% of ASD diagnoses were first identified in the transition clinic.** SPCD listed among conditions "frequently newly identified."
- **Why it matters:** This is the **only paper found that directly addresses SCD detection in the 15–21 transition window**, and its headline finding is that this population is **systematically under-identified until someone looks**. Directly supportive of a 13–25 targeting rationale.

### 2.7 Saul, Griffiths & Norbury (2023) — the child-band anchor
- **Journal:** J Child Psychol Psychiatry 64(3):376–387 · **DOI:** 10.1111/jcpp.13705 · **PMID:** 36114685 · **PMC:** PMC10087005
- **N:** 386 · **Exact age:** **5–6 years** · **Population flag:** DIRECT SCD (CCC-2 algorithms approximating DSM-5 inclusion/exclusion criteria)
- **Country:** UK (SCALES population sample) · **Natural conversation:** NO · **Read:** ABSTRACT ONLY
- **Key numbers:** Isolated social-communication difficulty **0–1.3%**; social-pragmatic difficulty *with* structural language problems and/or autistic symptoms **6.1–10.5%**.
- **Listed because** it is the most-cited prevalence figure in the field and is drawn from **5–6-year-olds**. Citing it as background for a 13–25 product requires explicit acknowledgement of the age mismatch.

### 2.8 Other DIRECT SCD, child band (for completeness — all CHILD_ONLY unless noted)

| Study | Journal / ID | N | Age | Notes | Read |
|---|---|---|---|---|---|
| Jain, Multani, Dodiya, Benani & Iyer (2025) | Autism 29(4):829–837; 10.1177/13623613251317787; PMID 39943881 | 232 ASD, **90 SCD** | "children" — **exact range not in abstract** | Vineland-III; DSM-5 + AIIMS-modified INCLEN. SCD showed better adaptive behaviour than ASD across all domains. India | ABSTRACT ONLY |
| Adams, Gaile, Roddam, Baxendale et al. (2020) | Pilot Feasibility Stud 6:137; 10.1186/s40814-020-00658-2; PMID 32983554 | 24 | **5–11** | **SCIP** — the only manualised SLT programme feasibility trial specifically for SPCD. **Stops at age 11.** | ABSTRACT ONLY |
| Gabbatore, Marchetti Guerrini & Bosco (2025) | Sci Rep 15:348; 10.1038/s41598-024-83280-z; PMID 39747328 | not in abstract | "children and adolescents" with BES-NOS — **exact range not in abstract** | ABaCo battery; cluster analysis to surface *undiagnosed* SPCD. Italy | ABSTRACT ONLY |
| Tsai & Lin (2020) | J Autism Dev Disord 50(2):685–687; 10.1007/s10803-019-04265-w; PMID 31650372 | small (brief report) | adolescents with ADHD | Diagnostic migration ASD → SCD | ABSTRACT ONLY |
| Tsai, Lin & Lee (2022) | Psychiatr Danub; 10.24869/psyd.2022.96; PMID 35467619 | **1** | adolescent | Case report: SCD + ADHD + Tourette, aripiprazole | ABSTRACT ONLY |
| Flax, Gwin, Wilson, Fradkin, Buyske & Brzustowicz (2019) | Autism 23(8):1982–1992; 10.1177/1362361318822503; PMID 30931583 | family genetics study | probands, siblings, **parents (adults)** | **MIXED / BAP.** 36.6% of language-impaired family members had ≥ mild social communication impairment. Concludes SPCD does **not** capture children with both SCI and RRB | ABSTRACT ONLY |
| Teruya, Kurihara, Ishibashi, Ota, Shinzato, Takaesu & Kondo (2025) | PCN Rep 4(1):e70084; 10.1002/pcn5.70084; PMID 40104129 | **94 ASD/SCD** (+17 SAD) | **"young patients" — age NOT stated in abstract** | Japan (Univ. of the Ryukyus, Okinawa). **DISC-12** self-report prescreen; 3 factors: nonassertiveness, poor empathy, interpersonal hypersensitivity | ABSTRACT ONLY |

> **On Teruya 2025:** this is a *second* Japanese ASD/SCD clinical sample, distinct from Yoshinaga. It is plausibly adult (adult neuropsychiatry outpatients, self-report design, AQ/LSAS convergent validity), but **I did not confirm the age range** and it must not be reported as an adult cohort without a full-text check.

---

## 3. ADULT pragmatic language — what actually exists

Searching adult pragmatics returns a large literature that is **almost entirely acquired, not developmental**:

- **Traumatic brain injury / stroke / right-hemisphere damage** dominates the La Trobe Communication Questionnaire corpus (67 hits; Rietdijk, Togher, Douglas, Finch, Behn, Steel, Meulenbroek, Hoepner, Keegan, Wiseman-Hakes and others). Minga, Fullwood, Rose & Fannin (2024, AJSLP; PMID 39173072) is a call to action for an ICD code for **pragmatic language disorders after right hemisphere stroke** — evidence that the adult pragmatic-disorder construct is *institutionally unrecognised* even in acquired populations.
- **Psychosis / mood disorders:** Meister et al. 2026 (Schizophrenia (Heidelb); PMID 41690994) — systematic review and meta-analysis of **expressive pragmatic language in mood and psychotic disorders**, adults.
- **Autistic adults:** Gaever & Eggers 2026 (IJLCD; PMID 41457448), Friedman et al. 2025 (JSLHR, filled pauses; PMID 41118722), Miller et al. 2026 (Autism, mixed-neurotype dialogue; PMID 42547992), Landau et al. 2026 (Front Psychiatry, sex differences in pragmatic language; PMID 42100785), Eigsti, Larson & Naigles 2025 (Phil Trans R Soc B, pragmatic language and ToM in those with a *history* of autism; PMID 40808463).
- **Genetic syndromes:** Diez-Itza, Viejo & Fernández-Urquiza 2022 (detailed in §6.2).
- **Forensic / occupational:** Morken, Helland, Evanger & Vårvik 2023 (Front Psychol; PMC10426285) — oral language skills and mental health in **female prisoners**, concluding pragmatic skills are essential. Wiseman-Hakes et al. 2023 (AJSLP; PMID 36599105) — adults with TBI histories and criminal-justice involvement.
- **Higher education:** Qi & Zhao 2026 (Healthcare; PMID 42354648) — scoping review, *Hidden Communication Needs in Higher Education: Developmental Communication Disorders, Mental Health, and Academic Participation*. Directly relevant framing for the 18–25 band.
- **Developmental → adult follow-up (HISTORICAL PLI):** **Whitehouse, Watt, Line & Bishop (2009)**, Int J Lang Commun Disord 44(4):511–528; 10.1080/13682820802708098; PMID 19340628; PMC2835860. **N = 7 PLI (M age 22;3)**, 19 SLI (M 24;8), 11 high-functioning ASD (M 21;9), 12 typical (M 21;6). Interview-based psychosocial outcomes with participants and parents. **ABSTRACT ONLY.** Findings: the PLI group obtained *higher* education and worked in skilled professions relative to SLI, but **social relationship difficulties were most prominent in the PLI and ASD groups**. This is the **only longitudinal child-pragmatic-impairment → adult-outcome study found**, and n = 7. Companion paper: Whitehouse, Line, Watt & Bishop 2009, IJLCD 44(3); PMID 19343569.

**Assessment for the project:** for the 18–25 band there is **no developmental-SCD behavioural evidence base at all**. The nearest anchors are (a) Yoshinaga's n = 52 clinical cohort with no behavioural data, (b) Whitehouse's n = 7 PLI adults, (c) the adjacent autistic-adult pragmatics literature.

---

## 4. Intervention studies with participants aged 13+

### 4.1 Parsons et al. 2017 — the gap claim, VERIFIED IN FULL TEXT

Parsons, Cordier, Munro, Joosten & Speyer (2017), *A systematic review of pragmatic language interventions for children with autism spectrum disorder*, PLoS One 12(4):e0172242; 10.1371/journal.pone.0172242; PMID 28426832; PMC5398499. **Read: FULL TEXT.**

- **Verbatim from the Results section:** *"The 21 studies that met the eligibility criteria included 925 participants aged between 21 months and 14 years of age. Of the 21 included studies, 11 studies included preschool aged children (younger than 5 years), and 10 studies included primary/elementary school aged children (aged between 5 and 12 years inclusive). **None of the included studies targeted children aged 13–18 years.**"*
- **Verbatim from the Discussion:** *"This review did not find any evidence for any effective pragmatic language interventions for adolescents with ASD, highlighting a gap in the continuity of effective interventions for individuals with ASD as their social environment evolves and becomes more complex."*
- **Critically, the search was NOT age-limited below 18** — the stated limitation was *"participant age (0–18 years)."* The adolescent band was **in scope and returned nothing**. That makes this a genuine absence finding, not a search artefact.
- **Corroborating detail extracted from the included-study table:** the **maximum mean age across all included studies was 11.27 years**; study mean ages ranged 2.53–11.27. One eligibility-criterion string "aged 13–18 years" does appear in the extracted table text, but the authors' own synthesis explicitly states that no included study *targeted* 13–18, and the overall participant ceiling is 14 years.
- **Minor internal inconsistency in the source:** the abstract says "22 studies reporting on 20 pragmatic language interventions"; the Results section says "21 studies." Cite the Results figure (21 studies, 925 participants) for the age claim, since that is the sentence carrying it.

### 4.2 Has the gap been filled since 2017? PARTIALLY — by three studies, none SCD-specific

| Study | ID | N | Age | Population | Design | Conversation data | Read |
|---|---|---|---|---|---|---|---|
| **Yoo, Lee, Lee, Kim, Cho, Ju, Kim, Moon, Choi, Lee, Jang, Park, Seok & Joung (2025)** | Psychiatry Clin Neurosci 79(7):389–397; 10.1111/pcn.13824; PMID 40214154; PMC12232077 | not stated in retrieved abstract | **10–18** | **ASD or SCD** — the only post-2017 intervention found that **explicitly enrols SCD** | Multicentre, parallel, open-label, assessor-blinded **RCT pilot**; NDTx-01 mobile app game integrating social skills training | NO | ABSTRACT ONLY |
| **Ayvazo, Shmuel & Bin-Nun (2026)** | J Autism Dev Disord 56(1):13–25; 10.1007/s10803-024-06548-3; PMID 39269676; PMC12860758 | **3** | **16–18** | ADJACENT ASD | Single-case **withdrawal design**; self-monitoring + daily video-based model | **YES** — 10-min conversation sessions, coded | ABSTRACT ONLY |
| **Arturi, Scoppola, Riccioni, Siracusano, Iasevoli, Civetta, Spalletta, Fiori & Mazzone (2025)** | Brain Sci 15(9):970; 10.3390/brainsci15090970; PMID 41008330; PMC12468920 | **10** | **18–25** | ADJACENT ASD | Randomised **active vs sham tDCS** (left Broca's area) + concomitant CBT, 5 consecutive days per condition | NO (pragmatic battery) | ABSTRACT ONLY |

Also relevant, feasibility-grade:

- **Algahtani (2026)**, PLoS One 21(7):e0352505; PMID 42447173; PMC13367686 — **16 individuals with ASD aged 15–28** + 16 controls, Saudi Arabia (University of Jeddah). NLP-based communication-assistance tool combining sentiment analysis, intent identification and situational simplification with real-time feedback in **digital communication**. ADJACENT ASD. ABSTRACT ONLY.
- **Lee, Cho, Ju, Kim, Choi, Yoo & Joung (2025)**, JMIR Res Protoc 14:e66419; PMID 40925589 — protocol for the Yoo trial. Notable verbatim framing: *"most existing interventions primarily focus on early childhood, leaving adolescents relatively underserved."* Korea, 3 hospitals, ages 10–18, ASD or SCD.
- **Ayvazo 2026 is the closest existing analogue to the MVP's target behaviours.** Its dependent variable was a *sequence*: a turn-taking response (waiting quietly until the speaker finished) followed by an utterance that either made an on-topic statement/response **or** asked a contextually appropriate wh-question. That is topic management plus repair-adjacent behaviour, coded from real conversation, in 16–18-year-olds. n = 3.

**Verdict on the Parsons gap:** narrowed, not closed. Post-2017 there are **three** interventions reaching 13+; **one** of the three includes SCD participants at all; **none** is SCD-only; **none** targets the four MVP constructs directly.

---

## 5. Pragmatic assessment tools validated for 13+

### 5.1 Transition Pragmatics Interview (TPI) — the strongest match found

A five-paper development programme by Poll and colleagues (Miami University / Elmhurst University), built **specifically for transition-age adolescents**, grounded in the "synthesis model of pragmatics," criterion-referenced and Rasch-analysed.

| Paper | ID | N | Age | Contribution | Read |
|---|---|---|---|---|---|
| Poll & Petru (2023) | Clin Linguist Phon; 10.1080/02699206.2022.2148131; PMID 36426780 | — | — | Content validity via expert review + cognitive interviewing | LISTING ONLY |
| Poll, Mayes & Petru (2024) | Int J Speech Lang Pathol; 10.1080/17549507.2023.2287424; PMID 38343131; PMC11316841 | — | — | Content validity of a new item set | LISTING ONLY |
| **Poll, Boone & Petru (2024)** | J Speech Lang Hear Res 67(7):2353–2366; 10.1044/2024_JSLHR-23-00709; PMID 38896882; PMC11253795 | **37** | **14–22** | Primary psychometric evaluation. Rasch: **unidimensional**, supports a single summary score. Item difficulty varied by the social-communication element assessed (p < .001); an SDS developmental-level account was **not** supported (p = .55) | ABSTRACT ONLY |
| **Poll, Boone & Petru (2025)** | J Commun Disord 115:106513; 10.1016/j.jcomdis.2025.106513; PMID 40056748; PMC12104000 | **109** | **14–21** | Rasch **keyform** scoring template identifies each examinee's "transition zone" — the item set just beyond current ability — to select intervention goals | ABSTRACT ONLY |
| **Poll, Getachew, Boone & Petru (2026)** | Int J Lang Commun Disord 61(3):e70261; 10.1111/1460-6984.70261; PMID 42089582; PMC13148118 | **150** (59 with developmental disabilities) | **14–21** | Social communication measured across **four post-school contexts**; measures **highly correlated across contexts**. Post-secondary education experience associated with greater ability for all; independent-living experience only for those with disabilities | ABSTRACT ONLY |

⚠ The 37 / 109 / 150 samples may overlap (same research group, same instrument, overlapping years). **Do not sum.**

### 5.2 Poll, Maskalunas, Walls, Durbin, Hunken & Petru (2021) — the tool landscape review

Lang Speech Hear Serv Sch 52(3):917–936; 10.1044/2021_LSHSS-20-00141; PMID 34000203. **ABSTRACT ONLY.**
Systematic review applying **COSMIN** to **directly administered** social communication assessments for **14–21-year-olds** with developmental disabilities. **13 assessments identified.** The stated motivation is that evidence-based assessment selection is poorly adopted in this age band. **This is the correct citation for "what instruments exist for 13+."**

### 5.3 Instrument-by-instrument findings

| Tool | Status for 13+ | Evidence |
|---|---|---|
| **TPI** | ✅ **Purpose-built, 14–21/22** | Five papers above |
| **CCC-2** | ⚠ **Used at 13–14, but that is its ceiling region** | Ellis Weismer 2021 applied it at 13–14; Saul 2023 at 5–6; Sadati 2024 used CCC with 11–16. Wellnitz et al. 2021 (Autism Res; PMID 33410271) revised the CCC-2 factor structure. **No adult version (CC-A) found** — query `"Children's Communication Checklist" AND (adult OR "CC-A" OR adolescent)` returned 2 hits, neither relevant |
| **La Trobe Communication Questionnaire (LCQ)** | ✅ Adult — but **acquired-injury tradition, not developmental** | 67 hits, overwhelmingly TBI / stroke / brain tumour / epilepsy / MS / PPA. Recent adaptations: **Dutch** (Verhoeks et al. 2026, Brain Inj; 10.1080/02699052.2026.2647410; PMID 41906675) and **Greek** (Filippakopoulou et al. 2026; 10.1007/978-3-032-03398-7_2; PMID 41273544). Verhoeks et al. 2024 (Ann Phys Rehabil Med; PMID 39098162) is a COSMIN review of cognitive-communication instruments after brain injury |
| **Pragmatic Rating Scale (PRS)** | ⚠ Split | **PRS-School Age** psychometrics: Dillon, Holingue, Herman & Landa 2021 (JSLHR; PMID 34388006); applied by Maltman, Willer & Sterling 2023 (JSLHR; PMID 37844621). **Adult PRS** appears as an observational measure inside broad-autism-phenotype and first-degree-relative work (Landau et al. 2026; Xing et al. 2026 Brain Sci, PMID 41594827; Maltman et al. 2021 Front Psychiatry, PMID 34421690; Martin et al. 2023 Front Neurol longitudinal, PMID 37545730). No standalone adult validation paper surfaced |
| **Protocole MEC (Montreal Evaluation of Communication)** | ✅ Adult, acquired | Fonseca, Joanette, Côté, Ska et al. 2008, Span J Psychol; 10.1017/s1138741600004686; PMID 18988453 — Brazilian normative and reliability data. Adult RHD/TBI tradition |
| **SLDT / SLDT-Adolescent** | ❌ **NOT FOUND AFTER DEFINED SEARCH** (see §7) | Query returned 12 hits, **none** a validation study. Appears only as an outcome measure embedded in other work (e.g. D'Angelo et al. 2019, Schizophr Res, PMID 30077431 — social language deficits in children and adolescents with/at risk for psychosis; King et al. 2023, Children, FASD virtual assessment). Denman et al. 2017 (Front Psychol; PMID 28936189) reviewed language-assessment psychometrics **only for ages 4–12** |
| **PPIC (Profile of Pragmatic Impairment in Communication)** | ❌ **NOT FOUND AFTER DEFINED SEARCH** (see §7) | Exact-phrase query returned no matching record |
| **ABaCo (Assessment Battery for Communication)** | ⚠ Italian; children + adolescents | Gabbatore et al. 2025 Sci Rep; exact age range not confirmed |
| **Pragmatics Observational Measure-2 (POM-2)** | ⚠ Childhood | Cordier et al. 2019 Front Psychol; PMID 30873094 — IRT modelling of childhood pragmatics |
| **AQ-J** | ⚠ Screens adults but **does not separate SCD from ASD** | Yoshinaga 2023: ASD-vs-SCD AUC only **0.75** |
| **DISC-12** | ⚠ New, Japanese, self-report, age unconfirmed | Teruya et al. 2025 |

---

## 6. The four MVP pragmatic targets, by age band

Verdict key: **CHILD_ONLY** / **ADOLESCENT_EVIDENCE** (13–17) / **ADULT_EVIDENCE** (18–25) / **NONE**.
Two verdicts are given per target: one for **DIRECT SCD populations**, one for **any population** (including adjacent). This distinction is the crux of the section.

### 6.1 Listener knowledge / presupposition (audience design, common ground)

| Band | DIRECT SCD | Any population |
|---|---|---|
| 13–17 | **NONE** | **ADOLESCENT_EVIDENCE** |
| 18–25 | **NONE** | **NONE** (nothing squarely in band) |

- **Arvidsson, Pagmar & Uddén (2022)**, *When did you stop speaking to yourself? Age-related differences in adolescents' world knowledge-based audience design*, R Soc Open Sci 9(11):220305; 10.1098/rsos.220305; PMID 36465686; PMC9709564. **N = 58**: ages **11–12 (n = 29, M = 11.8)** and **15–16 (n = 29, M = 15.9)**. Swedish, Stockholm University. **GENERAL PRAGMATICS / typical development.** Online referential-production task with addressee world knowledge manipulated. A post-test survey confirmed both age groups held *similar assumptions* about addressee knowledge, but the younger group **did not consistently act on them during online production**. Audience design improved significantly with age, and **executive function (Wisconsin Card Sorting Task) did not explain the gain**. **ABSTRACT ONLY.** No conversation data (online production task).
  → The single most useful adolescent finding for this target: it establishes that **world-knowledge-based audience design is still maturing through adolescence in typical development, independent of EF**. That both justifies targeting it at 13–17 and warns that a typical-development baseline is age-sensitive *within* the band.
- **Karin, Geva, Bar-Yehuda, Estrugo & Bauminger-Zviely (2026)**, J Autism Dev Disord 56(4):1325–1338; 10.1007/s10803-024-06642-6; PMID 39570556; PMC12987844. **N = 148 children aged 6–16** (64 TD, 84 autistic), Israel. **ADJACENT ASD.** Tangram-card common-ground task in fixed dyads matched on IQ, age, sex and mother's education, plus joint-action motor tasks. Both groups grew more efficient over 6 turns; autistic participants less efficient. **The motor-coordination → common-ground link was strongest in children under 10** — i.e. the mechanism the paper identifies is *least* applicable at the top of its age range. **ABSTRACT ONLY.**
- **NOT FOUND:** any presupposition or common-ground study in a DIRECT SCD sample at any age.

### 6.2 Information quantity (Gricean maxim of quantity, informativeness)

| Band | DIRECT SCD | Any population |
|---|---|---|
| 13–17 | **NONE** | **NONE** |
| 18–25 | **NONE** | **ADULT_EVIDENCE** (adjacent only; n = 12; straddles 26+) |

- **Diez-Itza, Viejo & Fernández-Urquiza (2022)**, *Pragmatic Profiles of Adults with Fragile X Syndrome and Williams Syndrome*, Brain Sci 12(3):385; 10.3390/brainsci12030385; PMID 35326341; PMC8946534. **N = 12 Spanish-speaking ADULTS** (6 FXS, 6 WS), **all without an ASD diagnosis**. **ADJACENT (genetic syndromes).** **NATURAL CONVERSATION: YES — 71,859 words of extensive naturalistic conversation**, transcribed and coded with **CHILDES/TALKBANK** conventions and the **PREP-CORP pragmatic protocol**. The analysis is explicitly **violations of the Gricean maxims of conversation**, yielding indexes of cooperation and conversational response. FXS profile: more non-contingent language, **perseveration of topic and form**, impulsive conversational responses. WS profile: more **tangential utterances**, reformulations, overly literal interpretation. **ABSTRACT ONLY** (full abstract read; Methods/Results not read in full).
  → The **only adult study found that operationalises the Gricean maxims over natural conversation**, and therefore the closest methodological precedent for both the information-quantity target *and* the topic-management target. It is n = 12 in a genetic-syndrome population. Exact ages within adulthood are not given in the abstract, so it straddles 18–25 / 26+ and cannot be assigned cleanly to one bin.
- **NOT FOUND:** any over-/under-informativeness or quantity-maxim study in SCD, or in any 13–17 clinical sample, in the queries run.

### 6.3 Topic management (maintenance, shift, tangentiality)

| Band | DIRECT SCD | Any population |
|---|---|---|
| 13–17 | **NONE** | **ADOLESCENT_EVIDENCE** (n = 3 intervention; plus partial-band descriptive) |
| 18–25 | **NONE** | **ADULT_EVIDENCE** (adjacent only) |

- **Ábalos, Kissine, Vicente & Castroviejo (2026)**, Autism Res 19(4):e70204; 10.1002/aur.70204; PMID 41708108; PMC13087834. 43 autistic + 46 age-matched neurotypical **Spanish-speaking children, M = 8.55 (SD 1.91)** → **CHILD_ONLY.** Semi-spontaneous conversation task. The authors developed a theoretically grounded protocol for systematically coding topic shifts, validated against a rating task with neurotypical adults. Finding: comparable numbers of topic-*supporting* responses, but autistic participants produced significantly **more** topic shifts, and those shifts sat at the "less natural" end of the empirically supported rating scale. **ABSTRACT ONLY.** *Methodologically the best topic-shift coding scheme found — but normed on 8-year-olds.*
- **Ayvazo et al. (2026)** (§4.2) — **ages 16–18, n = 3**, on-topic statement/response as a coded dependent variable in 10-minute conversations. **ADOLESCENT_EVIDENCE, ADJACENT ASD.**
- **Diez-Itza et al. (2022)** — adult topic perseveration (FXS) and tangential utterances (WS). **ADULT_EVIDENCE, ADJACENT.**
- **Hoffman (2026)**, *Now, what were we talking about? Effects of topic reminders on discourse coherence in young and older adults*, Neuropsychol Dev Cogn B; 10.1080/13825585.2026.2679769; PMID 42198832. Typical young and older adults. **GENERAL PRAGMATICS.** LISTING ONLY.
- Historical note carried inside Parsons 2017's own literature review: *"poor conversational topic management, the contribution of irrelevant information to conversations"* is cited there as a known ASD adolescent difficulty (citing Paul, Orlovski, Marcinko & Volkmar 2009, JADD 39(1):115–125, conversational behaviours in youth with high-functioning ASD/Asperger syndrome). Parsons also cites **Ciccia & Turkstra 2002** (*Cohesion, communication burden, and response adequacy in adolescent conversations*, Adv Speech Lang Pathol 4(1):1–8) as the reference point for typical adolescent conversational development — a 2002 paper is still the anchor.

### 6.4 Repair / clarification

| Band | DIRECT SCD | Any population |
|---|---|---|
| 13–17 | **NONE** | **ADOLESCENT_EVIDENCE** (adjacent DHH) |
| 18–25 | **NONE** | **NONE** (nearest is older-adult hearing work) |

- **Sadati & Mohamadi (2024)**, *Communication breakdown repair skills: Comparison between deaf and hard-of-hearing, and normal-hearing adolescents*, Cochlear Implants Int 25(2):99–108; 10.1080/14670100.2024.2379122; PMID 39028756. **N = 32** (16 DHH, 16 normal-hearing), **ages 11–16**, Iran (Iran University of Medical Sciences, Tehran). **ADJACENT (hearing).** **NATURAL CONVERSATION: YES — a 10-minute conversation with an unfamiliar adult**; coded number and type of **clarification requests and responses to those requests**; CCC completed by parents. **ABSTRACT ONLY.** Findings: DHH adolescents used significantly more **nonverbal** clarification requests and more verbal and nonverbal **responses** to clarification requests; the unfamiliar adult made more clarification requests to them; the CCC pragmatic composite correlated with the number of breakdowns and the number of adult clarification requests.
  → **The best methodological template found for the repair target in this age band**: real conversation, unfamiliar partner, both directions of repair coded, a 10-minute sample, cross-referenced to a pragmatic checklist. Wrong population, right method.
- **Ellis, Rönnberg & Plejert (2024)**, Int J Lang Commun Disord; 10.1111/1460-6984.12940; PMID 37589337 — combined effects of **age and hearing impairment** on utterances and **requests for clarification** in spontaneous conversation *and* a referential communication task. Adults, skewing older. LISTING ONLY.
- **NOT FOUND:** any conversational-repair study in a DIRECT SCD sample at any age, or in any 18–25 clinical developmental sample.

### 6.5 Summary verdict table

| MVP target | 13–17 (SCD) | 13–17 (any population) | 18–25 (SCD) | 18–25 (any population) |
|---|---|---|---|---|
| Listener knowledge / presupposition | **NONE** | **ADOLESCENT_EVIDENCE** (Arvidsson 2022, typical, n = 29 at 15–16) | **NONE** | **NONE** |
| Information quantity | **NONE** | **NONE** | **NONE** | **ADULT_EVIDENCE** (Diez-Itza 2022, n = 12, FXS/WS) |
| Topic management | **NONE** | **ADOLESCENT_EVIDENCE** (Ayvazo 2026, ASD, n = 3) | **NONE** | **ADULT_EVIDENCE** (Diez-Itza 2022) |
| Repair / clarification | **NONE** | **ADOLESCENT_EVIDENCE** (Sadati 2024, DHH, n = 32 at 11–16) | **NONE** | **NONE** |

**All four MVP targets are CHILD_ONLY or NONE within DIRECT SCD populations.** Every adolescent or adult data point above comes from an adjacent population. This is the single most important finding in this document and should govern how the PoC frames its evidence claims.

---

## 7. NOT FOUND AFTER DEFINED SEARCH

Per instruction, no claim of worldwide non-existence is made. The following were searched on **2026-09-12** and produced no qualifying record.

Endpoints used throughout:
- Europe PMC REST — `https://www.ebi.ac.uk/europepmc/webservices/rest/search?query=<Q>&resultType=lite&format=json&pageSize=<N>`
- NCBI efetch — `https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&id=<IDS>&rettype=abstract&retmode=text`
- Europe PMC full text — `https://www.ebi.ac.uk/europepmc/webservices/rest/PMC#######/fullTextXML`

1. **PPIC (Profile of Pragmatic Impairment in Communication)** — **NOT FOUND AFTER DEFINED SEARCH.**
   Query: `"Profile of Pragmatic Impairment in Communication" OR "Pragmatic Rating Scale" OR "Protocole MEC" OR "Montreal Evaluation of Communication"` (122 hits; PPIC contributed none).
2. **SLDT-Adolescent validation study** — **NOT FOUND AFTER DEFINED SEARCH.**
   Query: `"Social Language Development Test" OR "SLDT-Adolescent" OR "Social Language Development Test Adolescent"` (12 hits, none a psychometric validation).
3. **CCC adult version (CC-A)** — **NOT FOUND AFTER DEFINED SEARCH.**
   Query: `"Children's Communication Checklist" AND (adult OR adults OR "CC-A" OR adolescent)` (2 hits, neither relevant).
4. **Any conversational-repair or clarification-request study in a DIRECT SCD sample, any age** — **NOT FOUND AFTER DEFINED SEARCH.**
   Query: `("conversational repair" OR "clarification request" OR "topic management" OR "topic maintenance") AND (adolescent OR adolescents OR adult OR adults)` (455 hits, top 30 screened by relevance; no DIRECT SCD sample).
5. **Any informativeness / quantity-maxim study in a DIRECT SCD sample, any age** — **NOT FOUND AFTER DEFINED SEARCH.**
   Query: `("referential communication" OR "common ground" OR presupposition OR "informativeness" OR "audience design") AND (adolescent OR adolescents OR "young adult")` (4,028 hits — query too broad; top 30 screened by relevance; no DIRECT SCD sample surfaced).
6. **A second adult SCD cohort with a confirmed adult age range, outside Japan** — **NOT FOUND AFTER DEFINED SEARCH.**
   Queries: `("social communication disorder" OR "social (pragmatic) communication disorder") AND (adult OR adults OR "adult psychiatry" OR "adult clinic")` (409 hits); `TITLE:"social communication disorder" AND (adolescen* OR adult* OR "young adult")` (17 hits).
7. **An SCD-specific intervention trial (SCD-only enrolment) with participants 13+** — **NOT FOUND AFTER DEFINED SEARCH.** Yoo 2025 enrols "ASD **or** SCD" and does not report an SCD-only subgroup in its abstract; Adams 2020 (SCIP) is SPCD-specific but stops at age 11.
   Queries: `"pragmatic language" AND (intervention OR training OR therapy) AND (adolescent OR adolescents OR teenager)` (715 hits); `AUTH:"Parsons L" AND (pragmatic OR "social communication" OR autism)` (24 hits).
8. **A Korean SCD cohort study** (as distinct from the Korean ASD-or-SCD intervention trials) — **NOT FOUND AFTER DEFINED SEARCH.**
   Query: `("social communication disorder" OR "pragmatic language") AND (Korea OR Korean OR Japan OR Japanese OR China OR Chinese)` (435 hits).

### Full query log (Europe PMC unless noted)

| # | Query | Hits |
|---|---|---|
| q1 | `TITLE:"social communication disorder" AND (adolescen* OR adult* OR "young adult")` | 17 |
| q2 | `ABSTRACT:"pragmatic language" AND (adult OR adults OR "young adult")` | 234 |
| q3 | `"La Trobe Communication Questionnaire"` | 67 |
| q4 | `"social (pragmatic) communication disorder" OR "social pragmatic communication disorder" OR SPCD` | 585 |
| q5 | `AUTH:"Ellis Weismer" AND (pragmatic OR "social communication")` | 41 |
| q6 | `"Social Language Development Test" OR "SLDT-Adolescent" OR "Social Language Development Test Adolescent"` | 12 |
| q7 | `AUTH:"Mandy W" AND ("social communication" OR pragmatic OR SPCD)` | 81 |
| q8 | `AUTH:"Azizpour" AND ("social communication" OR pragmatic)` | 2 |
| q9 | `AUTH:"Parsons L" AND (pragmatic OR "social communication" OR autism)` | 24 |
| q10 | `"pragmatic language" AND (intervention OR training OR therapy) AND (adolescent OR adolescents OR teenager)` | 715 |
| q11 | `"Profile of Pragmatic Impairment in Communication" OR "Pragmatic Rating Scale" OR "Protocole MEC" OR "Montreal Evaluation of Communication"` | 122 |
| q12 | `"pragmatic language impairment" AND (adolescent OR adolescents OR "young adult" OR adulthood OR outcome)` | 160 |
| q13 | `("conversational repair" OR "clarification request" OR "topic management" OR "topic maintenance") AND (adolescent OR adolescents OR adult OR adults)` | 455 |
| q14 | `("referential communication" OR "common ground" OR presupposition OR "informativeness" OR "audience design") AND (adolescent OR adolescents OR "young adult")` | 4028 |
| q15 | `"Children's Communication Checklist" AND (adult OR adults OR "CC-A" OR adolescent)` | 2 |
| q16 | `"social communication" AND (university OR college OR employment OR workplace) AND ("young adult" OR "young adults") AND (pragmatic OR conversation)` | 1291 |
| q17 | `AUTH:"Whitehouse AJ" AND ("pragmatic language impairment" OR "specific language impairment")` | 23 |
| q18 | `"Transition Pragmatics Interview" OR (AUTH:"Poll GH" AND (pragmatic OR "social communication"))` | 8 |
| q19 | `"developmental language disorder" AND pragmatic AND (adolescent OR adolescents OR "young adult")` | 235 |
| q20 | `("social communication disorder" OR "pragmatic language") AND (Korea OR Korean OR Japan OR Japanese OR China OR Chinese)` | 435 |
| q21 | `("social communication disorder" OR "social (pragmatic) communication disorder") AND (adult OR adults OR "adult psychiatry" OR "adult clinic")` | 409 |

Full texts retrieved: **PMC5398499** (Parsons 2017), **PMC10644653** (Yoshinaga 2023).

---

## 8. Reading-depth ledger

**FULL TEXT read (Methods/Results inspected):**
- Parsons et al. 2017 (PMC5398499) — participant-age synthesis, included-study table, discussion
- Yoshinaga et al. 2023 (PMC10644653) — participant table, diagnostic procedure, limitations

**ABSTRACT ONLY — every other study cited in this document.** Specifically including: Ellis Weismer 2021, Mandy 2017, Azizpour 2026a/b, Güler 2026, Saul 2023, Jain 2025, Adams 2020, Gabbatore 2025, Flax 2019, Teruya 2025, Tsai 2020/2022, Yoo 2025, Lee 2025, Ayvazo 2026, Arturi 2025, Algahtani 2026, Poll/TPI 2024 (JSLHR), Poll 2025 (JCD), Poll 2026 (IJLCD), Poll 2021 (COSMIN review), Whitehouse 2009, Arvidsson 2022, Karin 2026, Ábalos 2026, Sadati 2024, Diez-Itza 2022, Richardson 2026.

Papers marked **LISTING ONLY** were seen as a search-result row (title, authors, year, journal, DOI/PMID) and **not read even at abstract level**: Poll & Petru 2023, Poll/Mayes/Petru 2024, Hoffman 2026, Ellis/Rönnberg/Plejert 2024, Almehmadi 2020, and the supporting citations named in §3 and §5.3.

---

## 9. Cautions for downstream use

1. **Do not sum participants.** Known or suspected overlaps: Azizpour 2026a ≈ 2026b (same n = 120 sample); the three TPI samples (37 / 109 / 150); Yoo 2025 and Lee 2025 (same trial — RCT report and protocol).
2. **Do not treat ASD studies as SCD evidence.** Ayvazo, Arturi, Algahtani, Karin, Ábalos, Richardson and Almehmadi are all ASD. Mandy 2017 found SPCD *not qualitatively distinct* from ASD — that is an argument about diagnostic boundaries, not a licence to substitute populations in an evidence table.
3. **Four reporting gaps block firm claims**, each resolvable with one full-text read: (a) the age distribution of Mandy 2017's 88 SPCD cases; (b) the age range of Teruya 2025's 94 ASD/SCD patients; (c) the SPCD case count in Güler 2026; (d) the n in Yoo 2025.
4. **The instruments carry the age mismatch, not just the samples.** The strongest 13–17 prevalence estimate (Ellis Weismer 2021) rests on the CCC-2, a child checklist applied at 13–14. The only purpose-built adolescent instrument (TPI) has no SCD-diagnosed validation sample.
5. **Natural conversation data is scarce at every age and absent in SCD.** Across the whole corpus, the studies that collected and coded real conversation are: Sadati 2024 (DHH, 11–16), Ayvazo 2026 (ASD, 16–18), Diez-Itza 2022 (FXS/WS adults), Ábalos 2026 (ASD, M = 8.55), Richardson 2026 (ASD, 9–16), and Karin 2026 (task-based, 6–16). **None is a DIRECT SCD sample.**
