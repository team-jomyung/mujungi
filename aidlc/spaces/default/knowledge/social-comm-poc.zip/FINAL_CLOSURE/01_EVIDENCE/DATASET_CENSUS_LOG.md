# DATASET CENSUS · 검색 기록

2026-09-14

`DATASET_CENSUS_KO.csv` (27 행) 와 `DATASET_CENSUS_GLOBAL.csv` (20 행) 를 만들면서 실제로 어디를 뒤졌는지 적는다.
**못 찾은 것은 "없다" 가 아니라 `NOT FOUND AFTER DEFINED SEARCH` 이고, 검색 조건을 함께 적는다.**

두 CSV 의 관계는 이렇다. `DATASET_CENSUS_NOTE.md` §1 의 확정 표는 **재조사하지 않고 그대로 옮겼고**, 옮기면서 1차 출처 URL 만 다시 짚었다.
§2 의 미확인 항목이 이번에 실제로 조사한 대상이다. CSV 의 `notes` 에서 `NOTE 1 확정분` 과 `NOTE 2 조사 항목` 으로 구분된다.

---

## 1 · 이번에 확인한 것 · 1차 출처

전부 **저장소 LICENSE 파일 · 배포처 약관 페이지 · 카탈로그 레코드** 같은 1차 출처다. 블로그나 2차 소개글은 근거로 쓰지 않았다.
데이터 파일 자체는 내려받지 않았다. GitHub API 의 저장소 메타데이터, 저장소 파일 목록, LICENSE 와 README 원문, 약관 페이지까지만 봤다.

| 대상 | 어디 | 무엇을 확인했나 | 결과 |
|---|---|---|---|
| ProSem | `api.github.com/repos/warnikchow/prosem` + `raw.githubusercontent.com/.../LICENSE` + 저장소 파일 목록 | 라이선스 · 저장소 구성 | **찾음** · CC-BY-SA-4.0 전문 20,139 bytes. 저장소에 데이터 없음 (LICENSE + README 둘뿐) |
| ProSem 본문 위치 | Google Drive · Dropbox 링크 HEAD 요청 (다운로드 안 함) | 링크 생존 여부 | **찾음** · 307 · 302 로 둘 다 살아 있음 |
| ProSem 논문 | Semantic Scholar `graph/v1/paper/search` | 제목 대조 | **찾음** (CorpusId 202635782) · 초록은 제공 안 됨 |
| ParaKQC | `api.github.com/repos/warnikchow/paraKQC` + LICENSE 원문 + `contents/data` | 라이선스 · 데이터 소재 | **찾음** · CC-BY-SA-4.0, `data/paraKQC_v1.txt` 가 저장소 안에 있음 |
| ParaKQC 도메인 | `aclanthology.org/2020.lrec-1.842/` + 같은 논문 PDF 본문 | 주제 · 맥락 유무 | **찾음** · 주제 넷 = 이메일 · 일정 잡기 · 스마트홈 · 날씨 |
| K-MIND | `api.github.com/repos/AIRC-KETI/K-MIND` + `contents/` + README 원문 | 저장소 실물 상태 | **찾음** · 여전히 빈 껍데기 (아래 §4) |
| KMI | `raw.githubusercontent.com/hjkim811/KMI/main/LICENSE` + 저장소 파일 목록 | 라이선스 원문 | **찾음** · CC BY 4.0 · 342 bytes |
| 3i4K | `raw.githubusercontent.com/warnikchow/3i4k/master/LICENSE` | 라이선스 원문 | **찾음** · CC BY-SA 4.0 전문 |
| KoCoSa | `api.github.com/repos/Yu-billie/KoCoSa_sarcasm_detection` + `contents/` + HF datasets API | LICENSE 파일 유무 | **찾음** · 루트에 LICENSE 없음 · API `license=null` · HF 미러도 태그 없음 |
| AnnoMI | `api.github.com/repos/uccollab/AnnoMI` + `contents/` | LICENSE 파일 유무 | **찾음** · 루트에 LICENSE 없음 · `license=null` |
| AI Hub 이용정책 | `www.aihub.or.kr/intrcn/guid/usagepolicy.do` | 국외 이용 · 영리 · 재배포 | **찾음** (아래 §5) |
| AI Hub 543 · 71305 | `www.aihub.or.kr/aihubdata/data/view.do?dataSetSn=...` | 개별 라이선스 필드 · 신청 제한 | **찾음** · 라이선스 필드 없음 · "내국인만 데이터 신청이 가능합니다" |
| 국립국어원 | `kli.korean.go.kr/corpus/boards/termsInfo.do` | 이용약관 제12조 | **찾음** · ② ⑤ ⑥ 원문 확보 |
| TalkBank | `talkbank.org/0share/rules.html` | Ground Rules 원문 | **찾음** · CC BY-NC-SA 3.0 · LLM 조항 원문 확보 |
| TalkBank 경로 | `talkbank.org/share/rules.html` | 경로 대조 | **404** · 실제 경로는 `/0share/rules.html` 이다 (2026-09-14 재확인) |
| ASDBank | `talkbank.org/asd/` + `talkbank.org/asd/access/` | 배지 버전 · 코퍼스 수 | **찾음** · 홈 배지 4.0 / Ground Rules 본문 3.0 (아래 §4) |
| CABank 한국어 | `talkbank.org/ca/access/` | 한국어 코퍼스 유무 | **0 건** · 한국어 코퍼스 없음 |
| CHILDES 한국어 | `talkbank.org/childes/access/EastAsian/` | 한국어 코퍼스 목록 | **찾음** · Jiwon · Ko · Ryu 셋 |
| SANACS | `catalogue.elra.info/en-us/repository/browse/ELRA-S0491/` | 라이선스 · 가격 | **찾음** · Non Commercial Use - ELRA END USER · 0.00 EUR |
| SBCSAE | `www.linguistics.ucsb.edu/research/santa-barbara-corpus-spoken-american-english` | 라이선스 · 규모 | **찾음** · CC BY-ND 3.0 US · 60 녹음 · 약 249,000 단어 |
| Playlogue | `huggingface.co/datasets/playlogue/playlogue-v1` | 라이선스 · 주석 체계 · 대상 | **찾음** · cc-by-nc-sa-3.0 · DPICS · 일반 발달 아동 |
| ItaASD | `hdl.handle.net/20.500.11752/OPEN-990` → `dspace-clarin-it.ilc.cnr.it` | 라이선스 · 구성 · 접근 | **찾음** (아래 §4 · 이전 조사에서 못 열던 것) |
| LDC2022S14 | `catalog.ldc.upenn.edu/LDC2022S14` | 라이선스 · 배포 내용 · 가격 | **찾음** · LDC User Agreement for Non-Members · 전사 미배포 · "Login for the applicable fee" |
| CANDOR | `betterup-data-requests.herokuapp.com` | 등록 전 약관 노출 여부 | **미노출** · "(c) 2022 BetterUp. All rights reserved" 만 있음 |
| AMI | `groups.inf.ed.ac.uk/ami/corpus/` | 라이선스 | **찾음** · CC BY 4.0 (신호 · 전사 · 일부 주석) |
| SwDA | `api.github.com/repos/cgpotts/swda` | 저장소 라이선스 | **찾음** · GPL-2.0 (저장소 한정) |
| pragmaticsAggression | `huggingface.co/api/datasets` 검색 | 라이선스 태그 | **찾음** · cc-by-nc-4.0 |
| CHAT 미러 | `api.github.com/repos/jamsawamsa/Autism_SLI_textAnalyzer_NLP_ML` | 라이선스 | **찾음** · `license=null` · 무단 재배포본 |
| 간접 화행 평가셋 | `arxiv.org/abs/2502.10995` | 논문 동일성 | **찾음** · "Evaluating Large language models on Understanding Korean indirect Speech acts" |
| KMI 논문 | `arxiv.org/abs/2502.05651` | 논문 동일성 | **찾음** |

---

## 2 · NOT FOUND AFTER DEFINED SEARCH

찾지 못한 것이다. **없다는 뜻이 아니라 아래 조건으로 찾았을 때 안 나왔다는 뜻이다.**

| 무엇 | 정의된 검색 (2026-09-14) | 뒤지지 못한 곳 |
|---|---|---|
| **ToM-Diary 의 배포처와 라이선스** | GitHub repo search `q=ToM-Diary` · `q=diary+theory+of+mind+korean` · `q=perspective+taking+korean+dataset` · `q=tomdiary` (각 상위 5~6 건) · HuggingFace datasets API `search=ToM-Diary` · `search=tom diary` · arXiv API `all:"ToM-Diary"` · `abs:"diary" AND abs:"theory of mind" AND abs:"Korean"` | Zenodo · OSF · KCI · RISS |
| **KOPLAC 의 공개 데이터** | GitHub repo search `q=KOPLAC` · `q=koplac` (상위 5 건 · 전부 동명 계정이고 화용 자료 0 건) · HuggingFace datasets API `search=KOPLAC` 0 건 · `search=korean children pragmatic` 0 건 | Zenodo (403) · OSF (무응답) · 파라다이스복지재단 판매 페이지 내부 |
| **CPLC 의 공개 데이터** | GitHub repo search `q=CPLC+pragmatic` 0 건 | 같음 · 언어치료연구 원문 |
| **한국어 화용 평가셋 · 간접 화행 평가셋의 저장소 주소** | 프로젝트 기록 전수 grep (`github.com` · `huggingface.co` URL 3 개뿐) · arXiv API `abs:"indirect speech act" AND abs:"Korean"` 0 건 | 저자 문의 (미진행) |
| **K-MIND 의 라이선스와 공개 일정** | 저장소에 LICENSE 파일 없음 · README 46 bytes 전체 확인 · GitHub repo search `q=KMIND` · `q=K-MIND in:name` · `q=kmind+dataset` · `q=mind in:name korean dialogue` · arXiv API `all:"K-MIND"` 0 건 | 교신저자 문의 (미진행) · IITP 과제 산출물 공개 의무 확인 |
| **INCA-A 밖의 임상군 화용 주석** | ASDBank 색인 전수 · CHILDES Clinical-Eng 벌크 `%spa` 실측 28 코드 (2026-09-11) · Playlogue 데이터 카드 (DPICS 확인, 그러나 전부 일반 발달 아동) | LDC · ELRA · CLARIN 재검색 (2026-09-11 조사가 각각 0 건 · SANACS 1 건 · SANACS + ItaASD 2 건으로 끝냈고 이번에 다시 돌리지 않았다) |
| **ProSem 외부 링크 본문에 저장소 LICENSE 가 적용되는지** | 저장소 README 전문 · LICENSE 전문 · 저장소 파일 목록 — 어디에도 적용 범위 문구가 없다 | 저자 문의 (미진행) |
| **CANDOR 의 라이선스 전문** | 요청 포털 등록 전 화면 (약관 미노출) | 등록 후 단계 (미진행) |
| **ICSI 의 라이선스** | 이번 조사에서 배포처 약관을 열지 않았다 | ICSI 배포처 |

---

## 2-1 · 약관 페이지를 열지 못한 여섯 (`NOT CHECKED`)

CSV 에서 `license` 가 `NOT CHECKED` 인 여섯 행이다. **표기가 없다는 뜻이 아니라 이번 조사가 배포처 약관을 못 열었다는 뜻이다.**
`NOT STATED`(열었는데 표기가 없음)와 섞으면 안 된다. 못 연 사정을 각각 적는다.

| 항목 | 왜 못 열었나 | 다음에 열려면 |
|---|---|---|
| **서울대 · 가천대 ASD 아동 음성 코퍼스** | **약관 페이지가 존재하지 않는다.** 2026-09-11 조사가 배포처 자체가 없다고 판정했고(논문 전문에 public · release · available · request 문장 0 건) 이번에 그 판정을 뒤집을 새 경로를 찾지 않았다 | 교신저자 문의 |
| **ETRI KEMDy20** | 2026-09-11 기록에 **공식 배포처가 해외 IP 연결을 거부한다**고 적혀 있다. 이번 조사는 배포처 URL 자체를 다시 특정하지 못했다 — WebSearch 예산이 소진돼 주소를 찾을 검색 경로가 없었다 | 국내 망에서 ETRI 배포처 직접 접속 |
| **SAE4K** | 배포처를 특정하지 않았다. 2026-09-09 판정이 **라벨 구조만으로** 탈락시킨 것이라(진술 클래스 없음 · 산출물이 구조화 질의 쌍) 라이선스가 판정을 바꾸지 않아 우선순위에서 밀렸다 | 논문의 데이터 가용성 절 |
| **협력적 대화 요약 말뭉치 2025** | 배포처 주소가 프로젝트 기록 어디에도 없고(전수 grep 결과 프로젝트가 보유한 URL 은 3 개뿐) WebSearch 를 못 써서 특정하지 못했다 | 배포처 특정이 먼저 |
| **공공데이터포털 언어치료 데이터** | **발화 0 건으로 이미 탈락한 항목**이라 약관을 열지 않았다. 내용이 발달재활 제공기관 행정 목록이어서 라이선스가 판정을 바꾸지 않는다 | 공공데이터포털 각 목록의 이용허락범위 필드 |
| **ICSI Meeting Corpus** | 2026-09-11 기록이 **AMI 와 ICSI 를 CC BY 4.0 으로 묶어** 적었는데, 이번에 원문으로 확인한 것은 AMI 뿐이다(`groups.inf.ed.ac.uk/ami/corpus/`). ICSI 배포처 약관은 열지 않았다. 묶어 적은 기록을 그대로 옮기면 확인하지 않은 것을 확인한 것처럼 만들기 때문에 나눴다 | ICSI 배포처 약관 |

여섯 다 **CSV 에서는 막는 쪽으로 닫아 두었다** — `redistribution=RESERVED`, `commercial_use=NO`, `model_training=NO`.
모르는 것을 열어 두면 읽는 쪽이 "아직 모름 = 아마 괜찮음" 으로 읽는다. 그리고 여섯 중 다섯은 **이미 무관 · 탈락 판정이 나 있어 라이선스가 결론을 바꾸지 않는다.**
결론을 바꿀 수 있는 것은 ETRI KEMDy20 하나뿐이다(준언어 축에 값이 있는 유일한 한국어 후보).

---

## 3 · 이번에 뒤지지 못한 곳 · 모든 부재 진술에 붙는 한계

| 어디 | 상태 | 영향 |
|---|---|---|
| **WebSearch** | 세션 예산 200/200 소진 — 한 번도 못 씀 | 검색 엔진 기반 탐색이 아예 빠졌다. 아래는 전부 API 직접 호출과 알려진 URL 로만 한 것이다 |
| **Zenodo API** | HTTP 403 (`Access to this resource has been restricted due to unusual traffic`) | KOPLAC · CPLC · ToM-Diary 의 부재 진술에서 Zenodo 를 **뺀다** |
| **OSF API** | 무응답 (연결 실패) | 같음 |
| **KCI · RISS · DBpia** | 조회하지 않음 | 국내 학술 경로에 있는 데이터 공개 사례가 빠져 있을 수 있다 |
| **ASSTA (ICPhS 2019 논문 호스트)** | DNS 실패 (`getaddrinfo ENOTFOUND www.assta.org`) | ProSem 논문 본문을 못 봤다. 판정은 저장소 README + 논문 제목 + Semantic Scholar 레코드로 했다 |
| **repository.clarin.it** | 모든 경로가 JS 리다이렉트 껍데기 (DSpace REST · OAI-PMH 포함) | ItaASD 는 handle 리졸버로 우회했다. 다른 CLARIN-IT 자원은 같은 우회가 필요하다 |
| **AI Hub 실제 신청** | 미진행 (내국인 한정 · 승인 필요) | 543 · 544 · 71305 · 267 의 실물은 여전히 미확인 |
| **ELRA 주문 · TalkBank 계정 생성** | 미진행 | SANACS · ASDBank 실물 미확인 |

---

## 4 · 이전 기록과 달라진 것 · 어긋난 것

### 4-1 · ItaASD — 이번에 처음 열렸다

2026-09-11 조사에서 저장소 호스트가 `ECONNREFUSED` 였다. 2026-09-14 에는 `repository.clarin.it` 이 HTTP 200 을 주지만 본문이 JS 리다이렉트 껍데기다.
**handle 리졸버(`hdl.handle.net/20.500.11752/OPEN-990`)가 `dspace-clarin-it.ilc.cnr.it` 로 넘겨 주어 기록을 읽었다.**

읽고 나니 이 자료는 두 가지로 우리와 무관하다.

- **원자료가 비공개다.** 녹음 · 전사 · 임상정보는 이탈리아 개인정보 규정으로 공개되지 않고, 익명화된 음향 · 리듬 · 어휘 · 통사 측정값만 요청 시 제공된다.
- **과제가 독백이다.** 그림 설명 · 이야기 산출 · 이야기 재산출이라 상대 턴이 없다. DengSiok 과 같은 이유로 말순서 · 응답 지연 · 수리 분석이 원천적으로 불가능하다.

라이선스 표기는 없다. 권리 유보로 둔다.

### 4-2 · ASDBank 코퍼스 수가 세는 법에 따라 갈린다

색인 페이지(`talkbank.org/asd/access/`)를 언어별로 읽으면 **13** 이고, 2026-09-11 조사가 개별 문서를 열어 센 값은 **15** 다.
차이의 원인은 색인이 언어로 묶여 있고 **Nadig 가 English 와 French 양쪽에 나온다**는 것이다. CSV 에 둘 다 적었다.

### 4-3 · ASDBank 라이선스 표기 어긋남은 그대로다

ASDBank 홈 배지는 **CC BY-NC-SA 4.0**, TalkBank Ground Rules 본문은 **3.0** 이다. 2026-09-11 기록과 같고 보수적으로 3.0 으로 본다.

### 4-4 · K-MIND 는 6 개월째 그대로다

2026-09-14 GitHub API 재확인.

```
repo      AIRC-KETI/K-MIND
license   null
size      0
contents  README.md (46 bytes) 하나
README    "# Korean Multimodal INteraction Data (K-MIND)"  ← 전문이 이 한 줄
pushed    2026-03-06T06:20:08Z   (생성 2026-03-06T06:19:26Z · 이후 무변동)
stars     0
```

**생성 다음 42 초 뒤 push 하고 그대로 멈춰 있다.** 공개 준비 중인지 중단인지는 여전히 알 수 없다.
규모(292 명 · 115 시간 30 분)와 구성(발화 의도 21 종 · 백채널 6 종 · 준언어 층)은 전부 논문 기술이고 실물이 아니다.
그래서 CSV 의 `relevance_to_scd` 를 유관도 무관도 아닌 **UNDETERMINED** 로 뒀다. 받아 보지 못한 것을 유관하다고 적지 않는다.

### 4-5 · KMI 의 라이선스는 CC BY 4.0 이 맞는데 자동 감지가 못 잡는다

LICENSE 원문은 `Creative Commons Attribution 4.0 International (CC BY 4.0) / Copyright (c) Hyunjong Kim` 이다.
그런데 342 bytes 짜리 안내문이고 법적 전문이 아니라서 **GitHub API 는 `NOASSERTION` · `Other` 로 잡는다.**
라이선스 스캐너를 쓰는 조직에 제출할 때 걸릴 수 있다는 2026-09-10 기록이 이번에도 그대로 재현됐다.

---

## 5 · AI Hub · 라이선스와 해외 이용 제한

NOTE §2 가 "씨앗 후보가 늘 수 있다" 고 적은 항목이다. 결론은 **늘 수는 있는데 조건이 셋 붙는다** 이다.

개별 데이터셋 페이지(543 · 71305)에는 **라이선스 필드가 아예 없다.** 있는 것은 `※ 내국인만 데이터 신청이 가능합니다` 한 줄뿐이다.
조건은 포털 이용정책에 있고, 원문은 이렇다.

> 국외에 소재하는 법인, 단체 또는 개인이 AI데이터 등을 이용하기 위해서는 수행기관 등 및 한국지능정보사회진흥원과 별도로 합의가 필요합니다.

> 본 AI데이터 등의 국외 반출을 위해서는 수행기관 등 및 한국지능정보사회진흥원과 별도로 합의가 필요합니다.

> 지능형 제품・서비스, 챗봇 등 다양한 분야에서 영리적・비영리적 연구・개발 목적으로 활용할 수 있습니다.
> (다만) 판매 등 상업적 이용을 희망하는 경우 수행기관과 별도 협의가 필요합니다.

> 제공 받은 AI데이터 등을 수행기관 등과 한국지능정보사회진흥원의 승인을 받지 않은 다른 법인, 단체 또는 개인에게 열람하게 하거나 제공, 양도, 대여, 판매하여서는 안됩니다.

세 줄로 줄이면 이렇다. **재배포 금지 · 판매는 별도 협의 · 국외 이용과 국외 반출은 별도 합의.**
연구 개발 목적의 영리 이용까지는 열려 있다는 점에서 국립국어원보다 덜 막혀 있으나, 라이선스 이름이 없으므로 CSV 의 `license` 는 `NOT STATED` 로 적고 괄호에 포털 이용정책이 적용된다고 붙였다.

**주의.** 위 문구는 AI 허브 **개방 데이터** 에 붙는 조건이다. 같은 정책 페이지가 KETI · 공항 CCTV · 카이스트 오디오북 같은 일부 데이터셋에는
`비상업적인 목적의 연구나 개발에만 사용될 수 있다` 를 따로 붙인다. **데이터셋마다 다르므로 신청 전에 해당 데이터셋 조건을 다시 봐야 한다.**

---

## 6 · NOTE §2 여섯 항목의 판정

| 항목 | 판정 | 근거 |
|---|---|---|
| **ProSem** | **UNRELATED** | wh-intervention(의문사 개입) 중의성을 운율로 가르는 코퍼스다. 낭독된 단일 문장이라 상대 턴 · 대화 맥락 · 사회적 상황이 없다. 가르는 대상이 **의문문 유형이라는 문법 중의성**이지 사회적 단서가 아니다. 라이선스는 CC-BY-SA-4.0 으로 깨끗하지만 **저장소에 데이터가 없고** 본문은 Google Drive · Dropbox 외부 링크에 있으며 저장소 LICENSE 가 그 본문까지 덮는지는 명시가 없다 |
| **ParaKQC** | **UNRELATED** | 주제가 논문에 넷으로 못 박혀 있다 — **이메일 · 일정 잡기 · 스마트홈 · 날씨.** 음성비서 명령 · 질문 도메인이고 단일 발화다. 논문에 공손성 · 사회적 적절성 논의가 없고 speech act 는 의문문/명령문 형식 분류로만 쓰인다. 인접 용도 하나는 적어 뒀다 — 사람이 검수한 한국어 동치 집합이라 A1 동등성 판정기의 보정 참조는 될 수 있다. **그것은 SCD 유관성이 아니다** |
| **K-MIND** | **UNDETERMINED** | 저장소가 빈 껍데기라는 기록이 그대로 재확인됐다 (§4-4). 실물이 없으므로 유관 판정도 무관 판정도 하지 않는다 |
| **KMI** | **INTERPRETIVE_FRAME** | CC BY 4.0 확정. 한국어 자료 중 조건이 가장 깨끗하다. 다만 합성이고 라벨이 상담자 턴에만 붙으며 동기면담은 전문 상담 어휘라 일상 코치와 도메인이 어긋난다 |
| **AI Hub 상담 · 대화 코퍼스** | **SEED_SURFACE (조건부)** | §5. 씨앗 후보가 되기는 한다. 조건 셋을 지켜야 한다. 웰니스 대화 스크립트(267)만 **UNRELATED** — 대화의도 359 종이 전략이 아니라 상담 주제별 사용자 의도이고 안심존 이용과 기관 심의가 필요하다 |
| **KOPLAC · CPLC** | **UNRELATED** | 둘 다 도구이고 데이터가 아니다. 공개 데이터는 §2 의 조건으로 찾았을 때 0 건 |
| **TalkBank 한국어 코퍼스** | **UNRELATED** | CHILDES 한국어는 Jiwon(1 명 · 2;0-2;3) · Ko(30 명 · 0;8-2;3) · Ryu(3 명 · 2;0-3;6) 셋이 전부이고 **전부 일반 발달 영유아다.** CABank 한국어는 0 건. 임상군도 못 덮고 연령도 못 덮는다 |
| **INCA-A 밖의 임상 화용 주석** | **체계는 하나 더 있고 임상군 표본은 없다** | Playlogue 가 **DPICS**(부모-자녀 상호작용 치료의 임상 검증 코딩 체계)를 부모 4,773 · 아동 3,895 발화에 붙였다. 공개 대화 자료에 임상 검증 상호작용 코딩이 대규모로 붙은 INCA-A 밖의 두 번째 사례다. **그런데 대상이 전부 북미 영어권 일반 발달 아동이고 저자도 다른 맥락으로의 일반화를 명시적으로 부인한다** → 임상군 화용 주석의 규모를 늘리지 않는다. 임상군 쪽 실측은 여전히 Rollins 923 건이 전부다 |

**여섯 다 POC 진행을 막지 않는다.** NOTE §2 의 예측이 그대로 맞았다. ProSem 과 ParaKQC 는 무관 판정이라 빠지고, 나머지는 이미 내려 둔 처리를 바꾸지 않는다.

---

## 7 · 만든 파일 검산

2026-09-14 12:55 기준, 디스크에 있는 파일을 다시 읽어 센 값이다.

| 파일 | 행 (헤더 제외) | 열 | 비고 |
|---|---|---|---|
| `DATASET_CENSUS_KO.csv` | 27 | 13 | 모든 물리 행의 필드 수 13 으로 일치 |
| `DATASET_CENSUS_GLOBAL.csv` | 20 | 13 | 같음 |

**라이선스가 확정되지 않은 항목**

두 가지를 나눈다. `NOT STATED` 는 **배포처를 열었는데 라이선스 표기가 없는 것**이고, `NOT CHECKED` 는 **이번 조사에서 약관 페이지를 열지 못한 것**이다.
둘은 다른 상태이고 섞으면 안 된다. 앞의 것은 조사 결과이고 뒤의 것은 조사 범위의 한계다.

| 파일 | `NOT STATED` | `NOT CHECKED` | 합 (미상) |
|---|---|---|---|
| KO | **12** | **5** | **17** |
| GLOBAL | **4** | **1** | **5** |
| 합계 | **16** | **6** | **22** |

`NOT STATED` 16 행의 내역.

- **KO 12** — ToM-Diary · KoCoSa · 한국어 화용 평가셋 · 한국어 간접 화행 평가셋 · K-MIND · CPLC (여섯은 조건 자체가 없어 권리 유보)
  · AI Hub 543 · 544 · 71305 · 267 · 86 · 자폐 관련 데이터 (여섯은 라이선스 **이름**만 없고 포털 이용정책이 조건을 정한다)
- **GLOBAL 4** — AnnoMI · ItaASD · CANDOR · GitHub CHAT 미러

`NOT CHECKED` 6 행의 내역.

- **KO 5** — 서울대 · 가천대 ASD 아동 음성 코퍼스 · ETRI KEMDy20 · SAE4K · 협력적 대화 요약 말뭉치 2025 · 공공데이터포털 언어치료 데이터
- **GLOBAL 1** — ICSI Meeting Corpus

**미상인 22 행은 전부 `redistribution` 이 닫혀 있다** (`RESERVED` 또는 `FORBIDDEN` 또는 `NO`). 열린 채 남은 행은 0 이다.
`UNDETERMINED` 로 두면 읽는 쪽이 "아직 모름 = 아마 괜찮음" 으로 읽기 때문에 막는 쪽으로 닫았고, 확인하지 않았다는 사실은 각 행 `notes` 에 남아 있다.
AI Hub 여섯 행만 `RESERVED` 가 아니라 `FORBIDDEN` 인데, 이것은 더 느슨해서가 아니라 **포털 이용정책이 승인 없는 제3자 제공을 명시적으로 금지하기 때문**이다.

**`model_training` 이 `ALLOWED` 인 행은 5 개다.**

| 파일 | 행 | 라이선스 |
|---|---|---|
| KO | 3i4K · ProSem · ParaKQC | CC BY-SA 4.0 |
| KO | KMI | CC BY 4.0 |
| GLOBAL | AMI Meeting Corpus | CC BY 4.0 |

이 칸은 **라이선스가 무엇을 허용하는가**를 적는 자리이고, 다섯 다 실제로 허용한다.
**우리가 학습에 쓰지 않는다는 것은 별개의 방침이고 이 열이 담는 사실이 아니다.** 두 문장을 겹쳐 쓰면 라이선스 사실 쪽이 틀리게 된다.

## 8 · 이 문서가 약속하지 않는 것

체계적 문헌고찰이 아니다. 검색 엔진(WebSearch)을 한 번도 못 썼고 Zenodo · OSF · KCI · RISS 를 뒤지지 않았다.
그래서 여기의 어떤 부재 진술도 **"없다" 가 아니라 "이 정의로 찾았을 때 없었다"** 로 읽어야 한다.

데이터 파일은 하나도 내려받지 않았다. 확인한 것은 저장소 메타데이터 · 파일 목록 · LICENSE 원문 · README 원문 · 약관 페이지 · 카탈로그 레코드까지다.
따라서 이 census 의 `size` 값 중 실측으로 센 것은 2026-09-11 조사가 오프라인에서 센 것들이고, 나머지는 배포처나 논문이 적은 값이다. `notes` 에 어느 쪽인지 적었다.
