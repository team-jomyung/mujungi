# THEOREM AND PRECEDENT

Evidence file for FINAL_CLOSURE. Compiled 2026-09-12.

**Sourcing rules applied in this document**
- Every row is marked `[FULL TEXT]` or `[ABSTRACT ONLY]`. `[FULL TEXT]` means the body/methods were actually retrieved, not just the abstract.
- No claim of non-existence is made anywhere. Where nothing was found, the entry reads **NOT FOUND AFTER DEFINED SEARCH** and states the exact query string and endpoint used.
- No effect size appears here that was not returned verbatim by a retrieved source. Where a source reported no number, the entry says so.
- WebSearch was not used (quota exhausted). All retrieval was via ar5iv, arXiv (abs + Atom API), Europe PMC REST, and PMC.

---

# PART 1 — THE DORNER THEOREM, READ PROPERLY

## 1.0 Bibliographic record

| Field | Value |
|---|---|
| Title | *Limits to scalable evaluation at the frontier: LLM as Judge won't beat twice the data* |
| Authors | Florian E. Dorner, Vivian Y. Nastl, Moritz Hardt |
| arXiv | 2410.13341 |
| Venue | ICLR 2025 (comments field: "ICLR 2025; 27 pages, 8 figures") |
| Versions | v1 2024-10-17 · v2 2025-02-11 · v3 2026-01-06 · v4 2026-08-17 |
| Retrieval | **[FULL TEXT]** via `https://ar5iv.labs.arxiv.org/html/2410.13341` (three passes: setup/theorems, scope/limitations, future work/continuous case). Metadata cross-checked against `https://arxiv.org/abs/2410.13341`. |

OpenReview was attempted at `https://openreview.net/forum?id=SJ80wEEsIv` and returned a bot-verification interstitial, not the forum. Reviews therefore **NOT FOUND AFTER DEFINED SEARCH** (endpoint: openreview.net/forum; blocked by challenge page, not absent).

---

## 1.1 Headline correction

> **The claim under review:** *"LLM judges cannot reduce human labels by more than half — therefore full automation is theoretically impossible."*

**Verdict: the first clause is a fair paraphrase of Corollary 7 under its stated assumption. The second clause ("therefore full automation is theoretically impossible") does not follow and is not what the paper proves.**

Three distinct over-generalizations are packed into that sentence:

1. **"LLM judges cannot reduce human labels by more than half"** — true only *under the assumption* `0.5 ≤ AG(m) ≤ b(m)`, i.e. only at the frontier where the judge is no better at judging than the evaluated model is at the task. The paper states this assumption explicitly in Theorem 6 and Corollary 7, and explicitly says gains above 2× are possible when it fails.
2. **"cannot reduce ... labels"** — the bound is on the *variance* of an estimator of an aggregate quantity, converted into an equivalent-sample-size statement. It is not a bound on the number of items a human must look at in a labelling pipeline.
3. **"therefore full automation is impossible"** — the theorem is about **estimating a population mean**, not about **producing per-item labels**. Nothing in the paper addresses whether an individual item can be labelled without a human. The paper never makes an automation-impossibility claim.

The precise applicability statement for the PoC pipeline is in §1.8.

---

## 1.2 Formal setup — what is actually being estimated

**[FULL TEXT]** The estimand is an expectation over an input distribution, not a per-item label:

> "For a fixed model m, our goal is to estimate its true score 𝔼s(x, m(x))," where "the expectation is taken over an input drawn from a distribution."

> "The model m is then evaluated based on its expected score 𝔼s(X, m(X))."

> "the goal is to estimate E[s(m)] = E[s(X,m)]"

Notation, verbatim from the paper:

| Symbol | Meaning |
|---|---|
| `s(x, m(x))` | binary **ground-truth** score of model m on input x |
| `s̃(x, m(x))` | binary **proxy** score from the judge model |
| `b(m) = ℙ{s(m)=1}` | the evaluated model's expected true score (its accuracy) |
| `p(m) = ℙ{s̃(m)=s(m) \| s(m)=1}` | judge true positive rate |
| `q(m) = ℙ{s̃(m)=s(m) \| s(m)=0}` | judge true negative rate |
| `n` | number of ground-truth-labelled samples |
| `N` | number of proxy-scored samples |
| `AG(m) = b(m)p(m) + (1−b(m))q(m)` | judge **agreement rate** with ground truth |

Boundary cases are excluded: "we assume b(m), p(m), q(m) ∈ (0,1) for the remainder of the text."

**The debiasing family.** Prediction-Powered Inference (PPI) is the central object, *and it is squarely inside the bound, not outside it*:

> "The PPI estimator thus equals θ̂^PP(x) = 1/N ∑_{i=n+1}^{N+n} s̃_i(m) + 1/n ∑_{j=1}^{n} (s_j(m) − s̃_j(m))."

with the interpolated (power-tuned) variant `θ̂^PP_λ = λ θ̂^PP + (1−λ) θ̂^GT`.

**The quantity bounded.** The *sample efficiency factor*:

> "We call τ(θ̂) ≔ Var(θ̂^GT)/Var(θ̂) the sample efficiency factor of the estimator θ̂. It is our main quantity of interest."

> "Using an estimator θ̂ with sample efficiency factor τ is equivalent to increasing the ground-truth sample size by a factor of τ."

That last sentence is the *only* bridge from the variance bound to the "half the labels" language. It is an equivalent-sample-size statement about estimating a mean.

---

## 1.3 The theorems, verbatim

**Theorem 5 (optimality of PPI within the class).** **[FULL TEXT]**

> "Let Θ be the set of all unbiased estimators for 𝔼s(m) that observe n joint samples (s(m), s̃(m)) and N independent proxy samples s̃(m). Then, any θ̂ ∈ Θ fulfills the variance bound Var(θ̂) ≥ Var(θ̂^PP_{λ*})."

Consequence given in the paper:

> τ(θ̂) ≤ max_{θ̂∈Θ} τ(θ̂) = τ(θ̂^PP_{λ*}) ≤ 1/(1 − ρ(s(m), s̃(m))²)

where ρ is the Pearson correlation between true and proxy score.

**Theorem 6 (correlation ceiling at the frontier).** **[FULL TEXT]**

> "Assume 0.5 ≤ AG(m) ≤ b(m). Then, ρ(s(m), s̃(m))² ≤ 0.5"

**Corollary 7 (the headline).** **[FULL TEXT]**

> "Assume 0.5 ≤ AG(m) ≤ b(m). Then, τ_max = max_{θ̂∈Θ} τ(θ̂) ≤ 2."

**Theorem 10 (continuous proxy scores).** **[FULL TEXT]**

> "For any proxy score s̃ with SO(R(s̃)) ≤ b, we have ρ²(s, s̃) ≤ 0.5. Correspondingly, the sample efficiency of PPI is bounded: τ(θ̂^PP_λ*) ≤ 2."

with soft agreement `SO(s̃) ≔ E[s s̃ + (1−s)(1−s̃)]` and `R(s̃) = P(s=1 | s̃)` the recalibrated proxy.

**Proposition 3 (ranking).** **[FULL TEXT]** Ranking is handled separately and is a *consistency* statement, not a τ bound:

> "Let θ̂ be an estimator... such that Var(θ̂) converges to zero in dataset size. Then if |E[θ̂(m)] − E[s(m)]| < ε/2 for all models m, using θ̂ to rank models yields the correct ranking with high probability."

For model *pairs* (Appendix A.3), the paper notes the difference estimator `θ̂^PP_λ*(m) − θ̂^PP_λ'*(m')` is not automatically optimal and requires joint optimization of λ and λ'; empirically the τ ≤ 2 behaviour still held.

### Assumption list for Theorem 5, made explicit

1. **Unbiasedness.** Θ contains only estimators unbiased for 𝔼s(m). Biased-but-lower-MSE estimators are outside Θ.
2. **Sampling design.** n *joint* samples `(s, s̃)` plus N *independent* proxy-only samples. Uniform sampling.
3. **Black-box scoring.** "we treat the scoring functions s and s̃ as black boxes, as is standard, and focus on the joint distribution of the two induced random variables."
4. **No prompt-conditional modelling.** The decisive scope clause:

> "For black-box estimators that do not model the prompt-conditional distribution ℙ[(s(m), s̃(m))|x], we show that the answer is *no*"

   i.e. **estimators that do model ℙ[(s, s̃)|x] are not covered by Theorem 5.** This is the authors' own carve-out, not an inference of mine.

Theorem 6/Corollary 7 add: 5. **Frontier condition** `0.5 ≤ AG(m) ≤ b(m)`.

---

## 1.4 What "judge is no more accurate than the evaluated model" means formally

It is the condition **`0.5 ≤ AG(m) ≤ b(m)`**, and it *is* a same-distribution agreement-with-ground-truth condition. **[FULL TEXT]**

- `AG(m)` is the judge's **agreement rate with ground truth on the same item distribution** the model is evaluated on: `AG(m) = b(m)p(m) + (1−b(m))q(m)`.
- `b(m)` is the evaluated model's accuracy on that same distribution.
- The paper's own gloss: "for binary classification, AG(m) equals the judge model's accuracy, while b(m) equals the evaluated model's accuracy."
- The framing sentence: "We focus on tasks for which performing and judging the task are of similar difficulty."
- And in plain words: "When the judge model performs worse at its task than the evaluated model, the optimal debiasing method is no better than using twice the ground truth data."

The lower bound `0.5 ≤ AG(m)` also matters: the condition is a *sandwich*, not a one-sided inequality.

**This assumption is an empirical property of a specific (judge, task, item distribution) triple. It is not a law.** The paper is explicit that when judging is easier than doing, the condition fails and gains above 2× are available.

---

## 1.5 Aggregate quantity vs per-item labels — the decisive distinction

**[FULL TEXT]** The paper estimates `𝔼s(X, m(X))`, a scalar population mean. Every theorem bounds the **variance of an estimator of that scalar**.

Nothing in the paper:
- bounds the accuracy of a per-item label,
- bounds how many individual items a human must inspect in an annotation pipeline,
- models a decision rule that routes some items to humans and accepts others,
- or makes any claim about whether a given item can be labelled without a human.

These are different problems with different loss functions. Estimating a mean to a target variance and producing a correct label for every item are not reducible to one another: an estimator can hit the mean with tiny variance while every individual proxy label is wrong in a compensating way, and conversely a per-item labeller can be excellent on 90% of items and useless on 10%.

**Consequence:** an argument of the form "Dorner ⇒ you will always need humans on at least half the items" is a category error. The theorem's `τ ≤ 2` is about *estimator variance equivalence*, not about *item counts in a labelling workflow*.

---

## 1.6 What the authors themselves say is NOT covered

Verbatim, from the Discussion (Section 6) — quoted in full because it is the load-bearing passage: **[FULL TEXT]**

> "Our results show that for evaluating frontier models, LLM judges might fall short of the promise of largely replacing expert labelers: While doubling the effective sample size can be useful for practitioners, the order of magnitude of required ground truth labels remains the same with and without access to LLM judges. That said, there are ways to circumvent our negative results:
>
> First, our results pertain to uniform sampling rather than more sophisticated sampling strategies. Approaches like stratified PPI might be able to obtain a somewhat better sample efficiency factor, for example by breaking the assumptions of Theorem 6 per-stratum. That said, Theorem 5 still applies per-stratum. Empirical results presented in Appendix B.3 suggest that at the frontier, stratified PPI rarely improves sample efficiency by more than a factor of two, compared to standard stratified sampling. Second, Theorem 6 only holds if the proxy s̃ is less capable at predicting s than the evaluated model m is at its task. Thus, for tasks in which evaluation is substantially easier than the task itself, or tasks for which data to train a specialized evaluator is abundant, gains in sample efficiency of more than a factor two are possible even when evaluating models at the frontier. In addition, weaker models might find their way into many applications due to cost saving reasons, such that efficient evaluations of these models are still valuable.
>
> Finally, we would like to reiterate that our results do not only apply to LLM judges, but any form of biased evaluators including (poorly instructed) crowdworkers."

Additional scope notes:

> "Although our motivation focuses on language models as the source of proxy scores, our formal work applies to any proxy score, e.g., scores provided by crowdworkers."

On stratification (Appendix B.3):

> "Theorem 5 still applies per-stratum when applying stratified PPI... A judge model that is weaker than the evaluated model on average could still be stronger on certain strata, thus achieving a sample efficiency factor larger than two (on these strata)."

### Coverage table

| Method / setting | Covered by the bound? | Basis |
|---|---|---|
| Prediction-Powered Inference (PPI), incl. power-tuned λ | **YES — it is the optimum within Θ** | Theorem 5 |
| Control variates / difference estimators of this form | **YES** — the PPI estimator *is* a control-variate estimator; any unbiased estimator seeing (n joint, N proxy) samples is in Θ | Theorem 5 |
| Any other **unbiased** estimator of 𝔼s(m) on uniform samples | **YES** | Theorem 5 ("the set of all unbiased estimators") |
| **Stratified sampling / stratified PPI** | **PARTIALLY** — Theorem 5 applies *per stratum*; Theorem 6's assumption can break per-stratum, so >2× is possible on strata where the judge is locally strong. Authors' Appendix B.3 empirics: "rarely improves sample efficiency by more than a factor of two" at the frontier | Discussion + App. B.3 |
| **Non-uniform / adaptive sampling strategies** | **NOT COVERED** — "our results pertain to uniform sampling rather than more sophisticated sampling strategies" | Discussion |
| **Estimators that model ℙ[(s, s̃)\|x]** (prompt-conditional) | **NOT COVERED** — explicit carve-out in the Theorem 5 scope clause | Section 3 scope clause |
| **Active learning** (choosing which items to label) | **NOT ADDRESSED** — no treatment in the paper | Absence across three full-text passes; see search log §1.9 |
| **Selective prediction / abstention / judge-confidence routing** | **NOT ADDRESSED** — no treatment in the paper | Absence across three full-text passes; see search log §1.9 |
| **Per-item label production** | **NOT THE PROBLEM STUDIED** — estimand is 𝔼s(m) | §1.5 |
| Biased estimators / MSE-optimal shrinkage | **NOT COVERED** — Θ is defined as unbiased estimators only | Theorem 5 |
| Judges stronger than the model (`AG(m) > b(m)`) | **BOUND DOES NOT BIND**; the paper gives no replacement upper bound for this regime | Discussion |

---

## 1.7 The empirical section

**[FULL TEXT]**

**Settings.** Two primary, one appendix:
- **MMLU** multiple-choice QA. "We obtain model predictions from the HELM... leaderboard... We then aggregate all subtasks of MMLU into a single test set and set s equal the accuracy score."
- **MT-Bench** chatbot evaluation, pairwise: "For each pair of these models m and m′, both models are queried with the same prompt x... an expert evaluator decides whether model m produced a better response than m′."
- **TruthfulQA** (Appendix B.2).

**What was measured.** "In all cases, we calculate the empirical correlation ρ(s, s̃) between the score s and the proxy s̃ to obtain and plot an upper bound for the sample efficiency factor τ_max based on Theorem 5." Note this is an *upper bound on achievable savings*, computed from realized correlations — not a measured saving from a deployed pipeline.

**Realized results (verbatim):**
- MMLU (Fig. 2): "Sample efficiency gains stay below two, unless SOTA models are used to evaluate weak models."
- MT-Bench (Fig. 3): "Sample efficiency get close to two in some cases, but consistently stay below that value."
- Overall: "The sample efficiency factor τ_max consistently stays below the value of two suggested by Corollary 7, except when current flagship models are used to judge the significantly worse LLama2-7b on MMLU."
- Magnitude caveat: "τ_max is often substantially smaller than two, especially on MMLU. This highlights that Corollary 7 provides a best-case upper bound rather than a guarantee that τ_max will be close to two in practice."
- TruthfulQA (App. B.2): "the sample efficiency factor τ_max is consistently below two when weaker models are used to evaluate stronger ones."

**No single headline percentage saving is reported.** The empirical contribution is "realized τ_max is below the theoretical ceiling, often well below." Do not quote a specific savings percentage from this paper; it does not publish one.

---

## 1.8 APPLICABILITY STATEMENT for the PoC pipeline

**The pipeline under review:**
1. Two human annotators label structured fields on conversation pairs → **gold set**.
2. An **LLM panel** labels new conversation pairs.
3. **Low-confidence pairs are routed to a human.**

### Where the theorem BINDS

**(A) Any claim of the form "our benchmark score / field-level accuracy is X%, estimated using panel labels debiased by the gold set."**

If the PoC reports an aggregate metric — panel accuracy on a field, agreement rate, a leaderboard-style score, a "% of Tier-S items correctly labelled" figure — computed by a PPI-style or control-variate estimator that mixes `n` human-labelled items with `N` panel-labelled items, then:

- Theorem 5 applies. PPI with tuned λ is the variance-optimal choice within the unbiased class; no cleverer unbiased combination will beat it.
- **If** the panel's agreement with the two-human gold on the same item distribution satisfies `0.5 ≤ AG ≤ b` (judge agreement no better than the accuracy of whatever is being scored), **then** Corollary 7 caps the effective-sample-size multiplier at 2. Budgeting on an assumption of, say, "the panel gives us 10× the effective gold" is not defensible in that regime.
- The condition is checkable. `AG` is measurable directly from the double-annotated gold set: it is the panel's agreement rate with the adjudicated human label. `b` is the accuracy of the thing being evaluated. **Measure both before invoking or dismissing the bound.** Note the PoC's own reported numbers — similarity-判정기 AUC ≈ 0.58 vs relevance ≈ 0.86+ — suggest the two are in very different regimes, and the bound's applicability differs field by field.
- Per-field stratification is worth doing: the authors explicitly note a judge weaker on average can be stronger on particular strata, and τ > 2 is available there. Theorem 5 still holds within each stratum.

**(B) Sample-size planning for the gold set, if planning assumes panel labels substitute for gold labels in the variance calculation.** Same reasoning; the order of magnitude of gold items needed does not change.

### Where the theorem DOES NOT BIND

**(C) The two-human gold annotation step — not constrained.** The theorem says nothing about how to construct ground truth. It takes `s` as given.

**(D) Per-item labelling by the panel — not constrained.** The estimand in Dorner is `𝔼s(X, m(X))`, a population mean (§1.5). The PoC's step 2 produces *labels on items*, which is a different problem with a different loss. There is no theorem here bounding per-item label quality, and no theorem here implying any floor on the fraction of items a human must see.

**(E) Selective routing / abstention — EXPLICITLY NOT CONSTRAINED. Stated plainly, as requested:**

> **The Dorner theorem does not apply to selective routing for per-item labelling.**

Three independent reasons, each sufficient:

1. **Wrong estimand.** Routing produces per-item labels; the theorem bounds the variance of an estimator of an aggregate mean.
2. **Wrong sampling design.** "our results pertain to uniform sampling rather than more sophisticated sampling strategies." Confidence-based routing is by construction non-uniform and adaptive — it selects which items get human labels *as a function of the judge's own output on those items*.
3. **Wrong estimator class.** Routing on judge confidence is precisely an estimator that uses `ℙ[(s, s̃)|x]` — the per-prompt conditional the authors carve out: "For black-box estimators that **do not model the prompt-conditional distribution** ℙ[(s(m), s̃(m))|x], we show that the answer is no." A confidence-based router models exactly that conditional. It is outside Θ.

The paper contains no treatment of abstention, selective prediction, active learning, or confidence-based human routing. That is a gap in the theorem's coverage, not a silent extension of it.

**(F) The claim "full automation is theoretically impossible" is NOT supported by this paper.** The paper's own strongest statement is the much narrower: "LLM judges might fall short of the promise of largely replacing expert labelers: While doubling the effective sample size can be useful for practitioners, the order of magnitude of required ground truth labels remains the same." That is a statement about label *budget order-of-magnitude for aggregate estimation*, not about automation feasibility.

### Recommended wording for the PoC writeup

> Dorner, Nastl & Hardt (ICLR 2025) show that when a judge's agreement with ground truth does not exceed the accuracy of the system being scored, no unbiased debiasing estimator over uniformly sampled items can more than double the effective size of the ground-truth set (τ ≤ 2). We apply this where it applies: to our **aggregate field-level accuracy estimates** computed from gold + panel labels, where it caps the leverage we may claim from the panel. It does not govern our **per-item routing design**, because the theorem bounds the variance of an estimator of a population mean under uniform sampling by estimators that do not model the prompt-conditional distribution, whereas confidence-based routing is per-item, non-uniform, and explicitly conditions on the prompt — all three of which the authors place outside their result. We therefore make no automation-impossibility claim on the basis of this theorem, and we report the measured agreement rate AG against our adjudicated gold set so the bound's applicability can be checked directly, per field.

---

## 1.9 Search log for Part 1

| Query / endpoint | Result |
|---|---|
| `https://ar5iv.labs.arxiv.org/html/2410.13341` — pass 1: setup, theorems, estimator family, empirics | Retrieved, FULL TEXT |
| same URL — pass 2: scope, "we do not consider", "future work", "limitation", active learning, abstention, routing, selective prediction, judge confidence, aggregate-vs-per-item | Retrieved. Active learning, abstention, selective prediction, judge-confidence routing: **NOT FOUND AFTER DEFINED SEARCH** in the paper body |
| same URL — pass 3: future work, Theorem 10, ranking/model comparison, τ definition, judge-stronger regime | Retrieved, FULL TEXT |
| `https://arxiv.org/abs/2410.13341` — metadata, versions, venue | Retrieved |
| `https://openreview.net/forum?id=SJ80wEEsIv` — reviews | **NOT FOUND AFTER DEFINED SEARCH**: endpoint returned a bot-verification interstitial, no forum content |

---

# PART 2 — PRECEDENT FOR "REAL PERSONAL EXPERIENCE → TRAINING MATERIAL"

The chain to be evidenced, arrow by arrow:

```
real event capture → reflection → rehearsal → transfer → outcome follow-up
```

Evidence grades used: **DIRECT** (same construct, same or closely comparable population and modality) · **ADJACENT** (established, but in another population or domain) · **NOT FOUND AFTER DEFINED SEARCH**.

---

## 2.0 Headline finding

**Yes — published interventions do use the client's own recorded real interaction as the training stimulus, and the evidence for that design is strong, including a 6-year randomised follow-up.** But the strongest instances are almost all **dyadic caregiver-mediated** work (parent–child, spouse–person-with-aphasia), where the person who watches the video and changes their behaviour is the *communication partner*, not the person with the communication difficulty.

The specific configuration the PoC is aiming at — **the individual's own real conversation, captured in daily life, fed back to that individual for their own social-communication skill** — is where the chain thins out. See §2.6.

---

## 2.1 ARROW 1 — real event capture

### Grade: **DIRECT** for dyadic clinical work; **DIRECT but assessment-only** for momentary capture of everyday social interaction.

**1a. Clinical recording of the dyad's own real interaction (DIRECT)**

| Study | Design | Population | What is captured | Cite | Source |
|---|---|---|---|---|---|
| Bouaziz et al., *Child Adolesc Psychiatry Ment Health* 2026 — PACT focus group | Qualitative | Parents of autistic children who completed PACT | "PACT uses video feedback to analyze parent-child play sequences with the parent and to support parental reflexivity about the most appropriate interactive style." | DOI 10.1186/s13034-026-01072-x · PMID 41888850 | [ABSTRACT ONLY] |
| Starreveld et al., *Attach Hum Dev* 2024 — VIPP-School | RCT, 58 teacher–child dyads | Teachers, K–grade 2 | "videotaped interactions during five 1.5-hour sessions at school" | DOI 10.1080/14616734.2024.2419621 · PMID 39470124 | [ABSTRACT ONLY] |
| Ramchandani et al., *JCPP* 2026 — VIPP-SD 6-year follow-up | RCT, n=300 | Caregivers of children 12–36m at risk of behaviour problems | "6 home-based video-feedback sessions" | DOI 10.1111/jcpp.70037 · PMID 40959892 | [ABSTRACT ONLY] |
| Volkmer et al., *Int J Lang Commun Disord* 2026 — Better Conversations intensive groups | Service improvement, 9 dyads (4 non-progressive aphasia, 5 PPA) | Aphasia / PPA dyads | "identifying individual dyad facilitators and barriers to conversation (using video feedback)" | DOI 10.1111/1460-6984.70296 · PMID 42533589 | [ABSTRACT ONLY] |
| Winsnes et al., *Brain Sci* 2025 — Norwegian BC-PPA adaptation | Cultural adaptation pilot, 4 dyads | PPA dyads | "coding of conversation behaviours from video samples" collected pre-, post-, 3-month follow-up | DOI 10.3390/brainsci15090994 · PMID 41008354 | [ABSTRACT ONLY] |
| Totsika et al., *Pilot Feasibility Stud* 2026 — Video Interaction Guidance | Feasibility RCT, 44 consented / 40 randomised | Parents of children with intellectual disability, 6–12y | "Video Interaction Guidance (VIG) is a brief, personalised, strengths-based therapy that focuses on improving the parent-child relationship and interactions." Remotely delivered. | DOI 10.1186/s40814-026-01800-2 · PMID 41814416 | [ABSTRACT ONLY] |

**Important caveat on naturalistic vs clinic capture.** A dedicated search for whether Better Conversations records the dyad's *everyday home* conversation with their *own* partner (as opposed to clinic-recorded interaction) did not resolve from abstracts. The Volkmer abstract confirms video feedback of the dyad, but does not state the recording location. **Home-setting recording: NOT FOUND AFTER DEFINED SEARCH** at abstract level — queries: `("Better Conversations" AND (aphasia OR conversation therapy))` and `AUTH:"Beeke S"`, endpoint Europe PMC REST `/search?...&resultType=core`. The canonical Beeke et al. *Better Conversations with Aphasia* methodology papers (Aphasiology, UCL) are not indexed in Europe PMC with retrievable abstracts and were not obtained. This should be resolved from the BCA manual before the PoC cites home-recording precedent.

**1b. Momentary capture of everyday social interaction (DIRECT for capture, but see Arrow 2)**

Sixteen studies returned; 1,577 total hits. Representative, all **[ABSTRACT ONLY]**:

| Study | N | Capture | Cite |
|---|---|---|---|
| Bilston, *JMIR Ment Health* 2026 | 190 (18–24y) | "EMA capturing affective and affiliative responses to recent online or offline social interactions 3× daily for 1 week" | 10.2196/94753 · PMID 42574044 |
| Adamis et al., *Behav Res Ther* 2025 | 202 (108 high / 94 low social anxiety) | "Three times per day for one week...participants reported their attention orientation...during real-world social interactions" | 10.1016/j.brat.2025.104759 · PMID 40318602 |
| Hay et al., *J Anxiety Disord* 2026 | 116 | "EMA...three times a day...across a 15-17-day period" on "social interactions" and "belongingness" | 10.1016/j.janxdis.2026.103126 · PMID 41637871 |
| Kuhney et al., *Schizophr Bull* 2025 | 193 (132 CHR-p, 61 HC) | "6 days of digital phenotyping...EMA surveys focused on in-person and electronic social interactions" | 10.1093/schbul/sbaf032 · PMID 40170392 |
| Ilen et al., *Sci Rep* 2026 | 51 (27 autistic, 24 non-autistic, 11–26y) | "EMA assessed daily affective dynamics" | 10.1038/s41598-025-34614-y · PMID 41495332 |
| Yarger et al., *BMJ Open* 2025 (ADORA protocol) | 160 (80 autistic, 80 non-autistic, 11–14y) | "real-time self-reports of anxiety captured through ecological momentary assessment" + HRV | 10.1136/bmjopen-2025-107684 · PMID 40908015 |

Capture of real social interaction in daily life is a mature, well-populated method. **Arrow 1 is not the bottleneck.**

---

## 2.2 ARROW 2 — reflection (captured event fed back to the person)

### Grade: **DIRECT for dyadic video feedback (caregiver/partner as the reflecting agent). NOT FOUND for EMA-captured social interaction fed back to the individual.**

**The split is sharp and is the most important empirical finding in Part 2.**

**2a. Video feedback = reflection, established (DIRECT).** The reflective function is stated explicitly in the primary construct description:

> "PACT uses video feedback to analyze parent-child play sequences with the parent and **to support parental reflexivity** about the most appropriate interactive style." — Bouaziz et al. 2026, PMID 41888850 [ABSTRACT ONLY]

Corroborating: Lassen et al., *Infant Ment Health J* 2026, qualitative VIPP-SD study, 11 parents — "video feedback and the educational content were experienced as key" (DOI 10.1002/imhj.70064 · PMID 41486089) [ABSTRACT ONLY]. Cotugno et al., *Front Psychol* 2025 — family-based therapy "enhanced through attachment-based strategies such as video feedback, emotional regulation, and **reflective** parenting" (DOI 10.3389/fpsyg.2025.1710932 · PMID 41608175) [ABSTRACT ONLY].

**2b. EMA-captured social interaction fed back to the participant: NOT FOUND AFTER DEFINED SEARCH.**

Query: `("ecological momentary assessment" OR "experience sampling") AND ("social interaction" OR "social communication") AND (autism OR adolescent OR "social anxiety")`
Endpoint: `https://www.ebi.ac.uk/europepmc/webservices/rest/search?...&format=json&pageSize=30&resultType=core` · 1,577 hits, top 30 examined.

Result: **15 of 16 identifiable studies used the captured social-interaction data for assessment only, with no feedback to the participant and no intervention.** The single intervention study (Ma et al., *JMIR Pediatr Parent* 2026, 40 parents of autistic children, DOI 10.2196/84224 · PMID 42241696) delivered mindfulness psychoeducation to parents and did **not** capture or feed back moment-to-moment social interaction data.

Within this defined search, **no study was found in which a person's own EMA-captured real social interaction was returned to them as reflective material.** This is a genuine gap, not a null result to be glossed over — and it is precisely the arrow the PoC would be instantiating.

---

## 2.3 ARROW 3 — rehearsal

### Grade: **DIRECT** that rehearsal is a standard, explicitly-coded component of communication partner training; **DIRECT** that rehearsal produces measured skill gains.

| Finding | Source | Grade |
|---|---|---|
| "behavioral practice/rehearsal" formally identified as a **common behaviour change technique across communication partner training programs** (TBI Express and adapted versions); 20–25 BCTs and 15–16 mechanisms of action coded | Behn et al., *Int J Lang Commun Disord* 2026 · DOI 10.1111/1460-6984.70238 · PMID 41968884 [ABSTRACT ONLY] | DIRECT (methodological) |
| Better Conversations includes "**practice** (in the group and across dyads) of conversation strategies"; 26 h over 2 weeks; 26/31 goals self-rated achieved, no change on 5 | Volkmer et al. 2026 · PMID 42533589 [ABSTRACT ONLY] | DIRECT |
| PEERS for Preschoolers RCT, 46 autistic children (mean 4.50y): "Significant improvements were found in child social responsiveness, social skills, behavior problems"; number of playdates increased | Martinez et al., *J Korean Acad Child Adolesc Psychiatry* 2026 · DOI 10.5765/jkacap.250042 · PMID 41523201 [ABSTRACT ONLY] — **no numeric effect size reported in abstract** | DIRECT |
| Three-level meta-analysis of single-case designs, ASD social problem-solving: **pooled effect = 1.741 (SE 0.087, 95% CI [1.570, 1.911])**. Caveat stated by authors: "It is not possible to isolate the independent contribution of SPS components" | Jin et al., *Behav Sci* 2026 · DOI 10.3390/bs16071129 · PMID 42510250 [ABSTRACT ONLY] | DIRECT (aggregate, component not isolable) |
| School-based interventions for ADHD, n=1,962: **social skills d = 0.28, p<0.001** | Yegencik et al., *Front Psychol* 2025 · DOI 10.3389/fpsyg.2025.1611145 · PMID 40761448 [ABSTRACT ONLY] | ADJACENT (ADHD, school setting) |

**Rehearsal works as a within-setting skill-acquisition mechanism. The question is Arrow 4.**

---

## 2.4 ARROW 4 — transfer / generalization to real life

### Grade: **This is the weakest arrow. Evidence is mixed and several primary sources report transfer as variable or absent.**

Reporting this honestly matters more than reporting it favourably.

**Negative / cautionary findings:**

| Finding, verbatim | Source | Source type |
|---|---|---|
| "Transfer to real-world functioning is **more variable**" (social-cognitive and metacognitive interventions in complex psychosis) | Pinzi et al., *Medicina (Kaunas)* 2026 · DOI 10.3390/medicina62050841 · PMID 42195093 | Narrative review [ABSTRACT ONLY] |
| "**Figural transfer was identified in 24 studies, while literal transfer was identified in 10 studies**" (serious games, adolescents) | de Rooij et al., *JMIR Serious Games* 2026 · DOI 10.2196/77173 · PMID 41961995 | Systematic review [ABSTRACT ONLY] |
| "Future research should focus on implementation strategies **enhancing skill generalisation**, addressing resource limitations" (schizophrenia spectrum) | Nitayawan et al., *BMJ Open* 2025 · DOI 10.1136/bmjopen-2025-106597 · PMID 41436267 | Scoping review [ABSTRACT ONLY] |
| VR for ASD social/communication skills: "Evidence is **too heterogeneous and immature for valid quantitative synthesis**" — no stable estimates produced | Wang et al., *JMIR Pediatr Parent* 2026 · DOI 10.2196/82814 · PMID 42061227 | Network meta-analysis [ABSTRACT ONLY] |

**Positive finding — and notably, it comes from the branch that trains in the natural setting rather than the clinic:**

| Finding, verbatim | Source | Source type |
|---|---|---|
| "Children's midpoint social communication **at home generalised to school** at midpoint **and to clinic** at endpoint." 248 autistic children (2–11y), PACT-G, assessments at baseline / +7m / +12m | Carruthers et al., *J Autism Dev Disord* 2025 · DOI 10.1007/s10803-024-06370-x · PMID 38743153 | Cross-setting generalisation study [ABSTRACT ONLY] |

That single result is the most directly relevant generalisation evidence located, and it is worth noting its direction: generalisation ran **from the home (the real setting where the intervention operated) outward**, not from clinic inward.

**Caution against over-claiming from PACT-G:** the same programme's main RCT was null on its primary outcome — "no significant treatment effects on the end-point Autism Diagnostic Observation Schedule-2 primary outcome (**–0.04, 95% CI –0.26 to 0.18; p = 0.734**)", n=249 (122 PACT-G / 127 TAU), three-site parallel-group RCT (Green et al., *NIHR Efficacy and Mechanism Evaluation* 2022 · PMID 35605069) [ABSTRACT ONLY]. Generalisation of a measured behaviour across settings is not the same as efficacy on a diagnostic outcome.

---

## 2.5 ARROW 5 — outcome follow-up

### Grade: **DIRECT and strong — including two long-horizon randomised follow-ups. This is the best-evidenced arrow after Arrow 1.**

| Study | Design | Follow-up horizon | Result, verbatim | Cite | Source |
|---|---|---|---|---|---|
| **VIPP-SD long-term (UK)** — Ramchandani et al., *JCPP* 2026 | RCT, n=300 randomised (294 analysed, **244 retained at 6 years**); 6 home-based video-feedback sessions | **6 years** | "**probability of 86% that VIPP-SD was superior**"; **d = −0.11** on PACS total score (authors describe as small) | DOI 10.1111/jcpp.70037 · PMID 40959892 | [ABSTRACT ONLY] |
| **PACT mid-childhood follow-up** — Carruthers et al., *JCPP* 2024 | RCT, 152 randomised at ages 2–5; **121 (79.6%) followed 5–6 years after endpoint**, mean age 10.5y | **5–6 years post-endpoint** | "Increased child initiation at treatment midpoint mediated the **majority (73%)** of the treatment effect on follow-up ADOS CSS." | DOI 10.1111/jcpp.13798 · PMID 37095645 | [ABSTRACT ONLY] |
| Alimirzaie et al., *Attach Hum Dev* 2026 | Quasi-experimental, 60 Iranian mothers, 8 weekly group sessions with video feedback | 3 months | **partial η² = .72** (sensitivity); **partial η² = .66** (maltreatment risk); effects maintained at 3-month follow-up | DOI 10.1080/14616734.2026.2713499 · PMID 42554022 | [ABSTRACT ONLY] |
| Starreveld et al., *Attach Hum Dev* 2024 — VIPP-School | RCT, 58 teacher–child dyads | Post-intervention only | **d = 0.87** (teacher sensitivity); **d = 0.53** (supportive interactions) | DOI 10.1080/14616734.2024.2419621 · PMID 39470124 | [ABSTRACT ONLY] |
| Totsika et al., *Pilot Feasibility Stud* 2026 — VIG | Feasibility RCT, 40 randomised | 6 months, **75% retention** | Feasibility outcomes only; 70% of VIG arm completed ≥3 VIG cycles | DOI 10.1186/s40814-026-01800-2 · PMID 41814416 | [ABSTRACT ONLY] |
| Winsnes et al., *Brain Sci* 2025 — BC-PPA Norwegian | Adaptation pilot, 4 dyads | 3 months | Goal Attainment Scaling goals achieved; Aphasia Impact Questionnaire and Communicative Effectiveness Index **maintained at 3-month follow-up** | DOI 10.3390/brainsci15090994 · PMID 41008354 | [ABSTRACT ONLY] |
| Volkmer et al. 2026 — BC intensive groups | Service improvement, 9 dyads | 3 months | 26/31 goals self-rated achieved; "increased confidence and participation across participants" | DOI 10.1111/1460-6984.70296 · PMID 42533589 | [ABSTRACT ONLY] |

**Note the honest magnitude.** The 6-year VIPP-SD effect is **d = −0.11** — a small effect, characterised by the authors probabilistically ("86% probability of superiority") rather than as a confirmed difference. The long-horizon evidence establishes that the *design* is followable and its effects are *detectable years later*; it does not establish large effects.

---

## 2.6 The specific question: does any published intervention use the CLIENT'S OWN recorded/reported real interaction as the training stimulus?

**YES — clearly and repeatedly, in the video-feedback family.** PACT, VIPP / VIPP-SD / VIPP-School, Video Interaction Guidance, and Better Conversations all record the participant's own real interaction and play it back to them as the material worked on.

**But note precisely whose interaction and whose behaviour changes:**

| Programme | Whose real interaction is recorded | Who watches and changes | Is the person with the communication difficulty the trainee? |
|---|---|---|---|
| PACT / PACT-G | parent–child play | the **parent** | No — parent-mediated |
| VIPP-SD / VIPP-School | parent–child, teacher–child | the **parent / teacher** | No |
| Video Interaction Guidance | parent–child | the **parent** | No |
| Better Conversations (aphasia, PPA, Parkinson's, DLD) | the **dyad's** conversation | **both** members of the dyad | Partially — dyadic, both members targeted |

So: the arrow **"own real interaction → reflection → practice → measured outcome years later"** has DIRECT precedent. The narrower arrow **"an individual's own real conversation, captured in ordinary daily life, fed back to that individual for their own social-communication skill"** is where the search found no instance (§2.2b). The PoC should claim the former as precedent and be explicit that it is extending into the latter.

---

## 2.7 Video self-modeling: confirm or refute "shows only SUCCESSFUL clips"

**Instruction was to confirm or refute from a primary source. CONFIRMED — from the primary source, including the Methods.**

**Primary source, Methods section, FULL TEXT** — Ste-Marie, Vertes, Rymal & Martini, *Frontiers in Psychology* 2011;2:155. DOI 10.3389/fpsyg.2011.00155 · PMID 21779270 · PMCID PMC3133863. Retrieved via Europe PMC `/PMC3133863/fullTextXML`.

Abstract, verbatim:
> "The FSM involved **editing video footage such that it showed the learner performing the trampoline routine at a higher skill level than their current capability**."

Materials section, verbatim:
> "The video footage from the pre-test practice trials were used to create these FSM videos...For each participant, one of the researchers qualified in trampoline (former Canadian Novice National champion), examined all of the footage and **selected the best performance of each individual trampoline skill** to create the five-skill routine. These skills were then **edited together to make it appear as though the learner was performing the skills in immediate succession**. The FSM video showed the learner performing the skills in real time."

> "New FSM videos were constructed for each intervention session if the child's performance improved. This was done so that the FSM video would **always show the most successful behaviors**..."

Introduction definitions, verbatim:
> **Positive self-review:** "catch me being good and remind myself of it"
> **Feedforward modeling:** "creating an experience that shows the learner performing at a higher skill level **yet to be attained**, or performing the skill in a more challenging context."

**Corroborating sources** [ABSTRACT ONLY]:
- Steel et al., *Percept Mot Skills* 2021 (cerebral palsy, n=8), DOI 10.1177/00315125211012810 — positive self-review defined as "watching a video of oneself performing **only the best examples** of a desired task."
- Goh et al., *JMIR Form Res* 2021 (Parkinson's, freezing of gait), DOI 10.2196/28315 — "180° videos of the participants **successfully performing** their movement strategies."
- Dowrick, *WIREs Cogn Sci* 2012;3(2):215–230, DOI 10.1002/wcs.1156 · PMID 26301396 — the canonical self-model theory paper; describes learning "from the future" via "feedforward, in which component behaviors (in the repertoire) are reconfigured to produce a new skill." [ABSTRACT ONLY — the full verbatim abstract was not obtainable: `europepmc.org/abstract/MED/26301396` returned navigation chrome only, and `eutils efetch` returned a truncated rendering. **Full Dowrick 2012 abstract: NOT FOUND AFTER DEFINED SEARCH** at those two endpoints.]
- Smith, Hand & Dowrick, *J Autism Dev Disord* 2014;44(4):926–36, DOI 10.1007/s10803-013-1946-0 · PMID 24068486 — "VSM using feedforward" enables "rapid learning" where clients see themselves performing successfully "without needing prompts or intensive operant conditioning." [ABSTRACT ONLY]

**Conclusion.** The characterization is **correct and is confirmed at Methods level from a primary source**. Video self-modeling — in both its variants — is constructed by *removing* failure. Positive self-review shows only past successes; feedforward shows a performance the person **has never actually produced**, assembled by editing. It is an aspirational-exemplar design.

This is indeed the **opposite** of a design in which a person reviews their own unedited real interaction including what went wrong. **No study located in the VSM search showed unedited footage containing errors or failures** — query `"video self-modeling" OR "video self-modelling"`, Europe PMC REST, 17 records examined; 14/17 gave no construction detail in the abstract, 3/17 explicitly described success-only or edited-superior construction, 0/17 described unedited-with-errors. Stated as required: **unedited-including-failure VSM: NOT FOUND AFTER DEFINED SEARCH.**

**Consequence for the PoC.** Video self-modeling is *not* precedent for reviewing one's own real (including unsuccessful) interaction. The precedent for *that* is the video-feedback family — PACT, VIPP, VIG, Better Conversations — where real unedited interaction is reviewed jointly and both facilitators *and barriers* are identified. Note the Volkmer wording explicitly includes both: "identifying individual dyad **facilitators and barriers** to conversation (using video feedback)." Cite the video-feedback family, not VSM, for this arrow.

---

## 2.8 Just-in-time adaptive intervention — real-time trigger from captured state

### Grade: **ADJACENT.** The mechanism is well established; it is almost never applied to social communication.

Query: `"just-in-time adaptive intervention"`, Europe PMC REST, 14 records examined, all **[ABSTRACT ONLY]**.

**Domain distribution — only 1 of 14 targets social/interpersonal skills:**

| Study | Domain | Social? | Result |
|---|---|---|---|
| Elmer et al., PsyArXiv 2026 (micro-randomized trial protocol) — "Activating Social Resources in Psychotherapy-Seeking Individuals" | **social support activation / help-seeking, depression** | ✅ **YES** | Protocol. 5 daily EMAs; 4 randomized triggering conditions (vulnerability-triggered, vulnerability+receptivity, support-need-triggered, control). **Results pending.** DOI 10.31234/osf.io/98jfa_v1 |
| Höhener et al., *JMIR Mhealth Uhealth* 2026 | physical activity in couples (dyadic) | ⚠️ adjacent | dyadic JITAIs increased device-based MVPA — **actor b=11.17, SE=3.18, P<.001; partner b=7.23, SE=3.60, P=.03**; self-reported **actor b=17.34, SE=3.65, P<.001; partner b=11.82, SE=4.10, P<.001**. DOI 10.2196/67136 · PMID 41592319 |
| Kor et al., *JMIR Aging* 2026 | dementia caregiver stress | ❌ | "significant reductions in perceived stress (P<.001), depressive symptoms (P<.001), and caregiver burden (P=.003)"; ML-optimized notification timing. DOI 10.2196/87316 · PMID 42247635 |
| Skeen et al., *JMIR Hum Factors* 2026 | HIV + violence exposure, coping | ⚠️ partial (social support seeking) | "91% (n=28) endorsing increased calm and emotional well-being"; geofencing-triggered. DOI 10.2196/80705 · PMID 42360924 |
| Bollinger et al., *J Subst Use Addict Treat* 2026 | opioid use disorder, geofenced | ⚠️ partial | Protocol; geofence entry triggers "motivational messages, craving check-ins, and optional escalation to social support". DOI 10.1016/j.josat.2026.209946 · PMID 41862055 |
| Guo et al., *JMIR Mhealth Uhealth* 2026 (scoping review, 14 studies) | sedentary behaviour / PA | ❌ | "6 studies provided preliminary evidence supporting the positive effects of JITAIs in promoting PA; 3 studies suggested positive effects on reducing sedentary behavior" |
| Sühs 2026 (pain), Qian 2026 (anger), Lachowicz 2026 (anxiety breathing), Lampe 2026 (cannabis/binge eating), Wang 2026 (liver cancer), Lim 2026 (sedentary), Gazi 2026 (framework), Luo 2026 (bibliometric, 451 articles) | pain, anger, anxiety, substance use, oncology, activity, methods | ❌ | see search log |

**Finding.** JITAI is a mature methodology with real-time-context triggering demonstrated across many domains, but **a JITAI targeting social-communication skill with a reported efficacy result was NOT FOUND AFTER DEFINED SEARCH** — query `"just-in-time adaptive intervention"`, Europe PMC REST `/search?...&pageSize=30&resultType=core`. The one social-domain entry (Elmer et al.) is a protocol with no results yet.

---

## 2.9 Arrow-by-arrow summary

| Arrow | Grade | Best citation | Honest statement of the limit |
|---|---|---|---|
| **real event capture** | **DIRECT** | PACT (PMID 41888850); VIPP-SD (PMID 40959892); EMA social-interaction literature (1,577 hits) | Mature. Home-recording specifically for Better Conversations unconfirmed from abstracts. |
| **→ reflection** | **DIRECT for dyadic video feedback; NOT FOUND for EMA-captured social interaction fed back to the individual** | Bouaziz 2026: video feedback "to support parental reflexivity" | **15/16 EMA social-interaction studies were assessment-only.** This is the PoC's genuine novelty and should be stated as such. |
| **→ rehearsal** | **DIRECT** | Behn 2026 codes "behavioral practice/rehearsal" as a standard CPT technique; Jin 2026 pooled effect 1.741 [1.570, 1.911] | Component contribution not isolable (authors' own caveat). |
| **→ transfer** | **MIXED — weakest arrow** | Carruthers 2025: home→school and home→clinic generalisation, n=248 | Countervailing: Pinzi 2026 "transfer to real-world functioning is more variable"; de Rooij 2026 literal transfer in only 10 studies; PACT-G primary outcome null (−0.04, 95% CI −0.26 to 0.18, p=0.734). |
| **→ outcome follow-up** | **DIRECT, long-horizon** | VIPP-SD 6-year RCT (244 retained, d=−0.11, 86% probability superior); PACT 5–6y follow-up (73% mediation) | Effects at long horizon are **small**. Do not present these as large. |

---

## 2.10 Search log for Part 2

Endpoint for all rows: `https://www.ebi.ac.uk/europepmc/webservices/rest/search?query=<Q>&format=json&pageSize=<N>&resultType=core`, plus `/PMC3133863/fullTextXML` and `/search?query=EXT_ID:21779270`.

| Query string | Hits / examined | Outcome |
|---|---|---|
| `"ecological momentary intervention" AND (social OR communication OR interaction)` | 14 examined | EMI mature; none used the client's own captured social interaction as stimulus |
| `"video self-modeling" OR "video self-modelling"` | 17 examined | Success-only construction confirmed (3 explicit, 0 contradicting) |
| `"video feedback" AND ("social skills" OR "social communication" OR pragmatic)` | 16 examined | PACT reflexivity quote located |
| `"Preschool Autism Communication Trial" OR (PACT AND autism AND (Pickles OR Green) AND randomised)` | 11 examined | PACT-G RCT null primary; Carruthers generalisation + 5–6y mediation located |
| `("behavioral rehearsal" OR "behavioural rehearsal" OR "role-play") AND "social skills" AND (generalization OR generalisation OR transfer)` | 780 hits, 15 examined | Rehearsal effective within setting; transfer mixed |
| `("ecological momentary assessment" OR "experience sampling") AND ("social interaction" OR "social communication") AND (autism OR adolescent OR "social anxiety")` | 1,577 hits, 16 examined | **15/16 assessment-only** |
| `"Better Conversations" AND (aphasia OR conversation therapy)` | 12 examined | Video feedback confirmed; home-recording unconfirmed |
| `AUTH:"Beeke S"` | 12 examined | Same; canonical BCA manual papers not indexed with retrievable abstracts |
| `(Dowrick AND ("self modeling" OR "self-modelling" OR feedforward)) OR ("feedforward" AND "self-modeling")` | 18 examined | Ste-Marie + Smith + Dowrick located |
| `"just-in-time adaptive intervention"` | 14 examined | 1/14 social-domain, protocol only |
| `EXT_ID:21779270` then `/PMC3133863/fullTextXML` | 1 | **FULL TEXT Methods retrieved** — VSM editing confirmed |

**Terms from the brief that were searched and yielded nothing distinct beyond the above, stated as required:**
"autobiographical memory intervention social", "conversation replay therapy", "self-review speech language therapy", "personalized pragmatic intervention", "personalized role-play social skills" — these did not surface as distinct indexed intervention literatures within the Europe PMC queries run above. **NOT FOUND AFTER DEFINED SEARCH** (endpoint: Europe PMC REST `/search`, `resultType=core`; these phrases appeared only as components of the broader queries logged, not as named intervention families with primary trials).

---

# PART 3 — E0–E4 ABLATION LITERATURE

Mapping used:

| Condition | Meaning |
|---|---|
| **E0** | plain LLM, no scaffolding |
| **E1** | LLM + rubric / decomposed criteria in the prompt |
| **E2** | LLM + structured external knowledge supplied in context |
| **E3** | vector / dense RAG |
| **E4** | knowledge-graph / GraphRAG retrieval |

All arXiv rows are **[ABSTRACT ONLY]** unless marked otherwise. arXiv abstracts are author-written claims about their own systems; treat method-paper numbers as upper bounds and weight the independent evaluations more heavily.

---

## 3.1 E0 → E1: does a rubric beat a plain judge prompt?

Query: `all:"LLM-as-a-judge" AND all:"rubric"`, endpoint `http://export.arxiv.org/api/query`, 20 entries examined.

**Strongest head-to-head numbers located:**

| arXiv | Title | Comparison | Number, verbatim |
|---|---|---|---|
| 2605.01630v1 | *Prosa: Brazilian Portuguese Benchmark* | filtered **rubric** scoring vs **holistic** scoring | "Under filtered rubric scoring the three judges agree on every one of 16 ranks, whereas under holistic scoring they agree on only 7 of 16" — i.e. **16/16 vs 7/16 inter-judge rank agreement** |
| 2504.17087v1 | *LLMs as Meta-Judges* | rubric + multi-agent vs raw judgments | "about **15.55% improvement** compared to raw judgments and about **8.37% improvement** over single-agent baseline" |
| 2603.11027v1 | *Beyond the Illusion of Consensus* | **knowledge-anchored** rubrics vs generic rubrics | "Agreement increases in codified domains (**Education +22%, Academic +27%**) where knowledge anchors evaluators" |
| 2601.08654v3 | *From Rubrics to Reliable Scores* | evidence-grounded rubric execution vs frozen prompt-only scoring | "achieves **stronger agreement** with human scores in most evaluated settings, while better matching empirical score distributions" — **no numeric delta in abstract** |
| 2606.01629v4 | *LongJudgeBench* | rubric/reference presence | "rubrics or references are **helpful but not always sufficient**" — no numeric delta in abstract |

**Critical / negative results on rubrics — these matter for an E1 claim:**

| arXiv | Finding, verbatim |
|---|---|
| 2609.02942v1 · *Judging LLM-as-a-Judge: Concerning Rubric Artifacts* (Bagaria, Sundaram, Krishnan, Ravindran) | "**Classifiers trained only on rubric text, without access to any evaluated response, achieve nontrivial predictive performance on judge outputs**" — the rubric itself leaks score signal independent of the thing being judged |
| 2602.02219v3 · *Position Bias in Rubric-Based LLM-as-a-Judge* | rubric **ordering** biases outcomes; "only a small number of random order permutations are sufficient to reduce the error introduced by this bias for majority of models" |
| 2604.06996v3 · *Self-Preference Bias in Rubric-Based Evaluation* (Pombal, Rei, Martins) | "on HealthBench, a medical chat benchmark with **subjective** rubrics, SPB skews model scores by **up to 10 points**" |
| 2506.22316v4 · *Evaluating Scoring Bias* | taxonomy of rubric-specific biases: rubric order, score ID, reference answer bias |
| 2606.04923v2 · *Reward Hacking in Rubric-Based RL* | rubric-based judges are reproducibly gameable (CHERRL) |

**Reading for the PoC.** E0→E1 gains are real and sometimes large on *inter-judge agreement* (7/16 → 16/16 is the cleanest datapoint located), but the rubric is itself an artifact that carries bias and can be gamed. Any E1 result should be reported alongside a position-permutation control (2602.02219v3's finding that a few permutations suffice makes this cheap) and a check that the rubric text alone does not predict the score (2609.02942v1's test).

---

## 3.2 E1 → E2: structured external knowledge in context

The cleanest located datapoint is **2603.11027v1**, above: knowledge-anchored rubrics vs generic rubrics gave **+22% (Education) and +27% (Academic)** agreement, with the authors attributing the gain to domains being "codified" — i.e. where external knowledge exists to anchor to.

This is the most direct E1→E2 evidence found. It is a single paper, abstract-only. **A dedicated, independent E1-vs-E2 ablation on a social/pragmatic reasoning task: NOT FOUND AFTER DEFINED SEARCH** (queries: `all:"LLM-as-a-judge" AND all:"rubric"`; `abs:"knowledge graph" AND abs:"large language model" AND abs:"ablation"` — the latter returned HTTP 429 and was replaced by `abs:"knowledge graph" AND abs:"retrieval-augmented" AND abs:"baseline"`; endpoint `export.arxiv.org/api/query`).

---

## 3.3 E3 → E4: vector RAG vs knowledge-graph RAG

### The anchor paper

**Edge, Trinh, Cheng, Bradley, Chao, Mody, Truitt, Metropolitansky, Ness, Larson — "From Local to Global: A Graph RAG Approach to Query-Focused Summarization", arXiv 2404.16130** (v1 2024-04-24, v2 2025-02-19). **[ABSTRACT ONLY]**

Abstract, verbatim on the claim:
> "For a class of global sensemaking questions over datasets in the 1 million token range, we show that GraphRAG leads to **substantial improvements over a conventional RAG baseline for both the comprehensiveness and diversity** of generated answers."

Read the scope carefully: the claim is for **global sensemaking / query-focused summarization** over ~1M-token corpora, on **comprehensiveness and diversity** judged by an LLM — not for per-item factual labelling, and **no numeric effect size appears in the abstract.** The paper's own framing is that conventional RAG "fails on global questions directed at an entire text corpus."

### Independent and critical evaluations — this is the important body

Query: `all:"GraphRAG" AND all:"evaluation"`, endpoint `export.arxiv.org/api/query`, 10 entries examined. All **[ABSTRACT ONLY]**.

| arXiv | Title | Finding, verbatim |
|---|---|---|
| **2603.29875v3** | *UnWeaving the knots of GraphRAG — turns out VectorRAG is almost enough* (Tuora, Galiński, Godziszewski, Karpowicz, Czyżnikiewicz, Kozakiewicz, Ziętkiewicz) | "on end to end QA evaluation **VectorRAG performs better than standard GraphRAG and almost as good as current SOTA graph-based solutions, for a fraction of the cost**"; GraphRAG carries "orders of magnitude increased componential complexity" |
| **2506.06331v2** | *How Significant Are the Real Performance Gains? An Unbiased Evaluation Framework for GraphRAG* (Zeng et al.) | "their **performance gains are much more moderate than reported previously**"; the standard answer-evaluation framework "has two critical flaws...which may lead to biased or even wrong conclusions" |
| **2506.05690v3** | *When to use Graphs in RAG* (Xiang et al.) | "recent studies report that **GraphRAG frequently underperforms vanilla RAG on many real-world tasks**"; asks "Is GraphRAG really effective, and in which scenarios do graph structures provide measurable benefits?" |
| **2604.09666v1** | *Do We Still Need GraphRAG? Benchmarking RAG and GraphRAG for Agentic Search Systems* (Fan, Xue, Liu, Tan) | "**agentic search substantially improves dense RAG and narrows the performance gap to GraphRAG**"; "can agentic search compensate for the absence of explicit graph structure, reducing the need for costly GraphRAG pipelines?" |
| **2606.25656v1** | *Is GraphRAG Needed? From Basic RAG to Graph-/Agentic Solutions with Context Optimization* (Chen et al.) | "**retrieval-generation gap** where expanded retrieval does not proportionally improve generation quality, suggesting **retrieval-oriented metrics overstate advanced retrieval benefits**"; 19%–53% token reduction via context optimization |
| **2502.11371v3** | *RAG vs. GraphRAG: A Systematic Evaluation and Key Insights* (Han et al., 12 authors) | "results highlight the **distinct strengths of RAG and GraphRAG across different tasks**" — neither dominates universally; combining them gives "consistent performance improvements" |
| 2506.02404v3 | *GraphRAG-Bench* (Xiao et al.) | evaluates 9 GraphRAG methods; no explicit vector-RAG baseline in the abstract |
| 2504.02112v2 | *PolyG* | "existing GraphRAG methods **fall short in effectiveness...and/or efficiency** because they adopt either a fixed graph traversal strategy" |
| 2507.03226v3 | *Towards Practical GraphRAG* (Min et al.) | positive but **modest**: "improvements of **up to 15% and 4.35%** over vanilla vector retrieval baselines"; dependency parsing reaches "94% of LLM-based performance" at lower cost |
| 2603.05207v2 | *Core-based Hierarchies for Efficient GraphRAG* | "consistently improves answer comprehensiveness and diversity while reducing token usage" |

### Contrast: method papers reporting their own gains

Query: `abs:"knowledge graph" AND abs:"retrieval-augmented" AND abs:"baseline"`, 8 entries. All **[ABSTRACT ONLY]**, all reporting *their own* system beating baselines:

- **2504.09823v1 (RAKG):** "RAKG achieves an accuracy of **95.91%** on the MINE dataset, a **6.2 percentage point** improvement over the current best baseline, GraphRAG (89.71%)" — note the baseline beaten here is GraphRAG, on KG *construction*.
- **2606.15971v2 (SAG):** "On MuSiQue... SAG reaches **80.36% Recall@5, outperforming the strongest baseline by 11.52 points**."
- **2601.05254v3 (TagRAG):** "average winning rate of **78.36%** against baselines while maintaining about **14.6× construction and 1.9× retrieval efficiency** compared with GraphRAG."
- 2508.09460v1 (MetaKGRAG), 2508.18260v2 (MIRAGE), 2504.01309v1, 2510.15339v3, 2603.05698v2 — qualitative superiority claims, no isolated numbers in abstracts.

---

## 3.4 Answers to the three questions posed

**Q1: What effect sizes are typically reported between prompt-only and external-structure conditions?**

There is **no stable typical effect size**, and reporting one would be fabrication. The retrieved numbers do not share a metric, task, or baseline. What can be said honestly:

- The largest clean prompt-structure effect located is an **inter-judge agreement** effect, not an accuracy effect: **7/16 → 16/16 rank agreement** (2605.01630v1).
- Rubric-vs-raw judgment improvement of **15.55%** and knowledge-anchoring gains of **+22%/+27%** are reported, all abstract-only, all single-source, all on different metrics.
- On the retrieval side, the *independently evaluated* delta between vector RAG and GraphRAG is repeatedly characterised as small, task-dependent, or absent; the one head-to-head number from a pro-GraphRAG method paper is "**up to 15% and 4.35%**" over vanilla vector retrieval (2507.03226v3) — and that is the favourable framing.
- The strongest cross-cutting empirical regularity is **shrinkage on independent re-evaluation**: 2506.06331v2 states gains "are much more moderate than reported previously," and 2606.25656v1 states "retrieval-oriented metrics overstate advanced retrieval benefits."

**Q2: Has anyone shown prompt-only matching KG-based retrieval?**

Not prompt-only *with no retrieval at all* — that specific comparison was **NOT FOUND AFTER DEFINED SEARCH** (queries in §3.3; endpoint `export.arxiv.org/api/query`).

But the adjacent and arguably more useful result is established repeatedly: **the simpler retrieval condition matches or beats the knowledge-graph condition.**
- 2603.29875v3: "VectorRAG performs better than standard GraphRAG and almost as good as current SOTA graph-based solutions, for a fraction of the cost."
- 2506.05690v3: "GraphRAG frequently underperforms vanilla RAG on many real-world tasks."
- 2604.09666v1: agentic dense RAG "narrows the performance gap to GraphRAG."

For an E0–E4 ablation this is the key design implication: **E4 must be defended against E3, not only against E0**, and the burden of proof sits with E4.

**Q3: Microsoft GraphRAG paper and critical/negative results — included?**

Yes. Anchor paper §3.3 (arXiv 2404.16130). Six independent critical/negative evaluations catalogued above: 2603.29875v3, 2506.06331v2, 2506.05690v3, 2604.09666v1, 2606.25656v1, 2502.11371v3.

---

## 3.5 Design note for the PoC's E0–E4 ablation

Drawn from the retrieved literature, not invented:

1. **Report E3 as a first-class condition, not a formality.** The independent literature's dominant finding is that E4's margin over E3 shrinks or vanishes under unbiased evaluation (2506.06331v2, 2506.05690v3, 2603.29875v3).
2. **Report cost alongside accuracy.** 2603.29875v3 ("a fraction of the cost"), 2601.05254v3 (14.6× construction cost), 2606.25656v1 (19–53% token reduction) all make cost the deciding variable when accuracy deltas are small.
3. **Do not evaluate E0–E4 with an unaudited LLM judge.** 2506.06331v2 identifies "two critical flaws" in the standard GraphRAG answer-evaluation framework that "may lead to biased or even wrong conclusions." Given the PoC's own judge-reliability numbers, this risk is live.
4. **Add two cheap controls to any E1+ condition:** position permutation (2602.02219v3 — a few permutations suffice) and the rubric-alone leakage probe (2609.02942v1 — can a classifier predict the score from rubric text alone, with no response?).
5. **Separate retrieval metrics from generation metrics.** 2606.25656v1's "retrieval-generation gap": better retrieval scores did not proportionally improve generation quality.

---

# APPENDIX — ENDPOINTS USED

- `https://ar5iv.labs.arxiv.org/html/<ID>` — full text HTML (Dorner, 3 passes) — **only FULL-TEXT arXiv source used**
- `https://arxiv.org/abs/<ID>` — metadata + abstract
- `http://export.arxiv.org/api/query?search_query=...` — Atom search (one call returned HTTP 429 and was reissued with a modified query)
- `https://www.ebi.ac.uk/europepmc/webservices/rest/search?query=...&format=json&resultType=core`
- `https://www.ebi.ac.uk/europepmc/webservices/rest/PMC<ID>/fullTextXML` — **FULL TEXT, Ste-Marie 2011**
- `https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi` — attempted, returned truncated rendering
- `https://openreview.net/forum?id=...` — blocked by bot-verification interstitial
- `https://europepmc.org/abstract/MED/26301396` — returned navigation chrome only

WebSearch was **not** used (quota exhausted at 200/200 per instruction).
