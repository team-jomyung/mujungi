# EVIDENCE LEDGER · 상태

2026-09-14

**`EVIDENCE_LEDGER.csv` 는 네 번째 시도에서 만들었다.** 앞선 세 번은 계정 지출 한도로 중단됐다.
가장 중요한 두 값(AMP · PRS-SA)의 대조가 끝났고 결과가 갈렸다. **검색 기록은 `EVIDENCE_LEDGER_SEARCH_LOG.md`.**

| 준거 | 결과 | 뜻 |
|---|---|---|
| AMP κ .712 / .715 | **NOT FOUND AFTER DEFINED SEARCH** | Collins 2014 초록에 계수가 없고 전문이 유료 장벽이다. **인용에서 뺀다** |
| AMP κ **.783** (Adams 2018) | **전문 확인** · 비가중 Cohen κ | 통계 종류는 맞다. 다만 채점 지침 대조 과제라 우리 과제와 모양이 다르다 |
| PRS-SA 가중 κ **.831** (Dillon 2021) | **전문 확인 · 값 일치** | **직접 비교 불가.** 7점 가중 κ · 1점 허용 · 평균이고 **하한 .4917** |
| PRS-SA 4영역 23+5문항 | **전문 확인 · 값 일치** | 구성 기술. 문턱과 무관 |
| Swineford "19 행동" | **다른 도구였다** | 성인용 PRS(Landa 1992). 모순이 아니었다 |

**결론 · 문턱 0.6 에 모양이 같은 외부 준거는 없다.** 규범 근거로 남는 것은 McHugh 2012 뿐이다.
0.6 은 계속 **PROJECT OPERATING THRESHOLD** 로 적는다. `STATISTICAL_DESIGN.md` · `A1_PROTOCOL.md` 에 반영했다.

아래 표의 나머지 항목은 여전히 미대조다.

---

## 1 · 그래서 지금 대조된 것과 안 된 것

**대조가 끝난 것** · 이번 스프린트에서 문서를 쓰면서 원자료와 직접 맞춰 본 수치.

| 수치 | 대조 결과 | 어디서 |
|---|---|---|
| Parsons 2017 "None of the included studies targeted children aged 13-18 years" | 전문 확인 · 연령 상한 미설정 | `AGE_EVIDENCE.md` §4 |
| Dorner τ ≤ 2 · Corollary 7 가정 · uniform sampling · Theorem 5 적용범위 | 전문 3회 확인 | `THEOREM_AND_PRECEDENT.md` §1 |
| Ste-Marie 2011 "always show the most successful behaviors" · 17건 중 0 | 전문 확인 | 같음 §2.7 |
| Jung 2024 · 보정셋 500 · 0.90에서 55.7% · 0.85에서 63.2% · ECE 0.215~0.217 | 전문 확인 | `agent_llm_judge.md` C3 |
| Bayerl & Paul · 81% 대 70% (p=.002) · 전문성 n.s. | 전문 확인 | 같음 D3 |
| McHugh 2012 "below 0.60 indicates inadequate agreement" | 전문 확인 | 같음 D2 |
| Artstein & Poesio "black art" | 전문 확인 | 같음 D2 |
| DSM-5 A3 "rephrasing when misunderstood" | Swineford 2014 전문 | `_agent_pragmatics_review.md` §1.1 |
| Saul 2023 0~1.3% / 6.1~10.5% | 초록 verbatim | `agent_scd_census.md` Row 11 |
| Yuan & Dollaghan 594 → 206 · κ .69~.76 | 초록 · **Gabbatore 2023 의 220 과 불일치 · 206 사용** | 같음 Row 1 |
| TOPICC 7범주 17문항 대 "12 aspects" | **두 출처가 다른 것을 센다** · 17문항은 2011 양식 · 12는 Lockton 2016 이 부호화한 수 | `AMP_TOPICC_검증.md` |
| A1 시뮬레이션 · 40쌍 κ0.7 → 0.175 · 60쌍 κ0.8 → 0.795 | `A1_SAMPLE_SIZE_RESULTS.json` 재실행 · **옛 판 값(0.13 · 0.81)을 인용하고 있었다. ERR-06** <!-- numcheck-ok 고치기 전 값을 기록으로 인용 --> | 이번 스프린트 |
| KG ablation · POC B dry-run 수치 | 이번에 직접 실행 | 이번 스프린트 |

**대조가 안 된 것** · 문서에 있으나 이번에 원문과 맞춰 보지 못한 수치.

| 수치 | 상태 |
|---|---|
| ~~AMP κ .712 / .715~~ | **대조 끝 · NOT FOUND.** 1차 출처에 없다. 인용에서 뺐다 |
| ~~PRS-SA 가중 κ .831 · 4영역 23+5문항~~ | **대조 끝 · 값 일치.** Swineford 의 19 는 다른 도구였다. 단 가중 κ 라 직접 비교 불가 |
| JUDGE-BENCH κ 0.28 | **미대조** · 2차 인용 |
| LLM 편향 수치 (자기인식 73.5% · 자기선호 0.705~0.912 · 교사→학생 19~22%) | **미대조** |
| Gates 2017 g=1.15 / 0.28 | **미대조** · `SCD_문헌.md` 경유 |
| Parsons 2017 g=0.500 · 0.274 · 21건 925명 | **미대조** |
| NDTx-01 p=0.037 · 39/38 | **미대조** · 초록 인용 |
| Carruthers 2025 n=248 · PACT-G −0.04 p=0.734 · VIPP-SD d=−0.11 | **미대조** |
| 3i4K 총량 · KoCoSa 12,824 · 간접화행 240 · 화용 평가셋 120 | **미대조** (2026-09-11 조사 기록) |
| EMA 1,577 / 16 / 15 | 에이전트 자체 검색 수치 · **재현 안 됨** |

---

## 2 · 이것이 바꾸는 것

**바꾸지 않는 것** · 이번 스프린트의 판정 넷은 전부 위쪽(대조 완료) 수치에 걸려 있다.
범위 판정 · 연령 공백 · 표본 크기 · Dorner 적용 · KG 불필요 · POC B 수락 규칙.

**바꾸는 것** · 발표에서 아래 수치를 **인용할 때는 "확인하지 못한 2차 인용"이라고 말한다.**
특히 AMP κ 와 PRS-SA κ 는 우리 문턱 0.6 의 **인접 준거**로 쓰이고 있다. 그 둘이 틀리면 문턱의 근거가 약해진다.

→ `03_AUTOMATION/A1_PROTOCOL.md` 와 `STATISTICAL_DESIGN.md` 의 문턱 근거 문장에 이 사실을 적었다.

---

## 3 · 다시 돌리는 법

계정 한도가 풀리면 `evidence-verifier` 지시문을 그대로 다시 쓴다. 열 구성과 named claim 목록이 지시문에 있다.
**우선순위는 §1 아래 표의 열 줄이다.** 특히 AMP · PRS-SA · JUDGE-BENCH 셋.
