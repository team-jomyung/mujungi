# -*- coding: utf-8 -*-
"""SOURCE_TABLE.csv · FINAL_CLOSURE 가 인용하는 출처 한 장. SCD census 에 방법 · 판정자 · 법령 · 경쟁 출처를 더한다.

    python build_source_table.py      (build_evidence_tables.py 를 먼저 돌린다)
"""
import csv
import io
import os

HERE = os.path.dirname(os.path.abspath(__file__))

# id, citation, identifier, tier, depth, used_in
METHOD = [
    ('X-DOR', 'Dorner, Nastl & Hardt 2025 · LLM as judge won\'t beat twice the data (ICLR)', 'arXiv 2410.13341', 'METHOD', 'FULL', 'A2_PROTOCOL §8 · THEOREM_AND_PRECEDENT Part 1'),
    ('X-JUN', 'Jung, Brahman & Choi 2024 · Trust or Escalate', 'arXiv 2407.18370', 'METHOD', 'FULL', 'A2 라우팅 · ROUTING_POLICY_REPORT'),
    ('X-ZHE', 'Zheng et al. 2023 · Judging LLM-as-a-judge (MT-Bench)', 'arXiv 2306.05685', 'METHOD', 'ABSTRACT', 'judge_harness 양방향 질의'),
    ('X-VER', 'Verga et al. 2024 · Panel of LLM evaluators (PoLL)', 'arXiv 2404.18796', 'METHOD', 'ABSTRACT', '판정단 계열 분리'),
    ('X-PAN', 'Panickssery et al. 2024 · LLM evaluators recognize and favor their own generations', 'arXiv 2404.13076', 'METHOD', 'ABSTRACT', '생성 모델 판정단 제외'),
    ('X-XIO', 'Xiong et al. 2024 · Can LLMs express their uncertainty?', 'arXiv 2306.13063', 'METHOD', 'ABSTRACT', '말로 표현한 확신 과신'),
    ('X-TIA', 'Tian et al. 2023 · Just ask for calibration', 'arXiv 2305.14975', 'METHOD', 'ABSTRACT', '반대 결과'),
    ('X-GEI', 'Geifman & El-Yaniv 2017 · Selective classification', 'arXiv 1705.08500', 'METHOD', 'ABSTRACT', '위험-적용범위'),
    ('X-KAM', 'Kamath, Jia & Liang 2020 · Selective QA under domain shift', 'arXiv 2006.09462', 'METHOD', 'ABSTRACT', '보정기'),
    ('X-SET', 'Settles 2009 · Active learning literature survey', 'UW-Madison TR 1648', 'METHOD', 'FULL', '능동학습 절감 수치 NOT ESTABLISHED'),
    ('X-LIC', 'Li et al. 2023 · CoAnnotating', 'arXiv 2310.15638', 'METHOD', 'FULL', '미묘한 과제에서 위임은 품질을 떨어뜨림'),
    ('X-PPI', 'Angelopoulos et al. 2023 · Prediction-powered inference', 'arXiv 2301.09633', 'METHOD', 'ABSTRACT', 'Dorner 정리 안에 있음'),
    ('X-BOY', 'Boyeau et al. 2024 · AutoEval done right', 'arXiv 2403.07008', 'METHOD', 'ABSTRACT', '유효 표본 +50% 까지'),
    ('X-CHA', 'Chaganty, Mussman & Liang 2018 · Price of debiasing automatic metrics', 'arXiv 1807.02202', 'METHOD', 'ABSTRACT', '절감 7-13%'),
    ('X-JBN', 'JUDGE-BENCH (Bavaresco et al.) · LLMs instead of human judges?', 'CLOSURE_RESEARCH L-3 참조 · EVIDENCE_LEDGER 대조', 'METHOD', 'SECONDARY', '주관 과제 κ 0.28'),
    ('X-BAY', 'Bayerl & Paul 2011 · What determines inter-coder agreement', 'doi 10.1162/COLI_a_00074', 'METHOD', 'FULL', 'A1 판정자 설계 · 훈련 81% 대 70%'),
    ('X-ART', 'Artstein & Poesio 2008 · Inter-coder agreement for CL', 'doi 10.1162/coli.07-034-R2', 'METHOD', 'FULL', '문턱은 black art · 혼동행렬 보고'),
    ('X-MCH', 'McHugh 2012 · Interrater reliability: the kappa statistic', 'doi 10.11613/BM.2012.031 PMC3900052', 'METHOD', 'FULL', 'κ 0.60 미만 부적절'),
    ('X-LAN', 'Landis & Koch 1977 · Measurement of observer agreement', 'doi 10.2307/2529310', 'METHOD', 'SECONDARY', 'κ 구간 관례'),
    ('X-TRA', 'Tractenberg et al. 2010 · Training to a kappa criterion (CDR)', 'PMC2924444', 'METHOD', 'METADATA', 'A1 훈련 참조점'),
    ('X-BUJ', 'Bujang & Baharum 2017 · Minimum sample size for kappa', 'doi 10.2427/12267', 'METHOD', 'METADATA', '표본 참조 · 인용 비권장'),
    ('X-HRI', 'Hripcsak & Rothschild 2005 · Agreement, F-measure, reliability', 'PMID 15684123', 'METHOD', 'FULL', '구간형 라벨은 F'),
    ('X-KRA', 'Krasny-Pacini et al. 2013 · GAS in rehabilitation', 'PMID 23562111', 'METHOD', 'ABSTRACT', '서열 점수 평균 금지'),
    ('X-EDG', 'Edge et al. 2024 · From local to global: GraphRAG', 'arXiv 2404.16130', 'METHOD', 'ABSTRACT', 'E4 기준 논문'),
    ('X-UNW', 'Tuora et al. 2026 · VectorRAG is almost enough', 'arXiv 2603.29875', 'METHOD', 'ABSTRACT', 'E4 는 E3 를 이겨야'),
    ('X-UNB', 'Zeng et al. 2025 · Unbiased evaluation of GraphRAG', 'arXiv 2506.06331', 'METHOD', 'ABSTRACT', '이득이 완만'),
    ('X-WHE', 'Xiang et al. 2025 · When to use graphs in RAG', 'arXiv 2506.05690', 'METHOD', 'ABSTRACT', 'GraphRAG 가 자주 짐'),
    ('X-AGT', 'Fan et al. 2026 · Do we still need GraphRAG?', 'arXiv 2604.09666', 'METHOD', 'ABSTRACT', '에이전트 검색이 격차 좁힘'),
    ('X-GAP', 'Chen et al. 2026 · Is GraphRAG needed?', 'arXiv 2606.25656', 'METHOD', 'ABSTRACT', '검색-생성 격차'),
    ('X-RVG', 'Han et al. 2025 · RAG vs GraphRAG systematic evaluation', 'arXiv 2502.11371', 'METHOD', 'ABSTRACT', '과제별 강점'),
    ('X-RUB', 'Bagaria et al. 2026 · Concerning rubric artifacts', 'arXiv 2609.02942', 'METHOD', 'ABSTRACT', 'rubric-only 누출 통제'),
    ('X-POS', 'Position bias in rubric-based LLM-as-a-judge 2026', 'arXiv 2602.02219', 'METHOD', 'ABSTRACT', '위치 순열 통제'),
    ('X-PRO', 'Prosa benchmark 2026 · rubric vs holistic', 'arXiv 2605.01630', 'METHOD', 'ABSTRACT', 'E0 → E1 순위 일치 7/16 → 16/16'),
    ('X-ANC', 'Beyond the illusion of consensus 2026', 'arXiv 2603.11027', 'METHOD', 'ABSTRACT', 'E1 → E2 +22/+27%'),
    ('Y-BRL', 'Brown & Levinson 1987 · Politeness', 'doi 10.1017/cbo9780511813085', 'GENERAL', 'METADATA', 'RELATIONSHIP_SCOPE'),
    ('Y-HOL', 'Holtgraves & Yang 1992 · Request strategies culture gender (Korean)', 'PMID 1556657', 'GENERAL', 'ABSTRACT', 'P·D·R 상호작용 · 한국 표본'),
    ('Y-KIM', 'Kim Kyu-hyun 2024 · Request for confirmation sequences in Korean', 'doi 10.1515/opli-2024-0010', 'GENERAL', 'ABSTRACT', '한국어 완화 확인'),
    ('Y-KWS', 'Kwon & Sturt 2024 · Processing of honorifics in Korean', 'PMID 39116506', 'GENERAL', 'ABSTRACT', '존대 문법화'),
    ('Y-DIN', 'Dingemanse et al. 2015 · Universal principles in repair', 'doi 10.1371/journal.pone.0136100', 'GENERAL', 'FULL', '수리 형식 셋'),
    ('Y-SVE', 'Svennevig 2008 · Trying the easiest solution first', 'doi 10.1016/j.pragma.2007.11.007', 'GENERAL', 'METADATA', '수리 틀 선호'),
    ('Y-MCH', 'McHoul 1990 · Repair in classroom talk', 'doi 10.1017/s004740450001455x', 'GENERAL', 'ABSTRACT', '자리가 수리 구조를 바꿈'),
    ('Y-LIN', 'Linde 1988 · Politeness and accidents in aviation discourse', 'doi 10.1017/s0047404500012951', 'GENERAL', 'ABSTRACT', '윗사람 완화 · 과업 위험'),
    ('Y-KIR', 'Kiresuk & Sherman 1968 · Goal attainment scaling', 'PMID 24185570', 'GENERAL', 'ABSTRACT', 'D2 목표'),
    ('Y-TUR', 'Turner-Stokes 2009 · GAS practical guide', 'PMID 19179355', 'GENERAL', 'ABSTRACT', 'D2'),
    ('Y-BUD', 'Budgett et al. 2024 · Personalised goals in dementia', 'PMC11247364', 'GENERAL', 'ABSTRACT', '자유 목표 31% 가 범주 밖 · C-12'),
    ('Y-ANG', 'Angeli et al. 2019a · Documented vs caregiver goals', 'PMC6708649', 'GENERAL', 'ABSTRACT', '일치 -0.03'),
    ('Y-LEV', 'Levack et al. 2011 · Goal setting in stroke rehab', 'PMID 21306859', 'GENERAL', 'ABSTRACT', '임상가 선호 목표'),
    ('Y-STA', 'Staunton et al. 2025 · GAS for paediatric autism trials', 'PMC12618709', 'ADJACENT_ASD_DLD', 'FULL', '혼합형 목표'),
    ('Z-PAR', 'Parsons et al. 2017 (see R04)', 'doi 10.1371/journal.pone.0172242', 'ADJACENT_ASD_DLD', 'FULL', '13-18 공백 인용'),
    ('Z-STE', 'Ste-Marie et al. 2011 · Video self-modeling', 'PMC (THEOREM_AND_PRECEDENT §2.7)', 'ADJACENT_ASD_DLD', 'FULL', 'VSM 은 성공 장면만'),
    ('Z-PCT', 'PACT · PACT-G · VIPP-SD · Carruthers 2025', 'THEOREM_AND_PRECEDENT §2.4', 'ADJACENT_ASD_DLD', 'MIXED', '영상 피드백 계열'),
    ('L-PIPA', '개인정보 보호법 §2 · §15 · §18 · §21 · §22의2 · §23 · §28의2~7 · §36 · §37의2 · §58의2', '국가법령정보센터 API', 'LAW', 'FULL', '08_ETHICS'),
    ('L-BIO', '생명윤리법 §2 · §15 · §16 · 시행규칙 §2 · §13 · §14 · §15', '국가법령정보센터 API', 'LAW', 'FULL', '08_ETHICS'),
    ('L-MED', '의료기기법 §2 · §24 · §26 · 디지털의료제품법 §2', '국가법령정보센터 API', 'LAW', 'FULL', '효능 문구'),
    ('L-PIPC', '개인정보보호위원회 제2021-007-072호', 'PIPC 처분례', 'LAW', 'FULL', '대화데이터 AI 개발 목적 외 이용'),
    ('C-NDT', 'Yoo et al. 2025 NDTx-01 (see M08)', 'CRIS KCT0009140', 'MIXED', 'ABSTRACT', '09_PRIOR_ART'),
    ('C-AAC', 'Choi et al. 2025 AACessTalk (CHI)', 'arXiv 2409.09641', 'ADJACENT_ASD_DLD', 'ABSTRACT', '09_PRIOR_ART'),
    ('C-SOC', 'Lian et al. 2026 SocialCoach', 'arXiv 2606.04155', 'GENERAL', 'ABSTRACT', '09_PRIOR_ART'),
    ('C-AUT', 'arXiv 2507.21077 · autism framed as deficit of neurotypical social skills', 'arXiv 2507.21077', 'GENERAL', 'ABSTRACT', 'INSTRUCTOR_QA 51'),
]


def main():
    rows = []
    with io.open(os.path.join(HERE, 'SCD_STUDY_CENSUS.csv'), encoding='utf-8') as f:
        for r in csv.DictReader(f):
            rows.append([r['source_id'], '%s %s · %s' % (r['authors'], r['year'], r['title']), r['identifier'],
                         r['bucket'], r['fulltext_or_abstract'], r['source_file']])
    rows += [list(m) for m in METHOD]
    with io.open(os.path.join(HERE, 'SOURCE_TABLE.csv'), 'w', encoding='utf-8', newline='') as f:
        w = csv.writer(f)
        w.writerow(['source_id', 'citation', 'identifier', 'tier_or_bucket', 'reading_depth', 'used_in'])
        w.writerows(rows)
    from collections import Counter
    print('SOURCE_TABLE rows', len(rows), dict(Counter(r[4] for r in rows)))


if __name__ == '__main__':
    main()
