# E0 ~ E4 PROTOCOL · "그냥 GPT 에 넣어도 되지 않나"

2026-09-13 · O 워크스트림. 다섯 조건을 같은 test set 에서 비교한다.
**입증 책임은 구조를 더한 쪽에 있다.** E4 는 E0 가 아니라 **E3 를 이겨야** 한다.

---

## 1 · 다섯 조건

| 조건 | 무엇 | 외부 자원 | 구현 |
|---|---|---|---|
| **E0** | plain LLM. 두 상황 + 질문 | 없음 | `scoring/arms.py::E0` |
| **E1** | LLM + 규격 rubric 을 프롬프트에 | 없음 (프롬프트 안) | `E1` · `judge_harness.build_prompt` 와 같은 rubric |
| **E2** | LLM + 외부 온톨로지에서 꺼낸 **구조화 문맥** (해당 필드의 정의 · 값 영역 · 판정 규칙을 JSON 으로) | 온톨로지 파일 (조회 · 검색 아님) | `E2` · `decision_rules_machine_readable.json` 조회 |
| **E3** | **Vector RAG.** 규격 · 지침 · 씨앗 장면을 청크로 색인하고 유사 청크를 문맥으로 | 벡터 색인 | `E3` · bag-of-words 자리 · 임베딩 모델은 `_vec` 만 교체 |
| **E4** | **Ontology/KG + 그래프 검색.** 필드 → 판정 규칙 → 씨앗 장면 경로를 따라 문맥 구성 | 그래프 | `E4` · 경로를 meta.path 로 출력 |

모든 조건에서 **같은 모델 · 같은 test set · 같은 출력 스키마 · 같은 판정 함수**다. 다른 것은 문맥만이다.

---

## 2 · 과제

A2 와 같은 과제다. **두 상황을 읽고 Core 필드 셋(required_inference · perspective_structure · decidable_by_evidence)이 같은지 판정.**
gold 는 A1 사람 합의. 그래서 **E0~E4 는 A1 뒤에만 돌릴 수 있다.**

A2 는 "판정단이 사람을 재현하나", E0~E4 는 "**어떤 문맥 구성이** 재현을 높이나". 같은 harness 를 쓰고 arm 만 바꾼다.

---

## 3 · 지표

| 지표 | 정의 | 어디서 |
|---|---|---|
| accuracy · macro F1 · κ | gold 대비 · 필드별 | `judge_harness.analyze` 재사용 |
| **evidence precision / recall** | 판정이 댄 `evidence_span` 과 gold 근거 구간의 겹침 | gold 에 `evidence_span_A/B` 열 필요 · A1 양식 확장 (C-09) |
| **unsupported inference rate** | 라벨은 냈는데 `evidence_span` 이 비었거나 원문에 없는 비율 | `scoring/run_ablation.py` |
| **path validity** (E4 만) | 경로의 연속 노드 사이에 실제 간선이 있는 비율 | `arms.path_validity` |
| **consistency** | paraphrase 섭동 전후 라벨 일치율 | `bias_tests.perturbations.paraphrase` 재사용 |
| **abstention** | UNKNOWN 비율 · UNKNOWN 이 gold UNKNOWN 과 맞는 비율 | 혼동행렬 |
| **latency** | 문맥 구성 ms · 모델 ms · 각 p95 | `run_ablation.py` |
| **cost** | 입력 토큰 중앙값 · 호출 수/판정 · 색인 구축 비용(1회) | 같음 · `COST_LATENCY_PLAN.md` |

**retrieval 지표와 generation 지표를 분리한다.** E3/E4 의 검색 hit rate 가 좋아도 판정 정확도가 안 오르면 검색이 좋아진 것이지 판정이 좋아진 것이 아니다 (arXiv 2606.25656 "retrieval-generation gap").

---

## 4 · 판정 규칙 · 미리 정한다

| 관측 | 결론 |
|---|---|
| **E1 ≈ E2** (필드별 κ 분포가 겹침) | **"외부 온톨로지 DB 가 필수"라는 주장이 약해진다.** 규격을 프롬프트에 넣는 것으로 충분하다 |
| E2 > E1 | 구조화 문맥이 이득. 다만 그것이 DB 여야 하는지는 별개다. E2 는 파일 조회로 된다 |
| **E4 ≤ E3** | **그래프 정당화 실패.** E3 로 간다. GATE 8 = 아키텍처 단순화 |
| E4 > E3 **그리고** path validity 높음 **그리고** 입력 토큰이 E3 의 2배 이내 | 그래프 정당화 |
| E4 > E3 인데 path validity 낮음 | 이득이 그래프 구조에서 온 것이 아니다. 문맥 길이 등 다른 요인. 정당화 안 됨 |
| E0 ≈ E1 | rubric 이 효과 없음. **rubric-only 누출 검사**(§5)를 먼저 의심 |

"유의"의 기준 · **held_out 에서 repeated holdout k=10 의 κ 분포가 겹치지 않을 때.** p 값 하나로 정하지 않는다. **PROJECT OPERATING RULE.**

---

## 5 · 반드시 붙이는 통제 둘

| 통제 | 왜 | 어떻게 |
|---|---|---|
| **위치 순열** | rubric 항목 순서가 판정을 바꾼다 (arXiv 2602.02219) | `E1(order=...)` 로 rubric 순서 3종 · 분산 보고. 몇 개 순열로 충분하다는 것이 그 논문의 결과 |
| **rubric-only 누출** | rubric 문구만 보고 응답 없이도 점수가 예측된다 (arXiv 2609.02942) | **두 상황을 비운 채** rubric 만 주고 판정시킨다. 라벨 분포가 gold 분포와 상관 있으면 rubric 이 답을 새고 있다 |

두 통제는 E1 이상 모든 조건에 붙는다. E0 에는 rubric 이 없으므로 해당 없다.

---

## 6 · 문헌이 미리 말해 주는 것

`../01_EVIDENCE/THEOREM_AND_PRECEDENT.md` Part 3.

| 비교 | 문헌 | 우리 기대치 |
|---|---|---|
| E0 → E1 | 판정자 간 순위 일치 7/16 → 16/16 (arXiv 2605.01630) · rubric 대 raw +15.55% (2504.17087) | **rubric 이득은 실재.** 다만 rubric 자체가 편향 운반체 |
| E1 → E2 | knowledge-anchored rubric +22%/+27% 일치 (2603.11027 · 단일 논문 · 초록) | 사회·화용 과제에서의 독립 검증 **NOT FOUND AFTER DEFINED SEARCH** |
| E3 → E4 | **독립 평가 6건이 같은 방향.** "VectorRAG 가 표준 GraphRAG 보다 낫고 비용은 일부" (2603.29875) · "이득이 이전 보고보다 훨씬 완만" (2506.06331) | **E4 가 E3 를 이길 것으로 기대하지 않는다.** 이기면 왜인지 path validity 로 확인 |

**전형적 효과 크기는 없다.** 지표 · 과제 · 기준선이 다 달라 하나의 숫자를 적으면 조작이다.

---

## 7 · 지금 할 수 있는 것과 없는 것

| 했다 | 할 수 없다 |
|---|---|
| 다섯 arm 문맥 구성 코드 · provider 추상화 · 지표 · 경로 타당성 · 일관성 · 토큰/지연 기록 | 실제 모델 호출 (벤더 미정 · 키 없음) |
| test set 규격 (`DATASET.md`) · 비용 계획 (`COST_LATENCY_PLAN.md`) | gold (A1 0건) |
| **dry-run** · Echo 모델로 다섯 arm 이 같은 스키마로 나오는지 확인 | 어떤 성능 주장 |

**GATE 8 은 미실행이다.** 이 문서는 실행 절차이고 결과가 아니다.

---

## 8 · 절차

```
A1 gold 확정 → gold_split (held_out 40%) → held_out pair_id 를 색인·그래프에서 제외
  → HTTPModel 에 모델 하나 지정 (다섯 arm 동일)
  → E2 조회 파일 · E3 색인 · E4 그래프 구축 (1회 · 비용 기록)
  → development 로 rubric 순열 3종 · rubric-only 누출 검사
  → held_out 한 번 · 다섯 arm · 지표 전부 · 반복 k=10
  → §4 판정 규칙 → GATE 8
```
