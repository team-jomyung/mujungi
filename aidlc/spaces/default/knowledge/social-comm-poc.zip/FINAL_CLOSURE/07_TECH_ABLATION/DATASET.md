# E0~E4 DATASET

2026-09-13 · 다섯 조건이 공유하는 test set 의 규격. **데이터 자체는 A1 뒤에 생긴다.**

---

## 1 · 단위와 출처

| | 값 |
|---|---|
| 단위 | **pair** (상황 A · 상황 B) × **필드** (셋) = 판정 1건 |
| 출처 | A1 합의 gold 의 **held_out 묶음** (40%). calibration · development 는 쓰지 않는다 |
| 크기 | A1 60쌍 → held_out 24쌍 × 3 = **72 판정** · A1 120쌍 → **144 판정** |
| 반복 | repeated holdout k=10 · 분할마다 다른 held_out |

**72 판정으로 다섯 arm 의 차이를 가르기는 빠듯하다.** 그래서 반복 분할의 분포가 "겹치지 않을 때만 유의"로 정했다.
120쌍이 A2 뿐 아니라 E0~E4 에도 낫다.

---

## 2 · 열 · gold CSV 에 있어야 하는 것

| 열 | 출처 | 필수 | 용도 |
|---|---|---|---|
| pair_id | randomize_pairs | 예 | 분할 · 추적 |
| event_A · event_B | blind / 합성 | 예 | 입력 |
| required_inference · perspective_structure · decidable_by_evidence | A1 합의 (SAME / DIFFERENT / UNKNOWN) | 예 | gold 라벨 |
| **evidence_span_A · evidence_span_B** | A1 판정자가 원문 구간을 복사 | **E0~E4 에 필요 · 현재 양식에 없음** | evidence precision / recall |
| target_skill · relationship_type_A · relationship_type_B | 규칙 / blind 메타 | 권장 | 층별 분해 |
| source (synthetic / blind) | randomization_key (분석자만) | 권장 | 출처별 κ |

**evidence_span 열은 A1 양식에 지금 없다.** 추가하지 않으면 evidence 지표를 낼 수 없다.
→ `annotation_form.csv` 에 `evidence_span_A` · `evidence_span_B` 두 열. 판정자는 "근거로 삼은 원문 구간을 그대로 복사"한다.
**`02_SCOPE/SPEC_V0_2_CANDIDATES.md` C-09.** 판정 규칙을 건드리지 않고 양식만 늘린다.

---

## 3 · 각 arm 이 추가로 받는 것

| arm | 추가 입력 | 크기 (토큰 · 추정) |
|---|---|---|
| E0 | 없음 | 두 상황 ≈ 300~600 |
| E1 | rubric (필드 정의 셋 + 공통 규칙) | +300~600 |
| E2 | 해당 필드의 정의 · 값 영역 · Skill Identity 규칙 절 (JSON) | +300~600 |
| E3 | 상위 k=5 청크 (규격 요약 · 지침 · 씨앗) | +500~1500 |
| E4 | 경로 (필드 → 규칙 → 씨앗 k=3) + 노드 텍스트 | +500~1500 |

**E3 와 E4 의 문맥 길이를 맞춘다.** 길이가 다르면 이득이 구조에서 온 것인지 길이에서 온 것인지 모른다.
`run_ablation.py` 가 arm 별 `tokens_in_median` 을 기록하므로 사후에 확인된다.

---

## 4 · 색인 · 그래프의 재료

| 재료 | 크기 | 라이선스 | E3 | E4 |
|---|---|---|---|---|
| frozen_spec_summary.md | 1장 | 프로젝트 자체 | 청크 | 노드 |
| annotation_guideline_onepage.md | 1장 | 자체 | 청크 | 노드 |
| decision_rules_machine_readable.json | 11KB | 자체 | 청크 | **간선의 원천** (필드 → 규칙) |
| existing_synthetic_20.csv + gold | 20쌍 | 자체 | 청크 | 노드 (씨앗) · **held_out 에 있는 쌍은 제외** |
| frozen_spec_v0_1.html 텍스트 | 약 100KB | 자체 | 선택 | 선택 |
| 3i4K · ToM-Diary 일부 | 선택 | CC-BY-SA-4.0 · 확인 필요 | 선택 | 선택 |

**held_out 쌍이 색인에 들어가면 누출이다.** `arms.E3(..., exclude_pair_ids=...)` 와 `E4(..., exclude_pair_ids=...)` 에 `gold_split` manifest 의 held_out 목록을 넘긴다.

---

## 5 · 합성 test set 으로 먼저 해도 되는 것

A1 전에 배선을 확인하려면 `existing_synthetic_20.csv` 와 `_gold/existing_synthetic_20_SPEC_EXPECTED.csv` 로 돌릴 수 있다.
**단 그 결과는 어떤 보고서에도 성능으로 적지 않는다.** 규격 작성자가 만든 쌍이라 E1 의 rubric 과 상관이 있을 수밖에 없다.

`run_ablation.py` 는 official 이 아니면 출력 맨 위에 `NOT VALIDATION RESULT` 를 박는다.
