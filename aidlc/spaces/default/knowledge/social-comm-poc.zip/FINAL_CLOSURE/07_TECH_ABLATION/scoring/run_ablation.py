# -*- coding: utf-8 -*-
"""E0~E4 실행기. 다섯 arm 을 같은 항목 · 같은 provider 로 돌리고 지표를 한 표로 낸다.

    python run_ablation.py --demo                        Echo provider · 배선 확인
    python run_ablation.py --gold <held_out.csv> ...     실제 provider 를 붙인 뒤

출력 results/e0_e4_report.json
  arm 별 · κ · accuracy · macro F1 · evidence P/R · unsupported rate · abstention · consistency
          · tokens_in 중앙값 · ctx_ms p95 · model_ms p95 · path_validity(E4)

Echo provider 출력은 성능이 아니다. 출력 맨 위에 NOT VALIDATION RESULT 를 박는다.
"""
from __future__ import annotations

import argparse
import io
import json
import os
import random
import statistics
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, '..', '..', '03_AUTOMATION', 'judge_harness'))
sys.path.insert(0, os.path.join(HERE, '..', '..', '03_AUTOMATION', 'bias_tests'))

import arms as A  # noqa: E402
from judge_harness import JUDGED_FIELDS, LABELS, kappa, macro_f1, load_gold  # noqa: E402
import perturbations as P  # noqa: E402


class EchoModel(object):
    """모델 자리. 프롬프트 해시로 라벨. 실제 판정 아님."""
    name = 'echo'

    def call(self, prompt):
        s = json.dumps(prompt, ensure_ascii=False)
        h = sum(ord(c) for c in s) % 100
        lab = 'UNKNOWN' if h < 15 else ('SAME' if h < 60 else 'DIFFERENT')
        span = prompt['situation_1'][:12] if h % 3 else ''
        return {'label': lab, 'confidence': 0.5 + (h % 40) / 100.0, 'reason': 'echo', 'evidence_span': span}


class HTTPModel(object):
    """실제 벤더 호출 자리. 키는 환경변수만. 다섯 arm 에 같은 모델을 쓴다."""
    name = 'http'

    def __init__(self, model, env_key):
        self.model = model
        if not os.environ.get(env_key):
            raise RuntimeError('%s 가 환경변수에 없다. 키를 코드에 넣지 않는다' % env_key)

    def call(self, prompt):
        raise NotImplementedError('벤더 SDK 호출을 팀이 채운다. 출력 스키마는 prompt["output_schema"]')


def evidence_pr(span, gold_spans):
    """판정이 댄 구간과 gold 구간의 문자 겹침으로 P/R. gold 가 없으면 None."""
    if not gold_spans:
        return None, None
    if not span:
        return 0.0, 0.0
    hit = any(span in g or g in span for g in gold_spans if g)
    return (1.0 if hit else 0.0), (1.0 if hit else 0.0)


def p95(xs):
    if not xs:
        return None
    xs = sorted(xs)
    return round(xs[min(len(xs) - 1, int(0.95 * len(xs)))], 2)


def run_arm(arm, items, model, graph=None):
    recs = []
    for it in items:
        for f in JUDGED_FIELDS:
            if f not in it['gold']:
                continue
            built = arm.build(it, f)
            t = time.perf_counter()
            out = model.call(built['prompt'])
            model_ms = (time.perf_counter() - t) * 1000
            # consistency · paraphrase 섭동 후 같은 라벨인가
            pit = P.paraphrase(it)
            out2 = model.call(arm.build(pit, f)['prompt'])
            gold_spans = [it.get('evidence_span_A', ''), it.get('evidence_span_B', '')]
            ep, er = evidence_pr(out.get('evidence_span', ''), [g for g in gold_spans if g])
            recs.append({
                'pair_id': it['pair_id'], 'field': f, 'gold': it['gold'][f],
                'label': out['label'], 'confidence': out.get('confidence'),
                'evidence_span': out.get('evidence_span', ''),
                'unsupported': out['label'] != 'UNKNOWN' and not out.get('evidence_span'),
                'consistent': out['label'] == out2['label'],
                'evidence_p': ep, 'evidence_r': er,
                'tokens_in': built['meta']['tokens_in'], 'ctx_ms': built['meta']['ctx_ms'],
                'model_ms': model_ms,
                'path_validity': A.path_validity(built['meta']['path'], graph) if graph and 'path' in built['meta'] else None,
            })
    return recs


def summarize(recs):
    pairs = [(r['gold'], r['label']) for r in recs]
    decided = [p for p in pairs if p[1] != 'UNKNOWN']
    ev_p = [r['evidence_p'] for r in recs if r['evidence_p'] is not None]
    ev_r = [r['evidence_r'] for r in recs if r['evidence_r'] is not None]
    pv = [r['path_validity'] for r in recs if r['path_validity'] is not None]
    k = kappa(pairs) if len(pairs) > 1 else None
    return {
        'n': len(recs),
        'kappa': round(k, 3) if k is not None else None,
        'accuracy': round(sum(1 for g, p in pairs if g == p) / len(pairs), 3) if pairs else None,
        'macro_f1': round(macro_f1(pairs), 3) if pairs else None,
        'abstention_rate': round(sum(1 for _, p in pairs if p == 'UNKNOWN') / len(pairs), 3) if pairs else None,
        'abstention_correct': round(sum(1 for g, p in pairs if p == 'UNKNOWN' and g == 'UNKNOWN')
                                    / max(1, sum(1 for _, p in pairs if p == 'UNKNOWN')), 3),
        'unsupported_rate': round(sum(1 for r in recs if r['unsupported']) / len(recs), 3) if recs else None,
        'consistency_paraphrase': round(sum(1 for r in recs if r['consistent']) / len(recs), 3) if recs else None,
        'evidence_precision': round(sum(ev_p) / len(ev_p), 3) if ev_p else None,
        'evidence_recall': round(sum(ev_r) / len(ev_r), 3) if ev_r else None,
        'tokens_in_median': statistics.median(r['tokens_in'] for r in recs) if recs else None,
        'ctx_ms_p95': p95([r['ctx_ms'] for r in recs]),
        'model_ms_p95': p95([r['model_ms'] for r in recs]),
        'calls_per_judgement': 2,
        'path_validity_mean': round(sum(pv) / len(pv), 3) if pv else None,
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--gold', default=None)
    ap.add_argument('--demo', action='store_true')
    ap.add_argument('--out', default='results')
    a = ap.parse_args()

    if a.demo or not a.gold:
        rng = random.Random(11)
        items = []
        for i in range(1, 25):
            items.append({'pair_id': 'P%02d' % i,
                          'event_A': '친구가 "이번 주말에 다 같이 보드게임 하는데 너도 올래?"라고 했다. 나는 가고 싶지 않아서 그날 좀 봐야 할 게 있다고 말했다.',
                          'event_B': '선배가 "이번 MT 다 오는 거지?"라고 했다. 나는 그 주에 시험이 있다고 대답했다. 선배가 그래 시험이 중요하지 라고 했다.',
                          'evidence_span_A': '그날 좀 봐야 할 게 있다', 'evidence_span_B': '',
                          'gold': {f: rng.choice(LABELS) for f in JUDGED_FIELDS}})
        model = EchoModel()
        official = False
    else:
        items = load_gold(a.gold)
        print('실제 모델을 등록해야 한다. HTTPModel 을 채운 뒤 여기 붙인다.')
        return 2

    chunks = A.default_chunks()
    graph, node_text = A.build_default_graph(chunks[:6])
    arm_list = [A.E0(), A.E1(), A.E2(), A.E3(chunks, k=5), A.E4(graph, node_text, chunks[:6], k=3)]
    report = {'WARNING': None if official else 'NOT VALIDATION RESULT · ECHO MODEL · 배선 확인',
              'model': model.name, 'n_items': len(items), 'arms': {}}
    for arm in arm_list:
        recs = run_arm(arm, items, model, graph if arm.name == 'E4' else None)
        report['arms'][arm.name] = summarize(recs)
    report['decision_rule'] = [
        'E1 ≈ E2 → 외부 온톨로지 DB 필수 주장 약화',
        'E4 ≤ E3 → 그래프 정당화 실패 · E3 로',
        'E4 > E3 이고 path_validity 높고 tokens_in 이 E3 의 2배 이내 → 그래프 정당화',
        '유의 판정은 held_out repeated holdout k=10 의 κ 분포가 겹치지 않을 때 · PROJECT OPERATING RULE',
    ]
    outdir = os.path.join(HERE, a.out)
    os.makedirs(outdir, exist_ok=True)
    io.open(os.path.join(outdir, 'e0_e4_report.json'), 'w', encoding='utf-8').write(
        json.dumps(report, ensure_ascii=False, indent=2))
    if report['WARNING']:
        print('#' * 64)
        print('#  ' + report['WARNING'])
        print('#' * 64)
    print('%-4s %-7s %-6s %-8s %-8s %-8s %-10s %-9s %-8s %s' % (
        'arm', 'kappa', 'acc', 'unsupp', 'abst', 'consis', 'evP/evR', 'tokens', 'ctx p95', 'pathV'))
    for name, s in report['arms'].items():
        print('%-4s %-7s %-6s %-8s %-8s %-8s %-10s %-9s %-8s %s' % (
            name, s['kappa'], s['accuracy'], s['unsupported_rate'], s['abstention_rate'],
            s['consistency_paraphrase'], '%s/%s' % (s['evidence_precision'], s['evidence_recall']),
            s['tokens_in_median'], s['ctx_ms_p95'], s['path_validity_mean']))
    print('저장 ·', os.path.join(outdir, 'e0_e4_report.json'))
    return 0


if __name__ == '__main__':
    sys.exit(main())
