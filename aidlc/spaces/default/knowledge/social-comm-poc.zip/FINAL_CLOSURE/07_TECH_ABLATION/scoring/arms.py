# -*- coding: utf-8 -*-
"""E0~E4 다섯 arm 의 문맥 구성. 다른 것은 문맥만이고 모델 · 스키마 · 판정 함수는 같다.

각 arm 은 build(item, field) -> dict(prompt, meta) 를 낸다.
  prompt.context      arm 이 덧붙이는 문맥 (E0 은 빈 문자열)
  meta.tokens_in      입력 토큰 추정 (문자수/2 · 벤더 카운터가 있으면 바꾼다)
  meta.ctx_ms         문맥 구성에 걸린 시간
  meta.path           E4 만 · 따라간 그래프 경로 · path validity 계산용
  meta.chunks         E3 만 · 가져온 청크 id

색인과 그래프의 재료는 DATASET.md §4. held_out 쌍은 색인에 넣지 않는다.
"""
from __future__ import annotations

import io
import json
import math
import os
import time
from collections import Counter

HERE = os.path.dirname(os.path.abspath(__file__))
RC1 = os.path.join(HERE, '..', '..', '..', 'poc_validation_v0_1')

FIELD_RUBRIC = {
    'required_inference': '머리로 메워야 하는 빈칸의 종류가 두 상황에서 같은가. 상대가 말하지 않은 것을 맥락으로 채우는 종류인지, 진술에서 행동 요구를 읽는 종류인지 등.',
    'perspective_structure': '누구의 속을 몇 겹 짐작해야 하는가가 같은가. 상대 의도 1겹인지, 상대가 나를 어떻게 볼지까지 2겹인지.',
    'decidable_by_evidence': '주어진 단서로 답을 고를 수 있는가가 같은가. 둘 다 단서가 있어 고를 수 있으면 SAME, 한쪽만 고를 수 없으면 DIFFERENT.',
}
COMMON_RULE = ('세 값 중 하나만 낸다. SAME / DIFFERENT / UNKNOWN. 모르면 UNKNOWN. '
               'UNKNOWN 은 정당한 답이고 억지로 고르지 않는다. 근거로 삼은 원문 구간을 evidence_span 에 그대로 복사한다.')


def _est_tokens(s):
    return int(math.ceil(len(s) / 2.0))


class Arm(object):
    name = 'base'

    def build(self, item, field):
        raise NotImplementedError

    def _wrap(self, item, field, context, meta):
        prompt = {
            'system': COMMON_RULE,
            'context': context,
            'situation_1': item['event_A'],
            'situation_2': item['event_B'],
            'field': field,
            'output_schema': {'label': 'SAME | DIFFERENT | UNKNOWN', 'confidence': '0~1',
                              'reason': '한 문장', 'evidence_span': '원문 구간'},
        }
        meta = dict(meta)
        meta['tokens_in'] = _est_tokens(json.dumps(prompt, ensure_ascii=False))
        return {'prompt': prompt, 'meta': meta}


class E0(Arm):
    """plain LLM. 문맥 없음."""
    name = 'E0'

    def build(self, item, field):
        return self._wrap(item, field, '', {'ctx_ms': 0.0})


class E1(Arm):
    """규격 rubric 을 프롬프트에. 외부 자원 없음."""
    name = 'E1'

    def __init__(self, rubric=None, order=None):
        self.rubric = rubric or FIELD_RUBRIC
        self.order = order  # 위치 순열 통제용 · 필드 정의 나열 순서

    def build(self, item, field):
        t = time.perf_counter()
        keys = self.order or list(self.rubric)
        ctx = '판정 지침\n' + '\n'.join('- %s: %s' % (k, self.rubric[k]) for k in keys)
        return self._wrap(item, field, ctx, {'ctx_ms': (time.perf_counter() - t) * 1000})


class E2(Arm):
    """외부 온톨로지 파일에서 해당 필드의 정의와 판정 규칙을 조회해 구조화 문맥으로. 검색이 아니라 조회다."""
    name = 'E2'

    def __init__(self, rules_path=None):
        p = rules_path or os.path.join(RC1, '01_SPEC', 'decision_rules_machine_readable.json')
        self.rules = json.load(io.open(p, encoding='utf-8')) if os.path.exists(p) else {}

    def build(self, item, field):
        t = time.perf_counter()
        ctx_obj = {
            'field': field,
            'definition': FIELD_RUBRIC.get(field, ''),
            'value_domain': self.rules.get('value_domains', {}).get('field_comparison', []),
            'core_fields_understand': self.rules.get('core_equivalence_fields', {}).get('understand', []),
            'skill_identity_rule': self.rules.get('rules', {}).get('skill_identity', {}).get('clauses', []),
        }
        ctx = '온톨로지 정의 (JSON)\n' + json.dumps(ctx_obj, ensure_ascii=False)
        return self._wrap(item, field, ctx, {'ctx_ms': (time.perf_counter() - t) * 1000})


class E3(Arm):
    """Vector RAG. bag-of-words 코사인으로 상위 k 청크. 임베딩 모델이 붙으면 _vec 만 바꾼다."""
    name = 'E3'

    def __init__(self, chunks, k=5, exclude_pair_ids=()):
        self.k = k
        self.chunks = [c for c in chunks if c.get('pair_id') not in set(exclude_pair_ids)]
        self.vecs = [self._vec(c['text']) for c in self.chunks]

    @staticmethod
    def _vec(s):
        return Counter(s.split())

    @staticmethod
    def _cos(a, b):
        num = sum(a[w] * b.get(w, 0) for w in a)
        den = math.sqrt(sum(v * v for v in a.values())) * math.sqrt(sum(v * v for v in b.values()))
        return num / den if den else 0.0

    def build(self, item, field):
        t = time.perf_counter()
        q = self._vec(item['event_A'] + ' ' + item['event_B'] + ' ' + field)
        scored = sorted(((self._cos(q, v), i) for i, v in enumerate(self.vecs)), reverse=True)[:self.k]
        picked = [self.chunks[i] for _, i in scored]
        ctx = '관련 문서 조각\n' + '\n---\n'.join(c['text'] for c in picked)
        return self._wrap(item, field, ctx, {'ctx_ms': (time.perf_counter() - t) * 1000,
                                             'chunks': [c['id'] for c in picked]})


class E4(Arm):
    """온톨로지/KG + 그래프 검색. 표적 -> 필드 -> 규칙 -> 유사 씨앗 경로를 따라 문맥을 만든다.

    graph 는 {node: [(edge, node), ...]}. 경로를 meta.path 로 내서 path validity 를 계산할 수 있게 한다."""
    name = 'E4'

    def __init__(self, graph, node_text, seed_chunks, k=3, exclude_pair_ids=()):
        self.g = graph
        self.text = node_text
        self.seeds = [c for c in seed_chunks if c.get('pair_id') not in set(exclude_pair_ids)]
        self.k = k

    def build(self, item, field):
        t = time.perf_counter()
        path = [('field:' + field)]
        ctx_parts = [self.text.get('field:' + field, '')]
        # 필드 -> 규칙
        for edge, nxt in self.g.get('field:' + field, []):
            if edge == 'GOVERNED_BY':
                path.append(nxt)
                ctx_parts.append(self.text.get(nxt, ''))
        # 필드 -> 씨앗 (같은 필드에서 SAME/DIFFERENT 가 갈린 씨앗 k개)
        n_seed = 0
        for edge, nxt in self.g.get('field:' + field, []):
            if edge == 'ILLUSTRATED_BY' and n_seed < self.k:
                path.append(nxt)
                ctx_parts.append(self.text.get(nxt, ''))
                n_seed += 1
        ctx = '온톨로지 경로 ' + ' -> '.join(path) + '\n' + '\n---\n'.join(p for p in ctx_parts if p)
        return self._wrap(item, field, ctx, {'ctx_ms': (time.perf_counter() - t) * 1000, 'path': path})


def path_validity(path, graph):
    """경로의 연속한 두 노드 사이에 실제 간선이 있는 비율. 1.0 이면 전부 실제 간선."""
    if len(path) < 2:
        return 1.0
    ok = 0
    for a, b in zip(path, path[1:]):
        if any(n == b for _, n in graph.get(a, [])):
            ok += 1
    return round(ok / (len(path) - 1), 3)


def build_default_graph(seed_chunks):
    """DATASET.md §4 의 재료로 최소 그래프. 표적 -> 필드 -> 규칙 -> 씨앗."""
    g = {}
    text = {}
    for f, d in FIELD_RUBRIC.items():
        g['field:' + f] = [('GOVERNED_BY', 'rule:skill_identity')]
        text['field:' + f] = '%s: %s' % (f, d)
    text['rule:skill_identity'] = ('Skill Identity 규칙: Core 중 하나라도 UNKNOWN 이면 UNDETERMINED, '
                                   '하나라도 DIFFERENT 면 DIFFERENT, 전부 SAME 이면 SAME. UNKNOWN 이 DIFFERENT 보다 먼저.')
    g['rule:skill_identity'] = []
    for c in seed_chunks:
        node = 'seed:' + c['id']
        text[node] = c['text']
        g.setdefault(node, [])
        for f in FIELD_RUBRIC:
            g['field:' + f].append(('ILLUSTRATED_BY', node))
    return g, text


def default_chunks():
    """규격 요약과 지침을 청크로. 파일이 없으면 rubric 만 청크로 쓴다."""
    chunks = []
    for i, (f, d) in enumerate(FIELD_RUBRIC.items()):
        chunks.append({'id': 'rubric-%d' % i, 'text': '%s: %s' % (f, d)})
    for rel in ('01_SPEC/frozen_spec_summary.md', '02_POC_A/annotation_guideline_onepage.md'):
        p = os.path.join(RC1, rel)
        if os.path.exists(p):
            body = io.open(p, encoding='utf-8').read()
            paras = [x.strip() for x in body.split('\n\n') if len(x.strip()) > 40]
            for j, para in enumerate(paras):
                chunks.append({'id': '%s#%d' % (os.path.basename(rel), j), 'text': para[:600]})
    return chunks
