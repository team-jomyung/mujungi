# -*- coding: utf-8 -*-
"""F4 편향 시험 실행기. 섭동별로 판정이 얼마나 뒤집히는지와 gold 대비 정확도가 얼마나 움직이는지 낸다.

    python run_bias_tests.py --demo                      EchoProvider 로 배선 확인
    python run_bias_tests.py --gold <A1합의.csv> ...      실제 판정자를 붙인 뒤

출력 (results/bias_report.json)
  섭동별
    flip_rate            원본 판정과 섭동 후 판정이 다른 비율        낮을수록 좋다
    accuracy_original    원본에서 gold 대비 정확도
    accuracy_perturbed   섭동 후 gold 대비 정확도
    delta                perturbed - original                       0 에 가까울수록 좋다
    unknown_shift        UNKNOWN 비율 변화                            섭동이 보류를 늘리거나 줄이는가
  generator_family
    판정자 계열이 생성자 계열과 같은 것과 다른 것의 정확도를 나눠 낸다

EchoProvider 출력으로는 어떤 편향도 주장하지 않는다. 배선 확인이다.
"""
from __future__ import annotations

import argparse
import io
import json
import os
import random
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', 'judge_harness'))
sys.path.insert(0, HERE)

from judge_harness import EchoProvider, JUDGED_FIELDS, LABELS, load_gold  # noqa: E402
import perturbations as P  # noqa: E402


class TextHashProvider(EchoProvider):
    """데모용. 본문 해시로 라벨을 만들어 섭동이 실제로 판정을 흔드는지 배선을 보인다.

    judge_harness.EchoProvider 는 pair_id 를 해시하므로 본문을 바꿔도 라벨이 안 변한다.
    그 provider 로 편향 시험을 돌리면 flip_rate 가 전부 0 이 되어 "편향 없음"처럼 읽힌다.
    그것은 결과가 아니라 배선 착시다. 여기서는 본문에 민감한 더미를 쓴다."""

    def judge(self, item, field, order):
        text = item['event_A'] + '|' + item['event_B'] if order == 'AB' else item['event_B'] + '|' + item['event_A']
        h = sum(ord(c) for c in text) % 100
        lab = 'UNKNOWN' if h < 15 else ('SAME' if h < 65 else 'DIFFERENT')
        return lab, 0.5 + (h % 40) / 100.0, 'text-hash 더미 · 실제 판정 아님', ''


def judge_all(items, provider, order='AB'):
    out = {}
    for it in items:
        for fld in JUDGED_FIELDS:
            if fld in it['gold']:
                lab, conf, _, _ = provider.judge(it, fld, order)
                out[(it['pair_id'], fld)] = (lab, conf)
    return out


def compare(base, pert, gold_of):
    keys = sorted(base)
    flips = sum(1 for k in keys if base[k][0] != pert[k][0])
    acc_b = sum(1 for k in keys if base[k][0] == gold_of[k]) / len(keys)
    acc_p = sum(1 for k in keys if pert[k][0] == gold_of[k]) / len(keys)
    unk_b = sum(1 for k in keys if base[k][0] == 'UNKNOWN') / len(keys)
    unk_p = sum(1 for k in keys if pert[k][0] == 'UNKNOWN') / len(keys)
    return {
        'n': len(keys),
        'flip_rate': round(flips / len(keys), 3),
        'accuracy_original': round(acc_b, 3),
        'accuracy_perturbed': round(acc_p, 3),
        'delta': round(acc_p - acc_b, 3),
        'unknown_shift': round(unk_p - unk_b, 3),
    }


def run(items, providers, generator_family=None):
    gold_of = {(it['pair_id'], f): it['gold'][f] for it in items for f in JUDGED_FIELDS if f in it['gold']}
    report = {'n_pairs': len(items), 'n_judgements': len(gold_of), 'providers': {}}
    for p in providers:
        base = judge_all(items, p)
        per = {}
        for name, fn in P.ALL.items():
            pert_items = [fn(it) for it in items]
            # order_swap 은 harness 가 'BA' 로 묻는 것과 같다. 여기서는 텍스트를 바꾸고 AB 로 묻는다
            pert = judge_all(pert_items, p)
            per[name] = compare(base, pert, gold_of)
        report['providers'][p.name] = {
            'family': p.family,
            'same_family_as_generator': (generator_family is not None and p.family == generator_family),
            'perturbations': per,
        }
    # 생성자 계열 누출 · 같은 계열 판정자와 다른 계열 판정자의 원본 정확도 비교
    if generator_family:
        same = [v['perturbations']['paraphrase']['accuracy_original']
                for v in report['providers'].values() if v['same_family_as_generator']]
        diff = [v['perturbations']['paraphrase']['accuracy_original']
                for v in report['providers'].values() if not v['same_family_as_generator']]
        report['generator_family_leakage'] = {
            'generator_family': generator_family,
            'mean_accuracy_same_family': round(sum(same) / len(same), 3) if same else None,
            'mean_accuracy_other_family': round(sum(diff) / len(diff), 3) if diff else None,
            'note': '같은 계열이 유의하게 높으면 자기 선호 편향을 의심한다. 생성 모델은 판정단에서 뺀다',
        }
    report['reading'] = [
        'flip_rate 가 0 이 아니면 그 섭동이 판정을 움직인다. 구조는 안 바뀌었으므로 편향이다',
        'relationship 섭동에서 Core 세 필드가 뒤집히면 관계가 Core 판정에 새고 있다. 규격상 Core 는 관계 입력이 아니다',
        'verbosity 에서 긴 쪽으로 SAME 이 몰리면 길이 편향이다',
        'flip_rate 0 은 두 가지 뜻이 있다. 편향이 없다, 또는 판정자가 본문을 보지 않는다. '
        'idhash 더미가 후자의 예다. 실제 판정자에서 0 이 나오면 paraphrase 에서도 0 인지 먼저 본다',
        '더미 출력은 배선 확인이지 결과가 아니다',
    ]
    return report


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--gold', default=None)
    ap.add_argument('--demo', action='store_true')
    ap.add_argument('--generator-family', default=None)
    ap.add_argument('--out', default='results')
    args = ap.parse_args()

    if args.demo or not args.gold:
        print('=' * 60)
        print('  DEMO · EchoProvider · 배선 확인. 편향 결과가 아니다')
        print('=' * 60)
        rng = random.Random(3)
        items = []
        for i in range(1, 31):
            items.append({'pair_id': 'P%02d' % i,
                          'event_A': '민수 선배가 "그거 꼭 해야 해?"라고 말했다. 나는 조금 당황했습니다.',
                          'event_B': '팀장님이 "이거 내일까지 되죠?"라고 물었다. 나는 그냥 네라고 대답했다.',
                          'gold': {f: rng.choice(LABELS) for f in JUDGED_FIELDS}})
        providers = [TextHashProvider('texthash_a', 'familyX', 0.0, 1),
                     TextHashProvider('texthash_b', 'familyY', 0.0, 2),
                     EchoProvider('idhash_c', 'familyZ', 0.0, 3)]
        gen_family = 'familyX'
        print('  texthash_* 는 본문 해시라 섭동에 흔들린다 (배선 확인용). idhash_c 는 pair_id 해시라 안 흔들린다.')
        print('  둘을 같이 두는 이유 · flip_rate 0 이 "편향 없음"이 아니라 "본문을 안 본다"일 수 있음을 보이려는 것')
    else:
        items = load_gold(args.gold)
        print('실제 provider 를 등록해야 한다. HTTPProvider 를 채운 뒤 여기 붙인다.')
        return 2

    rep = run(items, providers, gen_family)
    outdir = os.path.join(HERE, args.out)
    os.makedirs(outdir, exist_ok=True)
    io.open(os.path.join(outdir, 'bias_report.json'), 'w', encoding='utf-8').write(
        json.dumps(rep, ensure_ascii=False, indent=2))
    print('판정 %d건 · 판정자 %d' % (rep['n_judgements'], len(rep['providers'])))
    print('%-18s %-10s %-10s %-10s %s' % ('perturbation', 'flip', 'acc_orig', 'acc_pert', 'delta'))
    for pname, pv in rep['providers'].items():
        print('[%s · %s]' % (pname, pv['family']))
        for k, v in pv['perturbations'].items():
            print('  %-16s %-10s %-10s %-10s %s' % (k, v['flip_rate'], v['accuracy_original'],
                                                   v['accuracy_perturbed'], v['delta']))
    if 'generator_family_leakage' in rep:
        print('생성자 계열 누출 ·', rep['generator_family_leakage'])
    print('저장 ·', os.path.join(outdir, 'bias_report.json'))
    return 0


if __name__ == '__main__':
    sys.exit(main())
