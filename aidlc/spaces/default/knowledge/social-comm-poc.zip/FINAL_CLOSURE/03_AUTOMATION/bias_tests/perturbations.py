# -*- coding: utf-8 -*-
"""판정 편향 시험용 섭동. 한 항목의 표면만 바꾸고 구조는 그대로 둔다.

각 함수는 item 을 받아 새 item 을 돌려준다. 원본을 고치지 않는다.
구조를 바꾸지 않았으므로 gold 라벨은 그대로다. 판정이 바뀌면 그것이 편향이다.

섭동 일곱 (F4)
  order_swap            A 와 B 를 바꾼다                        (harness 가 이미 양방향으로 묻는다)
  verbosity             한쪽 상황에 무관한 세부를 덧붙인다        길이가 판정을 끌어당기는가
  style                 격식체 <-> 구어체                        말투가 판정을 끌어당기는가
  relationship          관계 표지를 다른 관계로 바꾼다           관계가 Core 판정에 새는가 (Core 는 관계 입력이 아니다)
  name_neutralize       이름을 역할 토큰으로 바꾼다              이름과 성별이 판정에 새는가
  paraphrase            어순과 어휘를 바꾼 같은 뜻 문장          표면 의존인가
  generator_family      섭동이 아니라 분석 축. 판정자 계열 == 생성자 계열이면 표시
"""
from __future__ import annotations

import copy
import re

VERBOSE_PAD = (' 그날은 비가 조금 왔고 점심은 학식에서 먹었다. 오후 수업이 하나 있었고 '
               '저녁에는 별다른 일정이 없었다. 카톡 알림이 몇 개 와 있었다.')

FORMAL_TO_CASUAL = [
    (r'했습니다', '했어'), (r'였습니다', '였어'), (r'입니다', '이야'), (r'합니다', '해'),
    (r'습니다', '어'), (r'하였다', '했다'), (r'그러나', '근데'), (r'그리고', '그리고'),
]
CASUAL_TO_FORMAL = [
    (r'했어\b', '했습니다'), (r'였어\b', '였습니다'), (r'이야\b', '입니다'), (r'근데', '그러나'),
    (r'했다\b', '하였습니다'), (r'그랬다\b', '그러하였습니다'),
]

REL_MARKERS = {
    '친구': '선배', '선배': '친구', '후배': '동료', '동료': '후배',
    '팀장님': '친구', '교수님': '동아리 선배', '상사': '같은 조 친구', '사수': '동기',
}

NAME_PATTERN = re.compile(r'(^|[^가-힣])([가-힣]{2,3})\s?(씨|님|선배|후배|언니|오빠|형|누나)')

PARAPHRASE_SWAPS = [
    ('말했다', '얘기했다'), ('물었다', '질문했다'), ('대답했다', '답했다'), ('갑자기', '문득'),
    ('조금', '약간'), ('그냥', '단지'), ('아무 말도', '한마디도'), ('나중에', '이후에'),
]


def _clone(item):
    return copy.deepcopy(item)


def order_swap(item):
    it = _clone(item)
    it['event_A'], it['event_B'] = item['event_B'], item['event_A']
    it['perturbation'] = 'order_swap'
    return it


def verbosity(item, side='A'):
    it = _clone(item)
    key = 'event_' + side
    it[key] = it[key] + VERBOSE_PAD
    it['perturbation'] = 'verbosity_' + side
    return it


def style(item, direction='to_casual'):
    it = _clone(item)
    rules = FORMAL_TO_CASUAL if direction == 'to_casual' else CASUAL_TO_FORMAL
    for key in ('event_A', 'event_B'):
        s = it[key]
        for pat, rep in rules:
            s = re.sub(pat, rep, s)
        it[key] = s
    it['perturbation'] = 'style_' + direction
    return it


def relationship(item):
    """관계 표지만 바꾼다. Core 필드는 관계의 입력이 아니므로 판정이 바뀌면 누출이다.

    주의. direct_check_allowed 는 관계에서 파생되는 결정적 필드라 이 시험 대상이 아니다.
    JUDGED_FIELDS 셋에만 적용한다."""
    it = _clone(item)
    for key in ('event_A', 'event_B'):
        s = it[key]
        for a, b in REL_MARKERS.items():
            s = s.replace(a, '\x00' + b + '\x00')   # 이중 치환 방지
        it[key] = s.replace('\x00', '')
    it['perturbation'] = 'relationship'
    return it


def name_neutralize(item):
    it = _clone(item)
    for key in ('event_A', 'event_B'):
        it[key] = NAME_PATTERN.sub(lambda m: m.group(1) + '[그분] ' + m.group(3), it[key])
    it['perturbation'] = 'name_neutralize'
    return it


def paraphrase(item):
    it = _clone(item)
    for key in ('event_A', 'event_B'):
        s = it[key]
        for a, b in PARAPHRASE_SWAPS:
            s = s.replace(a, b)
        it[key] = s
    it['perturbation'] = 'paraphrase'
    return it


ALL = {
    'order_swap': order_swap,
    'verbosity_A': lambda it: verbosity(it, 'A'),
    'verbosity_B': lambda it: verbosity(it, 'B'),
    'style_to_casual': lambda it: style(it, 'to_casual'),
    'style_to_formal': lambda it: style(it, 'to_formal'),
    'relationship': relationship,
    'name_neutralize': name_neutralize,
    'paraphrase': paraphrase,
}
