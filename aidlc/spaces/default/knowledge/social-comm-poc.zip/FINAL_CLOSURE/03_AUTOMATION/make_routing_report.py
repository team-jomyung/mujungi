# -*- coding: utf-8 -*-
"""ROUTING_POLICY_REPORT.md 를 judge_harness 결과에서 만든다. 손으로 옮겨 적지 않는다.

    python make_routing_report.py
"""
import io
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))


def main():
    rep = json.load(io.open(os.path.join(HERE, 'judge_harness', 'results', 'a2_report.json'), encoding='utf-8'))
    curve = rep['routing_curve']
    fields = list(rep['by_field'])
    mid = next(r for r in curve if abs(r['threshold'] - 0.5) < 1e-9)
    L = [
        '# ROUTING POLICY REPORT',
        '',
        '2026-09-14 · F7. 문턱을 고정하지 않고 곡선을 낸다. 팀이 곡선을 보고 고른다.',
        '`make_routing_report.py` 가 `judge_harness/results/a2_report.json` 에서 만든다. 손으로 옮겨 적지 않는다.',
        '',
        '**이 곡선은 EchoProvider 출력이다.** 텍스트 해시로 라벨을 만드는 더미라 **형식만 유효하고 값은 무의미하다.**',
        '실제 판정자를 붙이고 A1 gold 의 held_out 묶음으로 다시 낸 곡선만 의사결정에 쓴다.',
        '',
        '## 1 · 자동 확정 규칙',
        '',
        '```',
        '자동 확정    = 판정단 만장일치  AND  평균 확신 >= 문턱',
        '사람 검토    = 나머지 전부 (불일치 · UNDETERMINED · 확신 미달)',
        '잘못된 확신  = 자동 확정했는데 gold 와 다름 / 자동 확정 수',
        '```',
        '',
        '말로 표현한 확신은 과신한다(Jung 2024 · ECE 약 0.22). 그래서 **만장일치를 먼저 요구**하고 확신은 그 안에서만 쓴다.',
        '',
        '## 2 · 곡선 · DRY-RUN · 판정 %d건 · 필드 %d (%s)' % (rep['n_judgements'], len(fields), ' · '.join(fields)),
        '',
        '`direct_check_allowed` 가 이번에 판정 필드로 들어왔다. 관계에서 규칙으로 채우면 규범적 이분법이 되기 때문이다 (`02_SCOPE/RELATIONSHIP_SCOPE.md`).',
        '',
        '| 문턱 | 자동화율 | 사람 검토율 | 잘못된 확신율 | 자동 n | 검토 n | 오답 n |',
        '|---|---|---|---|---|---|---|',
    ]
    for r in curve:
        fc = '-' if r['false_confident_rate'] is None else r['false_confident_rate']
        L.append('| %.2f | %.3f | %.3f | %s | %d | %d | %d |' % (
            r['threshold'], r['automation_coverage'], r['human_review_rate'], fc, r['n_auto'], r['n_review'], r['n_wrong']))
    L += [
        '',
        '## 3 · 실제 판정자를 붙인 뒤 읽는 법',
        '',
        '| 보는 것 | 뜻 |',
        '|---|---|',
        '| 잘못된 확신율이 목표 아래로 내려가는 **가장 낮은 문턱** | 그 문턱의 자동화율이 곧 "사람 없이 처리되는 비율" |',
        '| 문턱을 올려도 잘못된 확신율이 안 내려감 | 확신에 정보가 없다. 만장일치만으로 라우팅한다 |',
        '| 자동화율이 0.5 아래 | Jung 2024 의 실측(0.90 일치 목표에서 55.7%)과 비슷한 범위. 판정단으로 사람을 절반 넘게 줄이기 어렵다는 뜻 |',
        '| 필드별로 곡선이 크게 다름 | 필드별 문턱을 따로 둔다. 필드별 AG 가 다르면 Dorner 한계도 필드별로 갈린다 |',
        '',
        '**목표 잘못된 확신율은 PROJECT OPERATING THRESHOLD 다.** 문헌이 정한 값이 아니다.',
        '',
        '## 4 · 지금 이 곡선에서 읽어도 되는 것',
        '',
        '- 문턱 0.50 에서 자동화율 %.3f 은 Echo 판정자들의 만장일치 확률에서 나온 값이다. 실제 판정자와 무관하다' % mid['automation_coverage'],
        '- **읽어도 되는 것은 열의 형식과 계산 경로뿐이다**',
        '',
        '## 5 · 다시 만들기',
        '',
        '```',
        'python judge_harness/judge_harness.py --gold <held_out.csv> --out results',
        'python make_routing_report.py',
        '```',
        '',
        '`gold_split.py` 의 manifest 해시를 보고서에 함께 적는다. held_out 이 아닌 묶음에서 낸 곡선은 의사결정에 쓰지 않는다.',
    ]
    io.open(os.path.join(HERE, 'ROUTING_POLICY_REPORT.md'), 'w', encoding='utf-8', newline='\n').write('\n'.join(L) + '\n')
    print('ROUTING_POLICY_REPORT.md · 문턱 %d · 필드 %d' % (len(curve), len(fields)))


if __name__ == '__main__':
    main()
