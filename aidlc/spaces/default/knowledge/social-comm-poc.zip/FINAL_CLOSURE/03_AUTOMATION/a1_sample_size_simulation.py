# -*- coding: utf-8 -*-
"""POC A1 표본 크기를 시뮬레이션으로 정한다.

  python a1_sample_size_simulation.py

지금까지 "40쌍 이상"은 우리 DEMO 한 번(n=20, CI 폭 0.647)에서 나온 감이었다.
그것을 몬테카를로로 대체한다. 문헌 문턱이 아니라 **이 과제 구조에서 계산한 값**이다.

무엇을 모형화하는가
  두 판정자가 3범주(SAME / DIFFERENT / UNKNOWN)에 라벨을 붙인다.
  참 일치 수준 kappa_true 와 범주 분포 prevalence 를 정하고
  그 조건을 만족하는 결합분포에서 n 쌍을 뽑아 Cohen kappa 와 부트스트랩 CI 를 낸다.

무엇을 재는가
  1 CI 폭의 중앙값
  2 CI 하한이 목표 문턱을 넘을 확률  (= 문턱 초과를 주장할 수 있는 검정력)
  3 축2(거리) 유효 표본이 얼마나 줄어드는가

주의
  이것은 통계적 정밀도 계산이지 "이만큼이면 POC 가 성공한다"가 아니다.
  표준 라이브러리만 쓴다. numpy 없이 돈다.
"""

import io
import json
import os
import random

SEED = 20260912
CATS = ('SAME', 'DIFFERENT', 'UNKNOWN')

# 축2 감소율 · 우리 DEMO 실측에서 20쌍 -> 9쌍이었다.
# 거리 축은 두 판정자가 모두 이해축 SAME 으로 본 쌍에서만 계산된다.
AXIS2_RETENTION_OBSERVED = 9.0 / 20.0


def build_joint(kappa_true, prev):
    """목표 kappa 를 내는 두 판정자의 결합분포를 만든다.

    구조 · 확률 p 로 둘이 같은 범주에 합의하고(주변분포 prev 를 따름),
    1-p 로 각자 독립적으로 prev 에서 뽑는다.
    이때 기대 관측일치 Po = p + (1-p)*Pe 이고 kappa = (Po-Pe)/(1-Pe) = p 가 된다.
    즉 p 를 kappa_true 로 두면 목표 kappa 를 가진 결합분포가 된다.
    """
    p = kappa_true
    joint = {}
    for i, a in enumerate(CATS):
        for j, b in enumerate(CATS):
            agree_part = p * prev[i] if a == b else 0.0
            indep_part = (1.0 - p) * prev[i] * prev[j]
            joint[(a, b)] = agree_part + indep_part
    tot = sum(joint.values())
    return {k: v / tot for k, v in joint.items()}


def sample(joint, n, rng):
    keys = list(joint)
    weights = [joint[k] for k in keys]
    cum, acc = [], 0.0
    for w in weights:
        acc += w
        cum.append(acc)
    out = []
    for _ in range(n):
        r = rng.random() * cum[-1]
        for k, c in zip(keys, cum):
            if r <= c:
                out.append(k)
                break
    return out


def cohen_kappa(pairs):
    n = len(pairs)
    if n == 0:
        return None
    agree = sum(1 for a, b in pairs if a == b) / n
    ma = {c: sum(1 for a, _ in pairs if a == c) / n for c in CATS}
    mb = {c: sum(1 for _, b in pairs if b == c) / n for c in CATS}
    pe = sum(ma[c] * mb[c] for c in CATS)
    if abs(1.0 - pe) < 1e-12:
        return None
    return (agree - pe) / (1.0 - pe)


def boot_ci(pairs, rng, B=1000, alpha=0.05):
    n = len(pairs)
    ks = []
    for _ in range(B):
        rs = [pairs[rng.randrange(n)] for _ in range(n)]
        k = cohen_kappa(rs)
        if k is not None:
            ks.append(k)
    if len(ks) < 50:
        return None, None
    ks.sort()
    lo = ks[int(len(ks) * (alpha / 2))]
    hi = ks[min(len(ks) - 1, int(len(ks) * (1 - alpha / 2)))]
    return lo, hi


def median(xs):
    s = sorted(xs)
    m = len(s)
    if m == 0:
        return None
    return s[m // 2] if m % 2 else (s[m // 2 - 1] + s[m // 2]) / 2.0


def run_cell(n, kappa_true, prev, threshold, reps, rng, B):
    widths, lo_over, ks = [], 0, []
    for _ in range(reps):
        joint = build_joint(kappa_true, prev)
        pairs = sample(joint, n, rng)
        k = cohen_kappa(pairs)
        if k is None:
            continue
        ks.append(k)
        lo, hi = boot_ci(pairs, rng, B=B)
        if lo is None:
            continue
        widths.append(hi - lo)
        if lo > threshold:
            lo_over += 1
    return {
        'n': n,
        'kappa_true': kappa_true,
        'median_kappa_hat': round(median(ks), 3) if ks else None,
        'median_ci_width': round(median(widths), 3) if widths else None,
        'p_lower_ci_above_threshold': round(lo_over / float(reps), 3),
        'reps': reps,
    }


def main():
    rng = random.Random(SEED)
    # 범주 분포 세 조건 · 우리 규격에서 UNKNOWN 은 정당한 답이므로 드물지 않을 수 있다
    PREVALENCES = {
        'balanced':      (0.40, 0.40, 0.20),
        'same_heavy':    (0.60, 0.30, 0.10),
        'unknown_heavy': (0.35, 0.30, 0.35),
    }
    NS = (20, 40, 60, 80, 100, 150, 200)
    KAPPAS = (0.4, 0.5, 0.6, 0.7, 0.8)
    THRESHOLD = 0.6
    REPS = 200
    B = 250

    results = []
    print('POC A1 표본 크기 시뮬레이션')
    print('  seed %d · 반복 %d · 부트스트랩 %d · 문턱 kappa > %.1f' % (SEED, REPS, B, THRESHOLD))
    print()

    for pname, prev in PREVALENCES.items():
        print('=' * 74)
        print('  범주 분포 · %s   SAME %.2f / DIFFERENT %.2f / UNKNOWN %.2f'
              % (pname, prev[0], prev[1], prev[2]))
        print('=' * 74)
        print('  %-5s %-8s %-10s %-11s %s' % ('n', 'κ참값', 'κ추정 중앙', 'CI폭 중앙', 'P(하한>0.6)'))
        for kt in KAPPAS:
            for n in NS:
                r = run_cell(n, kt, prev, THRESHOLD, REPS, rng, B)
                r['prevalence'] = pname
                results.append(r)
                print('  %-5d %-8.1f %-10s %-11s %s'
                      % (n, kt,
                         r['median_kappa_hat'], r['median_ci_width'],
                         r['p_lower_ci_above_threshold']))
            print('  ' + '-' * 70)
        print()

    # ── 축2 유효 표본
    print('=' * 74)
    print('  축2 · 거리 판정의 유효 표본')
    print('=' * 74)
    print('  거리는 두 판정자가 모두 이해축 SAME 으로 본 쌍에서만 계산된다.')
    print('  우리 DEMO 실측 · 20쌍 -> 9쌍 (유지율 %.2f)' % AXIS2_RETENTION_OBSERVED)
    print()
    print('  %-8s %-14s %s' % ('전체 n', '기대 축2 n', '축2 에서 쓸 만한가'))
    for n in NS:
        eff = int(round(n * AXIS2_RETENTION_OBSERVED))
        verdict = '불가' if eff < 20 else ('빠듯' if eff < 40 else '가능')
        print('  %-8d %-14d %s' % (n, eff, verdict))
    print()

    out = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                       'A1_SAMPLE_SIZE_RESULTS.json')
    io.open(out, 'w', encoding='utf-8').write(
        json.dumps({'seed': SEED, 'reps': REPS, 'bootstrap': B,
                    'threshold': THRESHOLD,
                    'axis2_retention_observed': AXIS2_RETENTION_OBSERVED,
                    'results': results}, ensure_ascii=False, indent=2))
    print('저장 ·', out)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
