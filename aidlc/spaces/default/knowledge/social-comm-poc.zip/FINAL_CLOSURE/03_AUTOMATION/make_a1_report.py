# -*- coding: utf-8 -*-
"""A1_SAMPLE_SIZE_REPORT.md 를 시뮬레이션 결과 JSON 에서 만든다. 손으로 옮겨 적지 않는다.

    python make_a1_report.py

왜 있나
  ERR-06 · 보고서가 인용한 수치(0.13 · 0.81 · 0.58 · 0.90 · 0.63)가 지금 코드의 출력과 달랐다.
  옛 판 스크립트(반복 수가 달랐다)의 출력을 손으로 옮겨 적어 둔 것이 남아 있었다.
  ERR-04 · ERR-05 와 같은 계열이다. 숫자의 출처를 코드 하나로 두고 문서를 거기서 만든다.

주의 · 이 스크립트는 시뮬레이션을 돌리지 않는다. JSON 을 읽어 표만 만든다.
      JSON 을 새로 만들려면 a1_sample_size_simulation.py 를 돌린다 (수 분 걸린다).
"""
import io
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
RESULTS = os.path.join(HERE, 'A1_SAMPLE_SIZE_RESULTS.json')
OUT = os.path.join(HERE, 'A1_SAMPLE_SIZE_REPORT.md')
KEY_NS = (20, 40, 60, 80, 120, 200)   # 120 이 없으면 100 과 150 사이라 표에서 뺀다


def cell(rows, prev, n, k):
    for r in rows:
        if r['prevalence'] == prev and r['n'] == n and abs(r['kappa_true'] - k) < 1e-9:
            return r
    return None


def main():
    d = json.load(io.open(RESULTS, encoding='utf-8'))
    rows = d['results']
    ns = sorted({r['n'] for r in rows})
    kappas = sorted({r['kappa_true'] for r in rows})
    th = d['threshold']
    ret = d['axis2_retention_observed']
    g = lambda n, k, p='balanced': cell(rows, p, n, k)

    L = ['# POC A1 표본 크기 · 시뮬레이션 결과', '',
         '`make_a1_report.py` 가 `A1_SAMPLE_SIZE_RESULTS.json` 에서 만든다. **숫자를 손으로 옮겨 적지 않는다.**',
         '',
         'seed %d · 반복 %d · 부트스트랩 %d · 문턱 kappa > %.1f · 몬테카를로'
         % (d['seed'], d['reps'], d['bootstrap'], th),
         '',
         '> **이 결과는 CLOSURE_RESEARCH 의 "40쌍 이상" 권고를 뒤집는다.**',
         '> 그 숫자는 우리 DEMO 한 번(n=20, CI 폭 0.647)에서 나온 감이었다.',
         '> 시뮬레이션은 40쌍으로 문턱 주장을 할 수 없다고 말한다.',
         '', '---', '',
         '## 1 · 무엇을 모형화했나', '',
         '두 판정자가 3범주(SAME / DIFFERENT / UNKNOWN)에 라벨을 붙인다.',
         '참 일치 `κ_true` 와 범주 분포를 정하고 그 결합분포에서 n 쌍을 뽑아',
         'Cohen κ 와 부트스트랩 95% CI 를 낸다.',
         '',
         '재는 것은 둘이다.',
         '',
         '1. **CI 폭의 중앙값** · 추정이 얼마나 정밀한가',
         '2. **P(CI 하한 > %.1f)** · 우리 문턱을 넘었다고 **주장할 수 있는 확률**' % th,
         '', '---', '',
         '## 2 · 결과 · 균형 분포 (SAME .40 / DIFFERENT .40 / UNKNOWN .20)', '']
    head = '| n |' + ''.join(' κ참값 %.1f |  |' % k for k in kappas)
    sub = '|---|' + '---|---|' * len(kappas)
    L += [head, sub, '| | ' + ' | '.join('CI폭 | P(>%.1f)' % th for _ in kappas) + ' |']
    for n in ns:
        cells = []
        for k in kappas:
            r = g(n, k)
            cells.append('%s | %s' % (r['median_ci_width'], r['p_lower_ci_above_threshold']) if r else '— | —')
        L.append('| **%d** | %s |' % (n, ' | '.join(cells)))

    L += ['', '## 3 · 다른 범주 분포에서', '',
          '| 분포 | κ참값 | n | CI폭 | P(>%.1f) |' % th, '|---|---|---|---|---|']
    for p in ('same_heavy', 'unknown_heavy'):
        for k in (0.7, 0.8):
            for n in (60, 120 if 120 in ns else 100):
                r = g(n, k, p)
                if r:
                    L.append('| %s | %.1f | %d | %s | %s |'
                             % (p, k, n, r['median_ci_width'], r['p_lower_ci_above_threshold']))
    L += ['', '**결정적인 변수는 참 일치 수준이다.** 범주 분포를 바꿔도 같은 자리에서 결론이 갈린다.',
          '', '---', '', '## 4 · 이 표가 말하는 것', '']

    n40_07, n60_08 = g(40, 0.7), g(60, 0.8)
    n40_08, n200_07 = g(40, 0.8), g(200, 0.7)
    # 격자에 120 이 없다(20/40/60/80/100/150/200). 권장 120쌍은 격자 점이 아니므로
    # κ 근거는 양쪽 격자 점(100 · 150)으로 적고, 120 자체는 축2 계산에서 나온 값이라고 밝힌다
    n100_08, n150_08 = g(100, 0.8), g(150, 0.8)
    L += ['### 4-1 · 40쌍으로는 문턱 주장을 못 한다', '',
          '참 일치가 **0.7 이어도 40쌍에서 문턱 초과를 주장할 확률이 %s** 다.'
          % n40_07['p_lower_ci_above_threshold'],
          '60쌍에서 %s, 200쌍에서도 %s 다.'
          % (g(60, 0.7)['p_lower_ci_above_threshold'], n200_07['p_lower_ci_above_threshold']),
          '',
          '즉 **판정자들이 실제로 꽤 잘 맞아도(κ 0.7) 연구가 결론을 못 낸다.**',
          '',
          '### 4-2 · 문턱 주장은 참 일치가 0.8 은 되어야 가능하다', '',
          'κ 참값 0.8 일 때 · 40쌍 %s · **60쌍 %s** · 100쌍 %s · 150쌍 %s.'
          % (n40_08['p_lower_ci_above_threshold'], n60_08['p_lower_ci_above_threshold'],
             n100_08['p_lower_ci_above_threshold'], n150_08['p_lower_ci_above_threshold']),
          '',
          '**격자에 120 은 없다.** 권장값 120쌍은 이 표가 아니라 아래 4-4 의 축2 계산에서 나온다.',
          '',
          '**60쌍이 문턱 주장을 할 수 있는 최소선이고, 그것도 실제 일치가 0.8 일 때만이다.**',
          '',
          '### 4-3 · 참값이 문턱과 같으면 어떤 n 으로도 못 넘는다', '']
    at06 = [g(n, 0.6)['p_lower_ci_above_threshold'] for n in ns]
    L += ['κ참값 0.6 에서 P(하한>%.1f)이 모든 n 에서 %s ~ %s 다.' % (th, min(at06), max(at06)),
          '**당연한 결과이고, 그래서 "문턱을 넘었는가"라는 질문 자체가 위험하다.**',
          '참 일치가 문턱 언저리면 표본을 아무리 늘려도 결론이 안 난다.',
          '',
          '### 4-4 · 축2(거리)는 훨씬 더 크게 줄어든다', '',
          '거리 판정은 **두 판정자가 모두 이해축 SAME 으로 본 쌍**에서만 계산된다.',
          '우리 DEMO 실측 유지율은 **%s** 다.' % ret, '',
          '| 전체 n | 기대 축2 n (유지율 %s) | 유지율 0.55 | 유지율 0.60 |' % ret,
          '|---|---|---|---|']
    for n in ns:
        L.append('| %d | %d | %d | %d |' % (n, int(n * ret), int(n * 0.55), int(n * 0.60)))
    L += ['',
          '**거리 축에 대해 무언가 말하려면 전체 120쌍이 필요하다.** 위 표의 보수적 쪽(유지율 %s) 기준이다.' % ret,
          '', '---', '', '## 5 · 권고', '',
          '| | 값 | 근거 |', '|---|---|---|',
          '| **MINIMUM_FEASIBILITY_N** | **60쌍** | κ 0.8 일 때 문턱 주장 확률 %s. 축2 는 %d~%d쌍으로 빠듯 |'
          % (n60_08['p_lower_ci_above_threshold'], int(60 * ret), int(60 * 0.60)),
          '| **PREFERRED_N** | **120쌍** | **축2 근거.** 거리 축이 %d~%d쌍이 되어 처음 쓸 만해진다. '
          'κ 근거는 격자 양옆 · 100쌍 %s · 150쌍 %s |'
          % (int(120 * ret), int(120 * 0.60),
             n100_08['p_lower_ci_above_threshold'], n150_08['p_lower_ci_above_threshold']),
          '| 하지 말아야 할 것 | 40쌍으로 문턱 주장 | κ 0.7 이어도 확률 %s |'
          % n40_07['p_lower_ci_above_threshold'],
          '',
          '### 그런데 더 중요한 권고가 하나 있다', '',
          '**"κ 가 %.1f 을 넘었는가"를 1차 판정 기준으로 삼지 않는 편이 낫다.**' % th, '',
          '이유가 셋이다.', '',
          '1. 위 4-3 이 보여 주듯 참값이 문턱 근처면 어떤 표본으로도 결론이 안 난다',
          '2. Artstein & Poesio 2008 이 문턱 설정을 "little more than a **black art**" 라고 부른다',
          '3. 같은 논문이 권하는 것은 문턱을 맞히는 것이 아니라 **혼동행렬과 방법 보고**다', '',
          '그래서 A1 의 1차 산출물을 이렇게 바꾼다.', '',
          '- **주 산출물** · 축별 κ **점추정과 CI**, 그리고 **혼동행렬**',
          '- **부 산출물** · 문턱 비교는 참고로만. `κ %.1f` 은 **프로젝트 운영 기준**이라고 계속 명시' % th,
          '- **판정 규칙** · CI 가 문턱을 걸치면 "불확정"이지 실패가 아니다. 그때 고칠 것은 **지침**이다',
          '', '---', '', '## 6 · 이 시뮬레이션이 말하지 않는 것', '',
          '- **참 일치가 얼마일지는 모른다.** 위 표는 조건부다. 실제 κ 는 A1 을 돌려야 안다',
          '- 모형은 "확률 p 로 합의하고 아니면 독립"이라는 단순 구조다. 실제 판정자 오류는 범주별로 다를 수 있다',
          '- **이것은 통계적 정밀도 계산이지 "이만큼이면 POC 가 성공한다"가 아니다**',
          '- 판정자 훈련 효과는 모형에 없다. Bayerl & Paul 2011 에 따르면 훈련이 일치도를 11%p 올린다.',
          '  **표본을 늘리는 것보다 훈련이 싸고 효과가 클 수 있다**',
          '',
          '마지막 줄이 실무적으로 가장 중요하다.',
          '**60쌍을 120쌍으로 늘리는 비용과, 판정자를 제대로 훈련시키는 비용을 비교해야 한다.**',
          '', '---', '', '## 7 · 알려진 한계 · 셀 사이의 난수 공유', '',
          '`main()` 이 `random.Random(SEED)` **하나**를 만들어 모든 셀에 차례로 넘긴다.',
          '그래서 한 셀의 결과가 **그 앞에서 계산된 모든 셀에 의존한다.** 같은 코드에서는 결정적이지만',
          '(두 번 돌려 바이트 단위로 같은 것을 확인했다), **반복 수나 셀 순서를 바꾸면 셀마다의 값이 달라진다.**',
          '',
          '실제로 그 일이 있었다. 옛 판(반복 수가 달랐다)의 출력을 문서에 손으로 옮겨 적어 두었고,',
          '코드가 바뀐 뒤에도 그 숫자가 남아 있었다(ERR-06). **결론은 바뀌지 않았지만 숫자가 틀렸다.**',
          '',
          '**셀마다 독립 seed 를 주는 것이 옳다.** 지금 고치지 않은 이유는 그러면 기존 JSON 과 비교가 끊기기 때문이고,',
          '대신 이 보고서를 JSON 에서 생성하게 만들어 **손으로 옮겨 적는 경로를 없앴다.**',
          ]
    io.open(OUT, 'w', encoding='utf-8', newline='\n').write('\n'.join(L) + '\n')
    print('A1_SAMPLE_SIZE_REPORT.md · 셀 %d · n %s · κ %s' % (len(rows), ns, kappas))
    print('  핵심 · 40쌍 κ0.7 → %s · 60쌍 κ0.8 → %s · 100쌍 κ0.8 → %s · 150쌍 κ0.8 → %s'
          % (n40_07['p_lower_ci_above_threshold'], n60_08['p_lower_ci_above_threshold'],
             n100_08['p_lower_ci_above_threshold'], n150_08['p_lower_ci_above_threshold']))


if __name__ == '__main__':
    main()
