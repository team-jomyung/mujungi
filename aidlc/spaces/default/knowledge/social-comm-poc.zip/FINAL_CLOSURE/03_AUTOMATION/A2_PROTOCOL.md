# A2 PROTOCOL · LLM 판정기 타당성

2026-09-13 · F1~F8 을 실행 절차로 옮긴다. 코드는 `judge_harness/` 와 `bias_tests/`.

A2 가 재는 것은 **LLM 판정단이 A1 합의 gold 를 얼마나 재현하는가**다.
LLM 판정을 gold 라고 부르지 않는다. 결정적 필드를 정확도에 섞지 않는다. 문턱을 미리 고정하지 않는다.

---

## 1 · F1 · 판정 대상

| 필드 | 누가 정하나 | A2 대상 | 이유 |
|---|---|---|---|
| required_inference | LLM | **예** | 규칙으로 못 정한다 |
| perspective_structure | LLM | **예** | 같음 |
| decidable_by_evidence | LLM | **예** | 같음. 어느 데이터셋도 안 덮는 필드 |
| target_skill | 사용자 선택 → 규칙 | 아니오 | `blocked_at` 매핑 |
| direct_check_allowed | **판정** (예전에는 관계 → 규칙) | **예** | 관계만으로 정하면 "또래는 예 · 윗사람은 아니오" 라는 규범적 이분법이 된다. 부담 · 자리 · 위험이 함께 정한다 (`02_SCOPE/RELATIONSHIP_SCOPE.md`) |
| 변화 플래그 7종 | 규칙 | 아니오 | 입력 비교 |
| skill_identity · transfer_distance | 순수 함수 | 아니오 | 위 필드에서 계산 |

**"자동화율 X%"** 라는 숫자를 내지 않는 이유가 여기 있다. 결정적 필드를 섞으면 어떤 판정기든 70% 이상이 나온다.
A2 가 내는 숫자는 **네 필드에 대한** 정확도 · κ · 적용범위다. 결정적 필드는 `target_skill` 과 변화 플래그뿐이다.

---

## 2 · F2 · Gold 분할 · `gold_split.py`

```
A1 합의 gold (60~120쌍)
  ├ calibration  30%   프롬프트 문구 · rubric 표현을 고친다.        보고에 쓰지 않는다
  ├ development  30%   라우팅 문턱 · 앙상블 구성을 고른다.           보고에 쓰지 않는다
  └ held_out     40%   한 번 본다.                                  이 수치만 보고한다
```

| 규칙 | 구현 |
|---|---|
| **pair 단위 분할.** 한 쌍의 세 필드가 다른 묶음에 가지 않는다 | `split_once` 가 pair_id 로 나눈다 · `_assert_disjoint` |
| 층화 | `required_inference` gold 라벨 기준. 필드 바꿀 수 있음 |
| **작은 표본 대응** | `repeated_holdout(k=10)` · held_out 수치의 분포와 부트스트랩 CI 를 보고한다 |
| **감사 가능성** | `write_manifest` · 분할 목록 + sha256. **manifest 해시가 바뀌면 보고 수치 무효** |

**같은 예시로 프롬프트를 고치고 그 예시로 성능을 보고하지 않는다.** 이 문장 하나를 코드로 강제하는 것이 `gold_split.py` 의 전부다.

---

## 3 · F3 · 판정단 구성

| 항목 | 결정 | 근거 |
|---|---|---|
| 판정자 수 | **3** (A · B · C) | 홀수 · 만장일치/다수/불일치 구분 |
| 모델 계열 | **서로 다른 계열** | Verga 2024 PoLL (arXiv 2404.18796) |
| 생성 모델 | **판정단에서 제외** | 자기 선호 편향 · Panickssery 2024 (arXiv 2404.13076) |
| 입력 | rubric(규격 지침) + 두 상황 + 필드 하나 | 참조 답안이 없으므로 규격 지침을 rubric 으로 (Zheng 2023 · 참조 제공이 CoT 보다 효과 큼) |
| 출력 | **구조화** · `label ∈ {SAME, DIFFERENT, UNKNOWN}` · `confidence` · `reason` 한 문장 · `evidence_span` 원문 구간 | `build_prompt` 스키마 |
| UNKNOWN | **반드시 낼 수 있어야 한다** | 규격 · UNKNOWN 이 DIFFERENT 보다 먼저 |
| 순서 | **양방향** (AB · BA) | 위치 편향 측정 · Zheng 2023 |
| 판정단 라벨 | 만장일치면 그 라벨 · 아니면 **UNDETERMINED** | `run_panel` |
| API 키 | 환경변수만 · 코드 · zip 에 넣지 않음 | 표준 |
| 데이터 보관 | 비보관 옵트아웃 확인 | TalkBank 계열 조건 · PIPC 처분례 |

`HTTPProvider` 는 벤더 미정이라 `NotImplementedError` 다. **벤더 선택은 팀 결정**이고 코드 자리는 있다.

---

## 4 · F4 · 편향 시험 · `bias_tests/`

섭동은 **구조를 바꾸지 않고 표면만** 바꾼다. gold 는 그대로다. 판정이 바뀌면 편향이다.

| 섭동 | 무엇을 재나 | 판정 기준 |
|---|---|---|
| order_swap | 위치 편향 | `order_consistency` (harness) · flip_rate (bias_tests) |
| verbosity_A / B | 길이 편향 | 긴 쪽으로 SAME 이 몰리는가 |
| style_to_casual / formal | 말투 편향 | flip_rate |
| **relationship** | **관계 누출** | Core 세 필드는 관계의 입력이 아니다. 뒤집히면 규격 위반 판정 |
| name_neutralize | 이름·성별 누출 | flip_rate |
| paraphrase | 표면 의존 | flip_rate |
| generator_family | 자기 선호 | 같은 계열 대 다른 계열 정확도 차 |

출력 · 섭동별 `flip_rate` · `accuracy_original` · `accuracy_perturbed` · `delta` · `unknown_shift`.
**문턱을 두지 않는다.** 표를 보고 어느 섭동이 위험한지 읽는다.

`--demo` 는 EchoProvider 라 **모든 섭동에서 뒤집힌다.** 텍스트 해시로 라벨을 만들기 때문이다. 배선 확인일 뿐이다.

---

## 5 · F5 · 확신 · 무엇을 믿고 무엇을 안 믿나

| 신호 | 문헌 | 우리 사용 |
|---|---|---|
| **말로 표현한 확신** | Jung 2024 · GPT-4-turbo 에서도 ECE 0.215~0.217 · Xiong 2024 · 과신 | **라우팅에 단독으로 쓰지 않는다.** ECE 만 보고한다 |
| **순서 일관성** | 두 순서에서 같은 라벨 | 라우팅 조건 1 |
| **판정단 합의** | 셋이 같은 라벨 | 라우팅 조건 2 |
| **자기 일관성** | 같은 질문 k회 샘플링 | 벤더 연결 후. Provider 가 `sample=True` 지원하면 |
| logprob | 벤더가 주면 | 선택 |
| 보정 후 확신 | Jung 2024 Simulated Annotators · ECE 0.039~0.095 | **development 묶음에서 보정기를 학습**해 쓸 수 있다. 500건 보정셋이 문헌 값 · 우리는 그보다 작다 |

**AG 측정** · 필드별 `accuracy_on_decided` 가 곧 Dorner 정리의 `AG(m)` 다.
이 값이 **0.5 ≤ AG ≤ b(m)** 구간에 있는 필드는 정리의 2배 한계가 묶이고, 밖이면 묶이지 않는다.
**필드별로 확인해 보고서에 적는다.** 유사도 판정기가 필드에 따라 AUC 0.58 / 0.86 으로 갈리므로 필드별 확인이 필요하다.

---

## 6 · F6 · 지표

| 지표 | 단위 | 구현 |
|---|---|---|
| accuracy (decided) | 필드 | `analyze` |
| macro F1 | 필드 | `analyze` |
| Cohen κ vs gold | 필드 | `analyze` |
| 혼동행렬 (gold × 판정단 · UNDETERMINED 열 포함) | 필드 | `analyze` |
| ECE | 전체 | `ece` |
| coverage (자동 확정 비율) · human review rate · false confident rate | 문턱별 | `routing_curve` |
| error by skill · relationship · text length · style | 필드 × 층 | **gold CSV 에 `target_skill` · `relationship_type` 열이 있으면** 층별 재계산. `a2_breakdowns.py` |
| AG (판정단 정확도 · 필드별) | 필드 | `accuracy_on_decided` 를 AG 로 읽는다 |

**held_out 에서만 낸다.** repeated holdout 이면 k 개 수치의 중앙값과 범위, 부트스트랩 CI.

---

## 7 · F7 · 라우팅 곡선

문턱 0.00~1.00 을 0.05 간격으로 훑으며 · 자동 확정 = 만장일치 AND 평균 확신 ≥ 문턱.

| 문턱 | 자동화율 | 사람 검토율 | 잘못된 확신율 |
|---|---|---|---|
| (곡선) | | | |

**문턱을 미리 고정하지 않는다.** 곡선을 보고 팀이 고른다. 참조점 하나 ·
Jung 2024 는 목표 일치 0.90 에서 적용범위 55.7%, 0.85 에서 63.2% 였다(보정셋 500).
우리 값은 A2 를 돌려야 안다. 현재 곡선은 `ROUTING_POLICY_REPORT.md` 에 있고 **EchoProvider 라 형식만 유효**하다.

---

## 8 · F8 · Dorner 정리 · 적용 진술

`01_EVIDENCE/THEOREM_AND_PRECEDENT.md` §1.8 과 `FINAL_CLOSURE_REPORT.html` B-1 에 있다. 요약 ·

- **묶이는 곳** · 집계 지표를 gold+판정단 혼합 추정량으로 보고할 때. 증폭 최대 2배. PPI 도 안이다
- **묶이지 않는 곳** · 확신 기반 라우팅. Theorem 5 적용범위 조항(prompt-conditional 분포를 모형화하지 않는 추정량) 밖
- **검증** · §5 의 AG 를 필드별로 잰다
- **인용하지 않는 것** · 절감 백분율. 논문이 발표하지 않았다

---

## 9 · 절차

```
A1 합의 gold 확정
  → gold_split.py · manifest 저장 · 해시 기록
  → HTTPProvider 3개 등록 (서로 다른 계열 · 생성 모델 제외 · 환경변수 키)
  → calibration 묶음으로 rubric 문구 조정 (필요하면 · 횟수 기록)
  → development 묶음으로 라우팅 곡선 · 앙상블 구성 확인
  → held_out 한 번 · 필드별 지표 · AG · ECE · 편향 시험 전부
  → 보고 · manifest 해시와 함께
```

**held_out 을 본 뒤 프롬프트를 고치면 그 뒤의 수치는 held_out 수치가 아니다.** 다시 분할해야 한다.

---

## 10 · 이 문서가 정하지 않은 것

- 벤더와 모델 · 팀 결정
- 라우팅 문턱 · 곡선을 보고
- **판정기가 쓸 만할지** · 돌려야 안다. JUDGE-BENCH 의 주관 과제 최고 판정자 평균 κ 가 0.28 이었다는 것만 기대치로 적어 둔다
