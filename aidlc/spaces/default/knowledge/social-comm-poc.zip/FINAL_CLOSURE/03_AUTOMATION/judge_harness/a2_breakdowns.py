# -*- coding: utf-8 -*-
"""F6 층별 오류 분해. 필드별 지표를 skill / relationship / 텍스트 길이 / 말투 층으로 다시 낸다.

    python a2_breakdowns.py --records <recs.json> --gold <gold.csv>

recs 는 judge_harness.run_panel 의 출력(pair_id, field, gold, panel_label ...) 이고
gold CSV 에 target_skill, relationship_type 열이 있으면 그 층을 쓴다. 없으면 그 층은 건너뛴다.
텍스트 길이 층은 event_A + event_B 글자 수의 삼분위. 말투 층은 종결어미로 격식/구어를 나눈다.

층별 n 이 작으면 수치가 흔들린다. n 을 항상 같이 낸다. 층별 n < 10 이면 reportable=false.
"""
from __future__ import annotations

import argparse
import csv
import io
import json
import re
import sys
from collections import defaultdict

MIN_N = 10
FORMAL = re.compile(r'(습니다|입니다|하였다|하십니까)')


def style_of(text):
    return 'formal' if FORMAL.search(text or '') else 'casual'


def length_bin(n, cuts):
    if n <= cuts[0]:
        return 'short'
    if n <= cuts[1]:
        return 'mid'
    return 'long'


def kappa(pairs):
    n = len(pairs)
    if n < 2:
        return None
    cats = sorted({x for p in pairs for x in p})
    agree = sum(1 for a, b in pairs if a == b) / n
    pe = sum((sum(1 for a, _ in pairs if a == c) / n) * (sum(1 for _, b in pairs if b == c) / n) for c in cats)
    return None if abs(1 - pe) < 1e-12 else round((agree - pe) / (1 - pe), 3)


def breakdown(recs, meta):
    """meta[pair_id] = {'target_skill','relationship_type','length','style'} (있는 것만)."""
    strata = {'target_skill': defaultdict(list), 'relationship_type': defaultdict(list),
              'length': defaultdict(list), 'style': defaultdict(list)}
    for r in recs:
        m = meta.get(r['pair_id'], {})
        for axis in strata:
            if axis in m:
                strata[axis][(r['field'], m[axis])].append((r['gold'], r['panel_label']))
    out = {}
    for axis, groups in strata.items():
        if not groups:
            continue
        out[axis] = {}
        for (field, level), pairs in sorted(groups.items()):
            decided = [p for p in pairs if p[1] != 'UNDETERMINED']
            out[axis].setdefault(field, {})[level] = {
                'n': len(pairs),
                'reportable': len(pairs) >= MIN_N,
                'undetermined': sum(1 for p in pairs if p[1] == 'UNDETERMINED'),
                'accuracy_on_decided': round(sum(1 for g, p in decided if g == p) / len(decided), 3) if decided else None,
                'kappa': kappa(decided),
            }
    return out


def load_meta(gold_csv, recs):
    rows = list(csv.DictReader(io.open(gold_csv, encoding='utf-8-sig', newline='')))
    lens = []
    meta = {}
    for r in rows:
        pid = (r.get('pair_id') or '').strip()
        if not pid:
            continue
        text = (r.get('event_A') or '') + (r.get('event_B') or '')
        m = {'style': style_of(text), '_len': len(text)}
        for k in ('target_skill', 'relationship_type'):
            if r.get(k):
                m[k] = r[k].strip()
        meta[pid] = m
        lens.append(len(text))
    if lens:
        lens.sort()
        cuts = (lens[len(lens) // 3], lens[2 * len(lens) // 3])
        for m in meta.values():
            m['length'] = length_bin(m.pop('_len'), cuts)
    return meta


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--records', required=True)
    ap.add_argument('--gold', required=True)
    ap.add_argument('--out', default='results/a2_breakdowns.json')
    a = ap.parse_args()
    recs = json.load(io.open(a.records, encoding='utf-8'))
    meta = load_meta(a.gold, recs)
    rep = breakdown(recs, meta)
    rep['note'] = '층별 n < %d 는 reportable=false. 수치를 읽지 않는다' % MIN_N
    io.open(a.out, 'w', encoding='utf-8').write(json.dumps(rep, ensure_ascii=False, indent=2))
    print('축', list(k for k in rep if k != 'note'), '· 저장', a.out)
    return 0


if __name__ == '__main__':
    sys.exit(main())
