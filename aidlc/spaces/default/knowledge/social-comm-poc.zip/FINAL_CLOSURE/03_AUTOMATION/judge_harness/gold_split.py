# -*- coding: utf-8 -*-
"""A2 gold split. 같은 예시로 프롬프트를 고치고 그 예시로 성능을 보고하지 않기 위한 장치.

    from gold_split import split_once, repeated_holdout, write_manifest

세 묶음
  calibration   프롬프트와 rubric 문구를 고치는 데 쓴다. 성능 보고에 쓰지 않는다
  development   라우팅 문턱과 앙상블 구성을 고르는 데 쓴다. 성능 보고에 쓰지 않는다
  held_out      한 번만 본다. 여기서 나온 수치만 보고한다

표본이 작으면 (A1 gold 60~120쌍) 한 번의 분할은 운에 좌우된다.
그래서 repeated stratified holdout 을 기본으로 둔다. K 번 분할하고 held_out 수치의 분포를 보고한다.

층화 기준은 pair 단위의 gold 라벨이다. 한 쌍의 세 필드가 서로 다른 묶음에 가면
같은 텍스트를 보고 튜닝하게 되므로 반드시 pair_id 단위로 나눈다.

분할 결과는 manifest 로 남긴다. 어느 pair 가 어느 묶음이었는지와 그 해시가 남아야
"held_out 에서 나온 숫자"라는 말이 검증 가능하다.
"""
from __future__ import annotations

import hashlib
import io
import json
import random
from collections import defaultdict

DEFAULT_FRACTIONS = {'calibration': 0.30, 'development': 0.30, 'held_out': 0.40}


def _strata(items, field):
    """pair 를 지정 필드의 gold 라벨로 층화한다. 라벨이 없으면 'NA' 층."""
    strata = defaultdict(list)
    for it in items:
        strata[it.get('gold', {}).get(field, 'NA')].append(it['pair_id'])
    return strata


def split_once(items, seed, field='required_inference', fractions=None):
    """한 번 층화 분할. pair_id 목록 셋을 돌려준다. 어떤 pair 도 두 묶음에 들어가지 않는다."""
    fr = fractions or DEFAULT_FRACTIONS
    assert abs(sum(fr.values()) - 1.0) < 1e-9, '비율 합이 1 이어야 한다'
    rng = random.Random(seed)
    out = {k: [] for k in fr}
    for label, pids in sorted(_strata(items, field).items()):
        pids = sorted(pids)
        rng.shuffle(pids)
        n = len(pids)
        cuts, acc = [], 0
        keys = list(fr)
        for k in keys[:-1]:
            acc += int(round(fr[k] * n))
            cuts.append(acc)
        parts = [pids[:cuts[0]]] + [pids[cuts[i]:cuts[i + 1]] for i in range(len(cuts) - 1)] + [pids[cuts[-1]:]]
        for k, p in zip(keys, parts):
            out[k].extend(p)
    _assert_disjoint(out)
    return out


def _assert_disjoint(split):
    seen = {}
    for k, pids in split.items():
        for p in pids:
            assert p not in seen, 'pair %s 가 %s 와 %s 두 묶음에 있다' % (p, seen[p], k)
            seen[p] = k


def repeated_holdout(items, k=10, seed=20260913, field='required_inference', fractions=None):
    """K 번 분할. 각 분할은 다른 seed. held_out 수치의 분포를 보고하는 데 쓴다."""
    return [split_once(items, seed + i, field, fractions) for i in range(k)]


def select(items, pids):
    s = set(pids)
    return [it for it in items if it['pair_id'] in s]


def manifest(split, seed, field, gold_path=None):
    """분할을 해시와 함께 기록한다. held_out 을 보고 프롬프트를 고쳤는지 나중에 검증하는 근거."""
    body = json.dumps({k: sorted(v) for k, v in split.items()}, sort_keys=True, ensure_ascii=False)
    return {
        'seed': seed,
        'stratify_field': field,
        'gold_path': gold_path,
        'counts': {k: len(v) for k, v in split.items()},
        'split': {k: sorted(v) for k, v in split.items()},
        'sha256': hashlib.sha256(body.encode('utf-8')).hexdigest(),
        'rule': 'calibration 과 development 만 보고 프롬프트와 문턱을 고친다. '
                'held_out 은 한 번 본다. 이 파일의 해시가 바뀌면 보고 수치는 무효다',
    }


def write_manifest(path, split, seed, field, gold_path=None):
    m = manifest(split, seed, field, gold_path)
    io.open(path, 'w', encoding='utf-8').write(json.dumps(m, ensure_ascii=False, indent=2))
    return m


def bootstrap_ci(values, n_boot=2000, seed=20260912, alpha=0.05):
    """held_out 반복 수치나 항목 단위 정답 여부에 대한 백분위 부트스트랩 CI."""
    if not values:
        return None
    rng = random.Random(seed)
    n = len(values)
    means = []
    for _ in range(n_boot):
        s = [values[rng.randrange(n)] for _ in range(n)]
        means.append(sum(s) / n)
    means.sort()
    lo = means[int(alpha / 2 * n_boot)]
    hi = means[min(n_boot - 1, int((1 - alpha / 2) * n_boot))]
    return {'point': round(sum(values) / n, 4), 'ci95': [round(lo, 4), round(hi, 4)], 'n': n}


if __name__ == '__main__':
    import sys
    rng = random.Random(1)
    labels = ('SAME', 'DIFFERENT', 'UNKNOWN')
    demo = [{'pair_id': 'P%02d' % i,
             'gold': {'required_inference': rng.choice(labels)}} for i in range(1, 61)]
    sp = split_once(demo, seed=20260913)
    print('한 번 분할 ·', {k: len(v) for k, v in sp.items()})
    reps = repeated_holdout(demo, k=5)
    print('반복 5회 · held_out 크기', [len(r['held_out']) for r in reps])
    m = manifest(sp, 20260913, 'required_inference')
    print('manifest sha256', m['sha256'][:16])
    print('bootstrap 예시', bootstrap_ci([1, 0, 1, 1, 0, 1, 1, 1, 0, 1]))
    sys.exit(0)
