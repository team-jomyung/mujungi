# -*- coding: utf-8 -*-
"""POC A2 · LLM 판정단 보정 harness.

  python judge_harness.py --gold <A1합의.csv> --providers echo,echo2 --out results
  python judge_harness.py --demo            판정자 없이 구조만 확인한다

무엇을 하는가
  A1 에서 사람 둘이 합의한 gold 를 기준으로 LLM 판정단이 얼마나 재현하는지 잰다.

무엇을 하지 않는가
  * LLM 판정을 gold 라고 부르지 않는다
  * 결정적 필드를 LLM 정확도 숫자에 섞지 않는다
  * 문턱을 미리 고정하지 않는다. 라우팅 곡선을 내고 고르게 한다
  * API key 를 코드에 넣지 않는다. 환경변수만 읽는다

설계 근거
  판정 대상을 세 필드로 한정한다. 나머지는 규칙으로 결정되므로 섞으면 수가 부풀려진다.
  모델군을 분리한다 (Verga 2024 PoLL · arXiv 2404.18796).
  생성 모델은 판정단에서 뺀다 (Panickssery 2024 · arXiv 2404.13076).
  순서를 양방향으로 물어 위치 편향을 잰다 (Zheng 2023 · arXiv 2306.05685).
  말로 표현한 확신을 그대로 쓰지 않는다 (Jung 2024 · arXiv 2407.18370, ECE 0.22).
"""

import argparse
import csv
import io
import json
import os
import random
import sys

HERE = os.path.dirname(os.path.abspath(__file__))

# ── 판정 대상 · LLM 이 필요한 필드만
JUDGED_FIELDS = ('required_inference', 'perspective_structure', 'decidable_by_evidence',
                 'direct_check_allowed')
# direct_check_allowed 는 예전에 결정적 필드였다(관계에서 규칙으로 파생). 그것이 곧
# '또래는 예 · 윗사람은 아니오' 라는 규범적 이분법이라 판정 필드로 옮겼다. 02_SCOPE/RELATIONSHIP_SCOPE.md

# ── 결정적 필드 · 여기 섞으면 자동화율이 부풀려진다
DETERMINISTIC_FIELDS = ('target_skill',
                        'topic_changed', 'place_changed', 'participants_changed',
                        'relationship_changed', 'situation_type_changed')

LABELS = ('SAME', 'DIFFERENT', 'UNKNOWN')


# ─────────────────────── provider 추상화 ───────────────────────

class Provider(object):
    """판정자 하나. 모델군이 서로 다르게 구성해야 한다."""

    name = 'base'
    family = 'base'

    def judge(self, item, field, order):
        """(label, confidence, reason, evidence_span) 를 돌려준다.

        order 는 'AB' 또는 'BA'. 같은 항목을 양방향으로 물어 위치 편향을 잰다.
        구현체는 반드시 UNKNOWN 을 낼 수 있어야 한다."""
        raise NotImplementedError


class EchoProvider(Provider):
    """결정적 더미. API 없이 harness 배선을 확인한다.

    실제 판정이 아니다. 이 출력으로 어떤 성능도 주장하지 않는다."""

    def __init__(self, name='echo', family='echo', bias=0.0, seed=1):
        self.name, self.family = name, family
        self.bias = bias
        self.rng = random.Random(seed)

    def judge(self, item, field, order):
        # 텍스트 해시로 결정적 라벨을 만든다. 내용 이해가 아니다
        h = hash((item['pair_id'], field, self.name)) % 100
        if h < 15:
            lab = 'UNKNOWN'
        elif h < 15 + int(50 + self.bias * 100):
            lab = 'SAME'
        else:
            lab = 'DIFFERENT'
        # 위치 편향 주입 · bias 가 0 이 아니면 순서에 따라 답이 흔들린다
        if order == 'BA' and self.rng.random() < abs(self.bias):
            lab = 'SAME' if lab == 'DIFFERENT' else lab
        conf = 0.5 + (h % 40) / 100.0
        return lab, conf, 'echo provider · 실제 판정 아님', ''


class HTTPProvider(Provider):
    """실제 모델 호출 자리. 벤더 선택은 팀 결정이므로 비워 둔다.

    반드시 지킬 것
      * API key 는 환경변수에서만 읽는다. 코드와 zip 에 넣지 않는다
      * 판정 지침(rubric)을 프롬프트에 넣는다. reference 가 CoT 보다 효과가 크다
      * 구조화 출력으로 받는다. UNKNOWN 과 근거 구간을 반드시 포함시킨다
      * 데이터 비보관 옵션을 켠다. TalkBank 계열 자료를 쓸 때 필수 조건이다
    """

    def __init__(self, name, family, model, env_key):
        self.name, self.family, self.model = name, family, model
        self.env_key = env_key

    def judge(self, item, field, order):
        key = os.environ.get(self.env_key)
        if not key:
            raise RuntimeError(
                '%s 가 환경변수에 없다. 코드에 키를 넣지 않는다.' % self.env_key)
        raise NotImplementedError(
            'TODO · 벤더 SDK 호출. 팀이 모델을 정한 뒤 채운다. '
            '구조화 출력 스키마는 build_prompt 참조')


def build_prompt(item, field, order, rubric):
    """판정 프롬프트. 참조 답안 대신 rubric 을 준다.

    Zheng 2023 에서 참조 제공이 실패율을 70%->15% 로 낮췄고
    사고연쇄는 70%->30% 에 그쳤다. 우리에게는 정답이 없으므로
    참조 대신 규격 지침을 rubric 으로 준다."""
    a, b = (item['event_A'], item['event_B']) if order == 'AB' \
        else (item['event_B'], item['event_A'])
    return {
        'system': '두 상황을 읽고 한 항목만 판정한다. 모르면 UNKNOWN 을 낸다. '
                  'UNKNOWN 은 정당한 답이고 억지로 고르지 않는다.',
        'rubric': rubric.get(field, ''),
        'situation_1': a,
        'situation_2': b,
        'field': field,
        'output_schema': {
            'label': 'SAME | DIFFERENT | UNKNOWN',
            'confidence': '0.0 ~ 1.0',
            'reason': '한 문장',
            'evidence_span': '판단 근거로 삼은 원문 구간. 없으면 빈 문자열',
        },
    }


# ─────────────────────── 실행 ───────────────────────

def load_gold(path):
    with io.open(path, encoding='utf-8-sig', newline='') as f:
        rows = list(csv.DictReader(f))
    out = []
    for r in rows:
        pid = (r.get('pair_id') or '').strip()
        if not pid:
            continue
        item = {'pair_id': pid,
                'event_A': r.get('event_A', ''),
                'event_B': r.get('event_B', ''),
                'gold': {}}
        for fld in JUDGED_FIELDS:
            v = (r.get(fld) or '').strip().upper()
            if v in LABELS:
                item['gold'][fld] = v
        out.append(item)
    return out


def run_panel(items, providers, rubric, both_orders=True):
    recs = []
    orders = ('AB', 'BA') if both_orders else ('AB',)
    for it in items:
        for fld in JUDGED_FIELDS:
            if fld not in it['gold']:
                continue
            votes = {}
            for p in providers:
                per_order = {}
                for o in orders:
                    lab, conf, reason, span = p.judge(it, fld, o)
                    per_order[o] = {'label': lab, 'confidence': conf,
                                    'reason': reason, 'evidence_span': span}
                votes[p.name] = {
                    'family': p.family,
                    'orders': per_order,
                    'order_consistent': len({v['label'] for v in per_order.values()}) == 1,
                    'label': per_order['AB']['label'],
                    'confidence': per_order['AB']['confidence'],
                }
            labels = [v['label'] for v in votes.values()]
            agree = len(set(labels)) == 1
            recs.append({
                'pair_id': it['pair_id'], 'field': fld,
                'gold': it['gold'][fld],
                'votes': votes,
                'panel_label': labels[0] if agree else 'UNDETERMINED',
                'panel_unanimous': agree,
                'all_order_consistent': all(v['order_consistent'] for v in votes.values()),
                'mean_confidence': sum(v['confidence'] for v in votes.values()) / len(votes),
            })
    return recs


# ─────────────────────── 지표 ───────────────────────

def kappa(pairs):
    n = len(pairs)
    if not n:
        return None
    cats = sorted({x for p in pairs for x in p})
    agree = sum(1 for a, b in pairs if a == b) / n
    pe = sum((sum(1 for a, _ in pairs if a == c) / n) *
             (sum(1 for _, b in pairs if b == c) / n) for c in cats)
    return None if abs(1 - pe) < 1e-12 else (agree - pe) / (1 - pe)


def macro_f1(pairs):
    cats = sorted({x for p in pairs for x in p})
    fs = []
    for c in cats:
        tp = sum(1 for g, p in pairs if g == c and p == c)
        fp = sum(1 for g, p in pairs if g != c and p == c)
        fn = sum(1 for g, p in pairs if g == c and p != c)
        prec = tp / (tp + fp) if tp + fp else 0.0
        rec = tp / (tp + fn) if tp + fn else 0.0
        fs.append(2 * prec * rec / (prec + rec) if prec + rec else 0.0)
    return sum(fs) / len(fs) if fs else None


def ece(recs, bins=10):
    """확신 보정 오차. 말로 표현한 확신은 과신한다는 것이 문헌 결과다."""
    buckets = [[] for _ in range(bins)]
    for r in recs:
        c = min(max(r['mean_confidence'], 0.0), 0.999)
        buckets[int(c * bins)].append((c, 1 if r['panel_label'] == r['gold'] else 0))
    n = sum(len(b) for b in buckets)
    if not n:
        return None
    tot = 0.0
    for b in buckets:
        if not b:
            continue
        conf = sum(x[0] for x in b) / len(b)
        acc = sum(x[1] for x in b) / len(b)
        tot += (len(b) / n) * abs(conf - acc)
    return tot


def routing_curve(recs):
    """문턱을 고정하지 않는다. 곡선을 내고 사람이 고르게 한다."""
    out = []
    for th in [i / 20.0 for i in range(0, 21)]:
        auto = [r for r in recs if r['panel_unanimous'] and r['mean_confidence'] >= th]
        rev = [r for r in recs if r not in auto]
        wrong = [r for r in auto if r['panel_label'] != r['gold']]
        out.append({
            'threshold': round(th, 2),
            'automation_coverage': round(len(auto) / len(recs), 3) if recs else 0,
            'human_review_rate': round(len(rev) / len(recs), 3) if recs else 0,
            'false_confident_rate': round(len(wrong) / len(auto), 3) if auto else None,
            'n_auto': len(auto), 'n_review': len(rev), 'n_wrong': len(wrong),
        })
    return out


def bias_report(recs):
    tot = len(recs)
    order_ok = sum(1 for r in recs if r['all_order_consistent'])
    fam = {}
    for r in recs:
        for name, v in r['votes'].items():
            d = fam.setdefault(v['family'], {'n': 0, 'correct': 0})
            d['n'] += 1
            d['correct'] += 1 if v['label'] == r['gold'] else 0
    return {
        'order_consistency': round(order_ok / tot, 3) if tot else None,
        'by_family': {k: {'n': v['n'],
                          'accuracy': round(v['correct'] / v['n'], 3) if v['n'] else None}
                      for k, v in fam.items()},
        'note': '순서 비일관은 위치 편향이다. 계열별 정확도 차이는 판정단 구성 문제다',
    }


def analyze(recs):
    rep = {'n_judgements': len(recs), 'by_field': {}}
    for fld in JUDGED_FIELDS:
        sub = [r for r in recs if r['field'] == fld]
        if not sub:
            continue
        pairs = [(r['gold'], r['panel_label']) for r in sub]
        decided = [p for p in pairs if p[1] != 'UNDETERMINED']
        rep['by_field'][fld] = {
            'n': len(sub),
            'panel_undetermined': sum(1 for p in pairs if p[1] == 'UNDETERMINED'),
            'accuracy_on_decided': round(
                sum(1 for g, p in decided if g == p) / len(decided), 3) if decided else None,
            'kappa_vs_gold': round(kappa(decided), 3) if len(decided) > 1 and kappa(decided) is not None else None,
            'macro_f1': round(macro_f1(decided), 3) if decided else None,
            'confusion': {'%s->%s' % (g, p): sum(1 for a, b in pairs if a == g and b == p)
                          for g in LABELS for p in list(LABELS) + ['UNDETERMINED']
                          if sum(1 for a, b in pairs if a == g and b == p)},
        }
    rep['calibration_ece'] = round(ece(recs), 3) if recs else None
    rep['bias'] = bias_report(recs)
    rep['routing_curve'] = routing_curve(recs)
    rep['caveats'] = [
        '결정적 필드는 이 수치에 들어 있지 않다. 자동화율을 말할 때 섞지 않는다',
        '말로 표현한 확신은 과신한다(문헌 ECE 약 0.22). 라우팅은 판정단 합의와 함께 본다',
        '문턱을 고정하지 않았다. routing_curve 를 보고 고른다',
        'EchoProvider 출력으로는 어떤 성능도 주장할 수 없다',
    ]
    return rep


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--gold', default=None, help='A1 사람 합의 CSV')
    ap.add_argument('--rubric', default=None, help='판정 지침 JSON')
    ap.add_argument('--out', default='results')
    ap.add_argument('--demo', action='store_true', help='EchoProvider 로 배선만 확인')
    args = ap.parse_args()

    rubric = {}
    if args.rubric and os.path.exists(args.rubric):
        rubric = json.loads(io.open(args.rubric, encoding='utf-8').read())

    if args.demo or not args.gold:
        print('=' * 62)
        print('  DEMO · EchoProvider 로 배선만 확인한다')
        print('  실제 판정이 아니다. 이 숫자로 어떤 성능도 주장하지 않는다')
        print('=' * 62)
        rng = random.Random(7)
        items = []
        for i in range(1, 41):
            g = {f: rng.choice(LABELS) for f in JUDGED_FIELDS}
            items.append({'pair_id': 'P%02d' % i, 'event_A': '상황 A %d' % i,
                          'event_B': '상황 B %d' % i, 'gold': g})
        providers = [EchoProvider('echo_a', 'familyX', 0.0, 1),
                     EchoProvider('echo_b', 'familyY', 0.1, 2),
                     EchoProvider('echo_c', 'familyZ', 0.0, 3)]
    else:
        items = load_gold(args.gold)
        print('gold %d쌍 · 판정 대상 필드 %d개' % (len(items), len(JUDGED_FIELDS)))
        print('실제 provider 를 붙여야 한다. HTTPProvider 를 채운 뒤 여기 등록한다.')
        return 2

    recs = run_panel(items, providers, rubric)
    rep = analyze(recs)

    outdir = os.path.join(HERE, args.out)
    os.makedirs(outdir, exist_ok=True)
    io.open(os.path.join(outdir, 'a2_report.json'), 'w', encoding='utf-8').write(
        json.dumps(rep, ensure_ascii=False, indent=2))

    print()
    print('판정 %d건 · 필드 %d개' % (rep['n_judgements'], len(rep['by_field'])))
    for f, d in rep['by_field'].items():
        print('  %-26s n=%-4d 미결 %-3d 정확도 %-6s κ %-7s macroF1 %s'
              % (f, d['n'], d['panel_undetermined'], d['accuracy_on_decided'],
                 d['kappa_vs_gold'], d['macro_f1']))
    print('  보정 ECE %s · 순서 일관 %s'
          % (rep['calibration_ece'], rep['bias']['order_consistency']))
    print()
    print('라우팅 곡선 (일부)')
    print('  %-8s %-12s %-12s %s' % ('문턱', '자동화율', '사람검토율', '잘못된확신율'))
    for row in rep['routing_curve'][::4]:
        print('  %-8s %-12s %-12s %s'
              % (row['threshold'], row['automation_coverage'],
                 row['human_review_rate'], row['false_confident_rate']))
    print()
    print('저장 ·', os.path.join(outdir, 'a2_report.json'))
    return 0


if __name__ == '__main__':
    sys.exit(main())
