# -*- coding: utf-8 -*-
"""G3 · G4 보존 평가와 fallback 판정.

    python evaluate_preservation.py --records dryrun/preservation_records.jsonl \
                                    --human <사람 판정.csv> --key dryrun/_key_human_eval.csv
    python evaluate_preservation.py --demo     사람 판정을 모의로 만들어 판정 경로만 확인

무엇을 내나
  등급별    사람 기준 등급 일치율 (사람 이해 SAME AND 사람 거리 = 목표 등급)
            필드 보존율 (사람이 SAME 이라고 본 비율 · 넷)
            재생성 · 평균 시도 수
            계획 준수율 (판정자가 본 변화 축 = 계획이 바꾸라고 한 축)
            LLM pre-filter 와 사람의 등급 일치 (B 맥락에서 판정자 타당성)
  G4 판정   FAR_ENABLED / SAME_NEAR_MVP / BANK_ONLY / BLOCKED

문턱은 RC1 04_POC_B_SCAFFOLD/preservation_metrics.py 의 T 를 그대로 가져온다. 여기서 숫자를 다시 적지 않는다.
전부 PROJECT OPERATING THRESHOLD 다 (규격 §11.4).

판정 규칙 (G4)
  A 가 PASS 가 아니면                          BLOCKED · 공식 판정 없음
  SAME_CONTEXT 또는 NEAR 가 FAIL               BANK_ONLY · 사전 작성 시나리오 은행으로 간다
  FAR 가 FAIL 또는 RETRY                       SAME_NEAR_MVP · FAR 는 끈다. RETRY 면 프롬프트 수정 뒤 1회 재측정
  셋 다 PASS                                   FAR_ENABLED
  등급의 결과 = 등급 일치율 · 필드 보존 · 평균 시도 셋 중 가장 나쁜 것
"""
from __future__ import annotations

import argparse
import csv
import io
import json
import os
import random
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
RC1 = os.path.normpath(os.path.join(HERE, '..', '..', '..', 'poc_validation_v0_1'))
sys.path.insert(0, os.path.join(RC1, '04_POC_B_SCAFFOLD'))
sys.path.insert(0, os.path.join(RC1, '02_POC_A'))

from preservation_metrics import T, poc_a_passed  # noqa: E402
from rule_engine import skill_identity, transfer_distance, SAME  # noqa: E402

GRADES = ('SAME_CONTEXT', 'NEAR', 'FAR')
PRESERVE = ('required_inference', 'perspective_structure', 'decidable_by_evidence', 'direct_check_allowed')
RANK = {'PASS': 0, 'RETRY': 1, 'FAIL': 2, 'NA': 3}


def load_records(path):
    return [json.loads(l) for l in io.open(path, encoding='utf-8') if l.strip()]


def attach_human(records, human_csv, key_csv):
    key = {r['item_id']: r['candidate_id'] for r in csv.DictReader(io.open(key_csv, encoding='utf-8-sig'))}
    by = {r['candidate_id']: r for r in records}
    for h in csv.DictReader(io.open(human_csv, encoding='utf-8-sig')):
        cid = key.get(h['item_id'])
        if not cid or cid not in by:
            continue
        ann = {
            'target_skill': h['human_target_skill'], 'required_inference': h['human_required_inference'],
            'perspective_structure': h['human_perspective_structure'],
            'decidable_by_evidence': h['human_decidable_by_evidence'],
            'direct_check_allowed': h['human_direct_check_allowed'],
            'relationship_changed': h['human_relationship_changed'],
            'situation_type_changed': h['human_situation_type_changed'],
            'misread_cost_changed': h['human_misread_cost_changed'],
            'recoverability_changed': h['human_recoverability_changed'],
            'topic_changed': 'CHANGED', 'place_changed': 'CHANGED', 'participants_changed': 'CHANGED',
        }
        if not all(ann[f] for f in ann):
            continue
        si = skill_identity(ann, 'understand')
        r = by[cid]
        r['human_skill_identity_understand'] = si
        r['human_skill_identity_perform'] = skill_identity(ann, 'perform')
        r['human_distance'] = transfer_distance(ann, si)
        r['human_field_preservation'] = {f: ann[f] for f in PRESERVE}
    return records


def demo_human(records, agree=0.85, seed=20260914):
    """모의 사람 판정. 생성기 내부 진실(_dryrun_truth)을 기준으로 agree 확률로 맞게 적는다. DEMO 전용."""
    rng = random.Random(seed)
    for r in records:
        if not r['accepted_by_prefilter']:
            continue
        t = r.get('_dryrun_truth') or {}
        true_same = not t.get('broke')
        si = 'SAME' if (true_same if rng.random() < agree else not true_same) else 'DIFFERENT'
        true_dist = r['target_grade'] if not t.get('overchange') else ('FAR' if r['target_grade'] != 'FAR' else 'NEAR')
        dist = true_dist if rng.random() < agree else rng.choice(GRADES)
        r['human_skill_identity_understand'] = si
        r['human_distance'] = dist if si == SAME else 'NOT_COMPUTED'
        r['human_field_preservation'] = {f: ('SAME' if (si == SAME or f != 'required_inference') else 'DIFFERENT')
                                         for f in PRESERVE}
    return records


def grade_result(value, th, higher_better=True):
    if value is None:
        return 'NA'
    if higher_better:
        return 'PASS' if value >= th['pass'] else ('RETRY' if value >= th['retry'] else 'FAIL')
    return 'PASS' if value <= th['pass'] else ('RETRY' if value <= th['retry'] else 'FAIL')


def summarize(records):
    out = {}
    for g in GRADES:
        sub = [r for r in records if r['target_grade'] == g]
        judged = [r for r in sub if r['human_skill_identity_understand'] is not None]
        match = [r for r in judged if r['human_skill_identity_understand'] == SAME and r['human_distance'] == g]
        pres = {}
        for f in PRESERVE:
            vals = [r['human_field_preservation'][f] for r in judged if r['human_field_preservation']]
            pres[f] = round(sum(1 for v in vals if v == SAME) / len(vals), 3) if vals else None
        llm_h = [r for r in judged if r['accepted_by_prefilter']]
        out[g] = {
            'n_candidates': len(sub), 'n_human_judged': len(judged),
            'grade_accuracy_human': round(len(match) / len(judged), 3) if judged else None,
            'core_preservation_min': min(v for v in pres.values() if v is not None) if any(v is not None for v in pres.values()) else None,
            'core_preservation': pres,
            'avg_attempts': round(sum(r['attempts'] for r in sub) / len(sub), 3) if sub else None,
            'first_pass_rate': round(sum(1 for r in sub if r['attempts'] == 1 and r['accepted_by_prefilter']) / len(sub), 3) if sub else None,
            'plan_adherence': round(sum(1 for r in sub if r['plan_adherence']['adheres']) / len(sub), 3) if sub else None,
            'prefilter_vs_human_grade_agreement': round(
                sum(1 for r in llm_h if (r['llm_distance'] == r['human_distance'])) / len(llm_h), 3) if llm_h else None,
        }
    return out


def decide(summary, a_passed):
    per = {}
    for g in GRADES:
        s = summary[g]
        parts = {
            'grade_accuracy': grade_result(s['grade_accuracy_human'], T['grade_accuracy'][g]),
            'core_preservation': grade_result(s['core_preservation_min'], T['core_preservation']),
            'avg_attempts': grade_result(s['avg_attempts'], T['avg_attempts'], higher_better=False),
        }
        worst = max(parts.values(), key=lambda x: RANK[x])
        per[g] = {'result': worst, 'parts': parts}
    if not a_passed:
        verdict, why = 'BLOCKED', 'POC A 가 PASS 가 아니다. 사람 판정의 기준이 없으므로 공식 판정을 내지 않는다'
    elif per['SAME_CONTEXT']['result'] in ('FAIL', 'NA') or per['NEAR']['result'] in ('FAIL', 'NA'):
        verdict, why = 'BANK_ONLY', 'SAME_CONTEXT 또는 NEAR 가 실패했다. 사전 작성 시나리오 은행으로 간다'
    elif per['FAR']['result'] in ('FAIL', 'RETRY', 'NA'):
        verdict = 'SAME_NEAR_MVP'
        why = 'FAR 가 %s 다. MVP 를 SAME + NEAR 로 제한한다' % per['FAR']['result']
        if per['FAR']['result'] == 'RETRY':
            why += '. 프롬프트를 고친 뒤 FAR 만 1회 재측정한다'
    else:
        verdict, why = 'FAR_ENABLED', '세 등급 모두 통과했다'
    return {'verdict': verdict, 'reason': why, 'per_grade': per,
            'thresholds_basis': 'PROJECT OPERATING THRESHOLD · frozen spec §11.4 · preservation_metrics.T'}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--records', default=os.path.join(HERE, 'dryrun', 'preservation_records.jsonl'))
    ap.add_argument('--human', default=None)
    ap.add_argument('--key', default=os.path.join(HERE, 'dryrun', '_key_human_eval.csv'))
    ap.add_argument('--demo', action='store_true')
    ap.add_argument('--assume-a-pass', action='store_true', help='DEMO 에서 G4 분기를 보려고 A 통과를 가정한다')
    a = ap.parse_args()
    recs = load_records(a.records)
    if a.demo:
        recs = demo_human(recs)
    elif a.human:
        recs = attach_human(recs, a.human, a.key)
    summ = summarize(recs)
    a_ok = poc_a_passed() or (a.demo and a.assume_a_pass)
    dec = decide(summ, a_ok)
    out = {'WARNING': 'NOT VALIDATION RESULT · DEMO 사람 판정' if a.demo else None,
           'summary': summ, 'decision': dec}
    outp = os.path.join(os.path.dirname(a.records), 'preservation_evaluation.json')
    io.open(outp, 'w', encoding='utf-8').write(json.dumps(out, ensure_ascii=False, indent=2))
    if out['WARNING']:
        print('#' * 60)
        print('#  ' + out['WARNING'])
        print('#' * 60)
    print('%-13s %-6s %-8s %-9s %-8s %-8s %-8s %s' % ('grade', 'n', 'acc(h)', 'pres_min', 'attempts', 'plan', 'llm~h', 'result'))
    for g in GRADES:
        s, p = summ[g], dec['per_grade'][g]
        print('%-13s %-6s %-8s %-9s %-8s %-8s %-8s %s %s' % (
            g, s['n_human_judged'], s['grade_accuracy_human'], s['core_preservation_min'], s['avg_attempts'],
            s['plan_adherence'], s['prefilter_vs_human_grade_agreement'], p['result'], p['parts']))
    print()
    print('G4 판정 ·', dec['verdict'], '·', dec['reason'])
    print('저장 ·', outp)
    return 0


if __name__ == '__main__':
    sys.exit(main())
