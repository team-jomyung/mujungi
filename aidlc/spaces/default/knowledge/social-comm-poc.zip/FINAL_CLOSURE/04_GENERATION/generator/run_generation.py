# -*- coding: utf-8 -*-
"""POC B 생성 파이프라인 · 앵커 → 통제 변형 → 분리된 판정 → 규칙 → 재생성 → 보존 기록.

    python run_generation.py --dry-run        Echo 생성기 · Echo 판정자 · 배선 확인
    python run_generation.py --provider ...   실제 모델 · A 통과 뒤에만

흐름 (씨앗마다)
  1 앵커      씨앗을 base_context 그대로 장면으로 쓴다. 사람이 한 번 확인한다
  2 계획      variation_plan 이 등급마다 바꿀 축과 값을 정해 준다
  3 변형      생성기가 계획대로 쓴다
  4 분리      isolation.for_judge 가 생성기 정보를 빼고 두 장면만 판정자에게 준다
  5 판정      판정자가 필드마다 SAME / DIFFERENT / UNKNOWN, 변화 축마다 CHANGED / SAME / UNKNOWN
  6 규칙      RC1 rule_engine 이 Skill Identity 와 거리를 계산한다. 판정자는 등급을 정하지 않는다
  7 수락      이해 SAME 이고 거리 = 목표 등급이면 수락. 아니면 재생성 (최대 5회)
  8 기록      preservation_record 한 줄 · 목표 대 실제 · 필드 보존 · 재생성 수 · 계획 준수

LLM 판정은 pre-filter 다. 공식 보존 판정은 사람이다(human_eval_blinded.csv).
Echo 출력은 시나리오가 아니다. 어떤 성능도 주장하지 않는다.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import os
import random
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
RC1 = os.path.normpath(os.path.join(HERE, '..', '..', '..', 'poc_validation_v0_1'))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(RC1, '02_POC_A'))

import isolation as ISO  # noqa: E402
import prompts as PR  # noqa: E402
import variation_plan as VP  # noqa: E402
from rule_engine import skill_identity, transfer_distance, SAME  # noqa: E402

CORE = ('target_skill', 'required_inference', 'perspective_structure', 'decidable_by_evidence', 'direct_check_allowed')
CHANGE_FIELDS = {'relationship_type': 'relationship_changed', 'situation_type': 'situation_type_changed',
                 'misread_cost': 'misread_cost_changed', 'recoverable': 'recoverability_changed'}
MAX_ATTEMPTS = 5


# ───────────────────────── Echo 생성기 · 판정자 ─────────────────────────

class EchoGenerator(object):
    """모델을 부르지 않는다. 장면 글 안에 표지를 넣어, 글을 읽는 판정자가 변화를 찾을 수 있게 한다.

    가끔 일부러 구조를 깨거나(다른 추론) 계획에 없는 축을 바꾼다. 재생성과 계획 준수 경로를 확인하려고."""
    family = 'echo-gen'

    def __init__(self, seed=20260914, p_break=0.18, p_overchange=0.12):
        self.rng = random.Random(seed)
        self.p_break, self.p_over = p_break, p_overchange
        self.truth = {}

    def _scene(self, inv, ctx, tag, broke=False):
        rel = PR.REL_KO[ctx['relationship_type']]
        sit = PR.SIT_KO[ctx['situation_type']]
        cost = '대가큼' if ctx['misread_cost'] == 'HIGH' else '대가작음'
        rec = '되돌림가능' if ctx['recoverable'] else '되돌림불가'
        dialogue = [{'speaker': 'OTHER', 'text': '[%s] 상대가 먼저 말을 꺼냈다' % tag},
                    {'speaker': 'SELF', 'text': '[%s] 나는 대답했다' % tag}]
        narr = '[관계:%s][자리:%s][%s][%s] %s' % (rel, sit, cost, rec, inv)
        if broke:
            narr += ' [다른 추론]'
        return {'dialogue': dialogue, 'narration': narr}

    def anchor(self, seed):
        return self._scene(seed['invariant_sentence'], seed['base_context'], 'anchor %s' % seed['id'])

    def variant(self, seed, plan, attempt):
        ctx = dict(plan['target_context'])
        broke = self.rng.random() < self.p_break
        over = self.rng.random() < self.p_over
        if over:
            # 계획에 없는 축을 하나 더 바꾼다
            keep = [k for k, v in plan['change'].items() if v == 'KEEP' and k in CHANGE_FIELDS]
            if keep:
                k = self.rng.choice(keep)
                if k == 'recoverable':
                    ctx[k] = not ctx[k]
                elif k == 'misread_cost':
                    ctx[k] = 'HIGH' if ctx[k] == 'LOW' else 'LOW'
                elif k == 'relationship_type':
                    ctx[k] = VP._rotate(VP.RELATIONSHIPS, ctx[k], attempt + 7)
                else:
                    ctx[k] = VP._rotate(VP.SITUATIONS, ctx[k], attempt + 2)
        # 장면 글에 후보 번호를 넣지 않는다. 번호에 목표 등급이 들어 있어 판정자가 글 대신 번호를 읽게 된다.
        # 첫 dry-run 에서 isolation.assert_no_leak 이 바로 이 누출을 잡았다(SAME_CONTEXT 가 대사에 있었다)
        tag = 'v' + hashlib.sha1(('%s|%d' % (plan['candidate_id'], attempt)).encode('utf-8')).hexdigest()[:6]
        scene = self._scene(seed['invariant_sentence'], ctx, tag, broke)
        # 생성기가 주장하는 메타데이터 · 판정자에게 가면 안 된다
        scene.update({'intended_core': seed['core'], 'intended_grade': plan['target_grade'],
                      'context': ctx, '_echo': True})
        self.truth[(plan['candidate_id'], attempt)] = {'broke': broke, 'overchange': over, 'ctx': ctx}
        return scene


class EchoJudge(object):
    """글에서 표지만 읽는다. 메타데이터를 받지 않는다. 가끔 UNKNOWN 을 낸다."""
    family = 'echo-judge'

    def __init__(self, seed=7):
        self.rng = random.Random(seed)

    @staticmethod
    def _markers(text):
        import re
        return {
            'relationship_type': (re.search(r'\[관계:([^\]]+)\]', text) or [None, None])[1],
            'situation_type': (re.search(r'\[자리:([^\]]+)\]', text) or [None, None])[1],
            'misread_cost': 'HIGH' if '[대가큼]' in text else 'LOW',
            'recoverable': '[되돌림가능]' in text,
        }

    def judge(self, payload):
        a, b = payload['situation_1'], payload['situation_2']
        ma, mb = self._markers(a), self._markers(b)
        out = {}
        for f in CORE:
            if self.rng.random() < 0.04:
                out[f] = 'UNKNOWN'
            elif f == 'required_inference' and '[다른 추론]' in b:
                out[f] = 'DIFFERENT'
            elif f == 'direct_check_allowed' and ma['relationship_type'] != mb['relationship_type'] and self.rng.random() < 0.3:
                out[f] = 'DIFFERENT'
            else:
                out[f] = 'SAME'
        for k, name in CHANGE_FIELDS.items():
            out[name] = 'CHANGED' if ma[k] != mb[k] else 'SAME'
        out['topic_changed'] = out['place_changed'] = out['participants_changed'] = 'CHANGED'
        return out


# ───────────────────────── 파이프라인 ─────────────────────────

def plan_adherence(plan, judged):
    """계획이 바꾸라고 한 축과 판정자가 바뀌었다고 본 축이 같은가."""
    planned = {CHANGE_FIELDS[k] for k, v in plan['change'].items() if k in CHANGE_FIELDS and v == 'CHANGE'}
    seen = {n for n in CHANGE_FIELDS.values() if judged.get(n) == 'CHANGED'}
    return {'planned': sorted(planned), 'judged_changed': sorted(seen),
            'extra': sorted(seen - planned), 'missing': sorted(planned - seen), 'adheres': planned == seen}


def run(seeds, plan, gen, judge, max_attempts=MAX_ATTEMPTS):
    ISO.check_families(gen.family, [judge.family])
    by_seed = {s['id']: s for s in seeds}
    anchors = {s['id']: gen.anchor(s) for s in seeds}
    records = []
    for p in plan:
        seed = by_seed[p['seed_id']]
        attempts, accepted, last = 0, None, None
        while attempts < max_attempts:
            attempts += 1
            cand = gen.variant(seed, p, attempts)
            payload = ISO.for_judge(anchors[seed['id']], cand, 'ALL_CORE_AND_CHANGES')
            judged = judge.judge(payload)
            si_u = skill_identity(judged, 'understand')
            si_p = skill_identity(judged, 'perform')
            dist = transfer_distance(judged, si_u)
            adh_now = plan_adherence(p, judged)
            last = {'judged': judged, 'si_u': si_u, 'si_p': si_p, 'dist': dist,
                    'payload_sha256': ISO.payload_hash(payload), 'scene': ISO.render_scene(cand),
                    'truth': gen.truth.get((p['candidate_id'], attempts))}
            # 등급만 맞으면 받지 않는다. 계획에 없는 축을 하나 더 바꿔도 등급은 같을 수 있다
            # (NEAR 계획에 관계와 자리를 둘 다 바꾸면 여전히 NEAR). 그러면 통제 변형이 무너진다.
            # 첫 dry-run 에서 계획 준수 0.92 인데 수락 100% 였던 것이 이 구멍이다
            if si_u == SAME and dist == p['target_grade'] and adh_now['adheres']:
                accepted = last
                break
        use = accepted or last
        adh = plan_adherence(p, use['judged'])
        records.append({
            'candidate_id': p['candidate_id'], 'seed_id': p['seed_id'], 'skill_family': p['skill_family'],
            'scope_tier': p['scope_tier'], 'target_grade': p['target_grade'], 'variant_index': p['variant_index'],
            'target_skill_identity_understand': 'SAME',
            'target_skill_identity_perform': 'SAME_OR_DIFFERENT_IF_DIRECT_CHECK_CHANGES',
            'llm_skill_identity_understand': use['si_u'], 'llm_skill_identity_perform': use['si_p'],
            'target_distance': p['target_grade'], 'llm_distance': use['dist'],
            'llm_field_preservation': {f: use['judged'][f] for f in CORE},
            'human_skill_identity_understand': None, 'human_distance': None, 'human_field_preservation': None,
            'regeneration_count': attempts - 1, 'attempts': attempts,
            'accepted_by_prefilter': accepted is not None,
            'plan_adherence': adh,
            'generator_family': gen.family, 'judge_family': judge.family,
            'isolation_check_passed': True, 'payload_sha256': use['payload_sha256'],
            'scene_for_human': use['scene'], 'anchor_for_human': ISO.render_scene(anchors[seed['id']]),
            '_dryrun_truth': use['truth'],
        })
    return records, anchors


def write_outputs(records, outdir, dry):
    os.makedirs(outdir, exist_ok=True)
    with io.open(os.path.join(outdir, 'preservation_records.jsonl'), 'w', encoding='utf-8') as f:
        for r in records:
            f.write(json.dumps(r, ensure_ascii=False) + '\n')
    # 사람 판정용 · 목표 등급과 생성 정보를 가린다. 섞는다
    rng = random.Random(20260914)
    acc = [r for r in records if r['accepted_by_prefilter']]
    order = list(acc)
    rng.shuffle(order)
    cols = ['item_id', 'scene_1', 'scene_2',
            'human_target_skill', 'human_required_inference', 'human_perspective_structure',
            'human_decidable_by_evidence', 'human_direct_check_allowed',
            'human_relationship_changed', 'human_situation_type_changed',
            'human_misread_cost_changed', 'human_recoverability_changed', 'rater_note']
    with io.open(os.path.join(outdir, 'human_eval_blinded.csv'), 'w', encoding='utf-8', newline='') as f:
        w = csv.writer(f)
        w.writerow(cols)
        for i, r in enumerate(order, 1):
            w.writerow(['G%03d' % i, r['anchor_for_human'], r['scene_for_human']] + [''] * (len(cols) - 3))
    with io.open(os.path.join(outdir, '_key_human_eval.csv'), 'w', encoding='utf-8', newline='') as f:
        w = csv.writer(f)
        w.writerow(['item_id', 'candidate_id', 'target_grade'])
        for i, r in enumerate(order, 1):
            w.writerow(['G%03d' % i, r['candidate_id'], r['target_grade']])
    meta = {'WARNING': 'NOT VALIDATION RESULT · DRY-RUN · ECHO' if dry else None,
            'n_candidates': len(records), 'n_accepted_prefilter': len(acc)}
    io.open(os.path.join(outdir, 'run_meta.json'), 'w', encoding='utf-8').write(json.dumps(meta, ensure_ascii=False, indent=2))
    return len(acc)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--dry-run', action='store_true')
    ap.add_argument('--out', default=os.path.join(HERE, '..', 'preservation_evaluation', 'dryrun'))
    a = ap.parse_args()
    if not a.dry_run:
        blocked = os.path.join(RC1, '04_POC_B_SCAFFOLD', 'BLOCKED_UNTIL_A_PASS.md')
        if os.path.exists(blocked):
            print('POC A 가 통과하지 않았다. 실제 생성은 막혀 있다 · %s' % blocked)
            return 2
        print('실제 provider 를 붙여야 한다. EchoGenerator / EchoJudge 자리에 등록한다.')
        return 2
    seeds = json.load(io.open(VP.SEEDS, encoding='utf-8'))['seeds']
    plan = VP.build(seeds)
    records, _ = run(seeds, plan, EchoGenerator(), EchoJudge())
    n_acc = write_outputs(records, a.out, True)
    print('#' * 60)
    print('#  NOT VALIDATION RESULT · DRY-RUN · Echo 생성기 · Echo 판정자')
    print('#' * 60)
    print('후보 %d · pre-filter 수락 %d' % (len(records), n_acc))
    for g in VP.GRADES:
        sub = [r for r in records if r['target_grade'] == g]
        acc = sum(1 for r in sub if r['accepted_by_prefilter'])
        att = sum(r['attempts'] for r in sub) / len(sub)
        adh = sum(1 for r in sub if r['plan_adherence']['adheres']) / len(sub)
        print('  %-13s 수락 %2d/%-2d · 평균 시도 %.2f · 계획 준수 %.2f' % (g, acc, len(sub), att, adh))
    print('저장 ·', os.path.normpath(a.out))
    return 0


if __name__ == '__main__':
    sys.exit(main())
