# -*- coding: utf-8 -*-
"""G1 생성 프롬프트. 기술 영역마다, 등급마다, 계획마다 다르게 만든다.

공통 규칙은 RC1 의 04_POC_B_SCAFFOLD/generator_prompt.md 와 같다. 여기서 더하는 것은 둘이다.
  1 통제 변형 · variation_plan 이 정한 축과 값만 바꾼다. 생성기가 바꿀 축을 고르지 않는다
  2 기술 영역별 보존 조건 · 표면을 바꿔도 그 기술이 성립하려면 장면에 무엇이 남아 있어야 하는지

앵커 · 비교의 한쪽
  씨앗은 구조(core · base_context)만 있고 장면 글이 없다. 판정자는 두 장면을 비교하는 과제(A1 · A2 와 같은 과제)로
  보존을 판정해야 하므로, 먼저 씨앗을 base_context 그대로 장면으로 쓴 앵커를 만든다. 앵커는 사람이 한 번 확인한다.
"""
from __future__ import annotations

REL_KO = {
    'FRIEND_CLOSE': '친한 친구', 'FRIEND_CASUAL': '그냥 아는 친구', 'CLASSMATE': '같은 반 · 같은 수업',
    'CLUB_PEER': '동아리 또래', 'CLUB_SENIOR': '동아리 선배', 'CLUB_JUNIOR': '동아리 후배', 'TEAMMATE': '조별과제 팀원',
    'SUPERVISOR': '직장 상사 · 사수', 'COWORKER': '직장 동료', 'TEACHER': '선생님 · 교수님', 'FAMILY': '가족',
    'ACQUAINTANCE': '얼굴만 아는 사람', 'STRANGER': '처음 보는 사람',
}
SIT_KO = {
    'FRIEND_PRIVATE': '친구끼리 사적인 자리', 'SCHOOL_GROUP': '학교 조별 활동', 'CLUB': '동아리', 'WORKPLACE': '직장',
    'FAMILY': '집', 'ONLINE_TEXT': '메신저 대화', 'PUBLIC_FORMAL': '면접이나 공식 자리',
}

FAMILY_RULES = {
    'listener_knowledge': (
        '장면 안에 상대가 무엇을 알고 무엇을 모르는지 드러나는 단서가 있어야 한다. '
        '예를 들어 상대가 그 자리에 없었다는 사실, 처음 듣는 이름에 되묻는 반응. '
        '변형해도 "상대가 모르는 것"의 종류(이전 대화 내용 · 내부 사정 · 전문 용어 중 무엇)는 유지한다.'),
    'information_quantity': (
        '상대에게 필요한 정보가 무엇인지 장면에서 복원할 수 있어야 한다. 그래야 빠뜨렸는지 넘쳤는지 판정할 수 있다. '
        '변형해도 넘침인지 모자람인지의 방향은 유지한다.'),
    'topic_management': (
        '화제를 옮기려는 신호(말끝 흐림 · 짧은 응답 · 다른 화제 제안 · 대답 대신 질문) 또는 상대 화제가 아직 끝나지 않았다는 신호가 '
        '최소 하나 대사로 들어가야 한다. 변형해도 신호의 종류는 유지한다.'),
    'repair_clarification': (
        '어긋남이 한 턴에서 분명히 생겨야 하고, 그 뒤에 되돌릴 기회가 있는 턴이 있어야 한다. '
        '"나"의 역할(상대가 잘못 알아들은 것을 내가 되돌리는 쪽인지, 내가 모르는 것을 물어야 하는 쪽인지)은 바꾸지 않는다.'),
    'reciprocity_responsiveness': (
        '상대의 말 속에 요청이나 질문이 최소 하나 있어야 하고, "나"의 턴이 그것에 반응할 자리여야 한다. '
        '변형해도 요청의 종류(부탁 · 질문 · 제안)는 유지한다.'),
    'indirect_meaning': (
        '말한 것과 뜻하는 것이 다를 수 있는 대사가 최소 하나 있어야 한다. 해설을 붙이지 않는다.'),
    'listener_relationship_adaptation': (
        '관계에 따라 표현 수위를 골라야 하는 부탁이나 거절이 장면 안에 있어야 한다.'),
}

COMMON = [
    'core 다섯을 그대로 유지한다. 하나라도 바뀌면 다른 기술이 된다',
    '표면 문장을 반드시 바꾼다. 같으면 암기를 훈련하게 된다',
    '한국의 청소년 · 이십대 상황으로 쓴다. 1인칭 "나"',
    '실명 · 연락처 · 학교명 · 회사명을 쓰지 않는다. 전부 지어낸다',
    '상대의 속마음을 단정하지 않는다. 정답이나 해설을 붙이지 않는다',
    '자살 · 자해 · 성적 내용 · 혐오 표현 금지',
]


def _ctx_line(ctx):
    return '%s · %s · 잘못 짚었을 때 대가 %s · 나중에 되돌릴 수 %s' % (
        REL_KO.get(ctx['relationship_type'], ctx['relationship_type']),
        SIT_KO.get(ctx['situation_type'], ctx['situation_type']),
        '큼' if ctx['misread_cost'] == 'HIGH' else '작음',
        '있음' if ctx['recoverable'] else '없음')


def change_instructions(plan):
    c, b, t = plan['change'], plan['base_context'], plan['target_context']
    lines = ['화제 · 장소 · 등장인물은 바꾼다']
    if c['relationship_type'] == 'CHANGE':
        lines.append('관계를 "%s" 에서 "%s" 로 바꾼다' % (REL_KO[b['relationship_type']], REL_KO[t['relationship_type']]))
    else:
        lines.append('관계 "%s" 는 그대로 둔다' % REL_KO[b['relationship_type']])
    if c['situation_type'] == 'CHANGE':
        lines.append('자리를 "%s" 에서 "%s" 로 바꾼다' % (SIT_KO[b['situation_type']], SIT_KO[t['situation_type']]))
    else:
        lines.append('자리 "%s" 는 그대로 둔다' % SIT_KO[b['situation_type']])
    if c['misread_cost'] == 'CHANGE':
        lines.append('잘못 짚었을 때 대가를 "%s" 에서 "%s" 로 바꾼다' % (
            '큼' if b['misread_cost'] == 'HIGH' else '작음', '큼' if t['misread_cost'] == 'HIGH' else '작음'))
    else:
        lines.append('잘못 짚었을 때 대가는 그대로 둔다')
    if c['recoverable'] == 'CHANGE':
        lines.append('나중에 되돌릴 수 있는지를 "%s" 에서 "%s" 로 바꾼다' % (
            '있음' if b['recoverable'] else '없음', '있음' if t['recoverable'] else '없음'))
    else:
        lines.append('나중에 되돌릴 수 있는지는 그대로 둔다')
    lines.append('위에 적지 않은 것은 바꾸지 않는다. 바꿀 축을 스스로 고르지 않는다')
    return lines


def anchor_prompt(seed):
    return {
        'role': 'generator', 'task': 'ANCHOR',
        'instruction': '아래 씨앗을 base_context 그대로 한 장면으로 쓴다. 이 장면이 비교의 기준이 된다.',
        'invariant_sentence': seed['invariant_sentence'],
        'core': seed['core'],
        'context_line': _ctx_line(seed['base_context']),
        'family_rule': FAMILY_RULES.get(seed['skill_family'], ''),
        'common_rules': COMMON,
        'output': {'dialogue': '[{speaker: OTHER|SELF, text}] 3~6턴', 'narration': '2~3문장 · 어디서 막혔는지 한 문장'},
    }


def variant_prompt(seed, plan, anchor_text=None):
    return {
        'role': 'generator', 'task': 'VARIANT',
        'instruction': '기준 장면과 같은 기술이 필요한 새 장면을 쓴다. 아래 바꿀 것과 둘 것을 정확히 지킨다.',
        'invariant_sentence': seed['invariant_sentence'],
        'core': seed['core'],
        'anchor_scene': anchor_text,
        'change_instructions': change_instructions(plan),
        'family_rule': FAMILY_RULES.get(seed['skill_family'], ''),
        'common_rules': COMMON,
        'output': {'dialogue': '[{speaker: OTHER|SELF, text}] 3~6턴', 'narration': '2~3문장'},
    }
