# -*- coding: utf-8 -*-
"""G2 생성기와 판정자 분리. 판정자에게 가는 것에서 생성기 정보를 전부 뺀다.

판정자는 두 장면만 받는다. A1 · A2 와 같은 과제다(두 상황 · 필드 하나).
  situation_1  앵커 장면 글
  situation_2  변형 장면 글

빼는 것
  intended_core · intended_grade · what_changed · context(생성기가 주장한 관계와 자리) ·
  target_grade · candidate_id · seed_id · 생성 모델 이름 · _echo 같은 내부 표시

왜 context 까지 빼나
  생성기가 "관계를 SUPERVISOR 로 바꿨다"고 적어 두면 판정자는 대사를 읽지 않고 그 칸을 믿는다.
  보존 판정은 대사와 서술에서만 해야 한다.

payload 를 만든 뒤 assert_no_leak 로 검사한다. 걸리면 판정자를 부르지 않는다.
판정자와 생성자가 같은 모델 계열이면 check_families 가 멈춘다(자기 선호 편향 · Panickssery 2024).
"""
from __future__ import annotations

import hashlib
import json

LEAK_KEYS = ('intended_core', 'intended_grade', 'what_changed', 'target_grade', 'candidate_id',
             'seed_id', 'target_context', 'change', '_echo', '_broken_on_purpose', 'generator')
LEAK_VALUES = ('SAME_CONTEXT', 'NEAR_TRANSFER', 'FAR_TRANSFER', 'intended', 'target_grade')


def render_scene(obj):
    """dialogue + narration 을 사람이 읽는 글로 바꾼다. 다른 칸은 버린다."""
    lines = []
    for turn in obj.get('dialogue', []):
        who = '나' if turn.get('speaker') == 'SELF' else '상대'
        lines.append('%s: "%s"' % (who, turn.get('text', '')))
    if obj.get('narration'):
        lines.append(obj['narration'])
    return '\n'.join(lines)


def for_judge(anchor, candidate, field):
    payload = {
        'situation_1': render_scene(anchor),
        'situation_2': render_scene(candidate),
        'field': field,
    }
    assert_no_leak(payload)
    return payload


def assert_no_leak(payload):
    s = json.dumps(payload, ensure_ascii=False)
    bad = [k for k in LEAK_KEYS if '"%s"' % k in s] + [v for v in LEAK_VALUES if v in s]
    if bad:
        raise ValueError('판정자에게 생성기 정보가 샌다 · %s' % bad)
    return True


def payload_hash(payload):
    return hashlib.sha256(json.dumps(payload, ensure_ascii=False, sort_keys=True).encode('utf-8')).hexdigest()


def check_families(generator_family, judge_families):
    same = [j for j in judge_families if j == generator_family]
    if same:
        raise ValueError('생성 모델 계열(%s)이 판정단에 있다. 빼야 한다' % generator_family)
    return True
