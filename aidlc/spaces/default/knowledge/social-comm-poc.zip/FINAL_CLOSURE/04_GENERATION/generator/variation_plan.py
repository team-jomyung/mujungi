# -*- coding: utf-8 -*-
"""G1 통제 변형 계획. 생성기가 무엇을 바꾸고 무엇을 두는지 미리 정한다.

    python variation_plan.py                  plan/variation_plan.csv · .json

왜 계획을 먼저 만드나
  "NEAR 로 바꿔라"만 주면 생성기가 무엇을 바꿀지 스스로 정한다. 그러면 FAR 에는 늘 상사가 나오고
  NEAR 에는 늘 선배가 나오는 식으로 등급과 관계가 뒤섞인다. 전이 거리 측정이 관계 효과로 오염된다.
  계획은 등급마다 바꿀 축과 바꿀 값을 미리 정하고, 값을 씨앗끼리 돌려 균형을 맞춘다.

등급 정의 (frozen spec v0.1 §4.2 · 규칙 엔진과 같다)
  SAME_CONTEXT  표면 축(화제 · 장소 · 등장인물)만 바꾼다. 관계 · 상황 유형 · 오판 대가 · 회복 가능성 유지
  NEAR          관계 또는 상황 유형 하나를 바꾼다. 오판 대가 · 회복 가능성 유지
  FAR           관계 또는 상황 유형을 바꾸고, 오판 대가 또는 회복 가능성도 바꾼다

변형 셋의 역할 (등급마다 세 개)
  NEAR  v0 관계만 · v1 상황 유형만 · v2 관계만(다른 값)
  FAR   v0 관계 + 오판 대가 · v1 상황 유형 + 회복 가능성 · v2 관계 + 둘 다
"""
from __future__ import annotations

import csv
import io
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
SEEDS = os.path.join(HERE, 'skill_family_seeds.json')

RELATIONSHIPS = ['FRIEND_CLOSE', 'FRIEND_CASUAL', 'CLASSMATE', 'CLUB_PEER', 'CLUB_SENIOR', 'CLUB_JUNIOR',
                 'TEAMMATE', 'SUPERVISOR', 'COWORKER', 'TEACHER', 'FAMILY', 'ACQUAINTANCE', 'STRANGER']
SITUATIONS = ['FRIEND_PRIVATE', 'SCHOOL_GROUP', 'CLUB', 'WORKPLACE', 'FAMILY', 'ONLINE_TEXT', 'PUBLIC_FORMAL']
COST_FLIP = {'LOW': 'HIGH', 'HIGH': 'LOW'}
GRADES = ('SAME_CONTEXT', 'NEAR', 'FAR')
PER_GRADE = 3


def _rotate(pool, exclude, k):
    """exclude 를 뺀 목록에서 k 번째 값을 돌려 가며 고른다. 씨앗마다 다른 값이 나오게 한다."""
    cand = [x for x in pool if x != exclude]
    return cand[k % len(cand)]


def plan_for(seed, idx):
    """씨앗 하나의 계획. idx 는 씨앗 순번이고 값 회전에 쓴다."""
    base = seed['base_context']
    out = []
    for g in GRADES:
        for v in range(PER_GRADE):
            change = {'topic': 'CHANGE', 'place': 'CHANGE', 'participants': 'CHANGE',
                      'relationship_type': 'KEEP', 'situation_type': 'KEEP',
                      'misread_cost': 'KEEP', 'recoverable': 'KEEP'}
            target = dict(base)
            k = idx * PER_GRADE + v
            if g == 'NEAR':
                if v in (0, 2):
                    change['relationship_type'] = 'CHANGE'
                    target['relationship_type'] = _rotate(RELATIONSHIPS, base['relationship_type'], k)
                else:
                    change['situation_type'] = 'CHANGE'
                    target['situation_type'] = _rotate(SITUATIONS, base['situation_type'], k)
            elif g == 'FAR':
                if v in (0, 2):
                    change['relationship_type'] = 'CHANGE'
                    target['relationship_type'] = _rotate(RELATIONSHIPS, base['relationship_type'], k + 5)
                else:
                    change['situation_type'] = 'CHANGE'
                    target['situation_type'] = _rotate(SITUATIONS, base['situation_type'], k + 3)
                if v in (0, 2):
                    change['misread_cost'] = 'CHANGE'
                    target['misread_cost'] = COST_FLIP[base['misread_cost']]
                if v in (1, 2):
                    change['recoverable'] = 'CHANGE'
                    target['recoverable'] = not base['recoverable']
            out.append({
                'candidate_id': '%s_%s_%d' % (seed['id'], g, v),
                'seed_id': seed['id'], 'skill_family': seed['skill_family'], 'scope_tier': seed['scope_tier'],
                'target_grade': g, 'variant_index': v,
                'change': change, 'base_context': base, 'target_context': target,
            })
    return out


def build(seeds=None):
    seeds = seeds or json.load(io.open(SEEDS, encoding='utf-8'))['seeds']
    plan = []
    for i, s in enumerate(seeds):
        plan.extend(plan_for(s, i))
    return plan


def balance(plan):
    """등급별로 바뀐 관계 값이 한쪽으로 쏠렸는지 센다. 쏠리면 거리와 관계가 섞인다."""
    from collections import Counter
    rep = {}
    for g in ('NEAR', 'FAR'):
        c = Counter(p['target_context']['relationship_type'] for p in plan
                    if p['target_grade'] == g and p['change']['relationship_type'] == 'CHANGE')
        rep[g] = {'distinct_relationships': len(c), 'max_share': round(max(c.values()) / sum(c.values()), 3) if c else None,
                  'counts': dict(c)}
    return rep


def main():
    plan = build()
    outdir = os.path.join(HERE, 'plan')
    os.makedirs(outdir, exist_ok=True)
    io.open(os.path.join(outdir, 'variation_plan.json'), 'w', encoding='utf-8').write(
        json.dumps(plan, ensure_ascii=False, indent=1))
    cols = ['candidate_id', 'seed_id', 'skill_family', 'scope_tier', 'target_grade', 'variant_index',
            'rel_change', 'sit_change', 'cost_change', 'recov_change', 'base_rel', 'target_rel',
            'base_sit', 'target_sit', 'base_cost', 'target_cost', 'base_recov', 'target_recov']
    with io.open(os.path.join(outdir, 'variation_plan.csv'), 'w', encoding='utf-8', newline='') as f:
        w = csv.writer(f)
        w.writerow(cols)
        for p in plan:
            b, t, c = p['base_context'], p['target_context'], p['change']
            w.writerow([p['candidate_id'], p['seed_id'], p['skill_family'], p['scope_tier'], p['target_grade'],
                        p['variant_index'], c['relationship_type'], c['situation_type'], c['misread_cost'],
                        c['recoverable'], b['relationship_type'], t['relationship_type'], b['situation_type'],
                        t['situation_type'], b['misread_cost'], t['misread_cost'], b['recoverable'], t['recoverable']])
    bal = balance(plan)
    print('계획 %d건 · 씨앗 %d · 등급 3 · 변형 %d' % (len(plan), len(plan) // (3 * PER_GRADE), PER_GRADE))
    for g, r in bal.items():
        print('  %-5s 바뀐 관계 종류 %d · 최대 비중 %s' % (g, r['distinct_relationships'], r['max_share']))
    print('저장 · plan/variation_plan.json · .csv')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
