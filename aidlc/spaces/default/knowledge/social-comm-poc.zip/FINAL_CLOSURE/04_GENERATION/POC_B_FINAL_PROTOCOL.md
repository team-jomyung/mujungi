# POC B · FINAL PROTOCOL · 같은 기술 다른 상황 생성

2026-09-14 · G1 ~ G4. RC1 의 `04_POC_B_SCAFFOLD` (배관)를 기준으로 **통제 변형 · 판정자 분리 · 보존 기록 · 실패 시 축소 규칙**을 더했다.
코드 · `generator/` (계획 · 프롬프트 · 분리 · 실행) · `preservation_evaluation/` (기록 스키마 · 평가 · G4 판정).

**A 가 통과하기 전에는 공식 결과를 만들지 않는다.** 규격 §11.2 · `BLOCKED_UNTIL_A_PASS.md`. 이 문서의 수치는 전부 dry-run 이다.

---

## 0 · 흐름

```
씨앗 14 (§5.3 의 10 + 빈칸 채움 4)
  → 앵커         씨앗을 base_context 그대로 장면으로 · 사람이 한 번 확인 (C-15)
  → 변형 계획     등급마다 바꿀 축과 값을 미리 정함 · 씨앗끼리 값을 돌려 균형 (G1)
  → 생성         계획대로 · 기술 영역별 보존 조건 붙음 (G1)
  → 분리         생성기 정보를 전부 빼고 두 장면만 판정자에게 (G2)
  → 판정         필드별 SAME/DIFFERENT/UNKNOWN · 변화 축별 CHANGED/SAME/UNKNOWN
  → 규칙         RC1 rule_engine 이 Skill Identity 와 거리 계산 · 판정자는 등급을 정하지 않는다
  → 수락         이해 SAME AND 거리 = 목표 AND 계획 준수 (C-14) · 아니면 재생성 (최대 5)
  → 기록         보존 기록 한 줄 (G3)
  → 사람 판정     목표를 가리고 섞은 표 · 공식 기준
  → G4 판정      FAR_ENABLED / SAME_NEAR_MVP / BANK_ONLY / BLOCKED
```

---

## 1 · G1 · 씨앗과 통제 변형

### 1-1 · 씨앗

| 범위 판정 (`02_SCOPE/ONTOLOGY_SCOPE_FINAL.md`) | 씨앗 | 수 |
|---|---|---|
| MVP · 대화 속 함축 이해 | S1 S2 S3 S7 S9 | 5 |
| MVP · 청자 맞춤 정보 조절 | S4 S5 X3 | 3 |
| MVP · 관계 맞춤 조정 | S10 | 1 |
| MVP · 응답성 | **X4** | 1 |
| CONDITIONAL · 수리 · 명료화 | S6 X2 | 2 |
| CONDITIONAL · 화제 운용 | S8 X1 | 2 |

**X1 ~ X4 는 규격 작성 세션이 쓴 개발용 씨앗이다.** §5.3 에 없던 빈칸(화제 산출 · 명료화 요청 · 상대 지식 인식 · 응답성)을 채웠다. blind 가 아니고 A1 판정 대상이 아니다.
**관계 맞춤 조정과 응답성은 씨앗이 하나씩뿐이다.** POC B 결과를 영역별로 볼 때 이 둘은 n 이 작다.

### 1-2 · 등급마다 무엇을 바꾸나

| 등급 | 바꾸는 축 | 두는 축 | 변형 셋 |
|---|---|---|---|
| SAME_CONTEXT | 화제 · 장소 · 등장인물 | 관계 · 자리 · 오판 대가 · 되돌림 | 세 개 모두 표면만 |
| NEAR | 위 + **관계 또는 자리 하나** | 오판 대가 · 되돌림 | v0 관계 · v1 자리 · v2 관계(다른 값) |
| FAR | 위 + 관계/자리 **그리고** 오판 대가/되돌림 | Core 다섯 | v0 관계+대가 · v1 자리+되돌림 · v2 관계+둘 다 |

**값은 씨앗끼리 돌린다.** 계획 126건에서 NEAR 와 FAR 에 바뀐 관계가 각 11종이고 한 관계의 최대 비중이 **0.143** 이다.
"FAR 에는 늘 상사"처럼 등급과 관계가 뒤섞이면 거리 측정이 관계 효과로 오염된다. 이 균형이 그것을 막는다.

### 1-3 · 기술 영역별 보존 조건

표면을 다 바꿔도 그 기술이 성립하려면 장면에 무엇이 남아야 하는가. `generator/prompts.py` 의 `FAMILY_RULES`.

| 영역 | 남아야 하는 것 |
|---|---|
| 청자 맞춤 정보 조절 | 상대가 무엇을 알고 모르는지 드러나는 단서 · 과소인지 과다인지의 방향 |
| 화제 운용 | 화제 전환 신호 또는 상대 화제가 끝나지 않았다는 신호 하나 이상 |
| 수리 · 명료화 | 어긋남이 생긴 턴 · 되돌릴 기회가 있는 턴 · **"나"의 역할(되돌리기 대 묻기)** |
| 응답성 | 상대 말 속의 요청이나 질문 · 그 종류(부탁 · 질문 · 제안) |
| 함축 이해 | 말한 것과 뜻하는 것이 다를 수 있는 대사 하나 이상 |
| 관계 맞춤 조정 | 관계에 따라 표현 수위를 골라야 하는 부탁이나 거절 |

---

## 2 · G2 · 생성기와 판정자 분리

| 규칙 | 구현 |
|---|---|
| 판정자는 **두 장면 글만** 받는다 | `isolation.for_judge` · dialogue 와 narration 을 글로 바꾸고 나머지 칸은 버린다 |
| 생성기의 주장(intended_core · intended_grade · what_changed · context)을 **보지 않는다** | 같음. context 까지 빼는 이유 · 생성기가 "관계를 바꿨다"고 적어 두면 판정자가 대사 대신 그 칸을 믿는다 |
| **누출 검사** | `assert_no_leak` · payload 에 생성기 키나 등급 이름이 있으면 판정자를 부르지 않는다 |
| 생성 모델 계열 ≠ 판정 모델 계열 | `check_families` · 같으면 멈춘다 (Panickssery 2024 자기 선호) |
| 판정 과제 = A1 · A2 과제 | 두 장면 · Core 필드 판정. **A2 에서 검증한 판정자를 그대로 쓸 수 있다** |

### dry-run 에서 분리 검사가 실제로 잡은 것

첫 실행에서 `assert_no_leak` 이 멈췄다. **Echo 생성기가 장면 대사에 후보 번호(`S1_SAME_CONTEXT_0`)를 넣었고 그 번호에 목표 등급이 들어 있었다.**
판정자가 대사를 읽지 않고 번호로 등급을 맞힐 수 있는 경로다. 생성기 쪽을 고쳤다(번호 대신 해시).
**검사가 없었다면 dry-run 결과의 판정 일치가 부풀려졌을 것이다.** 실제 모델도 입력의 id 를 출력에 되풀이할 수 있으므로 이 검사는 실제 운영에서도 켜 둔다.

---

## 3 · G3 · 보존 기록

스키마 · `preservation_evaluation/preservation_record.schema.json`. 후보 하나에 한 줄.

| 칸 | 무엇 |
|---|---|
| target_skill_identity_understand | 항상 SAME |
| llm_skill_identity_understand / perform | pre-filter 판정 |
| human_skill_identity_understand / perform | **공식** |
| target_distance · llm_distance · human_distance | 목표 대 실제 |
| llm_field_preservation · human_field_preservation | Core 필드별 SAME/DIFFERENT/UNKNOWN |
| regeneration_count · attempts | 재생성 비용 |
| **plan_adherence** | 계획한 축 · 판정자가 본 변화 축 · 초과 · 누락 · 준수 여부 |
| generator_family · judge_family · isolation_check_passed · payload_sha256 | 무엇을 보고 판정했는지 재현 |

---

## 4 · 수락 기준 · 계획 준수를 넣은 이유 (C-14)

첫 dry-run 에서 **계획 준수 0.92 인데 수락 100%** 였다.
계획에 없는 축을 하나 더 바꿔도 등급은 같을 수 있다. NEAR 계획(관계만)에서 자리까지 바뀌어도 여전히 NEAR 다.
그러면 NEAR 변형 셋 중 일부가 관계와 자리를 동시에 바꾼 것이 되어 **"관계만 바뀌면 전이가 되나"를 물을 수 없다.**

| | 등급만 | 등급 + 계획 준수 |
|---|---|---|
| 수락 | 117 / 117 | 125 / 126 |
| 계획 준수 (수락분) | 0.92 | **1.00** |
| 평균 시도 | 1.49 ~ 1.59 | **1.62 ~ 1.90** |

**통제의 비용이 평균 시도 0.3 회 안팎이다.** Echo 기준이라 실제 비용은 모른다.

---

## 5 · G4 · 실패 시 축소 규칙

문턱은 RC1 `preservation_metrics.T` 를 그대로 가져온다(규격 §11.4 · **PROJECT OPERATING THRESHOLD**). 여기서 숫자를 다시 적지 않는다.

```
A 가 PASS 가 아님                          → BLOCKED · 공식 판정 없음
SAME_CONTEXT 또는 NEAR 가 FAIL              → BANK_ONLY · 사전 작성 시나리오 은행
FAR 가 FAIL 또는 RETRY                      → SAME_NEAR_MVP · FAR 를 끈다
                                              RETRY 면 프롬프트 수정 뒤 FAR 만 1회 재측정
셋 다 PASS                                 → FAR_ENABLED
등급의 결과 = 등급 일치 · 필드 보존 · 평균 시도 중 가장 나쁜 것
```

### dry-run 판정 경로 확인

| 조건 | 결과 |
|---|---|
| 실제 상태 (A 미시작) | **BLOCKED** · 공식 판정 없음 |
| `--demo --assume-a-pass` (모의 사람 판정 · 일치 확률 0.85) | FAR 필드 보존 최솟값이 문턱 아래 → **SAME_NEAR_MVP** |

**모의 판정의 결과는 아무것도 말하지 않는다.** 판정 경로 네 갈래가 코드에서 도는지만 확인했다.

---

## 6 · 사람이 하는 것

| 무엇 | 규모 | 언제 |
|---|---|---|
| 앵커 확인 | 14개 · 씨앗 core 와 맞는지 | 생성 전 |
| 보존 판정 | 수락 후보 전부 · `human_eval_blinded.csv` · 목표 등급 가림 · 섞음 | 생성 후 · **A1 판정자가 한다** |

A1 판정자가 해야 하는 이유 · 판정 기준이 A1 과 같아야 B 의 사람 판정이 기준 역할을 한다.

---

## 7 · 실행

```
cd FINAL_CLOSURE/04_GENERATION/generator
python variation_plan.py                 계획 126건
python run_generation.py --dry-run       Echo · 배선 확인
cd ../preservation_evaluation
python evaluate_preservation.py --demo --assume-a-pass    G4 경로 확인

실제 (A PASS 뒤)
  run_generation.py 의 EchoGenerator · EchoJudge 자리에 실제 provider 등록
  → 앵커 사람 확인 → 생성 → human_eval_blinded.csv 사람 판정
  → evaluate_preservation.py --human <판정.csv> --key dryrun/_key_human_eval.csv
```
