# STATISTICAL DESIGN · 다섯 연구

2026-09-13 · K 워크스트림. "나중에 통계 정하자"로 넘기지 않는다. 지금 정할 수 있는 것은 정하고, 근거 없는 문턱은 **PROJECT OPERATING THRESHOLD** 라고 적는다.

**이 POC 의 목적은 feasibility · measurement validity · automation validity · generation validity 다.
임상 효과가 아니다.** 임상 효과의 검정력 계산과 여기 표본 크기를 섞지 않는다.

---

## 0 · 공통

| 항목 | 결정 |
|---|---|
| CI | 백분위 부트스트랩 · **n=2000 · seed 20260912** · 95% |
| 다중비교 | 필드 다섯 · 축 둘 · 등급 셋을 각각 따로 보고 **보정하지 않는다.** 대신 어느 비교가 1차인지 미리 적는다 (아래 각 절). 탐색 결과는 탐색이라고 적는다 |
| 결측 | 판정 누락 = 그 항목 제외 · 제외 수를 보고. UNKNOWN 은 결측이 아니라 **라벨**이다 |
| UNKNOWN | 축 1 에서 하나의 범주로 κ 에 포함. 비율은 따로 보고 (규격 §11.4) |
| 보고 | **점추정 + CI + 혼동행렬**이 1차. 문턱 비교는 2차 (Artstein & Poesio 2008 · 문턱은 "black art") |
| 문턱 근거 | **모양이 같은 외부 준거는 없다.** 대조를 끝냈다(`01_EVIDENCE/EVIDENCE_LEDGER.csv`). AMP .712/.715 는 **1차 출처에서 못 찾았다**(인용에서 뺀다). PRS-SA .831 은 값이 맞지만 **7점 가중 κ · 1점 허용 · 평균이고 하한 .4917** 이라 비가중 3범주 κ 와 직접 비교할 수 없다. Adams 2018 의 비가중 Cohen κ .783 이 통계 종류는 맞으나 과제 모양이 다르다. **규범 근거로 남는 것은 McHugh 2012 뿐이고, 0.6 은 PROJECT OPERATING THRESHOLD 다** |

---

## 1 · A1 · 사람 재현성

| 항목 | 값 |
|---|---|
| **1차 지표** | Skill Identity(이해) Cohen κ · 3범주 · 비가중 |
| 2차 지표 | Skill Identity(수행) κ · Transfer Distance κ (4범주 · 두 판정자 모두 이해 SAME 인 쌍만 · 비가중 주 · 선형 가중 보조) · Core 필드 κ 다섯 · UNDETERMINED 비율(축 1) |
| 표본 단위 | **쌍** |
| 최소 N | **60쌍** (시뮬레이션 · κ참값 0.8 에서 P(하한>0.6)=0.795) · 권장 120 (거리 축 54~72쌍) |
| CI | 부트스트랩 (쌍 재표집) |
| 실패 조건 | CI 상한 < 0.4 (규격 `fail_below`) · UNDETERMINED > 0.30 |
| 불확정 | CI 가 0.6 을 걸침 → **지침 수정 후 재측정.** 실패 아님 |
| 진단 | 혼동행렬 3×3 둘 · 4×4 하나 · 6×6 (표기) · 출처별(합성/blind) κ |
| 문턱 | 0.6 **운영 값** (인접 준거는 대조 결과 직접 비교 불가) · 0.5 (Core · 거리) · 0.20 (UNDETERMINED) **운영** |

**κ 참값이 문턱 근처면 어떤 n 으로도 결론이 안 난다** (κ참 0.6 에서 n 을 200 까지 늘려도 P 가 0.02~0.07). 그래서 1차 산출물이 점추정·CI·혼동행렬이다.

---

## 2 · A2 · 판정기 타당성

| 항목 | 값 |
|---|---|
| **1차 지표** | 필드별 (셋) **held_out** 에서 판정단 vs gold κ 와 accuracy(decided) |
| 2차 지표 | macro F1 · ECE · coverage / human review rate / false confident rate 곡선 · 편향 시험 flip_rate 여덟 · AG 필드별 |
| 표본 단위 | **판정** (쌍 × 필드) · 분할은 **쌍 단위** |
| 최소 N | A1 gold 60쌍 → held_out 24쌍 = 72 판정 · **빠듯.** 120쌍 → 144 판정 |
| 분할 | calibration 30 / development 30 / held_out 40 · repeated stratified holdout **k=10** |
| CI | held_out k 개 수치의 범위 + 항목 부트스트랩 |
| 실패 조건 | **미리 정하지 않는다.** 라우팅 곡선을 보고 팀이 "쓸 만한 적용범위"를 정한다 (GATE 3). 참조점 · Jung 2024 0.90 일치에서 55.7% |
| 기대치 | JUDGE-BENCH 주관 과제 최고 판정자 평균 κ 0.28. 낮게 잡는다 |
| 금지 | held_out 을 본 뒤 프롬프트 수정 · 결정적 필드를 정확도에 섞기 |

---

## 3 · B · 구조 보존 (POC B)

| 항목 | 값 |
|---|---|
| **1차 지표** | 등급별 **사람 판정 등급 일치율** (목표 등급 = 사람 거리 판정 AND 사람 이해 SAME) |
| 2차 지표 | Core 필드 보존율 (사람이 SAME 으로 본 비율 · 넷) · strategy_space 보존(수행) · 1회 성공률 · 평균 시도 수 · 실패 사유 분포 |
| 표본 단위 | **생성 후보** (시드 × 등급 × 변형) · 시드 10 × 등급 3 × 3 = 90 |
| 최소 N | 90 후보 · 등급당 30. **운영 값.** 등급별 비율의 CI 폭이 ±0.17 수준 |
| 판정자 | A1 판정자 (사람) · 생성 목표를 가리고 섞어서 |
| CI | 등급별 비율 부트스트랩 |
| 판정 (규격 §11.4 · 전부 운영) | SAME_CONTEXT ≥ .80 · NEAR ≥ .70 · FAR ≥ .50 (pass) · Core 보존 ≥ .80 · 평균 시도 ≤ 3 |
| **fallback** | FAR 실패 → **MVP = SAME + NEAR.** NEAR 도 실패 → 사전 작성 시나리오 은행. GATE 4 |
| 전제 | **A1 통과 뒤에만.** A 가 안 되면 B 의 사람 판정이 기준이 아니다 |

---

## 4 · C · 개인 사건 수집 feasibility (POC C)

| 항목 | 값 |
|---|---|
| **1차 지표** | **완료율** (화면 1 진입 → 화면 7 저장) · 참가자당 사건 수 |
| 2차 지표 | intake burden 여섯 (`POC_C_AUDIT.md` L1) · 24~72h **관계·목표 일치율** · UNKNOWN 비율 · 개인정보 치환 발생률 · 이탈 화면 |
| 표본 단위 | **사건** (참가자 5~10 × 2~3건 = 10~30 사건) · 일치율은 **사건** 단위 |
| 최소 N | 참가자 5 · 사건 10. **feasibility 규모.** Adams & Gaile 2020 N=20 · SCIP feasibility 시작 22/완료 20 이 이 분야 파일럿 규모 |
| CI | 사건 수가 작아 **CI 를 내지 않는다.** 분자/분모를 그대로 적는다 (3/10 처럼) |
| 판정 | **개별 수치를 표로.** 비율 하나로 요약하지 않는다 |
| 실패 조건 | 완료율 < 0.5 · 또는 어떤 참가자도 2건 이상 못 적음 → GATE 5 개인화 설계 재검토. **운영 값** |
| 3건 이상 참가자 비율 | 탐색. `MIN_SAMPLE` 3 이 현실적인지 처음 보는 자리 |

---

## 5 · User performance pilot

| 항목 | 값 |
|---|---|
| **1차 지표** | rubric **평정자 간 신뢰도** (I4) · 지표별 선형 가중 κ (서열 0/1/2) · NA/UNKNOWN 일치 따로 |
| 2차 지표 | 참가자별 T0a·T0b·T1·T2·T3 지표값 그림 · 시점 간 차이 부호 · 자동 채점 vs 사람 (I5 · exact/adjacent/wκ/ρ) |
| 표본 단위 | **과제 시행** (참가자 × 시점 × 문항) |
| 최소 N | 신뢰도용 시행 표본 **NOT ESTABLISHED.** Tractenberg 2010 (수준당 5건 · CDR) 을 참조하면 지표 × 3수준 × 5 = 최소 150 시행이 나오지만 그건 다른 도구다. **첫 회차는 있는 것을 다 채점하고 CI 폭을 본다** |
| CI | 지표별 wκ 부트스트랩 |
| 실패 조건 | 지표의 wκ CI 상한 < 0.4 → 그 지표 문구 수정 · **향상 주장 금지** (GATE 6) |
| 향상 판정 | **개인별 · 시점별 · 지표별.** T0a→T0b 변화량을 잡음으로 두고 그보다 큰 T0→T1 상승만 "연습 과제 향상". 평균 내지 않음 · 통계 검정 기대 안 함 (n 작음) |
| 절대 금지 | 지표 합산 · UNDERSTAND 상승을 PERFORM 향상으로 · 임상 호전 |

---

## 6 · 표본 크기 · 무엇이 근거 있고 무엇이 운영 값인가

| 연구 | 숫자 | 근거 |
|---|---|---|
| A1 | 60 / 120 | **시뮬레이션** (우리가 돌림) |
| A2 | held_out 24~48쌍 | A1 의 40% · 파생 |
| B | 90 후보 | **운영** · 규격 §11.2 |
| C | 5~10명 × 2~3건 | **분야 관행** (SCIP 계열 20~24) · 검정력 아님 |
| Performance | NOT ESTABLISHED | 첫 회차 뒤 |

**임상 효과 검정력 계산은 없다.** 이 POC 는 그 질문을 묻지 않는다.

---

## 7 · 분석 코드 위치

| | |
|---|---|
| A1 κ · CI · 혼동행렬 | `poc_validation_v0_1/02_POC_A/analyze_agreement.py` |
| A1 표본 시뮬레이션 | `03_AUTOMATION/a1_sample_size_simulation.py` |
| A2 지표 · 라우팅 곡선 | `03_AUTOMATION/judge_harness/judge_harness.py` |
| A2 분할 · 부트스트랩 | `03_AUTOMATION/judge_harness/gold_split.py` |
| A2 편향 | `03_AUTOMATION/bias_tests/run_bias_tests.py` |
| B 보존 · 판정 | `poc_validation_v0_1/04_POC_B_SCAFFOLD/preservation_metrics.py` |
| C 파일럿 | `poc_validation_v0_1/03_POC_C/analyze_pilot.py` |
| Performance 자동 채점 비교 | `05_PERFORMANCE/automatic_scoring/score_harness.py` |
| E0~E4 | `07_TECH_ABLATION/scoring/run_ablation.py` |
