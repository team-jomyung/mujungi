# 강사님 발표용 근거 꾸러미

**보여 줄 것 하나 · `FINAL_INSTRUCTOR_REPORT.html`** (크롬으로 연다)

나머지는 그 문서의 숫자가 어디서 왔는지 따라갈 수 있게 남긴 것이다.

---

## 이 꾸러미가 답하는 것

| | 질문 | 어디 |
|---|---|---|
| Q1 | Ontology 를 어디까지 적용할 것인가. 범위를 정할 데이터가 있는가 | `01_DATA` `02_TARGET` `03_ONTOLOGY` `04_SKILLS` |
| Q2 | 실제 대화를 같은 능력을 요구하는 다른 상황으로 바꿀 수 있는가 | `07_SOCIAL_EVENT` `08_SCENARIO` `09_MANUAL_REVIEW` |
| Q3 | 무엇으로 객관적으로 평가하는가 | `05_BENCHMARK` `06_ABLATION` |
| — | 무엇을 주장할 수 있고 무엇은 못 하는가 | `11_CLAIMS` `10_RED_TEAM` |

## 다시 만드는 법

```
python 01_DATA/build_audit.py            47개 감사 + 등급
python build_docs.py                     01/02/03 문서 생성
python 04_SKILLS/build_skill_evidence.py 기술 범위
python 07_SOCIAL_EVENT/build_social_events.py
python 08_SCENARIO/auto_check.py         장면 기계 검사
python build_claims.py                   주장 대장
python build_report.py                   HTML 보고서
python verify_package.py                 발표 전 점검
```

실험을 다시 돌리려면

```
cd 05_BENCHMARK
python freeze_placement.py               채점 집합과 정답 자리를 못박는다
cd harness
python leakage.py                        먼저 이것이 통과해야 한다
python run.py --test-per-maxim 10 --k 3
python run.py --arms E1F --append        길이 통제 갈래
cd .. && python ../06_ABLATION/retrieval_diag.py
cd .. && python 06_ABLATION/analyze.py
```

중간에 죽으면 `--resume` 을 붙인다. 다 돌린 칸은 살리고 반쯤 돌린 칸만 버린다.
40문항짜리와 18문항짜리를 나란히 놓지 않기 위해서다.

## 지킨 것

- **사람을 새로 모집하지 않았다.** 신규 주석도 IRB 연구도 없다.
  사람 근거는 (1) 기존 자료에 든 gold (2) 팀 블라인드 수동 리뷰 둘뿐이다.
- **LLM 이 만들고 LLM 이 채점한 것을 Human-validated 라고 부르지 않는다.**
  gold 가 없는 칸은 `DEMONSTRATION_ONLY` 로 표시한다.
- **로컬 모델만 썼다.** 시험 자료가 권리 유보라 외부 API 로 보내지 않았다.
  ollama 의 exaone3.5:7.8b · bge-m3 이고 이 컴퓨터를 떠나지 않는다.
- **권리 유보 자료의 사본을 꾸러미에 두지 않았다.** 원래 자리에서 읽기만 한다.
  보고서에 원문 예시를 싣지 않고 집계 숫자만 낸다.
- **`POC_B_MANUAL_SANITY` 를 건드리지 않았다.** 읽기만 했다.
- **성격이 다른 수치를 합산하지 않았다.** 참가자 · 발화 · 대화 · 문항은 각각 단위를 적었다.
- **임상군 / 준임상 / 비임상을 섞어 하나로 계산하지 않았다.**

## 기계 검사

이 프로젝트는 같은 고장을 여러 번 겪었다. 값을 여러 곳에 손으로 적어서 어긋나는 것이다.
그래서 숫자는 **자료에서 읽어 문서를 생성**하고, 검사를 릴리스 관문에 건다.

| 검사 | 무엇 | 심은 결함 |
|---|---|---|
| `05_BENCHMARK/harness/leakage.py` | 시험 문항이 훈련·창고·프롬프트로 새는가 | 6개 심어 6개 적발 |
| `08_SCENARIO/auto_check.py` | 장면에 정답·메타가 새는가 | — |
| `verify_package.py` | 보고서 숫자가 CSV 와 같은가 · 지시서가 정한 토막이 다 있는가 · 금지 주장을 하는가 | 7개 심어 7개 적발 |
| `05_BENCHMARK/freeze_placement.py` | 정답 자리 배치가 못박은 것과 같은가 | 손으로 바꿔 보고 거부 확인 |
| `POC_B_MANUAL_SANITY/check_scenes.py` | 장면 생성 규칙 | 6개 심어 6개 적발 |

검사는 **심어 보고 터지는 것까지 확인한 뒤에** 통과를 믿는다.
조용히 통과하는 검사는 없는 것만 못하다.

## 이번에 걸린 것들

기계 검사가 실제로 잡아 낸 것만 적는다. 안 잡혔으면 그대로 나갔을 것들이다.

| 무엇 | 어떻게 잡혔나 |
|---|---|
| 채점 집합의 우연 기준선이 25%가 아니라 **35%** 였다 | 팀원이 격률 안 26.7%를 지적 → 실제 채점 집합을 재 보니 35%. 앞 결과 폐기 후 재실행 |
| 두 판이 같은 파일에 동시에 썼다 | 결과에 널 바이트. `TaskStop` 이 셸만 죽이고 python 자식은 살아남았다 |
| 못박은 배치 파일이 말없이 덮어써졌다 | 코드가 망가지면 기준도 같이 망가지는 상태. 지금은 덮어쓰기 거부 |
| 보고서에 **누출 검사 · 성능과 효과 구분 · 검색기 진단** 세 토막이 통째로 빠져 있었다 | 필수 토막 검사를 넣자마자. 결과가 없을 때 조기 반환되는 자리 아래 있었다 |
| 세 질문 어디에도 **한계 · 지금 판단** 칸이 없었다 | 지시서에서 뽑은 목록으로 검사. 보고서 제목에서 뽑은 목록으로는 영영 못 잡는다 |
| 메모리 부족으로 실험이 두 번 죽었다 | KV 캐시가 8.7GB. 실측 최장 프롬프트가 500토큰인데 문맥을 4096 열어 두고 있었다 |

마지막 둘이 같은 모양이다. **검사가 돌았는가가 아니라 검사의 기준이 어디서 왔는가**를 물어야 잡힌다.
기준을 산출물에서 뽑으면 산출물을 감사할 수 없다.

## 아직 못 한 것

- **팀 블라인드 수동 리뷰가 진행 중이다.** `[TEAM MANUAL RESULT PENDING]`
  결과 CSV 를 `09_MANUAL_REVIEW/manual_review_results/` 에 넣고 두 스크립트를 돌리면 집계된다.
- **`FINAL_INSTRUCTOR_REPORT.html` 을 실제 크롬 화면에서 눈으로 확인하지 못했다.**
  브라우저 확장이 연결되지 않아 구조로만 확인했다 (태그 균형 · CSS 중괄호 · 안 치환된 자리 0 ·
  토큰 14개 · 규칙 안에 박힌 색값 0). 열어 보고 깨지면 고쳐야 한다.
- 실험이 도는 중이면 보고서의 Q3 자리가 "도는 중" 으로 적힌다.
  다 돌면 `python build_report.py` 를 다시 돌린다.

## 하지 않는 주장

`11_CLAIMS/CLAIM_LEDGER.csv` 가 정본이다. 특히 이 셋은 어떤 등급도 주지 않는다.

- SCD 집단을 대상으로 성능을 검증했다
- 사용자가 훈련 뒤 실제로 나아진다
- SCD 치료·개선 효과가 있다

비임상 한국어로 잰 것을 SCD 검증이라고 부르지 않는다.
시스템의 화용 분석 성능과 사용자 효과는 다른 것이다.
