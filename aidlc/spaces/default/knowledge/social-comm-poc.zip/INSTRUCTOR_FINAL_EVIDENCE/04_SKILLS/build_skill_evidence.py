# -*- coding: utf-8 -*-
"""Skill 을 **자료 근거** 기준으로 다시 나눈다.

    python build_skill_evidence.py

앞 판과 무엇이 다른가
  앞 판(SKILL_SCOPE_V0_1)은 "문헌에 근거가 있는가 · 글로 관찰되는가" 로 나눴다.
  이번에는 하나를 더 본다 · **지금 손에 있는 Human Gold 로 잴 수 있는가.**

  그래서 CORE 가 둘로 갈린다.
    BENCHMARK_CORE  사람 gold 로 이 능력의 **적어도 일부**를 객관적으로 잰다
    DEMO_CORE       제품에는 중요한데 gold 가 없어 생성과 사례 시연까지만

  POC_B_MANUAL_SANITY 는 S1/S2/S3 을 평가 중이다. **그 파일은 안 건드린다.**
  거기서 나오는 결과와 여기 BENCHMARK_CORE 는 다른 것이다. 섞지 않는다.

격률과 기술을 잇는 것은 해석이다
  자료는 격률 넷을 준다. 우리 기술과 일대일이 아니다.
  Bishop & Adams (1989) 가 화용 손상을 "too much or too little information" 으로
  적었고 그것이 양의 격률과 같은 것을 가리킨다. 이 연결은 **우리가 한 주장**이다.
  자료가 준 것이 아니다. 그래서 INTERPRETIVE 로 표시하고 근거를 같이 적는다.
"""
from __future__ import annotations

import csv
import io
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', '03_ONTOLOGY'))
import mapping as ONT  # noqa: E402

TIERS = ('BENCHMARK_CORE', 'DEMO_CORE', 'CONDITIONAL', 'FUTURE_ONLY', 'EXCLUDE')

SKILLS = [
    dict(id='S1', ko='청자 맞춤 정보 조절 (상대 지식 · 정보량)',
         prev='CORE', tier='BENCHMARK_CORE',
         field='PhenomenonAttribution',
         gold='한국어 화용 평가셋 · 양의 격률 30문항',
         link='INTERPRETIVE',
         link_why=('양의 격률은 "필요한 만큼만 말한다" 이고, Bishop & Adams 1989 가 '
                   '화용 손상을 "too much or too little information" 으로 적었다. '
                   '같은 것을 가리킨다고 본다. **자료가 이 연결을 준 것은 아니다**'),
         metric='격률 4분류 중 quantity 클래스의 per-class F1',
         cover='일부. 정보량 판단만 잰다. 상대가 무엇을 아는지 추적하는 것은 안 잰다',
         why='사람이 쓴 한국어 gold 로 이 능력의 한 조각을 숫자로 낼 수 있다'),

    dict(id='S2', ko='관계 · 상황 맞춤 조정',
         prev='CORE', tier='DEMO_CORE',
         field='(없음)', gold='없음', link='NONE',
         link_why='관계에 따라 표현 수위를 바꾸는 것을 라벨로 준 한국어 공개 자료를 못 찾았다',
         metric='없음',
         cover='못 잰다',
         why=('제품에서 가장 중요한 축인데 **gold 가 없다.** '
              'Holtgraves & Yang 1992 가 한국 표본에서 P·D·R 상호작용을 보였지만 '
              '그것은 근거지 benchmark 가 아니다. 생성과 시연까지만 한다')),

    dict(id='S3', ko='대화 속 함축 · 비문자 의미 이해',
         prev='CORE', tier='BENCHMARK_CORE',
         field='InterpretationAttribution',
         gold='한국어 화용 평가셋 · 함축 해석 4지선다 120문항 (+ 방식의 격률 30문항)',
         link='DIRECT',
         link_why=('문항이 묻는 것이 바로 "이 발화가 이 맥락에서 갖는 뜻" 이다. '
                   '오답 구실에 literal 이 표시되어 있어 **문자 그대로 읽어서 틀린 비율**을 '
                   '따로 낼 수 있다. 그것이 우리가 다루려는 증상이다'),
         metric='accuracy · macro F1 · 오답 구실별 분포 (literal 오답률)',
         cover='이 자료가 재는 것과 우리 기술이 거의 같다',
         why='우리 중심 기술이고 유일하게 직접 재진다'),

    dict(id='S4', ko='응답성 · 상호성',
         prev='CONDITIONAL', tier='CONDITIONAL',
         field='StrategyAttribution', gold='KMI · 전략 8종 (PROXY)', link='PARTIAL',
         link_why='되비추기·인정하기는 응답성의 한 형태지만 응답성 자체의 라벨이 아니다',
         metric='KMI 전략 분류 macro F1 (PROXY 로만)',
         cover='일부. 상담 장면에 한정된다',
         why='라벨이 사람 것이 아니다. 숫자를 내더라도 PROXY 라고 적는다'),

    dict(id='S5', ko='수리 · 명료화 (오해받았을 때 되돌리기)',
         prev='CONDITIONAL', tier='CONDITIONAL',
         field='(없음)', gold='없음', link='NONE',
         link_why='한국어 수리 주석 자료를 못 찾았다',
         metric='없음', cover='못 잰다',
         why='DSM-5 A3 에 있고 PERFORM 지표가 이미 잰다. 빼지 않되 조건을 단다'),

    dict(id='S6', ko='내가 모를 때 묻기 (명료화 요청)',
         prev='CONDITIONAL', tier='CONDITIONAL',
         field='ActAttribution', gold='SAE4K · 질문 하위유형 (PROXY · 맥락 없음)',
         link='PARTIAL',
         link_why='질문 유형은 알지만 "몰라서 묻는 것" 인지는 맥락이 있어야 안다',
         metric='없음 (맥락이 없어 우리 필드 형식과 안 맞는다)',
         cover='못 잰다', why='진단 기준에 없다. 인접 근거 표시를 유지한다'),

    dict(id='S7', ko='화제 운용 (화제 전환 · 유지)',
         prev='SEED_ONLY', tier='FUTURE_ONLY',
         field='(없음)', gold='없음 · 관계의 격률 30문항이 인접하나 같지 않다',
         link='NONE',
         link_why=('관계의 격률은 "지금 이야기에 맞는 말" 이라 화제 관련성에 가깝지만, '
                   '우리 S7 은 여러 턴에 걸친 화제 운용이다. 문항은 한 턴짜리다'),
         metric='없음', cover='못 잰다',
         why='앞 판에서 이미 내렸다. 우리 사건 길이로는 잴 수 없다'),

    dict(id='S8', ko='반어 · 비꼼 · 간접 거절',
         prev='SEED_ONLY', tier='DEMO_CORE',
         field='PhenomenonAttribution',
         gold='KoCoSa 비꼼 이진 (PROXY · 권리 유보) · 질의 격률 30문항',
         link='PARTIAL',
         link_why='질의 격률에 반어·과장이 걸린다. 비꼼 자체 라벨은 KoCoSa 인데 권리 유보다',
         metric='질의 격률 per-class F1 (간접 근거)',
         cover='일부',
         why=('앞 판은 SEED_ONLY 였다. 질의 격률 30문항이 붙는 것을 이번에 확인해 '
              'DEMO_CORE 로 올린다. 다만 S3 과 점수가 겹치므로 따로 채점하지 않는다')),

    dict(id='S9', ko='운율 · 준언어', prev='EXCLUDE', tier='EXCLUDE',
         field='(없음)', gold='없음', link='NONE', link_why='음성이 있어야 보인다',
         metric='없음', cover='범위 밖', why='텍스트 제품인 이상 범위 밖이다'),

    dict(id='S10', ko='비언어 (시선 · 거리 · 표정)', prev='EXCLUDE', tier='EXCLUDE',
         field='(없음)', gold='없음', link='NONE', link_why='영상이 있어야 보인다',
         metric='없음', cover='범위 밖', why='우리 매체로 볼 수 없다'),
]

MAXIM_SKILL = [
    ('quantity', 'S1', 'INTERPRETIVE',
     'Bishop & Adams 1989 "too much or too little information" 과 같은 것을 가리킨다'),
    ('manner', 'S3', 'INTERPRETIVE', '모호하거나 에두르는 말이 함축 이해를 요구한다'),
    ('quality', 'S8', 'INTERPRETIVE', '반어 · 과장이 질의 격률 위반으로 걸린다'),
    ('relation', 'S7', 'WEAK',
     '화제 관련성에 가깝지만 문항이 한 턴짜리라 화제 운용과 같지 않다'),
]


def main():
    p = os.path.join(HERE, 'SKILL_EVIDENCE_MATRIX.csv')
    cols = ['skill_id', 'skill_ko', 'previous_tier', 'evidence_tier', 'ontology_field',
            'human_gold_source', 'skill_link_type', 'skill_link_why', 'metric',
            'coverage', 'why']
    with io.open(p, 'w', encoding='utf-8-sig', newline='') as fh:
        w = csv.writer(fh)
        w.writerow(cols)
        for s in SKILLS:
            w.writerow([s['id'], s['ko'], s['prev'], s['tier'], s['field'], s['gold'],
                        s['link'], s['link_why'], s['metric'], s['cover'], s['why']])

    import collections
    c = collections.Counter(s['tier'] for s in SKILLS)
    bc = [s for s in SKILLS if s['tier'] == 'BENCHMARK_CORE']

    t = ['# Skill 을 자료 근거로 다시 나눈다', '',
         '**앞 판과 기준이 다르다.** 앞 판은 문헌 근거와 관찰 가능성으로 나눴다.',
         '이번에는 하나 더 본다 · 지금 손에 있는 Human Gold 로 잴 수 있는가.', '',
         '| 등급 | 개수 | 기술 |', '|---|---|---|']
    for tier in TIERS:
        ss = [s for s in SKILLS if s['tier'] == tier]
        t.append('| %s | %d | %s |' % (tier, c[tier],
                                       ' · '.join(s['id'] for s in ss) or '-'))
    t += ['', '## BENCHMARK_CORE · %d개' % c['BENCHMARK_CORE'], '',
          '사람이 붙인 gold 로 **적어도 일부를** 객관적으로 잰다.', '']
    for s in bc:
        t += ['### %s %s' % (s['id'], s['ko']), '',
              '- gold · %s' % s['gold'],
              '- 온톨로지 필드 · %s' % s['field'],
              '- 지표 · %s' % s['metric'],
              '- 어디까지 재나 · %s' % s['cover'],
              '- 연결 유형 · **%s** · %s' % (s['link'], s['link_why']), '']
    t += ['## 격률 넷과 우리 기술의 연결', '',
          '자료는 격률을 준다. 우리 기술과 일대일이 아니다.',
          '아래 연결은 **우리가 한 해석**이고 자료가 준 것이 아니다.', '',
          '| 격률 | 기술 | 연결 | 근거 |', '|---|---|---|---|']
    for m, sid, kind, why in MAXIM_SKILL:
        t.append('| %s | %s | %s | %s |' % (m, sid, kind, why))
    t += ['', 'relation 만 WEAK 이다. 나머지 셋은 문헌이 같은 것을 가리킨다고 본다.',
          '이 연결을 인정하지 않으면 격률 성적은 S3 하나에만 붙는다.', '',
          '## 전체', '',
          '| 기술 | 앞 판 | 이번 | gold | 왜 |', '|---|---|---|---|---|']
    for s in SKILLS:
        t.append('| %s %s | %s | **%s** | %s | %s |' % (
            s['id'], s['ko'], s['prev'], s['tier'], s['gold'].replace('|', '·')[:46],
            s['why'].replace('|', '·')[:100]))
    t += ['', '## 팀 수동 리뷰와 섞지 않는다', '',
          '`POC_B_MANUAL_SANITY` 는 S1 · S2 · S3 의 **생성 장면**을 사람이 눈으로 본다.',
          '여기 BENCHMARK_CORE 는 **기존 자료의 사람 gold** 로 재는 것이다.',
          '', '| | 무엇을 재나 | 표본 | 부를 이름 |', '|---|---|---|---|',
          '| 팀 수동 리뷰 | 생성 장면이 쓸 만한가 | 18장면 · 사람 몇 | TEAM BLIND MANUAL SANITY RESULT |',
          '| BENCHMARK_CORE | 시스템이 사람 정답을 맞히는가 | 40문항 · 5갈래 | 화용 분석 성능 |',
          '', '둘은 다른 것이다. 하나를 다른 하나의 근거로 쓰지 않는다.', '',
          '## S2 가 DEMO_CORE 인 것이 이번 조사의 아픈 곳', '',
          '제품에서 가장 중요한 축이 **잴 수 없는 축**이다.',
          '관계에 따라 표현 수위를 바꾸는 것을 라벨로 준 한국어 공개 자료가 없다.',
          '', '그래서 S2 에 대해서는 이렇게만 말한다.',
          '- 생성은 한다 (POC B 가 S2 장면을 만든다)',
          '- 사람이 눈으로 본다 (팀 수동 리뷰)',
          '- **정확도는 말하지 않는다**', '']
    w2 = os.path.join(HERE, 'FINAL_SKILL_SCOPE.md')
    io.open(w2, 'w', encoding='utf-8', newline='\n').write(chr(10).join(t))

    print('기술 %d개 ·' % len(SKILLS), dict(sorted(c.items())))
    print('BENCHMARK_CORE ·', [s['id'] for s in bc])
    print('DEMO_CORE ·', [s['id'] for s in SKILLS if s['tier'] == 'DEMO_CORE'])
    print('저장 · SKILL_EVIDENCE_MATRIX.csv · FINAL_SKILL_SCOPE.md')
    _ = ONT
    return 0


if __name__ == '__main__':
    sys.exit(main())
