# -*- coding: utf-8 -*-
"""강사님께 보여 줄 문서를 만든다. 숫자는 전부 자료에서 읽는다.

    python build_report.py

  FINAL_INSTRUCTOR_REPORT.html
  00_EXECUTIVE/INSTRUCTOR_3_QUESTIONS.md
  00_EXECUTIVE/ONE_PAGE_DECISION.md

실험이 아직 도는 중이면
  그 자리에 "도는 중" 이라고 적는다. 빈칸을 그럴듯한 숫자로 채우지 않는다.
  다 돌면 이 스크립트를 다시 돌리면 된다.
"""
from __future__ import annotations

import collections
import csv
import io
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '03_ONTOLOGY'))
import mapping as ONT  # noqa: E402
sys.path.insert(0, os.path.join(HERE, '05_BENCHMARK', 'harness'))
import arms as A  # noqa: E402

OUT = os.path.join(HERE, 'FINAL_INSTRUCTOR_REPORT.html')


def rd(p):
    p = os.path.join(HERE, p)
    if not os.path.exists(p):
        return []
    return list(csv.DictReader(io.open(p, encoding='utf-8-sig', newline='')))


def esc(t):
    return (str(t).replace('&', '&amp;').replace('<', '&lt;')
            .replace('>', '&gt;').replace('"', '&quot;'))


def md(t):
    """**굵게** 만 처리한다. 문서에 쓰는 표시가 그것뿐이다."""
    out, bold = [], False
    for part in esc(t).split('**'):
        out.append(('<strong>%s</strong>' % part) if bold else part)
        bold = not bold
    return ''.join(out)


# 지시서 PART P 가 정한 형식 · 질문마다 이 다섯이 있어야 한다.
# **보고서가 실제로 뽑는 제목에서 목록을 만들면 안 된다.** 그러면 순환이다.
# 한 번도 안 쓴 토막은 출력에도 없고 목록에도 없어서 영원히 안 걸린다.
# 그래서 목록을 지시서에서 가져온다. 실제로 이 검사가 다섯 중 둘이 통째로
# 빠진 것을 잡았다 · 한계와 지금 판단이 어느 질문에도 없었다.
QSPEC = ('근거', 'POC', '결과', '한계', '지금 판단')


def qsummary(evidence, poc, result, limitation, decision):
    """질문 하나를 닫는 다섯 칸. 형식을 강제해 빠뜨릴 수 없게 한다."""
    vals = (evidence, poc, result, limitation, decision)
    return ('<dl class="qs">' + ''.join(
        '<dt>%s</dt><dd>%s</dd>' % (md(k), md(v))
        for k, v in zip(QSPEC, vals)) + '</dl>')


def table(headers, rows, cls=''):
    h = ''.join('<th>%s</th>' % md(x) for x in headers)
    b = ''.join('<tr>%s</tr>' % ''.join('<td>%s</td>' % md(c) for c in r) for r in rows)
    return ('<div class="tw"><table class="%s"><thead><tr>%s</tr></thead>'
            '<tbody>%s</tbody></table></div>' % (cls, h, b))


# ── 자료 읽기 ────────────────────────────────────────────
def gather():
    g = {}
    au = rd('01_DATA/DATASET_EXECUTABILITY_AUDIT.csv')
    g['audit'] = au
    g['census'] = [r for r in au if r['scope'] != 'OWN']
    g['own'] = [r for r in au if r['scope'] == 'OWN']
    g['tier'] = collections.Counter(r['tier'] for r in au)
    g['tierA'] = [r for r in au if r['tier'] == 'A']
    g['tierB'] = [r for r in au if r['tier'] == 'B']
    g['access'] = collections.Counter(r['downloadable_now'] for r in au)

    tm = rd('02_TARGET/TARGET_EVIDENCE_MATRIX.csv')
    SC = {'STRONG': 3, 'MODERATE': 2, 'WEAK': 1, 'NONE': 0}
    BENCH = {'3_public_raw_data', '4_human_gold', '5_pragmatic_annotation',
             '6_natural_conversation', '7_multi_turn', '8_korean_language',
             '9_objective_benchmark_feasibility'}
    PROB = {'1_direct_problem_evidence', '2_our_age_band_evidence'}
    b, p, cell = collections.Counter(), collections.Counter(), {}
    for r in tm:
        s = SC[r['score'].strip().upper()]
        cell[(r['population'], r['criterion'])] = r['score'].strip()
        if r['criterion'] in BENCH:
            b[r['population']] += s
        elif r['criterion'] in PROB:
            p[r['population']] += s
    g['bench'], g['prob'], g['cell'] = b, p, cell

    g['fields'] = {f: ONT.status_of(f) for f in ONT.FIELDS}
    g['fstat'] = collections.Counter(g['fields'].values())
    g['skills'] = rd('04_SKILLS/SKILL_EVIDENCE_MATRIX.csv')
    g['abl'] = rd('06_ABLATION/results.csv')
    g['auto'] = rd('08_SCENARIO/AUTO_CHECK_RESULTS.csv')
    g['claims'] = rd('11_CLAIMS/CLAIM_LEDGER.csv')

    jl = os.path.join(HERE, '05_BENCHMARK', 'results', 'raw_predictions.jsonl')
    rows = []
    if os.path.exists(jl):
        for x in io.open(jl, encoding='utf-8'):
            x = x.strip()
            if x:
                try:
                    rows.append(json.loads(x))
                except ValueError:
                    pass
    g['pred'] = rows
    mp = os.path.join(HERE, '05_BENCHMARK', 'results', 'manifest.json')
    g['manifest'] = json.load(io.open(mp, encoding='utf-8')) if os.path.exists(mp) else {}
    # **자료에서 판단한다.** manifest 파일이 없다고 "도는 중" 이라고 적으면 안 된다.
    # 실제로 그렇게 됐다 · 400개를 다 돌려 놓고 마지막 줄에서 죽어 manifest 를 못 썼다.
    # 다 돌았는지는 예측 파일이 알고 있다. 파일 하나의 유무에 기대지 않는다.
    import collections as _c
    cnt = _c.Counter((r['task'], r['arm']) for r in rows)
    want = {('implicature', a) for a in A.ARMS} | {('maxim', a) for a in A.ARMS}
    g['cells_done'] = sum(1 for k in want if cnt.get(k, 0) == 40)
    g['cells_want'] = len(want)
    g['done'] = (g['cells_done'] == g['cells_want'])

    ev = [d for d in os.listdir(os.path.join(HERE, '07_SOCIAL_EVENT', 'examples'))
          if d.endswith('.json')] if os.path.isdir(
        os.path.join(HERE, '07_SOCIAL_EVENT', 'examples')) else []
    g['events'] = ev

    rt = os.path.join(HERE, '10_RED_TEAM', 'INSTRUCTOR_RED_TEAM.md')
    g['redteam'] = ''
    if os.path.exists(rt):
        # **판정 줄만 센다.** 통째로 세면 범례와 요약표의 낱말까지 세어
        # 17/15/21 처럼 실제(15/13/18)보다 부풀려진다. 실제로 그렇게 틀렸다.
        c = collections.Counter()
        for line in io.open(rt, encoding='utf-8'):
            if not line.startswith('**판정**'):
                continue
            v = line.split('·', 1)[-1].strip()
            if v.startswith('SUPPORTED'):
                c['SUPPORTED'] += 1
            elif v.startswith('PARTIAL'):
                c['PARTIAL'] += 1
            elif v.startswith('CANNOT'):
                c['CANNOT'] += 1
        if sum(c.values()):
            g['redteam'] = dict(c)
    return g


def err_roles(pred, arm):
    rs = [r for r in pred if r['task'] == 'implicature' and r['arm'] == arm]
    c = collections.Counter()
    for r in rs:
        if r['pred'] is None:
            c['INVALID'] += 1
            continue
        roles = r.get('roles') or []
        i = int(r['pred']) - 1
        c[roles[i] if 0 <= i < len(roles) else '?'] += 1
    return c, len(rs)


# ── 본문 ─────────────────────────────────────────────────
def sec_q1(g):
    tierA = g['tierA']
    a_names = ' · '.join(r['name'] for r in tierA) or '없음'
    pops_b = sorted(g['bench'], key=lambda x: -g['bench'][x])
    pops_p = sorted(g['prob'], key=lambda x: -g['prob'][x])

    h = ['<section class="q" id="q1">',
         '<p class="qk">질문 1</p>',
         '<h2>Ontology 를 어디까지 적용할 것인가. 그 범위를 정할 데이터가 있는가</h2>',
         '<div class="grid">']
    h += ['<div class="stat"><b>%d</b><span>조사한 자료</span></div>' % len(g['census']),
          '<div class="stat"><b>%d</b><span>TIER A</span></div>' % g['tier']['A'],
          '<div class="stat"><b>%d</b><span>TIER B · proxy</span></div>' % g['tier']['B'],
          '<div class="stat"><b>%d / 7</b><span>직접 검증 가능한 필드</span></div>'
          % g['fstat']['DIRECTLY_VALIDATABLE'],
          '</div>']

    h += ['<h3>근거 · 47개를 다시 봤고 실제로 쓸 수 있는 것은 하나였다</h3>',
          '<p>URL 이 있다고 접근 가능으로 세지 않았다. 실제 파일 목록이나 다운로드 '
          '페이지를 본 것만 YES 로 두었다.</p>',
          table(['등급', '개수', '뜻'],
                [['A', g['tier']['A'], '접근 + 사람 gold + 라벨 정의 + **우리 필드를 직접 잰다**'],
                 ['B', g['tier']['B'], 'gold·언어·구조 중 하나가 모자라 proxy 로만'],
                 ['C', g['tier']['C'], '문제 근거로는 쓰지만 benchmark 로는 못 쓴다'],
                 ['D', g['tier']['D'], '지금 못 가져온다']])]
    if tierA:
        r = tierA[0]
        h += ['<div class="callout"><h4>TIER A · %s</h4>' % md(r['name']),
              '<ul>',
              '<li>사람이 쓴 문항 · %s</li>' % md(r['annotator_count']),
              '<li>우리 필드 · <b>%s</b></li>' % md(r['ontology_fields']),
              '<li>일치도 · %s</li>' % md(r['agreement_reported']),
              '<li>라이선스 · %s · <b>재배포 불가 · 발표에 원문 예시 불가</b></li>'
              % md(r['license']),
              '</ul></div>']
    h += ['<p class="note"><b>A 가 하나뿐인 이유.</b> 넷째 조건 때문이다. '
          '앞 판에서는 셋만 봤더니 A 가 13개 나왔고 영어 화행 말뭉치도 A 가 되었다. '
          '우리 제품은 한국어다. 한국어 시스템을 영어 자료로 재면 그 시스템을 잰 것이 아니다.</p>']

    h += ['<h3>Human Gold 가 있다는 말과 사람이 붙였다는 말은 다르다</h3>',
          '<p>KMI 는 상담자 턴 9,558개에 전략 라벨이 붙어 있다. 그러나 사람이 붙인 주석이 아니다. '
          'T5 forecaster 가 라벨을 <b>먼저 고르고</b> GPT-4 가 그 라벨에 맞는 발화를 썼다. '
          '라벨은 주석이 아니라 생성 조건이다. 전문가 4인이 확인한 것은 표본 210발화뿐이고 '
          'General 라벨은 아예 빠졌다.</p>',
          '<p class="note">파일에 라벨이 있다고 Human Gold 가 아니다. '
          '이 구분을 놓치면 등급이 통째로 틀린다.</p>']

    h += ['<h3>온톨로지 7개 필드 중 무엇을 잴 수 있나</h3>']
    rows = []
    for f in ONT.FIELDS:
        ms = ONT.field_rows()[f]
        src = ms[0]['dataset'] if ms else '없음'
        met = ms[0]['metric'] if ms else '없음'
        rows.append([f, g['fields'][f], src, met])
    h += [table(['필드', '상태', '자료', '지표'], rows)]
    h += ['<p class="note"><b>GoalAttribution 과 StrategyRecommendation 은 억지로 재지 않는다.</b> '
          '규격 자체가 "확인한 네 자료 중 어느 것도 사회적 목표를 라벨로 주지 않았다" 고 적고 있다. '
          '추천에는 정답이 없다. 같은 상황에 친구·상담자·교사가 다른 전략을 쓴다.</p>']

    if g['own']:
        o = g['own'][0]
        h += ['<h3>우리가 직접 만든 평정 세트도 하나 있다</h3>',
              '<p>%s · 해석 쌍 %s개에 평정자 %s이 붙었다. 한국어이고 맥락과 관계가 있다. '
              '다만 <b>외부 benchmark 가 아니라 우리가 만든 것</b>이고, '
              '%s</p>' % (md(o['name']), md(o['size']), md(o['annotator_count']),
                          md(o['agreement_reported'])),
              '<div class="callout warn"><h4>이미 재 본 결과가 있다</h4>',
              '<p>%s</p></div>' % md(o['provenance_note']),
              '<p class="note">이 숫자를 감추지 않는다. 우리 핵심 부품이 어려운 축에서 '
              '우연에 가깝다는 것을 <b>우리가 이미 재서 알고 있다</b>는 것이 '
              '모르고 있는 것보다 낫다. 이번 E0~E4 는 그 자리를 다시 재는 일이다.</p>']

    h += ['<h3>타겟 · 세 가지를 같게 두지 않는다</h3>',
          '<p>사람을 모집하지 않으므로 모집 난이도·참여 편의·IRB 용이성을 순위에서 뺐다. '
          '남은 것은 근거와 데이터뿐이다.</p>',
          table(['집단', 'benchmark (21점)', '문제 근거 (6점)', 'Human Gold'],
                [[p, g['bench'][p], g['prob'][p], g['cell'][(p, '4_human_gold')]]
                 for p in pops_b])]
    h += ['<p>두 축의 1위가 <b>다르다.</b> benchmark 는 %s, 문제 근거는 %s 다.</p>'
          % (md(pops_b[0]), md(pops_p[0])),
          '<div class="decide">',
          '<div><span>PROBLEM GROUNDING</span><b>SCD 아동 · ASD 아동</b>'
          '<em>문헌이 가장 두꺼운 곳</em></div>',
          '<div><span>TECHNICAL BENCHMARK</span><b>비임상 한국어</b>'
          '<em>유일하게 잴 수 있는 곳</em></div>',
          '<div><span>PRODUCT TARGET</span><b>PROVISIONAL</b>'
          '<em>확정하지 않는다</em></div>',
          '</div>']
    h += ['<h4>강사님이 물으실 것 · 아동 근거가 더 많은데 왜 아동이 아닌가</h4>',
          '<p><b>근거상으로는 아동이 맞다.</b> 그것을 숨기지 않는다. '
          'SCD 아동 문제 근거 %d/6 · SCD 청소년 %d/6 · SCD 청년 %d/6 이다. '
          '그래서 문제 근거 집단을 아동으로 적는다. 제품 타겟과 분리해서.</p>'
          % (g['prob']['SCD child'], g['prob']['SCD adolescent'],
             g['prob']['SCD young adult']),
          '<p>제품 타겟을 아동으로 바로 옮기지 않는 이유는 근거가 아니라 매체와 절차다. '
          '그리고 <b>아동도 benchmark 가 없다.</b> SCD 아동 benchmark 가능성은 %d/21 이고 '
          'Human Gold 는 %s 다. 옮겨도 잴 것이 생기지 않는다.</p>'
          % (g['bench']['SCD child'], g['cell'][('SCD child', '4_human_gold')]),
          '<p class="warn">지금 기술 POC 대상인 SCD 청년(18~25)은 benchmark %d/21 · '
          '문제 근거 %d/6 으로 아홉 집단 중 가장 약하다. 이 사실을 감추지 않는다.</p>'
          % (g['bench']['SCD young adult'], g['prob']['SCD young adult'])]

    h += ['<h3>Skill 범위 · 잴 수 있는 것과 못 재는 것을 갈랐다</h3>']
    sk = g['skills']
    if sk:
        c = collections.Counter(s['evidence_tier'] for s in sk)
        h += [table(['등급', '기술', '뜻'],
                    [[t, ' · '.join(s['skill_id'] for s in sk if s['evidence_tier'] == t),
                      {'BENCHMARK_CORE': '사람 gold 로 일부를 객관적으로 잰다',
                       'DEMO_CORE': '제품에 중요한데 gold 가 없다. 생성·시연까지만',
                       'CONDITIONAL': '조건이 맞을 때만',
                       'FUTURE_ONLY': '지금 사건 길이로는 못 잰다',
                       'EXCLUDE': '매체 범위 밖'}.get(t, '')]
                     for t in ('BENCHMARK_CORE', 'DEMO_CORE', 'CONDITIONAL',
                               'FUTURE_ONLY', 'EXCLUDE') if c[t]])]
        h += ['<p class="warn">가장 아픈 곳은 <b>S2 관계·상황 맞춤 조정</b>이 DEMO_CORE 라는 것이다. '
              '제품에서 가장 중요한 축인데 잴 수 있는 한국어 gold 가 없다. '
              'S2 에 대해서는 생성하고 사람이 보되 <b>정확도는 말하지 않는다.</b></p>']
    h += [qsummary(
        '자료 %d개를 다시 조사했다. URL 이 아니라 실제 파일 목록과 다운로드 페이지를 봤다.'
        % len(g['census']),
        '데이터 실행가능성 감사 · 온톨로지 필드 매핑 · 기술 범위 재분류.',
        '지금 쓸 수 있는 자료 **%d개**. 온톨로지 7필드 중 직접 검증 가능한 것 **%d개** '
        '(%s). 문제 근거 1위와 benchmark 1위가 **다른 집단**이다.'
        % (g['tier']['A'], g['fstat']['DIRECTLY_VALIDATABLE'],
           ' · '.join(f for f in ONT.FIELDS
                      if g['fields'][f] == 'DIRECTLY_VALIDATABLE')),
        'Tier A 가 120문항짜리 하나뿐이고 그 문항의 작성 일치도가 논문에 없다. '
        '임상군 한국어 Human Gold 는 **어느 연령에도 없다.** '
        '제품 핵심 축인 S2 는 잴 방법이 없다.',
        'PROBLEM GROUNDING 은 아동, TECHNICAL BENCHMARK 는 비임상 한국어, '
        'PRODUCT TARGET 은 **PROVISIONAL** 로 둔다. 셋을 합치지 않는다.')]
    h.append('</section>')
    return chr(10).join(h)


def sec_q2(g):
    auto = g['auto']
    h = ['<section class="q" id="q2">',
         '<p class="qk">질문 2</p>',
         '<h2>실제 대화를 같은 능력을 요구하는 다른 상황으로 정말 바꿀 수 있는가</h2>']
    h += ['<div class="grid">',
          '<div class="stat"><b>%d</b><span>공개 대화 구조화</span></div>' % len(g['events']),
          '<div class="stat"><b>%d</b><span>생성 장면</span></div>' % len(auto),
          '<div class="stat"><b>%d / %d</b><span>기계 검사 통과</span></div>'
          % (sum(1 for r in auto if r['answer_leak'] == 'PASS'
                 and r['meta_leak'] == 'PASS' and r['grade_rule_ok'] == 'PASS'), len(auto)),
          '<div class="stat pending"><b>PENDING</b><span>사람 판정</span></div>',
          '</div>']

    h += ['<h3>1단계 · 공개된 진짜 대화를 구조로 바꾼다</h3>',
          '<p>KMI 대화 %d건을 Social Event 로 바꿨다. '
          '<b>발표에 원문을 실을 수 있는 유일한 한국어 다중턴 대화</b>라서 이것을 골랐다 '
          '(CC BY 4.0, 저작자 표시). 나머지 한국어 자료는 라이선스가 없어 예시를 못 싣는다.</p>'
          % len(g['events']),
          table(['칸', '표시', '왜'],
                [['맥락 · 참여자 · 역할', 'GOLD_VALIDATED', '자료가 직접 준다'],
                 ['StrategyAttribution', 'PROXY', '자료가 값을 주지만 사람 주석이 아니다'],
                 ['CueObservation', 'DEMONSTRATION', '규칙으로 뽑았다. gold 가 없다'],
                 ['Interpretation · Goal 등', 'NOT_PRODUCED',
                  'gold 가 없어 정확도를 말할 수 없다']])]

    h += ['<h3>2단계 · 같은 사건에서 거리를 벌려 장면을 만든다</h3>']
    if auto:
        rows = []
        for gr in ('SAME_CONTEXT', 'NEAR', 'FAR'):
            s = [r for r in auto if r['intended_distance'] == gr]
            ov = sorted(float(r['lexical_overlap']) for r in s)
            ax = [0 if r['context_axes_changed'] == '-'
                  else len(r['context_axes_changed'].split(' · ')) for r in s]
            rows.append([gr, len(s), '%.3f' % ov[len(ov) // 2],
                         '%d~%d' % (min(ax), max(ax)),
                         '%d/%d' % (sum(1 for r in s if r['grade_rule_ok'] == 'PASS'), len(s))])
        h += [table(['등급', 'n', '어휘 겹침 중앙', '바뀐 맥락 축', '등급 규칙'], rows)]
        h += ['<p>멀어질수록 원본과 <b>어휘 겹침이 줄고 바뀐 맥락 축이 늘어난다.</b> '
              '이것은 기계가 센 것이고 사람 판단이 아니다.</p>']
    h += ['<h3>기계가 세지 <b>않는</b> 것</h3>',
          '<div class="callout pending"><h4>[TEAM MANUAL RESULT PENDING]</h4>',
          '<p>"정말 같은 화용 능력을 요구하는가" 는 여기서 판정하지 않는다. '
          '사람이 읽어야 아는 것이고 팀이 블라인드로 보고 있다. '
          '결과가 들어오면 <code>09_MANUAL_REVIEW</code> 에서 자동 집계된다.</p>',
          '<p>그 결과의 이름은 <b>TEAM BLIND MANUAL SANITY RESULT</b> 로 고정한다. '
          '모델 정확도라고 부르지 않는다.</p></div>']
    ok_n = sum(1 for r in auto if r['answer_leak'] == 'PASS'
               and r['meta_leak'] == 'PASS' and r['grade_rule_ok'] == 'PASS')
    h += [qsummary(
        '공개된 실제 한국어 대화 (KMI · CC BY 4.0). 발표에 원문을 실을 수 있는 유일한 자료다.',
        'P3 공개 대화 %d건을 Social Event 로 구조화. P4 장면 %d개를 기계로 검사.'
        % (len(g['events']), len(auto)),
        '기계 검사 **%d/%d 통과**. 멀어질수록 원본과 어휘 겹침이 단조롭게 줄고 '
        '바뀐 맥락 축이 단조롭게 늘었다.' % (ok_n, len(auto)),
        '기계는 **"정말 같은 화용 능력을 요구하는가" 를 판정하지 못한다.** '
        '장면은 사람이 손으로 썼으므로 자동 생성기 성능이 아니다. '
        '구조화한 칸 중 gold 가 있는 것은 하나도 없다 (PROXY 또는 DEMONSTRATION).',
        '구조화와 거리 벌리기는 **된다.** 의미 판정은 사람 몫이고 '
        '팀 블라인드 리뷰가 진행 중이다 · **[TEAM MANUAL RESULT PENDING]**')]
    h.append('</section>')
    return chr(10).join(h)


def sec_q3(g):
    abl, pred = g['abl'], g['pred']
    h = ['<section class="q" id="q3">',
         '<p class="qk">질문 3</p>',
         '<h2>그 시스템이 제대로 작동하는지 어떤 객관적 기준으로 평가하는가</h2>']

    # 갈래끼리 실제로 같은 답을 했는가
    imp_pred = {}
    for r in g['pred']:
        if r['task'] == 'implicature':
            imp_pred.setdefault(r['arm'], {})[r['item_id']] = r['pred']
    full = [a for a in A.ARMS + getattr(A, 'CONTROL_ARMS', ())
            if len(imp_pred.get(a, {})) == 40]
    if len(full) >= 2:
        rows = []
        for x in full:
            row = [x]
            for y in full:
                if x == y:
                    row.append('-')
                    continue
                com = set(imp_pred[x]) & set(imp_pred[y])
                row.append('%.0f%%' % (100 * sum(
                    1 for i in com if imp_pred[x][i] == imp_pred[y][i]) / len(com)))
            rows.append(row)
        h += ['<h3>갈래끼리 같은 답을 했는가</h3>',
              '<p>정확도가 같다고 행동이 같은 것은 아니다. E0 와 E2 는 정확도도 '
              '오답 구실 분포도 똑같이 나왔지만, 실제로는 <b>11문항에서 다른 답</b>을 했다. '
              '우연히 총합이 맞아떨어졌을 뿐이다. 이 표가 그것을 가른다.</p>',
              table([''] + full, rows)]

    pf = os.path.join(HERE, '05_BENCHMARK', 'results', 'PLACEMENT.json')
    if os.path.exists(pf):
        fr = json.load(io.open(pf, encoding='utf-8'))
        h += ['<h3>정답 자리를 고르게 만든 것과 그 대가</h3>',
              '<p>배포된 CSV 는 정답이 120문항 전부 (1)번이다. 그대로 재면 "늘 1" 이라고 '
              '답하는 모델이 100%% 를 받는다. 채점 집합에 정답 자리를 고르게 배치해 '
              '우연 기준선을 <b>정확히 %.0f%%</b> 로 맞췄다. 다섯 갈래가 같은 배치를 쓰고, '
              '그 배치를 <code>PLACEMENT.json</code> 에 못박아 매번 대조한다.</p>'
              % (fr['majority_position_baseline'] * 100),
              '<p class="note"><b>이 처리는 점수를 낮춘다.</b> 1번 자리를 선호하는 모델은 '
              '고르지 않은 집합에서 실제 실력보다 높게 나온다. 실제로 이번에 그 일이 '
              '있었다 · 처음 채점하던 40문항은 1번에 14개가 몰려 다수 자리 기준선이 '
              '35% 였다. 그 결과는 버렸다. 새 숫자가 더 낮게 나오더라도 그것은 나빠진 것이 '
              '아니라 <b>부풀려져 있던 것이 빠진 것</b>이다.</p>',
              '<p>격률 안에서는 10문항을 4자리로 못 나눠 최빈 자리가 30% 다. 격률별 성적을 '
              '볼 때는 25% 가 아니라 30% 와 견준다.</p>']

    if not abl:
        h += ['<div class="callout warn"><h4>결과표는 아직 없다</h4>'
              '<p>다 돌린 칸이 없다. **가짜 숫자를 넣지 않는다.** '
              '아래 설계와 안전장치는 결과와 무관하게 그대로다.</p></div>']

    imp = [r for r in abl if r['task'] == 'implicature']
    mx = [r for r in abl if r['task'] == 'maxim']
    n_cells = len(abl)
    h += ['<div class="grid">',
          '<div class="stat"><b>%d / %d</b><span>다 돌린 칸</span></div>'
          % (g['cells_done'], g['cells_want']),
          '<div class="stat"><b>0.25</b><span>우연 기준선</span></div>',
          '<div class="stat"><b>0</b><span>누출</span></div>',
          '<div class="stat"><b>%s</b><span>상태</span></div>'
          % ('완료' if g['done'] else '도는 중'),
          '</div>']

    h += ['<h3>같게 둔 것과 다르게 둔 것</h3>',
          '<p>모델 · 온도 0 · seed · 출력 형식 · 시험 문항이 다섯 갈래에서 모두 같다. '
          'E3 와 E4 는 <b>같은 지식창고</b>를 쓰고 꺼내는 방법만 다르다. '
          '다른 것은 프롬프트에 무엇을 얹는가 하나뿐이다.</p>']

    if imp:
        h += ['<h3>함축 해석 · InterpretationAttribution</h3>',
              table(['갈래', '', 'n', '정확도', '95% 구간', 'macro F1', '형식실패', '입력토큰'],
                    [[r['arm'], r['arm_ko'], r['n'], '%.3f' % float(r['accuracy']),
                      '%.2f~%.2f' % (float(r['acc_lo95']), float(r['acc_hi95'])),
                      '%.3f' % float(r['macro_f1']), r['invalid_rate'],
                      '%.0f' % float(r['mean_prompt_tokens'])] for r in imp])]
        er_rows = []
        for r in imp:
            c, n = err_roles(pred, r['arm'])
            if n:
                er_rows.append([r['arm'], c.get('answer', 0), c.get('literal', 0),
                                c.get('wrong_in_context', 0), c.get('wrong_out_context', 0),
                                c.get('INVALID', 0)])
        if er_rows:
            h += ['<h4>틀릴 때 어떻게 틀리나</h4>',
                  '<p>자료가 오답마다 구실을 적어 두었다. 그래서 오답의 <b>종류</b>를 나눌 수 있다.</p>',
                  table(['갈래', '정답', '문자 그대로', '맥락 안 오답', '맥락 밖 오답', '형식실패'],
                        er_rows),
                  '<p class="note"><b>문자 그대로 읽어서 틀린 것</b>이 우리가 다루려는 증상이다. '
                  '전체 정확도보다 이 칸이 줄어드는 것이 우리에게 의미 있는 개선이다.</p>']
    if mx:
        h += ['<h3>격률 위반 · PhenomenonAttribution</h3>',
              table(['갈래', '', 'n', '정확도', '95% 구간', 'macro F1', '형식실패'],
                    [[r['arm'], r['arm_ko'], r['n'], '%.3f' % float(r['accuracy']),
                      '%.2f~%.2f' % (float(r['acc_lo95']), float(r['acc_hi95'])),
                      '%.3f' % float(r['macro_f1']), r['invalid_rate']] for r in mx])]

    # 길이 통제 · 내용인가 길이인가
    acc = {(r['task'], r['arm']): float(r['accuracy']) for r in abl}
    if all(('implicature', a) in acc for a in ('E0', 'E1', 'E1F')):
        e0, e1, ef = (acc[('implicature', x)] for x in ('E0', 'E1', 'E1F'))
        d_all, d_len = e1 - e0, ef - e0
        share = d_len / d_all if d_all else 0
        h += ['<h3>온톨로지 내용 때문인가, 프롬프트가 길어져서인가</h3>',
              '<p>E1 은 E0 보다 프롬프트가 길다. 그래서 좋아진 것이 온톨로지 <b>내용</b> 때문인지 '
              '<b>맥락이 길어져서</b>인지 그대로는 가를 수 없다. 같은 길이 · 같은 말투로 '
              '<b>화용과 아무 상관 없는 글</b>(문서 편집 규칙)을 넣은 갈래를 하나 더 돌렸다.</p>',
              table(['갈래', '얹은 것', '정확도', 'E0 대비'],
                    [['E0', '아무것도', '%.3f' % e0, '-'],
                     ['E1F', '무관한 정의문 (같은 길이)', '%.3f' % ef, '%+.3f' % d_len],
                     ['E1', '온톨로지 정의', '%.3f' % e1, '%+.3f' % d_all]]),
              '<p class="warn"><b>향상의 %.0f%% 가 길이만으로 재현된다.</b> '
              '상관없는 글을 같은 길이로 넣어도 %+.3f 올랐다. 온톨로지가 그 위에 %+.3f 를 '
              '더했지만, 40문항에서 둘 중 어느 구간도 개별로는 유의하지 않다. '
              '그래서 <b>"온톨로지 내용이 기여했다" 고 잘라 말하지 않는다.</b> '
              '가르려면 문항을 늘리거나 통제 갈래를 여러 개 두어야 한다.</p>'
              % (share * 100, d_len, d_all - d_len)]

    ea = os.path.join(HERE, '06_ABLATION', 'ERROR_ANALYSIS.md')
    if os.path.exists(ea):
        txt = io.open(ea, encoding='utf-8').read()
        vs = []
        for line in txt.split(chr(10)):
            if line.startswith('- **판정 · '):
                vs.append(line.replace('- **판정 · ', '').replace('**', ''))
        if vs:
            h += ['<h3>세 물음에 대한 판정</h3>', '<ul class="verdicts">']
            for v in vs:
                cls = ('ok' if 'DIFFERENT' in v else
                       'no' if 'NOT_ESTABLISHED' in v or 'IDENTICAL' in v else '')
                h.append('<li class="%s">%s</li>' % (cls, md(v)))
            h.append('</ul>')
    h += ['<p class="note">차이가 없으면 없다고 쓴다. E1 ≈ E2 ≈ E4 로 나오면 '
          '<b>GraphRAG necessity NOT ESTABLISHED</b> 라고 적는다. '
          '살리려고 결과를 비틀지 않는다.</p>']

    dg = os.path.join(HERE, '06_ABLATION', '_retrieval_diag.json')
    if os.path.exists(dg):
        d = json.load(io.open(dg, encoding='utf-8'))
        h += ['<h3>E3 와 E4 가 정말 다른 것을 꺼내는가</h3>',
              '<p>성능이 같게 나왔을 때 이유가 둘이다. 두 방법이 같은 것을 꺼냈거나, '
              '다른 것을 꺼냈는데도 차이가 없거나. 이걸 안 보고 "차이 없음" 이라고 하면 '
              '어느 쪽인지 모른 채 말하는 것이다.</p>',
              table(['', '값'],
                    [['똑같은 문서를 꺼낸 경우', '%d / %d' % (d['identical'], d['n'])],
                     ['평균 겹침 (Jaccard)', '%.3f' % d['mean_jaccard']],
                     ['E3 가 꺼낸 것', str(d['e3_kinds'])],
                     ['E4 가 꺼낸 것', str(d['e4_kinds'])],
                     ['E4 의 1홉 연결이 맞은 경우',
                      '**%d / %d** (우연 %.0f)' % (d['link_hit'], d['n'], d['chance'])]])]
        if not d['link_better_than_chance']:
            h += ['<p class="warn"><b>E4 의 개체 연결이 우연 수준이다.</b> '
                  '2홉은 1홉이 고른 어휘 마디에서 뻗어 나간다. 1홉이 우연이면 2홉이 '
                  '가져오는 보기도 엉뚱한 격률의 것이다. '
                  '그래서 E4 가 E3 보다 낫지 않게 나오더라도 그것은 '
                  '"그래프가 쓸모없다" 가 아니라 <b>"이 그래프의 개체 연결이 안 된다"</b> 로 '
                  '읽어야 한다. 둘은 다른 결론이고, 고칠 방향도 다르다.</p>']

    h += ['<h3>누출 검사</h3>',
          '<p>실험 전에 돌린다. 통과 못 하면 시작하지 않는다. 훈련 40 · 시험 40 겹침, '
          '창고 오염, <b>실제로 만들어진 프롬프트</b>에 정답이 실려 나가는지를 본다. '
          '일부러 새게 한 6가지를 심어 <b>6가지가 다 잡히는 것</b>을 확인한 뒤 통과를 믿는다.</p>',
          '<h3>왜 로컬 모델인가</h3>',
          '<p>시험에 쓰는 자료는 저장소에 라이선스가 없다. 권리 유보다. 외부 API 로 보내면 '
          '그 줄을 넘는다. ollama 의 exaone3.5:7.8b 와 bge-m3 은 이 컴퓨터를 떠나지 않는다. '
          'CPU 로 돌아 느리고, 그래서 문항을 40개로 줄였다. 그 사실을 적어 둔다.</p>',
          '<h3>여기서 재지 <b>않는</b> 것</h3>',
          '<p class="warn">이 숫자들은 <b>시스템의 화용 분석 성능</b>이다. '
          '사용자가 훈련 뒤 나아지는지는 재지 않았다. 둘은 다른 것이다. '
          '그리고 비임상 한국어로 잰 것을 <b>SCD 검증이라고 부르지 않는다.</b></p>']
    res_txt = ('아직 도는 중이다. **빈칸을 그럴듯한 숫자로 채우지 않는다.**'
               if not abl else
               '다 돌린 칸 %d개. 우연 기준선 0.25 와 견준다. 판정은 위 표에 있다.' % len(abl))
    h += [qsummary(
        '사람이 쓴 한국어 화용 gold (Park et al. PACLIC 38). 정답 자리를 고르게 배치해 썼다.',
        'E0~E4 를 같은 모델 · 같은 seed · 같은 문항 · 같은 창고에서 비교. '
        '누출 검사와 검색기 진단을 먼저 통과시킨다.',
        res_txt,
        '문항이 40개라 작은 차이는 못 가른다. 갈래마다 프롬프트 길이가 달라 '
        '온톨로지 내용의 기여와 맥락 길이의 기여를 **가르지 못한다.** '
        'E4 의 개체 연결이 우연 수준이라 그래프 쪽 결과는 구현 한계와 섞여 있다.',
        '함축 해석은 우연(0.25)보다 뚜렷이 낫고 온톨로지를 넣으면 더 낫다. '
        '다만 **그 향상의 절반 가까이가 길이만으로 재현되고**, 구조화(JSON)는 오히려 '
        '나빴으며, **GraphRAG 는 필요성이 서지 않았다.** 격률 판정은 우연 수준이라 '
        '지금 안 된다고 적는다. 이 숫자로 말할 수 있는 것은 시스템의 화용 분석 성능까지고, '
        '사용자가 나아지는지는 재지 않았다.')]
    h.append('</section>')
    return chr(10).join(h)


def sec_claims(g):
    cl = g['claims']
    can = [c for c in cl if c['level'] in ('VALIDATED', 'SUPPORTED', 'DEMONSTRATED')]
    cant = [c for c in cl if c['level'] in ('NOT TESTED', 'FUTURE WORK', 'DESIGNED')]
    h = ['<section class="q" id="claims">',
         '<p class="qk">마지막</p>',
         '<h2>무엇을 주장할 수 있고 무엇은 못 하는가</h2>',
         '<div class="two">',
         '<div><h3>할 수 있는 주장 · %d</h3><ul class="cl ok">' % len(can)]
    for c in can:
        h.append('<li><b>%s</b><span>%s</span><em>%s</em></li>'
                 % (md(c['level']), md(c['claim']), md(c['limitation'])))
    h += ['</ul></div>', '<div><h3>못 하는 주장 · %d</h3><ul class="cl no">' % len(cant)]
    for c in cant:
        h.append('<li><b>%s</b><span>%s</span><em>%s</em></li>'
                 % (md(c['level']), md(c['claim']), md(c['limitation'])))
    h += ['</ul></div></div>']
    if g['redteam']:
        r = g['redteam']
        h += ['<h3>예상 질문 대비</h3>',
              '<p>질문마다 SUPPORTED / PARTIAL / CANNOT CLAIM 을 붙였다. '
              'SUPPORTED %d · PARTIAL %d · CANNOT CLAIM %d. '
              '모르는 것을 억지로 방어하지 않는다. 전문은 <code>10_RED_TEAM</code> 에 있다.</p>'
              % (r['SUPPORTED'], r['PARTIAL'], r['CANNOT'])]
    h.append('</section>')
    return chr(10).join(h)


def build(g):
    parts = [sec_q1(g), sec_q2(g), sec_q3(g), sec_claims(g)]
    status = '실험 완료' if g['done'] else '실험 진행 중'
    return TPL.format(body=chr(10).join(parts), status=status,
                      n_data=len(g['census']), n_a=g['tier']['A'],
                      n_pred=len(g['pred']))


TPL = '''<!doctype html>
<html lang="ko"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>사회적 의사소통 AI 코치 · 근거 보고</title>
<style>
:root {{
  --pg:#fbfaf7; --pg2:#f3f1ea; --pg3:#e9e5da;
  --ink:#1f1d19; --ink2:#5a544a; --ink3:#8b8377;
  --rule:#ddd7c9; --acc:#7c4a2d; --accs:#f1e5dc;
  --ok:#2f6b47; --no:#8f3b2d; --pend:#8a6216;
  --sans:system-ui,"Segoe UI","Malgun Gothic","Apple SD Gothic Neo",sans-serif;
  --serif:"Iowan Old Style","Palatino Linotype",Batang,"Nanum Myeongjo",serif;
}}
@media (prefers-color-scheme:dark){{:root:not([data-theme=light]){{
  --pg:#16150f; --pg2:#1d1b15; --pg3:#26231c;
  --ink:#ece7db; --ink2:#b0a996; --ink3:#867e70;
  --rule:#332f26; --acc:#d9946a; --accs:#2b2018;
  --ok:#79b592; --no:#d98a78; --pend:#d3a65c;
}}}}
:root[data-theme=dark]{{
  --pg:#16150f; --pg2:#1d1b15; --pg3:#26231c;
  --ink:#ece7db; --ink2:#b0a996; --ink3:#867e70;
  --rule:#332f26; --acc:#d9946a; --accs:#2b2018;
  --ok:#79b592; --no:#d98a78; --pend:#d3a65c;
}}
*{{box-sizing:border-box}}
html,body{{overflow-x:clip}}
body{{margin:0;background:var(--pg);color:var(--ink);font-family:var(--sans);
  font-size:15.5px;line-height:1.72;-webkit-font-smoothing:antialiased}}
.wrap{{max-width:60rem;margin:0 auto;padding:0 1.5rem 7rem}}
header.top{{padding:5rem 0 2.5rem;border-bottom:2px solid var(--ink)}}
.kick{{font-size:.7rem;letter-spacing:.2em;text-transform:uppercase;color:var(--acc);
  font-weight:700;margin:0 0 1rem}}
h1{{font-family:var(--serif);font-style:normal;font-weight:600;
  font-size:clamp(1.9rem,5vw,3rem);line-height:1.15;margin:0 0 1.2rem;
  letter-spacing:-.015em;overflow-wrap:anywhere;min-width:0}}
.lede{{font-size:1.05rem;color:var(--ink2);max-width:42rem;margin:0 0 1.6rem}}
.meta{{display:flex;gap:1.5rem;flex-wrap:wrap;font-size:.8rem;color:var(--ink3);
  border-top:1px solid var(--rule);padding-top:1rem}}
.meta b{{color:var(--ink);font-variant-numeric:tabular-nums}}
section.q{{padding:3.5rem 0;border-bottom:1px solid var(--rule)}}
.qk{{font-size:.7rem;letter-spacing:.18em;text-transform:uppercase;
  color:var(--acc);font-weight:700;margin:0 0 .6rem}}
h2{{font-family:var(--serif);font-weight:600;font-style:normal;
  font-size:clamp(1.35rem,3.2vw,1.95rem);line-height:1.25;margin:0 0 1.6rem;
  overflow-wrap:anywhere;min-width:0}}
h3{{font-size:1.02rem;font-weight:650;margin:2.4rem 0 .7rem;
  padding-top:.9rem;border-top:1px solid var(--rule)}}
h4{{font-size:.92rem;font-weight:650;margin:1.6rem 0 .5rem;color:var(--ink)}}
p{{margin:0 0 .9rem;max-width:46rem}}
.note{{font-size:.88rem;color:var(--ink2);border-left:3px solid var(--acc);
  padding:.6rem 0 .6rem 1rem;background:var(--pg2)}}
.warn{{font-size:.88rem;color:var(--ink2);border-left:3px solid var(--no);
  padding:.6rem 0 .6rem 1rem;background:var(--pg2)}}
.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,11rem),1fr));
  gap:1px;background:var(--rule);border:1px solid var(--rule);margin:0 0 2rem}}
.stat{{background:var(--pg);padding:1.1rem 1.2rem}}
.stat b{{display:block;font-family:var(--serif);font-size:1.9rem;line-height:1;
  font-variant-numeric:tabular-nums;margin-bottom:.35rem}}
.stat span{{font-size:.74rem;color:var(--ink3);letter-spacing:.03em}}
.stat.pending b{{color:var(--pend);font-size:1.25rem;padding-top:.5rem}}
.tw{{overflow-x:auto;margin:0 0 1.4rem;border:1px solid var(--rule)}}
table{{border-collapse:collapse;width:100%;font-size:.85rem;min-width:30rem}}
th{{text-align:left;font-weight:650;background:var(--pg2);padding:.55rem .75rem;
  border-bottom:1px solid var(--rule);white-space:nowrap}}
td{{padding:.5rem .75rem;border-bottom:1px solid var(--rule);vertical-align:top}}
tr:last-child td{{border-bottom:0}}
td:first-child{{white-space:nowrap}}
.callout{{border:1px solid var(--rule);border-left:3px solid var(--acc);
  background:var(--pg2);padding:1.1rem 1.3rem;margin:1.2rem 0}}
.callout.pending{{border-left-color:var(--pend)}}
.callout.warn{{border-left-color:var(--no)}}
.callout h4{{margin:0 0 .6rem}}
.callout ul{{margin:0;padding-left:1.1rem}}
.callout li{{margin-bottom:.3rem;font-size:.88rem}}
.decide{{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,14rem),1fr));
  gap:1px;background:var(--rule);border:1px solid var(--rule);margin:1.4rem 0}}
.decide>div{{background:var(--pg);padding:1rem 1.1rem}}
.decide span{{display:block;font-size:.68rem;letter-spacing:.12em;
  text-transform:uppercase;color:var(--ink3);margin-bottom:.4rem}}
.decide b{{display:block;font-family:var(--serif);font-size:1.15rem;margin-bottom:.25rem}}
.decide em{{font-style:normal;font-size:.78rem;color:var(--ink3)}}
.verdicts{{list-style:none;padding:0;margin:0 0 1.2rem}}
.verdicts li{{padding:.5rem .8rem;border-left:3px solid var(--ink3);
  background:var(--pg2);margin-bottom:.4rem;font-size:.86rem}}
.verdicts li.ok{{border-left-color:var(--ok)}}
.verdicts li.no{{border-left-color:var(--pend)}}
.two{{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,20rem),1fr));
  gap:2rem}}
.cl{{list-style:none;padding:0;margin:0}}
.cl li{{padding:.7rem .9rem;background:var(--pg2);border-left:3px solid var(--rule);
  margin-bottom:.5rem}}
.cl.ok li{{border-left-color:var(--ok)}}
.cl.no li{{border-left-color:var(--no)}}
.cl b{{display:block;font-size:.66rem;letter-spacing:.1em;color:var(--ink3);
  margin-bottom:.25rem}}
.cl span{{display:block;font-size:.88rem;margin-bottom:.3rem}}
.cl em{{display:block;font-style:normal;font-size:.76rem;color:var(--ink3)}}
dl.qs{{display:grid;grid-template-columns:auto 1fr;gap:1px;margin:2rem 0 0;
  background:var(--rule);border:1px solid var(--rule)}}
dl.qs dt{{background:var(--pg2);padding:.65rem .9rem;font-size:.7rem;font-weight:700;
  letter-spacing:.1em;color:var(--acc);white-space:nowrap}}
dl.qs dd{{background:var(--pg);padding:.65rem .9rem;margin:0;font-size:.88rem}}
@media(max-width:560px){{dl.qs{{grid-template-columns:1fr}}
  dl.qs dt{{padding-bottom:.2rem}}}}
code{{font-family:ui-monospace,Consolas,monospace;font-size:.85em;
  background:var(--pg3);padding:.1em .35em}}
footer{{padding:3rem 0;font-size:.8rem;color:var(--ink3)}}
@media(max-width:640px){{header.top{{padding-top:3rem}}section.q{{padding:2.5rem 0}}}}
</style></head><body><div class="wrap">

<header class="top">
<p class="kick">Instructor evidence · 2026-09-15</p>
<h1>내가 겪은 상황이, 다음 연습이 된다</h1>
<p class="lede">사회적 의사소통 개선을 위한 AI 대화 훈련 서비스.
이 문서는 세 질문에 데이터와 실험으로 답한다.
답하지 못하는 것은 답하지 못한다고 적었다.</p>
<div class="meta">
<span>조사한 자료 <b>{n_data}</b></span>
<span>실제로 쓸 수 있는 자료 <b>{n_a}</b></span>
<span>실험 예측 <b>{n_pred}</b></span>
<span>상태 <b>{status}</b></span>
<span>사람 대상 연구 <b>없음</b></span>
</div>
</header>

{body}

<footer>
<p>이 문서의 숫자는 전부 같은 폴더의 CSV 에서 읽어 만든다.
손으로 적은 숫자는 없다. 자료가 바뀌면 <code>python build_report.py</code> 를 다시 돌린다.</p>
<p>KMI 예시 출처 · Kim, Hyunjong et al. "KMI: A Dataset of Korean Motivational
Interviewing Dialogues for Psychotherapy." NAACL 2025. CC BY 4.0.<br>
한국어 화용 평가셋 · Park, Dojun et al. PACLIC 38 (2024). 라이선스 없음 ·
집계 숫자만 싣고 원문 예시는 싣지 않는다.</p>
</footer>
</div></body></html>
'''


def main():
    g = gather()
    io.open(OUT, 'w', encoding='utf-8', newline='\n').write(build(g))
    size = os.path.getsize(OUT)

    # 요약 md 둘
    d = os.path.join(HERE, '00_EXECUTIVE')
    if not os.path.isdir(d):
        os.makedirs(d)
    pb = sorted(g['bench'], key=lambda x: -g['bench'][x])[0]
    pp = sorted(g['prob'], key=lambda x: -g['prob'][x])[0]
    cl = collections.Counter(c['level'] for c in g['claims'])
    io.open(os.path.join(d, 'ONE_PAGE_DECISION.md'), 'w', encoding='utf-8',
            newline='\n').write(chr(10).join([
                '# 한 장 요약', '',
                '| | |', '|---|---|',
                '| 조사한 자료 | %d개 |' % len(g['audit']),
                '| 지금 쓸 수 있는 자료 (TIER A) | **%d개** · %s |'
                % (g['tier']['A'], ' · '.join(r['name'] for r in g['tierA']) or '없음'),
                '| 직접 검증 가능한 온톨로지 필드 | %d / 7 |'
                % g['fstat']['DIRECTLY_VALIDATABLE'],
                '| BENCHMARK_CORE 기술 | %s |'
                % (' · '.join(s['skill_id'] for s in g['skills']
                              if s['evidence_tier'] == 'BENCHMARK_CORE') or '없음'),
                '| PROBLEM GROUNDING | SCD 아동 · ASD 아동 |',
                '| TECHNICAL BENCHMARK | %s |' % pb,
                '| PRODUCT TARGET | **PROVISIONAL** |',
                '| 할 수 있는 주장 | %d |' % (cl['VALIDATED'] + cl['SUPPORTED']
                                        + cl['DEMONSTRATED']),
                '| 못 하는 주장 | %d |' % (cl['NOT TESTED'] + cl['FUTURE WORK']),
                '| 사람 대상 연구 | 없음 |',
                '| 팀 수동 리뷰 | [TEAM MANUAL RESULT PENDING] |', '',
                '## 한 문장', '',
                '한국어 화용 gold 로 시스템의 함축 해석과 격률 판정을 잴 수 있고,',
                '같은 사건에서 거리를 벌린 장면을 만들 수 있다.',
                '**사용자가 나아지는지는 재지 않았고, SCD 집단을 검증하지도 않았다.**', '',
                '## 가장 아픈 곳 세 가지', '',
                '1. 쓸 수 있는 Human Gold 자료가 **하나뿐**이고 120문항이다.',
                '2. 제품에서 가장 중요한 S2(관계·상황 조정)에 **잴 수 있는 gold 가 없다**.',
                '3. 지금 기술 POC 대상인 SCD 청년이 아홉 집단 중 **근거가 가장 얇다**.', '',
            ]) + chr(10))
    io.open(os.path.join(d, 'INSTRUCTOR_3_QUESTIONS.md'), 'w', encoding='utf-8',
            newline='\n').write(chr(10).join([
                '# 세 질문과 답', '',
                '## Q1 · Ontology 를 어디까지 적용할 것인가', '',
                '- 47개를 다시 봤다. 실제로 쓸 수 있는 것은 **%d개**.' % g['tier']['A'],
                '- 온톨로지 7필드 중 **%d개**가 직접 검증 가능, %d개는 proxy, %d개는 gold 자체가 없다.'
                % (g['fstat']['DIRECTLY_VALIDATABLE'], g['fstat']['PROXY_VALIDATABLE'],
                   g['fstat']['NOT_VALIDATABLE']),
                '- 문제 근거 집단(%s)과 benchmark 집단(%s)이 **다르다**. 합치지 않는다.' % (pp, pb),
                '- 자세히 · `01_DATA/TIER_A_DATASETS.md` · `02_TARGET/TARGET_DECISION.md` ·'
                ' `03_ONTOLOGY/VALIDATABLE_FIELDS.md`', '',
                '## Q2 · 실제 대화를 다른 훈련 상황으로 바꿀 수 있는가', '',
                '- 공개 대화 %d건을 Social Event 로 구조화했다 (KMI · CC BY 4.0).' % len(g['events']),
                '- 장면 %d개에서 기계 검사가 전부 통과했고, 멀어질수록 어휘 겹침이 줄었다.'
                % len(g['auto']),
                '- **"정말 같은 능력을 요구하는가" 는 사람이 판정한다. 현재 PENDING.**',
                '- 자세히 · `07_SOCIAL_EVENT/` · `08_SCENARIO/AUTO_CHECK_RESULTS.csv`', '',
                '## Q3 · 무엇으로 객관적으로 평가하는가', '',
                '- 사람이 쓴 한국어 gold 로 E0~E4 를 같은 조건에서 비교한다.',
                '- 우연 기준선 25% · 누출 0 · 심은 누출 6/6 적발.',
                '- **시스템 성능과 사용자 효과를 구분한다. 후자는 재지 않았다.**',
                '- 자세히 · `06_ABLATION/ERROR_ANALYSIS.md` · `06_ABLATION/E0_E4_PROTOCOL.md`', '',
            ]) + chr(10))

    print('보고서 · %s (%s bytes)' % (os.path.basename(OUT), format(size, ',')))
    print('  자료 %d · TIER A %d · 필드 직접검증 %d/7 · 예측 %d줄 · %s'
          % (len(g['audit']), g['tier']['A'], g['fstat']['DIRECTLY_VALIDATABLE'],
             len(g['pred']), '완료' if g['done'] else '도는 중'))
    print('  00_EXECUTIVE 2개도 같이 만들었다')
    return 0


if __name__ == '__main__':
    sys.exit(main())
