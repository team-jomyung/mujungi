# 타겟을 데이터로 다시 본다

사람을 모집하지 않는다. 그래서 모집 난이도 · 참여 편의 · IRB 용이성을
순위 기준에서 **뺐다.** 남은 것은 근거와 데이터뿐이다.

## 두 축을 따로 센다

| 집단 | benchmark 가능성 (21점) | 문제 근거 (6점) | 기술 적합 (3점) | Human Gold |
|---|---|---|---|---|
| nonclinical Korean population | 18 | 1 | 3 | STRONG |
| ASD child | 11 | 6 | 1 | MODERATE |
| PLI | 10 | 4 | 1 | WEAK |
| SCD child | 9 | 6 | 1 | WEAK |
| DLD/social-pragmatic difficulty | 8 | 5 | 1 | WEAK |
| ASD adolescent | 4 | 3 | 0 | NONE |
| SCD adolescent | 2 | 3 | 0 | NONE |
| SCD young adult | 1 | 2 | 0 | NONE |
| ASD young adult | 0 | 3 | 0 | NONE |

두 축의 1위가 **다르다.** benchmark 는 nonclinical Korean population, 문제 근거는 SCD child 다.
이것이 이번 조사의 핵심이다.

## 세 가지를 같게 두지 않는다

| | 집단 | 근거 |
|---|---|---|
| PROBLEM GROUNDING | SCD 아동 · ASD 아동 | 문제 근거 6/6 · 6/6 로 가장 두껍다 |
| TECHNICAL BENCHMARK | 비임상 한국어 | benchmark 18/21 · 유일하게 Human Gold=STRONG |
| PRODUCT TARGET | **PROVISIONAL · 확정하지 않는다** | 아래 참조 |

## 강사님이 물을 것 · "아동 근거가 더 많은데 왜 아동이 아닌가"

**근거상으로는 아동이 맞다.** 그것을 숨기지 않는다.
SCD 아동 문제 근거 6/6 · SCD 청소년 3/6 · SCD 청년 2/6 이다.
문헌은 아동을 가리킨다.

그래서 **문제 근거 집단을 아동으로 적는다.** 제품 타겟과 분리해서.

제품 타겟을 아동으로 바로 옮기지 않는 이유는 근거가 아니라 매체와 절차다.
- 우리 제품은 글로 하는 자기 연습이다. 아동은 보호자 동의와 다른 설계가 필요하다.
- **아동도 benchmark 가 없다.** SCD 아동 benchmark 가능성은 9/21 이고 Human Gold 는 WEAK 다.
  아동으로 옮겨도 잴 것이 생기지 않는다. 옮기는 것이 문제를 풀지 않는다.

## 두 번째 질문 · "아동도 Human-Gold benchmark 가 없나"

**없다.** 임상군 전체가 그렇다.

| 집단 | 공개 원자료 | Human Gold | 한국어 | benchmark 가능성 |
|---|---|---|---|---|
| nonclinical Korean population | MODERATE | STRONG | STRONG | STRONG |
| ASD child | MODERATE | MODERATE | NONE | WEAK |
| PLI | NONE | WEAK | NONE | NONE |
| SCD child | WEAK | WEAK | WEAK | NONE |
| DLD/social-pragmatic difficulty | NONE | WEAK | WEAK | NONE |
| ASD adolescent | NONE | NONE | WEAK | NONE |
| SCD adolescent | WEAK | NONE | WEAK | NONE |
| SCD young adult | WEAK | NONE | NONE | NONE |
| ASD young adult | NONE | NONE | NONE | NONE |

임상군 중 Human Gold 가 MODERATE 이상인 것은 ASD 아동뿐이고
그것도 한국어가 NONE 다. 영어 자료다.

## 지금 우리 기술 POC 대상이 가장 약하다

SCD 청년(18~25)은 benchmark 1/21 · 문제 근거 2/6 으로
아홉 집단 중 가장 낮은 축이다. **이 사실을 감추지 않는다.**

기술 POC 를 비임상 한국어로 돌린 것은 그래서 맞는 선택이었다.
다만 그것을 "SCD 를 검증했다" 고 부르면 안 된다. 부르지 않는다.

## 결론

```
PROBLEM GROUNDING POPULATION  = SCD 아동 · ASD 아동 (문헌)
TECHNICAL BENCHMARK POPULATION = 비임상 한국어 (유일하게 잴 수 있다)
PRODUCT TARGET                 = PROVISIONAL (확정 보류)
```

데이터가 그렇게 말한다. 셋을 하나로 합치면 어느 하나가 거짓이 된다.
