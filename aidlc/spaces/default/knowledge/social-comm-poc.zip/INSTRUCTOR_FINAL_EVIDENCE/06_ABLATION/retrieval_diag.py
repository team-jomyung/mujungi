# -*- coding: utf-8 -*-
"""E3 와 E4 가 정말 다른 것을 꺼내는가. 그리고 그래프 연결이 맞는가.

    python retrieval_diag.py

왜 이것을 따로 보나
  성능이 같게 나왔을 때 이유가 둘이다.
    (가) 두 방법이 같은 것을 꺼내서 → 애초에 비교가 아니었다
    (나) 다른 것을 꺼냈는데 성능이 같아서 → 진짜로 차이가 없다
  이걸 안 보고 "차이 없음" 이라고 하면 어느 쪽인지 모른 채 말하는 것이다.

  그리고 E4 의 1홉 연결이 맞는지도 본다. 연결이 우연 수준이면
  2홉으로 가져온 것이 엉뚱한 것이다. **성능 차이가 없는 이유를 여기서 찾는다.**
"""
from __future__ import annotations

import collections
import io
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', '05_BENCHMARK', 'harness'))
import arms as A  # noqa: E402
import data as D  # noqa: E402
import kb as KB  # noqa: E402
import llm as L  # noqa: E402

OUT = os.path.join(HERE, 'RETRIEVAL_DIAGNOSTIC.md')


def main():
    if not L.alive():
        print('ollama 가 없다')
        return 2
    items = D.load_kpt()
    tr, te = D.split_kpt(items)
    te = D.subsample(te, 10)
    docs = KB.build_docs(tr)
    vi, g = KB.VectorIndex(docs), KB.Graph(docs)

    same = 0
    ov = []
    k3, k4 = collections.Counter(), collections.Counter()
    link_hit = 0
    link_conf = collections.Counter()
    for it in te:
        q = A.retrieval_key('implicature', it)
        a = {d['id'] for d in vi.search(q, k=3)}
        b = {d['id'] for d in g.search(q, k=3)}
        ov.append(len(a & b) / len(a | b) if (a | b) else 0.0)
        same += (a == b)
        for d in vi.search(q, k=3):
            k3[d['kind']] += 1
        for d in g.search(q, k=3):
            k4[d['kind']] += 1
        got = g.link(q)['vocab']
        link_hit += (got == it['maxim'])
        link_conf[(it['maxim'], got)] += 1

    n = len(te)
    chance = n / len(D.MAXIMS)
    lines = [
        '# 검색기 진단 · E3 와 E4 가 정말 다른가', '',
        '시험 항목 %d개로 봤다. 모델을 부르지 않고 꺼내는 단계만 본다.' % n, '',
        '## 두 방법이 다른 것을 꺼내는가', '',
        '| | |', '|---|---|',
        '| 똑같은 문서를 꺼낸 경우 | **%d / %d** |' % (same, n),
        '| 평균 겹침 (Jaccard) | **%.3f** |' % (sum(ov) / n),
        '| E3 가 꺼낸 것 | %s |' % dict(k3),
        '| E4 가 꺼낸 것 | %s |' % dict(k4), '',
        '겹침이 거의 0 이다. **두 방법은 실제로 다른 것을 꺼낸다.**',
        '그러니 성능이 같게 나온다면 그것은 "같은 것을 봐서" 가 아니라 진짜로 차이가 없는 것이다.', '',
        'E3 은 보기(example)를 주로 꺼내고 E4 는 어휘(vocabulary) 정의를 주로 꺼낸다.',
        '설계한 대로다. E3 은 뜻이 가까운 사례를, E4 는 고를 값의 정의를 준다.', '',
        '## E4 의 1홉 연결이 맞는가', '',
        '| | |', '|---|---|',
        '| 연결이 실제 격률과 맞은 경우 | **%d / %d** |' % (link_hit, n),
        '| 우연히 맞을 기대값 | %.0f / %d |' % (chance, n),
        '| 우연 대비 | **%+.0f** |' % (link_hit - chance), '',
    ]
    if link_hit <= chance:
        lines += [
            '**연결이 우연 수준이다.** 이것이 중요하다.', '',
            'E4 의 2홉은 1홉이 고른 어휘 마디에서 뻗어 나간다. 1홉이 우연 수준이면',
            '2홉으로 가져온 보기도 엉뚱한 격률의 것이다. 즉 지금 구조에서 그래프 검색은',
            '**어휘 정의 넷을 나열해 주는 것 이상을 못 하고 있다.**', '',
            '그래서 E4 가 E3 보다 낫지 않게 나오더라도, 그것은 "그래프가 쓸모없다" 가 아니라',
            '**"이 그래프의 개체 연결이 안 된다"** 로 읽어야 한다. 둘은 다른 결론이다.', '',
            '고치려면 · 어휘 마디에 정의만 두지 말고 그 격률의 전형적 표현 양상을 붙이거나,',
            '1홉을 임베딩 대신 분류기로 바꾸는 것을 봐야 한다. 이번 범위 밖이다.', '',
        ]
    else:
        lines += ['연결이 우연보다 낫다. 2홉이 같은 격률의 보기를 가져온다.', '']

    lines += ['## 연결 혼동표', '',
              '| 실제 격률 | 연결된 어휘 | 개수 |', '|---|---|---|']
    for (real, got), c in sorted(link_conf.items(), key=lambda x: -x[1]):
        mark = ' ✓' if real == got else ''
        lines.append('| %s | %s%s | %d |' % (real, got, mark, c))
    lines += ['', '이 진단은 `python retrieval_diag.py` 로 다시 만든다.', '']

    io.open(OUT, 'w', encoding='utf-8', newline='\n').write(chr(10).join(lines))
    io.open(os.path.join(HERE, '_retrieval_diag.json'), 'w', encoding='utf-8',
            newline='\n').write(json.dumps({
                'n': n, 'identical': same, 'mean_jaccard': round(sum(ov) / n, 4),
                'e3_kinds': dict(k3), 'e4_kinds': dict(k4),
                'link_hit': link_hit, 'chance': chance,
                'link_better_than_chance': link_hit > chance,
            }, ensure_ascii=False, indent=2) + chr(10))

    print('시험 항목 %d' % n)
    print('  똑같이 꺼낸 경우 %d/%d · 평균 겹침 %.3f' % (same, n, sum(ov) / n))
    print('  E3 %s · E4 %s' % (dict(k3), dict(k4)))
    print('  1홉 연결 %d/%d (우연 %.0f) · %s'
          % (link_hit, n, chance, '우연 수준' if link_hit <= chance else '우연보다 낫다'))
    print('저장 · %s' % os.path.basename(OUT))
    return 0


if __name__ == '__main__':
    sys.exit(main())
