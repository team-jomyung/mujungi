# -*- coding: utf-8 -*-
"""E0~E4 결과를 읽고 세 물음에 답한다.

    python analyze.py

세 물음
  1 Ontology 를 넣으면 실제로 좋아지는가            E0 vs E1
  2 바깥 구조로 준 것이 프롬프트 글보다 나은가        E1 vs E2
  3 GraphRAG 가 Vector RAG 보다 나은가              E3 vs E4

짝지어 본다
  갈래끼리 정확도만 비교하면 40문항에서 한두 개 차이가 커 보인다.
  같은 문항을 두 갈래가 맞혔는지 짝지어 보는 McNemar 가 맞다.
  **한쪽만 맞힌 문항 수**가 실제로 달라진 양이다.

차이가 없으면 없다고 쓴다
  E1 ≈ E2 ≈ E4 로 나오면 `GraphRAG necessity NOT ESTABLISHED` 라고 적는다.
  살리려고 결과를 비틀지 않는다.
"""
from __future__ import annotations

import collections
import csv
import io
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', '05_BENCHMARK', 'harness'))
import arms as A  # noqa: E402
import metrics as M  # noqa: E402

sys.path.insert(0, os.path.join(HERE, '..', '05_BENCHMARK'))
RES = os.path.join(HERE, '..', '05_BENCHMARK', 'results')
JL = os.path.join(RES, 'raw_predictions.jsonl')


def load():
    """돌아가는 중에도 읽는다. 마지막 줄이 쓰이다 말았을 수 있으니 못 읽는 줄은 건너뛴다."""
    if not os.path.exists(JL):
        return []
    out, skipped = [], 0
    for x in io.open(JL, encoding='utf-8'):
        x = x.strip()
        if not x:
            continue
        try:
            out.append(json.loads(x))
        except ValueError:
            skipped += 1
    if skipped:
        print('  (쓰이다 만 줄 %d개를 건너뛰었다 · 아직 도는 중이다)' % skipped)
    return out


def cells(rows):
    c = collections.OrderedDict()
    for r in rows:
        c.setdefault((r['task'], r['arm']), []).append(r)
    return c


def control_note(c, task='implicature'):
    """길이 통제 갈래가 무엇을 말하는가. 한 줄로 정리한다."""
    have = {a for t, a in c if t == task}
    if not {'E0', 'E1', 'E1F'} <= have:
        return None
    import metrics as M2
    g = {a: M2.score(c[(task, a)], A.TASKS[task]['labels'])['accuracy']
         for a in ('E0', 'E1', 'E1F')}
    d_all = g['E1'] - g['E0']
    d_len = g['E1F'] - g['E0']
    share = (d_len / d_all) if d_all else 0.0
    if d_all <= 0:
        v = '온톨로지가 E0 보다 낫지 않다. 길이 논의가 의미 없다'
    elif share >= 0.7:
        v = '**좋아진 것의 대부분이 길이 때문이다.** 온톨로지 내용의 기여를 주장할 수 없다'
    elif share <= 0.3:
        v = '**길이만으로는 거의 안 좋아진다.** 좋아진 것은 내용 때문으로 읽는다'
    else:
        v = '길이와 내용이 섞여 있다. 어느 쪽이라고 잘라 말하지 않는다'
    return {'E0': g['E0'], 'E1': g['E1'], 'E1F': g['E1F'],
            'delta_total': round(d_all, 4), 'delta_length_only': round(d_len, 4),
            'length_share': round(share, 3), 'verdict': v}


def expected_n():
    """칸 하나에 몇 문항이 들어와야 하는가. **설계에서 읽는다.**

    앞서 본 것 중 가장 많은 수를 기준으로 삼았더니, 막 시작해 두 줄만 있을 때
    그 두 줄짜리 칸을 "다 돌린 칸" 으로 세었다. 재는 대상에서 기준을 뽑으면
    이런 일이 난다. 기준은 자료가 아니라 설계에서 와야 한다."""
    import data as D
    items = D.load_kpt()
    _tr, te = D.split_kpt(items)
    return {'implicature': len(D.subsample(te, 10)),
            'maxim': len(D.subsample(te, 10))}


def complete_only(c):
    """다 안 끝난 칸은 뺀다. 절반 돌린 칸을 다 돌린 칸과 견주면 안 된다."""
    want = expected_n()
    out = collections.OrderedDict(
        ((t, a), rs) for (t, a), rs in c.items()
        if len(rs) == want.get(t, -1))
    seen = collections.Counter()
    for (t, _a), rs in c.items():
        seen[t] = max(seen[t], len(rs))
    return out, {t: want.get(t, seen[t]) for t in seen}


def compare(c, task, x, y):
    if (task, x) not in c or (task, y) not in c:
        return None
    ax, ay = c[(task, x)], c[(task, y)]
    sx = M.score(ax, A.TASKS[task]['labels'])
    sy = M.score(ay, A.TASKS[task]['labels'])
    mc = M.mcnemar(ax, ay)
    return {'task': task, 'a': x, 'b': y,
            'acc_a': sx['accuracy'], 'acc_b': sy['accuracy'],
            'delta': round(sy['accuracy'] - sx['accuracy'], 4),
            'only_a': mc['b'], 'only_b': mc['c'], 'p': mc['p'],
            'f1_a': sx['macro_f1'], 'f1_b': sy['macro_f1']}


def verdict(cmp_, p_key='p'):
    """차이가 있다고 말할 수 있는가. 40문항이라 엄격하게 본다."""
    if cmp_ is None:
        return 'NOT_RUN', '이 칸을 안 돌렸다'
    if cmp_['only_a'] + cmp_['only_b'] == 0:
        return 'IDENTICAL', '두 갈래가 모든 문항에서 똑같이 답했다'
    pv = cmp_.get(p_key, cmp_['p'])
    d = '좋아지는' if cmp_['delta'] > 0 else '나빠지는'
    tail = '한쪽만 맞힌 문항 %d대%d' % (cmp_['only_a'], cmp_['only_b'])
    if pv < 0.05:
        return 'DIFFERENT', '%s 쪽 · Holm p=%.3f (원p=%.3f) · %s' % (d, pv, cmp_['p'], tail)
    if cmp_['p'] < 0.05:
        # 보정 전에는 유의했다. **신호는 있는데 여러 번 비교를 견디지 못한다.**
        # 이것을 그냥 NOT_ESTABLISHED 로 뭉치면 정보를 버리는 것이다.
        return 'SIGNAL_NOT_ESTABLISHED', (
            '%s 쪽 신호는 보이나 여러 번 비교를 견디지 못한다 · '
            '원p=%.3f → Holm p=%.3f · %s' % (d, cmp_['p'], pv, tail))
    return 'NOT_ESTABLISHED', 'Holm p=%.3f (원p=%.3f) · %s · 못 가른다' % (
        pv, cmp_['p'], tail)


def main():
    rows = load()
    if not rows:
        print('결과가 없다 · 05_BENCHMARK/harness/run.py 를 먼저 돌린다')
        io.open(os.path.join(HERE, 'NOT_EXECUTED.md'), 'w', encoding='utf-8',
                newline='\n').write(
            '# NOT_EXECUTED\n\nE0~E4 를 돌리지 않았다. 가짜 숫자를 넣지 않는다.\n')
        return 2

    # 다섯 갈래가 같은 보기 순서를 봤는가. 못박은 것과 대조한다.
    pf = os.path.join(RES, 'PLACEMENT.json')
    if os.path.exists(pf):
        import freeze_placement as FP
        frozen = json.load(io.open(pf, encoding='utf-8'))
        pbad = FP.verify(frozen, rows)
        print('보기 순서 · %s (기준선 %.3f)'
              % ('갈래마다 같다' if not pbad else '**어긋났다**',
                 frozen['majority_position_baseline']))
        for b in pbad[:6]:
            print('    %s' % b)
        if pbad:
            print('  **항목 단위 비교가 성립하지 않는다. 멈춘다.**')
            return 2

    allc = cells(rows)
    c, ns = complete_only(allc)
    partial = [k for k in allc if k not in c]
    print('예측 %d줄 · 다 돌린 칸 %d · 도는 중 %d' % (len(rows), len(c), len(partial)))
    for t, n in ns.items():
        print('  %s · 문항 %d' % (t, n))
    if partial:
        print('  아직 · %s' % ', '.join('%s/%s(%d)' % (t, a, len(allc[(t, a)]))
                                      for t, a in partial))

    # 결과표
    out = [['task', 'arm', 'arm_ko', 'n', 'accuracy', 'macro_f1', 'invalid_rate',
            'median_seconds', 'mean_prompt_tokens', 'mean_output_tokens',
            'acc_lo95', 'acc_hi95']]
    print()
    print('%-12s %-3s %-22s %4s %8s %8s %7s %7s %7s' % (
        'task', 'arm', '', 'n', '정확도', 'macroF1', '형식실패', '중앙초', '입력토큰'))
    for (task, arm), rs in sorted(c.items()):
        s = M.score(rs, A.TASKS[task]['labels'])
        lo, hi = M.wilson(s['correct_n'], s['n'])
        out.append([task, arm, A.ARM_KO[arm], s['n'], s['accuracy'], s['macro_f1'],
                    s['invalid_rate'], s['median_seconds'], s['mean_prompt_tokens'],
                    s['mean_output_tokens'], lo, hi])
        print('%-12s %-3s %-22s %4d %8.3f %8.3f %7.2f %7.1f %7.0f' % (
            task, arm, A.ARM_KO[arm], s['n'], s['accuracy'], s['macro_f1'],
            s['invalid_rate'], s['median_seconds'], s['mean_prompt_tokens']))
    with io.open(os.path.join(HERE, 'results.csv'), 'w',
                 encoding='utf-8-sig', newline='') as fh:
        csv.writer(fh).writerows(out)

    # 세 물음
    Q = [('1 Ontology 를 넣으면 좋아지는가', 'E0', 'E1'),
         ('1b 길이 통제 · 무관한 정의문도 좋아지나', 'E0', 'E1F'),
         ('1c 내용 때문인가 길이 때문인가', 'E1F', 'E1'),
         ('2 바깥 구조가 프롬프트 글보다 나은가', 'E1', 'E2'),
         ('3 GraphRAG 가 Vector RAG 보다 나은가', 'E3', 'E4'),
         ('참고 · RAG 가 Ontology 프롬프트보다 나은가', 'E1', 'E3')]
    # Holm · 과제마다 따로 조정한다. 한 과제 안에서 비교를 넷 하기 때문이다
    raw = {}
    for label, x, y in Q:
        for task in sorted({t for t, _a in c}):
            cm = compare(c, task, x, y)
            if cm:
                raw[(task, label)] = cm['p']
    by_task = {}
    for task in sorted({t for t, _l in raw}):
        sub = {k: v for k, v in raw.items() if k[0] == task}
        by_task.update(M.holm(sub))

    print()
    print('세 물음 · **Holm 조정** (과제마다 비교 %d개)'
          % max([sum(1 for k in raw if k[0] == t) for t in {k[0] for k in raw}] or [0]))
    ans = []
    for label, x, y in Q:
        for task in sorted({t for t, _a in c}):
            cm = compare(c, task, x, y)
            if cm:
                cm['p_holm'] = by_task.get((task, label), cm['p'])
            v, why = verdict(cm, p_key='p_holm')
            ans.append({'question': label, 'task': task, 'a': x, 'b': y,
                        'verdict': v, 'why': why, 'cmp': cm})
            if cm:
                print('  %-34s %-12s %s→%s  %.3f→%.3f  p=%.3f→%.3f  %s' % (
                    label, task, x, y, cm['acc_a'], cm['acc_b'],
                    cm['p'], cm['p_holm'], v))
            else:
                print('  %-34s %-12s %s→%s  %s' % (label, task, x, y, v))

    # 갈래끼리 실제로 같은 답을 했는가.
    # E0 와 E2 가 정확도도 오답 구실 분포도 똑같이 나왔다. 그대로 보면
    # "E2 가 구조를 통째로 무시했다" 로 읽힌다. 실제로는 11문항에서 답이 달랐고
    # 우연히 총합이 같았을 뿐이다. **총합이 같다고 행동이 같은 것이 아니다.**
    arms_done = [a for t, a in c if t == 'implicature']
    if len(arms_done) >= 2:
        by = {}
        for (t, arm), rs in c.items():
            if t == 'implicature':
                by[arm] = {r['item_id']: r['pred'] for r in rs}
        print()
        print('갈래끼리 같은 답을 한 비율 (함축)')
        order = [a for a in A.ARMS + A.CONTROL_ARMS if a in by]
        print('      ' + ' '.join('%6s' % a for a in order))
        for a in order:
            cols = []
            for b in order:
                if a == b:
                    cols.append('%6s' % '-')
                    continue
                com = set(by[a]) & set(by[b])
                cols.append('%5.0f%%' % (100 * sum(
                    1 for i in com if by[a][i] == by[b][i]) / len(com)) if com
                    else '%6s' % '-')
            print('  %-4s' % a + ' '.join(cols))
        print('  정확도가 같아도 답이 같은 것은 아니다. 이 표가 그것을 가른다.')

    cn = control_note(c)
    if cn:
        print()
        print('길이 통제 · 온톨로지 내용인가 프롬프트 길이인가')
        print('  E0 %.3f · E1F(무관한 정의문) %.3f · E1(온톨로지) %.3f'
              % (cn['E0'], cn['E1F'], cn['E1']))
        print('  전체 향상 %+.3f 중 길이만으로 %+.3f (%.0f%%)'
              % (cn['delta_total'], cn['delta_length_only'], cn['length_share'] * 100))
        print('  판정 · %s' % cn['verdict'].replace('**', ''))

    # 오답 방식
    print()
    print('함축 과제 · 틀렸을 때 어느 구실을 골랐나')
    er = {}
    for (task, arm), rs in sorted(c.items()):
        if task != 'implicature':
            continue
        e = M.error_roles(rs)
        er[arm] = e
        tot = sum(e.values()) or 1
        print('  %-3s %s' % (arm, ' · '.join(
            '%s %d(%.0f%%)' % (k, v, 100 * v / tot) for k, v in sorted(e.items()))))

    write_docs(c, ns, ans, er, partial)
    print()
    print('저장 · results.csv · ERROR_ANALYSIS.md · E0_E4_PROTOCOL.md')
    return 0


def write_docs(c, ns, ans, er, partial):
    man = {}
    mp = os.path.join(RES, 'manifest.json')
    if os.path.exists(mp):
        man = json.load(io.open(mp, encoding='utf-8'))

    t = ['# E0~E4 · 무엇을 어떻게 비교했나', '',
         '## 같게 둔 것', '',
         '| | |', '|---|---|',
         '| 모델 | %s (ollama · 이 컴퓨터) |' % man.get('llm', {}).get('gen_model', 'exaone3.5:7.8b'),
         '| 임베딩 | %s |' % man.get('llm', {}).get('emb_model', 'bge-m3'),
         '| temperature | 0 |', '| seed | %s |' % man.get('llm', {}).get('seed', '20260915'),
         '| 출력 형식 | 숫자 하나 또는 라벨 하나 |',
         '| 시험 문항 | 다섯 갈래가 같은 문항을 본다 |',
         '| 지식창고 | E3 와 E4 가 **같은 문서 더미**를 쓴다 |', '',
         '다른 것은 **프롬프트에 무엇을 얹는가** 하나뿐이다.', '',
         '| 갈래 | 얹는 것 |', '|---|---|']
    for a in A.ARMS:
        t.append('| %s | %s |' % (a, A.ARM_KO[a]))
    t += ['', '## 왜 로컬 모델인가', '',
          '시험에 쓰는 한국어 화용 평가셋은 저장소에 라이선스가 없다. 권리 유보다.',
          '외부 API 로 보내면 그 줄을 넘는다. ollama 는 이 컴퓨터를 안 떠난다.',
          'TalkBank 규칙이 요구하는 "비보관 옵트아웃" 문제도 같이 없어진다. 아예 안 보낸다.', '',
          'CPU 로 돌아서 느리다. 그래서 문항을 %s개로 줄였다. 그 사실을 적어 둔다.'
          % ns.get('implicature', '?'), '',
          '## 우연 기준선', '',
          '배포된 CSV 는 **정답이 120문항 전부 (1)번** 이다.',
          '섞지 않고 재면 "늘 1" 이라고 답하는 모델이 100% 를 받는다.',
          '항목 id 로 정답 자리를 고르게 돌려 각 자리에 30문항씩 두었다.',
          '그래서 우연 기준선이 정확히 **25%** 다.', '',
          '논문(Park et al. 2024)도 채점할 때 보기 순서를 돌렸다고 적고 있다. 같은 처리를 했다.', '',
          '### 여기서 한 번 틀렸다', '',
          '처음에는 자리 돌리기를 **항목 번호**로 했다. 120 전체에서는 30/30/30/30 이 나왔고',
          '그것만 확인하고 넘어갔다. 그런데 실제로 채점하는 집합은 120 이 아니다.',
          '격률별로 나누고 다시 뽑는 과정에서 균형이 깨졌다.', '',
          '| 집합 | 자리 분포 | 다수 자리 기준선 |', '|---|---|---|',
          '| 전체 120 | 30/30/30/30 | 25.0% |',
          '| 시험 몫 80 | 20/16/25/19 | 31.2% |',
          '| **실제 채점한 40** | **14/8/9/9** | **35.0%** |', '',
          'E0 가 0.550 을 받았을 때 기준선은 0.25 가 아니라 0.35 였다.',
          '위에서 맞춰 놓고 아래에서 뽑으면 소용이 없다.', '',
          '고친 방법 · 자리를 항목의 속성으로 두지 않는다. `place_gold()` 가 **건네받은 집합에**',
          '자리를 돌려 배치하고, 나눈 뒤와 뽑은 뒤에 다시 부른다. 지금은 세 집합 모두 25.0% 다.',
          '`run.py` 가 채점 직전 집합에서 기준선을 재고 0.26 을 넘으면 시작하지 않는다.', '',
          '앞 판의 결과는 **버렸다.** 기준선이 다른 숫자를 섞지 않는다.', '',
          '격률 안에서는 10 을 4 로 못 나눠 최빈 자리가 30% 다. 이것은 못 없앤다.',
          '격률별 성적을 낼 때는 25% 가 아니라 30% 와 견줘야 한다.', '',
          '## 도중에 설정을 하나 바꿨다', '',
          '실험 도중 메모리가 모자라 운영체제가 판을 두 번 죽였다. 원인은 모델 크기가 아니라',
          '**KV 캐시**였다. 기본 문맥 길이가 4096 이라 llama-server 가 8.7GB 를 물고 있었다.',
          '실측 최장 프롬프트는 500 토큰이다. 8배 크게 열어 두고 있었다.', '',
          '`num_ctx` 를 1024 로 줄였다. llama-server 가 4.9GB 로 내려가고 여유가 4.7GB 에서',
          '8.5GB 로 늘었다.', '',
          '**설정을 바꿨으니 앞뒤 결과를 섞어도 되는지 확인해야 한다.** 이미 돌린 문항 아홉 개를',
          '(E0·E1·E2 각 셋) 새 설정으로 다시 불러 예측이 같은지 봤다. **9/9 같았다.**',
          '프롬프트가 새 문맥 창에 넉넉히 들어가므로 잘린 것이 없다. 그래서 섞는다.',
          '확인하지 않고 섞었으면 앞 결과와 뒤 결과가 다른 조건이 된다.', '',
          '## 이 설계가 가르지 못하는 것', '',
          '**프롬프트 길이가 갈래마다 다르다.** E0 은 171 토큰, E1 은 286 토큰이다.',
          'E1 이 E0 보다 나았다면 그것이 온톨로지 내용 때문인지 맥락이 더 길어서인지',
          '이 설계로는 가르지 못한다. 가르려면 같은 길이의 **무관한 글**을 넣은 갈래가',
          '하나 더 있어야 한다. 이번에는 넣지 않았다.', '',
          '그래서 E0 대 E1 의 차이를 "온톨로지의 기여" 라고 단정하지 않는다.',
          '"온톨로지 정의를 넣었을 때의 차이" 까지만 말한다.', '',
          '표본도 작다. 40문항에서 McNemar 로 p<0.05 를 넘으려면 한쪽만 맞힌 문항이',
          '대략 6대0 이상으로 갈라져야 한다. 그보다 작은 차이는 **못 가른다**고 적는다.', '',
          '## 누출 검사', '',
          '실험 전에 돌린다. 통과 못 하면 시작하지 않는다.', '',
          '- 훈련 40 · 시험 40 이 겹치지 않는가',
          '- 시험 문항 글이 지식창고에 들어갔는가',
          '- **실제로 만들어진 프롬프트**에 정답이 실려 나가는가 (다섯 갈래 전부 만들어 본다)',
          '- 꺼내는 열쇠에 정답 칸이 섞였는가', '',
          '일부러 새게 한 6가지를 심어 6가지가 다 잡히는 것을 확인한 뒤에 통과를 믿는다.', '']
    io.open(os.path.join(HERE, 'E0_E4_PROTOCOL.md'), 'w', encoding='utf-8',
            newline='\n').write(chr(10).join(t))

    e = ['# 결과와 오류 분석', '']
    if partial:
        e += ['> **아직 다 안 돌았다.** 도는 중인 칸 · %s' %
              ', '.join('%s/%s' % k for k in partial), '',
              '> 아래는 다 돌린 칸만 넣은 것이다.', '']
    e += ['## 갈래별', '',
          '| 과제 | 갈래 | | n | 정확도 | 95% 구간 | macro F1 | 형식실패 | 중앙 초 | 입력토큰 |',
          '|---|---|---|---|---|---|---|---|---|---|']
    for (task, arm), rs in sorted(c.items()):
        s = M.score(rs, A.TASKS[task]['labels'])
        lo, hi = M.wilson(s['correct_n'], s['n'])
        e.append('| %s | %s | %s | %d | **%.3f** | %.2f~%.2f | %.3f | %.2f | %.1f | %.0f |'
                 % (task, arm, A.ARM_KO[arm], s['n'], s['accuracy'], lo, hi,
                    s['macro_f1'], s['invalid_rate'], s['median_seconds'],
                    s['mean_prompt_tokens']))
    e += ['', '우연 기준선은 두 과제 모두 0.25 다.', '',
          '## 세 물음에 대한 답', '']
    for a in ans:
        cm = a['cmp']
        e += ['### %s · %s' % (a['question'], a['task']), '']
        if cm is None:
            e += ['**NOT_RUN**', '']
            continue
        e += ['%s %.3f → %s %.3f (차이 %+.3f)' % (a['a'], cm['acc_a'], a['b'],
                                                cm['acc_b'], cm['delta']),
              '',
              '- %s 만 맞힌 문항 %d개 · %s 만 맞힌 문항 %d개'
              % (a['a'], cm['only_a'], a['b'], cm['only_b']),
              '- McNemar p=%.3f · **Holm 조정 p=%.3f** (한 과제에서 비교 넷)'
              % (cm['p'], cm.get('p_holm', cm['p'])),
              '- **판정 · %s** · %s' % (a['verdict'], a['why']), '']
    if er:
        e += ['## 틀릴 때 어떻게 틀리나 (함축 과제)', '',
              '자료가 오답마다 구실을 적어 두었다. 그래서 오답의 종류를 나눌 수 있다.', '',
              '| 갈래 | 정답 | 문자 그대로 | 맥락 안 오답 | 맥락 밖 오답 | 형식실패 |',
              '|---|---|---|---|---|---|']
        for arm in A.ARMS:
            if arm not in er:
                continue
            x = er[arm]
            e.append('| %s | %d | **%d** | %d | %d | %d |' % (
                arm, x.get('answer', 0), x.get('literal', 0),
                x.get('wrong_in_context', 0), x.get('wrong_out_context', 0),
                x.get('INVALID', 0)))
        e += ['', '**문자 그대로 읽어서 틀린 것**이 우리가 다루려는 증상이다.',
              '이 칸이 줄어드는 것이 우리에게 의미 있는 개선이다. 전체 정확도보다 이 칸을 본다.', '']
    io.open(os.path.join(HERE, 'ERROR_ANALYSIS.md'), 'w', encoding='utf-8',
            newline='\n').write(chr(10).join(e))


if __name__ == '__main__':
    sys.exit(main())
