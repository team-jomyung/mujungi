# 세 질문과 답

## Q1 · Ontology 를 어디까지 적용할 것인가

- 47개를 다시 봤다. 실제로 쓸 수 있는 것은 **1개**.
- 온톨로지 7필드 중 **2개**가 직접 검증 가능, 2개는 proxy, 2개는 gold 자체가 없다.
- 문제 근거 집단(SCD child)과 benchmark 집단(nonclinical Korean population)이 **다르다**. 합치지 않는다.
- 자세히 · `01_DATA/TIER_A_DATASETS.md` · `02_TARGET/TARGET_DECISION.md` · `03_ONTOLOGY/VALIDATABLE_FIELDS.md`

## Q2 · 실제 대화를 다른 훈련 상황으로 바꿀 수 있는가

- 공개 대화 12건을 Social Event 로 구조화했다 (KMI · CC BY 4.0).
- 장면 18개에서 기계 검사가 전부 통과했고, 멀어질수록 어휘 겹침이 줄었다.
- **"정말 같은 능력을 요구하는가" 는 사람이 판정한다. 현재 PENDING.**
- 자세히 · `07_SOCIAL_EVENT/` · `08_SCENARIO/AUTO_CHECK_RESULTS.csv`

## Q3 · 무엇으로 객관적으로 평가하는가

- 사람이 쓴 한국어 gold 로 E0~E4 를 같은 조건에서 비교한다.
- 우연 기준선 25% · 누출 0 · 심은 누출 6/6 적발.
- **시스템 성능과 사용자 효과를 구분한다. 후자는 재지 않았다.**
- 자세히 · `06_ABLATION/ERROR_ANALYSIS.md` · `06_ABLATION/E0_E4_PROTOCOL.md`

