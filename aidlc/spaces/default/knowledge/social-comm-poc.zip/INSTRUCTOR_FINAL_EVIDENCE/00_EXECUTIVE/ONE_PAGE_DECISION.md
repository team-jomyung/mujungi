# 한 장 요약

| | |
|---|---|
| 조사한 자료 | 48개 |
| 지금 쓸 수 있는 자료 (TIER A) | **1개** · 한국어 화용 평가셋 |
| 직접 검증 가능한 온톨로지 필드 | 2 / 7 |
| BENCHMARK_CORE 기술 | S1 · S3 |
| PROBLEM GROUNDING | SCD 아동 · ASD 아동 |
| TECHNICAL BENCHMARK | nonclinical Korean population |
| PRODUCT TARGET | **PROVISIONAL** |
| 할 수 있는 주장 | 11 |
| 못 하는 주장 | 13 |
| 사람 대상 연구 | 없음 |
| 팀 수동 리뷰 | [TEAM MANUAL RESULT PENDING] |

## 한 문장

한국어 화용 gold 로 시스템의 함축 해석과 격률 판정을 잴 수 있고,
같은 사건에서 거리를 벌린 장면을 만들 수 있다.
**사용자가 나아지는지는 재지 않았고, SCD 집단을 검증하지도 않았다.**

## 가장 아픈 곳 세 가지

1. 쓸 수 있는 Human Gold 자료가 **하나뿐**이고 120문항이다.
2. 제품에서 가장 중요한 S2(관계·상황 조정)에 **잴 수 있는 gold 가 없다**.
3. 지금 기술 POC 대상인 SCD 청년이 아홉 집단 중 **근거가 가장 얇다**.

