# TEAM BLIND MANUAL SANITY RESULT

**[TEAM MANUAL RESULT PENDING]**

팀 블라인드 리뷰가 아직 안 끝났다. 결과가 들어오면 이 파일이 다시 쓰인다.

- 넣을 자리 · `09_MANUAL_REVIEW/manual_review_results/reviewer_*.csv`
- 돌릴 것 · `python import_manual_reviews.py` 다음 `python aggregate_manual_reviews.py`

이 결과는 **모델 정확도가 아니다.** 사람이 눈으로 본 위생 점검이다.
