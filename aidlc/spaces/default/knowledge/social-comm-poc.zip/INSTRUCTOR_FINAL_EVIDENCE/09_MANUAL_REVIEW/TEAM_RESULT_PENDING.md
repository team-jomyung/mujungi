# [TEAM MANUAL RESULT PENDING]

팀 블라인드 수동 리뷰가 진행 중이다. 결과가 아직 없다.

**없는 결과를 지어내지 않는다.** 이 자리는 비워 둔다.

## 결과가 오면

1. 리뷰어별 CSV 를 `manual_review_results/reviewer_1.csv` 식으로 넣는다
2. `python import_manual_reviews.py`
3. `python aggregate_manual_reviews.py`

`TEAM_BLIND_MANUAL_SANITY_RESULT.md` 가 다시 쓰인다.

## 집계하는 것

- 자연스러움 평균 · 맥락 충분 비율 · 같은 능력으로 본 비율
- 의도한 거리와 읽힌 거리의 일치율 · 답 노출 비율
- 기술별 · 거리별 · 리뷰어별
- 리뷰어가 둘 이상이면 Fleiss κ

## 이름을 고정한다

이 결과의 이름은 **TEAM BLIND MANUAL SANITY RESULT** 다.
**모델 정확도라고 부르지 않는다.** 18장면을 사람 몇이 눈으로 본 것이고
표본이 작아 신뢰구간도 붙이지 않는다.

## 읽을 때

- 덜 채운 칸을 0 으로 세지 않는다. 분모에서 빼고 몇 개인지 따로 적는다
- 거리 일치는 맞은 개수만 보지 않는다. **어느 쪽으로 틀렸는지**가 더 쓸모 있다
- 답 노출이 하나라도 나오면 그것부터 고친다
