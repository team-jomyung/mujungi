# -*- coding: utf-8 -*-
"""합친 리뷰를 집계한다. 이름은 **TEAM BLIND MANUAL SANITY RESULT** 로 고정한다.

    python aggregate_manual_reviews.py

이름을 고정하는 이유
  이것은 모델 정확도가 아니다. 사람 몇이 열여덟 장면을 눈으로 본 결과다.
  "정확도" 라고 부르는 순간 다른 것이 되어 버린다. 표본이 작아 신뢰구간도 안 붙인다.

세는 것
  자연스러움 평균 · 맥락 충분 비율 · 같은 능력이라고 본 비율
  의도한 거리와 읽힌 거리의 일치율 · 답 노출 비율
  기술별 · 거리별 · 사람별
  사람이 둘 이상이면 사람끼리 얼마나 같게 봤는가 (q3 · q4 에 대해 Fleiss κ)

덜 채운 칸
  0 으로 세지 않는다. 분모에서 빼고, 몇 개였는지 따로 적는다.
  이것을 0 으로 세면 없는 판단을 있는 판단으로 바꾸는 것이다.
"""
from __future__ import annotations

import collections
import csv
import io
import json
import os
import sys
import unicodedata

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.abspath(os.path.join(HERE, '..', '..'))
KEY = os.path.join(REPO, 'POC_B_MANUAL_SANITY', 'MANUAL_REVIEW_KEY.csv')
MERGED = os.path.join(HERE, '_merged_reviews.json')
OUT_MD = os.path.join(HERE, 'TEAM_BLIND_MANUAL_SANITY_RESULT.md')

TITLE = 'TEAM BLIND MANUAL SANITY RESULT'
GRADE_KO = {'SAME_CONTEXT': '같은 맥락', 'NEAR': '가까움', 'FAR': '멂', 'UNSURE': '모르겠다'}
SKILL_KO = {'S1': '청자 맞춤 정보 조절', 'S2': '관계 · 상황 맞춤 조정', 'S3': '함축 이해'}


def wide(t):
    return sum(2 if unicodedata.east_asian_width(c) in 'WF' else 1 for c in t)


def pad(t, n):
    return t + ' ' * max(0, n - wide(t))


def pct(a, b):
    return '%5.1f%% (%d/%d)' % (100.0 * a / b, a, b) if b else '    -  (0/0)'


def fleiss(subjects):
    """subjects · [[라벨, 라벨, ...], ...] 사람마다 하나씩. 다 채운 항목만 넣는다."""
    subjects = [s for s in subjects if len(s) >= 2]
    if len(subjects) < 2:
        return None
    n = len(subjects[0])
    if any(len(s) != n for s in subjects):
        return None                      # 사람마다 개수가 다르면 안 잰다
    cats = sorted({c for s in subjects for c in s})
    if len(cats) < 2:
        return 1.0
    P = []
    pj = collections.Counter()
    for s in subjects:
        cnt = collections.Counter(s)
        for c in cats:
            pj[c] += cnt[c]
        P.append((sum(v * v for v in cnt.values()) - n) / (n * (n - 1)))
    tot = len(subjects) * n
    pe = sum((pj[c] / tot) ** 2 for c in cats)
    pbar = sum(P) / len(P)
    return round((pbar - pe) / (1 - pe), 4) if pe < 1 else 1.0


def block(title, buckets):
    print()
    print(title)
    print('  %s %4s %s %s %s %s %s'
          % (pad('', 24), '항목', pad('자연스러움', 13), pad('맥락 충분', 15),
             pad('같은 능력', 15), pad('거리 일치', 15), '답 노출'))
    for k, rs in buckets.items():
        nat = [float(r['q1_naturalness']) for r in rs if r['q1_naturalness']]
        ctx = [r for r in rs if r['q2_context_sufficient']]
        same = [r for r in rs if r['q3_same_ability']]
        dist = [r for r in rs if r['q4_distance']]
        leak = [r for r in rs if r['q5_answer_leak']]
        print('  %s %4d %s %s %s %s %s' % (
            pad(k, 24), len(rs),
            pad('%.2f' % (sum(nat) / len(nat)) if nat else '  -', 13),
            pad(pct(sum(1 for r in ctx if r['q2_context_sufficient'] == 'YES'), len(ctx)), 15),
            pad(pct(sum(1 for r in same if r['q3_same_ability'] == 'SAME'), len(same)), 15),
            pad(pct(sum(1 for r in dist
                        if r['q4_distance'] == r['intended_distance']), len(dist)), 15),
            pct(sum(1 for r in leak if r['q5_answer_leak'] == 'YES'), len(leak))))


def main(argv=None):
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument('--merged', default=MERGED)
    ap.add_argument('--out', default=OUT_MD)
    a = ap.parse_args(argv)
    merged, out_md = a.merged, a.out
    if not os.path.exists(merged):
        print('합친 파일이 없다 · 먼저 python import_manual_reviews.py')
        return 2
    d = json.load(io.open(merged, encoding='utf-8'))
    print('=' * 76)
    print(TITLE)
    print('=' * 76)

    if d['status'] != 'MERGED' or not d['rows']:
        print('[TEAM MANUAL RESULT PENDING]')
        print('  팀 리뷰 결과가 아직 없다. 숫자를 지어내지 않는다.')
        print('  결과 CSV 를 09_MANUAL_REVIEW/manual_review_results/ 에 넣고 다시 돌린다.')
        io.open(out_md, 'w', encoding='utf-8', newline='\n').write(
            '# %s\n\n**[TEAM MANUAL RESULT PENDING]**\n\n'
            '팀 블라인드 리뷰가 아직 안 끝났다. 결과가 들어오면 이 파일이 다시 쓰인다.\n\n'
            '- 넣을 자리 · `09_MANUAL_REVIEW/manual_review_results/reviewer_*.csv`\n'
            '- 돌릴 것 · `python import_manual_reviews.py` 다음 '
            '`python aggregate_manual_reviews.py`\n\n'
            '이 결과는 **모델 정확도가 아니다.** 사람이 눈으로 본 위생 점검이다.\n' % TITLE)
        return 0

    key = {r['display_id']: r for r in
           csv.DictReader(io.open(KEY, encoding='utf-8-sig', newline=''))}
    rows = [dict(r, **key[r['display_id']]) for r in d['rows'] if r['display_id'] in key]
    blanks = sum(1 for r in rows if not r['complete'])

    print('리뷰어 %d명 · 판단 %d건 · 항목 %d개' % (
        d['reviewers'], len(rows), len({r['display_id'] for r in rows})))
    if blanks:
        print('  덜 채운 판단 %d건 · **0 으로 세지 않고 분모에서 뺀다**' % blanks)

    def grp(keyfn, order=None):
        o = collections.OrderedDict()
        for r in sorted(rows, key=lambda x: str(keyfn(x))):
            o.setdefault(keyfn(r), []).append(r)
        if order:
            return collections.OrderedDict((k, o[k]) for k in order if k in o)
        return o

    block('전체', collections.OrderedDict([('모두', rows)]))
    block('기술별', grp(lambda r: '%s %s' % (r['scope_skill'],
                                          SKILL_KO.get(r['scope_skill'], ''))))
    block('거리별', grp(lambda r: GRADE_KO.get(r['intended_distance'], r['intended_distance']),
                     order=['같은 맥락', '가까움', '멂']))
    block('리뷰어별', grp(lambda r: r['reviewer']))

    if d['reviewers'] >= 2:
        print()
        print('리뷰어끼리 얼마나 같게 봤는가 · Fleiss κ')
        by_item = collections.defaultdict(dict)
        for r in rows:
            by_item[r['display_id']][r['reviewer']] = r
        names = sorted(d['reviewer_names'])
        for q in ('q3_same_ability', 'q4_distance'):
            full = [i for i, m in by_item.items()
                    if len(m) == len(names) and all(m[n][q] for n in names)]
            subs = [[by_item[i][n][q] for i in sorted(full)] for n in names]
            k = fleiss(subs)
            print('  %-22s %s (다 채운 항목 %d)'
                  % (q, ('%.3f' % k) if k is not None else '못 잰다', len(full)))
        print('  표본이 작다. 이 값을 성능이라고 부르지 않는다.')

    leak = [r for r in rows if r['q5_answer_leak'] == 'YES']
    print()
    print('=' * 76)
    if leak:
        print('판정 · 답 노출 %d건. 생성 규칙부터 고친다' % len(leak))
        for r in leak[:8]:
            print('    %s · %s · %s' % (r['display_id'], r['scope_skill'], r['reviewer']))
    else:
        print('판정 · 답 노출 없음')
    print('이 줄들은 %s 다. 모델 정확도가 아니다.' % TITLE)
    print('=' * 76)

    io.open(out_md, 'w', encoding='utf-8', newline='\n').write(
        '# %s\n\n리뷰어 %d명 · 판단 %d건 · 항목 %d개 · 덜 채운 판단 %d건\n\n'
        '이 결과는 **모델 정확도가 아니다.** 사람이 눈으로 본 위생 점검이고, '
        '표본이 작아 신뢰구간을 붙이지 않는다.\n\n'
        '자세한 표는 `python aggregate_manual_reviews.py` 를 돌려서 본다.\n'
        % (TITLE, d['reviewers'], len(rows), len({r['display_id'] for r in rows}), blanks))
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
