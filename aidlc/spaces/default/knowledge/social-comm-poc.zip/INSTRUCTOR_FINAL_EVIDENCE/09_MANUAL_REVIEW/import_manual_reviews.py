# -*- coding: utf-8 -*-
"""팀이 채운 리뷰 CSV 를 읽어 들인다. **POC_B_MANUAL_SANITY 는 건드리지 않는다.**

    python import_manual_reviews.py

어디서 읽나
  manual_review_results/reviewer_1.csv
  manual_review_results/reviewer_2.csv
  ...

  이름은 reviewer_*.csv 면 아무거나 된다. 사람 수만큼 넣으면 된다.
  열쇠는 POC_B_MANUAL_SANITY/MANUAL_REVIEW_KEY.csv 를 **읽기만** 한다.

무엇을 확인하나
  1 칸 이름이 MANUAL_REVIEW.html 이 내보내는 것과 같은가
  2 display_id 가 열쇠에 있는가
  3 값이 정해진 어휘 안에 있는가   <- 개수를 세기 전에 어휘부터 잠근다
  4 덜 채운 항목이 몇 개인가

왜 어휘를 잠그나
  앞서 한 번 당했다. 값이 ALLOWED 인데 '가능' 을 찾는 필터를 써서 검사가 **통과**했다.
  개수를 세면 그 한 자리만 보지만, 어휘를 잠그면 그 부류가 통째로 막힌다.
"""
from __future__ import annotations

import csv
import glob
import io
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.abspath(os.path.join(HERE, '..', '..'))
KEY = os.path.join(REPO, 'POC_B_MANUAL_SANITY', 'MANUAL_REVIEW_KEY.csv')
INBOX = os.path.join(HERE, 'manual_review_results')
OUT = os.path.join(HERE, '_merged_reviews.json')

COLS = ('display_id', 'q1_naturalness', 'q2_context_sufficient',
        'q3_same_ability', 'q4_distance', 'q5_answer_leak', 'memo')

VOCAB = {
    'q1_naturalness': ('1', '2', '3', '4', '5'),
    'q2_context_sufficient': ('YES', 'NO'),
    'q3_same_ability': ('SAME', 'DIFFERENT', 'UNSURE'),
    'q4_distance': ('SAME_CONTEXT', 'NEAR', 'FAR', 'UNSURE'),
    'q5_answer_leak': ('YES', 'NO'),
}


def load_key():
    if not os.path.exists(KEY):
        return None, '열쇠가 없다 · %s' % KEY
    rows = list(csv.DictReader(io.open(KEY, encoding='utf-8-sig', newline='')))
    return {r['display_id']: r for r in rows}, ''


def read_one(path, key):
    rows = list(csv.DictReader(io.open(path, encoding='utf-8-sig', newline='')))
    name = os.path.splitext(os.path.basename(path))[0]
    problems = []
    if not rows:
        return name, [], ['비어 있다']
    got = tuple(rows[0].keys())
    if got != COLS:
        problems.append('칸 이름이 다르다 · 기대 %s · 실제 %s'
                        % (', '.join(COLS), ', '.join(got)))
        return name, [], problems
    out = []
    for r in rows:
        did = (r['display_id'] or '').strip()
        if did not in key:
            problems.append('열쇠에 없는 항목 · %s' % did)
            continue
        rec = {'reviewer': name, 'display_id': did}
        for q, vocab in VOCAB.items():
            v = (r[q] or '').strip()
            if v and v not in vocab:
                problems.append('%s · %s 값이 어휘 밖이다 · %r' % (did, q, v))
                v = ''
            rec[q] = v
        rec['memo'] = (r['memo'] or '').strip()
        rec['complete'] = all(rec[q] for q in VOCAB)
        out.append(rec)
    seen = [x['display_id'] for x in out]
    if len(seen) != len(set(seen)):
        problems.append('같은 항목이 두 번 있다')
    return name, out, problems


def main(argv=None):
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument('--inbox', default=INBOX)
    ap.add_argument('--out', default=OUT)
    a = ap.parse_args(argv)
    inbox, out = a.inbox, a.out
    key, err = load_key()
    if err:
        print(err)
        return 2
    if not os.path.isdir(inbox):
        os.makedirs(inbox)
    files = sorted(glob.glob(os.path.join(inbox, 'reviewer_*.csv')))
    print('열쇠 %d항목 · 리뷰 파일 %d개' % (len(key), len(files)))
    if not files:
        print()
        print('[TEAM MANUAL RESULT PENDING]')
        print('  아직 아무도 안 냈다. 넣을 자리 · %s' % inbox)
        print('  파일 이름 · reviewer_1.csv · reviewer_2.csv ...')
        print('  **없는 결과를 지어내지 않는다.**')
        io.open(out, 'w', encoding='utf-8', newline='\n').write(
            json.dumps({'status': 'PENDING', 'reviewers': 0, 'rows': []},
                       ensure_ascii=False, indent=2) + chr(10))
        return 0

    allrows, bad = [], 0
    for f in files:
        name, rows, problems = read_one(f, key)
        done = sum(1 for r in rows if r['complete'])
        print('  %-14s %3d행 · 다 채운 것 %d · 문제 %d' % (name, len(rows), done, len(problems)))
        for p in problems[:6]:
            print('      %s' % p)
        bad += len(problems)
        allrows += rows

    io.open(out, 'w', encoding='utf-8', newline='\n').write(json.dumps(
        {'status': 'MERGED', 'reviewers': len(files),
         'reviewer_names': [os.path.splitext(os.path.basename(f))[0] for f in files],
         'rows': allrows}, ensure_ascii=False, indent=2) + chr(10))
    print()
    print('합친 줄 %d · 저장 %s' % (len(allrows), os.path.basename(out)))
    print('다음 · python aggregate_manual_reviews.py')
    return 1 if bad else 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
