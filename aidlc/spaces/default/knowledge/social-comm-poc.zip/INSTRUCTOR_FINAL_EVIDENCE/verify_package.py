# -*- coding: utf-8 -*-
"""꾸러미가 자기 자신과 맞는가. 발표 전에 돌린다.

    python verify_package.py

보는 것
  1 있어야 할 파일이 다 있는가
  2 보고서의 숫자가 CSV 와 같은가          <- 숫자 어긋남은 이 프로젝트의 단골 고장이다
  3 어휘가 정해진 집합 안에 있는가          <- 개수를 세기 전에 어휘부터 잠근다
  4 권리 유보 자료의 사본이 꾸러미에 없는가
  5 보고서에 원문 예시가 실리지 않았는가
  6 못 하는 주장을 하고 있지 않은가
  7 팀 리뷰 결과를 지어내지 않았는가
  8 실험을 안 돌렸으면 NOT_EXECUTED 가 있는가

심어 놓고 터지는지도 본다.
"""
from __future__ import annotations

import collections
import csv
import io
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.abspath(os.path.join(HERE, '..'))
REPORT = os.path.join(HERE, 'FINAL_INSTRUCTOR_REPORT.html')

MUST = [
    '00_EXECUTIVE/INSTRUCTOR_3_QUESTIONS.md', '00_EXECUTIVE/ONE_PAGE_DECISION.md',
    '01_DATA/DATASET_EXECUTABILITY_AUDIT.csv', '01_DATA/TIER_A_DATASETS.md',
    '01_DATA/DATA_ACCESS_EVIDENCE.md', '01_DATA/LICENSE_AUDIT.md',
    '01_DATA/GOLD_PROVENANCE.md',
    '02_TARGET/TARGET_EVIDENCE_MATRIX.csv', '02_TARGET/TARGET_DECISION.md',
    '03_ONTOLOGY/DATASET_ONTOLOGY_MAPPING.csv', '03_ONTOLOGY/VALIDATABLE_FIELDS.md',
    '04_SKILLS/SKILL_EVIDENCE_MATRIX.csv', '04_SKILLS/FINAL_SKILL_SCOPE.md',
    '05_BENCHMARK/harness/run.py', '05_BENCHMARK/harness/leakage.py',
    '05_BENCHMARK/freeze_placement.py', '05_BENCHMARK/results/PLACEMENT.json',
    '06_ABLATION/E0_E4_PROTOCOL.md', '06_ABLATION/ERROR_ANALYSIS.md',
    '07_SOCIAL_EVENT/SOCIAL_EVENT_POC.md',
    '08_SCENARIO/PUBLIC_DATA_SCENARIO_POC.md', '08_SCENARIO/AUTO_CHECK_RESULTS.csv',
    '09_MANUAL_REVIEW/import_manual_reviews.py',
    '09_MANUAL_REVIEW/aggregate_manual_reviews.py',
    '09_MANUAL_REVIEW/TEAM_RESULT_PENDING.md',
    '11_CLAIMS/CLAIM_LEDGER.csv', 'FINAL_INSTRUCTOR_REPORT.html',
]

VOCAB = {
    'tier': ('A', 'B', 'C', 'D'),
    'validation_strength': ('DIRECTLY_VALIDATABLE', 'PROXY_VALIDATABLE',
                            'DEMONSTRATION_ONLY', 'NOT_VALIDATABLE', 'NONE'),
    'downloadable_now': ('YES_DIRECT', 'YES_AFTER_FREE_REGISTRATION',
                         'APPLICATION_REQUIRED', 'NO', 'ACCESS_NOT_VERIFIED'),
    'gold_provenance': ('HUMAN_ANNOTATED', 'HUMAN_VERIFIED_MACHINE_OUTPUT',
                        'MACHINE_GENERATED', 'UNKNOWN', ''),
}
# ── 두 종류의 목록을 구분해서 쓴다 ──────────────────────────
#
# 1) SPEC 에서 온 것 · 지시서가 정한 형식이다. **한 번도 안 쓴 토막도 잡는다.**
# 2) 지금 제목에서 온 것 · 이미 있는 것이 사라지는 것만 잡는다. 회귀 전용이다.
#
# 2만 쓰면 순환이다. 아무도 안 쓴 토막은 출력에도 없고 목록에도 없어서
# 영원히 안 걸린다. 실제로 그랬다 · 제목에서 뽑은 목록은 세 개를 잡았지만,
# 지시서에서 뽑은 목록은 그 위에 **한계와 지금 판단이 세 질문 어디에도 없다**는
# 것을 더 잡았다. 앞의 목록으로는 잡을 수 없는 종류였다.
#
# 동결 파일이 스스로를 기준 삼으면 안 되는 것과 같은 이야기다. 한 층 위일 뿐이다.

# 1) 지시서 PART P · 질문마다 이 다섯이 있어야 한다
QSPEC = ('근거', 'POC', '결과', '한계', '지금 판단')
QSECTIONS = ('q1', 'q2', 'q3')
# 지시서 PART L · 세 질문이 최상위 구조다
QTITLES = {
    'q1': 'Ontology 를 어디까지 적용할 것인가',
    'q2': '실제 대화를',
    'q3': '객관적 기준으로 평가하는가',
}

# 2) 회귀 전용 · 지금 있는 토막이 사라지면 잡는다
REQUIRED_SECTIONS = [
    ('<h2>', 'Ontology 를 어디까지 적용할 것인가'),
    ('<h2>', '실제 대화를 같은 능력을 요구하는 다른 상황으로'),
    ('<h2>', '그 시스템이 제대로 작동하는지 어떤 객관적 기준으로'),
    ('<h2>', '무엇을 주장할 수 있고 무엇은 못 하는가'),
    ('<h3>', '근거 · 47개를 다시 봤고'),
    ('<h3>', 'Human Gold 가 있다는 말과 사람이 붙였다는 말은 다르다'),
    ('<h3>', '온톨로지 7개 필드 중 무엇을 잴 수 있나'),
    ('<h3>', '타겟 · 세 가지를 같게 두지 않는다'),
    ('<h3>', '정답 자리를 고르게 만든 것과 그 대가'),
    ('<h3>', '누출 검사'),
    ('<h3>', '여기서 재지'),
]
# 실험이 끝났을 때만 있어야 하는 것
REQUIRED_WHEN_DONE = [('<h3>', 'E3 와 E4 가 정말 다른 것을 꺼내는가')]

CLAIM_LEVELS = ('VALIDATED', 'SUPPORTED', 'DEMONSTRATED', 'DESIGNED',
                'NOT TESTED', 'FUTURE WORK')
SKILL_TIERS = ('BENCHMARK_CORE', 'DEMO_CORE', 'CONDITIONAL', 'FUTURE_ONLY', 'EXCLUDE')

# 해서는 안 되는 주장. 보고서 본문에 나오면 실패
FORBIDDEN = [
    (r'SCD\s*(집단|환자|아동|청소년)?\s*(를|을)?\s*(대상으로)?\s*검증(했|하였)',
     'SCD 검증했다고 적었다'),
    (r'치료\s*효과', '치료 효과를 말했다'),
    (r'(사용자|이용자).{0,8}(향상|개선)(되|됨|했)', '사용자 향상을 주장했다'),
    (r'임상(적)?\s*(효과|검증)(이|을|를)?\s*(있|입증|확인)', '임상 효과를 주장했다'),
]


def rd(p):
    f = os.path.join(HERE, p)
    if not os.path.exists(f):
        return []
    return list(csv.DictReader(io.open(f, encoding='utf-8-sig', newline='')))


def check():
    bad = []

    # 1 파일
    for m in MUST:
        if not os.path.exists(os.path.join(HERE, m)):
            bad.append('없다 · %s' % m)

    au = rd('01_DATA/DATASET_EXECUTABILITY_AUDIT.csv')
    cl = rd('11_CLAIMS/CLAIM_LEDGER.csv')
    sk = rd('04_SKILLS/SKILL_EVIDENCE_MATRIX.csv')
    if not au:
        bad.append('감사 CSV 가 비었다')
        return bad
    if not cl:
        bad.append('주장 대장이 비었다')

    # 3 어휘 잠금
    for col, vocab in VOCAB.items():
        if col not in au[0]:
            bad.append('감사 CSV 에 %s 칸이 없다' % col)
            continue
        off = {r[col].strip() for r in au} - set(vocab)
        if off:
            bad.append('%s 값이 어휘 밖이다 · %s' % (col, sorted(off)[:4]))
    off = {c['level'].strip() for c in cl} - set(CLAIM_LEVELS)
    if off:
        bad.append('주장 등급이 어휘 밖이다 · %s' % sorted(off))
    if sk:
        off = {s['evidence_tier'].strip() for s in sk} - set(SKILL_TIERS)
        if off:
            bad.append('기술 등급이 어휘 밖이다 · %s' % sorted(off))

    if not os.path.exists(REPORT):
        bad.append('보고서가 없다')
        return bad
    h = io.open(REPORT, encoding='utf-8').read()
    body = re.sub(r'<style[^>]*>.*?</style>', '', h, flags=re.S)
    text = re.sub(r'<[^>]+>', ' ', body)

    # 2 숫자가 자료와 같은가
    tc = collections.Counter(r['tier'] for r in au)
    cen = [r for r in au if r['scope'] != 'OWN']
    pairs = [('조사한 자료', len(cen)), ('TIER A', tc['A'])]
    for label, n in pairs:
        if not re.search(r'%s\s*</?[a-z]*>?\s*%d' % (re.escape(label), n), body) \
                and str(n) not in text:
            bad.append('보고서에 %s=%d 가 안 보인다' % (label, n))
    m = re.search(r'실제로 쓸 수 있는 자료\s*<b>(\d+)</b>', body)
    if m and int(m.group(1)) != tc['A']:
        bad.append('보고서 TIER A(%s) 와 CSV(%d) 가 다르다' % (m.group(1), tc['A']))
    m = re.search(r'조사한 자료\s*<b>(\d+)</b>', body)
    if m and int(m.group(1)) != len(cen):
        bad.append('보고서 자료 수(%s) 와 census(%d) 가 다르다' % (m.group(1), len(cen)))

    # 4 권리 유보 사본
    for dp, _dn, fn in os.walk(HERE):
        for f in fn:
            if f in ('korean_pragmatics_testset.csv', 'kocosa.json'):
                bad.append('권리 유보 자료의 사본이 꾸러미에 있다 · %s'
                           % os.path.relpath(os.path.join(dp, f), HERE))

    # 5 원문 예시
    kpt = os.path.join(REPO, 'experiments', 'korean_pragmatics_testset.csv')
    if os.path.exists(kpt):
        rows = list(csv.DictReader(io.open(kpt, encoding='utf-8', newline='')))
        for r in rows[:40]:
            st = (r['Statement'] or '').strip().strip('"“”')
            if len(st) > 6 and st in text:
                bad.append('보고서에 평가셋 원문이 실렸다 · %s' % st[:24])
                break

    # 6 금지 주장
    for rx, why in FORBIDDEN:
        m = re.search(rx, text)
        if m:
            bad.append('%s · "%s"' % (why, m.group(0)[:30]))

    # 5a 지시서가 정한 형식을 지켰는가 · **이것이 더 센 검사다**
    secs = dict(re.findall(r'<section class="q" id="(\w+)">(.*?)</section>', body, re.S))
    for sid in QSECTIONS:
        if sid not in secs:
            bad.append('질문 토막이 통째로 없다 · %s' % sid)
            continue
        if QTITLES[sid] not in secs[sid]:
            bad.append('%s 의 질문 제목이 지시서와 다르다' % sid)
        dl = re.search(r'<dl class="qs">(.*?)</dl>', secs[sid], re.S)
        got = re.findall(r'<dt>([^<]+)</dt>', dl.group(1)) if dl else []
        miss = [k for k in QSPEC if k not in got]
        if miss:
            bad.append('%s 에 지시서가 요구한 칸이 없다 · %s' % (sid, ' · '.join(miss)))
        for k, v in re.findall(r'<dt>([^<]+)</dt><dd>(.*?)</dd>', secs[sid], re.S):
            if len(re.sub(r'<[^>]+>', '', v).strip()) < 12:
                bad.append('%s 의 "%s" 칸이 비었거나 너무 짧다' % (sid, k))

    # 5b 있어야 할 토막이 다 있는가 (회귀 전용)
    for tag, needle in REQUIRED_SECTIONS:
        if needle not in body:
            bad.append('보고서에 빠진 토막 · %s%s' % (tag, needle))
    abl0 = rd('06_ABLATION/results.csv')
    if abl0:
        for tag, needle in REQUIRED_WHEN_DONE:
            if needle not in body:
                bad.append('실험을 돌렸는데 빠진 토막 · %s%s' % (tag, needle))

    # 6b 레드팀 숫자가 원본 표와 같은가
    rt = os.path.join(HERE, '10_RED_TEAM', 'INSTRUCTOR_RED_TEAM.md')
    m = re.search(r'SUPPORTED (\d+) · PARTIAL (\d+) · CANNOT CLAIM (\d+)', text)
    if os.path.exists(rt) and m:
        src = io.open(rt, encoding='utf-8').read()
        want = {}
        for k in ('SUPPORTED ANSWER', 'PARTIAL ANSWER', 'CANNOT CLAIM'):
            t = re.search(r'\|\s*%s\s*\|\s*(\d+)\s*\|' % re.escape(k), src)
            if t:
                want[k] = int(t.group(1))
        got = dict(zip(('SUPPORTED ANSWER', 'PARTIAL ANSWER', 'CANNOT CLAIM'),
                       (int(m.group(1)), int(m.group(2)), int(m.group(3)))))
        if want and want != got:
            bad.append('레드팀 숫자가 원본과 다르다 · 원본 %s · 보고서 %s' % (want, got))

    # 7 팀 리뷰
    mr = os.path.join(HERE, '09_MANUAL_REVIEW', '_merged_reviews.json')
    if os.path.exists(mr):
        d = json.load(io.open(mr, encoding='utf-8'))
        if d.get('status') == 'MERGED' and d.get('rows'):
            if 'PENDING' in text:
                bad.append('팀 결과가 들어왔는데 보고서가 아직 PENDING 이라고 적는다')
        elif 'PENDING' not in text:
            bad.append('팀 결과가 없는데 보고서가 PENDING 을 안 적는다')

    # 8 실험
    jl = os.path.join(HERE, '05_BENCHMARK', 'results', 'raw_predictions.jsonl')
    ne = os.path.join(HERE, '06_ABLATION', 'NOT_EXECUTED.md')
    if not os.path.exists(jl) and not os.path.exists(ne):
        bad.append('실험 결과도 NOT_EXECUTED.md 도 없다')
    abl = rd('06_ABLATION/results.csv')
    if abl:
        for r in abl:
            if not (0 <= float(r['accuracy']) <= 1):
                bad.append('정확도가 범위 밖이다 · %s' % r)
            if int(r['n']) < 1:
                bad.append('n 이 0 인 칸이 결과표에 있다')
    return bad


def selftest():
    """심어 놓고 터지는가. 보고서 사본을 임시로 건드려 본다."""
    import shutil
    import tempfile
    h = io.open(REPORT, encoding='utf-8').read()
    tmp = tempfile.mkdtemp()
    bak = os.path.join(tmp, 'r.html')
    shutil.copy2(REPORT, bak)
    cases = [
        ('금지 주장 · 치료 효과', h.replace('</footer>', '<p>치료 효과가 있다</p></footer>')),
        ('금지 주장 · SCD 검증', h.replace('</footer>', '<p>SCD 집단을 대상으로 검증했다</p></footer>')),
        ('숫자 어긋남', re.sub(r'(실제로 쓸 수 있는 자료 <b>)\d+(</b>)', r'\g<1>99\g<2>', h)),
        ('섹션 통째로 빠짐',
         h.replace('<h3>정답 자리를 고르게 만든 것과 그 대가</h3>', '')),
        ('Q3 제목 빠짐',
         h.replace('그 시스템이 제대로 작동하는지 어떤 객관적 기준으로 평가하는가', '')),
        ('지시서 칸 하나 빠짐', h.replace('<dt>한계</dt>', '<dt>없앰</dt>', 1)),
        ('지시서 칸이 비어 있음',
         re.sub(r'(<dt>지금 판단</dt><dd>).*?(</dd>)', r'\g<1>-\g<2>', h,
                count=1, flags=re.S)),
    ]
    fired = 0
    try:
        for label, mutated in cases:
            io.open(REPORT, 'w', encoding='utf-8', newline='\n').write(mutated)
            if check():
                fired += 1
            else:
                print('    >>> "%s" 를 해도 안 터진다' % label)
    finally:
        shutil.copy2(bak, REPORT)
        shutil.rmtree(tmp, ignore_errors=True)
    return fired, len(cases)


def main():
    bad = check()
    print('꾸러미 점검')
    print('  어긋난 곳 %d' % len(bad))
    for b in bad:
        print('      %s' % b)
    fired, total = selftest()
    print('  심은 결함 %d개 중 %d개가 터졌다' % (total, fired))
    if fired != total:
        return 1
    print()
    print('판정 · %s' % ('통과' if not bad else '**고칠 것이 있다**'))
    return 1 if bad else 0


if __name__ == '__main__':
    sys.exit(main())
