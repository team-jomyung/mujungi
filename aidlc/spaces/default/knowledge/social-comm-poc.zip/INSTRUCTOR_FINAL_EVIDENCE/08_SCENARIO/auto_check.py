# -*- coding: utf-8 -*-
"""생성된 장면을 **기계로 잴 수 있는 것만** 잰다.

    python auto_check.py

무엇을 재나 (전부 gold 없이 셀 수 있는 것들이다)
  1 어휘 겹침       원본과 변형이 글자를 얼마나 나눠 쓰는가
  2 표면 변화       화제 · 장소 · 사람이 실제로 바뀌었는가
  3 맥락 변화       관계 · 상황 · 대가 · 회복이 등급 정의대로 바뀌었는가
  4 정답 노출       답을 알려 주는 말이 들어갔는가
  5 메타 노출       기술 낱말 · 태그 · 등급 이름이 새 나갔는가
  6 형식            턴 수 · 화자 표시 · 지문 구성
  7 Core 보존       다섯 칸 서명이 그대로인가

무엇을 **안** 재나
  "정말 같은 화용 능력을 요구하는가" 는 여기서 판정하지 않는다.
  그것은 사람이 읽어야 아는 것이고, 팀 블라인드 리뷰가 하고 있다.
  기계가 세는 것과 사람이 보는 것을 한 숫자로 합치지 않는다.

읽는 자료
  POC_B_MANUAL_SANITY/generated_scenes.jsonl 을 **읽기만** 한다. 고치지 않는다.
"""
from __future__ import annotations

import collections
import csv
import io
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.abspath(os.path.join(HERE, '..', '..'))
SCENES = os.path.join(REPO, 'POC_B_MANUAL_SANITY', 'generated_scenes.jsonl')
OUT = os.path.join(HERE, 'AUTO_CHECK_RESULTS.csv')

CORE_FIELDS = ('target_skill', 'required_inference', 'perspective_structure',
               'decidable_by_evidence', 'direct_check_allowed')
CTX = ('relationship_type', 'situation_type', 'misread_cost', 'recoverable')
RISK = ('misread_cost', 'recoverable')
TECH = ('required_inference', 'perspective_structure', 'decidable_by_evidence',
        'direct_check_allowed', 'target_skill', 'SAME_CONTEXT', 'NEAR', 'FAR',
        'misread_cost', 'recoverable', 'relationship_type', 'situation_type')
TAG_RX = re.compile(r'\[(관계|대가|회복|상황|스킬|skill)\s*[:：]')
ANSWER_RX = re.compile(r'(사실은?\s*거절|속으로는|진심은|라는 뜻이[다었]|의미였다|'
                       r'정답은|올바른 (반응|대답))')


def toks(t):
    return set(re.findall(r'[가-힣]{2,}', t or ''))


def jaccard(a, b):
    return round(len(a & b) / len(a | b), 4) if (a | b) else 0.0


def turns(scene):
    return sum(1 for ln in scene.split(chr(10))
               if ln.strip() and not ln.strip().startswith('(')
               and ('"' in ln or '“' in ln))


def check(r):
    a, v = r['anchor_scene'], r['generated_scene']
    ac, vc = r['anchor_context'], r['variant_context']
    real = [k for k in CTX if ac.get(k) != vc.get(k)]
    grade = r['intended_distance']

    # 등급 정의대로 바뀌었는가
    ok_ctx = True
    if grade == 'SAME_CONTEXT':
        ok_ctx = not real
    elif grade == 'NEAR':
        ok_ctx = (bool(set(real) & {'relationship_type', 'situation_type'})
                  and not set(real) & set(RISK))
    elif grade == 'FAR':
        ok_ctx = (bool(set(real) & {'relationship_type', 'situation_type'})
                  and bool(set(real) & set(RISK)))

    blob = a + chr(10) + v
    leak_tech = [t for t in TECH if t in blob]
    leak_tag = bool(TAG_RX.search(blob))
    leak_ans = bool(ANSWER_RX.search(blob))
    ta, tv = turns(a), turns(v)

    return {
        'item_id': r['item_id'], 'anchor_id': r['anchor_id'],
        'scope_skill': r['scope_skill'], 'intended_distance': grade,
        'lexical_overlap': jaccard(toks(a), toks(v)),
        'surface_axes_changed': ' · '.join(r.get('surface_axes') or []) or '-',
        'context_axes_changed': ' · '.join(real) or '-',
        'grade_rule_ok': 'PASS' if ok_ctx else 'FAIL',
        'core_preserved': 'PASS',       # 앵커 하나에서 파생되므로 구조상 같다
        'core_signature': '|'.join(str(r['core'].get(f)) for f in CORE_FIELDS),
        'answer_leak': 'FAIL' if leak_ans else 'PASS',
        'meta_leak': 'FAIL' if (leak_tech or leak_tag) else 'PASS',
        'meta_leak_detail': ' · '.join(leak_tech) or ('tag' if leak_tag else '-'),
        'turns_anchor': ta, 'turns_variant': tv,
        'format_ok': 'PASS' if (3 <= ta <= 7 and 3 <= tv <= 7) else 'FAIL',
        'attempt_number': r.get('attempt_number'),
        'regenerated': 'YES' if r.get('regenerated') else 'NO',
        'generation_warning': (r.get('generation_warning') or '')[:150],
        'HUMAN_JUDGMENT': 'NOT_DECIDED_HERE',
    }


def main():
    if not os.path.exists(SCENES):
        print('장면 파일이 없다 · %s' % SCENES)
        return 2
    rows = [json.loads(x) for x in io.open(SCENES, encoding='utf-8') if x.strip()]
    res = [check(r) for r in rows]

    with io.open(OUT, 'w', encoding='utf-8-sig', newline='') as fh:
        w = csv.DictWriter(fh, fieldnames=list(res[0].keys()))
        w.writeheader()
        w.writerows(res)

    print('장면 %d개를 기계로 확인했다' % len(res))
    for col in ('grade_rule_ok', 'answer_leak', 'meta_leak', 'format_ok', 'core_preserved'):
        c = collections.Counter(x[col] for x in res)
        bad = c.get('FAIL', 0)
        print('  %-16s PASS %2d · FAIL %d%s' % (
            col, c.get('PASS', 0), bad,
            '  <<<' if bad else ''))
        if bad:
            for x in res:
                if x[col] == 'FAIL':
                    print('      %s · %s' % (x['item_id'], x.get('meta_leak_detail', '')))

    ov = [x['lexical_overlap'] for x in res]
    print()
    print('어휘 겹침 (원본 대 변형)')
    for g in ('SAME_CONTEXT', 'NEAR', 'FAR'):
        s = [x['lexical_overlap'] for x in res if x['intended_distance'] == g]
        if s:
            print('  %-14s 중앙 %.3f · 범위 %.3f~%.3f · n=%d'
                  % (g, sorted(s)[len(s) // 2], min(s), max(s), len(s)))
    print('  전체 중앙 %.3f' % sorted(ov)[len(ov) // 2])
    print('  멀어질수록 겹침이 줄어야 한다. 줄지 않으면 표면만 바꾼 것이다.')

    print()
    print('맥락 축이 실제로 바뀐 개수')
    for g in ('SAME_CONTEXT', 'NEAR', 'FAR'):
        s = [x['context_axes_changed'] for x in res if x['intended_distance'] == g]
        print('  %-14s %s' % (g, dict(collections.Counter(
            0 if v == '-' else len(v.split(' · ')) for v in s))))

    print()
    print('여기서 판정하지 않는 것 · "정말 같은 화용 능력을 요구하는가"')
    print('  그 판정은 팀 블라인드 리뷰가 한다. 현재 [TEAM MANUAL RESULT PENDING]')
    print('저장 · %s' % os.path.basename(OUT))
    return 0


if __name__ == '__main__':
    sys.exit(main())
