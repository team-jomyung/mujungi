# -*- coding: utf-8 -*-
"""자료에서 문서를 만든다. 숫자를 손으로 적지 않는다.

    python build_docs.py

왜 생성하나
  이 프로젝트가 같은 고장을 네 번 겪었다. ERR-04 · 05 · 06 전부
  "값을 여러 곳에 손으로 적었다" 였다. 고치는 방법은 늘 같았다 ·
  **정본 하나 + 생성된 문서 + 기계 검사.**

만드는 것
  01_DATA/TIER_A_DATASETS.md
  01_DATA/DATA_ACCESS_EVIDENCE.md
  01_DATA/LICENSE_AUDIT.md
  02_TARGET/TARGET_DECISION.md
  03_ONTOLOGY/DATASET_ONTOLOGY_MAPPING.csv
  03_ONTOLOGY/VALIDATABLE_FIELDS.md
  04_SKILLS/SKILL_EVIDENCE_MATRIX.csv
  04_SKILLS/FINAL_SKILL_SCOPE.md
"""
from __future__ import annotations

import collections
import csv
import io
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '03_ONTOLOGY'))
import mapping as ONT  # noqa: E402

AUDIT = os.path.join(HERE, '01_DATA', 'DATASET_EXECUTABILITY_AUDIT.csv')
TARGET = os.path.join(HERE, '02_TARGET', 'TARGET_EVIDENCE_MATRIX.csv')

SC = {'STRONG': 3, 'MODERATE': 2, 'WEAK': 1, 'NONE': 0}
BENCH_C = ('3_public_raw_data', '4_human_gold', '5_pragmatic_annotation',
           '6_natural_conversation', '7_multi_turn', '8_korean_language',
           '9_objective_benchmark_feasibility')
PROB_C = ('1_direct_problem_evidence', '2_our_age_band_evidence')
FIT_C = ('10_fit_with_current_tech_frame',)


def w(path, text):
    d = os.path.dirname(path)
    if not os.path.isdir(d):
        os.makedirs(d)
    io.open(path, 'w', encoding='utf-8', newline='\n').write(text)
    return path


def rows(path):
    return list(csv.DictReader(io.open(path, encoding='utf-8-sig', newline='')))


# ── 01_DATA ──────────────────────────────────────────────
def tier_docs():
    au = rows(AUDIT)
    tc = collections.Counter(r['tier'] for r in au)
    dc = collections.Counter(r['downloadable_now'] for r in au)
    a = [r for r in au if r['tier'] == 'A']
    b = [r for r in au if r['tier'] == 'B']

    cen = [r for r in au if r['scope'] != 'OWN']
    own = [r for r in au if r['scope'] == 'OWN']
    t = ['# 지금 실제로 쓸 수 있는 자료', '',
         '조사한 자료 **%d개** (국외 %d · 국내 %d). 여기에 우리가 만든 평정 세트 %d개를 '
         '따로 센다 (**합치지 않는다**).' % (
             len(cen), sum(1 for r in au if r['scope'] == 'GLOBAL'),
             sum(1 for r in au if r['scope'] == 'KO'), len(own)), '',
         '| 등급 | 개수 | 뜻 |', '|---|---|---|',
         '| A | %d | 지금 접근 + 사람이 붙인 gold + 라벨 정의 + **우리 필드를 직접 잰다** |' % tc['A'],
         '| B | %d | 접근은 되는데 gold·언어·구조 중 하나가 모자라 proxy 로만 |' % tc['B'],
         '| C | %d | 문제 근거로는 쓰지만 benchmark 로는 못 쓴다 |' % tc['C'],
         '| D | %d | 지금 못 가져온다 |' % tc['D'], '',
         '## TIER A · %d개' % tc['A'], '']
    if not a:
        t.append('**없다.** 억지로 만들지 않았다.')
    for r in a:
        t += ['### %s' % r['name'], '',
              '- 우리 필드 · **%s**' % r['ontology_fields'],
              '- 라벨 · %s' % r['label_type'],
              '- 누가 붙였나 · %s' % r['annotator_count'],
              '- 일치도 · %s' % r['agreement_reported'],
              '- 라이선스 · %s' % r['license'],
              '- 확인 · %s' % r['provenance_note'], '']

    t += ['## A 가 하나뿐인 이유', '',
          '넷째 조건 때문이다. 앞 판에서는 셋만 봤더니 A 가 13개 나왔다.',
          '영어 화행 말뭉치도 A 가 되었다. 우리 제품은 한국어다.',
          '한국어 시스템을 영어 자료로 재면 그 시스템을 잰 것이 아니다.', '',
          '그래서 A 는 **우리 온톨로지 필드를 한국어로 직접 재는 것**만 남겼다.', '',
          '## TIER B · %d개 · proxy 로 쓴다' % tc['B'], '',
          '| 자료 | 우리 필드 | 왜 proxy 인가 |', '|---|---|---|']
    for r in b:
        t.append('| %s | %s | %s |' % (r['name'], r['ontology_fields'] or '-',
                                       r['tier_why'].replace('|', '·')[:110]))
    t += ['', '## 접근 상태', '',
          '| 상태 | 개수 |', '|---|---|']
    for k, v in dc.most_common():
        t.append('| %s | %d |' % (k, v))
    t += ['', '**URL 이 있다고 접근 가능으로 세지 않았다.**',
          '실제 파일 목록이나 다운로드 페이지를 본 것만 YES 로 두었고,',
          '못 본 것은 ACCESS_NOT_VERIFIED 로 남겼다.', '']
    w(os.path.join(HERE, '01_DATA', 'TIER_A_DATASETS.md'), chr(10).join(t))

    # 접근 근거
    e = ['# 접근을 어떻게 확인했나', '',
         '자료마다 실제로 무엇을 보았는지 적는다. 논문에 있다는 것은 근거가 아니다.', '',
         '| 자료 | 상태 | 본 것 | 주소 |', '|---|---|---|---|']
    for r in sorted(au, key=lambda x: (x['downloadable_now'], x['name'])):
        e.append('| %s | %s | %s | %s |' % (
            r['name'], r['downloadable_now'],
            (r['evidence_note'] or '-').replace('|', '·')[:120],
            (r['evidence_url'] or '-')[:70]))
    e += ['', '## 조사끼리 어긋난 곳', '']
    rec = [r for r in au if r['reconciled_note']]
    if not rec:
        e.append('없다.')
    for r in rec:
        e += ['### %s' % r['name'], '', r['reconciled_note'], '']
    w(os.path.join(HERE, '01_DATA', 'DATA_ACCESS_EVIDENCE.md'), chr(10).join(e))

    # 라이선스
    lic = ['# 라이선스 · 무엇을 해도 되고 무엇은 안 되나', '',
           '**이 표가 발표 자료에 무엇을 실을 수 있는지 정한다.**', '',
           '| 자료 | 라이선스 | 재배포 | 모델 학습 | 발표에 원문 |', '|---|---|---|---|---|']
    for r in sorted(au, key=lambda x: x['name']):
        if r['tier'] not in ('A', 'B'):
            continue
        show = 'X' if ('없음' in r['license'] or 'RESERVED' in r['license']
                       or 'NC' in r['license'] or 'ND' in r['license']) else 'O'
        lic.append('| %s | %s | %s | %s | %s |' % (
            r['name'], r['license'][:40] or '-',
            (r['redistribution'] or '-')[:34], (r['model_training'] or '-')[:34], show))
    lic += ['', '## 이번 실험이 지킨 것', '',
            '- **로컬 모델만 썼다.** 권리 유보 자료를 외부 API 로 보내지 않았다.',
            '  ollama 의 exaone3.5:7.8b · bge-m3 이고 이 컴퓨터를 안 떠났다.',
            '- TalkBank 규칙의 "비보관 옵트아웃" 문제도 같이 없어졌다. 아예 안 보냈다.',
            '- 권리 유보 자료의 **사본을 이 꾸러미에 두지 않았다.** 원래 자리에서 읽기만 한다.',
            '- 보고서에 **원문 예시를 싣지 않는다.** 집계 숫자만 낸다.',
            '- 발표에 예시를 실을 수 있는 것은 KMI (CC BY 4.0) 하나뿐이다. 저작자를 표시한다.', '']
    w(os.path.join(HERE, '01_DATA', 'LICENSE_AUDIT.md'), chr(10).join(lic))
    return tc, a, b


# ── 02_TARGET ────────────────────────────────────────────
def target_doc():
    tr = rows(TARGET)
    got = {r['criterion'] for r in tr}
    want = set(BENCH_C) | set(PROB_C) | set(FIT_C)
    if got != want:
        raise SystemExit('criterion 어휘가 다르다 · 없는 것 %s · 남는 것 %s'
                         % (sorted(want - got), sorted(got - want)))
    cell, bench, prob, fit = {}, collections.defaultdict(int), \
        collections.defaultdict(int), collections.defaultdict(int)
    for r in tr:
        p, c, s = r['population'], r['criterion'], r['score'].strip().upper()
        cell[(p, c)] = s
        if c in BENCH_C:
            bench[p] += SC[s]
        elif c in PROB_C:
            prob[p] += SC[s]
        else:
            fit[p] += SC[s]
    pops = sorted(bench, key=lambda x: (-bench[x], -prob[x]))
    top_b = pops[0]
    top_p = sorted(prob, key=lambda x: -prob[x])[0]

    t = ['# 타겟을 데이터로 다시 본다', '',
         '사람을 모집하지 않는다. 그래서 모집 난이도 · 참여 편의 · IRB 용이성을',
         '순위 기준에서 **뺐다.** 남은 것은 근거와 데이터뿐이다.', '',
         '## 두 축을 따로 센다', '',
         '| 집단 | benchmark 가능성 (21점) | 문제 근거 (6점) | 기술 적합 (3점) | Human Gold |',
         '|---|---|---|---|---|']
    for p in pops:
        t.append('| %s | %d | %d | %d | %s |' % (
            p, bench[p], prob[p], fit[p], cell[(p, '4_human_gold')]))
    t += ['', '두 축의 1위가 **다르다.** benchmark 는 %s, 문제 근거는 %s 다.' % (top_b, top_p),
          '이것이 이번 조사의 핵심이다.', '',
          '## 세 가지를 같게 두지 않는다', '',
          '| | 집단 | 근거 |', '|---|---|---|',
          '| PROBLEM GROUNDING | SCD 아동 · ASD 아동 | 문제 근거 %d/6 · %d/6 로 가장 두껍다 |'
          % (prob['SCD child'], prob['ASD child']),
          '| TECHNICAL BENCHMARK | 비임상 한국어 | benchmark %d/21 · 유일하게 Human Gold=%s |'
          % (bench['nonclinical Korean population'],
             cell[('nonclinical Korean population', '4_human_gold')]),
          '| PRODUCT TARGET | **PROVISIONAL · 확정하지 않는다** | 아래 참조 |', '',
          '## 강사님이 물을 것 · "아동 근거가 더 많은데 왜 아동이 아닌가"', '',
          '**근거상으로는 아동이 맞다.** 그것을 숨기지 않는다.',
          'SCD 아동 문제 근거 %d/6 · SCD 청소년 %d/6 · SCD 청년 %d/6 이다.'
          % (prob['SCD child'], prob['SCD adolescent'], prob['SCD young adult']),
          '문헌은 아동을 가리킨다.', '',
          '그래서 **문제 근거 집단을 아동으로 적는다.** 제품 타겟과 분리해서.', '',
          '제품 타겟을 아동으로 바로 옮기지 않는 이유는 근거가 아니라 매체와 절차다.',
          '- 우리 제품은 글로 하는 자기 연습이다. 아동은 보호자 동의와 다른 설계가 필요하다.',
          '- **아동도 benchmark 가 없다.** SCD 아동 benchmark 가능성은 %d/21 이고 '
          'Human Gold 는 %s 다.' % (bench['SCD child'], cell[('SCD child', '4_human_gold')]),
          '  아동으로 옮겨도 잴 것이 생기지 않는다. 옮기는 것이 문제를 풀지 않는다.', '',
          '## 두 번째 질문 · "아동도 Human-Gold benchmark 가 없나"', '',
          '**없다.** 임상군 전체가 그렇다.', '',
          '| 집단 | 공개 원자료 | Human Gold | 한국어 | benchmark 가능성 |', '|---|---|---|---|---|']
    for p in pops:
        t.append('| %s | %s | %s | %s | %s |' % (
            p, cell[(p, '3_public_raw_data')], cell[(p, '4_human_gold')],
            cell[(p, '8_korean_language')], cell[(p, '9_objective_benchmark_feasibility')]))
    t += ['', '임상군 중 Human Gold 가 MODERATE 이상인 것은 ASD 아동뿐이고',
          '그것도 한국어가 %s 다. 영어 자료다.' % cell[('ASD child', '8_korean_language')],
          '', '## 지금 우리 기술 POC 대상이 가장 약하다', '',
          'SCD 청년(18~25)은 benchmark %d/21 · 문제 근거 %d/6 으로'
          % (bench['SCD young adult'], prob['SCD young adult']),
          '아홉 집단 중 가장 낮은 축이다. **이 사실을 감추지 않는다.**', '',
          '기술 POC 를 비임상 한국어로 돌린 것은 그래서 맞는 선택이었다.',
          '다만 그것을 "SCD 를 검증했다" 고 부르면 안 된다. 부르지 않는다.', '',
          '## 결론', '',
          '```', 'PROBLEM GROUNDING POPULATION  = SCD 아동 · ASD 아동 (문헌)',
          'TECHNICAL BENCHMARK POPULATION = 비임상 한국어 (유일하게 잴 수 있다)',
          'PRODUCT TARGET                 = PROVISIONAL (확정 보류)', '```', '',
          '데이터가 그렇게 말한다. 셋을 하나로 합치면 어느 하나가 거짓이 된다.', '']
    w(os.path.join(HERE, '02_TARGET', 'TARGET_DECISION.md'), chr(10).join(t))
    return bench, prob, cell


# ── 03_ONTOLOGY ──────────────────────────────────────────
def ontology_docs():
    out = [['field', 'dataset', 'gold_label', 'mapping_rule', 'metric',
            'validation_strength', 'note']]
    for f in ONT.FIELDS:
        ms = ONT.field_rows()[f]
        if not ms:
            out.append([f, '-', '-', '-', '-', 'NOT_VALIDATABLE', ONT.NO_GOLD.get(f, '')])
        for m in ms:
            out.append([f, m['dataset'], m['gold_label'], m['rule'], m['metric'],
                        m['strength'], m['note']])
    p = os.path.join(HERE, '03_ONTOLOGY', 'DATASET_ONTOLOGY_MAPPING.csv')
    with io.open(p, 'w', encoding='utf-8-sig', newline='') as fh:
        csv.writer(fh).writerows(out)

    st = {f: ONT.status_of(f) for f in ONT.FIELDS}
    c = collections.Counter(st.values())
    t = ['# 어느 필드를 무엇으로 검증하는가', '',
         '강사님 질문 · **"그 데이터로 너희 시스템의 정확히 뭘 검증하는데?"**', '',
         '| 상태 | 개수 | 필드 |', '|---|---|---|']
    for s in ONT.STRENGTH:
        fs = [f for f in ONT.FIELDS if st[f] == s]
        t.append('| %s | %d | %s |' % (s, c[s], ' · '.join(fs) or '-'))
    t += ['', '## 필드별', '']
    for f in ONT.FIELDS:
        t += ['### %s · %s' % (f, st[f]), '']
        ms = ONT.field_rows()[f]
        if not ms:
            t += ['검증할 자료가 없다.', '', '> %s' % ONT.NO_GOLD.get(f, ''), '']
            continue
        t += ['| 자료 | gold | 매핑 규칙 | 지표 | 강도 |', '|---|---|---|---|---|']
        for m in ms:
            t.append('| %s | %s | %s | %s | %s |' % (
                m['dataset'], m['gold_label'].replace('|', '·'),
                m['rule'].replace('|', '·')[:90], m['metric'].replace('|', '·'),
                m['strength']))
        t.append('')
        for m in ms:
            t.append('- **%s** · %s' % (m['dataset'], m['note']))
        t.append('')
    t += ['## 억지로 재지 않는 것', '']
    for f, why in ONT.NO_GOLD.items():
        t += ['- **%s** · %s' % (f, why)]
    t += ['', '이 셋은 gold 가 없다. 없는 것을 있는 척하지 않는다.',
          'LLM 으로 정답을 만들어 LLM 을 채점하면 그것은 검증이 아니다.', '']
    w(os.path.join(HERE, '03_ONTOLOGY', 'VALIDATABLE_FIELDS.md'), chr(10).join(t))
    return st


def main():
    tc, a, b = tier_docs()
    bench, prob, cell = target_doc()
    st = ontology_docs()
    print('자료 등급 ·', dict(sorted(tc.items())))
    print('TIER A ·', [r['name'] for r in a] or '없음')
    print('온톨로지 필드 ·', dict(collections.Counter(st.values())))
    print('benchmark 1위 ·', sorted(bench, key=lambda x: -bench[x])[0])
    print('문제 근거 1위 ·', sorted(prob, key=lambda x: -prob[x])[0])
    print('만든 문서 · 01_DATA 3 · 02_TARGET 1 · 03_ONTOLOGY 2')
    return 0


if __name__ == '__main__':
    sys.exit(main())
