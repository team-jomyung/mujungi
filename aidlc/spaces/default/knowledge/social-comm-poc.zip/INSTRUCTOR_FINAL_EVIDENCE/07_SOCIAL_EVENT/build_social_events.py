# -*- coding: utf-8 -*-
"""공개된 진짜 대화를 Social Event 구조로 바꾼다.

    python build_social_events.py             규칙만으로 (모델 안 씀)
    python build_social_events.py --llm       모델로 해석·현상 칸까지 채운다

왜 KMI 인가
  **발표에 원문을 실을 수 있는 유일한 한국어 다중턴 대화**라서다.
  CC BY 4.0 이고 저작자 표시만 하면 된다.
  나머지 한국어 자료는 라이선스가 없어(권리 유보) 예시를 못 싣는다.

칸마다 표시를 붙인다
  GOLD_VALIDATED   자료가 사람 gold 로 준다
  PROXY            자료가 값을 주는데 그 값이 사람 것이 아니다
  DEMONSTRATION    우리가 만들어 보여 준다. **정확도를 말하지 않는다**

  KMI 의 전략 라벨은 PROXY 다. 사람이 붙인 주석이 아니라
  T5 가 먼저 고르고 GPT-4 가 거기 맞춰 문장을 쓴 **생성 조건**이다.
  그래서 이 예시들로 정확도를 주장하지 않는다.

출처 표시
  Kim, Hyunjong et al. "KMI: A Dataset of Korean Motivational Interviewing
  Dialogues for Psychotherapy." NAACL 2025. CC BY 4.0.
"""
from __future__ import annotations

import argparse
import io
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.abspath(os.path.join(HERE, '..', '..'))
sys.path.insert(0, os.path.join(HERE, '..', '05_BENCHMARK', 'harness'))
import data as D  # noqa: E402

OUT = os.path.join(HERE, 'examples')
ATTRIB = ('Kim, Hyunjong; Lee, Suyeon; Cho, Yeongjae; Ryu, Eunseo; Jo, Yohan; '
          'Seong, Suran; Cho, Sungzoon. "KMI: A Dataset of Korean Motivational '
          'Interviewing Dialogues for Psychotherapy." NAACL 2025. CC BY 4.0.')

# 전략 라벨 → 우리 어휘
STRATEGY_KO = {
    'Open Question': '열린 물음', 'Closed Question': '닫힌 물음',
    'Simple Reflection': '단순 되비추기', 'Complex Reflection': '복합 되비추기',
    'Affirm': '인정하기', 'Advise': '조언하기',
    'Give Information': '정보 주기', 'General': '일반',
}

# 규칙으로 뽑는 언어 단서. sc_LinguisticCue 의 예시 목록과 같은 갈래다
CUE_RULES = [
    ('주저 표지', re.compile(r'(음\.\.\.|어\.\.\.|그\.\.\.|글쎄|뭐랄까|아무래도)')),
    ('완화 표현', re.compile(r'(좀|조금|약간|살짝|~것 같|듯|아마|혹시)')),
    ('강화 표현', re.compile(r'(정말|진짜|너무|엄청|매우|항상|절대|전혀)')),
    ('경어 수준', re.compile(r'(습니다|십니다|세요|시죠|시네요)')),
    ('반복', re.compile(r'(\S{2,})\s*\1')),
]
# 담화 단서
DISC_RULES = [
    ('자기수정', re.compile(r'(아니|아니라|그게 아니라|말고)')),
    ('백채널', re.compile(r'^(네|음|아|그렇군요|맞아요)[\s.,]')),
]


def cues_of(text):
    out = []
    for name, rx in CUE_RULES:
        m = rx.search(text)
        if m:
            out.append({'cue': name, 'kind': 'sc_LinguisticCue',
                        'from_feature': m.group(0)[:16]})
    for name, rx in DISC_RULES:
        m = rx.search(text)
        if m:
            out.append({'cue': name, 'kind': 'sc_DiscourseCue',
                        'from_feature': m.group(0)[:16]})
    return out


def build_event(dlg, max_turns=8):
    turns = dlg['dialogue'][:max_turns]
    participants = [
        {'id': 'P1', 'label': '내담자', 'role': 'client'},
        {'id': 'P2', 'label': '상담자', 'role': 'counselor'},
    ]
    sus = []
    for i, t in enumerate(turns):
        spk = 'P2' if t['role'] == 'Therapist' else 'P1'
        txt = t['utterance_ko']
        node = {
            'id': 'U%02d' % (i + 1),
            'spoken_by': spk,
            'text': txt,
            'attributions': [],
        }
        if 'label' in t:
            node['attributions'].append({
                'type': 'sc_StrategyAttribution',
                'has_strategy': STRATEGY_KO.get(t['label'], t['label']),
                'source_value': t['label'],
                'provenance': 'KMI label',
                'status': 'PROXY',
                'why': '자료가 주는 값이지만 사람 주석이 아니다 (생성 조건)',
            })
        c = cues_of(txt)
        for x in c:
            node['attributions'].append({
                'type': 'sc_CueObservation',
                'has_cue': x['cue'], 'cue_kind': x['kind'],
                'from_feature': x['from_feature'],
                'provenance': 'rule',
                'status': 'DEMONSTRATION',
                'why': '규칙으로 뽑았다. 이 단서에 대한 gold 가 없다',
            })
        sus.append(node)

    return {
        'event_id': 'SE-KMI-%04d' % dlg['id'],
        'source': {'dataset': 'KMI', 'dialogue_id': dlg['id'],
                   'category': dlg['category_ko'], 'license': 'CC BY 4.0',
                   'attribution': ATTRIB},
        'context': {
            'situation_type': 'COUNSELING',
            'relationship_type': 'COUNSELOR_CLIENT',
            'topic': dlg['category_ko'],
            'status': 'GOLD_VALIDATED',
            'why': '자료가 직접 준다 · 역할과 주제는 파일에 적혀 있다',
        },
        'participants': participants,
        'situated_utterances': sus,
        'field_status': field_status(sus),
        'NOT_A_PERFORMANCE_CLAIM': (
            '이 예시는 구조화를 보여 준다. PROXY 와 DEMONSTRATION 칸의 '
            '정확도를 주장하지 않는다'),
    }


def field_status(sus):
    st = {}
    for u in sus:
        for a in u['attributions']:
            st.setdefault(a['type'], {'status': a['status'], 'n': 0})
            st[a['type']]['n'] += 1
    for f in ('sc_ActAttribution', 'sc_InterpretationAttribution',
              'sc_PhenomenonAttribution', 'sc_GoalAttribution',
              'sc_StrategyRecommendation'):
        st.setdefault(f, {'status': 'NOT_PRODUCED', 'n': 0})
    return st


def llm_enrich(event):
    """해석과 현상 칸을 모델로 채운다. **DEMONSTRATION 으로만 표시한다.**"""
    import llm as L
    for u in event['situated_utterances']:
        if u['spoken_by'] != 'P1':
            continue
        p = ('다음은 상담 대화의 한 대목이다.%s'
             '내담자 "%s"%s'
             '이 말이 이 자리에서 무엇을 하려는 말인지 한 문장으로만 쓰시오.%s답:'
             % (chr(10), u['text'], chr(10), chr(10)))
        try:
            r = L.generate(p, max_tokens=60, stop=[chr(10)])
        except Exception:
            continue
        txt = (r['text'] or '').strip()
        if txt:
            u['attributions'].append({
                'type': 'sc_InterpretationAttribution',
                'has_interpretation': txt[:120],
                'modes': ['pragmatic'],
                'provenance': 'local LLM (exaone3.5:7.8b)',
                'status': 'DEMONSTRATION',
                'why': '이 칸에는 gold 가 없다. 정확도를 말할 수 없다',
            })
    event['field_status'] = field_status(event['situated_utterances'])
    return event


def main(argv):
    ap = argparse.ArgumentParser()
    ap.add_argument('--llm', action='store_true')
    ap.add_argument('--n', type=int, default=12)
    a = ap.parse_args(argv)

    dl = D.load_kmi()
    if not dl:
        print('KMI 가 없다 · experiments/kmi.json')
        return 2
    # 주제를 골고루
    by = {}
    for d in dl:
        by.setdefault(d['category_ko'], []).append(d)
    picked = []
    i = 0
    while len(picked) < a.n:
        added = False
        for cat in sorted(by):
            if i < len(by[cat]) and len(picked) < a.n:
                picked.append(by[cat][i])
                added = True
        if not added:
            break
        i += 1

    if not os.path.isdir(OUT):
        os.makedirs(OUT)
    events = []
    for d in picked:
        e = build_event(d)
        if a.llm:
            e = llm_enrich(e)
        events.append(e)
        io.open(os.path.join(OUT, e['event_id'] + '.json'), 'w',
                encoding='utf-8', newline='\n').write(
            json.dumps(e, ensure_ascii=False, indent=2) + chr(10))

    import collections
    st = collections.Counter()
    for e in events:
        for f, v in e['field_status'].items():
            st['%s:%s' % (f.replace('sc_', ''), v['status'])] += 1
    print('Social Event %d개 · %s' % (len(events), OUT))
    print('  주제 ·', dict(collections.Counter(e['source']['category'] for e in events)))
    for k, v in sorted(st.items()):
        print('  %-46s %d' % (k, v))
    print('  모델 사용 ·', 'YES' if a.llm else 'NO (규칙만)')
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
