# POC-P3 · 공개 대화를 Social Event 로

공개된 진짜 한국어 대화 **12건**을 L4 구조로 바꿨다.

## 왜 KMI 인가

발표에 원문을 실을 수 있는 **유일한** 한국어 다중턴 대화라서다. CC BY 4.0 이고
저작자 표시만 하면 된다. 나머지 한국어 자료는 라이선스가 없어(권리 유보) 예시를 못 싣는다.

> Kim, Hyunjong et al. "KMI: A Dataset of Korean Motivational Interviewing
> Dialogues for Psychotherapy." NAACL 2025. CC BY 4.0.

## 칸마다 표시를 붙인다

| 표시 | 뜻 | 이 자료에서 |
|---|---|---|
| GOLD_VALIDATED | 자료가 사람 gold 로 준다 | 맥락 · 참여자 · 역할 |
| PROXY | 값은 주는데 사람 것이 아니다 | StrategyAttribution |
| DEMONSTRATION | 우리가 만들어 보인다 | CueObservation (규칙) |
| NOT_PRODUCED | 안 만들었다 | Interpretation · Goal · Phenomenon · Act |

예시 한 건의 칸 상태 · {'PROXY': 1, 'DEMONSTRATION': 1, 'NOT_PRODUCED': 5}

## 정확도를 말하지 않는 이유

StrategyAttribution 의 라벨은 사람 주석이 아니다. T5 forecaster 가 라벨을 먼저 고르고
GPT-4 가 그 라벨에 맞는 발화를 썼다. **생성 조건이지 주석이 아니다.**
전문가 4인이 확인한 것은 표본 210발화뿐이고 General 라벨은 아예 빠졌다.

그래서 이 예시들로 구조화가 **된다**는 것은 보이지만, 얼마나 정확한지는 말하지 않는다.

## 돌리는 법

    python build_social_events.py          규칙만 (모델 안 씀)
    python build_social_events.py --llm    해석 칸까지 모델로 채운다

`--llm` 으로 채운 해석 칸도 **DEMONSTRATION** 이다. 그 칸에는 gold 가 없다.
