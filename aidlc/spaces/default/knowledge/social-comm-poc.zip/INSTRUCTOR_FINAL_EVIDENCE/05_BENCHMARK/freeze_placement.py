# -*- coding: utf-8 -*-
"""채점할 집합과 정답 자리를 파일로 못박는다.

    python freeze_placement.py

왜 필요한가
  다섯 갈래를 **항목 단위로** 비교한다 (McNemar). 그러려면 같은 항목이
  갈래마다 같은 보기 순서를 가져야 한다. 갈래마다 자리를 다시 매기면
  "E1 만 맞힌 항목" 이 실력 차이인지 보기 순서 차이인지 알 수 없다.

  지금 코드는 집합을 한 번 만들어 다섯 갈래가 돌려 쓴다. 실측으로 확인했다 ·
  두 과제가 같은 객체이고, 다시 만들어도 자리가 하나도 안 바뀐다.

  다만 **확인했다는 말과 확인할 수 있는 것은 다르다.** 그래서 여기 적어 두고
  analyze.py 가 실제 예측과 대조한다. 구조를 누가 바꾸면 그때 걸린다.
"""
from __future__ import annotations

import collections
import io
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, 'harness'))
import data as D  # noqa: E402

OUT = os.path.join(HERE, 'results', 'PLACEMENT.json')


def build(per_maxim=10):
    items = D.load_kpt()
    _tr, te = D.split_kpt(items)
    te = D.subsample(te, per_maxim)
    pos = collections.Counter(x['gold_pos'] for x in te)
    per = {}
    for m in D.MAXIMS:
        c = collections.Counter(x['gold_pos'] for x in te if x['maxim'] == m)
        per[m] = {'counts': dict(sorted(c.items())),
                  'majority_baseline': round(max(c.values()) / sum(c.values()), 4)}
    return {
        'n': len(te),
        'items_per_maxim': per_maxim,
        'per_maxim_baseline': per,
        'split_seed': D.SPLIT_SEED,
        'shuffle_seed': D.SHUFFLE_SEED,
        'gold_position_counts': dict(sorted(pos.items())),
        'majority_position_baseline': round(max(pos.values()) / len(te), 4),
        'note': ('정답 자리는 채점 집합 전체에 한 번 배치되고 다섯 갈래가 그대로 쓴다. '
                 '갈래마다 다시 배치하지 않는다. 그래야 항목 단위 비교가 성립한다.'),
        'placement': {x['id']: {'gold_pos': x['gold_pos'], 'maxim': x['maxim'],
                                'roles': x['roles']} for x in te},
    }


def verify(frozen, pred_rows):
    """예측 파일이 이 배치를 따랐는가. 갈래끼리도 같은가."""
    bad = []
    pl = frozen['placement']
    by_item = collections.defaultdict(dict)
    for r in pred_rows:
        if r['task'] != 'implicature':
            continue
        by_item[r['item_id']][r['arm']] = r['gold']
    for item, arms in by_item.items():
        if item not in pl:
            bad.append('%s · 못박은 집합에 없는 항목이 채점됐다' % item)
            continue
        want = str(pl[item]['gold_pos'])
        for arm, got in arms.items():
            if got != want:
                bad.append('%s/%s · gold %s 인데 못박은 것은 %s' % (item, arm, got, want))
        if len(set(arms.values())) > 1:
            bad.append('%s · 갈래마다 gold 가 다르다 · %s' % (item, arms))
    return bad


def digest(obj):
    import hashlib
    return hashlib.sha256(json.dumps(obj, ensure_ascii=False, sort_keys=True)
                          .encode('utf-8')).hexdigest()


def compare(frozen, existing):
    """새로 만든 배치가 못박아 둔 것과 같은가. 다르면 무엇이 다른지 적는다."""
    bad = []
    a, b = existing.get('placement', {}), frozen['placement']
    miss = sorted(set(a) - set(b))
    extra = sorted(set(b) - set(a))
    if miss:
        bad.append('못박은 항목이 사라졌다 · %s' % miss[:5])
    if extra:
        bad.append('못박지 않은 항목이 생겼다 · %s' % extra[:5])
    for k in sorted(set(a) & set(b)):
        if a[k].get('gold_pos') != b[k]['gold_pos']:
            bad.append('%s · 자리가 %s 에서 %s 로 바뀌었다'
                       % (k, a[k].get('gold_pos'), b[k]['gold_pos']))
        if a[k].get('roles') != b[k]['roles']:
            bad.append('%s · 보기 순서가 바뀌었다' % k)
    return bad[:12]


def write(frozen):
    io.open(OUT, 'w', encoding='utf-8', newline=chr(10)).write(
        json.dumps(frozen, ensure_ascii=False, indent=2) + chr(10))


def main(argv=None):
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument('--force', action='store_true',
                    help='이미 못박은 것을 덮어쓴다. 정말 설계를 바꿀 때만')
    a = ap.parse_args(argv)

    frozen = build()
    d = os.path.dirname(OUT)
    if not os.path.isdir(d):
        os.makedirs(d)

    if os.path.exists(OUT):
        old = json.load(io.open(OUT, encoding='utf-8'))
        diff = compare(frozen, old)
        if not diff:
            print('못박힌 그대로다')
        elif not a.force:
            print('**못박은 배치와 지금 코드가 다르다. 덮어쓰지 않는다.**')
            for x in diff:
                print('    %s' % x)
            print('  코드가 틀렸으면 코드를 고친다.')
            print('  설계를 정말 바꾸는 것이면 --force 로 다시 못박는다.')
            return 2
        else:
            print('**--force · 기준을 다시 못박는다**')
            for x in diff:
                print('    %s' % x)
            print('  sha %s -> %s' % (digest(old['placement'])[:16],
                                      digest(frozen['placement'])[:16]))
            write(frozen)
    else:
        write(frozen)
        print('처음 못박았다')

    frozen = json.load(io.open(OUT, encoding='utf-8'))
    print('못박은 것 · %d항목 · %s · sha %s'
          % (frozen['n'], os.path.basename(OUT), digest(frozen['placement'])[:16]))
    print('  자리 분포 %s · 다수 자리 기준선 %.3f'
          % (frozen['gold_position_counts'], frozen['majority_position_baseline']))
    for m, v in frozen['per_maxim_baseline'].items():
        print('    %-9s %s · 다수 자리 %.3f' % (m, v['counts'], v['majority_baseline']))

    jl = os.path.join(HERE, 'results', 'raw_predictions.jsonl')
    if os.path.exists(jl):
        rows = []
        for x in io.open(jl, encoding='utf-8'):
            x = x.strip()
            if x:
                try:
                    rows.append(json.loads(x))
                except ValueError:
                    pass
        bad = verify(frozen, rows)
        print('  예측 %d줄 대조 · 어긋난 곳 %d' % (len(rows), len(bad)))
        for b in bad[:8]:
            print('      %s' % b)
        return 1 if bad else 0
    print('  아직 예측 파일이 없다')
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
