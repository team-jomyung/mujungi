# 벤치마크 하네스

지시서가 그린 구조와 두 군데가 다르다. 빠뜨린 것이 아니라 그렇게 두기로 한 것이라
여기 적어 둔다.

## `datasets/` 를 만들지 않았다

**권리 유보 자료의 사본을 이 꾸러미에 두지 않기 위해서다.**

시험에 쓰는 한국어 화용 평가셋은 저장소에 라이선스 파일이 없다
(`gh api` 로 2026-09-15 확인 · `license: null`). 라이선스 없음은 자유 이용이 아니라
권리 유보다. `experiments/DATA_LICENSE_NOTES.md` 가 내부 분석까지만으로 정리했고,
공개 전 점검표에 "라이선스 없는 자료의 사본이 공개 대상 폴더에 남아 있지 않은가" 가 있다.

그래서 `harness/data.py` 가 원래 자리(`experiments/korean_pragmatics_testset.csv`)에서
읽기만 하고, 이 꾸러미에는 **집계 숫자만** 남긴다.
`verify_package.py` 가 꾸러미 안에 그 파일 사본이 있으면 실패시킨다.

## `adapters/` 를 따로 두지 않았다

어댑터가 할 일을 `harness/data.py` 가 한다. 자료가 둘뿐이라 층을 하나 더 두면
읽기만 어려워진다. 하는 일은 셋이다.

- `load_kpt()` · 원본 CSV 를 읽어 보기와 구실을 뽑는다
- `place_gold()` · **쓸 집합을 받아** 정답 자리를 고르게 돌린다
- `kmi_strategy_items()` · KMI 대화를 전략 판정 문항으로 바꾼다

자료가 셋 이상으로 늘면 그때 나눈다.

## 파일

| 파일 | 하는 일 |
|---|---|
| `harness/llm.py` | 로컬 모델 한 곳. seed · 온도 · 문맥 길이를 고정한다 |
| `harness/data.py` | 자료 읽기 · 나누기 · 정답 자리 배치 |
| `harness/kb.py` | 지식창고 하나 · 꺼내는 방법 둘 (벡터 · 그래프) |
| `harness/arms.py` | E0~E4 와 길이 통제 E1F · 과제 셋 |
| `harness/metrics.py` | 정확도 · macro F1 · Wilson 구간 · McNemar |
| `harness/leakage.py` | 시험 문항이 새는가. **실험 전에 통과해야 한다** |
| `harness/run.py` | 실행. 잠금 · 이어 돌리기 · 기준선 가드 |
| `freeze_placement.py` | 채점 집합과 정답 자리를 못박고 대조한다 |
| `results/PLACEMENT.json` | 못박은 배치. 덮어쓰려면 `--force` |

## 돌리는 순서

    python freeze_placement.py
    cd harness
    python leakage.py
    python run.py --tasks implicature,maxim --test-per-maxim 10 --k 3
    python run.py --tasks implicature,maxim --arms E1F --append

중간에 죽으면 `--resume`. 다 돌린 칸은 살리고 반쯤 돌린 칸만 버린다.

## 이 하네스가 실제로 겪은 것

- 두 판이 같은 파일에 동시에 써서 결과에 널 바이트가 박혔다 → 잠금 + 심장박동
- 정답 자리가 채점 집합에서 35% 로 치우쳐 있었다 → `place_gold()` 를 뒤로 옮김 + 가드
- KV 캐시가 8.7GB 라 메모리 부족으로 두 번 죽었다 → `num_ctx` 를 1024 로
  (줄인 뒤 이미 돌린 문항 9개를 다시 불러 9/9 같은 것을 확인하고 섞었다)
- 400개를 다 돌려 놓고 마지막 재현 확인에서 죽었다 → 이어 돌린 칸을 건너뛰도록
