# -*- coding: utf-8 -*-
"""점수. 정확도 하나로 끝내지 않는다.

왜 여러 개를 보나
  정확도만 보면 어느 라벨에서 못하는지 안 보인다. 라벨이 고르게 뽑혀 있어도
  한 라벨을 통째로 못 맞히면서 전체 정확도는 그럭저럭일 수 있다.

  형식 실패는 **틀린 것과 따로 센다.** 답을 못 고른 것과 틀리게 고른 것은 다른 고장이다.
  다만 정확도의 분모에는 넣는다. 못 읽은 것을 빼고 재면 성적이 좋아 보인다.

함축 과제만 더 보는 것
  오답 자리가 무슨 구실이었는지 자료가 알려 준다.
  문자 그대로 읽어서 틀렸는가(literal) 가 우리 관심사다. 그것이 우리가 다루려는 증상이다.
"""
from __future__ import annotations

import collections
import math


def _f1(tp, fp, fn):
    p = tp / (tp + fp) if tp + fp else 0.0
    r = tp / (tp + fn) if tp + fn else 0.0
    return 2 * p * r / (p + r) if p + r else 0.0, p, r


def score(rows, labels):
    """rows · {gold, pred(None 이면 형식 실패), seconds, prompt_tokens, output_tokens}"""
    n = len(rows)
    if not n:
        return {}
    ok = sum(1 for r in rows if r['pred'] is not None and r['pred'] == r['gold'])
    invalid = sum(1 for r in rows if r['pred'] is None)
    per = {}
    for lab in labels:
        tp = sum(1 for r in rows if r['gold'] == lab and r['pred'] == lab)
        fp = sum(1 for r in rows if r['gold'] != lab and r['pred'] == lab)
        fn = sum(1 for r in rows if r['gold'] == lab and r['pred'] != lab)
        f, p, rc = _f1(tp, fp, fn)
        per[lab] = {'f1': round(f, 4), 'precision': round(p, 4), 'recall': round(rc, 4),
                    'support': sum(1 for r in rows if r['gold'] == lab)}
    macro = sum(v['f1'] for v in per.values()) / len(labels) if labels else 0.0
    secs = [r['seconds'] for r in rows]
    return {
        'n': n,
        'accuracy': round(ok / n, 4),
        'macro_f1': round(macro, 4),
        'invalid_rate': round(invalid / n, 4),
        'invalid_n': invalid,
        'correct_n': ok,
        'per_class': per,
        'median_seconds': round(sorted(secs)[n // 2], 2),
        'total_seconds': round(sum(secs), 1),
        'mean_prompt_tokens': round(sum(r['prompt_tokens'] for r in rows) / n, 1),
        'mean_output_tokens': round(sum(r['output_tokens'] for r in rows) / n, 1),
    }


def wilson(k, n, z=1.96):
    """정확도의 구간. 80항목짜리라 점추정만 내놓으면 과하게 읽힌다."""
    if not n:
        return (0.0, 0.0)
    p = k / n
    d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return (round(max(0.0, c - h), 4), round(min(1.0, c + h), 4))


def mcnemar(rows_a, rows_b):
    """같은 항목을 두 갈래가 맞혔는가. 짝지어 보는 것이 맞다.

    b = A만 맞힘 · c = B만 맞힘. 정확 이항검정(양측)."""
    by_a = {r['item_id']: r for r in rows_a}
    b = c = 0
    for r in rows_b:
        a = by_a.get(r['item_id'])
        if a is None:
            continue
        ha = a['pred'] == a['gold']
        hb = r['pred'] == r['gold']
        if ha and not hb:
            b += 1
        elif hb and not ha:
            c += 1
    n = b + c
    if n == 0:
        return {'b': 0, 'c': 0, 'p': 1.0, 'note': '다른 항목이 하나도 없다'}
    k = min(b, c)
    p = 0.0
    for i in range(k + 1):
        p += math.comb(n, i)
    p = min(1.0, 2 * p / (2 ** n))
    return {'b': b, 'c': c, 'p': round(p, 4)}


def holm(pvals):
    """여러 번 비교하면 우연히 유의한 것이 나온다. Holm 으로 조정한다.

    우리는 한 과제에서 비교를 넷 한다(E0-E1 · E1-E2 · E3-E4 · E1-E3).
    각각 0.05 로 보면 하나쯤 우연히 걸릴 확률이 꽤 된다.
    Holm 은 작은 p 부터 차례로 (n-i) 를 곱하고 단조성을 맞춘다.
    Bonferroni 보다 덜 보수적이면서 같은 보장을 준다.

    pvals · {이름: p}. 돌려주는 것 · {이름: 조정된 p}
    """
    if not pvals:
        return {}
    items = sorted(pvals.items(), key=lambda kv: kv[1])
    n = len(items)
    out, prev = {}, 0.0
    for i, (k, p) in enumerate(items):
        adj = min(1.0, (n - i) * p)
        adj = max(adj, prev)          # 단조성 · 앞의 것보다 작아질 수 없다
        out[k] = round(adj, 4)
        prev = adj
    return out


def confusion(rows, labels):
    m = collections.OrderedDict()
    for g in labels:
        m[g] = collections.OrderedDict((p, 0) for p in list(labels) + ['INVALID'])
    for r in rows:
        if r['gold'] in m:
            m[r['gold']][r['pred'] if r['pred'] in m[r['gold']] else 'INVALID'] += 1
    return m


def error_roles(rows):
    """함축 과제 전용. 틀렸을 때 어느 구실의 보기를 골랐는가."""
    c = collections.Counter()
    for r in rows:
        if r['pred'] is None:
            c['INVALID'] += 1
            continue
        roles = r.get('roles') or []
        i = int(r['pred']) - 1
        c[roles[i] if 0 <= i < len(roles) else 'UNKNOWN'] += 1
    return dict(c)
