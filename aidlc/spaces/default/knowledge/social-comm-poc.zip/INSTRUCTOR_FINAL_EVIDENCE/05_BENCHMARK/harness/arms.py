# -*- coding: utf-8 -*-
"""E0~E4 와 과제 셋. 붙이는 것만 다르고 나머지는 전부 같게 둔다.

공정하게 재려면
  모델 · 온도 · seed · 출력 형식 · 시험 항목이 다섯 갈래에서 모두 같아야 한다.
  다른 것은 **프롬프트에 무엇을 얹는가** 하나뿐이다.

  E0  아무것도 안 얹는다
  E1  온톨로지 정의를 글로 얹는다            (사람이 읽는 말)
  E2  온톨로지를 구조로 얹는다               (JSON 스키마)
  E3  벡터로 꺼낸 문서 k개를 얹는다
  E4  그래프로 꺼낸 문서 k개를 얹는다

  E3 와 E4 는 **같은 창고**에서 꺼낸다. 꺼내는 방법만 다르다.

출력 형식
  숫자 하나 또는 라벨 하나만 받는다. 길게 말하면 파싱 실패로 세고 숨기지 않는다.
  실패율도 결과다. 구조를 못 지키는 것도 성능이다.
"""
from __future__ import annotations

import json
import re

import kb as KB

ARMS = ('E0', 'E1', 'E2', 'E3', 'E4')
# 길이 통제 갈래. 기본 ARMS 에는 안 넣고 따로 돌린다
CONTROL_ARMS = ('E1F',)
ARM_KO = {
    'E0': 'Plain LLM',
    'E1': 'Ontology 정의 (prompt)',
    'E2': 'Ontology 구조 (JSON)',
    'E3': 'Vector RAG',
    'E4': 'Graph 검색',
    'E1F': '길이 통제 (무관한 정의문)',
}

MAXIMS = KB.D.MAXIMS
STRATEGIES = ('Open Question', 'Closed Question', 'Simple Reflection', 'Complex Reflection',
              'Affirm', 'Advise', 'Give Information', 'General')

# ── 온톨로지를 어떻게 얹는가 ───────────────────────────────
ONTO_PROSE = {
    'implicature': (
        '참고 · 화용 해석에 대한 정의\n'
        '- 맥락 없는 해석은 해석이 아니라 사전적 의미다. 글자 그대로의 뜻과 맥락이 주는 뜻은 다르다.\n'
        '- 하나의 발화는 문자적 읽기와 화용적 읽기를 동시에 가질 수 있다.\n'
        '- 물어야 할 것은 "이 말이 이 자리에서 무엇을 하려는가" 이지 "이 말이 무슨 뜻인가" 가 아니다.\n'
        '- 맥락에 없는 이야기를 끌어온 읽기는 틀린 읽기다.'),
    'maxim': (
        '참고 · 대화 격률\n'
        + chr(10).join('- %s · %s' % (k, v) for k, v in KB.MAXIM_DEF.items())),
    'strategy': (
        '참고 · 대응 전략에 대한 정의\n'
        '- 전략은 이미 말해진 응답이 실제로 무엇을 했는가에 붙인다. 제안이 아니라 기술이다.\n'
        '- 되비추기는 상대가 한 말을 돌려주는 것이고, 복합 되비추기는 말하지 않은 것까지 얹는다.\n'
        '- 열린 물음은 짧게 답할 수 없는 물음이고, 닫힌 물음은 예/아니오로 끝난다.\n'
        '- 인정하기는 상대의 강점이나 노력을 짚는 것이다.\n'
        '- 조언은 무엇을 하라고 말하는 것이고, 정보 주기는 사실을 알려 주는 것이다.'),
}

# 길이 통제용. **화용과 아무 상관 없는 정의문**을 E1 과 비슷한 길이로 둔다.
#
# 왜 필요한가
#   E1 이 E0 보다 나았다고 해서 그것이 온톨로지 "내용" 때문이라고 말할 수 없다.
#   E1 은 프롬프트가 더 길다(171 대 286 토큰). 맥락이 길어서 나아졌을 수도 있다.
#   같은 길이 · 같은 말투 · 관계 없는 내용을 넣은 갈래가 있어야 둘이 갈린다.
#
#   E1F 가 E0 수준이면 · 좋아진 것은 내용 때문이다
#   E1F 가 E1 수준이면 · 좋아진 것은 길이 때문이고 온톨로지는 기여가 없다
FILLER_PROSE = {
    'implicature': (
        '참고 · 문서 편집에 대한 정의%s'
        '- 쪽 번호는 본문이 시작되는 쪽부터 매기고 표지에는 넣지 않는다. 겉장과 속장은 다르다.%s'
        '- 하나의 문단은 들여쓰기와 줄간격을 동시에 가질 수 있다.%s'
        '- 정해야 할 것은 "이 표가 이 자리에서 몇 칸을 차지하는가" 이지 "이 표가 무슨 표인가" 가 아니다.%s'
        '- 본문에 없는 그림을 끌어온 배치는 틀린 배치다.') % ((chr(10),) * 4),
    'maxim': (
        '참고 · 문서 편집 규칙%s'
        '- 여백 · 위아래를 같게 두고 좌우는 제본 쪽을 넓게 잡는다. 좁으면 글자가 묻힌다.%s'
        '- 글꼴 · 본문과 제목을 섞지 않는다. 섞으면 어디가 제목인지 흐려진다.%s'
        '- 번호 · 항목이 셋을 넘으면 번호를 붙인다. 붙이지 않으면 세기 어렵다.%s'
        '- 여백주 · 본문에 넣기 애매한 것만 옆에 적는다. 길면 본문으로 올린다.') % ((chr(10),) * 4),
    'strategy': (
        '참고 · 문서 편집에 대한 정의%s'
        '- 각주는 이미 적힌 본문에 붙이는 것이다. 예고가 아니라 설명이다.%s'
        '- 인용은 원문을 그대로 옮기는 것이고, 요약 인용은 옮기지 않은 것까지 줄인다.%s'
        '- 열린 목록은 항목이 늘 수 있는 목록이고, 닫힌 목록은 그것으로 끝난다.%s'
        '- 강조는 본문의 무게를 짚는 것이다.%s'
        '- 부록은 뒤로 미루는 것이고, 각주는 아래로 내리는 것이다.') % ((chr(10),) * 5),
}

ONTO_JSON = {
    'implicature': {
        'attribution': 'sc_InterpretationAttribution',
        'definition': '이 대상이 어떤 뜻으로 읽힌다는 주장',
        'about': 'sco_SituatedUtterance',
        'has_interpretation': {
            'node': 'sco_Interpretation',
            'definition': '하나의 발화가 특정 맥락에서 가질 수 있는 의미',
            'modes': {'values': 'open', 'multi': True, 'examples': ['literal', 'pragmatic']},
        },
        'constraint': '맥락 없는 해석은 해석이 아니라 사전적 의미다',
    },
    'maxim': {
        'attribution': 'sc_PhenomenonAttribution',
        'definition': '이 대상이 어떤 화용적 양태를 보인다는 주장',
        'about': 'sco_SituatedUtterance',
        'has_phenomenon': {'node': 'sc_PragmaticPhenomenon', 'values': list(MAXIMS),
                           'definitions': KB.MAXIM_DEF},
        'constraint': '비꼼인지 아닌지는 맥락이 정한다',
    },
    'strategy': {
        'attribution': 'sc_StrategyAttribution',
        'definition': '이 응답이 어떤 전략을 실제로 썼다는 주장',
        'about': 'sco_SituatedUtterance',
        'has_strategy': {'node': 'sc_ResponseStrategy',
                         'subtype': 'sc_CounselingStrategy', 'values': list(STRATEGIES)},
        'note': '대상은 응답 발화가 놓인 자리다. 이미 말했다',
    },
}


# ── 과제 ─────────────────────────────────────────────────
def q_implicature(it):
    opts = chr(10).join('(%d) %s' % (i + 1, t) for i, t in enumerate(it['options']))
    return ('맥락: %s%s발화: %s%s%s%s%s'
            % (it['context'], chr(10), it['statement'], chr(10), chr(10), opts, chr(10)),
            '위 발화가 이 맥락에서 갖는 가장 적절한 의미의 번호 하나만 쓰시오.')


def q_maxim(it):
    return ('맥락: %s%s발화: %s%s' % (it['context'], chr(10), it['statement'], chr(10)),
            '위 발화가 어긴 격률 하나만 쓰시오. 보기: ' + ' / '.join(MAXIMS))


def q_strategy(it):
    return ('내담자: %s%s상담자: %s%s' % (it['client'], chr(10), it['therapist'], chr(10)),
            '상담자의 마지막 말이 쓴 전략 하나만 쓰시오. 보기: ' + ' / '.join(STRATEGIES))


TASKS = {
    'implicature': {'q': q_implicature, 'onto': 'implicature', 'labels': ('1', '2', '3', '4'),
                    'ko': '함축 해석 · InterpretationAttribution', 'max_tokens': 6},
    'maxim': {'q': q_maxim, 'onto': 'maxim', 'labels': MAXIMS,
              'ko': '격률 위반 · PhenomenonAttribution', 'max_tokens': 8},
    'strategy': {'q': q_strategy, 'onto': 'strategy', 'labels': STRATEGIES,
                 'ko': '전략 판정 · StrategyAttribution', 'max_tokens': 10},
}


def retrieval_key(task, it):
    """꺼낼 때 쓰는 글. **정답 칸은 절대 안 쓴다.**"""
    if task == 'strategy':
        return it['client'] + ' ' + it['therapist']
    return it['context'] + ' ' + it['statement']


def build_prompt(arm, task, it, vindex=None, graph=None, k=4):
    spec = TASKS[task]
    body, ask = spec['q'](it)
    head = ''
    if arm == 'E1':
        head = ONTO_PROSE[spec['onto']] + chr(10) * 2
    elif arm == 'E1F':
        head = FILLER_PROSE[spec['onto']] + chr(10) * 2
    elif arm == 'E2':
        head = ('참고 · 구조 정의' + chr(10)
                + json.dumps(ONTO_JSON[spec['onto']], ensure_ascii=False, indent=1)
                + chr(10) * 2)
    elif arm in ('E3', 'E4'):
        idx = vindex if arm == 'E3' else graph
        if idx is None:
            raise ValueError('%s 인데 검색기가 없다' % arm)
        docs = idx.search(retrieval_key(task, it), k=k)
        head = ('참고 자료' + chr(10)
                + chr(10).join('[%s] %s' % (d['id'], d['text']) for d in docs)
                + chr(10) * 2)
    return head + body + chr(10) + ask + chr(10) + '답:'


# ── 답 읽기 ──────────────────────────────────────────────
def parse(task, text):
    """정해진 값 하나로 읽는다. 못 읽으면 None. 숨기지 않고 실패로 센다."""
    t = (text or '').strip()
    if not t:
        return None
    if task == 'implicature':
        m = re.search(r'[1-4]', t)
        return m.group(0) if m else None
    labels = TASKS[task]['labels']
    low = t.lower()
    hits = [lab for lab in labels if lab.lower() in low]
    if len(hits) == 1:
        return hits[0]
    if hits:
        # 여러 개 나오면 가장 먼저 나온 것
        return min(hits, key=lambda lab: low.index(lab.lower()))
    return None
