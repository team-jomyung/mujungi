# -*- coding: utf-8 -*-
"""평가 자료를 읽고 나눈다. **사본을 여기 두지 않는다.**

왜 사본을 안 두나
  한국어 화용 평가셋은 저장소에 고지 파일이 없다. 라이선스 없음은 자유 이용이 아니라
  권리 유보다. `experiments/DATA_LICENSE_NOTES.md` 가 내부 분석까지만 허용으로 정리했다.
  그래서 원래 자리에서 읽기만 하고, 이 꾸러미에는 **집계 숫자만** 남긴다.
  보고서에도 원문 예시를 싣지 않는다.

정답이 늘 (1) 이다
  120 항목 전부 MCQ Answer 가 1 이다. 섞지 않고 재면 "늘 1" 이라고 답하는 모델이 100% 를 받는다.
  항목마다 고정 씨로 보기를 섞고, 정답이 몇 번으로 갔는지와 각 자리가 무슨 구실인지 적어 둔다.
  구실은 자료가 직접 준다 · answer / literal / wrong-in-context / wrong-out-of-context.
  그래서 **틀린 방식**까지 나눠 볼 수 있다. 문자 그대로 읽어서 틀린 것이 우리 관심사다.
"""
from __future__ import annotations

import csv
import io
import json
import os
import random
import re

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.abspath(os.path.join(HERE, '..', '..', '..'))
KPT = os.path.join(REPO, 'experiments', 'korean_pragmatics_testset.csv')
KMI = os.path.join(REPO, 'experiments', 'kmi.json')

SPLIT_SEED = 20260915
SHUFFLE_SEED = 20260915
TRAIN_PER_MAXIM = 10          # 나머지 20 은 시험용
MAXIMS = ('quantity', 'quality', 'relation', 'manner')
ROLES = ('answer', 'literal', 'wrong_in_context', 'wrong_out_context')

OPT_RX = re.compile(r'^\((\d)\)\s*(.+)$')
ROLE_MAP = {
    'answer': 'answer',
    'literal interpretation': 'literal',
    'wrong implicature within context': 'wrong_in_context',
    'wrong implicature out of context': 'wrong_out_context',
}


def _parse_numbered(block):
    """(1) ... (2) ... 형식을 번호 → 내용 으로."""
    out = {}
    for ln in block.split(chr(10)):
        m = OPT_RX.match(ln.strip())
        if m:
            out[int(m.group(1))] = m.group(2).strip()
    return out


def load_kpt():
    """한국어 화용 평가셋. 보기를 섞어서 돌려준다."""
    if not os.path.exists(KPT):
        raise SystemExit('평가셋이 없다 · %s' % KPT)
    raw = list(csv.DictReader(io.open(KPT, encoding='utf-8', newline='')))
    items = []
    for r in raw:
        opts = _parse_numbered(r['MCQ'])
        roles = _parse_numbered(r['MCQ Details'])
        if len(opts) != 4 or len(roles) != 4:
            raise SystemExit('항목 %s 의 보기/구실 수가 4 가 아니다' % r['ID'])
        gold_raw = int(r['MCQ Answer'].strip())
        # 원본 자리 → (내용, 구실)
        pairs = []
        for i in (1, 2, 3, 4):
            role = ROLE_MAP.get(roles[i].strip().lower())
            if role is None:
                raise SystemExit('모르는 구실 · %s' % roles[i])
            pairs.append({'text': opts[i], 'role': role, 'orig_pos': i})
        if pairs[gold_raw - 1]['role'] != 'answer':
            raise SystemExit('항목 %s · 정답 자리와 answer 구실이 안 맞는다' % r['ID'])

        # 오답 셋의 순서만 여기서 정한다. **정답 자리는 아직 안 정한다.**
        # 자리를 id 로 정하면 나눈 뒤 뽑을 때 균형이 깨진다. 실제로 깨졌다 ·
        # 120 전체는 30/30/30/30 인데 시험 몫 40 에서 1번 자리가 14개(35%)였다.
        # 위에서 맞춰 놓고 아래에서 뽑으면 소용이 없다. 그래서 place_gold() 가
        # **실제로 쓰는 집합을 받아서** 그때 자리를 돌린다.
        rng = random.Random(SHUFFLE_SEED + int(r['ID']))
        others = [x for x in pairs if x['role'] != 'answer']
        rng.shuffle(others)
        gold = next(x for x in pairs if x['role'] == 'answer')

        items.append({
            'id': 'KPT%03d' % int(r['ID']),
            'maxim': r['Type of Maxim'].strip(),
            'context': r['Context'].strip(),
            'statement': r['Statement'].strip(),
            '_gold': gold, '_others': others,
            'oeq_answer': r['OEQ Answer'].strip(),
        })
    return place_gold(items)


def place_gold(items):
    """쓸 집합을 받아 정답 자리를 고르게 돌린다.

    격률 안에서 돌리고, 격률마다 시작점을 어긋나게 둔다.
    그러면 격률 안에서도 고르고 전체에서도 고르다.
    **이 함수를 나눈 뒤·뽑은 뒤에 다시 부른다.** 그것이 요점이다."""
    out = []
    start = 0
    for m in MAXIMS:
        grp = sorted([x for x in items if x['maxim'] == m], key=lambda x: x['id'])
        for i, x in enumerate(grp):
            pos = (i + start) % 4 + 1
            sh = x['_others'][:pos - 1] + [x['_gold']] + x['_others'][pos - 1:]
            y = dict(x)
            y.update({'options': [p['text'] for p in sh],
                      'roles': [p['role'] for p in sh],
                      'gold_pos': pos, 'gold_text': sh[pos - 1]['text']})
            out.append(y)
        start += len(grp)          # 격률마다 시작점을 밀어 전체 균형을 맞춘다
    out.sort(key=lambda x: x['id'])
    return out


def split_kpt(items):
    """격률별로 고르게 나눈다. 훈련 쪽은 few-shot 과 지식창고에만 쓴다."""
    train, test = [], []
    for m in MAXIMS:
        pool = sorted([x for x in items if x['maxim'] == m], key=lambda x: x['id'])
        rng = random.Random(SPLIT_SEED + MAXIMS.index(m))
        rng.shuffle(pool)
        train += pool[:TRAIN_PER_MAXIM]
        test += pool[TRAIN_PER_MAXIM:]
    train.sort(key=lambda x: x['id'])
    test.sort(key=lambda x: x['id'])
    return place_gold(train), place_gold(test)


def subsample(test, per_maxim, seed=SPLIT_SEED):
    """격률별로 고르게 줄인다. 균형을 깨면 우연 기준선이 25% 가 아니게 된다."""
    if not per_maxim:
        return test
    out = []
    for m in MAXIMS:
        pool = sorted([x for x in test if x['maxim'] == m], key=lambda x: x['id'])
        rng = random.Random(seed + 99 + MAXIMS.index(m))
        rng.shuffle(pool)
        out += pool[:per_maxim]
    out.sort(key=lambda x: x['id'])
    return place_gold(out)


def load_kmi(max_dialogues=None):
    """KMI. CC BY 4.0 · 저작자 표시하면 보여 줄 수 있는 유일한 자료다."""
    if not os.path.exists(KMI):
        return []
    d = json.load(io.open(KMI, encoding='utf-8'))
    return d[:max_dialogues] if max_dialogues else d


def kmi_strategy_items(dialogues, per_label=12, seed=SPLIT_SEED):
    """상담자 턴 + 바로 앞 내담자 턴 → 그 턴이 쓴 전략 맞히기.

    라벨이 아주 치우쳐 있어(Open Question 3305 · Advise 43) 라벨마다 같은 수로 뽑는다.
    치우친 채로 재면 다수 라벨만 찍어도 정확도가 높게 나온다."""
    by = {}
    for dlg in dialogues:
        turns = dlg['dialogue']
        for i, t in enumerate(turns):
            if t.get('role') != 'Therapist' or 'label' not in t:
                continue
            prev = turns[i - 1] if i > 0 else None
            if not prev or prev.get('role') != 'Client':
                continue
            by.setdefault(t['label'], []).append({
                'id': 'KMI%04d_%02d' % (dlg['id'], i),
                'category': dlg['category_ko'],
                'client': prev['utterance_ko'],
                'therapist': t['utterance_ko'],
                'gold': t['label'],
            })
    out = []
    for lab in sorted(by):
        pool = by[lab]
        rng = random.Random(seed + len(lab))
        rng.shuffle(pool)
        out += pool[:per_label]
    out.sort(key=lambda x: x['id'])
    return out


def summary():
    items = load_kpt()
    tr, te = split_kpt(items)
    import collections
    print('한국어 화용 평가셋 · %d항목 (훈련 %d · 시험 %d)' % (len(items), len(tr), len(te)))
    print('  격률 ·', dict(collections.Counter(x['maxim'] for x in items)))
    print('  섞은 뒤 정답 자리 ·', dict(sorted(collections.Counter(
        x['gold_pos'] for x in items).items())))
    print('  섞기 전 정답 자리 · {1: %d}  <- 이래서 섞는다' % len(items))
    k = load_kmi()
    if k:
        ki = kmi_strategy_items(k)
        print('KMI · 대화 %d · 뽑은 항목 %d' % (len(k), len(ki)))
        print('  라벨 ·', dict(collections.Counter(x['gold'] for x in ki)))


if __name__ == '__main__':
    summary()
