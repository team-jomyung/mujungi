# -*- coding: utf-8 -*-
"""GraphRAG 가 왜 낮았는가. 단계를 하나씩 떼어 본다.

    python graph_diag.py --stage link      개체 연결만 (링커 넷 비교)
    python graph_diag.py --stage arms      E4-O · E4-K · E5 실제 과제
    python graph_diag.py --stage truncate  프롬프트에 실제로 들어갔는가

왜 단계를 떼나
  E4 가 낮다고 "그래프가 쓸모없다" 고 적으면 틀린 결론을 남긴다.
  파이프라인이 넷이다 · **연결 → 확장 → 꺼내기 → 프롬프트 주입.**
  어디서 깨졌는지 모르면 고칠 데도 모른다.

  현재 측정 · 1홉 연결이 10/40 = 우연이다. 그 다음 단계들은 틀린 입구에서 출발한다.
  그래서 **입구를 정답으로 고정**하면 어떻게 되는지를 본다. 그것이 oracle 시험이다.

네 가지 링커
  EMB   물음글 임베딩 ↔ 어휘 정의 임베딩 (지금 쓰는 것)
  LLM   모델에게 격률을 물어 그 답으로 들어간다
  EXF   벡터로 닮은 보기를 찾고 그 보기가 달린 어휘로 들어간다 (example-first)
  ORACLE 정답 격률로 들어간다. 상한선이지 방법이 아니다

홉
  1홉 · 들어간 어휘와 그 정의
  2홉 · + 그 어휘에 달린 보기 + 형제 어휘
  3홉 · + 그 어휘를 정의하는 온톨로지 마디 + 형제의 보기

잘림 감사
  그래프에서 찾았는데 프롬프트에 안 들어갔으면 **쓴 것이 아니다.**
  찾은 마디와 실제로 실린 마디를 따로 센다.
"""
from __future__ import annotations

import argparse
import collections
import io
import json
import os
import sys
import time

import arms as A
import data as D
import kb as KB
import llm as L
import metrics as M

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.abspath(os.path.join(HERE, '..', 'results'))

MAX_CONTEXT_DOCS = 3          # E3/E4 와 같은 k. 같게 두지 않으면 비교가 안 된다
LINKERS = ('EMB', 'LLM', 'EXF', 'ORACLE')


# ── 링커 넷 ──────────────────────────────────────────────
def link_emb(g, query, **_):
    return [g.link(query)['vocab']]


def link_emb_topk(g, query, k=2, **_):
    """상위 k개. 임베딩 점수 순."""
    q = KB.embed_all([query])[0]
    sc = [(KB._cos(q, v), d['vocab']) for v, d in zip(g.vvecs, g.vocab)]
    sc.sort(key=lambda x: -x[0])
    return [v for _s, v in sc[:k]]


def link_llm(g, query, **_):
    """모델에게 직접 묻는다. 링커를 바꾸면 달라지는지 보려는 것."""
    p = ('다음 대화 상황이 어긴 대화 격률을 하나만 고르시오.%s%s%s%s'
         '보기: %s%s답:'
         % (chr(10), query[:300], chr(10), chr(10), ' / '.join(D.MAXIMS), chr(10)))
    try:
        r = L.generate(p, max_tokens=8, stop=[chr(10)])
    except L.LLMError:
        return [g.vocab[0]['vocab']]
    got = A.parse('maxim', r['text'])
    return [got if got in D.MAXIMS else g.vocab[0]['vocab']]


def link_example_first(g, query, vindex=None, **_):
    """벡터로 닮은 **보기**를 먼저 찾고, 그 보기가 달린 어휘로 들어간다.

    지금 링커는 물음글을 어휘 '정의' 와 견준다. 정의는 추상적이라 잘 안 붙는다.
    보기는 구체적이라 더 잘 붙을 수 있다. 그 가설을 시험한다."""
    for d in vindex.search(query, k=5):
        if d['kind'] == 'example':
            return [d['vocab']]
    return link_emb(g, query)


def link_oracle(g, query, item=None, **_):
    """정답으로 들어간다. **방법이 아니라 상한선이다.**"""
    return [item['maxim']]


LINK_FN = {'EMB': link_emb, 'LLM': link_llm, 'EXF': link_example_first,
           'ORACLE': link_oracle}


# ── 확장 ─────────────────────────────────────────────────
def expand(g, entries, hops=2, per_vocab=1):
    """들어간 어휘에서 홉만큼 뻗는다. 찾은 것을 순서대로 돌려준다.

    잘림을 재려면 **찾은 것 전부**를 알아야 한다. 자르는 것은 부르는 쪽이 한다."""
    found, seen = [], set()

    def add(d):
        if d and d['id'] not in seen:
            seen.add(d['id'])
            found.append(d)

    vmap = {d['vocab']: d for d in g.vocab}
    for v in entries:                      # 1홉 · 들어간 어휘 자신
        add(vmap.get(v))
    if hops >= 2:
        for v in entries:                  # 2홉 · 그 어휘의 보기 + 형제 어휘
            for d in g.ex.get(v, [])[:per_vocab]:
                add(d)
        for d in g.vocab:
            if d['vocab'] not in entries:
                add(d)
    if hops >= 3:
        for d in g.onto[:2]:               # 3홉 · 온톨로지 마디 + 형제의 보기
            add(d)
        for d in g.vocab:
            if d['vocab'] not in entries:
                for e in g.ex.get(d['vocab'], [])[:1]:
                    add(e)
    return found


def build_prompt(task, item, docs, k=MAX_CONTEXT_DOCS):
    """E3/E4 와 **같은 형식**으로 만든다. 다르면 비교가 안 된다."""
    used = docs[:k]
    spec = A.TASKS[task]
    body, ask = spec['q'](item)
    head = ('참고 자료' + chr(10)
            + chr(10).join('[%s] %s' % (d['id'], d['text']) for d in used)
            + chr(10) * 2)
    return head + body + chr(10) + ask + chr(10) + '답:', used


# ── 실행 ─────────────────────────────────────────────────
def run_link_stage(items, g, vindex, fh):
    """링커 넷의 개체 연결 정확도만 잰다. 과제는 안 돌린다."""
    rows = []
    for name in LINKERS:
        fn = LINK_FN[name]
        hit = 0
        t0 = time.time()
        for it in items:
            q = A.retrieval_key('implicature', it)
            got = fn(g, q, vindex=vindex, item=it)
            ok = it['maxim'] in got
            hit += ok
            rows.append({'kind': 'link', 'linker': name, 'item_id': it['id'],
                         'gold': it['maxim'], 'pred': got[0],
                         'topk': got, 'hit': bool(ok)})
            fh.write(json.dumps(rows[-1], ensure_ascii=False) + chr(10))
            fh.flush()
        print('  %-7s 정확도 %5.1f%% (%d/%d) · %5.1fs'
              % (name, 100 * hit / len(items), hit, len(items), time.time() - t0))
    # top-k recall
    for k in (2, 3):
        hit = sum(1 for it in items
                  if it['maxim'] in link_emb_topk(g, A.retrieval_key('implicature', it), k=k))
        print('  EMB@%d  재현율 %5.1f%% (%d/%d)' % (k, 100 * hit / len(items), hit, len(items)))
        for it in items:
            got = link_emb_topk(g, A.retrieval_key('implicature', it), k=k)
            fh.write(json.dumps({'kind': 'link', 'linker': 'EMB@%d' % k,
                                 'item_id': it['id'], 'gold': it['maxim'],
                                 'pred': got[0], 'topk': got,
                                 'hit': it['maxim'] in got}, ensure_ascii=False) + chr(10))
        fh.flush()
    return rows


ARMS_SPEC = [
    ('E4',    'EMB',    1, 2, '지금 구현 · 재현 확인용'),
    ('E4-O',  'ORACLE', 1, 2, '입구를 정답으로 고정 · 상한선'),
    ('E4-K2', 'EMB',    2, 2, '상위 2개로 들어간다'),
    ('E4-K3', 'EMB',    3, 2, '상위 3개로 들어간다'),
    ('E5',    'EXF',    1, 2, 'Vector→Graph 하이브리드'),
    ('E4-O-h1', 'ORACLE', 1, 1, '정답 입구 · 1홉만'),
    ('E4-O-h3', 'ORACLE', 1, 3, '정답 입구 · 3홉'),
]


def run_arms_stage(items, g, vindex, fh, task='implicature', only=None):
    out = {}
    for arm, linker, topk, hops, note in ARMS_SPEC:
        if only and arm not in only:
            continue
        rows = []
        t0 = time.time()
        for it in items:
            q = A.retrieval_key(task, it)
            if linker == 'EMB' and topk > 1:
                entries = link_emb_topk(g, q, k=topk)
            else:
                entries = LINK_FN[linker](g, q, vindex=vindex, item=it)
            found = expand(g, entries, hops=hops)
            prompt, used = build_prompt(task, it, found)
            try:
                r = L.generate(prompt, max_tokens=A.TASKS[task]['max_tokens'],
                               stop=[chr(10) * 2])
            except L.LLMError as e:
                print('    호출 실패 · %s/%s · %s' % (arm, it['id'], e))
                r = {'text': '', 'seconds': 0.0, 'prompt_tokens': 0, 'output_tokens': 0}
            pred = A.parse(task, r['text'])
            row = {
                'kind': 'arm', 'arm': arm, 'task': task, 'item_id': it['id'],
                'linker': linker, 'topk': topk, 'hops': hops,
                'entries': entries, 'entry_correct': it['maxim'] in entries,
                'gold': A.TASKS[task] and (str(it['gold_pos']) if task == 'implicature'
                                           else it['maxim']),
                'pred': pred, 'raw': (r['text'] or '').strip()[:80],
                'found_nodes': [d['id'] for d in found],
                'used_nodes': [d['id'] for d in used],
                'truncated_nodes': [d['id'] for d in found[len(used):]],
                'seconds': r['seconds'], 'prompt_tokens': r['prompt_tokens'],
                'output_tokens': r.get('output_tokens', 0),
            }
            rows.append(row)
            fh.write(json.dumps(row, ensure_ascii=False) + chr(10))
            fh.flush()
        sc = M.score(rows, A.TASKS[task]['labels'])
        ec = sum(1 for r in rows if r['entry_correct']) / len(rows)
        tr = sum(len(r['truncated_nodes']) for r in rows) / len(rows)
        out[arm] = sc
        print('  %-9s 정확도 %.3f · 입구정답 %.0f%% · 잘린마디 %.1f개 · %5.1fs · %s'
              % (arm, sc['accuracy'], 100 * ec, tr, time.time() - t0, note))
    return out


def main(argv):
    ap = argparse.ArgumentParser()
    ap.add_argument('--stage', default='all',
                    choices=('link', 'arms', 'truncate', 'all'))
    ap.add_argument('--arms', default='')
    ap.add_argument('--per-maxim', type=int, default=10)
    a = ap.parse_args(argv)

    if not L.alive():
        print('ollama 가 없다')
        return 2
    items = D.load_kpt()
    tr, te = D.split_kpt(items)
    te = D.subsample(te, a.per_maxim)
    docs = KB.build_docs(tr)
    vindex, g = KB.VectorIndex(docs), KB.Graph(docs)
    if not os.path.isdir(OUT):
        os.makedirs(OUT)

    print('GraphRAG 진단 · 시험 %d문항 · 창고 %d문서' % (len(te), len(docs)))
    print('  마디 · 어휘 %d · 온톨로지 %d · 보기 %d'
          % (len(g.vocab), len(g.onto), sum(len(v) for v in g.ex.values())))

    if a.stage in ('link', 'all'):
        print()
        print('1단계 · 개체 연결만 (과제 안 돌림)')
        with io.open(os.path.join(OUT, 'graph_link.jsonl'), 'w',
                     encoding='utf-8', newline=chr(10)) as fh:
            run_link_stage(te, g, vindex, fh)

    if a.stage in ('arms', 'all'):
        print()
        print('2단계 · 실제 과제')
        only = [x for x in a.arms.split(',') if x.strip()] or None
        with io.open(os.path.join(OUT, 'graph_arms.jsonl'),
                     'a' if only else 'w', encoding='utf-8', newline=chr(10)) as fh:
            run_arms_stage(te, g, vindex, fh, only=only)
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
