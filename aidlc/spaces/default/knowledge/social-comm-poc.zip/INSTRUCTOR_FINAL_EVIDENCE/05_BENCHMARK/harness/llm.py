# -*- coding: utf-8 -*-
"""로컬 모델 한 곳. 여기 말고는 모델을 부르지 않는다.

왜 로컬인가
  쓰는 평가셋이 라이선스가 없는 자료다(권리 유보). 내부 분석까지만 허용된다.
  외부 API 로 보내면 그 줄을 넘는다. ollama 는 이 컴퓨터를 안 떠난다.
  TalkBank 규칙의 "비보관 옵트아웃" 문제도 같이 사라진다.

되돌릴 수 있게
  seed · temperature · num_predict 를 고정하고 호출마다 기록한다.
  같은 입력에 같은 출력이 나오는지 run.py 가 확인한다.
"""
from __future__ import annotations

import json
import time
import urllib.error
import urllib.request

HOST = 'http://localhost:11434'
GEN_MODEL = 'exaone3.5:7.8b'
EMB_MODEL = 'bge-m3'
SEED = 20260915
NUM_CTX = 1024


class LLMError(RuntimeError):
    pass


def _post(path, payload, timeout=600):
    body = json.dumps(payload).encode('utf-8')
    req = urllib.request.Request(HOST + path, body, {'Content-Type': 'application/json'})
    try:
        return json.loads(urllib.request.urlopen(req, timeout=timeout).read().decode('utf-8'))
    except urllib.error.URLError as e:
        raise LLMError('ollama 에 못 붙는다 · %s · %s' % (HOST, e))


def alive():
    try:
        d = _post('/api/generate', {'model': GEN_MODEL, 'prompt': 'hi', 'stream': False,
                                    'options': {'num_predict': 1}}, timeout=120)
        return bool(d)
    except LLMError:
        return False


def generate(prompt, max_tokens=8, stop=None, model=GEN_MODEL, retries=2):
    """한 번 부른다. 실패하면 두 번까지 다시. 몇 초 걸렸는지 토큰 몇 개였는지 같이 준다."""
    # num_ctx 를 실제 쓰는 만큼만 연다. 기본 4096 이면 KV 캐시가 8.7GB 까지 커져
    # 메모리가 모자라 판이 죽는다. 실제로 두 번 죽었다.
    # 실측 최장 프롬프트가 500 토큰이라 1024 면 두 배 여유다.
    # **줄여도 답이 같은지 확인하고 쓴다.** 안 그러면 앞 결과와 못 섞는다.
    opts = {'temperature': 0, 'top_p': 1, 'seed': SEED, 'num_predict': max_tokens,
            'num_ctx': NUM_CTX}
    if stop:
        opts['stop'] = stop
    last = None
    for attempt in range(retries + 1):
        t0 = time.time()
        try:
            d = _post('/api/generate', {'model': model, 'prompt': prompt,
                                        'stream': False, 'options': opts})
        except LLMError as e:
            last = e
            time.sleep(1.5 * (attempt + 1))
            continue
        return {
            'text': d.get('response', ''),
            'seconds': round(time.time() - t0, 3),
            'prompt_tokens': d.get('prompt_eval_count', 0),
            'output_tokens': d.get('eval_count', 0),
            'attempt': attempt + 1,
        }
    raise LLMError('%d번 시도했는데 다 실패했다 · %s' % (retries + 1, last))


def embed(texts, model=EMB_MODEL, keep_alive='30s'):
    """임베딩 모델을 오래 물고 있지 않는다.

    생성 모델이 5.4GB 다. 임베딩 모델까지 같이 올라가 있으면 메모리가 모자라
    운영체제가 판을 죽인다. 실제로 그렇게 한 번 죽었다(E3 18/40 에서).
    색인은 처음 한 번뿐이니 30초 뒤 내려도 된다."""
    d = _post('/api/embed', {'model': model, 'input': list(texts),
                             'keep_alive': keep_alive})
    v = d.get('embeddings')
    if not v:
        raise LLMError('임베딩이 비어 있다 · %s' % model)
    return v


def manifest():
    return {'host': HOST, 'gen_model': GEN_MODEL, 'emb_model': EMB_MODEL,
            'seed': SEED, 'temperature': 0, 'top_p': 1}
