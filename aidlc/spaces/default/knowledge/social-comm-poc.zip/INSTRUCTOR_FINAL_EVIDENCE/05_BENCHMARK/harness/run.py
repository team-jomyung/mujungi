# -*- coding: utf-8 -*-
"""E0~E4 를 실제로 돌린다.

    python run.py                          전부
    python run.py --tasks implicature      하나만
    python run.py --limit 8 --out _smoke   짧게 시험

반드시 지키는 것
  1 돌리기 전에 leakage.py 를 통과해야 한다. 안 되면 **시작하지 않는다.**
  2 한 줄 나올 때마다 파일에 쓴다. 중간에 끊겨도 거기까지는 남는다.
  3 다섯 갈래가 같은 항목 · 같은 모델 · 같은 seed · 같은 출력 형식을 쓴다.
  4 형식 실패를 버리지 않는다. 세어서 같이 보고한다.
  5 다 돌린 뒤 몇 개를 다시 불러 같은 답이 나오는지 본다.

안 돌아가면
  ollama 가 없으면 NOT_EXECUTED 로 적고 끝낸다. 가짜 숫자를 만들지 않는다.
"""
from __future__ import annotations

import argparse
import collections
import io
import json
import os
import sys
import time

import arms as A
import data as D
import kb as KB
import leakage as LK
import llm as L
import metrics as M

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.abspath(os.path.join(HERE, '..', 'results'))


LOCK_STALE = 300          # 5분 넘게 안 뛰면 죽은 것으로 본다


def lock_path(out):
    return os.path.join(out, '.run.lock')


def take_lock(out, force=False):
    """두 판이 같은 파일에 쓰지 못하게 막는다.

    실제로 그 일이 났다. TaskStop 이 껍데기 셸만 죽이고 python 자식은 살아남아서,
    새 판이 파일을 비우고 쓰는 동안 옛 판이 자기 위치에 계속 썼다.
    결과 파일에 널 바이트가 박히고 E0 10줄 · E2 6줄 같은 뒤섞인 상태가 나왔다.

    잠금은 심장박동을 적는다. 죽은 잠금은 5분 뒤 자동으로 풀린다."""
    p = lock_path(out)
    if os.path.exists(p) and not force:
        try:
            d = json.load(io.open(p, encoding='utf-8'))
            age = time.time() - d.get('beat', 0)
        except (ValueError, OSError):
            age = LOCK_STALE + 1
        if age < LOCK_STALE:
            print('**다른 판이 돌고 있다.** pid %s · %.0f초 전에 뛰었다'
                  % (d.get('pid'), age))
            print('  정말 지우려면 · --force · 또는 그 프로세스를 먼저 죽인다')
            return False
        print('  (죽은 잠금을 푼다 · %.0f초 전)' % age)
    beat(out)
    return True


def beat(out):
    io.open(lock_path(out), 'w', encoding='utf-8', newline=chr(10)).write(
        json.dumps({'pid': os.getpid(), 'beat': time.time()}) + chr(10))


def drop_lock(out):
    try:
        os.remove(lock_path(out))
    except OSError:
        pass


def gold_of(task, it):
    if task == 'implicature':
        return str(it['gold_pos'])
    if task == 'maxim':
        return it['maxim']
    return it['gold']


def run_cell(arm, task, items, vi, g, k, fh):
    rows = []
    for it in items:
        prompt = A.build_prompt(arm, task, it, vindex=vi, graph=g, k=k)
        try:
            r = L.generate(prompt, max_tokens=A.TASKS[task]['max_tokens'],
                           stop=[chr(10) * 2])
        except L.LLMError as e:
            print('    호출 실패 · %s/%s/%s · %s' % (task, arm, it['id'], e))
            r = {'text': '', 'seconds': 0.0, 'prompt_tokens': 0,
                 'output_tokens': 0, 'attempt': 0}
        pred = A.parse(task, r['text'])
        row = {
            'task': task, 'arm': arm, 'item_id': it['id'],
            'gold': gold_of(task, it), 'pred': pred,
            'raw': r['text'].strip()[:120],
            'seconds': r['seconds'], 'prompt_tokens': r['prompt_tokens'],
            'output_tokens': r['output_tokens'], 'attempt': r['attempt'],
            'prompt_chars': len(prompt),
        }
        if task == 'implicature':
            row['roles'] = it['roles']
        elif task == 'maxim':
            row['maxim'] = it['maxim']
        rows.append(row)
        fh.write(json.dumps(row, ensure_ascii=False) + chr(10))
        fh.flush()
    return rows


def repro_check(arm, task, items, vi, g, k, prev):
    """같은 것을 다시 불러 같은 답이 나오는가. 두 개만 본다."""
    by = {r['item_id']: r for r in prev}
    same = 0
    checked = items[:2]
    for it in checked:
        p = A.build_prompt(arm, task, it, vindex=vi, graph=g, k=k)
        try:
            r = L.generate(p, max_tokens=A.TASKS[task]['max_tokens'], stop=[chr(10) * 2])
        except L.LLMError:
            return None
        if A.parse(task, r['text']) == by[it['id']]['pred']:
            same += 1
    return '%d/%d' % (same, len(checked))


def main(argv):
    ap = argparse.ArgumentParser()
    ap.add_argument('--tasks', default='implicature,maxim')
    ap.add_argument('--arms', default=','.join(A.ARMS))
    ap.add_argument('--limit', type=int, default=0)
    ap.add_argument('--k', type=int, default=3)
    ap.add_argument('--test-per-maxim', type=int, default=0)
    ap.add_argument('--out', default=OUT)
    ap.add_argument('--kmi-per-label', type=int, default=6)
    ap.add_argument('--force', action='store_true')
    ap.add_argument('--resume', action='store_true',
                    help='이미 다 돌린 칸은 건너뛴다. 중간에 죽었을 때')
    ap.add_argument('--append', action='store_true',
                    help='기존 결과에 덧붙인다. 통제 갈래를 나중에 돌릴 때')
    a = ap.parse_args(argv)

    tasks = [t for t in a.tasks.split(',') if t.strip()]
    armlist = [x for x in a.arms.split(',') if x.strip()]
    if not os.path.isdir(a.out):
        os.makedirs(a.out)

    if not take_lock(a.out, a.force):
        return 2

    if not L.alive():
        io.open(os.path.join(a.out, 'NOT_EXECUTED.md'), 'w', encoding='utf-8',
                newline='\n').write(
            '# NOT_EXECUTED\n\nollama 에 붙지 못했다. 실험을 돌리지 않았다.\n'
            '가짜 결과를 대신 넣지 않는다.\n\n확인 · `ollama serve` · `ollama list`\n'
            '필요한 것 · %s · %s\n' % (L.GEN_MODEL, L.EMB_MODEL))
        print('ollama 가 없다 · NOT_EXECUTED.md 를 적고 끝낸다')
        return 2

    items = D.load_kpt()
    train, test = D.split_kpt(items)
    docs = KB.build_docs(train)
    vi, g = KB.VectorIndex(docs), KB.Graph(docs)

    bad = LK.check(train, test, docs, LK.build_prompts(test, docs, vi, g))
    if bad:
        print('**새는 곳이 있다. 실험을 시작하지 않는다.**')
        for b in bad[:10]:
            print('  %s' % b)
        return 2
    print('누출 검사 통과 · 시험 %d · 창고 %d' % (len(test), len(docs)))

    test = D.subsample(test, a.test_per_maxim)
    pool = {'implicature': test, 'maxim': test}
    if 'strategy' in tasks:
        pool['strategy'] = D.kmi_strategy_items(D.load_kmi(), per_label=a.kmi_per_label)
    if a.limit:
        pool = {k2: v[:a.limit] for k2, v in pool.items()}

    # 정답 자리가 실제로 고른가. **쓰는 집합에서** 잰다.
    # 앞 판은 120 전체에서만 확인하고 넘어갔다가 실제 시험 40 에서 35% 였다.
    pc = collections.Counter(x['gold_pos'] for x in test)
    base = max(pc.values()) / len(test) if test else 0
    per_maxim = {}
    for m in D.MAXIMS:
        c = collections.Counter(x['gold_pos'] for x in test if x['maxim'] == m)
        if c:
            per_maxim[m] = round(max(c.values()) / sum(c.values()), 4)
    print('정답 자리 분포 · %s · 다수 자리 기준선 %.3f' % (dict(sorted(pc.items())), base))
    if base > 0.26:
        print('**정답 자리가 치우쳤다. 우연 기준선이 %.3f 다. 시작하지 않는다.**' % base)
        return 2

    manifest = {
        'started': time.strftime('%Y-%m-%d %H:%M'),
        'majority_position_baseline': round(base, 4),
        'majority_position_baseline_per_maxim': per_maxim,
        'gold_position_counts': dict(sorted(pc.items())),
        'llm': L.manifest(), 'k': a.k,
        'split': {'train': len(train), 'test': len(test), 'test_per_maxim': a.test_per_maxim,
                  'split_seed': D.SPLIT_SEED, 'shuffle_seed': D.SHUFFLE_SEED},
        'kb': KB.stats(docs),
        'tasks': {t: len(pool[t]) for t in tasks},
        'arms': armlist,
        'chance_baseline': {'implicature': 0.25, 'maxim': 0.25,
                            'strategy': round(1 / len(A.STRATEGIES), 4)},
        'note': ('로컬 모델만 쓴다. 평가셋이 권리 유보라 밖으로 안 보낸다. '
                 '집계 숫자만 남기고 원문 예시는 보고서에 싣지 않는다'),
    }

    jl = os.path.join(a.out, 'raw_predictions.jsonl')

    done_cells = set()
    if a.resume and os.path.exists(jl):
        # 다 돌린 칸만 남기고 반쯤 돌린 칸은 버린다.
        # 반쯤 돌린 칸을 남기면 40문항짜리와 18문항짜리를 나란히 놓게 된다.
        keep, seen = [], {}
        for x in io.open(jl, encoding='utf-8'):
            x = x.strip()
            if not x:
                continue
            try:
                r = json.loads(x)
            except ValueError:
                continue
            seen.setdefault((r['task'], r['arm']), []).append((x, r))
        for (t, arm), rs in seen.items():
            if len(rs) == len(pool.get(t, [])):
                done_cells.add((t, arm))
                keep += [x for x, _r in rs]
        io.open(jl, 'w', encoding='utf-8', newline=chr(10)).write(
            chr(10).join(keep) + (chr(10) if keep else ''))
        print('이어 돌린다 · 살린 칸 %d · 버린 칸 %d'
              % (len(done_cells), len(seen) - len(done_cells)))
        for t, arm in sorted(done_cells):
            print('    살림 %s/%s' % (t, arm))
        a.append = True

    t0 = time.time()
    allrows = collections.defaultdict(list)
    total = sum(len(pool[t]) for t in tasks) * len(armlist) - sum(
        len(pool[t]) for t, _a in done_cells if t in pool)
    done = 0
    with io.open(jl, 'a' if a.append else 'w', encoding='utf-8',
                 newline=chr(10)) as fh:
        for task in tasks:
            for arm in armlist:
                if (task, arm) in done_cells:
                    continue
                s = time.time()
                beat(a.out)
                rows = run_cell(arm, task, pool[task], vi, g, a.k, fh)
                allrows[(task, arm)] = rows
                done += len(rows)
                sc = M.score(rows, A.TASKS[task]['labels'])
                print('  %-12s %-3s  정확도 %.3f · macroF1 %.3f · 형식실패 %d · %5.1fs  [%d/%d]'
                      % (task, arm, sc['accuracy'], sc['macro_f1'], sc['invalid_n'],
                         time.time() - s, done, total))

    manifest['finished'] = time.strftime('%Y-%m-%d %H:%M')
    manifest['total_seconds'] = round(time.time() - t0, 1)
    manifest['repro'] = {}
    for task in tasks:
        for arm in armlist[:2]:
            # **이번 판에서 실제로 돌린 칸만** 다시 불러 본다.
            # 이어 돌리기로 건너뛴 칸은 allrows 에 없다. 그걸 찾으면 KeyError 다.
            # 실제로 그렇게 죽었다 · 400개를 다 돌려 놓고 마지막 줄에서.
            rs = allrows.get((task, arm))
            if not rs:
                manifest['repro']['%s/%s' % (task, arm)] = 'SKIPPED_RESUMED'
                continue
            manifest['repro']['%s/%s' % (task, arm)] = repro_check(
                arm, task, pool[task], vi, g, a.k, rs)

    mname = 'manifest_append.json' if a.append else 'manifest.json'
    io.open(os.path.join(a.out, mname), 'w', encoding='utf-8',
            newline='\n').write(json.dumps(manifest, ensure_ascii=False, indent=2) + chr(10))
    print()
    print('끝 · %.1f분 · %s' % (manifest['total_seconds'] / 60, jl))
    print('재현 확인 ·', manifest['repro'])
    drop_lock(a.out)
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
