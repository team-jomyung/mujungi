# -*- coding: utf-8 -*-
"""시험 항목이 어디로든 새지 않았는가. **실험 전에 돌린다.**

    python leakage.py

보는 것
  1 훈련 몫과 시험 몫이 겹치는가 (id)
  2 시험 항목 글이 지식창고 문서에 들어 있는가
  3 시험 항목의 정답 글이 창고에 들어 있는가
  4 시험 항목끼리 거의 같은 것이 있는가
  5 실제로 만들어진 프롬프트에 정답이 실려 나가는가  <- 가장 중요하다
  6 꺼내는 열쇠에 정답 칸이 섞였는가

5번을 따로 두는 이유
  1~4 가 다 통과해도 프롬프트 조립에서 실수 한 번이면 정답이 실려 나간다.
  창고를 검사하는 것과 **실제로 나가는 글**을 검사하는 것은 다르다.
  그래서 다섯 갈래 프롬프트를 전부 만들어서 본다.

심어 놓고 터지는지도 본다. 조용한 검사는 없는 것만 못하다.
"""
from __future__ import annotations

import re
import sys

import arms as A
import data as D
import kb as KB
import llm as L


def norm(t):
    return re.sub(r'\s+', '', t or '')


def shingles(t, n=12):
    s = norm(t)
    return {s[i:i + n] for i in range(0, max(1, len(s) - n + 1))}


def jaccard(a, b):
    return len(a & b) / len(a | b) if (a | b) else 0.0


def check(train, test, docs, prompts):
    bad = []

    ids_tr = {x['id'] for x in train}
    ids_te = {x['id'] for x in test}
    dup = ids_tr & ids_te
    if dup:
        bad.append('훈련과 시험이 겹친다 · %s' % sorted(dup)[:6])

    blob = norm(chr(10).join(d['text'] for d in docs))
    for x in test:
        if norm(x['statement']) and norm(x['statement']) in blob:
            bad.append('%s · 시험 발화가 창고에 있다' % x['id'])
        if norm(x['gold_text']) and norm(x['gold_text']) in blob:
            bad.append('%s · 시험 정답 글이 창고에 있다' % x['id'])

    sh = {x['id']: shingles(x['context'] + x['statement']) for x in test}
    ids = sorted(sh)
    for i, a in enumerate(ids):
        for b in ids[i + 1:]:
            j = jaccard(sh[a], sh[b])
            if j > 0.8:
                bad.append('시험 항목 %s 와 %s 가 거의 같다 (%.2f)' % (a, b, j))

    # 5 실제 프롬프트
    for key, p in prompts.items():
        np_ = norm(p['prompt'])
        it = p['item']
        # 참고 자료 토막만 본다. 문제 본문에 발화와 보기가 실리는 것은 당연하다.
        # 격률 이름 넷이 보기로 실리는 것도 당연하다. **새는 것은 이 항목 자신의 글**이
        # 참고 자료에 들어가 있는 경우다.
        ref = ''
        if '참고 자료' in p['prompt']:
            ref = p['prompt'].split('참고 자료', 1)[1].split(chr(10) * 2, 1)[0]
        nref = norm(ref)
        if p['task'] in ('implicature', 'maxim'):
            if norm(it['statement']) and norm(it['statement']) in nref:
                bad.append('%s · 참고 자료에 이 항목의 발화가 있다' % key)
            if norm(it.get('oeq_answer', '')) and norm(it['oeq_answer']) in nref:
                bad.append('%s · 참고 자료에 이 항목의 정답 풀이가 있다' % key)
        elif p['task'] == 'strategy':
            if norm(it['therapist']) and norm(it['therapist']) in nref:
                bad.append('%s · 참고 자료에 이 항목의 상담자 발화가 있다' % key)

    # 6 꺼내는 열쇠
    for x in test[:5]:
        k = A.retrieval_key('implicature', x)
        if norm(x['gold_text']) and norm(x['gold_text']) in norm(k):
            bad.append('%s · 꺼내는 열쇠에 정답 글이 들어 있다' % x['id'])
        if x['maxim'] in k:
            bad.append('%s · 꺼내는 열쇠에 정답 격률이 들어 있다' % x['id'])
    return bad


def build_prompts(test, docs, vi, g, n=6):
    out = {}
    for task in ('implicature', 'maxim'):
        for x in test[:n]:
            for arm in tuple(A.ARMS) + tuple(getattr(A, 'CONTROL_ARMS', ())):
                out['%s/%s/%s' % (task, arm, x['id'])] = {
                    'task': task, 'item': x,
                    'prompt': A.build_prompt(arm, task, x, vindex=vi, graph=g)}
    return out


def selftest(train, test, docs, vi, g):
    """일부러 새게 해 놓고 잡히는지 본다."""
    import copy
    cases = []

    # a 훈련에 시험 항목을 넣는다
    t2 = copy.deepcopy(train) + [copy.deepcopy(test[0])]
    cases.append(('훈련에 시험 항목', lambda: check(t2, test, docs, {})))

    # b 창고에 시험 항목 글을 넣는다
    d2 = list(docs) + [{'id': 'EX:LEAK', 'kind': 'example', 'vocab': 'quantity',
                        'text': test[0]['context'] + test[0]['statement']}]
    cases.append(('창고에 시험 발화', lambda: check(train, test, d2, {})))

    # c 창고에 시험 정답 글을 넣는다
    d3 = list(docs) + [{'id': 'EX:LEAK2', 'kind': 'example', 'vocab': 'quantity',
                        'text': '보기 · ' + test[0]['gold_text']}]
    cases.append(('창고에 시험 정답', lambda: check(train, test, d3, {})))

    # d 참고 자료에 이 항목의 발화를 넣는다
    p4 = {'x/E3/%s' % test[0]['id']: {
        'task': 'implicature', 'item': test[0],
        'prompt': ('참고 자료' + chr(10) + '[EX:X] ' + test[0]['statement']
                   + chr(10) * 2 + '무엇인가')}}
    cases.append(('참고 자료에 이 항목 발화', lambda: check(train, test, docs, p4)))

    # e 참고 자료에 이 항목의 정답 풀이를 넣는다
    p5 = {'y/E3/%s' % test[0]['id']: {
        'task': 'implicature', 'item': test[0],
        'prompt': ('참고 자료' + chr(10) + '[EX:Y] 뜻 ' + test[0]['oeq_answer']
                   + chr(10) * 2 + '무엇인가')}}
    cases.append(('참고 자료에 이 항목 정답 풀이', lambda: check(train, test, docs, p5)))

    # f 시험 항목을 복제한다
    t6 = list(test) + [dict(test[0], id='KPT999')]
    cases.append(('시험 항목 복제', lambda: check(train, t6, docs, {})))

    fired = 0
    for label, fn in cases:
        if fn():
            fired += 1
        else:
            print('    >>> "%s" 를 해도 안 터진다' % label)
    return fired, len(cases)


def main():
    items = D.load_kpt()
    train, test = D.split_kpt(items)
    docs = KB.build_docs(train)
    print('훈련 %d · 시험 %d · 창고 문서 %d' % (len(train), len(test), len(docs)))

    if not L.alive():
        print('ollama 가 안 떠 있다 · 검색기 없이 1~4 만 본다')
        vi = g = None
        prompts = {}
    else:
        vi, g = KB.VectorIndex(docs), KB.Graph(docs)
        prompts = build_prompts(test, docs, vi, g)
        print('실제 프롬프트 %d개를 만들어 본다' % len(prompts))

    bad = check(train, test, docs, prompts)
    print('  샌 곳 %d' % len(bad))
    for b in bad[:20]:
        print('      %s' % b)

    fired, total = selftest(train, test, docs, vi, g)
    print('  일부러 새게 한 %d개 중 %d개가 잡혔다' % (total, fired))
    if fired != total:
        return 1
    return 1 if bad else 0


if __name__ == '__main__':
    sys.exit(main())
