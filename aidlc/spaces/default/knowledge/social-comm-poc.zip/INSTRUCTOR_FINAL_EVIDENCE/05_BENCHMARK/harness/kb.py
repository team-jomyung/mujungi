# -*- coding: utf-8 -*-
"""지식창고 하나 · 꺼내는 방법 둘.

왜 창고를 하나로 두나
  E3 와 E4 가 서로 다른 자료를 보면 무엇 때문에 차이가 났는지 알 수 없다.
  **같은 문서 더미**에서 꺼내고 **꺼내는 방법만** 다르게 한다. 그래야 비교가 된다.

  E3 벡터 · 물음 글과 문서를 임베딩해 가까운 것 k개
  E4 그래프 · 물음 글 → 어휘 마디 연결(1홉) → 그 마디에서 뻗은 것들(2홉)

창고에 무엇이 들어가나
  1 온톨로지 정의 조각 (v0_3_freeze_candidate.yaml · 주석 지침)
  2 훈련 몫 40항목 (정답과 오답 구실까지)

  **시험 몫 80항목은 절대 안 넣는다.** leakage.py 가 매번 확인한다.

정답 칸을 꺼내는 열쇠로 쓰지 않는다
  시험 때 그 항목의 격률을 알 리 없다. 아는 척하면 새는 것이다.
  꺼낼 때 쓰는 것은 맥락과 발화 글자뿐이다.
"""
from __future__ import annotations

import io
import json
import math
import os
import re

import data as D
import llm as L

HERE = os.path.dirname(os.path.abspath(__file__))
ONTO = os.path.join(D.REPO, 'ontology', 'v0_3_freeze_candidate.yaml')
GUIDE = os.path.join(D.REPO, 'ontology', 'annotation_guideline_v0_1.md')
CACHE = os.path.join(HERE, '_emb_cache.json')

MAXIM_DEF = {
    'quantity': '양의 격률. 필요한 만큼만 말한다. 너무 적게 말하거나 너무 많이 말하면 어긴다',
    'quality': '질의 격률. 참이라고 믿는 것만 말한다. 과장 · 반어 · 빈말이 여기 걸린다',
    'relation': '관계의 격률. 지금 이야기에 맞는 말을 한다. 딴 이야기를 하면 어긴다',
    'manner': '방식의 격률. 또렷하고 짧게 말한다. 모호하거나 에두르면 어긴다',
}


# ── 문서 더미 ────────────────────────────────────────────
def _onto_chunks():
    """온톨로지에서 우리가 쓰는 판정과 어휘만 떼어 온다."""
    if not os.path.exists(ONTO):
        return []
    s = io.open(ONTO, encoding='utf-8').read()
    out, cur, name = [], [], None
    for ln in s.split(chr(10)):
        m = re.match(r'^  (sc_[A-Za-z]+|sco_[A-Za-z]+):\s*$', ln)
        if m:
            if name and cur:
                out.append((name, chr(10).join(cur).strip()))
            name, cur = m.group(1), []
        elif name:
            if re.match(r'^[A-Za-z_#]', ln):
                out.append((name, chr(10).join(cur).strip()))
                name, cur = None, []
            else:
                cur.append(ln)
    if name and cur:
        out.append((name, chr(10).join(cur).strip()))
    return [{'id': 'ONTO:' + n, 'kind': 'ontology', 'vocab': n,
             'text': n + chr(10) + t[:280]} for n, t in out if t]


def _maxim_docs():
    return [{'id': 'VOCAB:' + k, 'kind': 'vocabulary', 'vocab': k,
             'text': '격률 %s · %s' % (k, v)} for k, v in MAXIM_DEF.items()]


def _train_docs(train):
    out = []
    for x in train:
        # **자리 번호를 적지 않는다.** 번호는 우리가 섞어서 생긴 것이지 지식이 아니다.
        # 적어 두면 꺼내진 보기의 "정답 (4)" 가 시험 항목의 답으로 읽힐 수 있다.
        #
        # 짧게 줄인다. 이 모델은 CPU 로 돈다. 프롬프트 천 토큰이 80초다.
        # 보기 넷을 다 실으면 E3 가 항목당 65초가 된다. 실을 수 없다.
        # 대신 **적절한 읽기와 문자 그대로의 읽기를 나란히** 둔다. 그 대비가 요점이다.
        lit = next((t for t, r in zip(x['options'], x['roles']) if r == 'literal'), '')
        out.append({
            'id': 'EX:' + x['id'], 'kind': 'example', 'vocab': x['maxim'],
            'text': ('맥락 %s%s발화 %s%s적절한 읽기 · %s%s문자 그대로 읽으면 · %s'
                     % (x['context'][:70], chr(10), x['statement'], chr(10),
                        x['oeq_answer'], chr(10), lit[:46])),
        })
    return out


def build_docs(train):
    return _maxim_docs() + _onto_chunks() + _train_docs(train)


# ── 임베딩 ───────────────────────────────────────────────
def _load_cache():
    if os.path.exists(CACHE):
        try:
            return json.load(io.open(CACHE, encoding='utf-8'))
        except ValueError:
            return {}
    return {}


def _save_cache(c):
    io.open(CACHE, 'w', encoding='utf-8', newline='\n').write(
        json.dumps(c, ensure_ascii=False))


def embed_all(texts):
    """한 번 뽑은 것은 다시 안 뽑는다. 되돌릴 수 있게 글 그대로를 열쇠로 쓴다."""
    cache = _load_cache()
    need = [t for t in texts if t not in cache]
    for i in range(0, len(need), 16):
        chunk = need[i:i + 16]
        for t, v in zip(chunk, L.embed(chunk)):
            cache[t] = v
    if need:
        _save_cache(cache)
    return [cache[t] for t in texts]


def _cos(a, b):
    n = sum(x * x for x in a) ** .5 * sum(y * y for y in b) ** .5
    return sum(x * y for x, y in zip(a, b)) / n if n else 0.0


class VectorIndex:
    """E3. 뜻이 가까운 문서를 꺼낸다."""

    def __init__(self, docs):
        self.docs = docs
        self.vecs = embed_all([d['text'] for d in docs])

    def search(self, query, k=4):
        q = embed_all([query])[0]
        scored = [(_cos(q, v), d) for v, d in zip(self.vecs, self.docs)]
        scored.sort(key=lambda x: -x[0])
        return [d for _s, d in scored[:k]]


class Graph:
    """E4. 어휘 마디에 걸고 거기서 뻗어 나간다.

    마디 · 어휘(격률 4) · 온톨로지 판정 · 보기(훈련 항목)
    간선 · 보기 --INSTANCE_OF--> 어휘 · 어휘 --DEFINED_BY--> 온톨로지 판정
           어휘 --SIBLING--> 다른 어휘

    꺼내는 법
      1홉 · 물음 글을 **어휘 정의**와만 견줘 가장 가까운 어휘 마디를 고른다
             (보기와 직접 견주지 않는다. 그건 E3 가 하는 일이다)
      2홉 · 그 어휘에 달린 보기 · 그 어휘를 정의하는 판정 · 형제 어휘 정의
      형제까지 넣는 이유는 고를 값들을 다 보여 줘야 고를 수 있어서다.
    """

    def __init__(self, docs):
        self.docs = docs
        self.vocab = [d for d in docs if d['kind'] == 'vocabulary']
        self.onto = [d for d in docs if d['kind'] == 'ontology']
        self.ex = {}
        for d in docs:
            if d['kind'] == 'example':
                self.ex.setdefault(d['vocab'], []).append(d)
        self.vvecs = embed_all([d['text'] for d in self.vocab])

    def link(self, query):
        q = embed_all([query])[0]
        scored = [(_cos(q, v), d) for v, d in zip(self.vvecs, self.vocab)]
        scored.sort(key=lambda x: -x[0])
        return scored[0][1]

    def search(self, query, k=4, per_vocab=1):
        hit = self.link(query)
        out = [hit]
        for d in self.ex.get(hit['vocab'], [])[:per_vocab]:
            out.append(d)
        for d in self.vocab:                      # 형제 어휘 · 고를 값을 다 보여 준다
            if d['id'] != hit['id']:
                out.append(d)
        for d in self.onto[:1]:                   # 판정 하나 · 무엇을 주장하는지
            out.append(d)
        return out[:max(k, 4)]


def stats(docs):
    import collections
    return dict(collections.Counter(d['kind'] for d in docs))


if __name__ == '__main__':
    items = D.load_kpt()
    train, test = D.split_kpt(items)
    docs = build_docs(train)
    print('문서 %d ·' % len(docs), stats(docs))
    if not L.alive():
        raise SystemExit('ollama 가 안 떠 있다')
    vi, g = VectorIndex(docs), Graph(docs)
    q = test[0]['context'] + ' ' + test[0]['statement']
    print()
    print('물음 · %s' % q[:70])
    print('E3 벡터 ·', [d['id'] for d in vi.search(q)])
    print('E4 그래프 ·', [d['id'] for d in g.search(q)])
    print('  1홉 어휘 · %s (실제 격률 %s)' % (g.link(q)['vocab'], test[0]['maxim']))
