# -*- coding: utf-8 -*-
"""무엇을 주장할 수 있고 무엇은 못 하는가. 한 줄씩 등급을 붙인다.

    python build_claims.py

여섯 등급
  VALIDATED    사람이 붙인 gold 로 숫자를 냈다
  SUPPORTED    근거가 있다. 다만 우리가 직접 잰 것은 아니다
  DEMONSTRATED 만들어 보였다. 정확도는 말하지 않는다
  DESIGNED     설계했고 코드가 돈다. 결과는 아직 없다
  NOT TESTED   안 해 봤다
  FUTURE WORK  이번 범위 밖이다

왜 이 표가 중요한가
  발표에서 한 문장이라도 등급보다 세게 말하면 그 자리에서 무너진다.
  **여기 없는 주장은 하지 않는다.** 특히 치료 효과는 어떤 등급도 주지 않는다.
"""
from __future__ import annotations

import csv
import io
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, '05_BENCHMARK', 'results', 'raw_predictions.jsonl')

LEVELS = ('VALIDATED', 'SUPPORTED', 'DEMONSTRATED', 'DESIGNED',
          'NOT TESTED', 'FUTURE WORK')


def ran_benchmark():
    if not os.path.exists(RES):
        return 0
    n = 0
    for x in io.open(RES, encoding='utf-8'):
        if x.strip():
            n += 1
    return n


CLAIMS = [
    # (주장, 등급, 근거, 조건)
    ('한국어 화용 문항 120개 중 시험 몫에서 시스템이 사람 정답을 맞히는 비율을 잰다',
     'VALIDATED', '06_ABLATION/results.csv · 사람이 쓴 gold · 우연 기준선 25%',
     '문항 40개뿐이고 문항 작성 일치도가 논문에 없다'),
    ('틀릴 때 문자 그대로 읽어서 틀리는 비율을 따로 낸다',
     'VALIDATED', '자료가 오답마다 구실을 표시한다 (literal / wrong-in / wrong-out)',
     '이 구분은 이 자료에만 있다. 다른 자료로 옮길 수 없다'),
    ('격률 4분류를 맞히는 정확도를 낸다',
     'VALIDATED', '격률별 30문항 균형 · PhenomenonAttribution',
     '격률과 우리 기술의 연결은 우리 해석이다. 자료가 준 것이 아니다'),
    ('Ontology 를 프롬프트에 넣으면 함축 해석 성적이 달라진다',
     'VALIDATED' if ran_benchmark() else 'DESIGNED',
     '06_ABLATION/ERROR_ANALYSIS.md · E0 0.475 → E1 0.650 · McNemar p=0.039',
     '달라진다는 것까지만이다. **왜 달라졌는지는 아래 항목 참조.** '
     '격률 과제에서는 같은 처리가 유의하지 않았다'),
    ('구조화한 온톨로지(JSON)가 프롬프트 글보다 낫다',
     'NOT TESTED',
     '반대 방향 · E1 0.650 → E2 0.475 (함축) · 격률에서는 유의차 없음',
     '**이 주장을 하지 않는다.** 함축에서는 오히려 나빠졌다'),
    ('Ontology 를 넣어 좋아진 것이 **온톨로지 내용 때문이다**',
     'NOT TESTED',
     '길이 통제 E1F · E0 0.475 → E1F(무관한 정의문) 0.550 → E1(온톨로지) 0.650',
     '**향상의 43%가 길이만으로 재현된다.** 상관없는 문서편집 규칙을 같은 길이로 넣어도 '
     '올랐다. 내용 기여와 길이 기여를 지금 설계로 가르지 못한다'),
    ('격률 판정(PhenomenonAttribution)을 이 시스템이 해낸다',
     'NOT TESTED',
     '없음 · E0 0.250 은 우연 기준선과 같고 가장 나은 갈래도 0.375 다',
     '**이 과제는 지금 안 된다.** 직접 검증 가능한 필드라는 것과 '
     '실제로 잘한다는 것은 다르다'),
    ('Vector RAG 와 Graph 검색을 같은 창고 · 같은 문항으로 비교한다',
     'VALIDATED' if ran_benchmark() else 'DESIGNED',
     'E3 vs E4 · 지식창고가 같고 꺼내는 방법만 다르다',
     '그래프가 작다. 어휘 4마디 + 판정 18 + 보기 40이다'),
    ('GraphRAG 가 Vector RAG 보다 낫다',
     'NOT TESTED',
     '없음 · E3 0.575 → E4 0.475 (함축) · 0.350 → 0.275 (격률) · 둘 다 p>0.05',
     '**GraphRAG necessity NOT ESTABLISHED.** 다만 검색기 진단에서 E4 의 개체연결이 '
     '10/40 = 우연 수준이라, "그래프가 쓸모없다" 가 아니라 "이 구현의 연결이 안 된다" 로 '
     '읽어야 한다'),
    ('시험 문항이 훈련 몫 · 지식창고 · 프롬프트 어디에도 새지 않았다',
     'VALIDATED', '05_BENCHMARK/harness/leakage.py · 샌 곳 0 · 심은 결함 6/6 적발',
     '없음'),
    ('공개된 실제 한국어 대화를 Social Event 구조로 바꾼다',
     'DEMONSTRATED', '07_SOCIAL_EVENT/examples · KMI 12건 · CC BY 4.0',
     '전략 칸은 PROXY(기계 라벨) · 단서 칸은 규칙. 정확도를 말하지 않는다'),
    ('같은 사건에서 SAME_CONTEXT · NEAR · FAR 장면을 만든다',
     'DEMONSTRATED', 'POC_B_MANUAL_SANITY/generated_scenes.jsonl · 18장면',
     '사람이 손으로 썼다. 자동 생성기 성능이 아니다'),
    ('멀어질수록 원본과 어휘 겹침이 줄어든다',
     'VALIDATED', '08_SCENARIO/AUTO_CHECK_RESULTS.csv · 0.140 → 0.060 → 0.044',
     '겹침이 준다고 같은 능력을 요구한다는 뜻은 아니다'),
    ('생성 장면에 정답·메타정보가 새지 않았다',
     'VALIDATED', '08_SCENARIO/AUTO_CHECK_RESULTS.csv · 18/18 PASS',
     '기계가 세는 규칙 안에서만 그렇다'),
    ('생성 장면이 정말 같은 화용 능력을 요구한다',
     'NOT TESTED', '팀 블라인드 리뷰 진행 중 · [TEAM MANUAL RESULT PENDING]',
     '사람이 읽어야 아는 것이다. 기계가 대신 판정하지 않는다'),
    ('SCD 아동·ASD 아동에게 화용 문제가 있다',
     'SUPPORTED', '02_TARGET/TARGET_EVIDENCE_MATRIX.csv · 문제 근거 6/6',
     '문헌 근거다. 우리가 잰 것이 아니다'),
    ('SCD 집단을 대상으로 성능을 검증했다',
     'NOT TESTED', '없음 · 임상군 한국어 Human Gold 가 하나도 없다',
     '**이 주장을 하지 않는다.** 비임상 한국어로 잰 것을 SCD 검증이라 부르지 않는다'),
    ('제품 타겟을 SCD 13~25 로 확정했다',
     'NOT TESTED', '없음 · 02_TARGET/TARGET_DECISION.md 는 PROVISIONAL 로 둔다',
     'SCD 청년은 아홉 집단 중 benchmark 1/21 · 문제 근거 2/6 으로 가장 약하다'),
    ('관계·상황에 맞춘 조정(S2) 성능을 잰다',
     'NOT TESTED', '없음 · 한국어 gold 자료가 없다',
     'S2 는 DEMO_CORE 다. 생성과 시연까지만 한다'),
    ('사용자가 훈련 뒤 실제로 나아진다',
     'NOT TESTED', '없음',
     '사람 대상 연구를 하지 않았다. 시스템 성능과 사용자 효과는 다른 것이다'),
    ('개인화가 작동한다',
     'NOT TESTED', '없음 · 실제 사용자 사건을 하나도 받지 않았다',
     'Personal Social Event 는 설계만 있다'),
    ('SCD 치료·개선 효과가 있다',
     'FUTURE WORK', '없음',
     '**어떤 등급도 주지 않는다. 의료 효과를 주장하지 않는다**'),
    ('GoalAttribution · StrategyRecommendation 을 평가한다',
     'FUTURE WORK', '없음 · 규격 자체가 gold 없음을 적고 있다',
     '억지로 LLM 으로 정답을 만들어 채점하지 않는다'),
    ('운율·비언어를 다룬다',
     'FUTURE WORK', '없음 · 텍스트 매체 범위 밖',
     '음성·영상 제품이 되면 그때'),
]


def main():
    n = ran_benchmark()
    p = os.path.join(HERE, '11_CLAIMS', 'CLAIM_LEDGER.csv')
    d = os.path.dirname(p)
    if not os.path.isdir(d):
        os.makedirs(d)
    with io.open(p, 'w', encoding='utf-8-sig', newline='') as fh:
        w = csv.writer(fh)
        w.writerow(['claim', 'level', 'evidence', 'limitation'])
        for c, lv, ev, li in CLAIMS:
            assert lv in LEVELS, lv
            w.writerow([c, lv, ev, li])

    import collections
    cnt = collections.Counter(lv for _c, lv, _e, _l in CLAIMS)
    print('주장 %d개 · 실험 예측 %d줄' % (len(CLAIMS), n))
    for lv in LEVELS:
        print('  %-14s %d' % (lv, cnt[lv]))
    can = [c for c, lv, _e, _l in CLAIMS if lv in ('VALIDATED', 'SUPPORTED', 'DEMONSTRATED')]
    cant = [c for c, lv, _e, _l in CLAIMS if lv in ('NOT TESTED', 'FUTURE WORK')]
    print()
    print('할 수 있는 주장 %d · 못 하는 주장 %d' % (len(can), len(cant)))
    print('저장 · 11_CLAIMS/CLAIM_LEDGER.csv')
    return 0


if __name__ == '__main__':
    sys.exit(main())
