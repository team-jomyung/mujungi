# 접근을 어떻게 확인했나

자료마다 실제로 무엇을 보았는지 적는다. 논문에 있다는 것은 근거가 아니다.

| 자료 | 상태 | 본 것 | 주소 |
|---|---|---|---|
| CPLC (아동 화용언어 체크리스트) | ACCESS_NOT_VERIFIED | No distributor page identified this session or in census (GitHub search q=CPLC+pragmatic already returned 0 in prior cen | - |
| ETRI KEMDy20 | ACCESS_NOT_VERIFIED | My guessed distribution subdomain "nlp.etri.re.kr" failed DNS resolution (ENOTFOUND) from this session. Base domain "etr | https://nlp.etri.re.kr/category/?cate=6 |
| ProSem | ACCESS_NOT_VERIFIED | GitHub repo itself has no data (LICENSE+README only, confirmed). External Google Drive link (file "sentences_final.xlsx" | https://drive.google.com/open?id=1KQO4PiUuPztSgZiuAZKilawLPMMBpV32 |
| ToM-Diary | ACCESS_NOT_VERIFIED | No distributor URL exists in project records. I independently ran GitHub search 'ToM-Diary' -> 0 relevant repos (only un | - |
| AI Hub 감성 대화 말뭉치 (dataSetSn=86) | APPLICATION_REQUIRED | Confirmed directly: application/approval process, login required, domestic-only - same wording as 543/544/71305. | https://www.aihub.or.kr/aihubdata/data/view.do?dataSetSn=86 |
| AI Hub 공감형 대화 (dataSetSn=71305) | APPLICATION_REQUIRED | Confirmed directly: approval process, login required, domestic-only. Page itself lists the label taxonomy (listener beha | https://www.aihub.or.kr/aihubdata/data/view.do?dataSetSn=71305 |
| AI Hub 용도별 목적대화 (dataSetSn=544) | APPLICATION_REQUIRED | Confirmed directly this session (previously the census had not reopened this page): same approval-gated wording as 543 ( | https://www.aihub.or.kr/aihubdata/data/view.do?dataSetSn=544 |
| AI Hub 웰니스 대화 스크립트 (dataSetSn=267) | APPLICATION_REQUIRED | Confirmed directly - stricter than standard AI-Hub flow: requires 안심존(secure zone) access + IRB ethics approval + instit | https://www.aihub.or.kr/aihubdata/data/view.do?dataSetSn=267 |
| AI Hub 자폐 관련 데이터 | APPLICATION_REQUIRED | AI-Hub site search for "자폐" surfaces only "소아청소년 정신질환 진단 안저 이미지 데이터" (dataSetSn=71516, fundus images) and "소아 뇌파 검사 데이터" | https://www.aihub.or.kr/aihubdata/data/view.do?dataSetSn=71516 |
| AI Hub 주제별 텍스트 일상 대화 (dataSetSn=543) | APPLICATION_REQUIRED | Confirmed directly: "데이터셋 다운로드 승인이 완료 된 후 API 다운로드 서비스를 이용하실 수 있습니다" - approval gate before any download; "내국인만 데이터 신청이  | https://www.aihub.or.kr/aihubdata/data/view.do?dataSetSn=543 |
| CANDOR | APPLICATION_REQUIRED | No license/terms visible before registering — only "(c) 2022 BetterUp. All rights reserved." Pure request-gate: form ask | https://betterup-data-requests.herokuapp.com/ |
| ItaASD | APPLICATION_REQUIRED | Page states raw data (recordings, transcriptions, clinical information) "is not available" due to Italian privacy policy | https://dspace-clarin-it.ilc.cnr.it/handle/20.500.11752/OPEN-990 |
| LDC2022S14 (Third DIHARD Challenge Evaluation) | APPLICATION_REQUIRED | "Login for the applicable fee" gate for both Members and Non-Members; requires at minimum the "LDC User Agreement for No | https://catalog.ldc.upenn.edu/LDC2022S14 |
| SANACS (ELRA-S0491) | APPLICATION_REQUIRED | No download button — only "add to cart"/order. Price: "0.00 €" for both academic members and non-members under "Non Comm | https://catalogue.elra.info/en-us/repository/browse/ELRA-S0491/ |
| TalkBank (전체 · Ground Rules) | APPLICATION_REQUIRED | Not a single dataset — platform-wide umbrella. Ground Rules names AphasiaBank/DementiaBank/FluencyBank/RHDBank/TBIBank a | https://talkbank.org/0share/rules.html ; https://talkbank.org/asd/acce |
| 국립국어원 맥락 추론 말뭉치 | APPLICATION_REQUIRED | Same NIKL gated process (application -> admin approve/reject -> signed DUA -> download), confirmed this session. Team al | https://kli.korean.go.kr/corpus/main/requestMain.do |
| 국립국어원 일상 대화 음성 말뭉치 | APPLICATION_REQUIRED | Corpus request page describes: application with usage justification -> "신청 사항은 관리자의 검토를 거쳐 승인 또는 반려될 수 있습니다" (administra | https://kli.korean.go.kr/corpus/main/requestMain.do |
| 협력적 대화 요약 말뭉치 2025 | APPLICATION_REQUIRED | Confirmed listed by exact name on NIKL's corpus request catalog. Same gated process as other NIKL corpora: application+j | https://kli.korean.go.kr/corpus/main/requestMain.do |
| K-MIND (Korean Multimodal INteraction Data) | NO | Repo root contains only README.md (46 bytes, entire content is the single line "# Korean Multimodal INteraction Data (K- | https://api.github.com/repos/AIRC-KETI/K-MIND/contents |
| KOPLAC (한국 아동 메타-화용언어 검사) | NO | Journal article page only. Example test items appear as figure IMAGES in Appendix 1 (not a distributable data file). Too | http://e-csd.org/journal/view.php?doi=10.12963/csd.18467 |
| 서울대 · 가천대 ASD 아동 음성 코퍼스 | NO | No distributor site exists (census already established: zero public/release/available/request statements anywhere in the | - |
| 한국어 간접 화행 평가셋 (ReDi · ReCo · ReEx) | NO | Full paper text states: "The test set is publicly available on our GitHub repository at https://github.com/annonymous/". | https://arxiv.org/html/2502.10995 |
| ASDBank | YES_AFTER_FREE_REGISTRATION | asd/ homepage: "click the green Login button...to set up your TalkBank account" required for ASD materials. access.html  | https://talkbank.org/asd/access.html ; https://talkbank.org/asd/ |
| ASDBank · Flusberg | YES_AFTER_FREE_REGISTRATION | Landing page shows a "Download transcripts" zip link, no password text on the page itself; same site-wide TalkBank login | https://talkbank.org/asd/access/English/Flusberg.html |
| ASDBank · Rollins | YES_AFTER_FREE_REGISTRATION | Landing page shows a "Download transcripts" link (href /data/asd/English/Rollins?f=zip) with no password text on the pag | https://talkbank.org/asd/access/English/Rollins.html |
| Playlogue | YES_AFTER_FREE_REGISTRATION | Gated:auto — page requires agreeing to share contact info and to "read and agree to the CHILDES ground rules for data us | https://huggingface.co/datasets/playlogue/playlogue-v1 |
| 3i4K | YES_DIRECT | GitHub API listing confirms data/fci.txt (2,956,116 bytes) + data/train_val_test/ present in public repo, no login. LICE | https://api.github.com/repos/warnikchow/3i4k/contents/data |
| AMI Meeting Corpus | YES_DIRECT | Direct links confirmed, no login/account mentioned: "AMI manual annotations v1.6.2" (22MB), "AMI automatic annotations v | https://groups.inf.ed.ac.uk/ami/download/ |
| AnnoMI | YES_DIRECT | AnnoMI-full.csv and AnnoMI-simple.csv confirmed present in the repo root alongside README.md. No LICENSE file found (rig | https://github.com/uccollab/AnnoMI |
| CHILDES Clinical-Eng (벌크) | YES_DIRECT | Index page (no login indicated) states: "Click here to download a 67 MB .zip file of all the Clinical-Eng transcripts" a | https://talkbank.org/childes/access/Clinical-Eng/ |
| CHILDES Eng-NA (벌크) | YES_DIRECT | Index page (no login indicated) states: "Click here to download a 95 MB .zip file of all the Eng-NA transcripts" at href | https://talkbank.org/childes/access/Eng-NA/ |
| CHILDES Eng-NA · NewEngland | YES_DIRECT | Confirmed as a listed entry inside the open Eng-NA index (same page/link as the bulk zip; did not open a NewEngland-spec | https://talkbank.org/childes/access/Eng-NA/ |
| CHILDES Korean · Jiwon | YES_DIRECT | Confirmed directly: transcripts browsable + downloadable zip, no login. Media explicitly marked "no longer available" (a | https://talkbank.org/childes/access/EastAsian/Korean/Jiwon.html |
| CHILDES Korean · Ko | YES_DIRECT | Page offers "Download transcripts" (CHAT zip) + "Link to media folder" (media.talkbank.org); no login/password mentioned | https://talkbank.org/childes/access/EastAsian/Korean/Ko.html |
| CHILDES Korean · Ryu | YES_DIRECT | Confirmed directly: browsable transcripts + zip download + media folder link, no login mentioned. 81hr15min longitudinal | https://talkbank.org/childes/access/EastAsian/Korean/Ryu.html |
| GitHub CHAT 미러 (jamsawamsa/Autism_SLI_textAnalyzer_NLP_ML) | YES_DIRECT | xml/ and plain_text/ folders confirmed present, each with asd/, sli/, typ/ subdirectories, packaged as .7z archives. No  | https://github.com/jamsawamsa/Autism_SLI_textAnalyzer_NLP_ML |
| ICSI Meeting Corpus | YES_DIRECT | Direct links confirmed, no login mentioned: "ICSI core annotations v1.0" (19MB, "transcripts plus dialogue act coding"), | https://groups.inf.ed.ac.uk/ami/icsi/download |
| KMI (Korean Motivational Interviewing) | YES_DIRECT | Public GitHub repo, no login: kmi.json (6,101,005 bytes) present at root. LICENSE = CC BY 4.0 (342 bytes plain-language  | https://api.github.com/repos/hjkim811/KMI/contents |
| KoCoSa | YES_DIRECT | HF datasets-server API returns real rows with columns context/response/label/sarcasm_explanation, no login. GitHub repo  | https://datasets-server.huggingface.co/rows?dataset=YuminKim/KoCoSa&co |
| ParaKQC | YES_DIRECT | data/paraKQC_v1.txt (704,972 bytes) directly present in public repo, no login. CC-BY-SA-4.0 LICENSE confirmed. | https://api.github.com/repos/warnikchow/paraKQC/contents/data |
| SAE4K | YES_DIRECT | Public GitHub repo (warnikchow/sae4k), no login. data/sae4k_v1.txt (2,545,926 bytes) + sae4k_v2.txt (4,756,575 bytes) pr | https://api.github.com/repos/warnikchow/sae4k/contents/data |
| SBCSAE (Santa Barbara Corpus) | YES_DIRECT | Page links directly to SBCorpus.zip and metadata.zip (linguistics.ucsb.edu/sites/default/files/sitefiles/research/SBC/)  | https://www.linguistics.ucsb.edu/research/santa-barbara-corpus-spoken- |
| SwDA (Switchboard Dialog Act Corpus) | YES_DIRECT | swda.zip confirmed present in the repo root, containing turn/utterance-level dialog-act tags plus Penn Treebank parses.  | https://github.com/cgpotts/swda |
| pragmaticsAggressionRedditConversations | YES_DIRECT | License tag cc-by-nc-4.0. Page states "Total file size: 2.87 MB" and "Downloads last month: 129," confirming files exist | https://huggingface.co/datasets/MARIANNE-INRIA/pragmaticsAggressionRed |
| testset_v0 (프로젝트 자체 평정) | YES_DIRECT | 실측 · clean_pairs 40 · boundary_candidates 20 · 평정자 5인 전원 · 관계 부부20/친구16/직장동료4 | testset/testset_v0.json |
| ugurcanvurgun/ASD_CHILDES | YES_DIRECT | MIT license tag shown (conflicts with upstream TalkBank CC BY-NC-SA per prior census — a reuploader's own tag does not o | https://huggingface.co/datasets/ugurcanvurgun/ASD_CHILDES |
| 공공데이터포털 언어치료 데이터 | YES_DIRECT | Search confirms census finding exactly: every result is a municipal registry of speech-therapy/developmental-rehab FACIL | https://www.data.go.kr/tcs/dss/selectDataSetList.do?keyword=%EC%96%B8% |
| 한국어 화용 평가셋 | YES_DIRECT | No URL anywhere in project records (license_source_url blank; repo address lost). I independently ran GitHub search '그라이 | - |

## 조사끼리 어긋난 곳

### 한국어 화용 평가셋

census-ko 는 ACCESS_NOT_VERIFIED 로 두었다. GitHub 검색으로 못 찾았다. gold-provenance 가 REST API 로 저장소를 찾아 1차 자료까지 확인했다. **검색으로 못 찾은 것이 없는 것은 아니다.**

### testset_v0 (프로젝트 자체 평정)

target-evidence 가 이 자료를 benchmark 후보로 지목했다. 확인해 보니 사람 평정은 맞지만 외부 benchmark 가 아니고 만장일치 선별 때문에 일치도를 다시 잴 수 없다. B 로 둔다
