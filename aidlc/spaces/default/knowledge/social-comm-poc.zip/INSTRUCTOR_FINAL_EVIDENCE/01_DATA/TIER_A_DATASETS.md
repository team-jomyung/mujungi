# 지금 실제로 쓸 수 있는 자료

조사한 자료 **47개** (국외 20 · 국내 27). 여기에 우리가 만든 평정 세트 1개를 따로 센다 (**합치지 않는다**).

| 등급 | 개수 | 뜻 |
|---|---|---|
| A | 1 | 지금 접근 + 사람이 붙인 gold + 라벨 정의 + **우리 필드를 직접 잰다** |
| B | 9 | 접근은 되는데 gold·언어·구조 중 하나가 모자라 proxy 로만 |
| C | 30 | 문제 근거로는 쓰지만 benchmark 로는 못 쓴다 |
| D | 8 | 지금 못 가져온다 |

## TIER A · 1개

### 한국어 화용 평가셋

- 우리 필드 · **InterpretationAttribution · PhenomenonAttribution**
- 라벨 · 그라이스 격률 4종 + 함축 해석 4지선다 (보기 구실까지 표시)
- 누가 붙였나 · 언어학 석사 4인이 직접 작성
- 일치도 · **없음** · 문항 작성 단계의 일치도를 논문이 보고하지 않는다
- 라이선스 · 없음 · 권리 유보 (RESERVED)
- 확인 · Park et al. PACLIC 38 (2024) · arXiv 2403.12675 · github.com/DojunPark/pragmatic_eval_korean · 2026-09-15 live 확인 license=null. 배포 CSV 는 정답이 늘 (1) 이다. 논문은 채점할 때 보기 순서를 돌렸다고 명시한다. 섞지 않고 쓰면 무의미한 숫자가 나온다

## A 가 하나뿐인 이유

넷째 조건 때문이다. 앞 판에서는 셋만 봤더니 A 가 13개 나왔다.
영어 화행 말뭉치도 A 가 되었다. 우리 제품은 한국어다.
한국어 시스템을 영어 자료로 재면 그 시스템을 잰 것이 아니다.

그래서 A 는 **우리 온톨로지 필드를 한국어로 직접 재는 것**만 남겼다.

## TIER B · 9개 · proxy 로 쓴다

| 자료 | 우리 필드 | 왜 proxy 인가 |
|---|---|---|
| ASDBank · Rollins | ActAttribution | ActAttribution 에 붙지만 proxy 다 (PROXY_VALIDATABLE) |
| AnnoMI | StrategyAttribution | StrategyAttribution 에 붙지만 proxy 다 (PROXY_VALIDATABLE) |
| CHILDES Eng-NA · NewEngland | ActAttribution | ActAttribution 에 붙지만 proxy 다 (PROXY_VALIDATABLE) |
| SwDA (Switchboard Dialog Act Corpus) | ActAttribution | ActAttribution 에 붙지만 proxy 다 (PROXY_VALIDATABLE) |
| 3i4K | ActAttribution | ActAttribution 에 붙지만 proxy 다 (PROXY_VALIDATABLE) |
| KMI (Korean Motivational Interviewing) | CueObservation · StrategyAttribution | 라벨이 사람 것이 아니다. 다만 접근이 자유롭고 저작자 표시만 하면 발표에 예시를 실을 수 있는 **유일한** 한국어 다중턴 대화다. proxy 와 시연용으로 쓴다 |
| KoCoSa | PhenomenonAttribution | PhenomenonAttribution 에 붙지만 proxy 다 (PROXY_VALIDATABLE) |
| SAE4K | ActAttribution | ActAttribution 에 붙지만 proxy 다 (PROXY_VALIDATABLE) |
| testset_v0 (프로젝트 자체 평정) | InterpretationAttribution | 사람 평정 · 한국어 · 맥락 있음. 다만 **외부 benchmark 가 아니라 우리가 만든 것**이고, 만장일치만 골라 남겨 쉬운 집합이며(정규 4.78 대 적대 1.07), 원자료 약정이 미확인 |

## 접근 상태

| 상태 | 개수 |
|---|---|
| YES_DIRECT | 22 |
| APPLICATION_REQUIRED | 14 |
| YES_AFTER_FREE_REGISTRATION | 4 |
| ACCESS_NOT_VERIFIED | 4 |
| NO | 4 |

**URL 이 있다고 접근 가능으로 세지 않았다.**
실제 파일 목록이나 다운로드 페이지를 본 것만 YES 로 두었고,
못 본 것은 ACCESS_NOT_VERIFIED 로 남겼다.
