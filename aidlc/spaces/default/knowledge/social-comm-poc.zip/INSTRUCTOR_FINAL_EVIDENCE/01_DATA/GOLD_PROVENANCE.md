# Gold-label provenance check: KMI and 한국어 화용 평가셋

Verification date 2026-09-15. Local files checked directly (`experiments/kmi.json`, `experiments/kmi_LICENSE.txt`, `experiments/korean_pragmatics_testset.csv`) and re-counted independently with a script, not just read from prior notes. Primary-source search used WebSearch (exhausted before this task — 200/200 used session-wide), `gh` CLI (GitHub API, authenticated), HuggingFace datasets API, arXiv API, Semantic Scholar API (rate-limited, 429, throughout), and WebFetch on Bing/DuckDuckGo (both returned CAPTCHA pages, no results).

**Update:** my own search for Dataset 2's source (log retained below) failed. Teammate `KoreanTools` independently located both the repo and the paper via the GitHub REST API and reported them back with quotes. Rather than relay that secondhand, I downloaded the arXiv PDF myself, extracted its text, and queried the GitHub repo's contents/license via `gh api` directly (2026-09-15) to re-verify every claim against the primary source before writing it up. Everything in the Dataset 2 section below is now primary-source verified by me — the section has been rewritten accordingly and supersedes the original UNKNOWN verdict.

---

## Dataset 1: KMI (Korean Motivational Interviewing)

**VERDICT: MACHINE_GENERATED — dialogue text and the 8 strategy labels alike. Not human-annotated in any sense. Do not call this "Human Gold."**

### Official source (verified)

- Paper: Kim, Hyunjong; Lee, Suyeon; Cho, Yeongjae; Ryu, Eunseo; Jo, Yohan; Seong, Suran; Cho, Sungzoon. **"KMI: A Dataset of Korean Motivational Interviewing Dialogues for Psychotherapy."** NAACL 2025. https://aclanthology.org/2025.naacl-long.541/ (PDF: https://aclanthology.org/2025.naacl-long.541.pdf)
- Repository: https://github.com/hjkim811/KMI (author account `hjkim811` = Hyunjong Kim, first author; matches the local `LICENSE` file's copyright holder)
- I downloaded the ACL Anthology PDF and extracted its text (26 pages, `pypdf`) to quote directly rather than relying on secondary summaries.

### 1. Human-written or LLM-generated dialogues?

LLM-generated, both sides. From the abstract: "we present KMI, the first synthetic dataset theoretically grounded in MI" (11 words, Kim et al. 2025, abstract). Both the therapist simulator and client simulator are LLM prompted: "For both simulators, we utilize GPT-4 API for high-quality generation" (10 words, §3.2.1), specifically **gpt-4-0125-preview** (paper footnote 4). No dialogue turn is human-written.

### 2. Were the 8 MI labels assigned by humans or a model — and is the label an annotation or a generation condition?

**It is a generation condition, not an annotation.** The paper states the pipeline explicitly: label is predicted *before* the utterance is written, then the utterance is generated to match it — "first predicting the next-turn therapist behavior via MI forecaster ... then generating the utterance" (13 words, §3.2.1). The "MI forecaster" that predicts the label is itself a machine model, not a person: a **fine-tuned T5-base model**, trained on a converted/translated version of the English AnnoMI dataset (§3.2.1, "MI Forecaster" paragraph). So both the label and the text it labels are machine output — the label was never observed in already-written human or model text and then classified; it was chosen first and the text was written to fit it.

### 3. Human validation/verification — how much, and of what?

Sample-based expert evaluation, not full-dataset annotation or filtering. Two separate sub-studies, both drawing samples from the 1,000-dialogue / 9,558-labeled-turn dataset, not reviewing all of it:

- **Dialogue/label quality (Likert):** "We recruited four Korean psychological counseling experts experienced in MI" (10 words, §4.2), certified by the Korean Psychological Association, paid 50,000 KRW/hour (Ethics Statement). They rated **100 of the 1,000 dialogues** (a 10% sample) on 6 MI-quality + 3 general-quality criteria, 1–5 Likert, median by majority vote.
- **Label accuracy (True/False):** "We randomly sample 30 utterances for each MI label ... a total of 210 utterances" (14 words, §4.2, "MI Label Accuracy"), footnote: **"Other is excluded"** (3 words) — i.e. only 7 of the 8 labels were checked; the "Other"/"General" label (776–779 turns, ~8% of labeled turns) was never human-validated at all. Result: "with an average accuracy of 96.0%" (6 words), ranging 90.0% (Give Information) to 100.0% (Open Question) per-label (Table 4).
- No claim anywhere in the paper of full-dataset human review, filtering, or correction. The Ethics Statement is explicit that source posts were collected without interaction and the dataset was not otherwise vetted: "we web-crawl posts from a Korean psychological counseling platform Mindcafe" (10 words, §3.1); "We collected only publicly available data and there was no interaction with the Mindcafe users" (Ethics Statement).

**Conclusion on labels:** even setting aside that the label is a generation condition rather than an annotation, the closest thing to "verification" the paper offers is a 210-utterance sample (2.4% of the 8,779 non-Other labeled turns) checked by 4 experts at 96.0% agreement — not a full audit, and it explicitly excludes one of the eight label values.

### 4. License

Confirmed both locally and against the live GitHub repo — identical text: **Creative Commons Attribution 4.0 International (CC BY 4.0)**, "Copyright (c) Hyunjong Kim." Fetched `https://raw.githubusercontent.com/hjkim811/KMI/main/LICENSE` directly on 2026-09-15; matches `experiments/kmi_LICENSE.txt` byte-for-byte in content. This is the dataset's own repo license, separate from (and not contradicted by) the paper's ACL Anthology copyright badge.

### Independent recount (not just re-reading prior notes)

I parsed `experiments/kmi.json` myself:

```
dialogues 1000, turns 18116, Therapist 9558, Client 8558
Open Question 3305, Complex Reflection 3055, Simple Reflection 1269,
Affirm 914, General 776, Closed Question 109, Give Information 87, Advise 43
(sum = 9558, self-consistent)
```

This matches the team-lead brief's numbers exactly. **It does not match the paper's own Table 2**, which reports (I extracted this directly from the PDF): Simple Reflection 1,269 / Complex Reflection 3,055 / **Open Question 2,305** / Closed Question 109 / Affirm 914 / Give Information 87 / Advise 43 / **Other 779** — summing to **8,561**, not 9,558. The file is internally self-consistent (sums to the stated 9,558 therapist turns); the paper table is not (off by 997, concentrated almost entirely in the Open Question row: 2,305 vs. the file's 3,305, a difference of exactly 1,000 — reads like a transcription/typo in the published table). **Use the file's measured distribution, not the paper's Table 2, in any report** — and if Table 2 is cited at all, flag the discrepancy.

### What remains unverified

- Whether the "MI forecaster" T5 model's predictions were spot-checked against the AnnoMI source labels beyond the cross-validation figures in the paper (Appendix C) — not needed for the Human Gold question, not chased further.
- The relationship between Mindcafe's own platform terms and the paper's "publicly available data" framing — paper doesn't address it; out of scope here.

---

## Dataset 2: 한국어 화용 평가셋 (Korean pragmatics / Gricean-maxim evaluation set, 120 items)

**VERDICT: HUMAN_ANNOTATED — the 120 items were written by human experts, not an LLM. Confirmed against the primary source (paper text I extracted myself + GitHub repo I queried myself today). No inter-annotator agreement is reported for the item-writing step itself, which is a real gap, but authorship is not in doubt.**

### Official source (verified)

- Paper: Park, Dojun; Lee, Jiwoo; Jeong, Hyeyun; Park, Seohyun; Lee, Sungeun. **"Pragmatic Competence Evaluation of Large Language Models for the Korean Language."** 38th Pacific Asia Conference on Language, Information and Computation (PACLIC 38), 2024. https://arxiv.org/abs/2403.12675 (v1 2024-03-19, v2 2024-10-17)
- Repository: https://github.com/DojunPark/pragmatic_eval_korean — self-cited in the paper's own abstract: "The test set is publicly available on our GitHub repository at https://github." + the full URL (confirmed by grepping my own PDF text extraction, lines 33–34).
- I downloaded the arXiv PDF myself and extracted its text (11 pages, `pypdf`), and queried `gh api repos/DojunPark/pragmatic_eval_korean` and its `/contents` endpoint directly today (2026-09-15) — not relying on `KoreanTools`' quotes alone.

### 1. Who wrote the 120 items — linguists, crowdworkers, or an LLM?

**Human linguists, stated directly in the methodology section.** §3.1 "Constructing Pragmatic Test Set," bullet "Expert Collaboration": **"The test units were crafted by four experts holding master's degrees in linguistics"** (13 words, §3.1) "or related fields, ensuring high-quality and contextually rich scenarios" (full sentence, verified by my own PDF text extraction). This independently confirms what this project's own prior notes had already claimed (`research/L4_현재근거_기준선.md`, `ontology/v0_3_proposal.md` §6.2, `experiments/l4_matrix.py`: "언어학 석사 4인이 직접 작성" / "written directly by 4 linguistics MA holders") — those notes turn out to have been accurate, they just hadn't preserved the citation. Not confirmed: whether these four item-writing experts are among the paper's five listed authors or separately recruited — the paper doesn't say, and I don't treat this as material to the verdict.

### 2. Human validation / inter-annotator agreement?

**None reported for the 120 items themselves.** I read the full paper (methodology, results, and Limitations sections) and grepped it for "agreement," "kappa," "reliab," "ICC," "inter-rater," "pilot," "review," "verif" — no inter-annotator-agreement figure, second-pass review, or pilot-validation step is described for the item-construction process. The only other human-expert step in the paper is unrelated to validating the 120 items: for the *Open-Ended Questions*, "three independent assessors with qualifications matching those of the test set creators evaluate LLMs' narrative responses using a Likert scale from 1 to 5" (§3.2) — this scores **model outputs** on the OEQ half of the benchmark, not the correctness of the 120 source items, and no agreement value is reported for it either. The paper's own Limitations section (verified directly) frames the whole study as "a pilot" and flags small item count and single-language scope as the two things to improve — it does not flag validation/IAA as a gap, but neither does it report one.

### 3. License — checked live today, not from a stale note

**No license.** Queried `gh api repos/DojunPark/pragmatic_eval_korean` directly on 2026-09-15: `"license": null`, `"description": null`, `"homepage": null`, created 2024-03-04, last pushed 2024-10-02, 0 stars. `/contents` lists exactly two files — `README.md` and `korean_pragmatics_testset.csv` — no `LICENSE` file. This confirms and updates this project's own prior note (`experiments/DATA_LICENSE_NOTES.md`, dated 2026-09-10, "저장소에 고지 파일이 없다") with a same-day check against the live repo rather than a 5-day-old one. Treat as **RESERVED (all rights reserved)** per this project's own DATASET_CENSUS_KO.csv convention — internal analysis only, no redistribution, no example text in anything published, until the author (Dojun Park) confirms terms.

### 4. Does the paper acknowledge the always-option-1 pattern? Is raw accuracy meaningful?

Both things are true at once, and they're about two different artifacts — worth being precise:

- **The distributed CSV is fixed, by design, not by oversight.** §3.2: the four MCQ options are always ordered "the correct answer that accurately reflects the implicated meaning within the context, a naive literal interpretation, an incorrect interpretation within context, and an incorrect interpretation out of context" — i.e., 1=correct/2=literal/3=wrong-in-context/4=wrong-out-of-context, always in that order. Table 3's caption states plainly: "The answer (1) in bold is the correct answer." I independently re-confirmed this from the raw file myself today: `MCQ Answer` = `"1"` for all 120/120 rows, one single `MCQ Details` pattern across the whole file. **Anyone who runs a model against this CSV as distributed, without reshuffling, gets a meaningless number** — a model that always answers "1" scores 100%.
- **The paper's own reported scores are not subject to that artifact.** §4.1 "Performance Report," verified directly: "In the case of the MCQ tests, we varied the order of the provided options to mitigate potential bias towards any specific answer position." So GPT-4's reported 81.11 MCQ score (Table 5) was measured after rotating option order across three trials per item — the fixed 1=correct layout only exists in the static, distributed file, not in how the authors themselves scored models. This resolves what looked like a contradiction between this project's own prior secondhand note ("논문은 평가할 때 보기 순서를 바꿨다고 명시한다") and a separate teammate's read of the static file structure — both are correct, about different things.
- **Practical implication for us:** if this dataset is used for our own model evaluation, the raw CSV must be reshuffled before scoring, exactly as the original authors did — their published number is a legitimate comparison point only after we do the same.

### Reuse caveat and scope note (from `pragmatics-reviewer`'s review, after reading this section)

Two points added by a teammate reviewing this file, not independently re-verified by me beyond what's already established above, but both follow directly from it and are worth keeping attached to the finding rather than left in chat:

- **The static-file trap inflates scores silently.** If this CSV feeds any of our own evaluation code, the loader must randomize MCQ option order per item (with a fixed seed, for reproducibility) before scoring — not just "if we want to compare to the paper" but because a model with *any* positional bias will otherwise score above its true pragmatic competence. The error only inflates, never depresses, so it won't present as an obvious bug during development; it has to be prevented at the loader level, not caught by eyeballing results.
- **Scope: this is model-capability evidence, not population evidence.** The 120 items test general LLM handling of Gricean maxims, written by expert linguists with no clinical population involved anywhere in the pipeline (matches `pragmatics-reviewer`'s independent literature search: Crossref/CSD turned up nothing because this benchmark was never going to be indexed there — it's an NLP benchmark, not a clinical instrument). If this project's final report cites it near the ontology's SCD/MVP target population claims, it needs to stay clearly labeled as LLM-capability evidence — citing it as if it says something about the social-communication-disorder population would be a misuse of what the source actually measures.

**Checked after the caveat above was written: the reuse trap is already handled correctly in code.** `INSTRUCTOR_FINAL_EVIDENCE/05_BENCHMARK/harness/data.py`'s `load_kpt()` already does this, and does it more rigorously than a plain shuffle-with-seed would: it deterministically round-robins the gold position by item ID (`gold_pos = (ID-1) % 4 + 1`, so positions 1–4 each get exactly 30 items **across the full 120-item set** — an exact 25% "always guess X" baseline overall, not just an approximately-even one from random chance), then randomizes the other three options among themselves with a per-item seed (`SHUFFLE_SEED + ID`). Its own docstring independently documents the same always-option-1 problem this section describes, and the same RESERVED-license no-redistribution constraint from §3 above (it reads the CSV from its original location and keeps no copy in the harness package). Confirmed by reading the file directly on 2026-09-15 — no action needed, noted here so this caveat isn't mistaken for an open risk.

**Per-maxim wrinkle (only matters if per-maxim results are ever reported with a stated chance baseline):** the exact 25% holds only in aggregate. I recomputed this directly from the real CSV and the real formula rather than take the arithmetic on faith: `ID` runs in four contiguous 30-item blocks, one per maxim (quantity 1–30, quality 31–60, relation 61–90, manner 91–120), and since 30 isn't divisible by 4, each block's round-robin cycle lands unevenly — but *which* two positions get the extra item flips depending on where each block's starting ID falls in the cycle:

```
quantity (1–30):   pos 1→8  pos 2→8  pos 3→7  pos 4→7
quality  (31–60):  pos 1→7  pos 2→7  pos 3→8  pos 4→8
relation (61–90):  pos 1→8  pos 2→8  pos 3→7  pos 4→7
manner   (91–120): pos 1→7  pos 2→7  pos 3→8  pos 4→8
```

So a per-maxim "always guess position 1" baseline is 8/30 = 26.7% for quantity and relation, 7/30 = 23.3% for quality and manner — never a flat 25% within a single maxim, only in the 120-item aggregate (30/30/30/30, confirmed by summing the columns above). This changes no conclusion in this document; it only matters if the final report ever publishes a per-maxim breakdown next to a stated 25% chance floor for that maxim specifically, in which case use the real per-maxim floor above instead.

**This is not a code defect, and there is no fix to apply.** 30 items into 4 positions can never split evenly (30 = 4×7 + 2), so exactly two positions get 8 items and two get 7 in every 30-item block, regardless of where the round-robin cycle starts — shifting the start offset only moves *which* two positions carry the extra item, as the table above already shows happening naturally across the four blocks. The only ways to force an exact 7.5/7.5/7.5/7.5 would be dropping to 28 items per maxim (discarding real data for a cosmetic property) or an intentionally uneven, non-round-robin assignment (which would just trade this documented imbalance for an undocumented one). Documented per-maxim baselines, not a harness change, is the correct and final resolution — if a future reader sees the 8/8/7/7 split, this is confirmation it was checked and left alone on purpose, not an open item.

### One false alarm, resolved, and one small unresolved detail (neither material to the verdict)

- **Encoding — resolved, was a false alarm, not a real discrepancy.** `KoreanTools` initially reported the downloaded CSV as CP949/EUC-KR; I independently re-parsed this project's copy with `utf-8-sig` and it decoded cleanly, so I flagged it as an open "maybe two snapshots differ" question. `KoreanTools` then re-checked at the byte level and found the cause: the file is UTF-8 throughout (90,620 bytes, no BOM; `utf-8` and `utf-8-sig` both decode cleanly; `cp949` throws `UnicodeDecodeError` at byte position 95, i.e. it cannot be CP949 at all) — the mojibake they saw earlier was their own terminal/stdout rendering on Windows garbling already-correct output, not a file-encoding problem. There is one file, it is UTF-8, both of us were reading the same thing. No encoding caveat applies to anyone using this CSV.
- Whether the four item-writing experts overlap with the paper's five authors is not stated in the paper.

### What remains unverified

- Whether the four item-writing experts are native Korean speakers (near-certain given the content, but the paper doesn't say so explicitly in the text I extracted).
- Any agreement/reliability figure for the item-construction step — genuinely absent from the paper, not just unfound by me.
- Author confirmation of reuse/redistribution terms beyond "intended for researchers and practitioners" (README) — not sought as part of this check; recommend direct contact with Dojun Park before any external publication that reproduces example items, per this project's own existing RESERVED-rights convention.

### Superseded: my own search log (kept for the audit trail)

Before `KoreanTools` reported the repo, my own search failed to find it: WebSearch was already exhausted (200/200 session-wide) before I started; `gh search repos`/`gh search code` with ~15 query variants (`"화용"`, `"화용능력"`, `"그라이스"`, `"pragmatic competence" korean`, `"implicature" korean`, `"maxim violation"`, code search on `"Type of Maxim"`/`"MCQ Details"`/`"OEQ Answer"`, etc.) found nothing; HuggingFace datasets API returned empty; arXiv API and Semantic Scholar API were rate-limited (429) on most attempts and returned nothing relevant on the rest; Bing/DuckDuckGo via WebFetch both served CAPTCHA pages. This project's own prior audit (`FINAL_CLOSURE/01_EVIDENCE/DATASET_CENSUS_LOG.md` line 62) had independently hit the same dead end before this session. `KoreanTools` succeeded by going through the GitHub REST API directly rather than search, which is worth remembering for the next dataset with no indexed footprint.
