# -*- coding: utf-8 -*-
"""47개 조사 결과를 하나로 합치고 등급을 매긴다.

    python build_audit.py

합치는 것
  1 기존 census (FINAL_CLOSURE/01_EVIDENCE) · 이름 · 라이선스 · 규모
  2 이번 접근성 조사 (_raw_global_access.csv · _raw_ko_access.csv)
  3 출처 확인 (GOLD_PROVENANCE.md 의 판정) · **이것이 1·2 를 덮는다**

왜 3이 덮나
  접근성 조사는 "gold 파일이 있는가" 를 본다. 출처 확인은 "그 라벨을 사람이 붙였는가" 를 본다.
  KMI 가 그 차이다. 파일에 라벨이 9,558개 있지만 사람이 붙인 것이 아니다.
  라벨을 **생성 조건**으로 넣고 그 조건에 맞는 문장을 모델이 썼다. 그것은 주석이 아니다.

  파일이 있다고 Human Gold 가 아니다. 이 구분을 놓치면 등급이 통째로 틀린다.

등급
  A 지금 접근 가능 + 사람이 붙인 gold + 라벨 정의 확인 가능 + 우리 필드를 직접 잰다
  B 접근은 되는데 gold·구조·언어·대상 중 하나가 모자라 proxy 로만
  C 문제 근거로는 쓰지만 benchmark 로는 못 쓴다
  D 지금 프로젝트에서 못 쓴다

  **A 를 억지로 만들지 않는다. 0개면 0개라고 쓴다.**
"""
from __future__ import annotations

import csv
import io
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                '..', '03_ONTOLOGY'))
import mapping as MAP_ONT  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.abspath(os.path.join(HERE, '..', '..'))
EV = os.path.join(REPO, 'FINAL_CLOSURE', '01_EVIDENCE')
OUT = os.path.join(HERE, 'DATASET_EXECUTABILITY_AUDIT.csv')

# ── 출처 확인이 덮어쓰는 값 ────────────────────────────────
# GOLD_PROVENANCE.md 에서 1차 자료까지 확인한 것만 적는다.
PROVENANCE = {
    'KMI (Korean Motivational Interviewing)': {
        'downloadable_now': 'YES_DIRECT',
        'gold_provenance': 'MACHINE_GENERATED',
        'human_gold_exists': 'NO',
        'gold_file_actually_present': 'YES_BUT_MACHINE',
        'annotator_count': '검증만 전문가 4인 · 표본 210발화 · 정확도 96.0% · General 라벨은 미검증',
        'agreement_reported': '없음 (표본 정확도만)',
        'provenance_note': ('Kim et al. NAACL 2025. 대화는 GPT-4 생성, 라벨은 T5 forecaster 가 '
                            '**먼저 정하고** 그 라벨에 맞게 발화를 생성했다. 주석이 아니라 생성 조건이다. '
                            '파일 실측 Open Question 3305 vs 논문 Table 2 는 2305 · 1000 차이'),
        'license': 'CC BY 4.0',
        'tier': 'B',
        'tier_why': ('라벨이 사람 것이 아니다. 다만 접근이 자유롭고 저작자 표시만 하면 '
                     '발표에 예시를 실을 수 있는 **유일한** 한국어 다중턴 대화다. '
                     'proxy 와 시연용으로 쓴다'),
    },
    '한국어 화용 평가셋': {
        'downloadable_now': 'YES_DIRECT',
        'gold_provenance': 'HUMAN_ANNOTATED',
        'human_gold_exists': 'YES',
        'gold_file_actually_present': 'YES',
        'label_type': '그라이스 격률 4종 + 함축 해석 4지선다 (보기 구실까지 표시)',
        'annotator_count': '언어학 석사 4인이 직접 작성',
        'agreement_reported': '**없음** · 문항 작성 단계의 일치도를 논문이 보고하지 않는다',
        'context_available': 'YES',
        'natural_conversation': 'NO',
        'multi_turn': 'NO',
        'provenance_note': ('Park et al. PACLIC 38 (2024) · arXiv 2403.12675 · '
                            'github.com/DojunPark/pragmatic_eval_korean · 2026-09-15 live 확인 license=null. '
                            '배포 CSV 는 정답이 늘 (1) 이다. 논문은 채점할 때 보기 순서를 돌렸다고 명시한다. '
                            '섞지 않고 쓰면 무의미한 숫자가 나온다'),
        'license': '없음 · 권리 유보 (RESERVED)',
        'tier': 'A',
        'tier_why': ('사람이 쓴 문항 + 정답 + 오답 구실까지 있다. 우리 '
                     'InterpretationAttribution 과 PhenomenonAttribution 을 직접 잰다. '
                     '다만 라이선스가 없어 **재배포 불가 · 발표에 원문 예시 불가**, '
                     '문항 일치도도 없다. 120문항뿐이다'),
    },
}

# census 47 에 없는 것. **47 에 합치지 않고 따로 센다.**
EXTRA = [{
    'scope': 'OWN', 'name': 'testset_v0 (프로젝트 자체 평정)',
    'owner': '이 프로젝트', 'size': '40 + 20', 'unit': '해석 쌍',
    'license': '국립국어원 말뭉치 파생 · 이용 약정 확인 필요',
    'redistribution': 'UNDETERMINED (약정 확인 필요)',
    'model_training': 'UNDETERMINED',
    'downloadable_now': 'YES_DIRECT',
    'evidence_url': 'testset/testset_v0.json',
    'evidence_note': ('실측 · clean_pairs 40 · boundary_candidates 20 · '
                      '평정자 5인 전원 · 관계 부부20/친구16/직장동료4'),
    'human_gold_exists': 'YES', 'gold_file_actually_present': 'YES',
    'gold_provenance': 'HUMAN_ANNOTATED',
    'label_type': '정규 해석 대 적대 해석 · 5인 평정 (1~5)',
    'annotator_count': '5인',
    'agreement_reported': ('**이 집합에서는 못 잰다** · 5인 만장일치인 것만 '
                           '골라 남긴 집합이라 일치도가 구성상 100% 다'),
    'natural_conversation': 'YES', 'multi_turn': 'YES', 'context_available': 'YES',
    'language': 'ko', 'population': '비임상 (말뭉치 화자)',
    'tier': 'B', 'tier_source': 'MANUAL',
    'tier_why': ('사람 평정 · 한국어 · 맥락 있음. 다만 **외부 benchmark 가 아니라 '
                 '우리가 만든 것**이고, 만장일치만 골라 남겨 쉬운 집합이며(정규 4.78 대 '
                 '적대 1.07), 원자료 약정이 미확인이다. proxy 로 쓴다'),
    'provenance_note': ('기존 실측 · 유사도 판정기 AUC 약 0.58(적대 구분) 대 '
                        '0.86(관련성). 우리 핵심 부품이 어려운 축에서 우연에 가깝다는 '
                        '것을 우리가 이미 재서 알고 있다'),
    'reconciled_note': ('target-evidence 가 이 자료를 benchmark 후보로 지목했다. '
                        '확인해 보니 사람 평정은 맞지만 외부 benchmark 가 아니고 '
                        '만장일치 선별 때문에 일치도를 다시 잴 수 없다. B 로 둔다'),
}]

# census-ko 가 못 찾은 것을 출처 확인이 찾았다. 그 사실 자체를 남긴다
RECONCILED = {
    '한국어 화용 평가셋': ('census-ko 는 ACCESS_NOT_VERIFIED 로 두었다. GitHub 검색으로 못 찾았다. '
                    'gold-provenance 가 REST API 로 저장소를 찾아 1차 자료까지 확인했다. '
                    '**검색으로 못 찾은 것이 없는 것은 아니다.**'),
}


def load(path, keycol='name'):
    if not os.path.exists(path):
        return {}
    return {r[keycol].strip(): r
            for r in csv.DictReader(io.open(path, encoding='utf-8-sig', newline=''))}


def ontology_link(name):
    """이 자료가 우리 필드 중 무엇을 재는가. 03_ONTOLOGY/mapping.py 가 정본이다."""
    ms = MAP_ONT.MAP.get(name, [])
    if not ms:
        return '', 'NONE'
    order = {s: i for i, s in enumerate(MAP_ONT.STRENGTH)}
    best = sorted(ms, key=lambda m: order[m['strength']])[0]
    return ' · '.join(sorted({m['field'] for m in ms})), best['strength']


def tier_of(row):
    """규칙을 코드로 적는다. 손으로 매기면 다음에 또 달라진다.

    A 는 **네 가지를 다** 만족해야 한다. 앞 판은 넷째를 빼먹어서 13개가 A 로 나왔다.
      1 지금 접근 가능  2 사람이 붙인 gold  3 라벨 정의 확인  4 **우리 필드를 직접 잰다**
    넷째가 빠지면 영어 화행 말뭉치도 A 가 된다. 우리 제품은 한국어다."""
    dl = row.get('downloadable_now', '')
    gold = row.get('human_gold_exists', '')
    present = row.get('gold_file_actually_present', '')
    prov = row.get('gold_provenance', '')
    fields, strength = ontology_link(row['name'])

    if dl == 'NO' or dl == 'ACCESS_NOT_VERIFIED':
        return 'D', '지금 자료를 못 가져온다'
    if dl == 'APPLICATION_REQUIRED':
        return 'C', '신청·승인이 필요하다. 내일까지 못 쓴다'
    if strength == 'NONE':
        return 'C', '우리 온톨로지 필드에 붙는 자리가 없다. 문제 근거로만'
    if (gold == 'YES' and present == 'YES' and prov != 'MACHINE_GENERATED'
            and strength == 'DIRECTLY_VALIDATABLE'):
        return 'A', '접근 + 사람 gold + 라벨 정의 + %s 를 직접 잰다' % fields
    if strength in ('DIRECTLY_VALIDATABLE', 'PROXY_VALIDATABLE'):
        return 'B', '%s 에 붙지만 proxy 다 (%s)' % (fields, strength)
    return 'C', 'gold 가 없다. 시연까지만'


def main():
    gl = load(os.path.join(HERE, '_raw_global_access.csv'))
    ko = load(os.path.join(HERE, '_raw_ko_access.csv'))
    cg = load(os.path.join(EV, 'DATASET_CENSUS_GLOBAL.csv'))
    ck = load(os.path.join(EV, 'DATASET_CENSUS_KO.csv'))

    rows = []
    for scope, access, census in (('GLOBAL', gl, cg), ('KO', ko, ck)):
        for name, c in census.items():
            a = access.get(name, {})
            r = {
                'scope': scope, 'name': name,
                'owner': c.get('owner', ''),
                'size': c.get('size', ''), 'unit': c.get('unit', ''),
                'license': c.get('license', ''),
                'redistribution': c.get('redistribution', ''),
                'model_training': c.get('model_training', ''),
                'downloadable_now': a.get('downloadable_now', 'ACCESS_NOT_VERIFIED'),
                'evidence_url': a.get('evidence_url', ''),
                'evidence_note': a.get('evidence_note', '')[:300],
                'human_gold_exists': a.get('human_gold_exists', 'UNCLEAR'),
                'gold_file_actually_present': a.get('gold_file_actually_present', 'NOT_VERIFIED'),
                'gold_provenance': '',
                'label_type': a.get('label_type', ''),
                'annotator_count': a.get('annotator_count', ''),
                'agreement_reported': a.get('agreement_reported', ''),
                'natural_conversation': a.get('natural_conversation', ''),
                'multi_turn': a.get('multi_turn', ''),
                'context_available': a.get('context_available', ''),
                'language': a.get('language', 'ko' if scope == 'KO' else ''),
                'population': a.get('population', ''),
                'provenance_note': '', 'reconciled_note': RECONCILED.get(name, ''),
            }
            r['ontology_fields'], r['validation_strength'] = ontology_link(name)
            r.update(PROVENANCE.get(name, {}))
            if 'tier' in r:
                r['tier_source'] = 'PROVENANCE_OVERRIDE'
            else:
                t, why = tier_of(r)
                r['tier'], r['tier_why'], r['tier_source'] = t, why, 'RULE'
            rows.append(r)

    for x in EXTRA:
        x = dict(x)
        x['ontology_fields'], x['validation_strength'] = ontology_link(x['name'])
        rows.append(x)

    cols = ['scope', 'name', 'tier', 'tier_why', 'tier_source',
            'ontology_fields', 'validation_strength', 'downloadable_now',
            'human_gold_exists', 'gold_file_actually_present', 'gold_provenance',
            'label_type', 'annotator_count', 'agreement_reported',
            'natural_conversation', 'multi_turn', 'context_available',
            'language', 'population', 'license', 'redistribution', 'model_training',
            'owner', 'size', 'unit', 'evidence_url', 'evidence_note',
            'provenance_note', 'reconciled_note']
    with io.open(OUT, 'w', encoding='utf-8-sig', newline='') as fh:
        w = csv.DictWriter(fh, fieldnames=cols, extrasaction='ignore')
        w.writeheader()
        for r in sorted(rows, key=lambda x: (x['tier'], x['scope'], x['name'])):
            w.writerow(r)

    import collections
    print('census %d개 (GLOBAL %d · KO %d) + 자체 평정 %d개 = %d행'
          % (len(cg) + len(ck), len(cg), len(ck), len(EXTRA), len(rows)))
    print('  등급 ·', dict(sorted(collections.Counter(r['tier'] for r in rows).items())))
    print('  접근 ·', dict(collections.Counter(r['downloadable_now'] for r in rows)))
    print()
    for t in ('A', 'B'):
        sel = [r for r in rows if r['tier'] == t]
        print('TIER %s · %d개' % (t, len(sel)))
        for r in sel:
            print('  %-46s %s' % (r['name'][:46], r['tier_why'][:70]))
    print()
    print('저장 · %s' % os.path.basename(OUT))
    return 0


if __name__ == '__main__':
    sys.exit(main())
