# 라이선스 · 무엇을 해도 되고 무엇은 안 되나

**이 표가 발표 자료에 무엇을 실을 수 있는지 정한다.**

| 자료 | 라이선스 | 재배포 | 모델 학습 | 발표에 원문 |
|---|---|---|---|---|
| 3i4K | CC-BY-SA-4.0 | ALLOWED (동일조건변경허락) | ALLOWED (파생물에 동일 조건) | O |
| ASDBank · Rollins | CC BY-NC-SA 3.0 | FORBIDDEN | FORBIDDEN | X |
| AnnoMI | NOT STATED | RESERVED (권리 유보) | RESERVED (권리 유보) | O |
| CHILDES Eng-NA · NewEngland | CC BY-NC-SA 3.0 | FORBIDDEN | FORBIDDEN | X |
| KMI (Korean Motivational Interviewing) | CC BY 4.0 | ALLOWED (저작자 표시) | ALLOWED | O |
| KoCoSa | NOT STATED | RESERVED (권리 유보) | RESERVED (권리 유보) | O |
| SAE4K | NOT CHECKED (약관 페이지를 열지 않았다) | RESERVED (권리 유보 · 약관 미확인이라 막는 쪽으로  | RESERVED (미확인 · 막는 쪽) | O |
| SwDA (Switchboard Dialog Act Corpus) | GPL-2.0 (저장소) | ALLOWED (GPL-2.0 · 저장소 한정) | UNDETERMINED (원자료 Switchboard 의 LD | O |
| testset_v0 (프로젝트 자체 평정) | 국립국어원 말뭉치 파생 · 이용 약정 확인 필요 | UNDETERMINED (약정 확인 필요) | UNDETERMINED | O |
| 한국어 화용 평가셋 | 없음 · 권리 유보 (RESERVED) | RESERVED (권리 유보) | RESERVED (권리 유보) | X |

## 이번 실험이 지킨 것

- **로컬 모델만 썼다.** 권리 유보 자료를 외부 API 로 보내지 않았다.
  ollama 의 exaone3.5:7.8b · bge-m3 이고 이 컴퓨터를 안 떠났다.
- TalkBank 규칙의 "비보관 옵트아웃" 문제도 같이 없어졌다. 아예 안 보냈다.
- 권리 유보 자료의 **사본을 이 꾸러미에 두지 않았다.** 원래 자리에서 읽기만 한다.
- 보고서에 **원문 예시를 싣지 않는다.** 집계 숫자만 낸다.
- 발표에 예시를 실을 수 있는 것은 KMI (CC BY 4.0) 하나뿐이다. 저작자를 표시한다.
