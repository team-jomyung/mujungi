# 어느 필드를 무엇으로 검증하는가

강사님 질문 · **"그 데이터로 너희 시스템의 정확히 뭘 검증하는데?"**

| 상태 | 개수 | 필드 |
|---|---|---|
| DIRECTLY_VALIDATABLE | 2 | InterpretationAttribution · PhenomenonAttribution |
| PROXY_VALIDATABLE | 2 | ActAttribution · StrategyAttribution |
| DEMONSTRATION_ONLY | 1 | CueObservation |
| NOT_VALIDATABLE | 2 | GoalAttribution · StrategyRecommendation |

## 필드별

### ActAttribution · PROXY_VALIDATABLE

| 자료 | gold | 매핑 규칙 | 지표 | 강도 |
|---|---|---|---|---|
| 3i4K | 발화 유형 7분류 (담화성분) | sc_SpeechAct 의 원천 어휘로 MAPS_TO | accuracy · macro F1 | PROXY_VALIDATABLE |
| SAE4K | 질문 하위유형 6분류 | sc_SpeechAct 하위 행위명으로 MAPS_TO | accuracy | PROXY_VALIDATABLE |
| SwDA (Switchboard Dialog Act Corpus) | SWBD-DAMSL 대화행위 태그 | sc_SpeechAct 로 MAPS_TO | accuracy · macro F1 | PROXY_VALIDATABLE |
| ASDBank · Rollins | INCA-A 화행 코딩 (%spa) | sc_SpeechAct 로 MAPS_TO | accuracy | PROXY_VALIDATABLE |
| CHILDES Eng-NA · NewEngland | INCA-A %spa 2단 | sc_SpeechAct 로 MAPS_TO | accuracy | PROXY_VALIDATABLE |

- **3i4K** · **맥락이 없다.** 단일 발화다. 우리 ActAttribution 은 sco_SituatedUtterance 를 대상으로 하는데 그 자리가 비어 있다
- **SAE4K** · 맥락 없음 · 질문 유형만 다룬다
- **SwDA (Switchboard Dialog Act Corpus)** · 영어 · 전화 대화
- **ASDBank · Rollins** · 영어 · 임상군(AS 아동) · CC BY-NC-SA 3.0 이고 **데이터를 모델에 편입 금지**. API 추론 시 비보관 옵트아웃 필수
- **CHILDES Eng-NA · NewEngland** · 영어 · 아동

### InterpretationAttribution · DIRECTLY_VALIDATABLE

| 자료 | gold | 매핑 규칙 | 지표 | 강도 |
|---|---|---|---|---|
| 한국어 화용 평가셋 | 함축 해석 4지선다 정답 + 오답 구실 4종 | 정답 보기 = sco_Interpretation(mode=pragmatic) · literal 보기 = mode=literal. 둘을 가르는 것이 이 필드가 하는 | accuracy · macro F1 · 오답 구실별 분포 (문자적 읽기로 틀린 비율) | DIRECTLY_VALIDATABLE |
| testset_v0 (프로젝트 자체 평정) | 정규/적대 해석 쌍에 대한 5인 평정 (1~5) | 정규 해석 = sco_Interpretation(mode=pragmatic) · 적대 해석 = 같은 자리에 놓인 왜곡. 둘을 가르는 것이 이 필드다 | AUC · 정확도 | PROXY_VALIDATABLE |
| 한국어 간접 화행 평가셋 (ReDi · ReCo · ReEx) | 간접 화행 4지선다 240문항 | 정답 보기 = sco_Interpretation(mode=pragmatic) | accuracy | NOT_VALIDATABLE |

- **한국어 화용 평가셋** · 한국어 · 사람이 쓴 문항 · 맥락 포함. 120문항뿐이고 일치도는 없다
- **testset_v0 (프로젝트 자체 평정)** · **외부 benchmark 가 아니라 우리가 만든 평정 세트다.** clean_pairs 40 은 5인 만장일치인 것만 골라 남긴 것이라 일치도를 이 집합에서 다시 계산할 수 없다(구성상 100%). 정규 4.78 대 적대 1.07 로 두 부류가 멀어 쉬운 집합이다. 원자료가 국립국어원 말뭉치라 이용 약정이 이어진다. 기존 실측 · 유사도 판정기 AUC 약 0.58(적대 구분) 대 0.86(관련성)
- **한국어 간접 화행 평가셋 (ReDi · ReCo · ReEx)** · **지금 못 가져온다.** 논문이 가리키는 저장소를 확인하지 못했다. 가져올 수 있게 되면 DIRECTLY 로 올라갈 후보 1순위다

### PhenomenonAttribution · DIRECTLY_VALIDATABLE

| 자료 | gold | 매핑 규칙 | 지표 | 강도 |
|---|---|---|---|---|
| 한국어 화용 평가셋 | 그라이스 격률 4종 (quantity · quality · relation · manner) | 격률 위반 = sc_PragmaticPhenomenon 의 값. 규격이 어휘를 열어 두었으므로 격률 넷을 원천 어휘로 받는다 | accuracy · macro F1 · 혼동행렬 | DIRECTLY_VALIDATABLE |
| KoCoSa | 비꼼 이진 라벨 + 설명 | 비꼼은 sc_PragmaticPhenomenon 에 이미 관찰된 값이다 | accuracy · F1 | PROXY_VALIDATABLE |

- **한국어 화용 평가셋** · 격률별 30문항으로 균형이 맞다
- **KoCoSa** · 라이선스 없음(권리 유보) · 대상 응답이 LLM 생성 · 국립국어원 말뭉치 파생이라 약정이 이어질 수 있다. 내부 분석까지만

### CueObservation · DEMONSTRATION_ONLY

| 자료 | gold | 매핑 규칙 | 지표 | 강도 |
|---|---|---|---|---|
| KMI (Korean Motivational Interviewing) | 없음 | 다중턴 한국어 대화라 담화 단서를 뽑아 보여 줄 수는 있다 | 없음 | DEMONSTRATION_ONLY |

- **KMI (Korean Motivational Interviewing)** · CC BY 4.0 라 발표에 원문을 실을 수 있는 유일한 한국어 대화다

### GoalAttribution · NOT_VALIDATABLE

검증할 자료가 없다.

> 규격이 직접 적어 두었다 · "확인한 네 자료 중 어느 것도 사회적 목표를 라벨로 주지 않았다". sc_InteractionGoal 은 values 를 정하지 않은 provisional 이다. 억지로 재지 않는다

### StrategyRecommendation · NOT_VALIDATABLE

검증할 자료가 없다.

> 추천에는 정답이 없다. 같은 상황에 친구 · 상담자 · 교사가 다른 전략을 쓴다. gold 를 만들 수 있는 종류가 아니다

### StrategyAttribution · PROXY_VALIDATABLE

| 자료 | gold | 매핑 규칙 | 지표 | 강도 |
|---|---|---|---|---|
| KMI (Korean Motivational Interviewing) | MI 전략 8종 (상담자 턴에 붙음) | sc_ResponseStrategy 의 하위 sc_CounselingStrategy 에 MAPS_TO | accuracy · macro F1 (라벨 불균형이 커서 균형 표본으로만) | PROXY_VALIDATABLE |
| AnnoMI | MI 발화 수준 라벨 | sc_CounselingStrategy 로 MAPS_TO | accuracy · macro F1 | PROXY_VALIDATABLE |

- **KMI (Korean Motivational Interviewing)** · **라벨이 사람 주석이 아니다.** T5 forecaster 가 라벨을 먼저 고르고 GPT-4 가 그 라벨에 맞는 발화를 썼다. 생성 조건이지 주석이 아니다. 전문가 4인이 표본 210발화만 확인했다 (96.0%, General 라벨 제외)
- **AnnoMI** · 영어 · 라이선스 표기 없음(권리 유보)

## 억지로 재지 않는 것

- **GoalAttribution** · 규격이 직접 적어 두었다 · "확인한 네 자료 중 어느 것도 사회적 목표를 라벨로 주지 않았다". sc_InteractionGoal 은 values 를 정하지 않은 provisional 이다. 억지로 재지 않는다
- **StrategyRecommendation** · 추천에는 정답이 없다. 같은 상황에 친구 · 상담자 · 교사가 다른 전략을 쓴다. gold 를 만들 수 있는 종류가 아니다
- **CueObservation** · 단서 주석이 붙은 한국어 자료를 못 찾았다. ObservedFeature 의 시간 측정값은 음성이 있어야 나온다

이 셋은 gold 가 없다. 없는 것을 있는 척하지 않는다.
LLM 으로 정답을 만들어 LLM 을 채점하면 그것은 검증이 아니다.
