# -*- coding: utf-8 -*-
"""어떤 자료가 우리 온톨로지의 **무엇을** 재는가.

강사님이 가장 쉽게 묻는 것 · "그 데이터로 너희 시스템의 정확히 뭘 검증하는데?"
그 물음에 한 줄로 답할 수 있어야 한다. 못 답하면 그 자료는 benchmark 가 아니다.

네 단계만 쓴다
  DIRECTLY_VALIDATABLE  사람이 붙인 gold 가 이 필드의 값을 직접 준다. **한국어다.**
  PROXY_VALIDATABLE     필드는 맞는데 언어가 다르거나 라벨이 사람 것이 아니거나 구조가 모자라다
  DEMONSTRATION_ONLY    gold 가 없다. 만들어 보여 줄 수는 있지만 정확도를 말할 수 없다
  NOT_VALIDATABLE       gold 가 있을 수 있는 자료가 아예 없다

언어를 왜 따지나
  우리 제품은 한국어다. 한국어 시스템을 영어 자료로 재면 그 시스템을 잰 것이 아니다.
  영어 화행 말뭉치는 **필드가 잴 수 있는 것인지**는 보여 주지만 우리 성능은 아니다.
  그래서 PROXY 로 내린다. 쓸모가 없다는 뜻이 아니라 다른 것을 잰다는 뜻이다.
"""
from __future__ import annotations

FIELDS = ('ActAttribution', 'InterpretationAttribution', 'PhenomenonAttribution',
          'CueObservation', 'GoalAttribution', 'StrategyRecommendation',
          'StrategyAttribution')

STRENGTH = ('DIRECTLY_VALIDATABLE', 'PROXY_VALIDATABLE',
            'DEMONSTRATION_ONLY', 'NOT_VALIDATABLE')

# dataset 이름 → 매핑들. 한 자료가 여러 필드를 잴 수 있다.
MAP = {
    '한국어 화용 평가셋': [
        dict(field='InterpretationAttribution',
             gold_label='함축 해석 4지선다 정답 + 오답 구실 4종',
             rule='정답 보기 = sco_Interpretation(mode=pragmatic) · '
                  'literal 보기 = mode=literal. 둘을 가르는 것이 이 필드가 하는 일이다',
             metric='accuracy · macro F1 · 오답 구실별 분포 (문자적 읽기로 틀린 비율)',
             strength='DIRECTLY_VALIDATABLE',
             note='한국어 · 사람이 쓴 문항 · 맥락 포함. 120문항뿐이고 일치도는 없다'),
        dict(field='PhenomenonAttribution',
             gold_label='그라이스 격률 4종 (quantity · quality · relation · manner)',
             rule='격률 위반 = sc_PragmaticPhenomenon 의 값. 규격이 어휘를 열어 두었으므로 '
                  '격률 넷을 원천 어휘로 받는다',
             metric='accuracy · macro F1 · 혼동행렬',
             strength='DIRECTLY_VALIDATABLE',
             note='격률별 30문항으로 균형이 맞다'),
    ],
    'KMI (Korean Motivational Interviewing)': [
        dict(field='StrategyAttribution',
             gold_label='MI 전략 8종 (상담자 턴에 붙음)',
             rule='sc_ResponseStrategy 의 하위 sc_CounselingStrategy 에 MAPS_TO',
             metric='accuracy · macro F1 (라벨 불균형이 커서 균형 표본으로만)',
             strength='PROXY_VALIDATABLE',
             note='**라벨이 사람 주석이 아니다.** T5 forecaster 가 라벨을 먼저 고르고 '
                  'GPT-4 가 그 라벨에 맞는 발화를 썼다. 생성 조건이지 주석이 아니다. '
                  '전문가 4인이 표본 210발화만 확인했다 (96.0%, General 라벨 제외)'),
        dict(field='CueObservation',
             gold_label='없음',
             rule='다중턴 한국어 대화라 담화 단서를 뽑아 보여 줄 수는 있다',
             metric='없음',
             strength='DEMONSTRATION_ONLY',
             note='CC BY 4.0 라 발표에 원문을 실을 수 있는 유일한 한국어 대화다'),
    ],
    'testset_v0 (프로젝트 자체 평정)': [
        dict(field='InterpretationAttribution',
             gold_label='정규/적대 해석 쌍에 대한 5인 평정 (1~5)',
             rule='정규 해석 = sco_Interpretation(mode=pragmatic) · '
                  '적대 해석 = 같은 자리에 놓인 왜곡. 둘을 가르는 것이 이 필드다',
             metric='AUC · 정확도',
             strength='PROXY_VALIDATABLE',
             note='**외부 benchmark 가 아니라 우리가 만든 평정 세트다.** '
                  'clean_pairs 40 은 5인 만장일치인 것만 골라 남긴 것이라 '
                  '일치도를 이 집합에서 다시 계산할 수 없다(구성상 100%). '
                  '정규 4.78 대 적대 1.07 로 두 부류가 멀어 쉬운 집합이다. '
                  '원자료가 국립국어원 말뭉치라 이용 약정이 이어진다. '
                  '기존 실측 · 유사도 판정기 AUC 약 0.58(적대 구분) 대 0.86(관련성)'),
    ],
    'KoCoSa': [
        dict(field='PhenomenonAttribution',
             gold_label='비꼼 이진 라벨 + 설명',
             rule='비꼼은 sc_PragmaticPhenomenon 에 이미 관찰된 값이다',
             metric='accuracy · F1',
             strength='PROXY_VALIDATABLE',
             note='라이선스 없음(권리 유보) · 대상 응답이 LLM 생성 · '
                  '국립국어원 말뭉치 파생이라 약정이 이어질 수 있다. 내부 분석까지만'),
    ],
    '3i4K': [
        dict(field='ActAttribution',
             gold_label='발화 유형 7분류 (담화성분)',
             rule='sc_SpeechAct 의 원천 어휘로 MAPS_TO',
             metric='accuracy · macro F1',
             strength='PROXY_VALIDATABLE',
             note='**맥락이 없다.** 단일 발화다. 우리 ActAttribution 은 '
                  'sco_SituatedUtterance 를 대상으로 하는데 그 자리가 비어 있다'),
    ],
    'SAE4K': [
        dict(field='ActAttribution',
             gold_label='질문 하위유형 6분류',
             rule='sc_SpeechAct 하위 행위명으로 MAPS_TO',
             metric='accuracy',
             strength='PROXY_VALIDATABLE',
             note='맥락 없음 · 질문 유형만 다룬다'),
    ],
    '한국어 간접 화행 평가셋 (ReDi · ReCo · ReEx)': [
        dict(field='InterpretationAttribution',
             gold_label='간접 화행 4지선다 240문항',
             rule='정답 보기 = sco_Interpretation(mode=pragmatic)',
             metric='accuracy',
             strength='NOT_VALIDATABLE',
             note='**지금 못 가져온다.** 논문이 가리키는 저장소를 확인하지 못했다. '
                  '가져올 수 있게 되면 DIRECTLY 로 올라갈 후보 1순위다'),
    ],
    'AnnoMI': [
        dict(field='StrategyAttribution',
             gold_label='MI 발화 수준 라벨',
             rule='sc_CounselingStrategy 로 MAPS_TO',
             metric='accuracy · macro F1',
             strength='PROXY_VALIDATABLE',
             note='영어 · 라이선스 표기 없음(권리 유보)'),
    ],
    'SwDA (Switchboard Dialog Act Corpus)': [
        dict(field='ActAttribution', gold_label='SWBD-DAMSL 대화행위 태그',
             rule='sc_SpeechAct 로 MAPS_TO', metric='accuracy · macro F1',
             strength='PROXY_VALIDATABLE', note='영어 · 전화 대화'),
    ],
    'ASDBank · Rollins': [
        dict(field='ActAttribution', gold_label='INCA-A 화행 코딩 (%spa)',
             rule='sc_SpeechAct 로 MAPS_TO', metric='accuracy',
             strength='PROXY_VALIDATABLE',
             note='영어 · 임상군(AS 아동) · CC BY-NC-SA 3.0 이고 '
                  '**데이터를 모델에 편입 금지**. API 추론 시 비보관 옵트아웃 필수'),
    ],
    'CHILDES Eng-NA · NewEngland': [
        dict(field='ActAttribution', gold_label='INCA-A %spa 2단',
             rule='sc_SpeechAct 로 MAPS_TO', metric='accuracy',
             strength='PROXY_VALIDATABLE', note='영어 · 아동'),
    ],
}

# gold 가 어디에도 없는 필드 · 규격 자체가 그렇게 적고 있다
NO_GOLD = {
    'GoalAttribution': ('규격이 직접 적어 두었다 · "확인한 네 자료 중 어느 것도 사회적 목표를 '
                        '라벨로 주지 않았다". sc_InteractionGoal 은 values 를 정하지 않은 '
                        'provisional 이다. 억지로 재지 않는다'),
    'StrategyRecommendation': ('추천에는 정답이 없다. 같은 상황에 친구 · 상담자 · 교사가 '
                               '다른 전략을 쓴다. gold 를 만들 수 있는 종류가 아니다'),
    'CueObservation': ('단서 주석이 붙은 한국어 자료를 못 찾았다. ObservedFeature 의 '
                       '시간 측정값은 음성이 있어야 나온다'),
}


def field_rows():
    """필드별로 가장 센 근거를 뽑는다."""
    best = {f: [] for f in FIELDS}
    for ds, ms in MAP.items():
        for m in ms:
            best[m['field']].append(dict(m, dataset=ds))
    order = {s: i for i, s in enumerate(STRENGTH)}
    for f in best:
        best[f].sort(key=lambda m: order[m['strength']])
    return best


def status_of(field):
    rows = field_rows()[field]
    if not rows:
        return 'NOT_VALIDATABLE'
    return rows[0]['strength']


def datasets_directly_validating():
    return sorted({ds for ds, ms in MAP.items() for m in ms
                   if m['strength'] == 'DIRECTLY_VALIDATABLE'})


if __name__ == '__main__':
    print('온톨로지 필드 %d개' % len(FIELDS))
    for f in FIELDS:
        rows = field_rows()[f]
        st = status_of(f)
        print()
        print('%-28s %s' % (f, st))
        if not rows:
            print('   근거 자료 없음 · %s' % NO_GOLD.get(f, '')[:88])
        for m in rows[:3]:
            print('   %-22s %-22s %s' % (m['dataset'][:22], m['strength'], m['metric'][:40]))
    print()
    print('직접 검증 가능한 자료 ·', datasets_directly_validating())
