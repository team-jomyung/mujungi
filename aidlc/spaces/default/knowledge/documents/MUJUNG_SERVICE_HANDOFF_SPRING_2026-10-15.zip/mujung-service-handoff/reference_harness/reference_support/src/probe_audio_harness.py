"""Probe 오디오 파이프라인 하네스.

흐름:
  아동 시뮬레이터 (gpt-6-luna, 텍스트)
    → 로컬 TTS (Piper, 무료)
    → gpt-live-1 (Live API, 오디오)
    → 전사 수집
    → Luna 분석 (Probe 2)

API 키 사용: 시뮬레이터, Live, Luna 분석 (TTS는 로컬)

하네스 v0.2 (2026-10-13) — 파일럿 감사에서 발견된 6개 버그 수정:
  1. 빈 시뮬레이터 출력: 1회 재시도 후에도 비어 있으면 무음 전송 없이 세션 정상 종료
  2. 고정 8초 대기 폐지: 출력 전사가 안정될 때까지 폴링 (안정 2.0초 / 최대 40초)
  3. 입력 전사 확인: get_input_transcript() 사용 (출력 getter 오용 수정)
  4. 아동 이름/관심사: 시나리오 필드(child_name/child_interest) 사용, 하드코딩 "민준" 제거
  5. P07 트리거: scenario["child_triggers"] 스크립트 트리거 주입 (중단 요청 기회 보장)
  6. 전사 순서: child opening → mujung 순으로 시계열 정합 (기존엔 뒤바뀜)
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import os
import sys
import time
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from probe_instructions_v02 import build_instructions
from probe_child import ChildSimulator
from live_api_session import LiveApiSession
from local_tts import synthesize

BASE = Path(__file__).resolve().parent.parent
RUNS = BASE / "runs" / "probe"

HARNESS_VERSION = "1.0"

# --- 응답 대기 파라미터 (v0.7: 실제 대화처럼 - 길게 기다림) ---
RESP_POLL_INTERVAL = 0.5      # 폴링 간격 (초)
RESP_AUDIO_SILENCE_SEC = 5.0  # 5초 침묵이면 종료 (문장 사이 쉼과 구분)
RESP_TRANSCRIPT_STABLE_SEC = 3.0  # 전사도 3초 안정
RESP_FIRST_GRACE_SEC = 3.0    # 최소 대기
RESP_NO_RESPONSE_SEC = 30.0   # 무응답 판단
RESP_MAX_SEC = 120.0          # 최대 2분 (긴 발화도 전부 캡처)

# child_name이 없는 시나리오용 결정적 폴백 풀 (시나리오 ID 해시로 선택)
CHILD_NAME_POOL = ["지호", "하준", "서연", "도윤", "민서", "준우", "예린", "시우"]
END_KEYWORDS = ["그만", "하기 싫어", "안 할래"]


def load_kit():
    with open(BASE / "data" / "probe_kit_v01.json", encoding="utf-8") as f:
        return json.load(f)


def _fallback_child_name(scenario_id: str) -> str:
    """child_name 미지정 시나리오용 결정적 이름 (하드코딩 회피)."""
    idx = int(hashlib.md5(scenario_id.encode()).hexdigest(), 16) % len(CHILD_NAME_POOL)
    return CHILD_NAME_POOL[idx]


async def wait_for_mujung_response(live: LiveApiSession) -> tuple[str, float]:
    """무중 응답 수집 (v0.8: 고정 시간 수집 - 정확도 최우선).

    턴 종료를 감지하려고 하지 않음. 고정 시간(25초) 동안 나오는
    모든 전사를 하나의 턴으로 합침. 실제 대화 디지털화 관점.
    반환: (전사 텍스트, 대기 시간 초)
    """
    FIXED_WAIT_SEC = 25.0  # 고정 수집 시간

    start = time.time()
    live.reset_output_audio_timer()

    # 고정 시간 동안 대기하면서 전사 수집
    await asyncio.sleep(FIXED_WAIT_SEC)

    text = live.get_output_transcript().strip()
    elapsed = time.time() - start

    # 전사가 비어 있으면 무응답
    if not text:
        # 5초 더 기다려봄
        await asyncio.sleep(5.0)
        text = live.get_output_transcript().strip()
        elapsed = time.time() - start
        if not text:
            return "", elapsed

    return text, elapsed


async def run_audio_session(profile_id: str, scenario_id: str,
                            max_roundtrips: int = 20,
                            max_duration_sec: float = 720.0) -> dict:
    """오디오 기반 1개 세션 실행.
    
    max_roundtrips: 최대 왕복 횟수 (기본 20, 약 10-12분 분량)
    max_duration_sec: 최대 세션 시간 (기본 720초 = 12분)
    """
    kit = load_kit()
    profiles = {p["id"]: p for p in kit["profiles"]}
    scenarios = {s["id"]: s for s in kit["scenarios"]}
    profile = profiles[profile_id]
    scenario = scenarios[scenario_id]

    # 버그 #4: 이름/관심사 하드코딩 제거 → 시나리오 필드 사용
    child_name = scenario.get("child_name") or _fallback_child_name(scenario_id)
    child_interest = scenario.get("child_interest") or "블록"
    # 버그 #5: P07 등 스크립트 트리거 (1-indexed roundtrip → 발화 텍스트)
    triggers = {t["roundtrip"]: t["text"]
                for t in scenario.get("child_triggers", [])}

    sim = ChildSimulator(profile, age=9)
    live = LiveApiSession(build_instructions(name=child_name,
                                             interest=child_interest))
    await live.connect()

    transcript: list[dict] = []
    private_log: list[dict] = []
    t0 = time.time()
    session_start = t0

    def add_turn(speaker: str, text: str):
        transcript.append({
            "turn": len(transcript) + 1,
            "speaker": speaker,
            "text": text,
            "timestamp_ms": int((time.time() - t0) * 1000),
        })

    try:
        # 시작: 시나리오 opening을 TTS로 변환해서 입력
        # (Live는 full-duplex라 먼저 말할 수 있음)
        opening = scenario.get("opening", "안녕.")
        # 버그 #6: opening을 먼저 기록 (기존엔 mujung 턴 뒤에 추가돼 순서가 뒤바뀜)
        add_turn("child", opening)
        private_log.append({"turn": 1, "profile_id": profile_id,
                            "note": "scenario opening via TTS",
                            "child_name": child_name,
                            "child_interest": child_interest})
        opening_audio = synthesize(opening)
        # v0.9: 누적 위치로 턴 구분
        prev_output_len = len(live.get_output_transcript())
        prev_input_len = len(live.get_input_transcript())
        await live.send_audio(opening_audio)
        _, waited = await wait_for_mujung_response(live)
        full_output = live.get_output_transcript()
        mujung_text = full_output[prev_output_len:].strip()
        full_input = live.get_input_transcript()
        heard = full_input[prev_input_len:].strip()  # 버그 #3: 입력 전사 getter 사용
        private_log.append({"turn": 1, "heard_by_live": heard,
                            "mujung_wait_sec": round(waited, 1)})
        if mujung_text:
            add_turn("mujung", mujung_text)
        else:
            private_log.append({"event": "no_response", "turn": len(transcript)})

        for rt in range(max_roundtrips):
            # 시간 상한 체크 (12분)
            if time.time() - session_start >= max_duration_sec:
                private_log.append({
                    "event": "max_duration_reached",
                    "duration_sec": round(time.time() - session_start, 1),
                })
                break
            roundtrip_no = rt + 1
            # 버그 #5: 스크립트 트리거 우선 (시뮬레이터 대신 주입)
            trigger_text = triggers.get(roundtrip_no)
            if trigger_text is not None:
                child_text = trigger_text
                child_source = "scripted_trigger"
            else:
                # 이전 무중 발화에 대한 아동 응답 생성
                last_mujung = (transcript[-1]["text"]
                               if transcript and transcript[-1]["speaker"] == "mujung"
                               else "")
                child_text = (await sim.arespond(last_mujung) or "").strip()
                child_source = "simulator"
                # 버그 #1: 빈 발화 1회 재시도
                if not child_text:
                    child_text = (await sim.arespond(last_mujung) or "").strip()
                if not child_text:
                    # 무음 TTS 전송 금지 — 세션 정상 종료
                    private_log.append({
                        "event": "simulator_empty_output",
                        "turn": len(transcript) + 1,
                        "roundtrip": roundtrip_no,
                        "note": "시뮬레이터가 빈 발화를 2회 연속 반환 — 무음 전송 없이 세션 종료",
                    })
                    break

            child_audio = synthesize(child_text)

            # v1.0: interrupt로 무중 발화를 확실히 중단 후 아동 음성 전송
            # (full-duplex라서 안 끊으면 응답이 섞임)
            await live.interrupt()
            # 새로 추가된 부분만 현재 턴으로 취급
            prev_output_len = len(live.get_output_transcript())
            prev_input_len = len(live.get_input_transcript())
            await live.send_audio(child_audio)
            _, waited = await wait_for_mujung_response(live)
            # 새로 추가된 부분만 현재 턴으로 취급
            full_output = live.get_output_transcript()
            mujung_text = full_output[prev_output_len:].strip()
            full_input = live.get_input_transcript()
            heard = full_input[prev_input_len:].strip()

            add_turn("child", child_text)
            private_log.append({
                "turn": len(transcript),
                "profile_id": profile_id,
                "roundtrip": roundtrip_no,
                "child_source": child_source,
                "heard_by_live": heard,
                "mujung_wait_sec": round(waited, 1),
            })

            if mujung_text:
                add_turn("mujung", mujung_text)
            else:
                private_log.append({"event": "no_response", "turn": len(transcript)})
                break

            # 종료 조건
            if any(k in child_text for k in END_KEYWORDS):
                private_log.append({"event": "child_end"})
                break

    finally:
        session_duration = time.time() - session_start
        await live.close()

    return {
        "profile_id": profile_id,
        "scenario_id": scenario_id,
        "model": "gpt-live-1",
        "harness_version": HARNESS_VERSION,
        "child_name": child_name,
        "child_interest": child_interest,
        "transcript": transcript,
        "private_behavior_log": private_log,
        "session_duration_sec": round(session_duration, 1),
        "estimated_cost_usd": round(session_duration / 60 * 0.05, 4),
        "roundtrips": len(transcript) // 2,
    }


async def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--profile", default="C00")
    ap.add_argument("--scenario", default="SC-C00-01")
    ap.add_argument("--rounds", type=int, default=4)
    args = ap.parse_args()

    print(f"Starting audio session: {args.profile}/{args.scenario}")
    result = await run_audio_session(args.profile, args.scenario,
                                     max_roundtrips=args.rounds)
    out = RUNS / args.scenario / "session_audio.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, ensure_ascii=False, indent=1),
                   encoding="utf-8")
    print(f"saved: {out}")
    print(f"duration: {result['session_duration_sec']}s, "
          f"cost: ${result['estimated_cost_usd']}")
    for t in result["transcript"]:
        print(f"  [{t['speaker']}] {t['text'][:60]}")


if __name__ == "__main__":
    asyncio.run(main())
