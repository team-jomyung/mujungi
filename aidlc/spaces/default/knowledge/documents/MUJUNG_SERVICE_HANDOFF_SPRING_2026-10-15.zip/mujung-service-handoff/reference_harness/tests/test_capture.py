"""Offline regressions. No credentials, external SDK imports or API calls."""
import asyncio
import base64
import json
from pathlib import Path
import sys
import time
from types import SimpleNamespace
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from live_api_session import LiveApiSession
from probe_v4 import wait_for_reply_opportunity


class FakeSocket:
    def __init__(self, finalize=True):
        self.incoming = asyncio.Queue()
        self.sent = []
        self.finalize = finalize
        self.closed = False

    def __aiter__(self):
        return self

    async def __anext__(self):
        item = await self.incoming.get()
        if item is None:
            raise StopAsyncIteration
        return json.dumps(item)

    async def send(self, message):
        event = json.loads(message)
        self.sent.append((time.monotonic(), event))
        if event["type"] == "session.start":
            await self.incoming.put({"type": "session.started", "session": {"id": "offline"}})
        elif event["type"] == "session.close" and self.finalize:
            await self.incoming.put({
                "type": "session.output_transcript.delta", "event_id": "last", "delta": " 마지막.",
                "start_ms": 9000, "end_ms": 9400,
            })
            await self.incoming.put({"type": "session.closed", "usage": {"seconds": 10}})
        elif event["type"] == "session.instructions.append":
            await self.incoming.put({
                "type": "session.instructions.appended", "client_event_id": event.get("event_id"),
                "start_ms": 100, "end_ms": 300,
            })

    async def close(self):
        self.closed = True


def delta(text, ident, start=0, end=10, speaker="output"):
    return {"type": "session.%s_transcript.delta" % speaker,
            "event_id": ident, "delta": text, "start_ms": start, "end_ms": end}


class CaptureTests(unittest.IsolatedAsyncioTestCase):
    async def make_session(self, **kwargs):
        ws = FakeSocket()
        live = LiveApiSession("offline", close_timeout=.1, **kwargs)
        await live.connect(websocket=ws)
        self.addAsyncCleanup(live.close)
        return live, ws

    async def test_config_explicit_pcm_rate(self):
        live, ws = await self.make_session()
        start = next(e for _, e in ws.sent if e["type"] == "session.start")
        self.assertEqual(start["session"]["audio"]["format"], {"type": "audio/pcm", "rate": 16000})

    async def test_raw_fragments_preserve_whitespace_and_interleaving(self):
        live = LiveApiSession("offline")
        cursor = live.transcript_cursor()
        live._handle_event(delta("팔 다리 움직이는", "a", 100, 600))
        live._handle_event(delta("응", "b", 400, 500, "input"))
        live._handle_event(delta(" 거?  거?", "c", 610, 900))
        self.assertEqual(live.output_since(cursor), "팔 다리 움직이는 거?  거?")
        self.assertEqual(live.get_input_transcript(), "응")
        self.assertEqual(live.transcript_cursor(), 3)
        events = live.capture_snapshot()["transcript_events"]
        self.assertEqual([e["event_id"] for e in events], ["a", "b", "c"])
        self.assertEqual(events[-1]["start_ms"], 610)

    async def test_audio_is_paced_and_silence_continues(self):
        live, ws = await self.make_session()
        await asyncio.sleep(.025)
        audio = b"\x01\x00" * 320 * 3
        await live.send_audio(audio, sample_rate=16000)
        await asyncio.sleep(.045)
        frames = [(t, base64.b64decode(e["audio"])) for t, e in ws.sent
                  if e["type"] == "session.input_audio.append"]
        self.assertTrue(all(len(frame) == 640 for _, frame in frames))
        voiced = [(t, f) for t, f in frames if any(f)]
        self.assertEqual(b"".join(f for _, f in voiced), audio)
        self.assertGreaterEqual(voiced[-1][0] - voiced[0][0], .03)
        self.assertTrue(any(not any(f) for t, f in frames if t > voiced[-1][0]))

    async def test_invalid_pcm_and_rate_rejected(self):
        live, _ = await self.make_session()
        for data, rate in [(b"x", 16000), (b"RIFF" + b"\0" * 40, 16000), (b"\0\0", 24000)]:
            with self.assertRaises((ValueError, TypeError)):
                await live.send_audio(data, sample_rate=rate)

    async def test_close_receives_late_transcript_before_cancelling(self):
        live, ws = await self.make_session()
        live._handle_event(delta("처음.", "first"))
        result = await live.close()
        self.assertIn("마지막.", live.get_output_transcript())
        self.assertTrue(ws.closed)
        self.assertIsInstance(result, dict)

    async def test_server_error_propagates_instead_of_waiting_for_timeout(self):
        live, ws = await self.make_session()
        await ws.incoming.put({"type": "error", "error": {"code": "test_error", "message": "offline error"}})
        await asyncio.sleep(.01)
        with self.assertRaises(RuntimeError):
            live.ensure_healthy()

    async def test_unexpected_socket_end_is_capture_failure(self):
        live, ws = await self.make_session()
        await ws.incoming.put(None)
        await asyncio.sleep(.01)
        with self.assertRaises(RuntimeError):
            live.ensure_healthy()

    async def test_instructions_use_documented_fields(self):
        live, ws = await self.make_session()
        await live.send_instructions("짧게 답해.")
        event = next(e for _, e in ws.sent if e["type"] == "session.instructions.append")
        self.assertEqual(event["content"], "짧게 답해.")
        self.assertIsNone(event["delegation_id"])
        self.assertNotIn("instructions", event)

    async def test_clear_does_not_destroy_evidence(self):
        live = LiveApiSession("offline")
        live._handle_event(delta("원문", "original"))
        with self.assertRaises((RuntimeError, NotImplementedError)):
            live.clear_transcripts()
        self.assertEqual(live.get_output_transcript(), "원문")

    async def test_24khz_uses_960_byte_frames(self):
        live, ws = await self.make_session(sample_rate=24000)
        await live.send_audio(b"\x01\0" * 480, sample_rate=24000)
        frames = [base64.b64decode(e["audio"]) for _, e in ws.sent
                  if e["type"] == "session.input_audio.append"]
        self.assertTrue(frames)
        self.assertTrue(all(len(frame) == 960 for frame in frames))

    async def test_invalid_numeric_configuration_rejected(self):
        for config in [{"sample_rate": 16000.0}, {"sample_rate": True},
                       {"start_timeout": float("nan")}, {"close_timeout": float("inf")},
                       {"max_duration_sec": 0}, {"max_duration_sec": 481}]:
            with self.assertRaises(ValueError):
                LiveApiSession("offline", **config)

    async def test_close_timeout_is_recorded_as_failure(self):
        ws = FakeSocket(finalize=False)
        live = LiveApiSession("offline", close_timeout=.02)
        await live.connect(websocket=ws)
        result = await live.close()
        self.assertEqual(result["status"], "CLOSE_TIMEOUT")
        self.assertFalse(result["server_closed_received"])
        self.assertTrue(ws.closed)
        self.assertFalse(live.capture_snapshot()["health"]["ok"])

    async def test_cancelling_close_cleans_tasks_and_pending_send(self):
        ws = FakeSocket(finalize=False)
        live = LiveApiSession("offline", close_timeout=1)
        await live.connect(websocket=ws)
        sending = asyncio.create_task(live.send_audio(b"\x01\0" * 16000))
        await asyncio.sleep(.01)
        closing = asyncio.create_task(live.close())
        await asyncio.sleep(.01)
        closing.cancel()
        with self.assertRaises(asyncio.CancelledError):
            await closing
        with self.assertRaises(RuntimeError):
            await sending
        self.assertTrue(ws.closed)
        self.assertTrue(live._listen_task.done())
        self.assertTrue(live._pump_task.done())
        self.assertEqual(live.capture_snapshot()["finalization"]["status"], "CANCELLED")

    async def test_sender_failure_releases_pending_audio(self):
        class FailingSocket(FakeSocket):
            async def send(self, message):
                if json.loads(message)["type"] == "session.input_audio.append":
                    raise OSError("offline transport failure")
                await super().send(message)
        ws = FailingSocket()
        live = LiveApiSession("offline", close_timeout=.02)
        await live.connect(websocket=ws)
        self.addAsyncCleanup(live.close)
        with self.assertRaises(RuntimeError):
            await asyncio.wait_for(live.send_audio(b"\0\0" * 320), timeout=.2)

    async def test_proxy_compatibility_is_per_connection_and_idempotent(self):
        class Headers:
            def __init__(self, entries): self.entries = list(entries)
            def get_all(self, key): return [v for k, v in self.entries if k.lower() == key.lower()]
            def raw_items(self): return iter(self.entries)
        class Protocol:
            def __init__(self): self.calls = 0
            def process_response(self, response):
                self.calls += 1
                return response.headers.get_all("Connection")
        live = LiveApiSession("offline")
        first, other = Protocol(), Protocol()
        live._configure_cloudflare_compat(first, Headers)
        live._configure_cloudflare_compat(first, Headers)
        response = SimpleNamespace(status_code=101, headers=Headers([("Upgrade", "websocket")]))
        self.assertEqual(first.process_response(response), ["Upgrade"])
        self.assertEqual(first.calls, 1)
        self.assertEqual(live.connection_compat["repairs"], 1)
        self.assertFalse(hasattr(other, "_mujung_compat_wrapped"))
        rejected = SimpleNamespace(status_code=403, headers=Headers([]))
        self.assertEqual(first.process_response(rejected), [])
        self.assertEqual(live.connection_compat["repairs"], 1)


class FakeCapture:
    """A deterministic event source for the boundary estimator."""
    def __init__(self):
        self.events = []
        self.output_revision = 0
        self.last_transcript_at = 0.0
        self.last_voice_until = 0.0
        self.playback_until = 0.0
        self.error = False

    def transcript_cursor(self):
        return len(self.events)

    def add(self, text):
        self.events.append(text)
        self.output_revision += 1
        self.last_transcript_at = time.monotonic()

    def output_since(self, cursor):
        return "".join(self.events[cursor:])

    def ensure_healthy(self):
        if self.error:
            raise RuntimeError("offline capture failure")

    def output_activity(self):
        return {"now": time.monotonic(), "last_transcript_at": self.last_transcript_at,
                "last_voice_until": self.last_voice_until, "playback_until": self.playback_until}


class BoundaryTests(unittest.IsolatedAsyncioTestCase):
    async def wait(self, live, cursor=0, seconds=.15, **kwargs):
        return await wait_for_reply_opportunity(
            live, cursor=cursor, deadline=time.monotonic() + seconds,
            text_stable=.025, audio_quiet=.01, poll_interval=.002, **kwargs)

    async def test_early_response_before_wait_is_included(self):
        live = FakeCapture()
        cursor = live.transcript_cursor()
        live.add("이미 도착한 답변.")
        result = await self.wait(live, cursor)
        self.assertEqual(result.text, "이미 도착한 답변.")
        self.assertEqual(result.status, "estimated")
        self.assertFalse(result.confirmed_done)

    async def test_delayed_continuation_not_skipped(self):
        live = FakeCapture()
        live.add("팔 다리 움직이는")
        task = asyncio.create_task(self.wait(live, require_terminal_punctuation=True))
        await asyncio.sleep(.055)
        self.assertFalse(task.done())
        live.add(" 거?")
        result = await task
        self.assertEqual(result.text, "팔 다리 움직이는 거?")
        self.assertEqual(result.revision, 2)

    async def test_new_fragment_restarts_stability_window(self):
        live = FakeCapture()
        live.add("안녕.")
        task = asyncio.create_task(self.wait(live))
        await asyncio.sleep(.018)
        live.add(" 더 이야기해 줄래?")
        await asyncio.sleep(.012)
        self.assertFalse(task.done())
        result = await task
        self.assertEqual(result.text, "안녕. 더 이야기해 줄래?")

    async def test_timeout_retains_partial_but_is_not_done(self):
        live = FakeCapture()
        live.add("그 집 만들")
        result = await self.wait(live, seconds=.04, require_terminal_punctuation=True)
        self.assertEqual(result.status, "boundary_timeout")
        self.assertEqual(result.text, "그 집 만들")
        self.assertFalse(result.confirmed_done)

    async def test_no_response_timeout_has_separate_status(self):
        result = await self.wait(FakeCapture(), seconds=.02)
        self.assertEqual(result.status, "no_response_timeout")

    async def test_estimated_audible_playback_must_drain(self):
        live = FakeCapture()
        live.add("답변.")
        live.playback_until = time.monotonic() + .08
        live.last_voice_until = live.playback_until
        task = asyncio.create_task(self.wait(live))
        await asyncio.sleep(.05)
        self.assertFalse(task.done())
        self.assertEqual((await task).status, "estimated")

    async def test_continuous_silent_output_does_not_block_reply(self):
        live = FakeCapture()
        live.add("답변.")
        live.playback_until = time.monotonic() + 60
        self.assertEqual((await self.wait(live)).status, "estimated")

    async def test_health_failure_is_not_response(self):
        live = FakeCapture()
        live.error = True
        result = await self.wait(live)
        self.assertEqual(result.status, "session_error")
        self.assertFalse(result.confirmed_done)


if __name__ == "__main__":
    unittest.main()
