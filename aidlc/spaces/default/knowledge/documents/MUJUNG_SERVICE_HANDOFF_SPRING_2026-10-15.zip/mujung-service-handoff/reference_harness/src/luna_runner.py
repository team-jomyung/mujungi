"""Luna test runner: conversation -> next-practice goal recommendation.

For each synthetic case the model reads the child/AI conversation and returns
a JSON recommendation. It is scored against expectations.json:

  - RECOMMEND : status==RECOMMEND, goal_code in acceptable_goal_codes,
                all required_evidence_turn_ids cited, no forbidden_claims text
  - NO_TARGET / INSUFFICIENT : status must match expected_status

Text-based: runs on Chat Completions, cheap. Results go to runs/luna/<case>/.
"""
from __future__ import annotations

import argparse
import asyncio
import json
import re
import sys
import time
from pathlib import Path

import copy
import math

BASE = Path(__file__).resolve().parent.parent
DATA = BASE / "data" / "luna"
RUNS = BASE / "runs" / "luna"
CHAT_URL = "https://api.openai.com/v1/chat/completions"

sys.path.insert(0, str(Path(__file__).resolve().parent))


def load(name: str):
    return json.loads((DATA / f"{name}.json").read_text(encoding="utf-8"))


def goal_catalog() -> list[dict]:
    seen: dict[str, dict] = {}
    for m in load("manual"):
        g = m["selected_goal"]
        seen.setdefault(g["goal_code"], {
            "goal_code": g["goal_code"],
            "goal_name": g["goal_name"],
            "practice_focus": g.get("practice_focus", ""),
            "opportunity": g.get("opportunity", ""),
        })
    return sorted(seen.values(), key=lambda g: g["goal_code"])


SYSTEM_PROMPT = """너는 아동 화용언어 연습 추천 AI다. 아래 [연습 목표 목록] 중에서, 주어진 대화 기록을 근거로 \
아이에게 지금 가장 적절한 '다음 연습' 목표를 하나 고르거나, 고를 수 없으면 상태를 보고한다.

규칙:
- 특정 결함으로 단정하지 마라. 관찰된 행동만 근거로 삼는다.
- 실제 또래 상황을 직접 관찰한 것처럼 말하지 마라.
- 아래 JSON 형식으로만 답한다 (마크다운 펜스 없이 순수 JSON):

{"status": "RECOMMEND" | "NO_TARGET" | "INSUFFICIENT",
 "goal_code": "<목록의 코드 중 하나, 해당 없으면 null>",
 "goal_name": "<목표 이름, 해당 없으면 null>",
 "rationale": "<선택/판단 근거 2-4문장>",
 "evidence_turn_ids": ["u3", ...]}

- status 설명:
  - RECOMMEND: 연습 목표를 추천할 근거가 충분하다.
  - NO_TARGET: 대화에 연습이 필요한 목표가 드러나지 않았다.
  - INSUFFICIENT: 정보가 부족해 판단할 수 없다.
- evidence_turn_ids에는 rationale의 근거가 된 발화 id만 넣는다.
"""


def build_user_prompt(case: dict, catalog: list[dict],
                      transcript: str = "full") -> str:
    lines = ["[연습 목표 목록]"]
    for g in catalog:
        lines.append(f"- {g['goal_code']}: {g['goal_name']} "
                     f"(연습 초점: {g['practice_focus']})")
    lines += ["", "[대화 기록]"]
    utterances = case["utterances"]
    if transcript == "short":
        utterances = utterances[: len(utterances) // 2]
        lines.append("(짧은 전사: 앞부분만 제공)")
    for u in utterances:
        who = "아이" if u["speaker"] == "CHILD" else "AI"
        lines.append(f"[{u['id']}] {who}: {u['text']}")
    lines += ["",
              f"학년대: {case.get('grade_band')} / 학년: {case.get('grade')}"]
    return "\n".join(lines)


def parse_json_response(text: str) -> dict:
    m = re.search(r"\{.*\}", text, re.S)
    if not m:
        raise ValueError("no JSON object in response")
    return json.loads(m.group(0))


def score(case_id: str, rec: dict, exp: dict, raw_text: str) -> dict:
    checks: dict[str, bool] = {}
    want = exp["expected_status"]
    checks["status_match"] = (rec.get("status") == want)
    if want == "RECOMMEND":
        checks["goal_acceptable"] = (
            rec.get("goal_code") in exp["acceptable_goal_codes"])
        cited = set(rec.get("evidence_turn_ids") or [])
        checks["evidence_cited"] = set(
            exp["required_evidence_turn_ids"]) <= cited
    else:
        checks["goal_acceptable"] = True
        checks["evidence_cited"] = True
    checks["no_forbidden_claims"] = not any(
        fc in raw_text for fc in exp["forbidden_claims"])
    return {"pass": all(checks.values()), "checks": checks,
            "expected": want, "got": rec.get("status"),
            "goal_code": rec.get("goal_code")}


TOKEN_FIELDS = ("prompt_tokens", "completion_tokens", "total_tokens", "reasoning_tokens")


def _usage_fields(data: dict) -> dict:
    usage = data.get("usage")
    usage = usage if isinstance(usage, dict) else {}
    details = usage.get("completion_tokens_details")
    details = details if isinstance(details, dict) else {}
    values = {key: usage.get(key) for key in TOKEN_FIELDS[:3]}
    values["reasoning_tokens"] = details.get("reasoning_tokens")
    return {key: value if isinstance(value, int) and not isinstance(value, bool) and value >= 0 else None
            for key, value in values.items()}


def _usage_summary(attempts: list) -> dict:
    result = {}
    for field in TOKEN_FIELDS:
        values = [a.get("usage", {}).get(field) for a in attempts]
        result[field] = sum(values) if values and all(isinstance(v, int) and not isinstance(v, bool) for v in values) else None
    result["usage_complete"] = bool(attempts) and all(result[field] is not None for field in TOKEN_FIELDS)
    return result


class LunaCallError(RuntimeError):
    """A classified failure containing safe metadata only, never API text."""
    def __init__(self, code: str, attempts: list | None = None):
        self.code = code if isinstance(code, str) and re.fullmatch(r"[A-Z][A-Z0-9_]{0,63}", code) else "INVALID_ERROR_CODE"
        self.attempts = copy.deepcopy(attempts or [])
        super().__init__(self.code)

    def as_dict(self) -> dict:
        return {"code": self.code, "attempts": copy.deepcopy(self.attempts),
                "attempt_count": len(self.attempts), "retry_count": max(0, len(self.attempts) - 1),
                "usage_summary": _usage_summary(self.attempts)}


def _identifier(value):
    return value if isinstance(value, str) and re.fullmatch(r"[A-Za-z0-9_.:/-]{1,200}", value) else None


def _explicit_http_status(data: dict):
    # This connector often does not return HTTP status. Never infer 200/429/500.
    error = data.get("error") if isinstance(data.get("error"), dict) else {}
    for value in (data.get("http_status"), data.get("status_code"), error.get("status_code")):
        if isinstance(value, int) and not isinstance(value, bool) and 100 <= value <= 599:
            return value
    return None


def _classify_response(data, metadata: dict, returncode: int):
    if not isinstance(data, dict):
        return "INVALID_RESPONSE", None
    metadata.update(response_model=_identifier(data.get("model")), response_id=_identifier(data.get("id")),
                    http_status=_explicit_http_status(data), usage=_usage_fields(data))
    metadata["reasoning_tokens"] = metadata["usage"]["reasoning_tokens"]
    error = data.get("error")
    if error is not None:
        if not isinstance(error, dict):
            return "INVALID_RESPONSE", None
        # Only allowlisted error identifiers control policy; never retain message.
        markers = {x for x in (error.get("code"), error.get("type")) if isinstance(x, str)}
        if markers & {"invalid_api_key", "authentication_error", "invalid_authentication", "permission_denied", "insufficient_permissions"} or metadata["http_status"] in (401, 403):
            return "AUTHENTICATION_ERROR", None
        if "insufficient_quota" in markers:
            return "REQUEST_REJECTED", None
        if markers & {"rate_limit_exceeded", "rate_limit_error"}:
            return "RATE_LIMIT_EXCEEDED", None
        if markers & {"server_error", "internal_server_error", "service_unavailable", "overloaded_error"}:
            return "SERVER_ERROR", None
        return "REQUEST_REJECTED", None
    choices = data.get("choices")
    if not isinstance(choices, list) or not choices or not isinstance(choices[0], dict):
        return "INVALID_RESPONSE", None
    choice = choices[0]
    message = choice.get("message")
    if not isinstance(message, dict):
        return "INVALID_RESPONSE", None
    finish = choice.get("finish_reason")
    metadata["finish_reason"] = finish if finish in ("stop", "length", "content_filter", "tool_calls", "function_call") else (None if finish is None else "UNRECOGNIZED")
    content = message.get("content")
    metadata["content_type"] = "missing" if "content" not in message else ("null" if content is None else type(content).__name__)
    metadata["content_length"] = len(content) if isinstance(content, (str, list, dict)) else None
    metadata["refusal"] = bool(message.get("refusal"))
    calls = message.get("tool_calls")
    metadata["tool_call_count"] = len(calls) if isinstance(calls, list) else (1 if calls else 0)
    if message.get("function_call"):
        metadata["tool_call_count"] += 1
    if returncode != 0:
        return "TRANSPORT_ERROR", None
    if metadata["refusal"]:
        return "REFUSAL", None
    if finish == "content_filter":
        return "CONTENT_FILTER", None
    if metadata["tool_call_count"] or finish in ("tool_calls", "function_call"):
        return "UNEXPECTED_TOOL_CALL", None
    if finish == "length":
        return "OUTPUT_BUDGET_EXHAUSTED", None
    if finish != "stop":
        return "UNKNOWN_FINISH_REASON", None
    if "content" not in message:
        return "INVALID_RESPONSE", None
    if content is None or (isinstance(content, str) and not content.strip()):
        return "EMPTY_CONTENT", None
    if not isinstance(content, str):
        return "INVALID_CONTENT_TYPE", None
    return "SUCCESS", content


async def _kill_and_reap(process):
    if process.returncode is None:
        try:
            process.kill()
        except ProcessLookupError:
            pass
    await process.communicate()


async def recommend(api_key: str, model: str, system: str,
                    user: str, max_tokens: int = 800, *,
                    reasoning_effort: str | None = None, max_attempts: int = 3,
                    timeout_s: float = 45.0, max_retry_tokens: int | None = None,
                    cli_path=None) -> tuple[str, dict]:
    """Use the existing connector CLI, with one deadline across all attempts.

    api_key remains unused: the CLI owns its existing connector authentication.
    No prompts, generated content, stderr, or credentials enter diagnostics.
    max_tokens maps only to wire max_completion_tokens. Length-limited output
    is never returned as a successful child utterance, even if it is nonempty.
    """
    if isinstance(max_tokens, bool) or not isinstance(max_tokens, int) or max_tokens <= 0:
        raise ValueError("max_tokens must be a positive integer")
    if isinstance(max_attempts, bool) or not isinstance(max_attempts, int) or not 1 <= max_attempts <= 10:
        raise ValueError("max_attempts must be an integer from 1 through 10")
    if isinstance(timeout_s, bool) or not isinstance(timeout_s, (int, float)) or not math.isfinite(timeout_s) or timeout_s <= 0:
        raise ValueError("timeout_s must be a positive finite number")
    if reasoning_effort is not None and reasoning_effort not in ("none", "minimal", "low", "medium", "high", "xhigh", "max"):
        raise ValueError("invalid reasoning_effort")
    cap = max_tokens if max_retry_tokens is None else max_retry_tokens
    if isinstance(cap, bool) or not isinstance(cap, int) or cap < max_tokens:
        raise ValueError("max_retry_tokens must be an integer at least max_tokens")
    if not all(isinstance(value, str) for value in (model, system, user)) or not model:
        raise ValueError("model, system, and user must be strings; model must not be empty")
    cli = str(cli_path) if cli_path is not None else str(Path.home() / "workspace" / "skills" / "openai" / "bin" / "openai_api.py")
    started = time.monotonic()
    deadline = started + float(timeout_s)
    attempts = []
    budget = max_tokens
    retryable = {"EMPTY_CONTENT", "TRANSPORT_ERROR", "RATE_LIMIT_EXCEEDED", "SERVER_ERROR"}
    for number in range(1, max_attempts + 1):
        if time.monotonic() >= deadline:
            raise LunaCallError("TIMEOUT", attempts)
        payload = {"model": model,
                   "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}],
                   "max_completion_tokens": budget}
        if reasoning_effort is not None:
            payload["reasoning_effort"] = reasoning_effort
        metadata = {"attempt": number, "request_model": model,
                    "max_completion_tokens": budget, "reasoning_effort": reasoning_effort,
                    "response_model": None, "response_id": None, "finish_reason": None,
                    "content_type": None, "content_length": None, "refusal": False,
                    "tool_call_count": 0, "usage": {key: None for key in TOKEN_FIELDS},
                    "reasoning_tokens": None, "returncode": None, "http_status": None,
                    "stdout_bytes": None, "stderr_bytes": None}
        attempt_started = time.monotonic()
        process = None
        text = None
        try:
            process = await asyncio.create_subprocess_exec(
                sys.executable, cli, "POST", "/v1/chat/completions", "--data",
                json.dumps(payload, ensure_ascii=False), stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE)
            stdout, _stderr = await asyncio.wait_for(process.communicate(), timeout=max(0.0, deadline - time.monotonic()))
            metadata["returncode"] = process.returncode
            metadata.update(stdout_bytes=len(stdout), stderr_bytes=len(_stderr))
            try:
                data = json.loads(stdout)
            except (ValueError, UnicodeError):
                code = "TRANSPORT_ERROR" if process.returncode else "INVALID_JSON"
            else:
                code, text = _classify_response(data, metadata, process.returncode)
                if process.returncode and code not in ("AUTHENTICATION_ERROR", "RATE_LIMIT_EXCEEDED", "SERVER_ERROR", "REQUEST_REJECTED"):
                    code, text = "TRANSPORT_ERROR", None
        except asyncio.CancelledError:
            if process is not None:
                await _kill_and_reap(process)
            raise
        except asyncio.TimeoutError:
            if process is not None:
                await _kill_and_reap(process)
                metadata["returncode"] = process.returncode
            code = "TIMEOUT"
        except OSError:
            if process is not None:
                await _kill_and_reap(process)
                metadata["returncode"] = process.returncode
            code = "TRANSPORT_ERROR"
        metadata.update(classification=code, latency_s=round(time.monotonic() - attempt_started, 6))
        attempts.append(metadata)
        if code == "SUCCESS":
            info = {**_usage_summary(attempts), "latency_s": round(time.monotonic() - started, 6),
                    "attempts": attempts, "attempt_count": len(attempts),
                    "retry_count": len(attempts) - 1, "last_attempt_usage": metadata["usage"]}
            return text, info
        next_budget = min(budget * 2, cap) if code == "OUTPUT_BUDGET_EXHAUSTED" else budget
        may_retry = code in retryable or (code == "OUTPUT_BUDGET_EXHAUSTED" and next_budget > budget)
        if not may_retry or number == max_attempts:
            raise LunaCallError(code, attempts)
        budget = next_budget
        # Backoff shares the original call deadline, including connector time.
        await asyncio.sleep(min(0.25 * (2 ** (number - 1)), max(0.0, deadline - time.monotonic())))
    raise LunaCallError("INVALID_RESPONSE", attempts)


async def run_case(api_key: str, model: str, case: dict, exp: dict,
                   catalog: list[dict], transcript: str = "full") -> dict:
    tag = f"{case['case_id']}.{transcript}"
    d = RUNS / tag
    d.mkdir(parents=True, exist_ok=True)
    user_prompt = build_user_prompt(case, catalog, transcript)
    (d / "prompt.txt").write_text(
        SYSTEM_PROMPT + "\n\n" + user_prompt, encoding="utf-8")
    meta = {"case_id": case["case_id"], "title": case.get("title"),
            "split": case.get("split"), "transcript": transcript,
            "model": model,
            "started_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
            "status": "started"}
    try:
        raw, info = await recommend(api_key, model, SYSTEM_PROMPT,
                                    user_prompt)
        (d / "response.txt").write_text(raw, encoding="utf-8")
        rec = parse_json_response(raw)
        (d / "recommendation.json").write_text(
            json.dumps(rec, ensure_ascii=False, indent=1), encoding="utf-8")
        result = score(case["case_id"], rec, exp, raw)
        (d / "score.json").write_text(
            json.dumps(result, ensure_ascii=False, indent=1), encoding="utf-8")
        meta.update(status="done", usage=info,
                    finished_at=time.strftime("%Y-%m-%dT%H:%M:%S%z"))
        # cost ledger: one line per API call
        with open(RUNS / "_ledger.jsonl", "a", encoding="utf-8") as lf:
            lf.write(json.dumps({
                "ts": meta["finished_at"], "case_id": case["case_id"],
                "transcript": transcript, "model": model, **info},
                ensure_ascii=False) + "\n")
        return {"case_id": case["case_id"], **result}
    except Exception as e:  # noqa: BLE001 - record and continue
        if isinstance(e, LunaCallError):
            meta["call_error"] = e.as_dict()
        meta.update(status="error", error=str(e)[:500],
                    finished_at=time.strftime("%Y-%m-%dT%H:%M:%S%z"))
        (d / "meta.json").write_text(
            json.dumps(meta, ensure_ascii=False, indent=1), encoding="utf-8")
        return {"case_id": case["case_id"], "pass": False,
                "error": str(e)[:200]}
    finally:
        (d / "meta.json").write_text(
            json.dumps(meta, ensure_ascii=False, indent=1), encoding="utf-8")


async def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="gpt-6-luna")
    ap.add_argument("--split", default="dev",
                    help="dev | holdout | all")
    ap.add_argument("--transcript", default="full",
                    choices=["full", "short"],
                    help="full = whole conversation, "
                         "short = first half of utterances")
    ap.add_argument("--cases", default="",
                    help="comma-separated case_ids, e.g. SYN-L01,SYN-U01 "
                         "(empty = all matching)")
    ap.add_argument("--limit", type=int, default=0)
    args = ap.parse_args()

    api_key = ""  # Connector CLI owns authentication; no separate token read.

    catalog = goal_catalog()
    print(f"goal catalog: {len(catalog)} codes "
          f"{[g['goal_code'] for g in catalog]}")
    cases = load("synthetic")
    exps = {e["case_id"]: e for e in load("expectations")}
    if args.split != "all":
        cases = [c for c in cases if c["split"] == args.split]
    cases = [c for c in cases if c["case_id"] in exps]
    if args.cases:
        wanted = {c.strip() for c in args.cases.split(",") if c.strip()}
        cases = [c for c in cases if c["case_id"] in wanted]
    if args.limit:
        cases = cases[:args.limit]
    print(f"cases: {len(cases)} (split={args.split}, "
          f"transcript={args.transcript}, model={args.model})")

    results = []
    for i, case in enumerate(cases, 1):
        print(f"[{i}/{len(cases)}] {case['case_id']}.{args.transcript} "
              f"{case.get('title','')[:30]} ...", flush=True)
        r = await run_case(api_key, args.model, case,
                           exps[case["case_id"]], catalog,
                           transcript=args.transcript)
        flag = "PASS" if r.get("pass") else "FAIL"
        print(f"   -> {flag} ({r.get('got')} / {r.get('goal_code')})")
        results.append(r)

    passed = sum(1 for r in results if r.get("pass"))
    summary = {"model": args.model, "split": args.split,
               "total": len(results), "passed": passed,
               "pass_rate": round(passed / len(results), 3) if results else 0,
               "results": results}
    (RUNS / f"_summary_{args.split}.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"summary: {passed}/{len(results)} passed "
          f"({summary['pass_rate']*100:.1f}%)")


if __name__ == "__main__":
    asyncio.run(main())
