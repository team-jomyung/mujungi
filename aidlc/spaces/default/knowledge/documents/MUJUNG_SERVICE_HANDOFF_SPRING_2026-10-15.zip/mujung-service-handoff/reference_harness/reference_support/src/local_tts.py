"""로컬 TTS (Piper) — 아동 시뮬레이터 발화를 오디오로 변환.

- API 키 불필요, 완전 로컬
- 출력: 16kHz PCM16 모노 (Live API 입력 형식)
"""
from __future__ import annotations

import io
import subprocess
import wave
from pathlib import Path

BASE = Path(__file__).resolve().parent.parent
VENV_PYTHON = BASE / ".venv" / "bin" / "python"
VOICE_MODEL = BASE / "data" / "tts_voices" / "ko_KR-kss-medium.onnx"


def synthesize(text: str, target_rate: int = 16000,
               max_retries: int = 3) -> bytes:
    """텍스트를 16kHz PCM16 모노 바이트로 변환."""
    import tempfile
    import time
    # 텍스트 정제: Piper가 처리 못하는 문자 제거
    text = text.strip().replace('"', '').replace('"', '').replace('"', '')
    text = text.replace('...', '.').replace('…', '.')
    if not text:
        text = "네."
    # 너무 길면 자름
    if len(text) > 200:
        text = text[:200]

    last_err = None
    for attempt in range(max_retries):
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tf:
            tmp_path = tf.name
        try:
            proc = subprocess.run(
                [str(VENV_PYTHON), "-m", "piper",
                 "--model", str(VOICE_MODEL),
                 "--output_file", tmp_path],
                input=text.encode("utf-8"),
                capture_output=True,
                timeout=60,
            )
            if proc.returncode != 0:
                last_err = proc.stderr.decode()[:300]
                time.sleep(1)
                continue
            with open(tmp_path, "rb") as f:
                wav_data = f.read()
            break
        finally:
            Path(tmp_path).unlink(missing_ok=True)
    else:
        raise RuntimeError(
            f"Piper failed after {max_retries} retries "
            f"(text={repr(text[:50])}): {last_err}")

    # WAV 파싱
    wav = wave.open(io.BytesIO(wav_data))
    n_channels = wav.getnchannels()
    src_rate = wav.getframerate()
    sampwidth = wav.getsampwidth()
    frames = wav.readframes(wav.getnframes())

    # 16-bit PCM으로 변환 (채널/레이트 처리)
    import struct
    n_samples = len(frames) // (sampwidth * n_channels)
    fmt = "<" + ("h" * n_samples * n_channels if sampwidth == 2 else "b" * n_samples * n_channels)
    # 간단히: 16-bit 스테레오→모노, 리샘플링
    if sampwidth == 2:
        samples = struct.unpack(f"<{n_samples * n_channels}h", frames)
    else:
        # 8-bit unsigned → 16-bit
        raw = struct.unpack(f"<{n_samples * n_channels}B", frames)
        samples = [((s - 128) << 8) for s in raw]

    # 스테레오→모노 (평균)
    if n_channels == 2:
        samples = [(samples[i] + samples[i + 1]) // 2
                   for i in range(0, len(samples), 2)]

    # 리샘플링 (선형 보간)
    if src_rate != target_rate:
        ratio = src_rate / target_rate
        new_len = int(len(samples) / ratio)
        resampled = []
        for i in range(new_len):
            pos = i * ratio
            i0 = int(pos)
            i1 = min(i0 + 1, len(samples) - 1)
            frac = pos - i0
            val = int(samples[i0] * (1 - frac) + samples[i1] * frac)
            resampled.append(max(-32768, min(32767, val)))
        samples = resampled

    return struct.pack(f"<{len(samples)}h", *samples)


if __name__ == "__main__":
    audio = synthesize("안녕! 나는 민준이야.")
    print(f"generated {len(audio)} bytes ({len(audio)/2/16000:.1f}s at 16kHz)")
