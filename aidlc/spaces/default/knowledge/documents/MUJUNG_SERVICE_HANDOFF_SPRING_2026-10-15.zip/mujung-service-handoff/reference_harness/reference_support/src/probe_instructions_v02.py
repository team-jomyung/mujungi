"""무중 지시문 빌더 v0.2.

출처:
- FT-policy-0.1 (cfg-000df018) — GOLD_REVIEWED 기본 정책
- v0.2 app trial — 앱 재시험용 대화 진행 지침 (TRIAL_PROPOSAL)

Probe에서는 v0.2를 기본으로 사용. 시뮬레이터 아동 정보를 주입.
"""
from __future__ import annotations
from pathlib import Path

INSTR_DIR = Path(__file__).parent.parent / "data" / "instructions"

_V02_TEMPLATE = None


def _load_v02() -> str:
    global _V02_TEMPLATE
    if _V02_TEMPLATE is None:
        _V02_TEMPLATE = (INSTR_DIR / "v02_app_trial.txt").read_text(
            encoding="utf-8")
    return _V02_TEMPLATE


def build_instructions(name: str = "지호", interest: str = "블록",
                       topic_hint: str = "블록 놀이",
                       prev_summary: str = "없음",
                       version: str = "v0.2") -> str:
    """Probe용 지시문 생성.

    v0.2 문서를 그대로 사용하되, Probe 환경에 맞게 조정:
    - "준비됐어" 응답 부분 제거 (바로 시작)
    - 아동 이름/관심사 주입
    """
    base = _load_v02()

    # Probe용 헤더 추가
    header = f"""[Probe 테스트 설정]
지금 이야기하는 아이: {name}. 좋아하는 것: {interest}.
위 지침을 따르되, 아래 시작 절차는 생략하고 바로 대화를 시작한다.
첫 발화는 관심사에 대한 가벼운 질문으로 시작한다.

---

"""

    return header + base


def build_instructions_v01(*args, **kwargs) -> str:
    """구버전 (05_AI동작명세_v0.1.md §2 기반). 호환용."""
    from probe_instructions import build_instructions as old_build
    return old_build(*args, **kwargs)
