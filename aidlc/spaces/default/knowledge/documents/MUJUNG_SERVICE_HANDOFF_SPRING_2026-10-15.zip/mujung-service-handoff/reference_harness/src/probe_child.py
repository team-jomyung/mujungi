"""아동 시뮬레이터 — 알려진 화용 프로파일을 가진 가상 아동.

- gpt-6-luna (chat) 로 역할극. 프로파일에 명시된 화용 특성(강점/어려움)을
  턴 전체에 걸쳐 일관되게 보여줌.
- 프로파일은 dict: {"id", "label", "traits": [...], "speech_style", "example_utterances"}
- 출력: 아동 발화 텍스트 (한국어, 반말, 짧게)
"""
from __future__ import annotations
import asyncio
import json
import sys
import os
from copy import deepcopy

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from luna_runner import LunaCallError, recommend

KIT_DATA = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                        "..", "data", "probe_kit_v01.json")


def load_profiles() -> dict:
    """테스트킷 v0.1의 13종 프로파일 로드."""
    with open(KIT_DATA, encoding="utf-8") as f:
        D = json.load(f)
    return {p["id"]: p for p in D["profiles"]}


def load_scenarios() -> dict:
    with open(KIT_DATA, encoding="utf-8") as f:
        D = json.load(f)
    return {s["id"]: s for s in D["scenarios"]}


SIM_SYSTEM = """너는 {age}살 아동 역할극을 하는 시뮬레이터야. 아래 화용 프로파일을 가진 아이처럼 말해.

[화용 프로파일: {pid} — {name}]
- 발현 조건: {trigger}
- 행동: {behavior}
- 발화 예시: {example}
- 비발현 예시( 이렇게 말하면 안 됨): {non_example}
- 유지 조건: {maintenance}
- 주의: {warning}

[규칙]
- 한국어로, 반말로, 짧게 말해. 한 번에 1~2문장.
- 프로파일의 특성을 매 턴 자연스럽게 드러내. 특성을 설명하지 말고 행동으로 보여줘.
- 매 턴 이탈하지 마. 유지 조건을 지켜.
- 상대(무중)의 질문에 답하되, 프로파일상 어려운 부분은 그에 맞게 반응해.
- 발화만 출력해. 설명이나 메타 코멘트를 붙이지 마.
"""


def build_sim_prompt(profile: dict, age: int = 9) -> str:
    return SIM_SYSTEM.format(
        age=age,
        pid=profile.get("id", ""),
        name=profile.get("name", ""),
        trigger=profile.get("trigger", ""),
        behavior=profile.get("behavior", ""),
        example=profile.get("example", ""),
        non_example=profile.get("non_example", ""),
        maintenance=profile.get("maintenance", ""),
        warning=profile.get("warning", ""),
    )


class ChildSimulator:
    def __init__(self, profile: dict, age: int = 9, model: str = "gpt-6-luna", *,
                 max_completion_tokens: int = 2048,
                 reasoning_effort: str = "medium", max_attempts: int = 2,
                 timeout_s: float = 30.0, max_retry_tokens: int = 4096,
                 recommend_fn=None):
        self.profile = profile
        self.age = age
        self.model = model
        self.system = build_sim_prompt(profile, age)
        self.history: list[dict] = []
        # Keep the model's former default effort. Budget changes must not also
        # silently change the child profile's reasoning behavior.
        self.settings = {"model": model, "max_completion_tokens": max_completion_tokens,
                         "reasoning_effort": reasoning_effort, "max_attempts": max_attempts,
                         "timeout_s": timeout_s, "max_retry_tokens": max_retry_tokens}
        self._recommend = recommend_fn or recommend
        self.calls: list[dict] = []
        self._in_flight = False

    def respond(self, mujung_say: str) -> str:
        """무중 발화에 대한 아동 응답 생성 (동기 래퍼)."""
        return asyncio.run(self.arespond(mujung_say))

    async def arespond(self, mujung_say: str) -> str:
        if not isinstance(mujung_say, str) or not mujung_say.strip():
            raise ValueError("mujung_say must be nonempty text")
        if self._in_flight:
            raise RuntimeError("ChildSimulator does not support overlapping calls")
        history_text = ""
        for h in self.history:
            who = "무중" if h["speaker"] == "mujung" else "아이"
            history_text += f"{who}: {h['text']}\n"
        user = (f"[지금까지 대화]\n{history_text}\n"
                f"[무중의 말] {mujung_say}\n\n아이로서 다음 한 마디를 해줘.")
        call = {"call_index": len(self.calls) + 1, "status": "STARTED"}
        self.calls.append(call)
        self._in_flight = True
        try:
            text, usage = await self._recommend(
                "", self.model, self.system, user,
                max_tokens=self.settings["max_completion_tokens"],
                reasoning_effort=self.settings["reasoning_effort"],
                max_attempts=self.settings["max_attempts"],
                timeout_s=self.settings["timeout_s"],
                max_retry_tokens=self.settings["max_retry_tokens"])
            # Also guard injected/custom adapters: never turn failures into
            # plausible child dialogue or commit them to the conversation.
            if not isinstance(text, str) or not text.strip():
                attempts = usage.get("attempts", []) if isinstance(usage, dict) else []
                raise LunaCallError("INVALID_CHILD_TEXT", attempts)
            text = text.strip()
            self.history.extend([{"speaker": "mujung", "text": mujung_say},
                                 {"speaker": "child", "text": text}])
            call.update(status="OK", usage=usage)
            return text
        except LunaCallError as exc:
            call.update(status="FAILED", error=exc.as_dict())
            raise
        except asyncio.CancelledError:
            call.update(status="CANCELLED", error={"code": "CANCELLED", "usage_complete": False})
            raise
        except Exception as exc:
            # Exception messages may contain user text or credentials.
            call.update(status="FAILED", error={"code": "UNEXPECTED_SIMULATOR_ERROR",
                                                 "type": type(exc).__name__})
            raise
        finally:
            self._in_flight = False

    def diagnostics_snapshot(self) -> dict:
        """Metadata only: no child/profile text, prompts, or API credentials."""
        return deepcopy({"version": "4.2", "settings": self.settings,
                         "fallback_used": False, "calls": self.calls})

    def reset(self):
        if self._in_flight:
            raise RuntimeError("Cannot reset while a child reply is in flight")
        self.history = []
        self.calls = []


# --- 테스트킷 v0.1 프로파일 (load_profiles()로 로드) ---
# 하위 호환용: PROFILES는 첫 접근 시 로드됨
_PROFILES_CACHE: dict | None = None


def get_profiles() -> dict:
    global _PROFILES_CACHE
    if _PROFILES_CACHE is None:
        _PROFILES_CACHE = load_profiles()
    return _PROFILES_CACHE


PROFILES = {}  # deprecated, use get_profiles()
