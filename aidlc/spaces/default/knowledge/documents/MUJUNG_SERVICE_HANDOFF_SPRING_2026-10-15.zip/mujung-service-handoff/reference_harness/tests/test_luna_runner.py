"""Offline subprocess contract tests. The fake CLI never contacts a network."""
import asyncio
import json
import os
from pathlib import Path
import sys
import tempfile
import time
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from luna_runner import LunaCallError, recommend


def response(content="정상 응답.", finish="stop", **message_extra):
    return {"id": "chatcmpl-test", "model": "gpt-6-luna",
            "choices": [{"finish_reason": finish,
                         "message": {"content": content, **message_extra}}],
            "usage": {"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15,
                      "completion_tokens_details": {"reasoning_tokens": 3}}}


class RunnerTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.calls = self.root / "calls.jsonl"
        self.pid = self.root / "pid"
        self.cli = self.root / "fake_cli.py"

    def tearDown(self):
        self.temp.cleanup()

    def fake(self, plans):
        config = self.root / "plans.json"
        config.write_text(json.dumps(plans), encoding="utf-8")
        self.cli.write_text(
            "import json,os,pathlib,sys,time\n"
            + "config=pathlib.Path(" + repr(str(config)) + ")\n"
            + "calls=pathlib.Path(" + repr(str(self.calls)) + ")\n"
            + "pid=pathlib.Path(" + repr(str(self.pid)) + ")\n"
            + "pid.write_text(str(os.getpid()))\n"
            + "old=calls.read_text().splitlines() if calls.exists() else []\n"
            + "payload=json.loads(sys.argv[4])\n"
            + "with calls.open('a') as f: f.write(json.dumps(payload)+'\\n')\n"
            + "plans=json.loads(config.read_text()); plan=plans[min(len(old),len(plans)-1)]\n"
            + "time.sleep(plan.get('sleep',0))\n"
            + "if 'raw' in plan: sys.stdout.write(plan['raw'])\n"
            + "elif 'data' in plan: sys.stdout.write(json.dumps(plan['data']))\n"
            + "sys.stderr.write(plan.get('stderr',''))\n"
            + "sys.exit(plan.get('returncode',0))\n", encoding="utf-8")

    async def call(self, **kwargs):
        return await recommend("SECRET_KEY", "gpt-6-luna", "SECRET_SYSTEM_PROMPT", "SECRET_USER_PROMPT",
                               cli_path=self.cli, **kwargs)

    def requests(self):
        return [json.loads(line) for line in self.calls.read_text().splitlines()] if self.calls.exists() else []

    def assert_gone(self):
        pid = int(self.pid.read_text())
        with self.assertRaises(ProcessLookupError):
            os.kill(pid, 0)

    async def test_wire_mapping_default_and_no_credential_forwarding(self):
        self.fake([{"data": response()}])
        text, info = await self.call(max_tokens=123)
        self.assertEqual(text, "정상 응답.")
        payload = self.requests()[0]
        self.assertEqual(payload["max_completion_tokens"], 123)
        self.assertNotIn("max_tokens", payload)
        self.assertNotIn("reasoning_effort", payload)
        self.assertNotIn("SECRET_KEY", json.dumps(payload))
        self.assertTrue(info["usage_complete"])
        self.assertIsNone(info["attempts"][0]["http_status"])

    async def test_length_empty_budget_doubles_then_succeeds_all_usage(self):
        self.fake([{"data": response("", "length")}, {"data": response()}])
        text, info = await self.call(max_tokens=120, max_retry_tokens=240, reasoning_effort="medium")
        self.assertEqual([p["max_completion_tokens"] for p in self.requests()], [120, 240])
        self.assertEqual([p["reasoning_effort"] for p in self.requests()], ["medium", "medium"])
        self.assertEqual(info["attempt_count"], 2)
        self.assertEqual(info["retry_count"], 1)
        self.assertEqual(info["prompt_tokens"], 20)
        self.assertEqual(info["completion_tokens"], 10)
        self.assertEqual(info["reasoning_tokens"], 6)
        self.assertEqual(info["attempts"][0]["classification"], "OUTPUT_BUDGET_EXHAUSTED")

    async def test_explicit_max_effort_is_preserved(self):
        self.fake([{"data": response()}])
        await self.call(reasoning_effort="max")
        self.assertEqual(self.requests()[0]["reasoning_effort"], "max")

    async def test_partial_length_is_not_success_and_no_cap_means_no_retry(self):
        self.fake([{"data": response("SECRET_PARTIAL_CONTENT", "length")}])
        with self.assertRaises(LunaCallError) as raised:
            await self.call(max_tokens=120)
        self.assertEqual(raised.exception.code, "OUTPUT_BUDGET_EXHAUSTED")
        self.assertEqual(len(self.requests()), 1)
        self.assertEqual(raised.exception.attempts[0]["content_length"], len("SECRET_PARTIAL_CONTENT"))
        self.assertNotIn("SECRET_PARTIAL_CONTENT", json.dumps(raised.exception.as_dict()))

    async def test_length_cap_exhaustion_and_failed_usage(self):
        self.fake([{"data": response("", "length")}])
        with self.assertRaises(LunaCallError) as raised:
            await self.call(max_tokens=120, max_retry_tokens=240, max_attempts=3)
        self.assertEqual(raised.exception.code, "OUTPUT_BUDGET_EXHAUSTED")
        self.assertEqual(len(self.requests()), 2)
        self.assertEqual(raised.exception.as_dict()["usage_summary"]["completion_tokens"], 10)

    async def test_stop_empty_whitespace_and_null_retry_without_budget_change(self):
        self.fake([{"data": response(" ")}, {"data": response(None)}, {"data": response()}])
        text, info = await self.call(max_tokens=100, max_retry_tokens=200)
        self.assertEqual(text, "정상 응답.")
        self.assertEqual([p["max_completion_tokens"] for p in self.requests()], [100, 100, 100])
        self.assertEqual([a["classification"] for a in info["attempts"]], ["EMPTY_CONTENT", "EMPTY_CONTENT", "SUCCESS"])

    async def test_empty_attempt_limit(self):
        self.fake([{"data": response("")}])
        with self.assertRaises(LunaCallError) as raised:
            await self.call(max_attempts=2)
        self.assertEqual(raised.exception.code, "EMPTY_CONTENT")
        self.assertEqual(raised.exception.as_dict()["retry_count"], 1)

    async def test_refusal_content_filter_and_tool_calls_never_retry(self):
        cases = [(response(None, refusal="SECRET_REFUSAL"), "REFUSAL"),
                 (response(None, "content_filter"), "CONTENT_FILTER"),
                 (response(None, "tool_calls", tool_calls=[{"arguments": "SECRET_TOOL_ARGS"}]), "UNEXPECTED_TOOL_CALL")]
        for data, code in cases:
            with self.subTest(code=code):
                if self.calls.exists():
                    self.calls.unlink()
                self.fake([{"data": data}])
                with self.assertRaises(LunaCallError) as raised:
                    await self.call()
                self.assertEqual(raised.exception.code, code)
                self.assertEqual(len(self.requests()), 1)
                self.assertNotIn("SECRET_", json.dumps(raised.exception.as_dict()))

    async def test_invalid_json_shape_content_and_finish_reason(self):
        cases = [({"raw": "not json SECRET_BODY"}, "INVALID_JSON"),
                 ({"data": {"choices": []}}, "INVALID_RESPONSE"),
                 ({"data": response([])}, "INVALID_CONTENT_TYPE"),
                 ({"data": response("text", None)}, "UNKNOWN_FINISH_REASON")]
        for plan, code in cases:
            with self.subTest(code=code):
                if self.calls.exists():
                    self.calls.unlink()
                self.fake([plan])
                with self.assertRaises(LunaCallError) as raised:
                    await self.call()
                self.assertEqual(raised.exception.code, code)
                self.assertEqual(len(self.requests()), 1)
                self.assertNotIn("SECRET_BODY", json.dumps(raised.exception.as_dict()))

    async def test_nonzero_cli_stderr_is_not_exposed_and_usage_is_incomplete(self):
        self.fake([{"returncode": 1, "stderr": "SECRET_CREDENTIALS SECRET_PROMPT"}, {"data": response()}])
        _, info = await self.call(max_attempts=2)
        self.assertEqual(info["attempts"][0]["classification"], "TRANSPORT_ERROR")
        self.assertFalse(info["usage_complete"])
        self.assertIsNone(info["completion_tokens"])
        self.assertEqual(info["last_attempt_usage"]["completion_tokens"], 5)
        self.assertNotIn("SECRET_", json.dumps(info))
        self.assertEqual(info["attempts"][0]["stdout_bytes"], 0)
        self.assertGreater(info["attempts"][0]["stderr_bytes"], 0)

    async def test_explicit_authentication_error_never_retries(self):
        self.fake([{"returncode": 1, "data": {"error": {"code": "invalid_api_key", "message": "SECRET_KEY"}}}])
        with self.assertRaises(LunaCallError) as raised:
            await self.call()
        self.assertEqual(raised.exception.code, "AUTHENTICATION_ERROR")
        self.assertEqual(len(self.requests()), 1)
        self.assertIsNone(raised.exception.attempts[0]["http_status"])
        self.assertNotIn("SECRET_KEY", json.dumps(raised.exception.as_dict()))

    async def test_structured_rate_limit_server_errors_retry(self):
        self.fake([{"returncode": 1, "data": {"error": {"code": "rate_limit_exceeded"}}},
                   {"returncode": 1, "data": {"error": {"type": "server_error"}, "http_status": 503}},
                   {"data": response()}])
        _, info = await self.call()
        self.assertEqual([a["classification"] for a in info["attempts"]], ["RATE_LIMIT_EXCEEDED", "SERVER_ERROR", "SUCCESS"])
        self.assertIsNone(info["attempts"][0]["http_status"])
        self.assertEqual(info["attempts"][1]["http_status"], 503)

    async def test_timeout_kills_and_reaps_process(self):
        self.fake([{"sleep": 10, "data": response()}])
        started = time.monotonic()
        with self.assertRaises(LunaCallError) as raised:
            await self.call(timeout_s=.25)
        self.assertEqual(raised.exception.code, "TIMEOUT")
        self.assertLess(time.monotonic() - started, 1.5)
        self.assertEqual(len(self.requests()), 1)
        self.assert_gone()

    async def test_one_deadline_includes_retry_backoff(self):
        self.fake([{"data": response("")}, {"sleep": 10, "data": response()}])
        started = time.monotonic()
        with self.assertRaises(LunaCallError) as raised:
            await self.call(timeout_s=.45)
        self.assertEqual(raised.exception.code, "TIMEOUT")
        self.assertEqual(len(self.requests()), 2)
        self.assertLess(time.monotonic() - started, 1.1)
        self.assert_gone()

    async def test_cancellation_kills_and_reaps_process(self):
        self.fake([{"sleep": 10, "data": response()}])
        task = asyncio.create_task(self.call(timeout_s=20))
        until = time.monotonic() + 2
        while not self.pid.exists() and time.monotonic() < until:
            await asyncio.sleep(.01)
        self.assertTrue(self.pid.exists())
        task.cancel()
        with self.assertRaises(asyncio.CancelledError):
            await task
        self.assert_gone()

    async def test_missing_usage_stays_unknown(self):
        data = response()
        del data["usage"]
        self.fake([{"data": data}])
        _, info = await self.call()
        self.assertFalse(info["usage_complete"])
        self.assertIsNone(info["reasoning_tokens"])

    async def test_diagnostics_omit_request_and_response_content(self):
        self.fake([{"data": response("SECRET_GENERATED_TEXT")}])
        text, info = await self.call()
        self.assertEqual(text, "SECRET_GENERATED_TEXT")
        self.assertNotIn("SECRET_", json.dumps(info))
        self.assertNotIn("messages", info)

    async def test_invalid_arguments_do_not_start_process(self):
        self.fake([{"data": response()}])
        for kwargs in ({"max_tokens": True}, {"max_attempts": 0}, {"timeout_s": -1},
                       {"reasoning_effort": "invalid"}, {"max_tokens": 200, "max_retry_tokens": 100}):
            with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
                await self.call(**kwargs)
        self.assertFalse(self.calls.exists())

    def test_error_can_be_constructed_by_child_and_is_copy_safe(self):
        attempts = [{"usage": {"completion_tokens": 5}}]
        error = LunaCallError("INVALID_CHILD_TEXT", attempts)
        attempts[0]["usage"]["completion_tokens"] = 99
        self.assertEqual(error.attempts[0]["usage"]["completion_tokens"], 5)
        self.assertEqual(str(error), "INVALID_CHILD_TEXT")
        self.assertEqual(error.as_dict()["attempt_count"], 1)


if __name__ == "__main__":
    unittest.main()
