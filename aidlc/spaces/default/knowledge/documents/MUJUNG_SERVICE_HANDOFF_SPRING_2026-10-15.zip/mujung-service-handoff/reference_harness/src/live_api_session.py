"""Continuous Live audio transport; transcript fragments are never turn-completion signals.

Offline imports require only Python 3.9+ stdlib. connect() lazily loads the original
custom.openai credential connector and websockets; inject websocket= for offline tests.
No credential, instruction text, or base64 audio is included in metadata logs.
"""
from __future__ import annotations

import asyncio
import base64
from collections import deque
import copy
import importlib
import json
import math
import os
from pathlib import Path
import re
import struct
import sys
import time

LIVE_WS_URL = "wss://api.openai.com/v1/live/sessions"


class LiveSessionError(RuntimeError):
    pass


def _identifier(value):
    return value if isinstance(value, str) and re.fullmatch(r"[\w.:-]{1,512}", value) else None


def _numeric_usage(value):
    if isinstance(value, dict):
        return {k: _numeric_usage(v) for k, v in value.items()
                if _identifier(k) and isinstance(v, (dict, int, float))}
    return value if isinstance(value, (int, float)) and math.isfinite(value) else None


class LiveApiSession:
    def __init__(self, instructions: str, model="gpt-live-1", delegation="client", *,
                 sample_rate=16000, max_duration_sec=480, start_timeout=30, close_timeout=5,
                 cloudflare_101_compat=True):
        if type(sample_rate) is not int or sample_rate not in (16000, 24000):
            raise ValueError("Declare PCM16LE mono with integer sample rate 16000 or 24000 Hz.")
        if any(type(v) not in (int, float) or not math.isfinite(v) or v <= 0
               for v in (max_duration_sec, start_timeout, close_timeout)) or max_duration_sec > 480:
            raise ValueError("Durations and timeouts must be finite positive numbers; capture is at most 480 seconds.")
        self.instructions, self.model, self.delegation = instructions, model, delegation
        self.sample_rate, self.frame_bytes, self.frame_seconds = sample_rate, sample_rate // 50 * 2, 0.02
        self.connection_compat = {"enabled": bool(cloudflare_101_compat), "installed": False, "repairs": 0, "scope": "connection"}
        self.max_duration_sec, self.start_timeout, self.close_timeout = max_duration_sec, start_timeout, close_timeout
        self.audio_format = {"type": "audio/pcm", "rate": sample_rate}
        self.ws = self.session_id = None
        self._listen_task = self._pump_task = None
        self._started, self._closed, self._failed = asyncio.Event(), asyncio.Event(), asyncio.Event()
        self._send_lock, self._close_lock = asyncio.Lock(), asyncio.Lock()
        self._error_code, self._finalization, self._started_payload, self._closed_payload = None, None, None, None
        self._closing, self._attempted = False, False
        self._pending, self._pending_bytes = deque(), 0
        self._input_pcm, self._output_pcm = bytearray(), bytearray()
        self.transcript_events, self.raw_event_records, self.output_audio_chunks = [], [], []
        self._seq, self._output_revision, self._started_at = 0, 0, 0.0
        self._last_transcript_at = self._last_voice_until = self._playback_until = 0.0
        self.pump_metrics = {"frames_sent": 0, "child_frames": 0, "silence_frames": 0,
                             "max_lag_seconds": 0.0, "late_frames": 0, "last_sent_monotonic": None}

    def _configure_cloudflare_compat(self, protocol, headers_factory):
        if not self.connection_compat["enabled"] or getattr(protocol, "_mujung_compat_wrapped", False):
            return
        original = protocol.process_response
        def process_response(response):
            if response.status_code == 101:
                upgrades = [v.lower() for v in response.headers.get_all("Upgrade")]
                conns = [v.lower() for v in response.headers.get_all("Connection")]
                if "websocket" in upgrades and "upgrade" not in conns:
                    headers = [(k, v) for k, v in response.headers.raw_items() if k.lower() != "connection"]
                    response.headers = headers_factory(headers + [("Connection", "Upgrade")])
                    self.connection_compat["repairs"] += 1
            return original(response)
        protocol.process_response, protocol._mujung_compat_wrapped = process_response, True
        self.connection_compat["installed"] = True

    async def _open_websocket(self):
        try:
            from websockets.asyncio.client import ClientConnection, connect
            from websockets.datastructures import Headers
        except ImportError:
            raise LiveSessionError("Missing dependency: install a websockets version providing websockets.asyncio.client.") from None
        connector_dir = "/opt/hatch/skills/skill-creator/bin"
        added = connector_dir not in sys.path and Path(connector_dir).is_dir()
        if added:
            sys.path.insert(0, connector_dir)
        try:
            dc = importlib.import_module("dynamic_credentials")
        except ImportError:
            raise LiveSessionError("Original custom.openai connector is unavailable; dynamic_credentials is required for a real connection.") from None
        finally:
            if added:
                sys.path.remove(connector_dir)
        entry = await asyncio.to_thread(dc.dynamic_credential_entry, "custom.openai")
        token = entry.get("surrogate") if isinstance(entry, dict) else None
        if not isinstance(token, str) or not token:
            raise LiveSessionError("The custom.openai connector did not provide a credential.")
        def connection_factory(protocol, **kwargs):
            self._configure_cloudflare_compat(protocol, Headers)
            return ClientConnection(protocol, **kwargs)
        return await connect(LIVE_WS_URL, additional_headers={"Authorization": "Bearer " + token},
                             proxy=os.environ.get("HTTPS_PROXY") or None,
                             create_connection=connection_factory,
                             max_size=16 * 1024 * 1024, open_timeout=self.start_timeout, close_timeout=2)

    async def connect(self, *, websocket=None):
        if self._attempted:
            raise LiveSessionError("Create a new session object for each connection attempt.")
        self._attempted = True
        try:
            self.ws = websocket if websocket is not None else await self._open_websocket()
            self._listen_task = asyncio.create_task(self._listen())
            await self._send({"type": "session.start", "session": {"model": self.model,
                "instructions": self.instructions, "delegation": {"type": self.delegation},
                "audio": {"format": self.audio_format}}})
            await self._wait_for("session.started", self.start_timeout)
            self._started_at = time.monotonic()
            self._pump_task = asyncio.create_task(self._audio_pump())
            return self
        except BaseException:
            self._fail("CONNECT_FAILED")
            await self._cleanup_transport()
            raise

    def _fail(self, code):
        if self._error_code is None:
            self._error_code = code
        self._failed.set()
        while self._pending:
            job = self._pending.popleft()
            if not job["done"].done():
                job["done"].set_exception(LiveSessionError(self._error_code))
        self._pending_bytes = 0

    def ensure_healthy(self):
        if self._error_code:
            raise LiveSessionError(self._error_code)

    async def _send(self, event):
        async with self._send_lock:
            if event["type"] == "session.input_audio.append" and (self._closing or self._failed.is_set()):
                return False
            try:
                await asyncio.wait_for(self.ws.send(json.dumps(event)), timeout=5)
            except asyncio.CancelledError:
                raise
            except Exception:
                self._fail("SOCKET_SEND_FAILED")
                raise LiveSessionError("SOCKET_SEND_FAILED") from None
            self._record(event, "sent")
            return True

    def _record(self, event, direction):
        if len(self.raw_event_records) >= 100000:
            self._fail("EVENT_CAPTURE_LIMIT")
            raise LiveSessionError("EVENT_CAPTURE_LIMIT")
        self._seq += 1
        record = {"seq": self._seq, "direction": direction, "type": event.get("type"),
                  "event_id": _identifier(event.get("event_id")), "received_monotonic": time.monotonic()}
        for key in ("start_ms", "end_ms"):
            if isinstance(event.get(key), (int, float)) and math.isfinite(event[key]):
                record[key] = event[key]
        if _identifier(event.get("client_event_id")):
            record["client_event_id"] = event["client_event_id"]
        if event.get("type") == "error" and isinstance(event.get("error"), dict):
            record["error"] = {k: event["error"][k] for k in ("code", "type", "client_event_id") if _identifier(event["error"].get(k))}
        self.raw_event_records.append(record)
        return record

    def _handle_event(self, event):
        try:
            self._process_event(event)
        except LiveSessionError as exc:
            self._fail(str(exc))
            raise

    def _process_event(self, event):
        if not isinstance(event, dict) or not isinstance(event.get("type"), str):
            raise LiveSessionError("MALFORMED_SERVER_EVENT")
        meta = self._record(event, "received")
        kind, now = event["type"], meta["received_monotonic"]
        if kind == "error":
            self._fail("LIVE_SERVER_ERROR")
            return
        if kind == "session.started":
            session = event.get("session", {})
            if not isinstance(session, dict):
                raise LiveSessionError("MALFORMED_SESSION_STARTED")
            resolved = session.get("audio", {}).get("format") if isinstance(session.get("audio", {}), dict) else None
            if resolved is not None and resolved != self.audio_format:
                raise LiveSessionError("RESOLVED_AUDIO_FORMAT_MISMATCH")
            self.session_id = session.get("id")
            self._started_payload = {"session_id": self.session_id, "audio_format": resolved or self.audio_format}
            self._started.set()
        elif kind == "session.closed":
            session = event.get("session") if isinstance(event.get("session"), dict) else {}
            self._closed_payload = {"usage": _numeric_usage(event.get("usage", session.get("usage", {})))}
            self._closed.set()
            if not self._closing:
                self._fail("UNEXPECTED_SESSION_CLOSED")
        elif kind in ("session.input_transcript.delta", "session.output_transcript.delta"):
            delta = event.get("delta")
            if isinstance(delta, dict):
                delta = delta.get("transcript")
            if not isinstance(delta, str):
                raise LiveSessionError("MALFORMED_TRANSCRIPT_DELTA")
            speaker = "mujung" if kind == "session.output_transcript.delta" else "child"
            self.transcript_events.append({**meta, "speaker": speaker, "delta": delta,
                                          "start_ms": event.get("start_ms"), "end_ms": event.get("end_ms")})
            if speaker == "mujung":
                self._output_revision += 1
                self._last_transcript_at = now
        elif kind == "session.output_audio.delta":
            delta = event.get("delta")
            if isinstance(delta, dict):
                delta = delta.get("audio")
            try:
                if not isinstance(delta, str) or not delta:
                    raise ValueError()
                pcm = base64.b64decode(delta, validate=True)
                if not pcm or len(pcm) % 2:
                    raise ValueError()
            except (ValueError, TypeError):
                raise LiveSessionError("MALFORMED_OUTPUT_AUDIO") from None
            if len(self._output_pcm) + len(pcm) > self.sample_rate * 2 * self.max_duration_sec:
                raise LiveSessionError("OUTPUT_AUDIO_CAPTURE_LIMIT")
            duration = len(pcm) / (self.sample_rate * 2)
            playback_start = max(now, self._playback_until)
            self._playback_until = playback_start + duration
            energy = sum(abs(s[0]) for s in struct.iter_unpack("<h", pcm)) / (len(pcm) // 2)
            if energy > 500:  # A heuristic only, not VAD or a turn-completion guarantee.
                self._last_voice_until = self._playback_until
            self.output_audio_chunks.append({**meta, "byte_offset": len(self._output_pcm), "byte_count": len(pcm),
                "duration_sec": duration, "mean_abs_amplitude": energy,
                "estimated_playback_start": playback_start, "estimated_playback_end": self._playback_until})
            self._output_pcm.extend(pcm)

    async def _listen(self):
        try:
            async for raw in self.ws:
                self._handle_event(json.loads(raw))
                if self._closed.is_set() or self._failed.is_set():
                    return
            if not self._closed.is_set():
                self._fail("UNEXPECTED_SOCKET_CLOSE")
        except asyncio.CancelledError:
            raise
        except LiveSessionError as exc:
            self._fail(str(exc))
        except Exception:
            self._fail("RECEIVER_FAILED")

    async def _wait_for(self, event_type, timeout=30):
        if event_type not in ("session.started", "session.closed"):
            raise ValueError("Only lifecycle signals have waiters; transcripts use append-only cursors.")
        signal = self._started if event_type == "session.started" else self._closed
        signal_task, failure_task = asyncio.create_task(signal.wait()), asyncio.create_task(self._failed.wait())
        try:
            done, _ = await asyncio.wait((signal_task, failure_task), timeout=timeout, return_when=asyncio.FIRST_COMPLETED)
            self.ensure_healthy()
            if not done:
                raise TimeoutError("Timed out waiting for " + event_type)
            return self._started_payload if event_type == "session.started" else self._closed_payload
        finally:
            for task in (signal_task, failure_task):
                task.cancel()
            await asyncio.gather(signal_task, failure_task, return_exceptions=True)

    async def _audio_pump(self):
        deadline = time.monotonic()
        try:
            while not self._closing and not self._closed.is_set():
                self.ensure_healthy()
                await asyncio.sleep(max(0, deadline - time.monotonic()))
                now = time.monotonic()
                if now - self._started_at >= self.max_duration_sec:
                    raise LiveSessionError("SESSION_DURATION_LIMIT")
                lag = max(0.0, now - deadline)
                self.pump_metrics["max_lag_seconds"] = max(self.pump_metrics["max_lag_seconds"], lag)
                self.pump_metrics["late_frames"] += int(lag > self.frame_seconds)
                job = self._pending[0] if self._pending else None
                part = job["pcm"][job["offset"]:job["offset"] + self.frame_bytes] if job else b""
                frame = part.ljust(self.frame_bytes, b"\x00")
                if not await self._send({"type": "session.input_audio.append", "audio": base64.b64encode(frame).decode("ascii")}):
                    return
                self._input_pcm.extend(frame)
                metrics = self.pump_metrics
                metrics["frames_sent"] += 1
                metrics["child_frames" if job else "silence_frames"] += 1
                metrics["last_sent_monotonic"] = time.monotonic()
                if self._failed.is_set():
                    return
                if job:
                    job["offset"] += len(part)
                    self._pending_bytes -= len(part)
                    if job["offset"] == len(job["pcm"]):
                        self._pending.popleft()
                        if not job["done"].done():
                            job["done"].set_result({"sent_bytes": len(job["pcm"]), "last_sent_monotonic": metrics["last_sent_monotonic"]})
                # Do not burst catch-up frames after a blocked event loop or slow socket.
                next_deadline, now = deadline + self.frame_seconds, time.monotonic()
                deadline = now + self.frame_seconds if next_deadline < now else next_deadline
        except asyncio.CancelledError:
            raise
        except LiveSessionError as exc:
            self._fail(str(exc))
        except Exception:
            self._fail("AUDIO_PUMP_FAILED")

    async def send_audio(self, pcm16_bytes, sample_rate=16000):
        self.ensure_healthy()
        if not self._started.is_set() or self._closing or self._closed.is_set():
            raise LiveSessionError("Audio requires an active, started session.")
        if sample_rate != self.sample_rate or not isinstance(pcm16_bytes, (bytes, bytearray, memoryview)):
            raise ValueError("Provide raw PCM16LE mono bytes matching the session's declared sample rate.")
        pcm = bytes(pcm16_bytes)
        if not pcm or len(pcm) % 2 or pcm.startswith((b"RIFF", b"RF64", b"OggS", b"fLaC", b"ID3")):
            raise ValueError("Expected nonempty sample-aligned raw PCM, not an audio container.")
        if len(self._pending) >= 8 or self._pending_bytes + len(pcm) > self.sample_rate * 2 * 60:
            raise ValueError("Pending child audio exceeds the bounded 60-second queue.")
        future = asyncio.get_running_loop().create_future()
        future.add_done_callback(lambda f: None if f.cancelled() else f.exception())
        self._pending.append({"pcm": pcm, "offset": 0, "done": future})
        self._pending_bytes += len(pcm)
        try:
            return await asyncio.shield(future)  # Local last-frame send, not a server acknowledgment.
        except asyncio.CancelledError:
            self._fail("AUDIO_SEND_CANCELLED")
            raise

    async def send_instructions(self, text):
        self.ensure_healthy()
        if not self._started.is_set() or self._closing or not isinstance(text, str) or not text.strip():
            raise ValueError("Instructions require an active session and nonempty text (API limit: 500 tokens).")
        await self._send({"type": "session.instructions.append", "content": text, "delegation_id": None})

    async def interrupt(self):
        raise NotImplementedError("session.interrupt is not a supported Live event; do not use it as a turn boundary.")

    def clear_transcripts(self):
        raise RuntimeError("Transcripts are append-only. Save transcript_cursor() and use output_since(cursor).")

    def transcript_cursor(self):
        return len(self.transcript_events)

    def output_since(self, cursor):
        if not isinstance(cursor, int) or not 0 <= cursor <= len(self.transcript_events):
            raise ValueError("Invalid transcript event cursor.")
        return "".join(e["delta"] for e in self.transcript_events[cursor:] if e["speaker"] == "mujung")

    @property
    def output_revision(self):
        return self._output_revision

    def output_activity(self):
        self.ensure_healthy()
        return {"last_transcript_at": self._last_transcript_at, "last_voice_until": self._last_voice_until,
                "playback_until": self._playback_until, "now": time.monotonic()}

    def get_output_transcript(self):
        return self.output_since(0)

    def get_input_transcript(self):
        return "".join(e["delta"] for e in self.transcript_events if e["speaker"] == "child")

    def get_output_pcm(self):
        return bytes(self._output_pcm)

    def get_input_pcm(self):
        return bytes(self._input_pcm)

    def capture_snapshot(self):
        return copy.deepcopy({"session_id": self.session_id, "model": self.model, "audio_format": self.audio_format,
            "connection_compat": self.connection_compat,
            "transcript_events": self.transcript_events, "transcript": {"child": self.get_input_transcript(), "mujung": self.get_output_transcript()},
            "raw_event_records": self.raw_event_records, "input_audio": {"bytes": len(self._input_pcm),
                "frames": self.pump_metrics["frames_sent"], "duration_sec": len(self._input_pcm)/(self.sample_rate*2)},
            "output_audio": {"bytes": len(self._output_pcm), "duration_sec": len(self._output_pcm)/(self.sample_rate*2), "chunks": self.output_audio_chunks},
            "pump_metrics": self.pump_metrics, "health": {"ok": self._error_code is None, "error_code": self._error_code},
            "playback_is_estimated_not_actual": True, "finalization": self._finalization})

    async def _cleanup_transport(self):
        tasks = [t for t in (self._listen_task, self._pump_task) if t is not None]
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
        if self.ws is not None:
            try:
                await asyncio.wait_for(self.ws.close(), timeout=min(3, self.close_timeout))
            except Exception:
                pass

    async def close(self):
        async with self._close_lock:
            if self._finalization is not None:
                return copy.deepcopy(self._finalization)
            self._closing = True
            status = "NOT_CONNECTED" if self.ws is None else "FAILED" if self._error_code else "CLOSED"
            cancelled = None
            try:
                if self.ws is not None and not self._closed.is_set():
                    await self._send({"type": "session.close"})
                    await self._wait_for("session.closed", self.close_timeout)
            except asyncio.CancelledError as exc:
                cancelled, status = exc, "CANCELLED"
                self._fail("CLOSE_CANCELLED")
            except TimeoutError:
                status = "CLOSE_TIMEOUT"
                self._fail("CLOSE_TIMEOUT")
            except Exception:
                status = "FAILED"
            cleanup = asyncio.create_task(self._cleanup_transport())
            try:
                await asyncio.shield(cleanup)
            except asyncio.CancelledError as exc:
                cancelled, status = exc, "CANCELLED"
                self._fail("CLOSE_CANCELLED")
                await cleanup
            while self._pending:
                job = self._pending.popleft()
                if not job["done"].done():
                    job["done"].set_exception(LiveSessionError("SESSION_CLOSING"))
            self._pending_bytes = 0
            self._finalization = {"status": status, "session_id": self.session_id,
                "server_closed_received": self._closed.is_set(), "error_code": self._error_code,
                "usage": (self._closed_payload or {}).get("usage", {})}
            if cancelled is not None:
                raise cancelled
            return copy.deepcopy(self._finalization)
