"""Child simulation failure regressions; every model call uses an async fake."""
import asyncio
from copy import deepcopy
import json
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from luna_runner import LunaCallError
from probe_child import ChildSimulator


PROFILE = {"id": "C00", "name": "합성 기준형", "behavior": "관련 있는 대답"}


class ChildSimulatorTests(unittest.IsolatedAsyncioTestCase):
    async def test_defaults_are_forwarded_and_success_commits_one_exchange(self):
        requests = []
        usage = {"attempts": [{"attempt": 1, "finish_reason": "stop"}], "total_tokens": 90}

        async def fake(*args, **kwargs):
            requests.append((args, kwargs))
            return "  블록으로 집을 만들었어.  ", deepcopy(usage)

        sim = ChildSimulator(PROFILE, recommend_fn=fake)
        answer = await sim.arespond("무엇을 만들었니?")
        self.assertEqual(answer, "블록으로 집을 만들었어.")
        self.assertEqual(len(requests), 1)
        args, options = requests[0]
        self.assertEqual(args[0], "")
        self.assertEqual(args[1], "gpt-6-luna")
        self.assertEqual(options, {"max_tokens": 2048, "reasoning_effort": "medium",
                                   "max_attempts": 2, "timeout_s": 30.0,
                                   "max_retry_tokens": 4096})
        self.assertEqual(sim.history, [{"speaker": "mujung", "text": "무엇을 만들었니?"},
                                       {"speaker": "child", "text": answer}])
        snapshot = sim.diagnostics_snapshot()
        self.assertFalse(snapshot["fallback_used"])
        self.assertEqual(snapshot["calls"][0]["status"], "OK")
        self.assertEqual(snapshot["calls"][0]["usage"], usage)

    async def test_explicit_model_and_call_settings_are_preserved(self):
        received = []

        async def fake(*args, **kwargs):
            received.append((args, kwargs))
            return "응.", {}

        sim = ChildSimulator(PROFILE, model="gpt-6-luna", max_completion_tokens=3072,
                             reasoning_effort="low", max_attempts=1, timeout_s=4.0,
                             max_retry_tokens=6144, recommend_fn=fake)
        await sim.arespond("이야기해 줄래?")
        self.assertEqual(received[0][1], {"max_tokens": 3072, "reasoning_effort": "low",
                                         "max_attempts": 1, "timeout_s": 4.0,
                                         "max_retry_tokens": 6144})

    async def test_current_turn_is_not_duplicated_in_previous_history(self):
        prompts = []
        replies = iter(["첫 번째 대답.", "두 번째 대답."])

        async def fake(*args, **kwargs):
            prompts.append(args[3])
            return next(replies), {}

        sim = ChildSimulator(PROFILE, recommend_fn=fake)
        await sim.arespond("첫 번째 질문.")
        await sim.arespond("두 번째 질문.")
        self.assertEqual(prompts[1].count("첫 번째 질문."), 1)
        self.assertEqual(prompts[1].count("첫 번째 대답."), 1)
        self.assertEqual(prompts[1].count("두 번째 질문."), 1)
        self.assertEqual([row["speaker"] for row in sim.history],
                         ["mujung", "child", "mujung", "child"])
        self.assertEqual([row["call_index"] for row in sim.calls], [1, 2])

    async def test_luna_failure_is_explicit_without_filler_or_history_commit(self):
        failure = LunaCallError("EMPTY_CONTENT", [{"attempt": 1, "finish_reason": "length"}])

        async def fake(*args, **kwargs):
            raise failure

        sim = ChildSimulator(PROFILE, recommend_fn=fake)
        with self.assertRaises(LunaCallError) as raised:
            await sim.arespond("어떤 놀이를 했니?")
        self.assertIs(raised.exception, failure)
        self.assertEqual(sim.history, [])
        self.assertEqual(sim.calls[0]["status"], "FAILED")
        self.assertEqual(sim.calls[0]["error"], failure.as_dict())
        self.assertFalse(sim.diagnostics_snapshot()["fallback_used"])

    async def test_custom_adapter_empty_null_and_nontext_are_rejected(self):
        for invalid in ("", " \n\t ", None, [], {"text": "응"}):
            with self.subTest(value=repr(invalid)):
                async def fake(*args, **kwargs):
                    return invalid, {"attempts": [{"attempt": 1}]}

                sim = ChildSimulator(PROFILE, recommend_fn=fake)
                with self.assertRaises(LunaCallError) as raised:
                    await sim.arespond("무슨 일이 있었니?")
                self.assertEqual(raised.exception.code, "INVALID_CHILD_TEXT")
                self.assertEqual(sim.history, [])
                self.assertEqual(sim.calls[0]["status"], "FAILED")

    async def test_failed_exchange_does_not_poison_next_attempt_history(self):
        prompts = []

        async def fake(*args, **kwargs):
            prompts.append(args[3])
            if len(prompts) == 2:
                raise LunaCallError("EMPTY_CONTENT")
            return "처음 대답." if len(prompts) == 1 else "다음 대답.", {}

        sim = ChildSimulator(PROFILE, recommend_fn=fake)
        await sim.arespond("처음 질문.")
        committed = deepcopy(sim.history)
        with self.assertRaises(LunaCallError):
            await sim.arespond("다음 질문.")
        self.assertEqual(sim.history, committed)
        await sim.arespond("다음 질문.")
        self.assertEqual(prompts[1], prompts[2])
        self.assertEqual(prompts[2].count("다음 질문."), 1)
        self.assertEqual(len(sim.history), 4)
        self.assertEqual([row["status"] for row in sim.calls], ["OK", "FAILED", "OK"])

    async def test_history_commits_only_after_reply_finishes(self):
        entered, release = asyncio.Event(), asyncio.Event()

        async def fake(*args, **kwargs):
            entered.set()
            await release.wait()
            return "대답.", {}

        sim = ChildSimulator(PROFILE, recommend_fn=fake)
        pending = asyncio.create_task(sim.arespond("질문."))
        await entered.wait()
        try:
            self.assertEqual(sim.history, [])
            self.assertEqual(sim.calls[0]["status"], "STARTED")
        finally:
            release.set()
            await pending
        self.assertEqual(len(sim.history), 2)

    async def test_cancellation_does_not_commit_and_next_call_can_succeed(self):
        entered = asyncio.Event()
        attempt = 0

        async def fake(*args, **kwargs):
            nonlocal attempt
            attempt += 1
            if attempt == 1:
                entered.set()
                await asyncio.Event().wait()
            return "새 대답.", {}

        sim = ChildSimulator(PROFILE, recommend_fn=fake)
        task = asyncio.create_task(sim.arespond("취소될 질문."))
        await entered.wait()
        task.cancel()
        with self.assertRaises(asyncio.CancelledError):
            await task
        self.assertEqual(sim.history, [])
        self.assertEqual(sim.calls[0]["status"], "CANCELLED")
        self.assertFalse(sim.calls[0]["error"]["usage_complete"])
        self.assertEqual(await sim.arespond("새 질문."), "새 대답.")
        self.assertEqual(len(sim.history), 2)
        self.assertNotIn("취소될 질문.", json.dumps(sim.history, ensure_ascii=False))

    async def test_concurrent_calls_and_reset_cannot_corrupt_pending_history(self):
        entered, release = asyncio.Event(), asyncio.Event()

        async def fake(*args, **kwargs):
            entered.set()
            await release.wait()
            return "응.", {}

        sim = ChildSimulator(PROFILE, recommend_fn=fake)
        pending = asyncio.create_task(sim.arespond("첫 질문."))
        await entered.wait()
        try:
            with self.assertRaises(RuntimeError):
                await sim.arespond("겹친 질문.")
            with self.assertRaises(RuntimeError):
                sim.reset()
            self.assertEqual(len(sim.calls), 1)
        finally:
            release.set()
            await pending
        self.assertEqual(len(sim.history), 2)

    async def test_reset_starts_new_history_and_diagnostics(self):
        async def fake(*args, **kwargs):
            return "응.", {}

        sim = ChildSimulator(PROFILE, recommend_fn=fake)
        await sim.arespond("질문.")
        sim.reset()
        self.assertEqual(sim.history, [])
        self.assertEqual(sim.diagnostics_snapshot()["calls"], [])
        await sim.arespond("다시 질문.")
        self.assertEqual(sim.calls[0]["call_index"], 1)

    async def test_diagnostics_are_detached_metadata_without_dialogue(self):
        async def fake(*args, **kwargs):
            return "비공개 대답 식별문자열.", {"attempts": [{"attempt": 1}]}

        sim = ChildSimulator(PROFILE, recommend_fn=fake)
        await sim.arespond("비공개 질문 식별문자열.")
        snapshot = sim.diagnostics_snapshot()
        encoded = json.dumps(snapshot, ensure_ascii=False)
        self.assertNotIn("비공개", encoded)
        self.assertNotIn(PROFILE["behavior"], encoded)
        snapshot["settings"]["model"] = "changed"
        snapshot["calls"][0]["usage"]["attempts"][0]["attempt"] = 999
        fresh = sim.diagnostics_snapshot()
        self.assertEqual(fresh["settings"]["model"], "gpt-6-luna")
        self.assertEqual(fresh["calls"][0]["usage"]["attempts"][0]["attempt"], 1)

    async def test_unexpected_adapter_error_keeps_message_out_of_diagnostics(self):
        async def fake(*args, **kwargs):
            raise RuntimeError("PRIVATE_EXCEPTION_PAYLOAD")

        sim = ChildSimulator(PROFILE, recommend_fn=fake)
        with self.assertRaises(RuntimeError):
            await sim.arespond("질문.")
        self.assertEqual(sim.history, [])
        self.assertEqual(sim.calls[0]["status"], "FAILED")
        self.assertNotIn("PRIVATE_EXCEPTION_PAYLOAD", json.dumps(sim.diagnostics_snapshot()))


if __name__ == "__main__":
    unittest.main()
