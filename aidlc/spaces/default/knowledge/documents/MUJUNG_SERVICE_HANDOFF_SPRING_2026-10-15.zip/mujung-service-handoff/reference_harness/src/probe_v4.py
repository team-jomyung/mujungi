"""Probe 4.2: preserve Live capture and classify child-simulator failures.

GPT-Live does not expose a completed voice-turn event. Quiet periods below are
application heuristics, never proof that a sentence or response is finished.
External simulator/TTS dependencies are loaded only when run_session is called.
"""
from __future__ import annotations

import asyncio
from dataclasses import asdict, dataclass
import json
import math
from pathlib import Path
import re
import time
from typing import Any, Callable, Literal, Optional
import uuid
import wave

from luna_runner import LunaCallError


HARNESS_VERSION = "4.2"
AUDIO_SILENCE_SEC = 0.8
TRANSCRIPT_STABLE_SEC = 1.2
MAX_WAIT_SEC = 30.0


class SessionBudgetExceeded(asyncio.TimeoutError):
    """The session deadline expired, or the next audio cannot fit its budget."""


@dataclass(frozen=True)
class ReplyOpportunity:
    status: Literal["estimated", "no_response_timeout", "boundary_timeout", "session_error"]
    text: str
    cursor: int
    revision: int
    reason: str
    confirmed_done: bool = False


def _positive_number(value: Any, name: str, *, allow_zero: bool = False) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(name + " must be a finite number")
    value = float(value)
    if not math.isfinite(value) or value < 0 or (not allow_zero and value == 0):
        raise ValueError(name + " must be " + ("nonnegative" if allow_zero else "positive"))
    return value


def _activity(live: Any) -> dict:
    activity = live.output_activity()
    result = {}
    for key in ("last_transcript_at", "last_voice_until", "playback_until", "now"):
        value = activity[key]
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
            raise ValueError("invalid output activity: " + key)
        result[key] = float(value)
    return result


def _has_terminal_punctuation(text: str) -> bool:
    # Optional extra guard only. Punctuation does not establish semantic completion.
    return bool(re.search(r"[.!?。！？…][\s\"'’”\)\]】]*$", text))


def _is_quiet(activity: dict, now: float, text_stable: float, audio_quiet: float) -> bool:
    # Live may keep streaming silence. Its queued playback endpoint can keep
    # advancing even while nothing audible remains. Only last_voice_until is
    # the estimated playback endpoint of audible output; playback_until is
    # useful queue metadata, not a reason to block a reply opportunity.
    return (now - activity["last_transcript_at"] >= text_stable
            and now - activity["last_voice_until"] >= audio_quiet)


async def wait_for_reply_opportunity(
    live: Any, *, cursor: int, deadline: float,
    text_stable: float = TRANSCRIPT_STABLE_SEC,
    audio_quiet: float = AUDIO_SILENCE_SEC,
    poll_interval: float = 0.05,
    require_terminal_punctuation: bool = True,
) -> ReplyOpportunity:
    """Wait after a cursor captured BEFORE input send; timeout is never success.

    deadline is an absolute time.monotonic() deadline. Caller must retain this
    cursor across retries so fragments received during send/TTS are not skipped.
    """
    if isinstance(cursor, bool) or not isinstance(cursor, int) or cursor < 0:
        raise ValueError("cursor must be a nonnegative transcript-event count")
    deadline = _positive_number(deadline, "deadline", allow_zero=True)
    text_stable = _positive_number(text_stable, "text_stable", allow_zero=True)
    audio_quiet = _positive_number(audio_quiet, "audio_quiet", allow_zero=True)
    poll_interval = _positive_number(poll_interval, "poll_interval")
    text = ""
    revision = -1
    last_observed_change: Optional[float] = None
    while True:
        now = time.monotonic()
        try:
            live.ensure_healthy()
            if cursor > live.transcript_cursor():
                return ReplyOpportunity("session_error", text, cursor, revision, "cursor_exceeds_capture")
            current_text = live.output_since(cursor)
            current_revision = live.output_revision
            activity = _activity(live)
            if not isinstance(current_text, str) or not isinstance(current_revision, int):
                raise ValueError("invalid transcript output")
            if last_observed_change is None:
                last_observed_change = activity["last_transcript_at"]
            elif current_text != text or current_revision != revision:
                last_observed_change = now
            text, revision = current_text, current_revision
        except Exception as exc:
            return ReplyOpportunity("session_error", text, cursor, revision,
                                    "live_health_error:" + type(exc).__name__)
        if now >= deadline:
            status = "boundary_timeout" if text.strip() else "no_response_timeout"
            return ReplyOpportunity(status, text, cursor, revision, "reply_deadline_elapsed")
        stable = now - max(last_observed_change, activity["last_transcript_at"]) >= text_stable
        punct_ok = not require_terminal_punctuation or _has_terminal_punctuation(text)
        if text.strip() and stable and punct_ok and _is_quiet(activity, now, text_stable, audio_quiet):
            return ReplyOpportunity("estimated", text, cursor, revision,
                                    "text_stable_and_audio_quiet; not_a_turn_done_signal")
        await asyncio.sleep(min(poll_interval, max(0.0, deadline - time.monotonic())))


async def wait_for_mujung_done(live: Any, *, cursor: int, deadline: float, **kwargs: Any) -> ReplyOpportunity:
    """Compatibility name; returns ReplyOpportunity, NOT a completed-turn string.

    cursor and deadline are intentionally required. No baseline is sampled here.
    """
    return await wait_for_reply_opportunity(live, cursor=cursor, deadline=deadline, **kwargs)


def _load_dependencies(kit_loader, synthesize_fn, simulator_factory, instructions_builder, session_factory):
    if kit_loader is None or synthesize_fn is None:
        from probe_audio_harness import load_kit, synthesize
        kit_loader = kit_loader or load_kit
        synthesize_fn = synthesize_fn or synthesize
    if simulator_factory is None:
        from probe_child import ChildSimulator
        simulator_factory = ChildSimulator
    if instructions_builder is None:
        from probe_instructions_v02 import build_instructions
        instructions_builder = build_instructions
    if session_factory is None:
        from live_api_session import LiveApiSession
        session_factory = LiveApiSession
    return kit_loader, synthesize_fn, simulator_factory, instructions_builder, session_factory


def _select_case(kit: dict, profile_id: str, scenario_id: str):
    if not isinstance(kit, dict):
        raise ValueError("kit must be an object")
    mappings = []
    for name in ("profiles", "scenarios"):
        items = kit.get(name)
        if not isinstance(items, list) or any(not isinstance(x, dict) or not isinstance(x.get("id"), str) for x in items):
            raise ValueError("invalid kit " + name)
        mapping = {x["id"]: x for x in items}
        if len(mapping) != len(items):
            raise ValueError("duplicate IDs in kit " + name)
        mappings.append(mapping)
    if profile_id not in mappings[0] or scenario_id not in mappings[1]:
        raise ValueError("unknown profile_id or scenario_id")
    profile, scenario = mappings[0][profile_id], mappings[1][scenario_id]
    assigned_profile = scenario.get("profile_id")
    if assigned_profile is not None and assigned_profile != profile_id:
        raise ValueError("scenario/profile mismatch")
    return profile, scenario


def _provisional_transcript(snapshot: dict, scripts: list, run_started: float) -> list:
    """Application send windows, not authoritative speech-turn boundaries.

    All output events are represented once, including late/final fragments.
    Recognition text and scripted TTS input stay explicitly distinguished.
    """
    events = snapshot.get("transcript_events", [])
    result = []

    def add_output(start, end):
        selected = [e for e in events[start:end] if e.get("type") == "session.output_transcript.delta"]
        if not selected:
            return
        starts = [e["start_ms"] for e in selected if isinstance(e.get("start_ms"), (int, float))]
        ends = [e["end_ms"] for e in selected if isinstance(e.get("end_ms"), (int, float))]
        received = [e["received_monotonic"] for e in selected
                    if isinstance(e.get("received_monotonic"), (int, float))]
        result.append({"speaker": "mujung", "text": "".join(e.get("delta", "") for e in selected),
                       "provenance": "LIVE_OUTPUT_TRANSCRIPT", "boundary_status": "PROVISIONAL_SEND_WINDOW",
                       "confirmed_done": False, "cursor_start": start, "cursor_end": end,
                       "source_event_ids": [e.get("event_id") for e in selected],
                       "source_event_seq": [e.get("seq") for e in selected],
                       "start_ms": min(starts) if starts else None, "end_ms": max(ends) if ends else None,
                       "timestamp_ms": max(0, int((min(received) - run_started) * 1000)) if received else None,
                       "timestamp_basis": "LOCAL_RECEIVE_TIME_NOT_SPEECH_TIME"})

    if scripts:
        add_output(0, scripts[0]["cursor_before_send"])
        for index, script in enumerate(scripts):
            result.append({"speaker": "child", "text": script["text"],
                           "provenance": "SCRIPTED_TTS_INPUT_NOT_RECOGNIZED_TRANSCRIPT",
                           "send_status": script["send_status"],
                           "send_started_ms": script["send_started_ms"], "send_ended_ms": script["send_ended_ms"],
                           "timestamp_ms": script["send_started_ms"],
                           "timestamp_basis": "LOCAL_SEND_TIME_NOT_SPEECH_TIME",
                           "boundary_status": "APPLICATION_INPUT_SEND", "confirmed_done": False})
            end = scripts[index + 1]["cursor_before_send"] if index + 1 < len(scripts) else len(events)
            add_output(script["cursor_before_send"], end)
    else:
        add_output(0, len(events))
    for index, item in enumerate(result, 1):
        item["turn"] = index
    return result


def _write_debug_capture(directory, result, live, sample_rate):
    # Only an explicit capture_dir enables raw transcript/audio persistence.
    root = Path(directory).expanduser()
    root.mkdir(parents=True, exist_ok=True)
    destination = root / ("capture-" + uuid.uuid4().hex)
    destination.mkdir(exist_ok=False)
    with (destination / "capture.json").open("x", encoding="utf-8") as output:
        json.dump(result, output, ensure_ascii=False, indent=2)
    for kind in ("input", "output"):
        getter = getattr(live, "get_" + kind + "_pcm", None)
        if getter is not None:
            pcm = getter()
            with wave.open(str(destination / (kind + ".wav")), "wb") as output:
                output.setnchannels(1)
                output.setsampwidth(2)
                output.setframerate(sample_rate)
                output.writeframes(pcm)
    return str(destination)


async def run_session(
    profile_id: str, scenario_id: str, duration_sec: float = 480.0, *,
    sample_rate: int = 16000, reply_timeout_sec: float = MAX_WAIT_SEC,
    text_stable: float = TRANSCRIPT_STABLE_SEC, audio_quiet: float = AUDIO_SILENCE_SEC,
    poll_interval: float = 0.05, require_terminal_punctuation: bool = True,
    max_stale_retries: int = 0, capture_dir=None,
    kit_loader: Optional[Callable] = None, synthesize_fn: Optional[Callable] = None,
    simulator_factory: Optional[Callable] = None, instructions_builder: Optional[Callable] = None,
    session_factory: Optional[Callable] = None,
) -> dict:
    """Run scripted audio input with continuous background capture.

    synthesize_fn must return raw mono PCM16 bytes at sample_rate; a rate label
    cannot resample audio. Missing original TTS dependencies fail before connect.
    The returned transcript is provisional; capture.transcript_events is primary.
    Retries default to zero because arespond may mutate simulator history even
    when its generated reply is never spoken. Set max_stale_retries above zero
    only with a stateless or transactional simulator whose caller safely handles
    speculative replies; this harness cannot roll back unknown internal state.
    """
    duration_sec = _positive_number(duration_sec, "duration_sec")
    reply_timeout_sec = _positive_number(reply_timeout_sec, "reply_timeout_sec")
    text_stable = _positive_number(text_stable, "text_stable", allow_zero=True)
    audio_quiet = _positive_number(audio_quiet, "audio_quiet", allow_zero=True)
    poll_interval = _positive_number(poll_interval, "poll_interval")
    if isinstance(sample_rate, bool) or sample_rate not in (16000, 24000):
        raise ValueError("sample_rate must be 16000 or 24000 for this PCM harness")
    if isinstance(max_stale_retries, bool) or not isinstance(max_stale_retries, int) or not 0 <= max_stale_retries <= 10:
        raise ValueError("max_stale_retries must be an integer from 0 through 10")
    if not isinstance(profile_id, str) or not isinstance(scenario_id, str):
        raise ValueError("profile_id and scenario_id must be strings")
    kit_loader, synthesize_fn, simulator_factory, instructions_builder, session_factory = _load_dependencies(
        kit_loader, synthesize_fn, simulator_factory, instructions_builder, session_factory)
    profile, scenario = _select_case(kit_loader(), profile_id, scenario_id)
    opening = scenario.get("opening", "안녕.")
    if not isinstance(opening, str) or not opening.strip():
        raise ValueError("scenario opening must be nonempty text")
    trigger_rows = scenario.get("child_triggers", [])
    if not isinstance(trigger_rows, list):
        raise ValueError("child_triggers must be a list")
    triggers = {}
    for trigger in trigger_rows:
        if (not isinstance(trigger, dict) or isinstance(trigger.get("roundtrip"), bool)
                or not isinstance(trigger.get("roundtrip"), int) or trigger["roundtrip"] < 1
                or not isinstance(trigger.get("text"), str) or not trigger["text"].strip()
                or trigger["roundtrip"] in triggers):
            raise ValueError("invalid or duplicate scenario child trigger")
        triggers[trigger["roundtrip"]] = trigger["text"]
    child_name = scenario.get("child_name")
    if not child_name:
        # Preserve the original fallback when its module is available; offline
        # injected tests do not need to install the original harness package.
        try:
            from probe_audio_harness import _fallback_child_name
        except ImportError:
            child_name = "아동"
        else:
            child_name = _fallback_child_name(scenario_id)
    instructions = instructions_builder(name=child_name, interest=scenario.get("child_interest") or "블록")
    sim = simulator_factory(profile, age=scenario.get("age", 9))
    live = session_factory(instructions=instructions, sample_rate=sample_rate)
    started = time.monotonic()
    deadline = started + duration_sec
    input_scripts = []
    opportunities = []
    discarded_replies = 0
    stop_reason = "not_started"
    error_stage = None
    error_type = None
    error_code = None
    error_details = None
    finalization = {"status": "NOT_ATTEMPTED"}
    capture = {}
    stage = "connect"

    def remaining():
        return max(0.0, deadline - time.monotonic())

    async def bounded(awaitable):
        budget = remaining()
        if budget <= 0:
            if hasattr(awaitable, "close"):
                awaitable.close()
            raise SessionBudgetExceeded()
        try:
            return await asyncio.wait_for(awaitable, timeout=budget)
        except asyncio.TimeoutError:
            if remaining() <= 0:
                raise SessionBudgetExceeded() from None
            raise

    async def synthesize_audio(text):
        pcm = await bounded(asyncio.to_thread(synthesize_fn, text))
        if not isinstance(pcm, (bytes, bytearray)) or not pcm or len(pcm) % 2:
            raise ValueError("synthesize must return nonempty raw mono PCM16 bytes")
        if len(pcm) / (2 * sample_rate) >= remaining():
            raise SessionBudgetExceeded()
        return bytes(pcm)

    async def send_script(text, pcm, roundtrip):
        live.ensure_healthy()
        if remaining() <= 0:
            raise SessionBudgetExceeded()
        cursor = live.transcript_cursor()  # MUST precede send_audio.
        row = {"roundtrip": roundtrip, "text": text,
               "provenance": "SCRIPTED_TTS_INPUT_NOT_RECOGNIZED_TRANSCRIPT",
               "cursor_before_send": cursor, "send_started_ms": int((time.monotonic() - started) * 1000),
               "send_ended_ms": None, "send_status": "SEND_STARTED", "sample_rate": sample_rate}
        input_scripts.append(row)
        try:
            await bounded(live.send_audio(pcm, sample_rate=sample_rate))
            row["send_status"] = "SENT"
        except BaseException:
            row["send_status"] = "SEND_INTERRUPTED"
            raise
        finally:
            row["send_ended_ms"] = int((time.monotonic() - started) * 1000)
        return cursor

    try:
        await bounded(live.connect())
        stage = "opening_tts"
        pcm = await synthesize_audio(opening)
        stage = "opening_send"
        cursor = await send_script(opening, pcm, 0)
        roundtrip_no = 1
        while remaining() > 0:
            stale_retries = 0
            while True:
                stage = "reply_boundary"
                opportunity = await wait_for_reply_opportunity(
                    live, cursor=cursor, deadline=min(deadline, time.monotonic() + reply_timeout_sec),
                    text_stable=text_stable, audio_quiet=audio_quiet, poll_interval=poll_interval,
                    require_terminal_punctuation=require_terminal_punctuation)
                opportunities.append(asdict(opportunity))
                if opportunity.status != "estimated":
                    stop_reason = opportunity.status
                    break
                if remaining() <= 0:
                    stop_reason = "duration_limit"
                    break
                stage = "child_simulation"
                if roundtrip_no in triggers:
                    child_text = triggers[roundtrip_no]
                else:
                    child_text = await bounded(sim.arespond(opportunity.text))
                    if not isinstance(child_text, str) or not child_text.strip():
                        stop_reason = "child_simulator_empty"
                        break
                child_text = child_text.strip()
                stage = "child_tts"
                pcm = await synthesize_audio(child_text)
                stage = "pre_send_recheck"
                live.ensure_healthy()
                activity = _activity(live)
                if remaining() <= 0:
                    stop_reason = "duration_limit"
                    break
                if (live.output_revision != opportunity.revision
                        or not _is_quiet(activity, time.monotonic(), text_stable, audio_quiet)):
                    discarded_replies += 1
                    stale_retries += 1
                    if stale_retries > max_stale_retries:
                        stop_reason = "boundary_changed_retry_limit"
                        break
                    # Keep the SAME cursor: regenerated replies include all late text.
                    continue
                stage = "child_send"
                cursor = await send_script(child_text, pcm, roundtrip_no)
                roundtrip_no += 1
                break
            if stop_reason != "not_started":
                break
        if stop_reason == "not_started":
            stop_reason = "duration_limit"
    except SessionBudgetExceeded:
        stop_reason = "duration_limit"
        error_stage = stage
        error_type = "TimeoutError"
        error_code = "SESSION_BUDGET_EXHAUSTED"
    except asyncio.TimeoutError:
        stop_reason = "dependency_timeout"
        error_stage = stage
        error_type = "TimeoutError"
        error_code = "DEPENDENCY_TIMEOUT"
    except asyncio.CancelledError:
        stop_reason = "cancelled"
        error_stage = stage
        error_type = "CancelledError"
        raise
    except Exception as exc:
        stop_reason = "child_simulator_error" if stage == "child_simulation" else "session_error"
        error_stage = stage
        error_type = type(exc).__name__
        if isinstance(exc, LunaCallError):
            error_code = exc.code
            error_details = exc.as_dict()
    finally:
        try:
            finalization = await live.close()
            if not isinstance(finalization, dict):
                finalization = {"status": "FAILED", "error_code": "INVALID_CLOSE_RESULT"}
        except Exception as exc:
            finalization = {"status": "FAILED", "error_code": "CLOSE_" + type(exc).__name__}
        try:
            capture = live.capture_snapshot()  # After close, retain final/late events.
        except Exception as exc:
            capture = {"capture_error": type(exc).__name__, "transcript_events": []}

    child_diagnostics = None
    snapshot_fn = getattr(sim, "diagnostics_snapshot", None)
    if callable(snapshot_fn):
        try:
            child_diagnostics = snapshot_fn()
        except Exception as exc:
            child_diagnostics = {"status": "UNAVAILABLE", "error_type": type(exc).__name__}
    child_failure = (stop_reason in {"child_simulator_empty", "child_simulator_error"}
                     or (stop_reason == "dependency_timeout" and error_stage == "child_simulation"))
    elapsed = time.monotonic() - started
    result = {
        "profile_id": profile_id, "scenario_id": scenario_id, "harness_version": HARNESS_VERSION,
        "model": "gpt-live-1", "audio_format": {"type": "audio/pcm", "rate": sample_rate},
        "method": "estimated_reply_opportunity_with_continuous_capture", "confirmed_done": False,
        "execution_status": "STOPPED", "stop_reason": stop_reason,
        "error_stage": error_stage, "error_type": error_type,
        "error_code": error_code, "error_details": error_details,
        "child_simulator_diagnostics": child_diagnostics,
        "evaluation_status": "INVALID_CHILD_SIMULATION" if child_failure else "REQUIRES_CAPTURE_REVIEW",
        "analysis_eligible": False,
        "transcript_boundary_status": "PROVISIONAL_APPLICATION_SEND_WINDOWS",
        "transcript": _provisional_transcript(capture, input_scripts, started),
        "input_scripts": input_scripts, "reply_opportunities": opportunities,
        "discarded_stale_replies": discarded_replies, "capture": capture,
        "finalization": finalization, "session_duration_sec": round(elapsed, 3),
        "estimated_cost_usd": round(elapsed / 60 * 0.05, 4),
        "cost_estimate_basis": "Original v4 wall-clock estimate at USD 0.05/min; includes local setup/close time, excludes simulator/TTS/backend costs; not billing.",
        "requested_duration_sec": duration_sec,
        "boundary_policy": {"text_stable_sec": text_stable, "audio_quiet_sec": audio_quiet,
                            "reply_timeout_sec": reply_timeout_sec,
                            "require_terminal_punctuation": require_terminal_punctuation,
                            "poll_interval_sec": poll_interval, "max_stale_retries": max_stale_retries},
    }
    if capture_dir is not None:
        try:
            result["capture_directory"] = _write_debug_capture(capture_dir, result, live, sample_rate)
        except Exception as exc:
            result["capture_write_error"] = type(exc).__name__
    return result
