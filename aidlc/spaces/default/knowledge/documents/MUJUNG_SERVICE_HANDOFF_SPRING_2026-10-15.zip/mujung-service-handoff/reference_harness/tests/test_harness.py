import asyncio
import base64
import json
from pathlib import Path
import sys
import tempfile
import time
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from probe_v4 import run_session
from live_api_session import LiveApiSession
from luna_runner import LunaCallError
from probe_child import ChildSimulator
from test_capture import FakeCapture, FakeSocket, delta

KIT = {"profiles": [{"id": "C00"}], "scenarios": [{"id": "SC-C00-01", "profile_id": "C00",
       "opening": "블록으로 집 만들었어.", "child_name": "합성 아동"}]}


class RunSession(FakeCapture):
    def __init__(self, instructions, sample_rate=16000, response="첫 응답."):
        super().__init__()
        self.response = response
        self.sent_audio = []
        self.closed = False
        self.recorded = []
        self.ticks = 0

    async def connect(self):
        async def heartbeat():
            while not self.closed:
                self.ticks += 1
                await asyncio.sleep(.002)
        self.heartbeat = asyncio.create_task(heartbeat())

    def add(self, text):
        super().add(text)
        self.recorded.append({"type": "session.output_transcript.delta", "speaker": "mujung",
                              "delta": text, "event_id": "e%d" % len(self.events),
                              "seq": len(self.events), "start_ms": len(self.events) * 10,
                              "end_ms": len(self.events) * 10 + 10})

    async def send_audio(self, pcm, sample_rate=16000):
        self.sent_audio.append(pcm)
        if self.response:
            self.add(self.response)
        await asyncio.sleep(.001)

    async def close(self):
        self.add(" 마지막.")
        self.closed = True
        if hasattr(self, "heartbeat"):
            await self.heartbeat
        return {"status": "CLOSED", "server_closed_received": True}

    def capture_snapshot(self):
        return {"transcript_events": self.recorded, "health": {"ok": True}, "heartbeat_ticks": self.ticks}

    def get_input_pcm(self):
        return b"\0\0" * 320

    def get_output_pcm(self):
        return b"\0\0" * 320


class EmptySimulator:
    def __init__(self, *args, **kwargs):
        self.calls = 0

    async def arespond(self, text):
        self.calls += 1
        return ""


class HarnessTests(unittest.IsolatedAsyncioTestCase):
    async def run_case(self, *, response="첫 응답.", simulator_factory=EmptySimulator,
                       synthesize_fn=lambda text: b"\0\0" * 20, **kwargs):
        self.session = RunSession("offline", response=response)
        return await run_session(
            "C00", "SC-C00-01", duration_sec=kwargs.pop("duration_sec", .5),
            reply_timeout_sec=kwargs.pop("reply_timeout_sec", .05),
            text_stable=.005, audio_quiet=.001, poll_interval=.001,
            kit_loader=lambda: KIT, synthesize_fn=synthesize_fn,
            simulator_factory=simulator_factory, instructions_builder=lambda **kw: "offline",
            session_factory=lambda **kw: self.session, **kwargs)

    async def test_reply_received_during_send_and_close_is_preserved(self):
        result = await self.run_case()
        text = "".join(r["text"] for r in result["transcript"] if r["speaker"] == "mujung")
        self.assertEqual(text, "첫 응답. 마지막.")
        self.assertEqual(result["reply_opportunities"][0]["text"], "첫 응답.")
        self.assertFalse(result["analysis_eligible"])
        self.assertFalse(result["confirmed_done"])
        self.assertEqual(len(self.session.sent_audio), 1)
        self.assertTrue(self.session.closed)
        self.assertIsInstance(result["estimated_cost_usd"], (int, float))
        self.assertTrue(all("timestamp_ms" in row for row in result["transcript"]))

    async def test_no_response_timeout_prevents_next_child_audio(self):
        result = await self.run_case(response="")
        self.assertEqual(result["stop_reason"], "no_response_timeout")
        self.assertEqual(len(self.session.sent_audio), 1)

    async def test_incomplete_sentence_timeout_prevents_next_child_audio(self):
        result = await self.run_case(response="그 집 만들")
        self.assertEqual(result["stop_reason"], "boundary_timeout")
        self.assertEqual(len(self.session.sent_audio), 1)
        self.assertIn("그 집 만들", result["capture"]["transcript_events"][0]["delta"])

    async def test_sync_tts_does_not_block_receiver(self):
        def slow_tts(text):
            time.sleep(.04)
            return b"\0\0" * 20
        await self.run_case(synthesize_fn=slow_tts)
        self.assertGreaterEqual(self.session.ticks, 8)

    async def test_changed_context_discards_reply_without_mutating_sim_twice(self):
        owner = self
        class LateSimulator(EmptySimulator):
            async def arespond(self, text):
                self.calls += 1
                owner.sim_calls = self.calls
                await asyncio.sleep(.002)
                owner.session.add(" 더 말할게.")
                return "이전 문장에 대한 대답"
        result = await self.run_case(simulator_factory=LateSimulator)
        self.assertEqual(result["stop_reason"], "boundary_changed_retry_limit")
        self.assertEqual(result["discarded_stale_replies"], 1)
        self.assertEqual(self.sim_calls, 1)
        self.assertEqual(len(self.session.sent_audio), 1)
        self.assertIn("더 말할게", "".join(e["delta"] for e in result["capture"]["transcript_events"]))

    async def test_session_budget_bounds_simulator_wait(self):
        class SlowSimulator(EmptySimulator):
            async def arespond(self, text):
                await asyncio.sleep(10)
                return "늦은 답"
        start = time.monotonic()
        result = await self.run_case(simulator_factory=SlowSimulator, duration_sec=.06)
        self.assertLess(time.monotonic() - start, .25)
        self.assertEqual(result["stop_reason"], "duration_limit")
        self.assertEqual(result["error_stage"], "child_simulation")
        self.assertEqual(len(self.session.sent_audio), 1)

    async def test_opt_in_capture_contains_final_events(self):
        with tempfile.TemporaryDirectory() as root:
            result = await self.run_case(capture_dir=root)
            directory = Path(result["capture_directory"])
            saved = json.loads((directory / "capture.json").read_text())
            self.assertEqual(saved["capture"]["transcript_events"][-1]["delta"], " 마지막.")
            self.assertTrue((directory / "input.wav").exists())
            self.assertTrue((directory / "output.wav").exists())

    async def test_scripted_child_text_is_not_claimed_recognized(self):
        result = await self.run_case()
        child = next(r for r in result["transcript"] if r["speaker"] == "child")
        self.assertEqual(child["provenance"], "SCRIPTED_TTS_INPUT_NOT_RECOGNIZED_TRANSCRIPT")
        self.assertEqual(child["send_status"], "SENT")

    async def test_real_client_and_harness_with_offline_socket(self):
        class DialogSocket(FakeSocket):
            def __init__(self):
                super().__init__()
                self.responded = False
                self.continuation = None
            async def send(self, message):
                await super().send(message)
                event = json.loads(message)
                if event["type"] == "session.input_audio.append":
                    pcm = base64.b64decode(event["audio"])
                    if any(pcm) and not self.responded:
                        self.responded = True
                        await self.incoming.put(delta("팔 다리 움직이는", "early", 10, 30))
                        async def late():
                            await asyncio.sleep(.04)
                            await self.incoming.put(delta(" 거?", "late", 35, 50))
                        self.continuation = asyncio.create_task(late())
            async def close(self):
                if self.continuation:
                    await self.continuation
                await super().close()
        socket = DialogSocket()
        real = LiveApiSession("offline", close_timeout=.1)
        async def open_fake(): return socket
        real._open_websocket = open_fake
        result = await run_session(
            "C00", "SC-C00-01", duration_sec=.6, reply_timeout_sec=.25,
            text_stable=.015, audio_quiet=.001, poll_interval=.001,
            kit_loader=lambda: KIT, synthesize_fn=lambda text: b"\1\0" * 320,
            simulator_factory=EmptySimulator, instructions_builder=lambda **kw: "offline",
            session_factory=lambda **kw: real)
        self.assertEqual(result["reply_opportunities"][0]["text"], "팔 다리 움직이는 거?")
        self.assertEqual(result["finalization"]["status"], "CLOSED")
        self.assertGreaterEqual(result["capture"]["pump_metrics"]["silence_frames"], 2)
        self.assertEqual(result["capture"]["transcript"]["mujung"], "팔 다리 움직이는 거? 마지막.")

    async def test_luna_failure_preserves_diagnostics_without_fallback_audio(self):
        failure = LunaCallError("EMPTY_CONTENT", [{"attempt": 1, "finish_reason": "length"}])
        synthesized = []

        async def fail_recommend(*args, **kwargs):
            raise failure

        def synthesize(text):
            synthesized.append(text)
            return b"\0\0" * 20

        result = await self.run_case(
            simulator_factory=lambda *args, **kwargs: ChildSimulator(
                *args, **kwargs, recommend_fn=fail_recommend), synthesize_fn=synthesize)
        self.assertEqual(result["stop_reason"], "child_simulator_error")
        self.assertEqual(result["error_stage"], "child_simulation")
        self.assertEqual(result["error_code"], "EMPTY_CONTENT")
        self.assertEqual(result["error_details"], failure.as_dict())
        self.assertEqual(result["evaluation_status"], "INVALID_CHILD_SIMULATION")
        self.assertFalse(result["analysis_eligible"])
        self.assertEqual(result["child_simulator_diagnostics"]["calls"][0]["status"], "FAILED")
        self.assertFalse(result["child_simulator_diagnostics"]["fallback_used"])
        self.assertEqual(synthesized, [KIT["scenarios"][0]["opening"]])
        self.assertEqual(len(self.session.sent_audio), 1)
        self.assertEqual(len(result["input_scripts"]), 1)
        self.assertTrue(self.session.closed)
        self.assertEqual(result["capture"]["transcript_events"][-1]["delta"], " 마지막.")

    async def test_custom_simulator_empty_and_null_stop_as_invalid(self):
        for invalid in ("", " \n ", None):
            with self.subTest(value=repr(invalid)):
                class InvalidSimulator(EmptySimulator):
                    async def arespond(self, text):
                        return invalid

                result = await self.run_case(simulator_factory=InvalidSimulator)
                self.assertEqual(result["stop_reason"], "child_simulator_empty")
                self.assertEqual(result["evaluation_status"], "INVALID_CHILD_SIMULATION")
                self.assertFalse(result["analysis_eligible"])
                self.assertEqual(len(self.session.sent_audio), 1)
                self.assertTrue(self.session.closed)

    async def test_internal_dependency_timeout_is_not_session_budget_expiry(self):
        class TimeoutSimulator(EmptySimulator):
            async def arespond(self, text):
                raise asyncio.TimeoutError()

        result = await self.run_case(simulator_factory=TimeoutSimulator, duration_sec=1.0)
        self.assertEqual(result["stop_reason"], "dependency_timeout")
        self.assertEqual(result["error_code"], "DEPENDENCY_TIMEOUT")
        self.assertEqual(result["error_stage"], "child_simulation")
        self.assertEqual(result["evaluation_status"], "INVALID_CHILD_SIMULATION")
        self.assertEqual(len(self.session.sent_audio), 1)
        self.assertTrue(self.session.closed)

    async def test_session_budget_cancels_child_call_and_preserves_its_diagnostics(self):
        async def slow_recommend(*args, **kwargs):
            await asyncio.Event().wait()

        result = await self.run_case(
            simulator_factory=lambda *args, **kwargs: ChildSimulator(
                *args, **kwargs, recommend_fn=slow_recommend), duration_sec=.08)
        self.assertEqual(result["stop_reason"], "duration_limit")
        self.assertEqual(result["error_code"], "SESSION_BUDGET_EXHAUSTED")
        self.assertEqual(result["error_stage"], "child_simulation")
        self.assertEqual(result["child_simulator_diagnostics"]["calls"][0]["status"], "CANCELLED")
        self.assertFalse(result["analysis_eligible"])
        self.assertEqual(len(self.session.sent_audio), 1)
        self.assertTrue(self.session.closed)

    async def test_unexpected_child_exception_stops_and_closes_without_filler(self):
        class BrokenSimulator(EmptySimulator):
            async def arespond(self, text):
                raise RuntimeError("PRIVATE_SIMULATOR_FAILURE_DETAIL")

        result = await self.run_case(simulator_factory=BrokenSimulator)
        self.assertEqual(result["stop_reason"], "child_simulator_error")
        self.assertEqual(result["evaluation_status"], "INVALID_CHILD_SIMULATION")
        self.assertEqual(result["error_type"], "RuntimeError")
        self.assertNotIn("PRIVATE_SIMULATOR_FAILURE_DETAIL", json.dumps(result))
        self.assertEqual(len(self.session.sent_audio), 1)
        self.assertTrue(self.session.closed)

    async def test_tts_dependency_timeout_is_distinct_from_child_luna_failure(self):
        def timeout_tts(text):
            raise asyncio.TimeoutError()

        result = await self.run_case(synthesize_fn=timeout_tts, duration_sec=1.0)
        self.assertEqual(result["stop_reason"], "dependency_timeout")
        self.assertEqual(result["error_stage"], "opening_tts")
        self.assertEqual(result["error_code"], "DEPENDENCY_TIMEOUT")
        self.assertEqual(result["evaluation_status"], "REQUIRES_CAPTURE_REVIEW")
        self.assertEqual(self.session.sent_audio, [])
        self.assertTrue(self.session.closed)


if __name__ == "__main__":
    unittest.main()
