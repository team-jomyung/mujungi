package com.mujung.live;

import com.fasterxml.jackson.databind.JsonNode;
import java.security.Principal;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import org.springframework.http.CacheControl;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/mujung/live/sessions")
public final class LiveSessionController {
    private final LiveSessionService service;
    public LiveSessionController(LiveSessionService service) { this.service=service; }
    @PostMapping public ResponseEntity<LiveSessionService.CreatedResponse> create(Principal principal,@RequestBody JsonNode body) {
        if(body==null || !body.isObject() || body.size()!=1 || !body.path("sdp").isTextual())
            throw new LiveFailure(400,"ONLY_SDP_IS_ACCEPTED");
        return ResponseEntity.status(201).cacheControl(CacheControl.noStore()).body(service.create(principal,body.get("sdp").asText()));
    }
    @GetMapping("/{id}") public ResponseEntity<LiveSessionService.Status> status(Principal principal,@PathVariable String id) {
        return ResponseEntity.ok().cacheControl(CacheControl.noStore()).body(service.status(principal,id));
    }
    @PostMapping("/{id}/close") public CompletableFuture<ResponseEntity<LiveSessionService.Status>> close(Principal principal,@PathVariable String id) {
        return service.close(principal,id).thenApply(s->ResponseEntity.ok().cacheControl(CacheControl.noStore()).body(s));
    }
    @ExceptionHandler(LiveFailure.class) public ResponseEntity<Map<String,String>> failure(LiveFailure failure) {
        return ResponseEntity.status(failure.httpStatus()).cacheControl(CacheControl.noStore()).body(Map.of("error",failure.code()));
    }
}
