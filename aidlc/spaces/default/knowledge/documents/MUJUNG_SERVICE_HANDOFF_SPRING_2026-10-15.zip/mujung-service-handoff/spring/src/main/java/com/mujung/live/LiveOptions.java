package com.mujung.live;

import java.time.Duration;

public record LiveOptions(Duration sessionLimit, Duration connectTimeout, Duration closeTimeout,
                          Duration metadataRetention, int maxSessions) {
    public LiveOptions {
        if (sessionLimit == null || sessionLimit.isNegative() || sessionLimit.isZero() || sessionLimit.compareTo(Duration.ofHours(1))>0
            || connectTimeout == null || connectTimeout.isNegative() || connectTimeout.isZero()
            || closeTimeout == null || closeTimeout.isNegative() || closeTimeout.isZero()
            || metadataRetention == null || metadataRetention.isNegative() || metadataRetention.isZero() || maxSessions < 1)
            throw new IllegalArgumentException("Invalid Live limits");
    }
    public static LiveOptions defaults() {
        return new LiveOptions(Duration.ofSeconds(480), Duration.ofSeconds(15), Duration.ofSeconds(10), Duration.ofHours(1), 128);
    }
}
