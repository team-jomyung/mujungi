package com.mujung.live;

import java.security.Principal;
import java.time.Clock;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

/** Single-process reference registry. It is not a distributed ownership store. */
public final class LiveSessionService implements AutoCloseable {
    private final LiveGateway gateway;
    private final ServiceAccessPolicy access;
    private final LiveOptions options;
    private final ScheduledExecutorService scheduler;
    private final Clock clock;
    private final String instructions;
    private final ConcurrentHashMap<String,Managed> sessions=new ConcurrentHashMap<>();
    private final Set<String> reservedOwners=new HashSet<>();
    private final Object lock=new Object();
    private boolean shuttingDown;

    public LiveSessionService(LiveGateway gateway, ServiceAccessPolicy access, LiveOptions options,
                              ScheduledExecutorService scheduler, Clock clock, String instructions) {
        if(instructions==null || instructions.isBlank()) throw new IllegalArgumentException("Instructions are required");
        this.gateway=gateway; this.access=access; this.options=options; this.scheduler=scheduler; this.clock=clock; this.instructions=instructions;
    }
    public record SessionId(String id) {}
    public record Transport(String type,String sdp) {}
    public record Capabilities(boolean serverControl,boolean jev,boolean memory,boolean luna) {}
    public record CreatedResponse(SessionId session, Transport transport, Instant expiresAt, Capabilities capabilities) {}
    public record Status(String sessionId,String status,String reason,Double usageSeconds,boolean finalUsageConfirmed) {}

    public CreatedResponse create(Principal principal,String sdp) {
        String owner=requireOwner(principal);
        if(sdp==null || !sdp.startsWith("v=0") || sdp.length()>65536) throw new LiveFailure(400,"INVALID_SDP");
        ServiceAccessPolicy.AllowedContext allowed=access.requireAllowed(principal);
        if(allowed==null) throw new LiveFailure(403,"SERVICE_ACCESS_DENIED");
        reserve(owner);
        Managed managed=null;
        try {
            Instant deadline=clock.instant().plus(options.sessionLimit());
            var created=gateway.create(sdp,instructions);
            managed=new Managed(created.sessionId(),owner,allowed,deadline);
            if(sessions.putIfAbsent(created.sessionId(),managed)!=null) throw new LiveFailure(502,"UPSTREAM_DUPLICATE_SESSION_ID");
            Managed current=managed;
            var connection=gateway.attach(created.sessionId(),new LiveGateway.Listener() {
                public void usage(double seconds) { current.usage(seconds); }
                public void finalized(String reason,Double seconds) { current.finish(true,reason,seconds); }
                public void failed(String code) { current.failed(code); }
            });
            managed.bind(connection);
            if(managed.completion.isDone()) throw new LiveFailure(502,"SESSION_CLOSED_DURING_STARTUP");
            synchronized(lock) {
                if(shuttingDown) {
                    managed.requestClose("SERVER_SHUTDOWN_DURING_CREATE");
                    throw new LiveFailure(503,"SERVICE_STOPPING");
                }
            }
            long remaining=Math.max(0,deadline.toEpochMilli()-clock.millis());
            managed.deadline=scheduler.schedule(()->current.requestClose("SESSION_LIMIT"),remaining,TimeUnit.MILLISECONDS);
            return new CreatedResponse(new SessionId(created.sessionId()),new Transport("webrtc",created.answerSdp()),
                deadline,new Capabilities(true,false,false,false));
        } catch(RuntimeException failure) {
            if(managed!=null) managed.requestClose("STARTUP_FAILED");
            if(failure instanceof LiveFailure) throw failure;
            throw new LiveFailure(503,"SESSION_STARTUP_FAILED");
        } finally { synchronized(lock) { reservedOwners.remove(owner); } }
    }
    private void reserve(String owner) {
        synchronized(lock) {
            if(shuttingDown) throw new LiveFailure(503,"SERVICE_STOPPING");
            long active=sessions.values().stream().filter(s->!s.completion.isDone()).count();
            if(reservedOwners.contains(owner) || sessions.values().stream().anyMatch(s->s.owner.equals(owner)&&!s.completion.isDone()))
                throw new LiveFailure(409,"SESSION_ALREADY_ACTIVE");
            if(active+reservedOwners.size()>=options.maxSessions()) throw new LiveFailure(429,"SESSION_CAPACITY_REACHED");
            reservedOwners.add(owner);
        }
    }
    public Status status(Principal principal,String id) { return owned(principal,id).status(); }
    public CompletableFuture<Status> close(Principal principal,String id) { return owned(principal,id).requestClose("USER_END_BUTTON"); }
    private Managed owned(Principal principal,String id) {
        String owner=requireOwner(principal);
        Managed value=sessions.get(id);
        // Do not disclose whether another account owns a particular upstream session ID.
        if(value==null || !value.owner.equals(owner)) throw new LiveFailure(404,"SESSION_NOT_FOUND");
        return value;
    }
    private static String requireOwner(Principal p) {
        if(p==null || p.getName()==null || p.getName().isBlank()) throw new LiveFailure(401,"AUTHENTICATION_REQUIRED");
        return p.getName();
    }
    @Override public void close() {
        synchronized(lock) { shuttingDown=true; }
        var closing=new ArrayList<CompletableFuture<Status>>();
        sessions.values().forEach(s->closing.add(s.requestClose("SERVER_SHUTDOWN")));
        try { CompletableFuture.allOf(closing.toArray(new CompletableFuture<?>[0])).get(options.closeTimeout().toMillis()+1000,TimeUnit.MILLISECONDS); }
        catch(Exception ignored) { sessions.values().forEach(s->s.finish(false,"SERVER_SHUTDOWN_UNCONFIRMED",null)); }
    }
    private final class Managed {
        final String id;
        final String owner;
        // Trusted metadata only; raw conversation, audio and SDP are not retained here.
        final ServiceAccessPolicy.AllowedContext context;
        final Instant expiresAt;
        final CompletableFuture<Status> completion=new CompletableFuture<>();
        LiveGateway.Connection connection;
        ScheduledFuture<?> deadline;
        ScheduledFuture<?> closeDeadline;
        String state="ACTIVE";
        String reason="RUNNING";
        Double usage;
        boolean finalUsageConfirmed;
        Managed(String id,String owner,ServiceAccessPolicy.AllowedContext context,Instant expiresAt) {
            this.id=id; this.owner=owner; this.context=context; this.expiresAt=expiresAt;
        }
        synchronized void bind(LiveGateway.Connection connection) {
            this.connection=connection;
            if(completion.isDone()) {
                // Shutdown/error may have completed before attach returned. Do not leave a newly attached session running.
                if(state.equals("FINALIZATION_UNCONFIRMED")) {
                    try { connection.requestClose().whenComplete((ignored,error)->connection.disconnect()); }
                    catch(RuntimeException failure) { connection.disconnect(); }
                } else connection.disconnect();
            }
        }
        synchronized Status status() { return new Status(id,state,reason,usage,finalUsageConfirmed); }
        synchronized void usage(double seconds) { if(!completion.isDone() && Double.isFinite(seconds) && seconds>=0) usage=seconds; }
        synchronized void failed(String code) {
            // Error events do not necessarily end GPT Live. Ask for remote close before releasing a usable socket.
            if(connection!=null && code.startsWith("UPSTREAM_")) requestClose(code);
            else finish(false,code,null);
        }
        synchronized CompletableFuture<Status> requestClose(String why) {
            if(completion.isDone() || state.equals("CLOSING")) return completion;
            state="CLOSING"; reason=why;
            if(connection==null) { finish(false,"NO_CONTROL_CONNECTION",null); return completion; }
            boolean timerAvailable=true;
            try { closeDeadline=scheduler.schedule(()->finish(false,"CLOSE_CONFIRMATION_TIMEOUT",null),options.closeTimeout().toMillis(),TimeUnit.MILLISECONDS); }
            catch(java.util.concurrent.RejectedExecutionException rejected) { timerAvailable=false; }
            final boolean waitForFinal=timerAvailable;
            try { connection.requestClose().whenComplete((ignored,error)-> {
                if(error!=null) finish(false,"CLOSE_SEND_FAILED",null);
                else if(!waitForFinal) finish(false,"CLOSE_TIMER_UNAVAILABLE",null);
            }); }
            catch(RuntimeException failure) { finish(false,"CLOSE_SEND_FAILED",null); }
            return completion;
        }
        synchronized void finish(boolean confirmed,String why,Double finalSeconds) {
            if(completion.isDone()) return;
            state=confirmed?"CLOSED_CONFIRMED":"FINALIZATION_UNCONFIRMED"; reason=why;
            if(confirmed && finalSeconds!=null && Double.isFinite(finalSeconds) && finalSeconds>=0) {
                usage=finalSeconds; finalUsageConfirmed=true;
            }
            if(deadline!=null) deadline.cancel(false);
            if(closeDeadline!=null) closeDeadline.cancel(false);
            completion.complete(status());
            if(connection!=null) connection.disconnect();
            try { scheduler.schedule(()->sessions.remove(id,this),options.metadataRetention().toMillis(),TimeUnit.MILLISECONDS); }
            catch(java.util.concurrent.RejectedExecutionException stopping) { sessions.remove(id,this); }
        }
    }
}
