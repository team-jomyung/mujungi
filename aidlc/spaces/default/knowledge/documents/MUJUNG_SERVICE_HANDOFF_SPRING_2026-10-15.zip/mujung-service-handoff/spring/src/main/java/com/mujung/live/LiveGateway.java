package com.mujung.live;

import java.util.concurrent.CompletionStage;

/** Transport boundary. Tests use a fake; the concrete gateway calls OpenAI only on an explicit request. */
public interface LiveGateway {
    Created create(String sdp, String instructions);
    Connection attach(String sessionId, Listener listener);
    record Created(String sessionId, String answerSdp) {}
    interface Connection {
        CompletionStage<Void> requestClose();
        void disconnect();
    }
    interface Listener {
        void usage(double seconds);
        void finalized(String reason, Double seconds);
        void failed(String safeCode);
    }
}
