무중 Spring 연결 모듈 · 2026-10-15

이 폴더는 기존 Java/Kotlin Spring 서비스 안에 넣는 참조 라이브러리입니다.
독립적으로 실행하는 서버/로그인 예제가 아니며, 실제 OpenAI 음성 통화는 실행하지 않았습니다.
Java 17, Spring Boot 3.5.3 기준으로 오프라인 컴파일·테스트했습니다. Boot 4/Jackson 3로의 호환은 확인하지 않았습니다.
서비스 프롬프트는 기존 v0.2를 실제 사용 흐름에 맞춰 조정한 새 후보이며, 기존 26세션의 점수를 재현했다는 의미가 아닙니다.

1. 기존 앱에 붙이는 순서

  a. src/main/java/com/mujung/live 패키지를 기존 앱에 넣거나 이 폴더를 Maven library module로 추가합니다.
     src/main/resources/mujung/live_service_v02.txt도 같은 classpath로 포함합니다.
     기존 앱의 Spring/Jackson 버전 관리와 충돌하지 않도록 기존 BOM을 우선합니다.
     이 폴더 자체의 확인 명령: mvn test
     이미 의존성이 저장된 환경의 확인 명령: mvn -o test

  b. 기존 서버 설정 클래스에 @Import(MujungLiveConfiguration.class)를 추가합니다.
     Kotlin에서도 @Import(MujungLiveConfiguration::class)로 동일하게 등록할 수 있습니다.
     별도 서버를 띄우는 Main 클래스나 자동 전역 component scan은 포함하지 않았습니다.

  c. ServiceAccessPolicy 구현을 기존 앱의 Bean으로 등록합니다. 기본 허용 구현은 없습니다.
     requireAllowed(Principal)는 다음을 기존 앱의 신뢰 가능한 상태로 검사해야 합니다.
       - 실제 인증된 로그인 및 현재 선택 아동에 대한 접근 권한
       - 필요한 동의와 최신 안내의 확인, 이번 참여 시작 허용
       - 사용자별 요청/시간/예산 제한
     통과하면 AllowedContext(불투명한 childKey, noticeVersion)를 반환합니다.
     거절하면 new LiveFailure(403, "SERVICE_ACCESS_DENIED")를 던집니다.
     브라우저가 보내는 childId, consent=true, role=admin 같은 값을 그대로 승인 근거로 쓰지 않습니다.
     Principal.getName()은 계정 간 충돌하지 않는 안정된 서버 인증 주체 키여야 합니다.
     아동별 동의/공지에 사용한 실제 서비스 문구는 기존 앱에서 검토·확정합니다.

  d. OPENAI_API_KEY를 서버의 환경변수/비밀 저장소로 주입합니다.
     클라이언트 번들, HTML, application.yml, Git, 로그에 키를 넣지 않습니다.
     여기에는 실제 키가 없습니다. Java 클라이언트는 api.openai.com 고정 URL에만 요청합니다.
     리다이렉트와 생성 자동 재시도를 사용하지 않습니다.

  e. application-example.yml의 필요한 항목을 기존 설정에 병합합니다.
     /api/mujung/live/**에 기존 인증·인가·HTTPS·CSRF 정책·요청 제한을 적용합니다.
     쿠키 인증이면 기존 앱 CSRF 토큰을 프런트 요청에 붙이고 CSRF를 전역 비활성화하지 않습니다.
     64 KiB 수준의 ingress request-body 상한을 적용하세요. JSON 파싱 전 body 상한은 호스트 앱/프록시의 책임입니다.
     생성 성공은 한 번의 유료 세션을 시작합니다. 오류 시 무조건 자동 재시도하지 않습니다.

  f. ../frontend 연결 예제를 기존 UI의 시작/종료 버튼에 연결합니다.
     기본은 동일 origin입니다. 기존 프런트와 서버가 별도 도메인이면 허용 origin과 credentials/CSRF를 기존 앱에서 지정합니다.

2. 프런트와 백엔드 계약

POST /api/mujung/live/sessions
  인증 필요. JSON: {"sdp":"v=0..."} 한 필드만 허용합니다.
  모델명, 프롬프트, 아동 ID, 저장 옵션, 권한은 프런트가 지정할 수 없습니다.
  201 응답 예:
  {
    "session":{"id":"live_opaque"},
    "transport":{"type":"webrtc","sdp":"SDP answer"},
    "expiresAt":"2026-10-15T08:08:00Z",
    "capabilities":{"serverControl":true,"jev":false,"memory":false,"luna":false}
  }
  expiresAt은 앱 벽시계 기준 종료 요청 시각입니다. 실제 사용량·종료 확인 시간과 동일한 값은 아닙니다.

GET /api/mujung/live/sessions/{id}
  해당 세션을 생성한 동일 로그인 주체만 조회합니다. 없거나 남의 세션이면 404입니다.
  {
    "sessionId":"live_opaque",
    "status":"ACTIVE",
    "reason":"RUNNING",
    "usageSeconds":null,
    "finalUsageConfirmed":false
  }
  status: ACTIVE | CLOSING | CLOSED_CONFIRMED | FINALIZATION_UNCONFIRMED
  usageSeconds는 아직 수신되지 않았다면 null이며, 누적값을 합산하지 않고 최신값으로 교체합니다.
  CLOSED_CONFIRMED는 session.closed 수신을 뜻합니다. 음성 내용의 안전성/화용 분석 성공을 뜻하지 않습니다.
  종료 이벤트에 usage가 없으면 CLOSED_CONFIRMED여도 finalUsageConfirmed=false입니다.

POST /api/mujung/live/sessions/{id}/close
  동일 소유자 인증 필요. 본문 불필요. 반복 요청은 같은 종료 결과를 기다립니다.
  위 GET과 동일한 구조를 반환하며, 기본 최대 10초 동안 session.closed를 기다립니다.
  종료 때 동의가 철회되었더라도 이미 소유한 세션의 종료는 차단하지 않습니다.
  FINALIZATION_UNCONFIRMED는 종료 완료/최종 비용을 확인하지 못했다는 뜻입니다.
  HTTP 200만 보고 완료로 표시하지 말고 반드시 status를 확인합니다.
  모든 성공/오류 응답에 Cache-Control: no-store를 설정합니다.

프런트 흐름
  - 사용자의 시작 동작 후 마이크 권한을 받습니다. 마이크/재생은 세션이 준비될 때까지 비활성화합니다.
  - oai-events 데이터 채널 및 이벤트 수신기를 먼저 설치하고 ICE를 모은 SDP를 서버에 보냅니다.
  - answer를 적용하고 session.started를 기다립니다. session.start를 다시 보내지 않습니다.
  - 종료 버튼: 즉시 마이크와 재생을 mute/중단하고 백엔드 close를 요청합니다.
    최종 이벤트 또는 서버 종료 결과/종료 타임아웃 후 peer/data-channel을 해제합니다.
  - 3~5초 간격 status 확인으로 서버 타이머·sideband 장애를 감지합니다.
    CLOSING/종료/확인 불가/조회 실패 시 재생과 마이크를 멈춥니다.
  - 서버가 프런트 데이터 채널의 명령 전송 권한을 []로 제한하므로 브라우저에서 session.close를 보내지 않습니다.
  - 전사·오디오·SDP를 console.log, 분석 SDK, 오류 리포팅 등에 남기지 않습니다.

3. 들어 있는 실제 제어

  - 서버 전용 키 및 서버가 고정한 모델/프롬프트/store:false
  - 서버 정책 Bean 필수, 소유자 기반 조회·종료, 계정당 동시 세션 1개
  - 전체 활성 세션 상한 기본 128, 생성 자동 재시도 없음
  - GPT Live WebRTC 생성 후 동일 세션 sideband 연결; session.start 재전송 없음
  - 프런트가 데이터 채널로 프롬프트·도구 명령 등을 주입할 권한 차단
  - 480초 벽시계 종료 요청(시험 기본값, 제품에서 조정), 종료 이벤트 확인
  - sideband 조기 단절/종료 확인 타임아웃을 FINALIZATION_UNCONFIRMED로 구분
  - API 응답 본문/자격 증명/원문 전사/음성/SDP를 로그나 파일에 저장하지 않음
  - 세션 메타데이터만 메모리에 최대 기본 1시간 보관 후 제거

4. 연결되지 않은 기능과 한계

  - Jev 의미 판정 및 음성 재생 전 차단: 미연결. 직접 WebRTC 재생 경로는 출력 심사 버퍼가 아닙니다.
  - Luna 분석: 미연결. sideband의 전사/오디오 payload는 현재 버리고 있습니다.
  - 개인 기억/Neo4j: 미연결. AllowedContext.childKey는 향후 승인된 기억 조회의 서버 범위 키입니다.
  - 말로 한 종료 의도를 코드에서 감지하는 기능: 미연결. 프롬프트의 종료 수용은 의미 이해에 맡겨져 있습니다.
    종료 버튼/타이머는 코드로 집행합니다. 의미 판정기를 붙일 때 인용된 “그만”과 현재 종료 의도를 구분하세요.
  - 세션별 원문을 저장하지 않지만 store:false가 제공자의 모든 보관 정책을 없앤다는 뜻은 아닙니다.
  - 단일 프로세스 참조입니다. 여러 서버, 강제 종료·재시작·네트워크 분리 상황의 분산 소유권/복구가 없습니다.
    이 형태로 수평 확장하지 마세요. 공유 상태/lease와 제어 소켓 소유 서버 라우팅, 장애 시 프런트 강제 중지 연결이 필요합니다.
  - sideband가 끊기면 서버가 종료 명령을 보냈는지/원격 세션이 끝났는지 보장할 수 없습니다.
    UI는 status 실패를 감지하면 즉시 미디어를 끊어야 합니다. 서버 장애 시에도 프런트의 자체 종료 타이머가 필요합니다.
  - 생성 HTTP 응답을 잃거나 attach에 실패하면 세션이 생겼는지/초기화 과금이 있었는지 확실하지 않을 수 있습니다.
    같은 요청을 자동 반복하지 않고 오류로 보고합니다. 성공한 SDP answer는 attach 성공 후에만 반환합니다.
  - 브라우저별 autoplay/ICE·기업망·실제 오디오 지연·동시 부하·아동 대상 품질은 실측하지 않았습니다.
  - 제공된 하네스 요약의 3.5초 전사 안정화/20 라운드트립은 실제 최신 코드와 대조되지 않은 설명입니다.
    확인 가능한 이전 v4.2 소스는 30초 응답 대기, 전사 안정화 기본 1.2초, 시간 제한을 사용합니다.
    이 값들을 실제 연속 음성 서비스의 턴 종료 판단으로 옮기지 않았습니다.

5. 공식 계약 확인 근거 (2026-10-15)

  GPT Live WebRTC 연결:
  https://developers.openai.com/api/docs/guides/voice-webrtc
  생성 및 client.data_channel 허용 이벤트 구조:
  https://developers.openai.com/api/reference/resources/live/methods/create
  sideband 연결/종료 제어:
  https://developers.openai.com/api/docs/guides/voice-server-controls
  session.closed, 누적 usage, 종료 확인 실패:
  https://developers.openai.com/api/docs/guides/live-conversations

  이 모듈은 /v1/live/sessions + /{id}/attach를 씁니다.
  Realtime의 /v1/realtime/calls 및 SIP 전용 hangup을 혼용하지 않습니다.
