package com.mujung.live;

import org.junit.jupiter.api.Test;
import org.springframework.boot.convert.ApplicationConversionService;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import static org.junit.jupiter.api.Assertions.*;

class SpringWiringTest {
    private AnnotationConfigApplicationContext context(boolean withAccess) {
        var context=new AnnotationConfigApplicationContext();
        context.getBeanFactory().setConversionService(ApplicationConversionService.getSharedInstance());
        context.getBeanFactory().registerSingleton("testGateway",new LiveSessionServiceTest.FakeGateway());
        if(withAccess) context.getBeanFactory().registerSingleton("serviceAccessPolicy",(ServiceAccessPolicy)p->new ServiceAccessPolicy.AllowedContext("child","notice-v1"));
        context.register(MujungLiveConfiguration.class);
        return context;
    }
    @Test void hostPolicyAndPackagedPromptWireWithoutNetwork() {
        try(var context=context(true)) {
            context.refresh(); assertNotNull(context.getBean(LiveSessionController.class));
            assertEquals(480,context.getBean(LiveOptions.class).sessionLimit().toSeconds());
            assertEquals("live_1",context.getBean(LiveSessionService.class).create(()->"account","v=0").session().id());
        }
    }
    @Test void missingHostPolicyFailsStartup() {
        try(var context=context(false)) {
            assertThrows(org.springframework.beans.BeansException.class,context::refresh);
        }
    }
}
