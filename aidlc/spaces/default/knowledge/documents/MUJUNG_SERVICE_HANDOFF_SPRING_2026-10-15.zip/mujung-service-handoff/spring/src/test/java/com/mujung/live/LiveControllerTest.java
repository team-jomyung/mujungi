package com.mujung.live;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.Clock;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import org.junit.jupiter.api.*;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

class LiveControllerTest {
    ScheduledExecutorService scheduler;LiveSessionService service;MockMvc mvc;
    @BeforeEach void setup() {
        scheduler=Executors.newScheduledThreadPool(2);
        service=new LiveSessionService(new LiveSessionServiceTest.FakeGateway(),p->new ServiceAccessPolicy.AllowedContext("child","v1"),
            LiveOptions.defaults(),scheduler,Clock.systemUTC(),"trusted");
        mvc=MockMvcBuilders.standaloneSetup(new LiveSessionController(service)).build();
    }
    @AfterEach void cleanup(){service.close();scheduler.shutdownNow();}
    @Test void spoofedConfigurationRejected() throws Exception {
        mvc.perform(post("/api/mujung/live/sessions").principal(()->"a").contentType(MediaType.APPLICATION_JSON)
            .content("{\"sdp\":\"v=0\",\"model\":\"other\"}"))
            .andExpect(status().isBadRequest()).andExpect(jsonPath("$.error").value("ONLY_SDP_IS_ACCEPTED"));
    }
    @Test void authenticatedCreateReturnsOnlyPublicContract() throws Exception {
        mvc.perform(post("/api/mujung/live/sessions").principal(()->"a").contentType(MediaType.APPLICATION_JSON).content("{\"sdp\":\"v=0\"}"))
            .andExpect(status().isCreated()).andExpect(header().string("Cache-Control","no-store"))
            .andExpect(jsonPath("$.session.id").value("live_1")).andExpect(jsonPath("$.transport.sdp").value("answer"))
            .andExpect(jsonPath("$.capabilities.jev").value(false)).andExpect(jsonPath("$.apiKey").doesNotExist());
    }
    @Test void anonymousCreateDenied() throws Exception {
        mvc.perform(post("/api/mujung/live/sessions").contentType(MediaType.APPLICATION_JSON).content("{\"sdp\":\"v=0\"}"))
            .andExpect(status().isUnauthorized());
    }
}
