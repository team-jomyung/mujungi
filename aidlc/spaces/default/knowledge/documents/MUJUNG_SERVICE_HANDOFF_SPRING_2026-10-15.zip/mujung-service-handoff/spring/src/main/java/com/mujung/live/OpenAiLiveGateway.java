package com.mujung.live;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.WebSocket;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.TimeUnit;

public final class OpenAiLiveGateway implements LiveGateway {
    private final HttpClient http;
    private final ObjectMapper json;
    private final String apiKey;
    private final LiveOptions options;
    public OpenAiLiveGateway(HttpClient http, ObjectMapper json, String apiKey, LiveOptions options) {
        if (apiKey == null || apiKey.isBlank()) throw new IllegalStateException("Set OPENAI_API_KEY on the server");
        this.http=http; this.json=json; this.apiKey=apiKey; this.options=options;
    }
    /** No client configuration, prompt, identity, tools or model can be supplied by the browser. */
    public static Map<String,Object> createPayload(String sdp, String instructions) {
        return Map.of("session", Map.of("model", "gpt-live-1", "instructions", instructions, "store", false,
            "delegation", Map.of("type", "client"),
            "client", Map.of("data_channel", Map.of("allowed_client_events", List.of(),
                "allowed_server_events", List.of(Map.of("type","session.started"), Map.of("type","session.closed"),
                Map.of("type","session.usage.updated"), Map.of("type","error"))))),
            "transport", Map.of("type", "webrtc", "sdp", sdp));
    }
    @Override public Created create(String sdp, String instructions) {
        try {
            var request=HttpRequest.newBuilder(URI.create("https://api.openai.com/v1/live/sessions"))
                .timeout(options.connectTimeout()).header("Authorization", "Bearer " + apiKey)
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(json.writeValueAsString(createPayload(sdp, instructions)))).build();
            var response=http.send(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
            if (response.statusCode()<200 || response.statusCode()>=300)
                throw new LiveFailure(502, "UPSTREAM_CREATE_REJECTED");
            JsonNode body=json.readTree(response.body());
            String id=body.path("session").path("id").asText("");
            String answer=body.path("transport").path("sdp").asText("");
            if (id.isBlank() || id.length()>512 || answer.isBlank()) throw new LiveFailure(502, "UPSTREAM_CREATE_INVALID");
            return new Created(id, answer);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt(); throw new LiveFailure(503,"CREATE_INTERRUPTED_OUTCOME_UNKNOWN");
        } catch (IOException e) { throw new LiveFailure(502,"CREATE_TRANSPORT_FAILED_OUTCOME_UNKNOWN"); }
    }
    @Override public Connection attach(String sessionId, Listener listener) {
        var socketListener=new Sideband(json, listener);
        // Encode one opaque path segment. Never use a caller-provided URL.
        String segment=URLEncoder.encode(sessionId, StandardCharsets.UTF_8).replace("+","%20");
        var attempt=http.newWebSocketBuilder().connectTimeout(options.connectTimeout())
            .header("Authorization", "Bearer " + apiKey)
            .buildAsync(URI.create("wss://api.openai.com/v1/live/sessions/" + segment + "/attach"), socketListener);
        try {
            WebSocket socket=attempt.get(options.connectTimeout().toMillis(),TimeUnit.MILLISECONDS);
            return new Connection() {
                @Override public CompletionStage<Void> requestClose() {
                    return socket.sendText("{\"type\":\"session.close\"}",true).thenApply(ignored->null);
                }
                @Override public void disconnect() { socket.abort(); }
            };
        } catch (InterruptedException e) {
            attempt.cancel(true); Thread.currentThread().interrupt(); throw new LiveFailure(503,"SIDEBAND_ATTACH_INTERRUPTED");
        } catch (Exception e) {
            attempt.cancel(true); throw new LiveFailure(502,"SIDEBAND_ATTACH_FAILED");
        }
    }
    /** Drops audio/transcript content immediately. No source text is stored or logged. */
    static final class Sideband implements WebSocket.Listener {
        private final ObjectMapper json;
        private final Listener target;
        private final StringBuilder fragments=new StringBuilder();
        private boolean finalized;
        Sideband(ObjectMapper json, Listener target) { this.json=json; this.target=target; }
        @Override public void onOpen(WebSocket socket) { socket.request(1); }
        @Override public CompletionStage<?> onText(WebSocket socket, CharSequence data, boolean last) {
            if (fragments.length()+data.length()>2_000_000) {
                target.failed("UPSTREAM_EVENT_TOO_LARGE"); socket.abort(); return CompletableFuture.completedFuture(null);
            }
            fragments.append(data);
            if (last) {
                try {
                    JsonNode event=json.readTree(fragments.toString());
                    String type=event.path("type").asText();
                    if (type.equals("session.usage.updated")) {
                        Double seconds=seconds(event); if(seconds!=null) target.usage(seconds);
                    } else if(type.equals("session.closed")) {
                        String reason=event.path("reason").asText("unknown");
                        if (!List.of("close_requested","expired","content","remote_hangup","connection_lost").contains(reason)) reason="unknown";
                        finalized=true; target.finalized(reason,seconds(event));
                    } else if(type.equals("error")) {
                        target.failed("UPSTREAM_SESSION_ERROR");
                    }
                } catch (IOException e) { target.failed("UPSTREAM_EVENT_INVALID"); }
                finally { fragments.setLength(0); }
            }
            socket.request(1); return CompletableFuture.completedFuture(null);
        }
        private static Double seconds(JsonNode event) {
            JsonNode n=event.path("usage").path("seconds");
            if(!n.isNumber()) return null;
            double s=n.doubleValue(); return Double.isFinite(s)&&s>=0?s:null;
        }
        @Override public CompletionStage<?> onClose(WebSocket socket,int code,String reason) {
            fragments.setLength(0); if(!finalized) target.failed("SIDEBAND_CLOSED_BEFORE_FINAL_EVENT");
            return CompletableFuture.completedFuture(null);
        }
        @Override public void onError(WebSocket socket,Throwable error) {
            fragments.setLength(0); if(!finalized) target.failed("SIDEBAND_CONNECTION_FAILED");
        }
    }
}
