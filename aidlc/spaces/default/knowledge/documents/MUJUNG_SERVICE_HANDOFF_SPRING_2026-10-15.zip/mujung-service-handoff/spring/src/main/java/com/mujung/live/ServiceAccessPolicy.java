package com.mujung.live;

import java.security.Principal;

/** Implement in the host app. There is deliberately no permissive default bean. */
public interface ServiceAccessPolicy {
    /** Authenticate, authorize the selected child, check current consent, notice and spend/rate limits.
     * The child key must come from trusted application state, never a browser-provided child ID.
     * Throw LiveFailure(403, "SERVICE_ACCESS_DENIED") when a condition is not satisfied. */
    AllowedContext requireAllowed(Principal principal);

    record AllowedContext(String childKey, String noticeVersion) {
        public AllowedContext {
            if (childKey == null || childKey.isBlank() || noticeVersion == null || noticeVersion.isBlank())
                throw new IllegalArgumentException("A trusted child key and acknowledged notice version are required");
        }
    }
}
