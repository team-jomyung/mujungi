package com.mujung.live;

/** Deliberately contains only a safe code, never raw upstream error bodies, SDP or credentials. */
public final class LiveFailure extends RuntimeException {
    private final int httpStatus;
    private final String code;
    public LiveFailure(int httpStatus, String code) { super(code); this.httpStatus=httpStatus; this.code=code; }
    public int httpStatus() { return httpStatus; }
    public String code() { return code; }
}
