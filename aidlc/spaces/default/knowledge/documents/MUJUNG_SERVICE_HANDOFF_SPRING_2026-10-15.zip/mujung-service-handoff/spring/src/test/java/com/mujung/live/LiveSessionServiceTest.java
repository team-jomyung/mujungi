package com.mujung.live;

import org.junit.jupiter.api.*;
import java.security.Principal;
import java.time.Clock;
import java.time.Duration;
import java.util.concurrent.*;
import static org.junit.jupiter.api.Assertions.*;

class LiveSessionServiceTest {
    final Principal alice=()->"account-a";
    final Principal bob=()->"account-b";
    ScheduledExecutorService scheduler;
    FakeGateway gateway;
    LiveSessionService service;
    @BeforeEach void setup() {
        scheduler=Executors.newScheduledThreadPool(2); gateway=new FakeGateway();
        service=make(()->new ServiceAccessPolicy.AllowedContext("child-opaque-a","notice-v1"),Duration.ofSeconds(30),Duration.ofMillis(80));
    }
    LiveSessionService make(java.util.function.Supplier<ServiceAccessPolicy.AllowedContext> policy,Duration limit,Duration close) {
        return new LiveSessionService(gateway,p->policy.get(),new LiveOptions(limit,Duration.ofSeconds(1),close,Duration.ofHours(1),2),scheduler,Clock.systemUTC(),"Trusted prompt");
    }
    @AfterEach void cleanup() { service.close(); scheduler.shutdownNow(); }
    String create() { return service.create(alice,"v=0\r\n").session().id(); }
    @Test void anonymousCannotSpend() {
        assertEquals(401,assertThrows(LiveFailure.class,()->service.create(null,"v=0")).httpStatus()); assertEquals(0,gateway.creates);
    }
    @Test void policyFailureHappensBeforeUpstream() {
        service=make(()->{throw new LiveFailure(403,"SERVICE_ACCESS_DENIED");},Duration.ofSeconds(30),Duration.ofMillis(80));
        assertThrows(LiveFailure.class,this::create); assertEquals(0,gateway.creates);
    }
    @Test void nullPolicyIsNotApproval() {
        service=make(()->null,Duration.ofSeconds(30),Duration.ofMillis(80)); assertThrows(LiveFailure.class,this::create); assertEquals(0,gateway.creates);
    }
    @Test void invalidOrLargeSdpRejected() {
        assertThrows(LiveFailure.class,()->service.create(alice,"not-sdp"));
        assertThrows(LiveFailure.class,()->service.create(alice,"v=0"+"x".repeat(65536))); assertEquals(0,gateway.creates);
    }
    @Test void scopeAndCapabilitiesAreExplicit() {
        var created=service.create(alice,"v=0"); assertEquals("webrtc",created.transport().type()); assertEquals("answer",created.transport().sdp());
        assertTrue(created.capabilities().serverControl()); assertFalse(created.capabilities().jev()); assertFalse(created.capabilities().memory());
    }
    @Test void foreignAccountCannotReadOrClose() {
        String id=create(); assertEquals(404,assertThrows(LiveFailure.class,()->service.status(bob,id)).httpStatus());
        assertThrows(LiveFailure.class,()->service.close(bob,id)); assertEquals(0,gateway.closes);
    }
    @Test void oneActiveSessionPerAccountNoSilentRestart() {
        create(); assertEquals(409,assertThrows(LiveFailure.class,this::create).httpStatus()); assertEquals(1,gateway.creates);
    }
    @Test void closeIsIdempotentAndWaitsForFinalEvent() throws Exception {
        String id=create(); gateway.autoFinalize=false;
        var first=service.close(alice,id); var second=service.close(alice,id);
        assertSame(first,second); assertFalse(first.isDone()); assertEquals(1,gateway.closes);
        gateway.listener.finalized("close_requested",9.5);
        var result=first.get(1,TimeUnit.SECONDS); assertEquals("CLOSED_CONFIRMED",result.status());
        assertTrue(result.finalUsageConfirmed()); assertEquals(9.5,result.usageSeconds()); assertEquals(1,gateway.disconnects);
    }
    @Test void earlyDisconnectNeverClaimsFinalUsage() {
        String id=create(); gateway.listener.usage(12.0); gateway.listener.failed("SIDEBAND_CONNECTION_FAILED");
        var result=service.status(alice,id); assertEquals("FINALIZATION_UNCONFIRMED",result.status());
        assertFalse(result.finalUsageConfirmed()); assertEquals(12.0,result.usageSeconds());
    }
    @Test void completedEventWithoutUsageConfirmsClosureButNotUsage() {
        String id=create(); gateway.listener.finalized("remote_hangup",null);
        assertEquals("CLOSED_CONFIRMED",service.status(alice,id).status()); assertFalse(service.status(alice,id).finalUsageConfirmed());
    }
    @Test void finalizationTimeoutIsExplicit() throws Exception {
        String id=create(); gateway.autoFinalize=false;
        var result=service.close(alice,id).get(1,TimeUnit.SECONDS);
        assertEquals("FINALIZATION_UNCONFIRMED",result.status()); assertEquals("CLOSE_CONFIRMATION_TIMEOUT",result.reason());
    }
    @Test void hardDeadlineClosesWithoutMoreTranscript() throws Exception {
        service=make(()->new ServiceAccessPolicy.AllowedContext("child","v1"),Duration.ofMillis(35),Duration.ofMillis(80));
        String id=create(); assertTrue(gateway.closed.await(1,TimeUnit.SECONDS));
        assertEquals("CLOSED_CONFIRMED",service.status(alice,id).status());
    }
    @Test void attachmentFailureDoesNotExposeReadySessionOrRetryCreate() {
        gateway.failAttach=true; assertEquals("SIDEBAND_ATTACH_FAILED",assertThrows(LiveFailure.class,this::create).code());
        assertEquals(1,gateway.creates);
    }
    @Test void cumulativeUsageReplacesInsteadOfAdds() {
        String id=create(); gateway.listener.usage(12); gateway.listener.usage(15); assertEquals(15,service.status(alice,id).usageSeconds());
    }
    @Test void closeDoesNotRequireConsentToRemainEnabled() throws Exception {
        String id=create(); gateway.autoFinalize=true;
        assertEquals("CLOSED_CONFIRMED",service.close(alice,id).get().status());
    }
    @Test void finalizedStateCannotBecomeFailureFromSocketClose() {
        String id=create(); gateway.listener.finalized("close_requested",15.0); gateway.listener.failed("LATE_SOCKET_CLOSE");
        assertEquals("CLOSED_CONFIRMED",service.status(alice,id).status());
    }
    @Test void lateCreationDuringShutdownIsClosedAndNotReturned() throws Exception {
        var entered=new CountDownLatch(1);var release=new CountDownLatch(1);
        gateway=new FakeGateway() {
            @Override public Created create(String sdp,String instructions) {
                entered.countDown();try { release.await(1,TimeUnit.SECONDS); }catch(InterruptedException e){Thread.currentThread().interrupt();}
                return super.create(sdp,instructions);
            }
        };
        service=make(()->new ServiceAccessPolicy.AllowedContext("child","v1"),Duration.ofSeconds(30),Duration.ofMillis(80));
        var executor=Executors.newSingleThreadExecutor();
        try {
            Future<?> create=executor.submit(this::create);
            assertTrue(entered.await(1,TimeUnit.SECONDS)); service.close(); release.countDown();
            var error=assertThrows(ExecutionException.class,()->create.get(1,TimeUnit.SECONDS));
            assertEquals("SERVICE_STOPPING",((LiveFailure)error.getCause()).code()); assertEquals(1,gateway.closes);
        } finally { release.countDown();executor.shutdownNow(); }
    }
    @Test void shutdownWhileAttachPendingStillSendsCloseAfterAttach() throws Exception {
        var entered=new CountDownLatch(1);var release=new CountDownLatch(1);
        gateway=new FakeGateway() {
            @Override public Connection attach(String id,Listener listener) {
                entered.countDown();try { release.await(1,TimeUnit.SECONDS); }catch(InterruptedException e){Thread.currentThread().interrupt();}
                return super.attach(id,listener);
            }
        };
        service=make(()->new ServiceAccessPolicy.AllowedContext("child","v1"),Duration.ofSeconds(30),Duration.ofMillis(80));
        var executor=Executors.newSingleThreadExecutor();
        try {
            Future<?> create=executor.submit(this::create);
            assertTrue(entered.await(1,TimeUnit.SECONDS));service.close();release.countDown();
            assertThrows(ExecutionException.class,()->create.get(1,TimeUnit.SECONDS));assertEquals(1,gateway.closes);
        }finally {release.countDown();executor.shutdownNow();}
    }
    @Test void usableSocketErrorAttemptsRemoteClose() {
        String id=create();gateway.listener.failed("UPSTREAM_SESSION_ERROR");assertEquals(1,gateway.closes);
        assertEquals("CLOSED_CONFIRMED",service.status(alice,id).status());
    }
    @Test void rejectedTimerStillSendsRemoteClose() throws Exception {
        String id=create();scheduler.shutdownNow();
        assertEquals("CLOSED_CONFIRMED",service.close(alice,id).get(1,TimeUnit.SECONDS).status());assertEquals(1,gateway.closes);
    }
    static class FakeGateway implements LiveGateway {
        int creates,closes,disconnects;
        boolean autoFinalize=true,failAttach;
        Listener listener;
        CountDownLatch closed=new CountDownLatch(1);
        public Created create(String sdp,String instructions) { creates++;return new Created("live_"+creates,"answer"); }
        public Connection attach(String id,Listener listener) {
            if(failAttach) throw new LiveFailure(502,"SIDEBAND_ATTACH_FAILED"); this.listener=listener;
            return new Connection() {
                public CompletionStage<Void> requestClose() { closes++;if(autoFinalize)listener.finalized("close_requested",1.0);closed.countDown();return CompletableFuture.completedFuture(null); }
                public void disconnect() { disconnects++; }
            };
        }
    }
}
