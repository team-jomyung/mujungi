package com.mujung.live;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.net.http.HttpClient;
import java.nio.charset.StandardCharsets;
import java.time.Clock;
import java.time.Duration;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.core.io.Resource;

/** Import explicitly into the existing application. Authentication/CSRF remain owned by that app. */
@Configuration(proxyBeanMethods=false)
@Import(LiveSessionController.class)
public class MujungLiveConfiguration {
    @Bean public LiveOptions mujungLiveOptions(
        @Value("${mujung.live.session-limit:480s}") Duration limit,
        @Value("${mujung.live.connect-timeout:15s}") Duration connect,
        @Value("${mujung.live.close-timeout:10s}") Duration close,
        @Value("${mujung.live.metadata-retention:1h}") Duration retention,
        @Value("${mujung.live.max-sessions:128}") int capacity) {
        return new LiveOptions(limit,connect,close,retention,capacity);
    }
    @Bean(destroyMethod="shutdown") public ScheduledExecutorService mujungLiveScheduler() {
        return Executors.newScheduledThreadPool(2,r->{var t=new Thread(r,"mujung-live-deadline");t.setDaemon(true);return t;});
    }
    @Bean
    @org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean(LiveGateway.class)
    public LiveGateway mujungLiveGateway(ObjectMapper mapper,LiveOptions options) {
        var http=HttpClient.newBuilder().connectTimeout(options.connectTimeout()).followRedirects(HttpClient.Redirect.NEVER).build();
        return new OpenAiLiveGateway(http,mapper,System.getenv("OPENAI_API_KEY"),options);
    }
    @Bean(destroyMethod="close") public LiveSessionService mujungLiveService(LiveGateway gateway,ServiceAccessPolicy access,
        LiveOptions options,@org.springframework.beans.factory.annotation.Qualifier("mujungLiveScheduler") ScheduledExecutorService mujungLiveScheduler,
        @Value("${mujung.live.instructions:classpath:mujung/live_service_v02.txt}") Resource prompt) throws java.io.IOException {
        String instructions;
        try(var input=prompt.getInputStream()) { instructions=new String(input.readAllBytes(),StandardCharsets.UTF_8); }
        return new LiveSessionService(gateway,access,options,mujungLiveScheduler,Clock.systemUTC(),instructions);
    }
}
