package com.mujung.live;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.net.http.WebSocket;
import java.nio.ByteBuffer;
import java.util.concurrent.*;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class GatewayContractTest {
    final ObjectMapper json=new ObjectMapper();
    @Test void serverOwnsConfigurationAndBrowserCannotAppendInstructions() {
        var payload=json.valueToTree(OpenAiLiveGateway.createPayload("v=0","trusted"));
        assertEquals("gpt-live-1",payload.at("/session/model").asText());
        assertFalse(payload.at("/session/store").asBoolean());
        assertEquals(0,payload.at("/session/client/data_channel/allowed_client_events").size());
        assertEquals(4,payload.at("/session/client/data_channel/allowed_server_events").size());
        assertEquals("webrtc",payload.at("/transport/type").asText());
        assertFalse(payload.at("/session").has("audio"));
    }
    @Test void fragmentedFinalEventIsAssembledBeforeCompletion() {
        var events=new Events();var sideband=new OpenAiLiveGateway.Sideband(json,events);var ws=new FakeSocket();
        sideband.onText(ws,"{\"type\":\"session.closed\",",false);assertEquals(0,events.finalized);
        sideband.onText(ws,"\"reason\":\"close_requested\",\"usage\":{\"seconds\":12.5}}",true);
        assertEquals(1,events.finalized);assertEquals(12.5,events.seconds);
    }
    @Test void socketCloseWithoutTerminalEventIsUnconfirmed() {
        var events=new Events();var sb=new OpenAiLiveGateway.Sideband(json,events);sb.onClose(new FakeSocket(),1000,"normal");
        assertEquals("SIDEBAND_CLOSED_BEFORE_FINAL_EVENT",events.failure);
    }
    @Test void socketCloseAfterFinalEventDoesNotOverwriteIt() {
        var events=new Events();var sb=new OpenAiLiveGateway.Sideband(json,events);var ws=new FakeSocket();
        sb.onText(ws,"{\"type\":\"session.closed\",\"reason\":\"expired\",\"usage\":{\"seconds\":0}}",true);
        sb.onClose(ws,1000,"normal");assertNull(events.failure);assertEquals(0.0,events.seconds);
    }
    @Test void transcriptsAndAudioAreNotForwardedToLifecycleListener() {
        var events=new Events();var sb=new OpenAiLiveGateway.Sideband(json,events);var ws=new FakeSocket();
        sb.onText(ws,"{\"type\":\"session.input_transcript.delta\",\"delta\":\"private text\"}",true);
        sb.onText(ws,"{\"type\":\"session.output_audio.delta\",\"delta\":\"private audio\"}",true);
        assertNull(events.failure);assertNull(events.seconds);assertEquals(0,events.finalized);
    }
    @Test void invalidUsageIsNeverConvertedToZero() {
        var events=new Events();var sb=new OpenAiLiveGateway.Sideband(json,events);
        sb.onText(new FakeSocket(),"{\"type\":\"session.closed\",\"reason\":\"content\",\"usage\":{\"seconds\":\"bad\"}}",true);
        assertNull(events.seconds);
    }
    @Test void upstreamErrorsAreSafeCodes() {
        var events=new Events();var sb=new OpenAiLiveGateway.Sideband(json,events);
        sb.onText(new FakeSocket(),"{\"type\":\"error\",\"error\":{\"message\":\"secret text\"}}",true);
        assertEquals("UPSTREAM_SESSION_ERROR",events.failure);
    }
    static class Events implements LiveGateway.Listener {
        int finalized; Double seconds;String failure;
        public void usage(double seconds){this.seconds=seconds;}
        public void finalized(String reason,Double seconds){finalized++;this.seconds=seconds;}
        public void failed(String safeCode){failure=safeCode;}
    }
    static class FakeSocket implements WebSocket {
        public CompletableFuture<WebSocket> sendText(CharSequence d,boolean l){return CompletableFuture.completedFuture(this);}
        public CompletableFuture<WebSocket> sendBinary(ByteBuffer d,boolean l){return CompletableFuture.completedFuture(this);}
        public CompletableFuture<WebSocket> sendPing(ByteBuffer d){return CompletableFuture.completedFuture(this);}
        public CompletableFuture<WebSocket> sendPong(ByteBuffer d){return CompletableFuture.completedFuture(this);}
        public CompletableFuture<WebSocket> sendClose(int c,String r){return CompletableFuture.completedFuture(this);}
        public void request(long n){} public String getSubprotocol(){return "";}
        public boolean isOutputClosed(){return false;}public boolean isInputClosed(){return false;}public void abort(){}
    }
}
