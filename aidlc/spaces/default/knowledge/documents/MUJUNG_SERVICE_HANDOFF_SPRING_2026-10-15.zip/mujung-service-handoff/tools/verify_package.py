"""Offline package integrity check. Does not connect to any API."""
from pathlib import Path
import hashlib
import json
import re

root = Path(__file__).resolve().parents[1]
manifest = json.loads((root / 'PACKAGE_MANIFEST.json').read_text(encoding='utf-8'))
errors = []
for item in manifest['files']:
    path = root / item['path']
    if not path.is_file():
        errors.append('Missing: ' + item['path'])
    elif hashlib.sha256(path.read_bytes()).hexdigest() != item['sha256']:
        errors.append('Changed: ' + item['path'])
prompt = root / 'prompts/live_service_v02.txt'
resource = root / 'spring/src/main/resources/mujung/live_service_v02.txt'
if not resource.is_file() or prompt.read_bytes() != resource.read_bytes():
    errors.append('Service prompt and Spring resource differ')
for item in manifest['files']:
    path = root / item['path']
    if path.suffix == '.json':
        try:
            json.loads(path.read_text(encoding='utf-8'))
        except (ValueError, UnicodeError):
            errors.append('Invalid JSON: ' + item['path'])
for link in re.findall(r'href="([^"]+)"', (root / 'START_HERE.html').read_text(encoding='utf-8')):
    if not link.startswith(('https:', 'http:', '#')) and not (root / link).is_file():
        errors.append('Broken local guide link: ' + link)
if errors:
    raise SystemExit('\n'.join(errors))
print('PASS: %s file hashes, prompt resource, JSON files and guide links' % len(manifest['files']))
