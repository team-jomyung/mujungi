import copy
import importlib.util
import json
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("guardrail_evaluate", ROOT / "evaluate.py")
ev = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ev)
CASES = json.loads((ROOT / "cases.json").read_text(encoding="utf-8"))


def example(mode="ENFORCED", decision="BLOCK", target="BLOCK", label="HARMFUL"):
    run = ev.make_plan(CASES)["runs"][0]
    run.update(run_id="test:" + mode, mode=mode, status="COMPLETED", origin="SYNTHETIC_REPLAY",
               configuration_status="FROZEN", stimulus_audio_sha256="c" * 64)
    run["measurement"] = {"clock": "MONOTONIC_SHARED", "playback": "DEVICE_ACK", "coverage_complete": True}
    run["segments"] = [{"segment_id": "s1", "candidate_sha256": "a" * 64, "audio_sha256": "b" * 64,
                        "expected_decision": target, "content_label": label, "review_status": "DRAFT",
                        "reviewer_ids": [], "purpose": "NORMAL", "mapping_verified": True,
                        "judge": {"provider": "MOCK", "status": "COMPLETED", "decision": decision,
                                  "model": "test-fake", "requested_at_ms": 10, "completed_at_ms": 100}}]
    if mode == "OFF":
        run["segments"][0]["judge"] = {"provider": "NONE", "status": "NOT_RUN", "decision": None,
                                       "model": None, "requested_at_ms": None, "completed_at_ms": None}
    run["events"] = [{"type": "CAPTURE_START", "t_ms": 0}, {"type": "CAPTURE_END", "t_ms": 1000}]
    return run


def playback(run, start=50, end=200):
    run["events"].append({"type": "PLAYBACK", "segment_id": "s1", "start_ms": start,
                          "end_ms": end, "confirmed": True, "audio_sha256": "b" * 64})
    return run


def audit(*runs):
    return ev.evaluate({"schema_version": "1.0", "runs": list(runs)}, CASES)


def retarget(run, case_id):
    case = next(c for c in CASES["cases"] if c["case_id"] == case_id)
    run["case_id"] = case_id
    if case["kind"] == "EVENT_REPLAY":
        run["grade_band"] = "shared"
        run["experiment"] = "CANDIDATE_REPLAY"
    run["input_sha256"] = ev.digest(ev.input_payload(case, run["grade_band"]))
    return run


class CaseAndPlanTests(unittest.TestCase):
    def test_case_counts_groups_and_draft(self):
        self.assertEqual(len(CASES["cases"]), 24)
        groups = {}
        for case in CASES["cases"]:
            self.assertEqual(case["expert_status"], "DRAFT")
            groups.setdefault(case["group_id"], set()).add(case["split"])
        self.assertTrue(all(len(splits) == 1 for splits in groups.values()))
        content = [c for c in CASES["cases"] if c["kind"] == "INPUT_SCRIPT"]
        self.assertEqual(sum(c["condition"] == "normal_control" for c in content), 10)
        self.assertEqual(sum(c["condition"] == "risk_elicitation" for c in content), 10)

    def test_plan_is_not_execution_or_success(self):
        plan = ev.make_plan(CASES)
        result = ev.evaluate(plan, CASES)
        self.assertEqual(len(plan["runs"]), 132)
        self.assertIsNone(result["overall_pass"])
        self.assertFalse(result["provider_executed_by_evaluator"])
        self.assertTrue(all(r["status"] == "NOT_RUN" for r in result["per_run"]))
        self.assertTrue(all(r["playback"]["harmful_audio"]["value_ms"] is None for r in result["per_run"]))

    def test_model_payload_contains_no_oracle(self):
        payload = ev.input_payload(CASES["cases"][0], "lower")
        self.assertEqual(set(payload), {"kind", "grade_band", "turns"})


class PlaybackAuditTests(unittest.TestCase):
    def test_block_correct_does_not_erase_earlier_harm(self):
        row = audit(playback(example()))["per_run"][0]
        self.assertEqual(row["classification"]["by_review_status"]["DRAFT"]["accuracy_decided_only"]["value"], 1)
        self.assertEqual(row["playback"]["harmful_audio"]["value_ms"], 150)
        self.assertEqual(row["playback"]["before_judge"]["value_ms"], 50)
        self.assertEqual(row["playback"]["without_valid_allow"]["value_ms"], 150)

    def test_complete_sink_can_observe_zero_playback(self):
        row = audit(example())["per_run"][0]
        self.assertEqual(row["playback"]["harmful_audio"], {"status": "MEASURED", "value_ms": 0, "is_lower_bound": False})

    def test_server_audio_is_not_device_playback(self):
        run = playback(example())
        run["measurement"]["playback"] = "NOT_INSTRUMENTED"
        row = audit(run)["per_run"][0]
        self.assertEqual(row["playback"]["harmful_audio"]["status"], "NOT_MEASURED")
        self.assertIsNone(row["playback"]["harmful_audio"]["value_ms"])

    def test_missing_timestamp_cannot_imply_zero(self):
        run = playback(example())
        del run["events"][-1]["end_ms"]
        self.assertIsNone(audit(run)["per_run"][0]["playback"]["harmful_audio"]["value_ms"])

    def test_unsynchronized_clock_not_measured(self):
        run = playback(example())
        run["measurement"]["clock"] = "UNSYNCHRONIZED"
        row = audit(run)["per_run"][0]
        self.assertIsNone(row["playback"]["harmful_audio"]["value_ms"])
        self.assertEqual(row["judge_latency_ms"], [])

    def test_partial_capture_reports_only_positive_lower_bounds(self):
        run = playback(example())
        run["measurement"]["coverage_complete"] = False
        metric = audit(run)["per_run"][0]["playback"]["harmful_audio"]
        self.assertEqual(metric, {"status": "PARTIAL", "value_ms": 150, "is_lower_bound": True})
        run["events"] = run["events"][:2]
        self.assertIsNone(audit(run)["per_run"][0]["playback"]["harmful_audio"]["value_ms"])

    def test_unknown_audio_mapping_cannot_claim_no_harm(self):
        run = playback(example())
        run["segments"][0]["mapping_verified"] = False
        row = audit(run)["per_run"][0]
        self.assertEqual(row["playback"]["unknown_label_audio"]["value_ms"], 150)
        self.assertIsNone(row["playback"]["harmful_audio"]["value_ms"])

    def test_audio_hash_mismatch_not_counted_as_measured(self):
        run = playback(example())
        run["events"][-1]["audio_sha256"] = "d" * 64
        self.assertIsNone(audit(run)["per_run"][0]["playback"]["harmful_audio"]["value_ms"])

    def test_duplicate_playback_events_not_double_counted(self):
        run = playback(playback(example()))
        self.assertEqual(audit(run)["per_run"][0]["playback"]["harmful_audio"]["value_ms"], 150)

    def test_late_allow_after_end_still_stale(self):
        run = playback(example(decision="ALLOW", target="ALLOW", label="SAFE"), 350, 500)
        run["segments"][0]["judge"]["completed_at_ms"] = 300
        run["events"].extend([{"type": "END_DETECTED", "t_ms": 200}, {"type": "GATE_RELEASE", "segment_id": "s1", "t_ms": 320}])
        row = audit(run)["per_run"][0]
        self.assertEqual(row["gate_events"]["release_after_end"], 1)
        self.assertEqual(row["playback"]["post_end_normal_audio"]["value_ms"], 150)
        self.assertEqual(row["playback"]["stop_tail_ms"], 300)

    def test_approved_closing_is_not_normal_audio_after_end(self):
        run = playback(example(decision="ALLOW", target="ALLOW", label="SAFE"), 350, 500)
        run["segments"][0]["purpose"] = "APPROVED_CLOSING"
        run["events"].append({"type": "END_DETECTED", "t_ms": 200})
        self.assertEqual(audit(run)["per_run"][0]["playback"]["post_end_normal_audio"]["value_ms"], 0)

    def test_release_before_allow_detected_without_playback_claim(self):
        run = example(decision="ALLOW")
        run["measurement"]["playback"] = "NOT_INSTRUMENTED"
        run["events"].append({"type": "GATE_RELEASE", "segment_id": "s1", "t_ms": 50})
        row = audit(run)["per_run"][0]
        self.assertEqual(row["gate_events"]["release_without_valid_allow"], 1)
        self.assertIsNone(row["playback"]["harmful_audio"]["value_ms"])

    def test_end_event_without_time_is_not_not_applicable(self):
        run = playback(example())
        run["events"].append({"type": "END_DETECTED", "t_ms": None})
        row = audit(run)["per_run"][0]
        self.assertEqual(row["playback"]["post_end_normal_audio"]["status"], "NOT_MEASURED")


class ClassificationTests(unittest.TestCase):
    def test_gold_and_draft_never_share_reference_accuracy(self):
        run = example(decision="ALLOW", target="ALLOW", label="SAFE")
        run["segments"][0].update(review_status="GOLD", reviewer_ids=["expert-test"])
        draft = copy.deepcopy(run["segments"][0])
        draft.update(segment_id="s2", expected_decision="BLOCK", review_status="DRAFT", reviewer_ids=[])
        run["segments"].append(draft)
        report = audit(run)
        for block in (report["per_run"][0]["classification"], report["strata"][0]["classification"]):
            self.assertEqual(block["gold_reference_accuracy"], {"numerator": 1, "denominator": 1, "value": 1})
            self.assertEqual(block["by_review_status"]["DRAFT"]["accuracy_decided_only"]["value"], 0)
            self.assertEqual(block["by_review_status"]["REVIEWED"]["accuracy_decided_only"]["denominator"], 0)
            self.assertEqual(block["pooled_descriptive_only"]["accuracy_decided_only"]["value"], .5)

    def test_false_block_normal_control_separate_from_exposure(self):
        row = audit(example(target="ALLOW", label="SAFE"))["per_run"][0]
        self.assertEqual(row["classification"]["by_review_status"]["DRAFT"]["false_block_rate_decided_only"]["value"], 1)
        self.assertEqual(row["playback"]["harmful_audio"]["value_ms"], 0)

    def test_timeout_is_unresolved_not_correct_block(self):
        run = example()
        run["segments"][0]["judge"].update(status="TIMEOUT", decision=None, completed_at_ms=None)
        row = audit(run)["per_run"][0]
        self.assertIsNone(row["classification"]["by_review_status"]["DRAFT"]["accuracy_decided_only"]["value"])
        self.assertEqual(row["classification"]["by_review_status"]["DRAFT"]["decision_coverage"]["value"], 0)
        self.assertEqual(row["classification"]["by_review_status"]["DRAFT"]["unresolved"], 1)

    def test_hold_is_not_correct_block(self):
        row = audit(example(decision="HOLD"))["per_run"][0]
        self.assertEqual(row["classification"]["by_review_status"]["DRAFT"]["unresolved"], 1)
        self.assertIsNone(row["classification"]["by_review_status"]["DRAFT"]["accuracy_decided_only"]["value"])

    def test_off_has_no_judge_accuracy(self):
        row = audit(playback(example(mode="OFF")))["per_run"][0]
        self.assertIsNone(row["classification"]["by_review_status"]["DRAFT"]["accuracy_decided_only"]["value"])
        self.assertEqual(row["playback"]["before_judge"]["value_ms"], 150)

    def test_safe_response_to_risky_input_may_be_allowed(self):
        row = audit(example(decision="ALLOW", target="ALLOW", label="SAFE"))["per_run"][0]
        self.assertEqual(row["case_id"], "GR01R")
        self.assertEqual(row["classification"]["by_review_status"]["DRAFT"]["accuracy_decided_only"]["value"], 1)

    def test_disconnected_provider_cannot_report_completion(self):
        run = example()
        run["segments"][0]["judge"]["provider"] = "NONE"
        with self.assertRaises(ValueError):
            audit(run)

    def test_fake_cannot_be_claimed_as_provider_capture(self):
        run = example()
        run["origin"] = "PROVIDER_CAPTURE"
        with self.assertRaises(ValueError):
            audit(run)

    def test_synthetic_cannot_be_claimed_as_jev_capture(self):
        run = example()
        run["segments"][0]["judge"]["provider"] = "JEV"
        with self.assertRaises(ValueError):
            audit(run)


class PairAndValidationTests(unittest.TestCase):
    def test_end_request_without_detection_is_gap_not_inapplicable(self):
        run = retarget(playback(example()), "GR05R")
        run["events"].append({"type": "INPUT_END", "t_ms": 20})
        row = audit(run)["per_run"][0]
        self.assertTrue(row["end_detection"]["missing_required_event"])
        self.assertIn("EXPECTED_END_SIGNAL_MISSING", row["warnings"])
        self.assertEqual(row["playback"]["post_end_normal_audio"]["status"], "NOT_MEASURED")
        self.assertIsNone(row["playback"]["post_end_normal_audio"]["value_ms"])
        self.assertIsNone(row["playback"]["stop_tail_ms"])

    def test_quoted_end_is_not_expected_current_end(self):
        row = audit(retarget(example(), "GR05N"))["per_run"][0]
        self.assertFalse(row["end_detection"]["expected_by_case"])
        self.assertFalse(row["end_detection"]["missing_required_event"])
        self.assertEqual(row["playback"]["post_end_normal_audio"]["status"], "NOT_APPLICABLE")

    def test_unrun_plan_is_not_detection_failure(self):
        result = ev.evaluate(ev.make_plan(CASES), CASES)
        self.assertFalse(any(r["end_detection"]["missing_required_event"] for r in result["per_run"]))

    def test_timeout_fault_not_injected_warns(self):
        row = audit(retarget(example(decision="ALLOW"), "GR21"))["per_run"][0]
        self.assertEqual(row["fault_observation"]["status"], "INCONSISTENT_WITH_PLANNED_FAULT")
        self.assertIn("PLANNED_FAULT_INCONSISTENT_WITH_PLANNED_FAULT", row["warnings"])

    def test_timeout_fault_observed_is_separate_from_correct_block(self):
        run = retarget(example(), "GR21")
        run["segments"][0]["judge"].update(status="TIMEOUT", decision=None, completed_at_ms=None)
        row = audit(run)["per_run"][0]
        self.assertEqual(row["fault_observation"]["status"], "OBSERVED_IN_RECORD")
        self.assertIsNone(row["classification"]["gold_reference_accuracy"]["value"])

    def test_other_faults_not_automatically_declared_executed(self):
        for cid in ("GR22", "GR23", "GR24"):
            row = audit(retarget(example(decision="ALLOW"), cid))["per_run"][0]
            self.assertIn(row["fault_observation"]["status"], ("NOT_VERIFIED", "INCONSISTENT_WITH_PLANNED_FAULT"))
            self.assertTrue(any(w.startswith("PLANNED_FAULT_") for w in row["warnings"]))

    def test_late_allow_fault_requires_correct_temporal_order(self):
        run = retarget(example(decision="ALLOW"), "GR22")
        run["events"].append({"type": "END_DETECTED", "t_ms": 200})
        self.assertEqual(audit(run)["per_run"][0]["fault_observation"]["status"], "INCONSISTENT_WITH_PLANNED_FAULT")
        run["segments"][0]["judge"]["completed_at_ms"] = 250
        self.assertEqual(audit(run)["per_run"][0]["fault_observation"]["status"], "OBSERVED_IN_RECORD")

    def test_mapping_and_early_playback_fault_observed_in_record(self):
        run = retarget(example(), "GR23")
        run["segments"][0]["mapping_verified"] = False
        self.assertEqual(audit(run)["per_run"][0]["fault_observation"]["status"], "OBSERVED_IN_RECORD")
        run = retarget(playback(example(), 50, 200), "GR24")
        self.assertEqual(audit(run)["per_run"][0]["fault_observation"]["status"], "OBSERVED_IN_RECORD")

    def test_matching_triplet_comparable(self):
        result = audit(*[example(mode=m) for m in ev.MODES])
        self.assertEqual(result["paired_comparisons"][0]["status"], "COMPARABLE")
        self.assertTrue(all(s["origin"] == "SYNTHETIC_REPLAY" for s in result["strata"]))

    def test_mismatched_policy_not_comparable(self):
        runs = [example(mode=m) for m in ev.MODES]
        runs[-1]["policy_sha256"] = "f" * 64
        self.assertIn("MISMATCH_POLICY_SHA256", audit(*runs)["paired_comparisons"][0]["reasons"])

    def test_different_judge_versions_not_comparable(self):
        runs = [example(mode=m) for m in ev.MODES]
        runs[-1]["segments"][0]["judge"]["model"] = "different-fake"
        self.assertIn("JUDGE_PROVIDER_OR_MODEL_MISMATCH", audit(*runs)["paired_comparisons"][0]["reasons"])

    def test_audio_identity_required_for_live_pair(self):
        runs = [example(mode=m) for m in ev.MODES]
        runs[-1]["stimulus_audio_sha256"] = None
        self.assertIn("IDENTICAL_INPUT_AUDIO_NOT_VERIFIED", audit(*runs)["paired_comparisons"][0]["reasons"])

    def test_replay_requires_same_candidate(self):
        runs = [example(mode=m) for m in ev.MODES]
        for run in runs:
            run["experiment"] = "CANDIDATE_REPLAY"
        runs[-1]["segments"][0]["candidate_sha256"] = "f" * 64
        self.assertIn("CANDIDATE_REPLAY_MISMATCH", audit(*runs)["paired_comparisons"][0]["reasons"])

    def test_input_mutation_cannot_silently_compare(self):
        run = example()
        run["input_sha256"] = "f" * 64
        with self.assertRaises(ValueError):
            audit(run)

    def test_unknown_segment_rejected(self):
        run = playback(example())
        run["events"][-1]["segment_id"] = "unmatched"
        with self.assertRaises(ValueError):
            audit(run)

    def test_reviewed_requires_reviewer_identity(self):
        run = example()
        run["segments"][0]["review_status"] = "REVIEWED"
        with self.assertRaises(ValueError):
            audit(run)

    def test_reversed_or_nonfinite_times_rejected(self):
        for end in (-1, float("nan"), 20):
            run = playback(example(), 50, end)
            with self.assertRaises(ValueError):
                audit(run)


if __name__ == "__main__":
    unittest.main()
