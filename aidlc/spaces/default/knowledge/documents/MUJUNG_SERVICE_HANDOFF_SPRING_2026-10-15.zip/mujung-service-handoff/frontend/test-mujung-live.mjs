import test from 'node:test';
import assert from 'node:assert/strict';
import { MujungLiveClient } from './mujung-live.js';

const tick = () => new Promise(resolve => setImmediate(resolve));
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
const deferred = () => { let resolve, reject; const promise = new Promise((a,b) => { resolve=a; reject=b; }); return {promise,resolve,reject}; };
const json = payload => ({ok:true,status:200,json:async()=>payload});
const created = id => ({session:{id},transport:{type:'webrtc',sdp:'v=0\r\nanswer'},expiresAt:new Date(Date.now()+60000).toISOString(),capabilities:{serverControl:true,jev:false,memory:false,luna:false}});
const closed = id => ({sessionId:id,status:'CLOSED_CONFIRMED',reason:'USER_STOP',usageSeconds:12,finalUsageConfirmed:true});

class Peer {
  constructor(events) { this.events=events; this.listeners=new Map(); this.iceGatheringState='complete'; this.connectionState='new'; this.closed=false; }
  createDataChannel(name) { this.events.push(`channel:${name}`); this.channel={closed:false,close(){this.closed=true;}}; return this.channel; }
  addTrack() {this.events.push('addTrack');}
  async createOffer() {this.events.push('offer');return {type:'offer',sdp:'v=0\r\noffer'};}
  async setLocalDescription(value) {this.localDescription=value;}
  async setRemoteDescription(value) {this.remoteDescription=value;this.connectionState='connected';this.onconnectionstatechange?.();if(!this.omitStarted)this.channel.onmessage?.({data:JSON.stringify({type:'session.started'})});}
  addEventListener(name,fn) {this.listeners.set(name,fn);}
  removeEventListener(name) {this.listeners.delete(name);}
  close() {this.closed=true;this.connectionState='closed';}
}
function setup(overrides={}) {
  const events=[],calls=[],statuses=[],errors=[],peers=[],audios=[];
  const track={stopped:false,stop(){this.stopped=true;}};
  const stream={getTracks:()=>[track]};
  const fetch=async(path,options)=>{
    calls.push({path,options});
    if(overrides.fetch) return overrides.fetch(path,options);
    if(options.method==='GET') return json({sessionId:'s-1',status:'ACTIVE',reason:'RUNNING',usageSeconds:null,finalUsageConfirmed:false});
    return json(path.endsWith('/close')?closed('s-1'):created('s-1'));
  };
  const client=new MujungLiveClient({
    getCsrfToken:()=> 'csrf-value', onStatus:value=>statuses.push(value),onError:value=>errors.push(value),
    requestTimeoutMs:100,closeTimeoutMs:100,iceTimeoutMs:100,statusPollMs:10000,
    ...overrides.options,
    dependencies:{fetch,getUserMedia:overrides.getUserMedia || (async()=>stream),
      createPeerConnection:()=>{const peer=new Peer(events);if(overrides.peer)overrides.peer(peer);peers.push(peer);return peer;},
      createAudio:()=>{const audio={muted:false,srcObject:null,paused:false,removed:false,play:overrides.play||(()=>Promise.resolve()),pause(){this.paused=true;},remove(){this.removed=true;}};audios.push(audio);return audio;},
      createMediaStream:tracks=>({getTracks:()=>tracks}),
    },
  });
  return {client,events,calls,statuses,errors,peers,audios,track,stream};
}
async function until(predicate) {for(let i=0;i<50;i++){if(predicate())return;await tick();}throw new Error('expected state did not occur');}

test('start uses same-origin SDP-only contract and creates oai-events before offer; stop waits server',async()=>{
  const closeResponse=deferred();
  const h=setup({fetch:(path)=>path.endsWith('/close')?closeResponse.promise:Promise.resolve(json(created('s-1')))});
  const result=await h.client.start();
  assert.equal(result.status,'READY');assert.ok(h.events.indexOf('channel:oai-events')<h.events.indexOf('offer'));
  const request=h.calls[0];assert.equal(request.options.credentials,'same-origin');assert.equal(request.options.redirect,'error');
  assert.deepEqual(Object.keys(JSON.parse(request.options.body)),['sdp']);
  assert.equal(request.options.headers['X-CSRF-TOKEN'],'csrf-value');assert.equal(request.options.headers.Authorization,undefined);
  assert.deepEqual(h.client.allowedClientEvents,[]);assert.equal(h.peers[0].channel.send,undefined);
  h.peers[0].ontrack({streams:[h.stream]});
  const stopped=h.client.stop();
  assert.equal(h.track.stopped,true);assert.equal(h.audios[0].muted,true);assert.equal(h.audios[0].srcObject,null);assert.equal(h.audios[0].removed,true);
  assert.equal(h.peers[0].closed,false);
  closeResponse.resolve(json(closed('s-1')));
  assert.equal((await stopped).status,'CLOSED_CONFIRMED');assert.equal(h.peers[0].closed,true);
  assert.equal(h.calls[1].options.body,undefined);
});

test('Stop during microphone permission wait stops late tracks and never creates session',async()=>{
  const permission=deferred();const h=setup({getUserMedia:()=>permission.promise});
  const started=h.client.start();assert.equal((await h.client.stop()).status,'NO_REMOTE_SESSION');
  permission.resolve(h.stream);assert.equal((await started).status,'CANCELLED');assert.equal(h.track.stopped,true);assert.equal(h.calls.length,0);
});

test('Stop during creation closes late session exactly once and does not apply its SDP',async()=>{
  const creation=deferred();const h=setup({fetch:path=>path.endsWith('/close')?Promise.resolve(json(closed('late-1'))):creation.promise});
  const started=h.client.start();await until(()=>h.calls.length===1);
  const stopped=h.client.stop();assert.equal(h.track.stopped,true);
  creation.resolve(json(created('late-1')));
  assert.equal((await started).status,'CANCELLED');assert.equal((await stopped).status,'CLOSED_CONFIRMED');
  assert.equal(h.peers[0].remoteDescription,undefined);assert.equal(h.calls.filter(c=>c.path.endsWith('/close')).length,1);
});

test('creation timeout stops local media and late response still gets server close',async()=>{
  const creation=deferred();const h=setup({options:{requestTimeoutMs:10,closeTimeoutMs:10},fetch:path=>path.endsWith('/close')?Promise.resolve(json(closed('late-2'))):creation.promise});
  await assert.rejects(h.client.start(),{code:'SESSION_CREATE_TIMEOUT'});
  assert.equal(h.track.stopped,true);assert.equal(h.peers[0].closed,true);
  assert.equal(h.statuses.at(-1).remoteStatus,'FINALIZATION_UNCONFIRMED');
  creation.resolve(json(created('late-2')));await until(()=>h.calls.some(c=>c.path.endsWith('/close')));await tick();
  assert.equal(h.calls.filter(c=>c.path.endsWith('/close')).length,1);
});

test('malformed late response with session id is also closed after timeout',async()=>{
  const creation=deferred();const h=setup({options:{requestTimeoutMs:5,closeTimeoutMs:5},fetch:path=>path.endsWith('/close')?Promise.resolve(json(closed('late-bad'))):creation.promise});
  await assert.rejects(h.client.start(),{code:'SESSION_CREATE_TIMEOUT'});
  creation.resolve(json({session:{id:'late-bad'},transport:{type:'wrong'},capabilities:{serverControl:true}}));
  await until(()=>h.calls.some(c=>c.path.endsWith('/close')));
});

test('autoplay rejection silences microphone and closes server session',async()=>{
  const h=setup({play:()=>Promise.reject(new Error('private browser message'))});await h.client.start();
  h.peers[0].ontrack({streams:[h.stream]});await until(()=>h.track.stopped);await h.client.stop();
  assert.deepEqual(h.errors,[{code:'AUTOPLAY_BLOCKED'}]);assert.equal(h.peers[0].closed,true);
});

test('connection failure triggers cleanup and sanitized error',async()=>{
  const h=setup();await h.client.start();h.peers[0].connectionState='failed';h.peers[0].onconnectionstatechange();
  await h.client.stop();assert.equal(h.track.stopped,true);assert.equal(h.peers[0].closed,true);assert.deepEqual(h.errors,[{code:'CONNECTION_LOST'}]);
});

test('close network failure is unconfirmed, never fake confirmed',async()=>{
  const h=setup({fetch:path=>path.endsWith('/close')?Promise.reject(new Error('network')):Promise.resolve(json(created('s-1')))});
  await h.client.start();const result=await h.client.stop();assert.equal(result.status,'FINALIZATION_UNCONFIRMED');assert.equal(result.finalUsageConfirmed,false);assert.equal(h.peers[0].closed,true);
});

test('repeated Stop makes only one server close request',async()=>{
  const h=setup();await h.client.start();const results=await Promise.all([h.client.stop(),h.client.stop()]);
  assert.equal(results[0].status,'CLOSED_CONFIRMED');assert.equal(h.calls.filter(c=>c.path.endsWith('/close')).length,1);
});

test('microphone rejection sanitizes error and makes no HTTP request',async()=>{
  const h=setup({getUserMedia:()=>Promise.reject(new Error('device internal details'))});
  await assert.rejects(h.client.start(),{code:'START_FAILED'});assert.deepEqual(h.errors,[{code:'START_FAILED'}]);assert.equal(h.calls.length,0);
});

test('ICE timeout disposes tracks and transport before POST',async()=>{
  const h=setup({options:{iceTimeoutMs:5},peer:peer=>{peer.iceGatheringState='gathering';}});
  await assert.rejects(h.client.start(),{code:'ICE_TIMEOUT'});assert.equal(h.calls.length,0);assert.equal(h.track.stopped,true);assert.equal(h.peers[0].closed,true);
});

test('invalid server response with known id closes remote session',async()=>{
  const h=setup({fetch:path=>Promise.resolve(json(path.endsWith('/close')?closed('s-1'):{session:{id:'s-1'},transport:{type:'webrtc',sdp:'x'},capabilities:{serverControl:false}}))});
  await assert.rejects(h.client.start(),{code:'INVALID_SESSION_RESPONSE'});assert.equal(h.calls.filter(c=>c.path.endsWith('/close')).length,1);
});

test('poll receives terminal sideband status and stops without changing confirmation',async()=>{
  const h=setup({options:{statusPollMs:5},fetch:(path,options)=>Promise.resolve(json(options.method==='GET'?{sessionId:'s-1',status:'FINALIZATION_UNCONFIRMED',reason:'SIDEBAND_LOST',usageSeconds:null,finalUsageConfirmed:false}:created('s-1')))});
  await h.client.start();await delay(20);const result=await h.client.stop();
  assert.equal(h.track.stopped,true);assert.equal(h.peers[0].closed,true);assert.equal(result.status,'FINALIZATION_UNCONFIRMED');assert.equal(h.calls.filter(c=>c.path.endsWith('/close')).length,0);
});

test('poll CLOSED_CONFIRMED without usage preserves unknown final usage',async()=>{
  const h=setup({options:{statusPollMs:5},fetch:(path,options)=>Promise.resolve(json(options.method==='GET'?{sessionId:'s-1',status:'CLOSED_CONFIRMED',reason:'TTL',usageSeconds:null,finalUsageConfirmed:false}:created('s-1')))});
  await h.client.start();await delay(20);const result=await h.client.stop();assert.equal(result.status,'CLOSED_CONFIRMED');assert.equal(result.finalUsageConfirmed,false);assert.equal(result.usageSeconds,null);
});

test('poll error safely stops and asks backend to finalize',async()=>{
  const h=setup({options:{statusPollMs:5},fetch:(path,options)=>options.method==='GET'?Promise.reject(new Error('poll')):Promise.resolve(json(path.endsWith('/close')?closed('s-1'):created('s-1')))});
  await h.client.start();await delay(20);await h.client.stop();assert.equal(h.track.stopped,true);assert.deepEqual(h.errors,[{code:'SERVER_STATUS_UNAVAILABLE'}]);assert.equal(h.calls.filter(c=>c.path.endsWith('/close')).length,1);
});

test('poll CLOSING immediately stops capture and waits for final confirmation',async()=>{
  const final=deferred();const h=setup({options:{statusPollMs:5},fetch:(path,options)=>options.method==='GET'?Promise.resolve(json({sessionId:'s-1',status:'CLOSING',reason:'TTL',usageSeconds:10,finalUsageConfirmed:false})):path.endsWith('/close')?final.promise:Promise.resolve(json(created('s-1')))});
  await h.client.start();await delay(15);assert.equal(h.track.stopped,true);assert.equal(h.peers[0].closed,false);final.resolve(json(closed('s-1')));assert.equal((await h.client.stop()).status,'CLOSED_CONFIRMED');
});

test('cross-origin endpoint and unsafe CSRF header rejected before any work',()=>{
  assert.throws(()=>new MujungLiveClient({endpoint:'https://other.example/sessions'}),{code:'INVALID_SAME_ORIGIN_ENDPOINT'});
  assert.throws(()=>new MujungLiveClient({endpoint:'//other.example/sessions'}),{code:'INVALID_SAME_ORIGIN_ENDPOINT'});
  assert.throws(()=>new MujungLiveClient({csrfHeaderName:'Authorization'}),{code:'INVALID_CSRF_HEADER'});
});


test('local expiry watchdog stops media even while status poll is not due',async()=>{
  const h=setup({options:{maxSessionMs:10,statusPollMs:10000}});
  await h.client.start();await delay(25);assert.equal(h.track.stopped,true);
  const result=await h.client.stop();assert.equal(result.status,'CLOSED_CONFIRMED');
  assert.ok(h.statuses.some(value=>value.reason==='SESSION_TIME_LIMIT'));
  assert.equal(h.calls.filter(c=>c.options.method==='GET').length,0);
});

test('already expired session is closed before applying remote SDP',async()=>{
  const h=setup({fetch:path=>Promise.resolve(json(path.endsWith('/close')?closed('s-1'):{...created('s-1'),expiresAt:'2000-01-01T00:00:00Z'}))});
  await assert.rejects(h.client.start(),{code:'SESSION_ALREADY_EXPIRED'});
  assert.equal(h.peers[0].remoteDescription,undefined);assert.equal(h.track.stopped,true);
  assert.equal(h.calls.filter(c=>c.path.endsWith('/close')).length,1);
});


test('microphone stays disabled until session.started and timeout closes remote',async()=>{
  const h=setup({options:{requestTimeoutMs:10},peer:peer=>{peer.omitStarted=true;}});
  const started=h.client.start();await until(()=>h.calls.length===1);
  assert.equal(h.track.enabled,false);assert.equal(h.audios[0].muted,true);
  await assert.rejects(started,{code:'SESSION_STARTED_TIMEOUT'});
  assert.equal(h.track.stopped,true);assert.equal(h.calls.filter(c=>c.path.endsWith('/close')).length,1);
});

test('session.started releases mic; transcript events have no handler side effects',async()=>{
  const h=setup();await h.client.start();assert.equal(h.track.enabled,true);
  const previous=h.statuses.length;h.peers[0].channel.onmessage({data:JSON.stringify({type:'session.output_transcript.delta',delta:'private child text'})});
  assert.equal(h.statuses.length,previous);assert.equal(h.errors.length,0);await h.client.stop();
});

test('remote closed metadata immediately silences media and uses backend finalization',async()=>{
  const h=setup();await h.client.start();h.peers[0].channel.onmessage({data:JSON.stringify({type:'session.closed'})});
  assert.equal(h.track.stopped,true);assert.equal((await h.client.stop()).status,'CLOSED_CONFIRMED');
});

test('invalid metadata is ignored without logging or altering state',async()=>{
  const h=setup();await h.client.start();const n=h.statuses.length;
  for(const data of ['null','[1,2]','not-json','"text"']) h.peers[0].channel.onmessage({data});
  assert.equal(h.statuses.length,n);assert.equal(h.errors.length,0);await h.client.stop();
});

test('late microphone result from old attempt cannot stop the new session',async()=>{
  const first=deferred();let count=0;const oldTrack={stopped:false,stop(){this.stopped=true;}};
  const h=setup({getUserMedia:()=>++count===1?first.promise:Promise.resolve({getTracks:()=>[h.track]})});
  const old=h.client.start();await h.client.stop();await h.client.start();
  first.resolve({getTracks:()=>[oldTrack]});assert.equal((await old).status,'CANCELLED');
  assert.equal(oldTrack.stopped,true);assert.equal(h.track.stopped,false);await h.client.stop();
});
