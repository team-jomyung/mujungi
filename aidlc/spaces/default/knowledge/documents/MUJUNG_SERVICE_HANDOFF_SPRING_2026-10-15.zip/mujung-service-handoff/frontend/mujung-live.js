/** Mujoong browser WebRTC adapter. No OpenAI key, transcript persistence, or model commands. */
export class MujungLiveError extends Error {
  constructor(code) { super(code); this.name = 'MujungLiveError'; this.code = code; }
}

export class MujungLiveClient {
  constructor({
    endpoint = '/api/mujung/live/sessions',
    getCsrfToken = () => null,
    csrfHeaderName = 'X-CSRF-TOKEN',
    onStatus = () => {}, onError = () => {},
    requestTimeoutMs = 20000, closeTimeoutMs = 15000, iceTimeoutMs = 10000, statusPollMs = 5000, maxSessionMs = 480000,
    dependencies = {},
  } = {}) {
    if (!/^\/(?!\/)[^?#]*$/.test(endpoint) || endpoint.includes('..')) throw new MujungLiveError('INVALID_SAME_ORIGIN_ENDPOINT');
    if (!/^X-[A-Za-z0-9-]+$/i.test(csrfHeaderName)) throw new MujungLiveError('INVALID_CSRF_HEADER');
    for (const value of [requestTimeoutMs, closeTimeoutMs, iceTimeoutMs, statusPollMs, maxSessionMs]) {
      if (!Number.isFinite(value) || value <= 0) throw new MujungLiveError('INVALID_TIMEOUT');
    }
    this.endpoint = endpoint.replace(/\/$/, '');
    this.getCsrfToken = getCsrfToken;
    this.csrfHeaderName = csrfHeaderName;
    this.onStatus = onStatus; this.onError = onError;
    this.requestTimeoutMs = requestTimeoutMs; this.closeTimeoutMs = closeTimeoutMs; this.iceTimeoutMs = iceTimeoutMs; this.statusPollMs = statusPollMs; this.maxSessionMs = maxSessionMs;
    this.deps = {
      now: () => Date.now(),
      fetch: (...args) => globalThis.fetch(...args),
      getUserMedia: constraints => navigator.mediaDevices.getUserMedia(constraints),
      createPeerConnection: () => new RTCPeerConnection(),
      createAudio: () => new Audio(),
      createMediaStream: tracks => new MediaStream(tracks),
      setTimeout: (...args) => globalThis.setTimeout(...args),
      clearTimeout: id => globalThis.clearTimeout(id),
      ...dependencies,
    };
    this.current = null;
    this.allowedClientEvents = Object.freeze([]);
  }

  _status(attempt, state, extra = {}) {
    if (this.current !== attempt) return;
    try { this.onStatus({ state, ...extra }); } catch { /* UI callbacks cannot block cleanup. */ }
  }
  _error(attempt, code) {
    if (this.current !== attempt) return;
    try { this.onError({ code }); } catch { /* Do not expose exception bodies or transcript text. */ }
  }
  _timeout(promise, ms, code) {
    let timer;
    const timeout = new Promise((_, reject) => { timer = this.deps.setTimeout(() => reject(new MujungLiveError(code)), ms); });
    return Promise.race([promise, timeout]).finally(() => this.deps.clearTimeout(timer));
  }
  async _json(method, path, body) {
    const headers = {};
    const token = await this.getCsrfToken();
    if (token) headers[this.csrfHeaderName] = String(token);
    if (body !== undefined) headers['Content-Type'] = 'application/json';
    const response = await this.deps.fetch(path, {
      method, credentials: 'same-origin', redirect: 'error', cache: 'no-store', headers,
      ...(body === undefined ? {} : { body: JSON.stringify(body) }),
    });
    if (!response.ok) throw new MujungLiveError(`HTTP_${response.status}`);
    try { return await response.json(); } catch { throw new MujungLiveError('INVALID_SERVER_JSON'); }
  }
  _check(attempt) {
    if (attempt.cancelled || this.current !== attempt) throw new MujungLiveError(attempt.failureCode || 'START_CANCELLED');
  }
  _cancel(attempt) {
    attempt.cancelled = true;
    if (attempt.pollTimer) this.deps.clearTimeout(attempt.pollTimer);
    if (attempt.expiryTimer) this.deps.clearTimeout(attempt.expiryTimer);
    for (const cancel of attempt.cancelWaits) cancel();
    attempt.cancelWaits.clear();
    this._silence(attempt);
  }
  _silence(attempt) {
    if (attempt.stream) {
      for (const track of attempt.stream.getTracks()) { try { track.stop(); } catch {} }
      attempt.stream = null;
    }
    if (attempt.audio) {
      try { attempt.audio.muted = true; attempt.audio.pause(); attempt.audio.srcObject = null; attempt.audio.remove(); } catch {}
      attempt.audio = null;
    }
  }
  _disposeTransport(attempt) {
    if (attempt.transportDisposed) return;
    attempt.transportDisposed = true;
    if (attempt.channel) {
      attempt.channel.onmessage = null; attempt.channel.onerror = null; attempt.channel.onclose = null;
      try { attempt.channel.close(); } catch {}
    }
    if (attempt.peer) {
      attempt.peer.ontrack = null; attempt.peer.onconnectionstatechange = null;
      try { attempt.peer.close(); } catch {}
    }
  }
  _playAudio(attempt) {
    if (attempt.cancelled || !attempt.started || !attempt.audio?.srcObject) return;
    attempt.audio.muted = false;
    try { Promise.resolve(attempt.audio.play()).catch(() => this._failAsync(attempt, 'AUTOPLAY_BLOCKED')); }
    catch { this._failAsync(attempt, 'AUTOPLAY_BLOCKED'); }
  }
  async _waitStarted(attempt) {
    if (attempt.started) return;
    let cancel;
    const cancelled = new Promise((_, reject) => {
      cancel = () => reject(new MujungLiveError('START_CANCELLED'));
      attempt.cancelWaits.add(cancel);
    });
    try { await this._timeout(Promise.race([attempt.startedPromise, cancelled]), this.requestTimeoutMs, 'SESSION_STARTED_TIMEOUT'); }
    finally { attempt.cancelWaits.delete(cancel); }
  }
  _metadataEvent(attempt, message) {
    if (attempt.cancelled || typeof message.data !== 'string' || message.data.length > 8192) return;
    let event;
    try { event = JSON.parse(message.data); } catch { return; }
    if (!event || typeof event !== 'object') return;
    // Consume only lifecycle metadata. No transcript handling, model commands, or event logging.
    if (event.type === 'session.started') {
      attempt.started = true; attempt.resolveStarted();
    } else if (event.type === 'session.closed') {
      this._status(attempt, 'STOPPING', { reason: 'REMOTE_SESSION_CLOSED' });
      this._cancel(attempt); attempt.stopPromise = this._finish(attempt);
    } else if (event.type === 'error') this._failAsync(attempt, 'LIVE_EVENT_ERROR');
  }
  async _iceComplete(attempt) {
    const peer = attempt.peer;
    if (peer.iceGatheringState === 'complete') return;
    let onChange, cancel;
    const promise = new Promise((resolve, reject) => {
      onChange = () => { if (peer.iceGatheringState === 'complete') resolve(); };
      cancel = () => reject(new MujungLiveError('START_CANCELLED'));
      attempt.cancelWaits.add(cancel);
      peer.addEventListener('icegatheringstatechange', onChange);
      onChange();
    });
    try { await this._timeout(promise, this.iceTimeoutMs, 'ICE_TIMEOUT'); }
    finally { peer.removeEventListener('icegatheringstatechange', onChange); attempt.cancelWaits.delete(cancel); }
  }
  _armExpiry(attempt, expiresAt) {
    const expiry = typeof expiresAt === 'string' ? Date.parse(expiresAt) : NaN;
    if (!Number.isFinite(expiry)) throw new MujungLiveError('INVALID_SESSION_EXPIRY');
    const remaining = Math.min(this.maxSessionMs, expiry - this.deps.now());
    if (remaining <= 0) throw new MujungLiveError('SESSION_ALREADY_EXPIRED');
    attempt.expiryTimer = this.deps.setTimeout(() => {
      if (attempt.cancelled) return;
      this._status(attempt, 'STOPPING', { reason: 'SESSION_TIME_LIMIT' });
      this._cancel(attempt);
      attempt.stopPromise = this._finish(attempt);
    }, remaining);
  }
  _scheduleStatusPoll(attempt) {
    if (attempt.cancelled || this.current !== attempt) return;
    attempt.pollTimer = this.deps.setTimeout(async () => {
      try {
        const result = await this._timeout(this._json('GET', `${this.endpoint}/${encodeURIComponent(attempt.sessionId)}`), this.requestTimeoutMs, 'STATUS_TIMEOUT');
        if (attempt.cancelled || this.current !== attempt) return;
        if (result.sessionId !== attempt.sessionId || !['ACTIVE', 'CLOSING', 'CLOSED_CONFIRMED', 'FINALIZATION_UNCONFIRMED'].includes(result.status)) {
          throw new MujungLiveError('INVALID_STATUS_RESPONSE');
        }
        if (['CLOSED_CONFIRMED', 'FINALIZATION_UNCONFIRMED'].includes(result.status)) {
          attempt.closePromise = Promise.resolve({ sessionId: result.sessionId, status: result.status,
            finalUsageConfirmed: result.status === 'CLOSED_CONFIRMED' && result.finalUsageConfirmed === true,
            usageSeconds: typeof result.usageSeconds === 'number' && Number.isFinite(result.usageSeconds) ? result.usageSeconds : null });
          this._cancel(attempt);
          attempt.stopPromise = this._finish(attempt);
        } else if (result.status === 'CLOSING') {
          this._status(attempt, 'STOPPING', { remoteStatus: 'CLOSING' });
          this._cancel(attempt);
          attempt.stopPromise = this._finish(attempt);
        } else this._scheduleStatusPoll(attempt);
      } catch {
        if (!attempt.cancelled) this._failAsync(attempt, 'SERVER_STATUS_UNAVAILABLE');
      }
    }, this.statusPollMs);
  }
  _validSessionId(value) { return typeof value === 'string' && /^[A-Za-z0-9_.:-]{1,200}$/.test(value); }
  async _closeRemote(attempt) {
    if (!attempt.sessionId) return { status: 'NO_REMOTE_SESSION', finalUsageConfirmed: false };
    if (attempt.closePromise) return attempt.closePromise;
    attempt.closePromise = (async () => {
      try {
        const result = await this._timeout(
          this._json('POST', `${this.endpoint}/${encodeURIComponent(attempt.sessionId)}/close`),
          this.closeTimeoutMs, 'CLOSE_TIMEOUT',
        );
        if (result.sessionId !== attempt.sessionId || !['CLOSED_CONFIRMED', 'FINALIZATION_UNCONFIRMED'].includes(result.status)) {
          throw new MujungLiveError('INVALID_CLOSE_RESPONSE');
        }
        return {
          sessionId: result.sessionId, status: result.status,
          finalUsageConfirmed: result.status === 'CLOSED_CONFIRMED' && result.finalUsageConfirmed === true,
          usageSeconds: typeof result.usageSeconds === 'number' && Number.isFinite(result.usageSeconds) ? result.usageSeconds : null,
        };
      } catch {
        return { sessionId: attempt.sessionId, status: 'FINALIZATION_UNCONFIRMED', finalUsageConfirmed: false, usageSeconds: null };
      }
    })();
    return attempt.closePromise;
  }
  async _created(attempt, payload) {
    // Remember a usable id even when the rest is invalid, so cleanup can close it.
    if (this._validSessionId(payload?.session?.id)) attempt.sessionId = payload.session.id;
    if (!attempt.sessionId || payload?.transport?.type !== 'webrtc' || typeof payload.transport.sdp !== 'string' || !payload.transport.sdp.trim()
        || payload?.capabilities?.serverControl !== true) {
      throw new MujungLiveError('INVALID_SESSION_RESPONSE');
    }
    if (attempt.cancelled || this.current !== attempt) {
      const finalization = await this._closeRemote(attempt);
      this._disposeTransport(attempt);
      this._status(attempt, 'STOPPED', { remoteStatus: finalization.status });
    } else this._armExpiry(attempt, payload.expiresAt);
    return payload;
  }
  async _finish(attempt) {
    let finalization;
    if (attempt.sessionId) finalization = await this._closeRemote(attempt);
    else if (attempt.createPromise) {
      try {
        await this._timeout(attempt.createPromise, this.closeTimeoutMs, 'CREATE_SETTLE_TIMEOUT');
        finalization = await this._closeRemote(attempt);
      } catch {
        finalization = attempt.sessionId ? await this._closeRemote(attempt)
          : { status: 'FINALIZATION_UNCONFIRMED', finalUsageConfirmed: false };
      }
    } else finalization = { status: 'NO_REMOTE_SESSION', finalUsageConfirmed: false };
    this._disposeTransport(attempt);
    attempt.finished = true;
    this._status(attempt, attempt.failureCode ? 'FAILED' : 'STOPPED', { remoteStatus: finalization.status });
    return finalization;
  }
  _failAsync(attempt, code) {
    if (attempt.cancelled) return;
    attempt.failureCode = code;
    this._error(attempt, code);
    this._cancel(attempt);
    attempt.stopPromise = this._finish(attempt);
  }

  /** Call only from the application's explicit Start click. Resolves after session.started. */
  async start() {
    if (this.current && !this.current.cancelled) throw new MujungLiveError('SESSION_ALREADY_ACTIVE');
    const attempt = { cancelled: false, finished: false, cancelWaits: new Set(), sessionId: null };
    this.current = attempt;
    this._status(attempt, 'STARTING');
    try {
      const stream = await this.deps.getUserMedia({ audio: true, video: false });
      attempt.stream = stream;
      if (attempt.cancelled || this.current !== attempt) { this._silence(attempt); return { status: 'CANCELLED' }; }
      const peer = this.deps.createPeerConnection();
      attempt.peer = peer;
      attempt.audio = this.deps.createAudio();
      attempt.audio.autoplay = false; attempt.audio.playsInline = true; attempt.audio.muted = true;
      attempt.startedPromise = new Promise(resolve => { attempt.resolveStarted = resolve; });
      attempt.channel = peer.createDataChannel('oai-events');
      attempt.channel.onmessage = message => this._metadataEvent(attempt, message);
      attempt.channel.onerror = () => this._failAsync(attempt, 'DATA_CHANNEL_ERROR');
      attempt.channel.onclose = () => this._failAsync(attempt, 'DATA_CHANNEL_CLOSED');
      // The data channel has no application send() surface: allowed_client_events is empty.
      for (const track of stream.getTracks()) { track.enabled = false; peer.addTrack(track, stream); }
      peer.ontrack = event => {
        if (attempt.cancelled) return;
        const audio = attempt.audio;
        audio.srcObject = event.streams?.[0] || this.deps.createMediaStream([event.track]);
        this._playAudio(attempt);
      };
      peer.onconnectionstatechange = () => {
        if (attempt.cancelled) return;
        if (peer.connectionState === 'connected' && attempt.started) this._status(attempt, 'ACTIVE', { sessionId: attempt.sessionId });
        else if (['failed', 'disconnected', 'closed'].includes(peer.connectionState)) this._failAsync(attempt, 'CONNECTION_LOST');
      };
      const offer = await this._timeout(peer.createOffer(), this.requestTimeoutMs, 'OFFER_TIMEOUT');
      this._check(attempt);
      await this._timeout(peer.setLocalDescription(offer), this.requestTimeoutMs, 'LOCAL_SDP_TIMEOUT');
      this._check(attempt);
      await this._iceComplete(attempt);
      this._check(attempt);
      const sdp = peer.localDescription?.sdp;
      if (typeof sdp !== 'string' || !sdp.trim()) throw new MujungLiveError('EMPTY_LOCAL_SDP');
      // Keep observing the original request after timeout/Stop, to close late-created sessions.
      attempt.createPromise = this._json('POST', this.endpoint, { sdp })
        .then(payload => this._created(attempt, payload))
        .catch(async error => {
          if (attempt.cancelled && attempt.sessionId) await this._closeRemote(attempt);
          throw error;
        });
      attempt.createPromise.catch(() => {});
      const payload = await this._timeout(attempt.createPromise, this.requestTimeoutMs, 'SESSION_CREATE_TIMEOUT');
      this._check(attempt);
      await this._timeout(peer.setRemoteDescription({ type: 'answer', sdp: payload.transport.sdp }), this.requestTimeoutMs, 'REMOTE_SDP_TIMEOUT');
      this._check(attempt);
      await this._waitStarted(attempt);
      this._check(attempt);
      for (const track of stream.getTracks()) track.enabled = true;
      this._playAudio(attempt);
      this._status(attempt, peer.connectionState === 'connected' ? 'ACTIVE' : 'CONNECTING', { sessionId: attempt.sessionId });
      this._scheduleStatusPoll(attempt);
      return { status: 'READY', sessionId: attempt.sessionId, expiresAt: payload.expiresAt, capabilities: payload.capabilities };
    } catch (error) {
      if (attempt.cancelled && !attempt.failureCode) return { status: 'CANCELLED' };
      const code = error instanceof MujungLiveError ? error.code : 'START_FAILED';
      if (!attempt.failureCode) { attempt.failureCode = code; this._error(attempt, code); }
      this._cancel(attempt);
      if (!attempt.stopPromise) attempt.stopPromise = this._finish(attempt);
      await attempt.stopPromise;
      throw new MujungLiveError(attempt.failureCode);
    }
  }

  /** Stops capture/playback immediately; transport closes after bounded server finalization. */
  async stop() {
    const attempt = this.current;
    if (!attempt) return { status: 'NO_REMOTE_SESSION', finalUsageConfirmed: false };
    if (attempt.stopPromise) return attempt.stopPromise;
    this._status(attempt, 'STOPPING');
    this._cancel(attempt);
    attempt.stopPromise = this._finish(attempt);
    return attempt.stopPromise;
  }
}
