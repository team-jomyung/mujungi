브라우저 연결 모듈 — mujung-live.js
2026-10-15 / 서비스 연결 예제, 오프라인 검증

이 파일은 기존 웹 프런트에서 import하는 ES module이다. OpenAI API 키를 받거나
저장하지 않는다. 기존 앱 로그인 쿠키와 CSRF 토큰으로 같은 origin의 Spring
백엔드만 호출한다. HTTPS 또는 localhost에서 마이크 권한이 필요하다.

연결 예시

import { MujungLiveClient } from './mujung-live.js';

const live = new MujungLiveClient({
  endpoint: '/api/mujung/live/sessions',
  // 기존 Spring Security CSRF 제공 방식에 맞춰 이 함수만 연결한다.
  getCsrfToken: () => document.querySelector('meta[name="_csrf"]')?.content,
  csrfHeaderName: 'X-CSRF-TOKEN',
  onStatus: info => updateYourExistingStatusUI(info),
  onError: info => showYourExistingErrorUI(info.code),
});

startButton.addEventListener('click', async () => {
  try { await live.start(); }
  catch (error) { showYourExistingErrorUI(error.code); }
});
stopButton.addEventListener('click', async () => {
  const result = await live.stop();
  // FINALIZATION_UNCONFIRMED이면 서버 종료 확인 실패로 표시한다.
  updateYourExistingFinalizationUI(result);
});

onStatus/onError는 사용자 앱의 UI 함수다. 위 예제의 updateYour... 함수를 그대로
복사해서 실행하는 대신 현재 프런트 상태 관리/알림으로 연결한다. onError와 catch를
함께 사용하는 경우 같은 오류를 두 번 표시하지 않도록 앱에서 한 경로를 선택한다.
프런트 번들/HTML/env에 OpenAI 키를 넣지 않는다. 설치 시 자동 API 호출은 없다.
실제 start 버튼을 누르면 백엔드가 세션을 생성하여 API 사용이 시작될 수 있다.

요청 계약
POST /api/mujung/live/sessions
  body: {"sdp":"..."}
  response: {session:{id},transport:{type:"webrtc",sdp},expiresAt,
             capabilities:{serverControl:true,jev:false,memory:false,luna:false}}
GET /api/mujung/live/sessions/{id}
  response: {sessionId,status,reason,usageSeconds,finalUsageConfirmed}
POST /api/mujung/live/sessions/{id}/close
  body 없음, response는 GET과 같은 형태
모든 요청 credentials="same-origin", redirect="error", cache="no-store"다.
사용자/아동 식별자, 모델명, 프롬프트를 프런트가 지정하지 않는다.

시작 및 종료
- 사용자의 명시적 시작 클릭에서만 start()를 호출한다. 자동 재연결/자동 재시작은 없다.
- 마이크 track을 준비하되 enabled=false로 두고, oai-events 채널을 offer보다 먼저 만든다.
- 서버 SDP answer를 적용하고 session.started 메타데이터를 확인한 뒤 마이크를 활성화한다.
- 오디오 재생도 session.started 전에는 음소거한다. 브라우저 autoplay 실패는 오류로
  표시하고 캡처/재생/세션을 중단한다. 사용자가 오류를 확인한 뒤 다시 시작한다.
- stop() 호출 즉시 로컬 마이크 track을 stop하고 오디오 mute/pause/srcObject 제거한다.
  서버 close 확인을 기다린 뒤 data channel/peer transport를 정리한다.
- 마이크 권한창 대기 중 종료해도 늦게 반환된 track을 즉시 stop한다.
- 세션 POST 중 종료/시간 초과가 발생하면 원 요청 응답을 계속 관찰한다.
  늦게 도착한 session.id는 close한다. 알려진 ID는 한 번만 close 요청한다.
- POST 응답이 영구 유실되면 ID가 없어 브라우저가 원격 종료를 입증할 수 없다.
  FINALIZATION_UNCONFIRMED로 표시하며, 서버의 세션 TTL이 별도로 필요하다.
- 연결 실패·데이터 채널 오류·오디오 autoplay 실패도 자동 종료로 이어진다.

서버 제어 상태 확인
- 기본 5초마다 GET 상태를 조회한다. statusPollMs로 조정하며 3~5초를 시작값으로 쓴다.
- CLOSING 또는 종료 상태가 오면 즉시 로컬 마이크/재생을 중단한다.
- 조회 오류/시간 초과도 안전하게 중단하고 서버에 종료를 요청한다.
- expiresAt와 로컬 최대480초 중 짧은 시간을 watchdog으로 사용한다.
  maxSessionMs는 백엔드 상한에 맞춰 조정한다. 브라우저/OS가 타이머를 지연할 수 있으므로
  이것은 단독 서버 수명 제한을 대신하지 않는다.
- 일반 요청 제한20초, ICE 수집10초, 종료 확인15초가 기본이다.
  백엔드 close 대기10초보다 프런트 대기를 길게 잡았다.
- 5초 폴링 + 네트워크 요청 제한은 장애 감지 지연이다. 500ms 내 원격 종료 보장이 아니다.
- CLOSED_CONFIRMED여도 finalUsageConfirmed=false일 수 있다. 종료 확인과 최종 사용량
  확인을 구분한다. 누락된 usageSeconds는 0으로 채우지 않는다.

범위
허용 client event 목록은 빈 배열이다. 브라우저에서 session.instructions.append,
모델 명령, 종료 명령을 data channel에 보내지 않는다. 종료는 서버 API가 담당한다.
메타데이터에서 session.started/session.closed/error만 처리하고 usage 이벤트는 무시한다.
전사 이벤트·원문·키를 로그/localStorage/서버에 저장하지 않는다.
지금 기본 설정에서는 서버도 전사 이벤트를 브라우저로 허용하지 않는다.
Jev 출력 차단, Luna 분석, 개인 기억은 capabilities=false이며 이 모듈에 구현되지 않았다.
실시간 음성은 OpenAI와 WebRTC로 전송된다. 현재 서비스의 안내·접근 허용 흐름을 먼저
통과한 사용자를 백엔드가 확인해야 한다. 오디오를 모델에 전달할 수 있는 기술적 준비가
되었다는 상태는 임상적 검증이나 안전성 검증 결과가 아니다.

컴포넌트 해제
대화 화면을 떠날 때에도 stop()으로 로컬 미디어를 먼저 끈다. 페이지 종료 시에는
비동기 서버 요청의 완료가 보장되지 않으므로 서버 TTL/정리 경로를 유지한다.
아동의 음성 "그만"은 이 모듈이 전사에서 판별하지 않는다. 현재 종료 버튼과 서버 종료
상태는 코드로 집행되며, 음성 종료 의도 분류는 별도 통합·검증 영역이다.

오프라인 테스트
  node --test test-mujung-live.mjs
Node 24.16.0의 가짜 마이크/peer/fetch로 검사했다. 실제 브라우저 마이크·오디오,
WebRTC 네트워크·Spring 로그인·OpenAI 계정 권한·실제 API는 여기서 실행하지 않았다.
